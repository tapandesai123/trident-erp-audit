import { create } from 'zustand';
import type { User, AuthTokens, Plant } from '@/services/auth';

interface AuthState {
  user: User | null;
  tokens: AuthTokens | null;
  plant: Plant | null;
  isAuthenticated: boolean;
  isLoading: boolean;

  // Actions
  login: (user: User, tokens: AuthTokens, plant?: Plant) => void;
  logout: () => void;
  setPlant: (plant: Plant) => void;
  setUser: (user: User) => void;
  setLoading: (loading: boolean) => void;
  // Internal — used by axios interceptor
  _setTokens: (tokens: AuthTokens) => void;
}

export const useAuthStore = create<AuthState>()((set) => ({
  user: null,
  tokens: null,
  plant: null,
  isAuthenticated: false,
  isLoading: false,

  login: (user, tokens, plant) =>
    set({
      user,
      tokens,
      plant: plant ?? null,
      isAuthenticated: true,
    }),

  logout: () =>
    set({
      user: null,
      tokens: null,
      plant: null,
      isAuthenticated: false,
    }),

  setPlant: (plant) => set({ plant }),

  setUser: (user) => set({ user }),

  setLoading: (isLoading) => set({ isLoading }),

  _setTokens: (tokens) => set({ tokens }),
}));
