import { lazy, Suspense } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import ProtectedRoute from './ProtectedRoute';
import LoadingSpinner from '@/components/ui/LoadingSpinner';

// Eager-loaded (critical path)
import LoginPage from '@/pages/auth/LoginPage';
import ForgotPasswordPage from '@/pages/auth/ForgotPasswordPage';
import AppLayout from '@/components/layout/AppLayout';

// Lazy-loaded pages
const DashboardPage = lazy(() => import('@/pages/dashboard/DashboardPage'));
const PlaceholderPage = lazy(() => import('@/pages/PlaceholderPage'));

// Masters — Vendors
const VendorListPage = lazy(() => import('@/pages/masters/vendors/VendorListPage'));
const VendorDetailPage = lazy(() => import('@/pages/masters/vendors/VendorDetailPage'));
const VendorFormPage = lazy(() => import('@/pages/masters/vendors/VendorFormPage'));

// Masters — Items
const ItemListPage = lazy(() => import('@/pages/masters/items/ItemListPage'));
const ItemDetailPage = lazy(() => import('@/pages/masters/items/ItemDetailPage'));
const ItemFormPage = lazy(() => import('@/pages/masters/items/ItemFormPage'));

// Masters — Customers
const CustomerListPage = lazy(() => import('@/pages/masters/customers/CustomerListPage'));
const CustomerDetailPage = lazy(() => import('@/pages/masters/customers/CustomerDetailPage'));
const CustomerFormPage = lazy(() => import('@/pages/masters/customers/CustomerFormPage'));

// Purchase — Dashboard
const PurchaseDashboardPage = lazy(() => import('@/pages/purchase/PurchaseDashboardPage'));

// Purchase — PRs
const PRListPage = lazy(() => import('@/pages/purchase/requisitions/PRListPage'));
const PRDetailPage = lazy(() => import('@/pages/purchase/requisitions/PRDetailPage'));
const PRFormPage = lazy(() => import('@/pages/purchase/requisitions/PRFormPage'));

// Purchase — POs
const POListPage = lazy(() => import('@/pages/purchase/orders/POListPage'));
const PODetailPage = lazy(() => import('@/pages/purchase/orders/PODetailPage'));
const POFormPage = lazy(() => import('@/pages/purchase/orders/POFormPage'));

// Purchase — Gate Entries
const GEListPage = lazy(() => import('@/pages/purchase/gate-entries/GEListPage'));
const GEFormPage = lazy(() => import('@/pages/purchase/gate-entries/GEFormPage'));

// Purchase — MRRs
const MRRListPage = lazy(() => import('@/pages/purchase/mrrs/MRRListPage'));
const MRRDetailPage = lazy(() => import('@/pages/purchase/mrrs/MRRDetailPage'));

// Sales
const SalesDashboardPage = lazy(() => import('@/pages/sales/SalesDashboardPage'));
const EnquiryListPage = lazy(() => import('@/pages/sales/EnquiryListPage'));
const EnquiryFormPage = lazy(() => import('@/pages/sales/EnquiryFormPage'));
const QuotationListPage = lazy(() => import('@/pages/sales/QuotationListPage'));
const QuotationDetailPage = lazy(() => import('@/pages/sales/QuotationDetailPage'));
const SOListPage = lazy(() => import('@/pages/sales/SOListPage'));
const SODetailPage = lazy(() => import('@/pages/sales/SODetailPage'));
const InvoiceListPage = lazy(() => import('@/pages/sales/InvoiceListPage'));
const InvoiceDetailPage = lazy(() => import('@/pages/sales/InvoiceDetailPage'));
const ComplaintListPage = lazy(() => import('@/pages/sales/ComplaintListPage'));
const ComplaintDetailPage = lazy(() => import('@/pages/sales/ComplaintDetailPage'));
const EDIImportPage = lazy(() => import('@/pages/sales/EDIImportPage'));

// Dispatch
const DispatchPlanPage = lazy(() => import('@/pages/dispatch/DispatchPlanPage'));
const DispatchOrderPage = lazy(() => import('@/pages/dispatch/DispatchOrderPage'));
const PODUploadPage = lazy(() => import('@/pages/dispatch/PODUploadPage'));
const TransporterPaymentPage = lazy(() => import('@/pages/dispatch/TransporterPaymentPage'));

// Stores
const StoresDashboardPage = lazy(() => import('@/pages/stores/StoresDashboardPage'));
const InventoryListPage = lazy(() => import('@/pages/stores/InventoryListPage'));
const InventoryDetailPage = lazy(() => import('@/pages/stores/InventoryDetailPage'));
const BinLocationPage = lazy(() => import('@/pages/stores/BinLocationPage'));
const PhysicalVerificationPage = lazy(() => import('@/pages/stores/PhysicalVerificationPage'));
const BelowMinimumPage = lazy(() => import('@/pages/stores/BelowMinimumPage'));

// Accounts
const AccountsDashboardPage = lazy(() => import('@/pages/accounts/AccountsDashboardPage'));
const VoucherListPage = lazy(() => import('@/pages/accounts/VoucherListPage'));
const VoucherFormPage = lazy(() => import('@/pages/accounts/VoucherFormPage'));
const OutstandingPage = lazy(() => import('@/pages/accounts/OutstandingPage'));
const GSTReturnsPage = lazy(() => import('@/pages/accounts/GSTReturnsPage'));
const MSMEReportPage = lazy(() => import('@/pages/accounts/MSMEReportPage'));

// Reports
const ReportsDashboardPage = lazy(() => import('@/pages/reports/ReportsDashboardPage'));
const ReportBuilderPage = lazy(() => import('@/pages/reports/ReportBuilderPage'));

// Quality
const InspectionListPage = lazy(() => import('@/pages/quality/InspectionListPage'));
const InspectionFormPage = lazy(() => import('@/pages/quality/InspectionFormPage'));
const CAPAListPage = lazy(() => import('@/pages/quality/CAPAListPage'));
const CAPADetailPage = lazy(() => import('@/pages/quality/CAPADetailPage'));


// Production
const BOMListPage = lazy(() => import('@/pages/production/BOMPages').then(m => ({ default: m.BOMListPage })));
const BOMFormPage = lazy(() => import('@/pages/production/BOMPages').then(m => ({ default: m.BOMFormPage })));
const WorkOrderListPage = lazy(() => import('@/pages/production/WorkOrderPages').then(m => ({ default: m.WorkOrderListPage })));
const WorkOrderDetailPage = lazy(() => import('@/pages/production/WorkOrderPages').then(m => ({ default: m.WorkOrderDetailPage })));
const JobCardPage = lazy(() => import('@/pages/production/JobCardAndWIPPages').then(m => ({ default: m.JobCardPage })));
const WIPTrackingPage = lazy(() => import('@/pages/production/JobCardAndWIPPages').then(m => ({ default: m.WIPTrackingPage })));

// Tasks
const TaskListPage = lazy(() => import('@/pages/tasks/TaskPages').then(m => ({ default: m.TaskListPage })));
const TaskDetailPage = lazy(() => import('@/pages/tasks/TaskPages').then(m => ({ default: m.TaskDetailPage })));
const TaskFormPage = lazy(() => import('@/pages/tasks/TaskPages').then(m => ({ default: m.TaskFormPage })));

// HR
const EmployeeListPage = lazy(() => import('@/pages/hr/HRPages').then(m => ({ default: m.EmployeeListPage })));
const EmployeeDetailPage = lazy(() => import('@/pages/hr/HRPages').then(m => ({ default: m.EmployeeDetailPage })));

// Payroll
const SalaryListPage = lazy(() => import('@/pages/payroll/PayrollPages').then(m => ({ default: m.SalaryListPage })));
const PayslipPage = lazy(() => import('@/pages/payroll/PayrollPages').then(m => ({ default: m.PayslipPage })));

// Assets
const AssetListPage = lazy(() => import('@/pages/assets/AssetPages').then(m => ({ default: m.AssetListPage })));
const AssetDetailPage = lazy(() => import('@/pages/assets/AssetPages').then(m => ({ default: m.AssetDetailPage })));

// Maintenance
const MaintenancePage = lazy(() => import('@/pages/maintenance/MaintenancePage').then(m => ({ default: m.MaintenancePage })));

// Projects
const ProjectListPage = lazy(() => import('@/pages/projects/ProjectPages').then(m => ({ default: m.ProjectListPage })));
const ProjectDetailPage = lazy(() => import('@/pages/projects/ProjectPages').then(m => ({ default: m.ProjectDetailPage })));

// CRM
const CRMPage = lazy(() => import('@/pages/crm/CRMPage').then(m => ({ default: m.CRMPage })));

// Webtel
const WebtelPage = lazy(() => import('@/pages/webtel/WebtelPage').then(m => ({ default: m.WebtelPage })));

// Purchase — Sauda & RGP (Task 11)
const SaudaListPage = lazy(() => import('@/pages/purchase/sauda/SaudaPages').then(m => ({ default: m.SaudaListPage })));
const SaudaFormPage = lazy(() => import('@/pages/purchase/sauda/SaudaPages').then(m => ({ default: m.SaudaFormPage })));
const SaudaDetailPage = lazy(() => import('@/pages/purchase/sauda/SaudaPages').then(m => ({ default: m.SaudaDetailPage })));
const RGPListPage = lazy(() => import('@/pages/purchase/rgp/RGPPages').then(m => ({ default: m.RGPListPage })));
const RGPFormPage = lazy(() => import('@/pages/purchase/rgp/RGPPages').then(m => ({ default: m.RGPFormPage })));
const RGPDetailPage = lazy(() => import('@/pages/purchase/rgp/RGPPages').then(m => ({ default: m.RGPDetailPage })));

// Production — Downtime (Task 11)
const DowntimeListPage = lazy(() => import('@/pages/production/downtime/DowntimePage').then(m => ({ default: m.DowntimeListPage })));
const DowntimeFormPage = lazy(() => import('@/pages/production/downtime/DowntimePage').then(m => ({ default: m.DowntimeFormPage })));

// Sales — Territory & Performance (Task 11)
const TerritoryDashboardPage = lazy(() => import('@/pages/sales/territory/TerritoryPages').then(m => ({ default: m.TerritoryDashboardPage })));
const SalesmanPerformancePage = lazy(() => import('@/pages/sales/territory/TerritoryPages').then(m => ({ default: m.SalesmanPerformancePage })));

// Admin — MLF Billing (Task 11)
const MLFBillingPage = lazy(() => import('@/pages/admin/MLFBillingPage').then(m => ({ default: m.default || m.MLFBillingPage })));

// Mobile — PWA pages (Task 11)
const MobileApprovalsPage = lazy(() => import('@/pages/mobile/MobileApprovalsPage').then(m => ({ default: m.default || m.MobileApprovalsPage })));
const QRScannerPage = lazy(() => import('@/pages/mobile/QRScannerPage'));

// Portal — Dealer Portal (Task 11)
const DealerPortalPage = lazy(() => import('@/pages/portal/DealerPortalPage').then(m => ({ default: m.default || m.DealerPortalPage })));
const CustomerPortalApp = lazy(() => import('@/pages/portal/CustomerPortalApp'));

function Loader() {
  return (
    <div className="flex items-center justify-center h-64">
      <LoadingSpinner size="xl" className="text-primary-600" />
    </div>
  );
}

function Lazy({ children }: { children: React.ReactNode }) {
  return <Suspense fallback={<Loader />}>{children}</Suspense>;
}

export default function AppRoutes() {
  return (
    <Routes>
      {/* Public routes */}
      <Route path="/login" element={<LoginPage />} />
      <Route path="/forgot-password" element={<ForgotPasswordPage />} />

      {/* Protected app shell */}
      <Route
        path="/"
        element={
          <ProtectedRoute>
            <AppLayout />
          </ProtectedRoute>
        }
      >
        <Route index element={<Navigate to="/dashboard" replace />} />

        {/* Dashboard */}
        <Route path="dashboard" element={<Lazy><DashboardPage /></Lazy>} />

        {/* Masters — Vendors */}
        <Route path="masters/vendors" element={<Lazy><VendorListPage /></Lazy>} />
        <Route path="masters/vendors/new" element={<Lazy><VendorFormPage /></Lazy>} />
        <Route path="masters/vendors/:id" element={<Lazy><VendorDetailPage /></Lazy>} />
        <Route path="masters/vendors/:id/edit" element={<Lazy><VendorFormPage /></Lazy>} />

        {/* Masters — Items */}
        <Route path="masters/items" element={<Lazy><ItemListPage /></Lazy>} />
        <Route path="masters/items/new" element={<Lazy><ItemFormPage /></Lazy>} />
        <Route path="masters/items/:id" element={<Lazy><ItemDetailPage /></Lazy>} />
        <Route path="masters/items/:id/edit" element={<Lazy><ItemFormPage /></Lazy>} />

        {/* Masters — Customers */}
        <Route path="masters/customers" element={<Lazy><CustomerListPage /></Lazy>} />
        <Route path="masters/customers/new" element={<Lazy><CustomerFormPage /></Lazy>} />
        <Route path="masters/customers/:id" element={<Lazy><CustomerDetailPage /></Lazy>} />
        <Route path="masters/customers/:id/edit" element={<Lazy><CustomerFormPage /></Lazy>} />

        {/* Purchase — Dashboard */}
        <Route path="purchase" element={<Lazy><PurchaseDashboardPage /></Lazy>} />

        {/* Purchase — PRs */}
        <Route path="purchase/requisitions" element={<Lazy><PRListPage /></Lazy>} />
        <Route path="purchase/requisitions/new" element={<Lazy><PRFormPage /></Lazy>} />
        <Route path="purchase/requisitions/:id" element={<Lazy><PRDetailPage /></Lazy>} />
        <Route path="purchase/requisitions/:id/edit" element={<Lazy><PRFormPage /></Lazy>} />

        {/* Purchase — POs */}
        <Route path="purchase/orders" element={<Lazy><POListPage /></Lazy>} />
        <Route path="purchase/orders/new" element={<Lazy><POFormPage /></Lazy>} />
        <Route path="purchase/orders/:id" element={<Lazy><PODetailPage /></Lazy>} />
        <Route path="purchase/orders/:id/edit" element={<Lazy><POFormPage /></Lazy>} />

        {/* Purchase — Gate Entries */}
        <Route path="purchase/gate-entries" element={<Lazy><GEListPage /></Lazy>} />
        <Route path="purchase/gate-entries/new" element={<Lazy><GEFormPage /></Lazy>} />
        <Route path="purchase/gate-entries/:id" element={<Lazy><GEListPage /></Lazy>} />

        {/* Purchase — MRRs */}
        <Route path="purchase/mrrs" element={<Lazy><MRRListPage /></Lazy>} />
        <Route path="purchase/mrrs/:id" element={<Lazy><MRRDetailPage /></Lazy>} />

        {/* Stores */}
        <Route path="stores" element={<Lazy><StoresDashboardPage /></Lazy>} />
        <Route path="stores/inventory" element={<Lazy><InventoryListPage /></Lazy>} />
        <Route path="stores/inventory/:id" element={<Lazy><InventoryDetailPage /></Lazy>} />
        <Route path="stores/bin-locations" element={<Lazy><BinLocationPage /></Lazy>} />
        <Route path="stores/physical-verification" element={<Lazy><PhysicalVerificationPage /></Lazy>} />
        <Route path="stores/below-minimum" element={<Lazy><BelowMinimumPage /></Lazy>} />

        {/* Sales */}
        <Route path="sales" element={<Lazy><SalesDashboardPage /></Lazy>} />
        <Route path="sales/enquiries" element={<Lazy><EnquiryListPage /></Lazy>} />
        <Route path="sales/enquiries/new" element={<Lazy><EnquiryFormPage /></Lazy>} />
        <Route path="sales/enquiries/:id" element={<Lazy><EnquiryFormPage /></Lazy>} />
        <Route path="sales/quotations" element={<Lazy><QuotationListPage /></Lazy>} />
        <Route path="sales/quotations/:id" element={<Lazy><QuotationDetailPage /></Lazy>} />
        <Route path="sales/orders" element={<Lazy><SOListPage /></Lazy>} />
        <Route path="sales/orders/:id" element={<Lazy><SODetailPage /></Lazy>} />
        <Route path="sales/despatches" element={<Lazy><SOListPage /></Lazy>} />
        <Route path="sales/invoices" element={<Lazy><InvoiceListPage /></Lazy>} />
        <Route path="sales/invoices/:id" element={<Lazy><InvoiceDetailPage /></Lazy>} />
        <Route path="sales/complaints" element={<Lazy><ComplaintListPage /></Lazy>} />
        <Route path="sales/complaints/new" element={<Lazy><ComplaintDetailPage /></Lazy>} />
        <Route path="sales/complaints/:id" element={<Lazy><ComplaintDetailPage /></Lazy>} />
        <Route path="sales/edi-import" element={<Lazy><EDIImportPage /></Lazy>} />

        {/* Accounts */}
        <Route path="accounts" element={<Lazy><AccountsDashboardPage /></Lazy>} />
        <Route path="accounts/vouchers" element={<Lazy><VoucherListPage /></Lazy>} />
        <Route path="accounts/vouchers/new" element={<Lazy><VoucherFormPage /></Lazy>} />
        <Route path="accounts/vouchers/:id" element={<Lazy><VoucherFormPage /></Lazy>} />
        <Route path="accounts/outstanding" element={<Lazy><OutstandingPage /></Lazy>} />
        <Route path="accounts/gst" element={<Lazy><GSTReturnsPage /></Lazy>} />
        <Route path="accounts/msme-report" element={<Lazy><MSMEReportPage /></Lazy>} />

        {/* Quality */}
        <Route path="quality/inspections" element={<Lazy><InspectionListPage /></Lazy>} />
        <Route path="quality/inspections/new" element={<Lazy><InspectionFormPage /></Lazy>} />
        <Route path="quality/inspections/:id" element={<Lazy><InspectionFormPage /></Lazy>} />
        <Route path="quality/capa" element={<Lazy><CAPAListPage /></Lazy>} />
        <Route path="quality/capa/:id" element={<Lazy><CAPADetailPage /></Lazy>} />


        {/* Production */}
        <Route path="production/boms" element={<Lazy><BOMListPage /></Lazy>} />
        <Route path="production/boms/new" element={<Lazy><BOMFormPage /></Lazy>} />
        <Route path="production/boms/:id" element={<Lazy><BOMFormPage /></Lazy>} />
        <Route path="production/work-orders" element={<Lazy><WorkOrderListPage /></Lazy>} />
        <Route path="production/work-orders/new" element={<Lazy><WorkOrderListPage /></Lazy>} />
        <Route path="production/work-orders/:id" element={<Lazy><WorkOrderDetailPage /></Lazy>} />
        <Route path="production/job-cards" element={<Lazy><JobCardPage /></Lazy>} />
        <Route path="production/job-cards/new" element={<Lazy><JobCardPage /></Lazy>} />
        <Route path="production/job-cards/:id" element={<Lazy><JobCardPage /></Lazy>} />
        <Route path="production/wip" element={<Lazy><WIPTrackingPage /></Lazy>} />
        <Route path="production/downtime" element={<Lazy><DowntimeListPage /></Lazy>} />
        <Route path="production/downtime/new" element={<Lazy><DowntimeFormPage /></Lazy>} />

        {/* Tasks */}
        <Route path="tasks" element={<Lazy><TaskListPage /></Lazy>} />
        <Route path="tasks/new" element={<Lazy><TaskFormPage /></Lazy>} />
        <Route path="tasks/:id" element={<Lazy><TaskDetailPage /></Lazy>} />
        <Route path="tasks/:id/edit" element={<Lazy><TaskFormPage /></Lazy>} />

        {/* HR */}
        <Route path="hr/employees" element={<Lazy><EmployeeListPage /></Lazy>} />
        <Route path="hr/employees/:id" element={<Lazy><EmployeeDetailPage /></Lazy>} />
        <Route path="hr/*" element={<Lazy><EmployeeListPage /></Lazy>} />

        {/* Payroll */}
        <Route path="payroll" element={<Lazy><SalaryListPage /></Lazy>} />
        <Route path="payroll/payslip/:id" element={<Lazy><PayslipPage /></Lazy>} />
        <Route path="payroll/*" element={<Lazy><SalaryListPage /></Lazy>} />

        {/* Assets */}
        <Route path="assets" element={<Lazy><AssetListPage /></Lazy>} />
        <Route path="assets/:id" element={<Lazy><AssetDetailPage /></Lazy>} />

        {/* Maintenance */}
        <Route path="maintenance" element={<Lazy><MaintenancePage /></Lazy>} />
        <Route path="maintenance/*" element={<Lazy><MaintenancePage /></Lazy>} />

        {/* Projects */}
        <Route path="projects" element={<Lazy><ProjectListPage /></Lazy>} />
        <Route path="projects/:id" element={<Lazy><ProjectDetailPage /></Lazy>} />

        {/* CRM */}
        <Route path="crm" element={<Lazy><CRMPage /></Lazy>} />
        <Route path="crm/*" element={<Lazy><CRMPage /></Lazy>} />

        {/* Webtel */}
        <Route path="webtel" element={<Lazy><WebtelPage /></Lazy>} />
        <Route path="webtel/*" element={<Lazy><WebtelPage /></Lazy>} />

        {/* Standalone modules */}
        {/* Dispatch */}
        <Route path="dispatch/plan" element={<Lazy><DispatchPlanPage /></Lazy>} />
        <Route path="dispatch/orders" element={<Lazy><TransporterPaymentPage /></Lazy>} />
        <Route path="dispatch/orders/:id" element={<Lazy><DispatchOrderPage /></Lazy>} />
        <Route path="dispatch/pod/:id" element={<Lazy><PODUploadPage /></Lazy>} />
        <Route path="dispatch/payments" element={<Lazy><TransporterPaymentPage /></Lazy>} />
        <Route path="reports" element={<Lazy><ReportsDashboardPage /></Lazy>} />
        <Route path="reports/builder" element={<Lazy><ReportBuilderPage /></Lazy>} />

        {/* Purchase — Sauda & RGP (Task 11) */}
        <Route path="purchase/sauda" element={<Lazy><SaudaListPage /></Lazy>} />
        <Route path="purchase/sauda/new" element={<Lazy><SaudaFormPage /></Lazy>} />
        <Route path="purchase/sauda/:id" element={<Lazy><SaudaDetailPage /></Lazy>} />
        <Route path="purchase/rgp" element={<Lazy><RGPListPage /></Lazy>} />
        <Route path="purchase/rgp/new" element={<Lazy><RGPFormPage /></Lazy>} />
        <Route path="purchase/rgp/:id" element={<Lazy><RGPDetailPage /></Lazy>} />

        {/* Sales — Territory & Performance (Task 11) */}
        <Route path="sales/territories" element={<Lazy><TerritoryDashboardPage /></Lazy>} />
        <Route path="sales/performance" element={<Lazy><SalesmanPerformancePage /></Lazy>} />

        {/* Admin (Task 11) */}
        <Route path="admin/mlf-billing" element={<Lazy><MLFBillingPage /></Lazy>} />

        {/* Mobile / PWA (Task 11) */}
        <Route path="mobile/approvals" element={<Lazy><MobileApprovalsPage /></Lazy>} />
        <Route path="mobile/scanner" element={<Lazy><QRScannerPage /></Lazy>} />

        {/* 404 inside app */}
        <Route path="*" element={<Navigate to="/dashboard" replace />} />
      </Route>

      {/* Customer Portal — standalone layout, no ERP chrome (Task 14) */}
      <Route path="/portal" element={<Lazy><CustomerPortalApp /></Lazy>} />
      <Route path="/portal/*" element={<Lazy><CustomerPortalApp /></Lazy>} />

      {/* Global fallback */}
      <Route path="*" element={<Navigate to="/login" replace />} />
    </Routes>
  );
}
