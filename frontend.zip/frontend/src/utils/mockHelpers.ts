/** Lightweight mock data helpers used across new modules */

export function rand(min: number, max: number) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

export function pick<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

export function fmtINR(n: number) {
  return '₹' + n.toLocaleString('en-IN');
}

export function fmtDate(d: Date | string) {
  const dt = typeof d === 'string' ? new Date(d) : d;
  return dt.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
}

export const STATUSES = {
  task: ['TODO', 'IN_PROGRESS', 'DONE', 'CANCELLED'] as const,
  priority: ['LOW', 'MEDIUM', 'HIGH', 'CRITICAL'] as const,
  wo: ['PLANNED', 'RELEASED', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED'] as const,
};

export type TaskStatus = typeof STATUSES.task[number];
export type Priority = typeof STATUSES.priority[number];
export type WOStatus = typeof STATUSES.wo[number];

export const PRIORITY_COLOR: Record<string, string> = {
  LOW: 'bg-neutral-100 text-neutral-600',
  MEDIUM: 'bg-blue-100 text-blue-700',
  HIGH: 'bg-orange-100 text-orange-700',
  CRITICAL: 'bg-red-100 text-red-700',
};

export const STATUS_COLOR: Record<string, string> = {
  TODO: 'bg-neutral-100 text-neutral-600',
  IN_PROGRESS: 'bg-blue-100 text-blue-700',
  DONE: 'bg-green-100 text-green-700',
  CANCELLED: 'bg-red-100 text-red-600',
  PLANNED: 'bg-neutral-100 text-neutral-600',
  RELEASED: 'bg-blue-100 text-blue-700',
  COMPLETED: 'bg-green-100 text-green-700',
  ACTIVE: 'bg-green-100 text-green-700',
  INACTIVE: 'bg-neutral-100 text-neutral-500',
  OPEN: 'bg-yellow-100 text-yellow-700',
  CLOSED: 'bg-green-100 text-green-700',
  OVERDUE: 'bg-red-100 text-red-700',
};
