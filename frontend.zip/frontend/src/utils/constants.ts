export const MODULE_NAMES = {
  DASHBOARD: 'Dashboard',
  MASTERS: 'Masters',
  PURCHASE: 'Purchase',
  STORES: 'Stores',
  SALES: 'Sales',
  ACCOUNTS: 'Accounts',
  PRODUCTION: 'Production',
  QUALITY: 'Quality',
  DISPATCH: 'Dispatch',
  CRM: 'CRM',
  HR: 'HR',
  PAYROLL: 'Payroll',
  ASSETS: 'Assets',
  MAINTENANCE: 'Maintenance',
  PROJECTS: 'Projects',
  TASKS: 'Tasks',
  REPORTS: 'Reports',
  WEBTEL: 'Webtel',
} as const;

export const PRIORITY_LEVELS = ['LOW', 'MEDIUM', 'HIGH', 'CRITICAL'] as const;
export type PriorityLevel = (typeof PRIORITY_LEVELS)[number];

export const PRIORITY_LABELS: Record<PriorityLevel, string> = {
  LOW: 'Low',
  MEDIUM: 'Medium',
  HIGH: 'High',
  CRITICAL: 'Critical',
};

export const DEFAULT_PAGE_SIZE = 20;
export const PAGE_SIZE_OPTIONS = [10, 20, 50, 100];

export const GST_RATES = [0, 5, 12, 18, 28];

export const UOM_OPTIONS = [
  'NOS', 'KGS', 'MTR', 'LTR', 'SET', 'BOX', 'PKT', 'DZN', 'SQM', 'CFT',
];
