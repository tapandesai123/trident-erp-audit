import type { PRStatus, POStatus, GEStatus, MRRStatus } from '@/services/purchase';
import type { BadgeVariant } from './status';
import { cn } from './cn';

export const PR_STATUS_LABELS: Record<PRStatus, string> = {
  DRAFT: 'Draft',
  SUBMITTED: 'Submitted',
  HOD_APPROVED: 'HOD Approved',
  PLANT_HEAD_APPROVED: 'Plant Head Approved',
  DIRECTOR_APPROVED: 'Director Approved',
  REJECTED: 'Rejected',
  CANCELLED: 'Cancelled',
  PO_CREATED: 'PO Created',
};

export const PO_STATUS_LABELS: Record<POStatus, string> = {
  DRAFT: 'Draft',
  SUBMITTED: 'Submitted',
  ACCOUNTS_CHECKED: 'Accounts Checked',
  APPROVED: 'Approved',
  PARTIALLY_RECEIVED: 'Partial Receipt',
  FULLY_RECEIVED: 'Fully Received',
  CANCELLED: 'Cancelled',
  AMENDED: 'Amended',
  CLOSED: 'Closed',
};

export const PRIORITY_CONFIG: Record<string, { label: string; cls: string }> = {
  URGENT: { label: 'Urgent', cls: 'bg-danger-100 text-danger-700 border-danger-200' },
  HIGH: { label: 'High', cls: 'bg-warning-100 text-warning-700 border-warning-200' },
  NORMAL: { label: 'Normal', cls: 'bg-neutral-100 text-neutral-600 border-neutral-200' },
  LOW: { label: 'Low', cls: 'bg-blue-50 text-blue-600 border-blue-100' },
};

export function priorityBadgeClass(priority: string) {
  return cn(
    'inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold border',
    PRIORITY_CONFIG[priority]?.cls ?? PRIORITY_CONFIG.NORMAL.cls
  );
}

export const PR_STATUS_VARIANT: Record<PRStatus, BadgeVariant> = {
  DRAFT: 'neutral',
  SUBMITTED: 'info',
  HOD_APPROVED: 'warning',
  PLANT_HEAD_APPROVED: 'warning',
  DIRECTOR_APPROVED: 'success',
  REJECTED: 'danger',
  CANCELLED: 'danger',
  PO_CREATED: 'primary',
};

export const PO_STATUS_VARIANT: Record<POStatus, BadgeVariant> = {
  DRAFT: 'neutral',
  SUBMITTED: 'info',
  ACCOUNTS_CHECKED: 'info',
  APPROVED: 'success',
  PARTIALLY_RECEIVED: 'warning',
  FULLY_RECEIVED: 'success',
  CANCELLED: 'danger',
  AMENDED: 'warning',
  CLOSED: 'neutral',
};

export const GE_STATUS_LABELS: Record<GEStatus, string> = {
  PENDING: 'Pending MRR',
  MRR_CREATED: 'MRR Created',
  REJECTED: 'Rejected',
};

export const MRR_STATUS_LABELS: Record<MRRStatus, string> = {
  DRAFT: 'Draft',
  QC_PENDING: 'QC Pending',
  QC_PASSED: 'QC Passed',
  QC_REJECTED: 'QC Rejected',
  COMPLETED: 'Completed',
};

export const RECEIPT_PCT_COLOR = (pct: number) =>
  pct >= 100 ? 'text-success-700' : pct >= 50 ? 'text-warning-700' : 'text-neutral-500';

// Approval level the PR is currently at
export function getPRApprovalLevel(status: PRStatus): number | null {
  if (status === 'SUBMITTED') return 1;
  if (status === 'HOD_APPROVED') return 2;
  if (status === 'PLANT_HEAD_APPROVED') return 3;
  return null;
}
