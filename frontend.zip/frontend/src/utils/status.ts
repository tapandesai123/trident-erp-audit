export type BadgeVariant = 'primary' | 'success' | 'warning' | 'danger' | 'neutral' | 'info';

const STATUS_MAP: Record<string, BadgeVariant> = {
  // Generic workflow statuses
  DRAFT: 'neutral',
  PENDING: 'warning',
  SUBMITTED: 'info',
  APPROVED: 'success',
  REJECTED: 'danger',
  CANCELLED: 'danger',
  CLOSED: 'neutral',
  ACTIVE: 'success',
  INACTIVE: 'neutral',

  // Purchase
  OPEN: 'info',
  PARTIAL: 'warning',
  FULFILLED: 'success',
  RECEIVED: 'success',
  INVOICED: 'primary',
  // PR statuses
  HOD_APPROVED: 'warning',
  PLANT_HEAD_APPROVED: 'warning',
  DIRECTOR_APPROVED: 'success',
  PO_CREATED: 'primary',
  RETURNED: 'warning',
  // PO statuses
  ACCOUNTS_CHECKED: 'info',
  PARTIALLY_RECEIVED: 'warning',
  FULLY_RECEIVED: 'success',
  AMENDED: 'warning',
  // Gate Entry
  MRR_CREATED: 'success',
  // MRR / QC
  QC_PENDING: 'warning',
  QC_PASSED: 'success',
  QC_REJECTED: 'danger',
  QUARANTINE: 'warning',

  // Production
  PLANNED: 'info',
  IN_PROGRESS: 'warning',
  COMPLETED: 'success',
  ON_HOLD: 'neutral',

  // Quality
  PASS: 'success',
  FAIL: 'danger',
  UNDER_REVIEW: 'warning',

  // Tasks
  TODO: 'neutral',
  IN_REVIEW: 'info',
  DONE: 'success',
  OVERDUE: 'danger',

  // Assets/Maintenance
  OPERATIONAL: 'success',
  UNDER_MAINTENANCE: 'warning',
  DECOMMISSIONED: 'danger',
  OPEN_ISSUE: 'warning',
  RESOLVED: 'success',
};

const STATUS_LABELS: Record<string, string> = {
  IN_PROGRESS: 'In Progress',
  UNDER_REVIEW: 'Under Review',
  OPEN_ISSUE: 'Open',
};

export function getStatusVariant(status: string): BadgeVariant {
  return STATUS_MAP[status.toUpperCase()] ?? 'neutral';
}

export function getStatusLabel(status: string): string {
  const upper = status.toUpperCase();
  return STATUS_LABELS[upper] ?? status.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());
}
