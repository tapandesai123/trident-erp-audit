/**
 * Service Worker for Trident ERP PWA
 * Uses Workbox via vite-plugin-pwa for caching strategy.
 *
 * Build-time: vite-plugin-pwa generates the final SW from this template.
 * Runtime caching strategies:
 *   - Static assets: CacheFirst (long TTL)
 *   - API responses: StaleWhileRevalidate (5 min TTL)
 *   - Offline fallback: shows cached version or offline.html
 */

import { precacheAndRoute, cleanupOutdatedCaches } from 'workbox-precaching';
import { registerRoute } from 'workbox-routing';
import { StaleWhileRevalidate, CacheFirst, NetworkFirst } from 'workbox-strategies';
import { ExpirationPlugin } from 'workbox-expiration';
import { CacheableResponsePlugin } from 'workbox-cacheable-response';

declare let self: ServiceWorkerGlobalScope;

// Clean up old caches
cleanupOutdatedCaches();

// Precache static assets (injected by vite-plugin-pwa at build time)
precacheAndRoute(self.__WB_MANIFEST);

// ── API Caching: StaleWhileRevalidate ────────────────────────────
registerRoute(
  ({ url }) => url.pathname.startsWith('/api/v1/'),
  new StaleWhileRevalidate({
    cacheName: 'api-cache',
    plugins: [
      new ExpirationPlugin({ maxAgeSeconds: 300 }), // 5 min
      new CacheableResponsePlugin({ statuses: [0, 200] }),
    ],
  })
);

// ── Static Assets: CacheFirst ────────────────────────────────────
registerRoute(
  ({ request }) => request.destination === 'image' || request.destination === 'font',
  new CacheFirst({
    cacheName: 'static-assets',
    plugins: [
      new ExpirationPlugin({ maxAgeSeconds: 7 * 24 * 60 * 60 }), // 7 days
      new CacheableResponsePlugin({ statuses: [0, 200] }),
    ],
  })
);

// ── Navigation: NetworkFirst with fallback ────────────────────────
registerRoute(
  ({ request }) => request.mode === 'navigate',
  new NetworkFirst({
    cacheName: 'pages-cache',
    plugins: [
      new CacheableResponsePlugin({ statuses: [0, 200] }),
    ],
    networkTimeoutSeconds: 3,
  })
);

// ── Offline Fallback ──────────────────────────────────────────────
self.addEventListener('fetch', (event) => {
  if (event.request.mode === 'navigate') {
    event.respondWith(
      fetch(event.request).catch(() =>
        caches.match('/index.html').then(r => r ?? new Response('Offline — please reconnect', { status: 503 }))
      )
    );
  }
});

// ── Background Sync: queue failed mutations ──────────────────────
self.addEventListener('sync', (event: any) => {
  if (event.tag === 'background-sync') {
    console.log('[SW] Background sync triggered');
  }
});

// ── Push Notifications ────────────────────────────────────────────
self.addEventListener('push', (event) => {
  const data = event.data?.json() ?? {};
  event.waitUntil(
    self.registration.showNotification(data.title || 'Trident ERP', {
      body: data.body || 'You have a new notification',
      icon: '/icons/icon-192.png',
      badge: '/icons/icon-192.png',
      data: { url: data.url || '/' },
    })
  );
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const url = event.notification.data?.url || '/';
  event.waitUntil(
    (self.clients as any).openWindow(url)
  );
});
