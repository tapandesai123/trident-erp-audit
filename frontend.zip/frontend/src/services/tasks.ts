// frontend/src/services/tasks.ts
import api from './api';

export const tasksService = {
  list: (params?: Record<string, unknown>) =>
    api.get('/api/v1/tasks/tasks/', { params }).then(r => r.data),
  get: (id: string) =>
    api.get(`/api/v1/tasks/tasks/${id}/`).then(r => r.data),
  create: (data: unknown) =>
    api.post('/api/v1/tasks/tasks/', data).then(r => r.data),
  update: (id: string, data: unknown) =>
    api.patch(`/api/v1/tasks/tasks/${id}/`, data).then(r => r.data),
  updateStatus: (id: string, status: string) =>
    api.post(`/api/v1/tasks/tasks/${id}/update_status/`, { status }).then(r => r.data),
  delete: (id: string) =>
    api.delete(`/api/v1/tasks/tasks/${id}/`).then(r => r.data),
  myTasks: () =>
    api.get('/api/v1/tasks/tasks/my_tasks/').then(r => r.data),
  overdue: () =>
    api.get('/api/v1/tasks/tasks/overdue/').then(r => r.data),
};
