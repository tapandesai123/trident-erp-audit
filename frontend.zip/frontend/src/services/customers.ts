import api, { PaginatedResponse } from './api';

export interface CustomerGroup {
  id: number;
  code: string;
  name: string;
}

export interface CustomerShipAddress {
  id?: number;
  label: string;
  address_line1: string;
  address_line2: string;
  city: string;
  state: string;
  pincode: string;
  gstin: string;
  contact_person: string;
  phone: string;
  is_default: boolean;
  is_active: boolean;
}

export interface CustomerContact {
  id?: number;
  name: string;
  designation: string;
  phone: string;
  mobile: string;
  email: string;
  is_primary: boolean;
}

export interface Customer {
  id: string;
  code: string;
  name: string;
  legal_name: string;
  customer_group: number | null;
  customer_group_name?: string;
  customer_type: 'DIRECT' | 'DEALER' | 'E_COMMERCE' | 'INSTITUTIONAL';
  // Address
  address_line1: string;
  address_line2: string;
  city: string;
  state: string;
  pincode: string;
  country: string;
  // Contact
  phone: string;
  mobile: string;
  email: string;
  website: string;
  contact_person: string;
  // Statutory
  gstin: string;
  pan: string;
  gst_type: 'REGULAR' | 'COMPOSITION' | 'UNREGISTERED' | 'INTERNATIONAL';
  // Commercial
  credit_days: number;
  credit_limit: string;
  payment_terms: string;
  // Sales
  sales_region: string;
  sales_zone: string;
  sales_territory: string;
  portal_enabled: boolean;
  is_active: boolean;
  notes: string;
  created_at: string;
  updated_at: string;
  ship_addresses?: CustomerShipAddress[];
  contacts?: CustomerContact[];
}

export interface CustomerListItem {
  id: string;
  code: string;
  name: string;
  customer_type: string;
  city: string;
  gstin: string;
  credit_limit: string;
  customer_group_name?: string;
  sales_territory: string;
  is_active: boolean;
}

export interface CustomerParams {
  search?: string;
  customer_type?: string;
  customer_group?: string;
  sales_territory?: string;
  sales_zone?: string;
  sales_region?: string;
  portal_enabled?: string;
  ordering?: string;
  limit?: number;
  offset?: number;
}

export const customersService = {
  getCustomers: (params?: CustomerParams) =>
    api.get<PaginatedResponse<CustomerListItem>>('masters/customers/', { params }).then(r => r.data),

  getCustomer: (id: string) =>
    api.get<Customer>(`masters/customers/${id}/`).then(r => r.data),

  createCustomer: (data: Partial<Customer>) =>
    api.post<Customer>('masters/customers/', data).then(r => r.data),

  updateCustomer: (id: string, data: Partial<Customer>) =>
    api.patch<Customer>(`masters/customers/${id}/`, data).then(r => r.data),

  getShipAddresses: (id: string) =>
    api.get<CustomerShipAddress[]>(`masters/customers/${id}/ship_addresses/`).then(r => r.data),

  addShipAddress: (id: string, data: Partial<CustomerShipAddress>) =>
    api.post<CustomerShipAddress>(`masters/customers/${id}/ship_addresses/`, data).then(r => r.data),

  exportCustomers: (params?: CustomerParams) =>
    api.get('masters/customers/export_excel/', { params, responseType: 'blob' }).then(r => r.data),

  importCustomers: (file: File) => {
    const form = new FormData();
    form.append('file', file);
    return api.post('masters/customers/import_excel/', form, {
      headers: { 'Content-Type': 'multipart/form-data' },
    }).then(r => r.data);
  },

  getGroups: () =>
    api.get<CustomerGroup[]>('masters/customer-groups/').then(r => r.data),
};
