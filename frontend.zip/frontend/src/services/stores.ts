import api, { PaginatedResponse } from './api';

// ─── Types ────────────────────────────────────────────────────────

export type QCStatus = 'PENDING' | 'PASSED' | 'REJECTED' | 'WAIVED';
export type LotStatus = 'AVAILABLE' | 'RESERVED' | 'CONSUMED' | 'QUARANTINE';

export interface InventoryLot {
  id: string;
  lot_number: string;
  roll_number?: string;
  item: string;
  item_code: string;
  item_name: string;
  quantity: string;
  uom_code: string;
  warehouse: string;
  warehouse_name: string;
  bin_location: string;
  bin_code: string;
  status: LotStatus;
  qc_status: QCStatus;
  received_date: string;
  age_days: number;
  mrr_number?: string;
  transactions?: LotTransaction[];
}

export interface LotTransaction {
  id: string;
  date: string;
  type: string;
  qty_in?: string;
  qty_out?: string;
  reference: string;
  user_name: string;
  remarks?: string;
}

export interface Warehouse {
  id: string;
  code: string;
  name: string;
  is_active: boolean;
}

export interface BinLocation {
  id: string;
  code: string;
  warehouse: string;
  warehouse_name: string;
  row_label: string;
  column_label: string;
  level_label?: string;
  capacity?: number;
  occupied_qty: number;
  occupancy_pct: number;
  lot_count: number;
}

export interface PhysicalVerification {
  id: string;
  verification_number: string;
  warehouse: string;
  warehouse_name: string;
  bay?: string;
  started_at: string;
  completed_at?: string;
  status: 'IN_PROGRESS' | 'SUBMITTED' | 'APPROVED';
  created_by_name: string;
}

export interface VerificationLine {
  id?: string;
  lot_number: string;
  item_code: string;
  item_name: string;
  bin_code: string;
  system_qty: string;
  counted_qty?: string;
  variance?: string;
  remarks?: string;
}

export interface BelowMinimumItem {
  item: string;
  item_code: string;
  item_name: string;
  item_group: string;
  current_stock: string;
  min_stock: string;
  uom_code: string;
  shortage: string;
  shortage_pct: number;
  warehouse_name: string;
  last_received_date?: string;
}

export interface StoresDashboardData {
  stock_value_by_warehouse: { warehouse: string; value: number }[];
  aging_buckets: { label: string; qty: number; value: number }[];
  qc_pending_count: number;
  total_lots: number;
  total_value: number;
  below_minimum_count: number;
}

// ─── Service ──────────────────────────────────────────────────────

export const storesService = {
  // Inventory
  listInventory: (params?: Record<string, unknown>) =>
    api.get<PaginatedResponse<InventoryLot>>('stores/inventory/', { params }).then(r => r.data),

  getLot: (id: string) =>
    api.get<InventoryLot>(`stores/inventory/${id}/`).then(r => r.data),

  transferLot: (id: string, payload: { target_bin: string; qty: string; remarks?: string }) =>
    api.post(`stores/inventory/${id}/transfer/`, payload).then(r => r.data),

  adjustLot: (id: string, payload: { adjustment_qty: string; reason: string; remarks?: string }) =>
    api.post(`stores/inventory/${id}/adjust/`, payload).then(r => r.data),

  getLotQR: (id: string) =>
    api.get<{ qr_data: string; qr_url: string }>(`stores/inventory/${id}/qr/`).then(r => r.data),

  printTag: (id: string, size: 'A4' | 'LABEL_60x70') =>
    api.get(`stores/inventory/${id}/print-tag/`, { params: { size }, responseType: 'blob' })
      .then(r => r.data as Blob),

  updateWeight: (id: string, payload: { new_weight: number; reason: string }) =>
    api.post<{ qr_base64: string; new_weight: number; lot_number: string }>(
      `stores/inventory/${id}/update-weight/`, payload
    ).then(r => r.data),

  batchPrint: (lot_ids: string[], size: 'A4' | 'LABEL_60x70') =>
    api.post(`stores/inventory/batch-print/`, { lot_ids, size }, { responseType: 'blob' })
      .then(r => r.data as Blob),

  // FIFO check for a specific lot
  checkFifo: (lotId: string, itemId: string, plantId?: string) => {
    const params: Record<string, string> = { item: itemId };
    if (plantId) params.plant = plantId;
    return api.get<{ violated: boolean; older_lot_number: string | null; older_lot_date: string | null }>(
      `stores/lots/${lotId}/fifo-check/`, { params }
    ).then(r => r.data);
  },

  // Create stock issue (with optional FIFO override)
  createIssue: (payload: Record<string, unknown>, overrideReason?: string) => {
    const headers: Record<string, string> = {};
    if (overrideReason) {
      headers['X-FIFO-Override'] = 'true';
    }
    return api.post('stores/issues/', payload, { headers }).then(r => r.data);
  },

  // Warehouses
  listWarehouses: () =>
    api.get<{ results: Warehouse[] }>('stores/warehouses/').then(r => r.data.results),

  // Bin locations
  listBins: (params?: Record<string, unknown>) =>
    api.get<PaginatedResponse<BinLocation>>('stores/bin-locations/', { params }).then(r => r.data),

  getBinLots: (binId: string) =>
    api.get<InventoryLot[]>(`stores/bin-locations/${binId}/lots/`).then(r => r.data),

  // Physical verification
  listVerifications: (params?: Record<string, unknown>) =>
    api.get<PaginatedResponse<PhysicalVerification>>('stores/physical-verifications/', { params }).then(r => r.data),

  createVerification: (payload: { warehouse: string; bay?: string }) =>
    api.post<PhysicalVerification>('stores/physical-verifications/', payload).then(r => r.data),

  getVerification: (id: string) =>
    api.get<PhysicalVerification & { lines: VerificationLine[] }>(`stores/physical-verifications/${id}/`).then(r => r.data),

  scanQR: (verificationId: string, qrData: string) =>
    api.post<VerificationLine>(`stores/physical-verifications/${verificationId}/scan/`, { qr_data: qrData }).then(r => r.data),

  updateLine: (verificationId: string, lineId: string, payload: Partial<VerificationLine>) =>
    api.patch<VerificationLine>(`stores/physical-verifications/${verificationId}/lines/${lineId}/`, payload).then(r => r.data),

  submitVerification: (id: string) =>
    api.post(`stores/physical-verifications/${id}/submit/`).then(r => r.data),

  // Below minimum
  listBelowMinimum: (params?: Record<string, unknown>) =>
    api.get<PaginatedResponse<BelowMinimumItem>>('stores/below-minimum/', { params }).then(r => r.data),

  // Dashboard
  getDashboard: () =>
    api.get<StoresDashboardData>('stores/dashboard/').then(r => r.data),
};
