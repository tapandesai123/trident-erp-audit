import api from './api';

export interface LoginCredentials {
  username: string;
  password: string;
}

export interface AuthTokens {
  access: string;
  refresh: string;
}

export interface User {
  id: number;
  username: string;
  email: string;
  first_name: string;
  last_name: string;
  full_name: string;
  is_staff: boolean;
  is_active: boolean;
  roles: string[];
  permissions: string[];
}

export interface Plant {
  id: number;
  code: string;
  name: string;
  address?: string;
}

export interface LoginResponse {
  access: string;
  refresh: string;
  user: User;
  plants: Plant[];
}

export const authService = {
  async login(username: string, password: string): Promise<LoginResponse> {
    const { data } = await api.post<LoginResponse>('auth/login/', { username, password });
    return data;
  },

  async logout(refreshToken: string): Promise<void> {
    await api.post('auth/logout/', { refresh: refreshToken });
  },

  async refreshToken(refresh: string): Promise<AuthTokens> {
    const { data } = await api.post<AuthTokens>('auth/token/refresh/', { refresh });
    return data;
  },

  async getCurrentUser(): Promise<User> {
    const { data } = await api.get<User>('auth/me/');
    return data;
  },

  async forgotPassword(email: string): Promise<{ detail: string }> {
    const { data } = await api.post<{ detail: string }>('auth/password/reset/', { email });
    return data;
  },

  async getPlants(): Promise<Plant[]> {
    const { data } = await api.get<Plant[]>('auth/plants/');
    return data;
  },
};
