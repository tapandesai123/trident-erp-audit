// frontend/src/services/payroll.ts
import api from './api';

export const payrollService = {
  list: (params?: Record<string, unknown>) =>
    api.get('/api/v1/payroll/salary-records/', { params }).then(r => r.data),
  get: (id: string) =>
    api.get(`/api/v1/payroll/salary-records/${id}/`).then(r => r.data),
  create: (data: unknown) =>
    api.post('/api/v1/payroll/salary-records/', data).then(r => r.data),
  update: (id: string, data: unknown) =>
    api.patch(`/api/v1/payroll/salary-records/${id}/`, data).then(r => r.data),

  // Payslips
  listPayslips: (params?: Record<string, unknown>) =>
    api.get('/api/v1/payroll/payslips/', { params }).then(r => r.data),
  getPayslip: (id: string) =>
    api.get(`/api/v1/payroll/payslips/${id}/`).then(r => r.data),
  downloadPayslip: (id: string) =>
    api.get(`/api/v1/payroll/payslips/${id}/download/`, { responseType: 'blob' }).then(r => r.data),

  // Process Payroll
  processPayroll: (data: { month: string; year: number }) =>
    api.post('/api/v1/payroll/process-payroll/', data).then(r => r.data),
  getProcessingStatus: (jobId: string) =>
    api.get(`/api/v1/payroll/process-payroll/${jobId}/status/`).then(r => r.data),
};
