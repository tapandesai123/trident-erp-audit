// frontend/src/services/assets.ts
import api from './api';

export const assetsService = {
  list: (params?: Record<string, unknown>) =>
    api.get('/api/v1/assets/assets/', { params }).then(r => r.data),
  get: (id: string) =>
    api.get(`/api/v1/assets/assets/${id}/`).then(r => r.data),
  create: (data: unknown) =>
    api.post('/api/v1/assets/assets/', data).then(r => r.data),
  update: (id: string, data: unknown) =>
    api.patch(`/api/v1/assets/assets/${id}/`, data).then(r => r.data),
  retire: (id: string, reason: string) =>
    api.post(`/api/v1/assets/assets/${id}/retire/`, { reason }).then(r => r.data),

  // Depreciation
  listDepreciationRuns: () =>
    api.get('/api/v1/assets/depreciation-runs/').then(r => r.data),
  runDepreciation: (data: { period_end: string }) =>
    api.post('/api/v1/assets/depreciation-runs/', data).then(r => r.data),

  // Categories
  listCategories: () =>
    api.get('/api/v1/assets/asset-categories/').then(r => r.data),

  // Transfers
  listTransfers: () =>
    api.get('/api/v1/assets/transfers/').then(r => r.data),
  createTransfer: (data: unknown) =>
    api.post('/api/v1/assets/transfers/', data).then(r => r.data),
};
