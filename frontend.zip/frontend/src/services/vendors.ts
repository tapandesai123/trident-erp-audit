import api, { PaginatedResponse } from './api';

export interface VendorGroup {
  id: number;
  code: string;
  name: string;
}

export interface VendorContact {
  id?: number;
  name: string;
  designation: string;
  phone: string;
  mobile: string;
  email: string;
  is_primary: boolean;
}

export interface Vendor {
  id: string;
  code: string;
  name: string;
  legal_name: string;
  vendor_group: number | null;
  vendor_group_name?: string;
  vendor_type: 'SUPPLIER' | 'TRANSPORTER' | 'JOB_WORKER' | 'SERVICE_PROVIDER';
  // Address
  address_line1: string;
  address_line2: string;
  city: string;
  state: string;
  pincode: string;
  country: string;
  // Contact
  phone: string;
  mobile: string;
  email: string;
  website: string;
  contact_person: string;
  // Statutory
  gstin: string;
  pan: string;
  gst_type: 'REGULAR' | 'COMPOSITION' | 'UNREGISTERED' | 'INTERNATIONAL';
  tds_applicable: boolean;
  tds_section: string;
  tds_rate: string;
  tcs_applicable: boolean;
  tcs_rate: string;
  msme_registered: boolean;
  msme_number: string;
  msme_type: string;
  // Bank
  bank_name: string;
  bank_account: string;
  bank_ifsc: string;
  bank_branch: string;
  // Commercial
  credit_days: number;
  credit_limit: string;
  payment_terms: string;
  delivery_rating: string;
  // Status
  is_approved: boolean;
  approved_by_name?: string;
  approved_at?: string;
  is_active: boolean;
  notes: string;
  created_at: string;
  updated_at: string;
  contacts?: VendorContact[];
}

export interface VendorListItem {
  id: string;
  code: string;
  name: string;
  vendor_type: string;
  city: string;
  gstin: string;
  is_approved: boolean;
  delivery_rating: string;
  vendor_group_name?: string;
  is_active: boolean;
}

export interface VendorParams {
  search?: string;
  vendor_type?: string;
  gst_type?: string;
  is_approved?: string;
  is_active?: string;
  ordering?: string;
  limit?: number;
  offset?: number;
}

export const vendorsService = {
  getVendors: (params?: VendorParams) =>
    api.get<PaginatedResponse<VendorListItem>>('masters/vendors/', { params }).then(r => r.data),

  getVendor: (id: string) =>
    api.get<Vendor>(`masters/vendors/${id}/`).then(r => r.data),

  createVendor: (data: Partial<Vendor>) =>
    api.post<Vendor>('masters/vendors/', data).then(r => r.data),

  updateVendor: (id: string, data: Partial<Vendor>) =>
    api.patch<Vendor>(`masters/vendors/${id}/`, data).then(r => r.data),

  approveVendor: (id: string, action: 'APPROVE' | 'REJECT', remarks?: string) =>
    api.post<Vendor>(`masters/vendors/${id}/approve/`, { action, remarks }).then(r => r.data),

  exportVendors: (params?: VendorParams) =>
    api.get('masters/vendors/export_excel/', { params, responseType: 'blob' }).then(r => r.data),

  importVendors: (file: File) => {
    const form = new FormData();
    form.append('file', file);
    return api.post('masters/vendors/import_excel/', form, {
      headers: { 'Content-Type': 'multipart/form-data' },
    }).then(r => r.data);
  },

  getGroups: () =>
    api.get<VendorGroup[]>('masters/vendor-groups/').then(r => r.data),
};
