// frontend/src/services/crm.ts
import api from './api';

export const crmService = {
  // Leads
  listLeads: (params?: Record<string, unknown>) =>
    api.get('/api/v1/crm/leads/', { params }).then(r => r.data),
  getLead: (id: string) =>
    api.get(`/api/v1/crm/leads/${id}/`).then(r => r.data),
  createLead: (data: unknown) =>
    api.post('/api/v1/crm/leads/', data).then(r => r.data),
  updateLead: (id: string, data: unknown) =>
    api.patch(`/api/v1/crm/leads/${id}/`, data).then(r => r.data),
  convertLead: (id: string) =>
    api.post(`/api/v1/crm/leads/${id}/convert/`).then(r => r.data),

  // Opportunities
  listOpportunities: (params?: Record<string, unknown>) =>
    api.get('/api/v1/crm/opportunities/', { params }).then(r => r.data),
  getOpportunity: (id: string) =>
    api.get(`/api/v1/crm/opportunities/${id}/`).then(r => r.data),
  createOpportunity: (data: unknown) =>
    api.post('/api/v1/crm/opportunities/', data).then(r => r.data),
  updateOpportunity: (id: string, data: unknown) =>
    api.patch(`/api/v1/crm/opportunities/${id}/`, data).then(r => r.data),

  // Visit Logs
  listVisits: (params?: Record<string, unknown>) =>
    api.get('/api/v1/crm/visit-logs/', { params }).then(r => r.data),
  createVisit: (data: unknown) =>
    api.post('/api/v1/crm/visit-logs/', data).then(r => r.data),

  // Follow-ups
  listFollowUps: (params?: Record<string, unknown>) =>
    api.get('/api/v1/crm/follow-ups/', { params }).then(r => r.data),
  createFollowUp: (data: unknown) =>
    api.post('/api/v1/crm/follow-ups/', data).then(r => r.data),
  pendingFollowUps: () =>
    api.get('/api/v1/crm/follow-ups/pending/').then(r => r.data),
};
