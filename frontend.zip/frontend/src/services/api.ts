import axios, { AxiosError, InternalAxiosRequestConfig } from 'axios';
import { useAuthStore } from '@/stores/authStore';

export interface PaginatedResponse<T> {
  count: number;
  next: string | null;
  previous: string | null;
  results: T[];
}

export interface ApiError {
  message: string;
  code?: string;
  detail?: string;
  errors?: Record<string, string[]>;
}

// Extend axios config to track retry state
interface RetryConfig extends InternalAxiosRequestConfig {
  _retry?: boolean;
}

export const api = axios.create({
  baseURL: '/api/v1/',
  headers: { 'Content-Type': 'application/json' },
  timeout: 30000,
});

// Request interceptor — attach access token + plant header
api.interceptors.request.use((config) => {
  const { tokens, plant } = useAuthStore.getState();

  if (tokens?.access) {
    config.headers.Authorization = `Bearer ${tokens.access}`;
  }
  if (plant?.id) {
    config.headers['X-Plant-ID'] = String(plant.id);
  }
  return config;
});

// Response interceptor — auto-refresh on 401
api.interceptors.response.use(
  (response) => response,
  async (error: AxiosError) => {
    const originalRequest = error.config as RetryConfig;

    if (error.response?.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true;
      const { tokens, logout, _setTokens } = useAuthStore.getState();

      if (tokens?.refresh) {
        try {
          const { data } = await axios.post('/api/v1/auth/token/refresh/', {
            refresh: tokens.refresh,
          });
          _setTokens({ access: data.access, refresh: tokens.refresh });
          originalRequest.headers.Authorization = `Bearer ${data.access}`;
          return api(originalRequest);
        } catch {
          logout();
        }
      } else {
        logout();
      }
    }

    return Promise.reject(error);
  }
);

export default api;
