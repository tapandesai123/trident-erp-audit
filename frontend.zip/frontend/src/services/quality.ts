import api, { PaginatedResponse } from './api';

// ─── Types ────────────────────────────────────────────────────────

export type InspectionType = 'INWARD' | 'IN_PROCESS' | 'FINAL';
export type InspectionResult = 'PASS' | 'FAIL' | 'CONDITIONAL';
export type CAPAStatus = 'OPEN' | 'IN_PROGRESS' | 'CLOSED' | 'OVERDUE';

export interface QCParameter {
  id: string;
  name: string;
  unit?: string;
  min_value?: number;
  max_value?: number;
  expected_value?: string;
  is_numeric: boolean;
  observed_value?: string;
  observed_numeric?: number;
  result?: 'PASS' | 'FAIL';
}

export interface InspectionListItem {
  id: string;
  inspection_number: string;
  inspection_type: InspectionType;
  item: string;
  item_code: string;
  item_name: string;
  lot_number?: string;
  mrr_number?: string;
  result?: InspectionResult;
  inspector: string;
  inspector_name: string;
  inspection_date: string;
  status: 'PENDING' | 'COMPLETED';
}

export interface Inspection {
  id: string;
  inspection_number: string;
  inspection_type: InspectionType;
  item: string;
  item_code: string;
  item_name: string;
  item_group: string;
  lot_number?: string;
  mrr_number?: string;
  source_ref?: string;
  inspector: string;
  inspector_name: string;
  inspection_date: string;
  result?: InspectionResult;
  overall_remarks?: string;
  parameters: QCParameter[];
  capa_id?: string;
  status: 'PENDING' | 'COMPLETED';
}

export interface CAPAListItem {
  id: string;
  capa_number: string;
  source_type: string;
  source_ref: string;
  item_name: string;
  defect_description: string;
  root_cause?: string;
  assigned_to: string;
  assigned_to_name: string;
  due_date: string;
  status: CAPAStatus;
  created_at: string;
}

export interface CAPAStatusUpdate {
  id: string;
  status: CAPAStatus;
  remarks: string;
  updated_by_name: string;
  updated_at: string;
}

export interface CAPA {
  id: string;
  capa_number: string;
  source_type: string;
  source_ref: string;
  inspection?: string;
  item: string;
  item_name: string;
  defect_description: string;
  root_cause?: string;
  corrective_actions?: string;
  preventive_actions?: string;
  assigned_to: string;
  assigned_to_name: string;
  due_date: string;
  status: CAPAStatus;
  created_at: string;
  created_by_name: string;
  status_updates: CAPAStatusUpdate[];
}

// ─── Service ──────────────────────────────────────────────────────

export const qualityService = {
  listInspections: (params?: Record<string, unknown>) =>
    api.get<PaginatedResponse<InspectionListItem>>('quality/inspections/', { params }).then(r => r.data),

  getInspection: (id: string) =>
    api.get<Inspection>(`quality/inspections/${id}/`).then(r => r.data),

  createInspection: (payload: Partial<Inspection>) =>
    api.post<Inspection>('quality/inspections/', payload).then(r => r.data),

  submitInspection: (id: string, payload: {
    parameters: { id: string; observed_value?: string; observed_numeric?: number }[];
    overall_remarks?: string;
    result: InspectionResult;
  }) =>
    api.post<Inspection>(`quality/inspections/${id}/submit/`, payload).then(r => r.data),

  getItemParameters: (itemId: string) =>
    api.get<QCParameter[]>(`quality/parameters/?item=${itemId}`).then(r => r.data),

  // CAPA
  listCAPAs: (params?: Record<string, unknown>) =>
    api.get<PaginatedResponse<CAPAListItem>>('quality/capas/', { params }).then(r => r.data),

  getCAPADetail: (id: string) =>
    api.get<CAPA>(`quality/capas/${id}/`).then(r => r.data),

  createCAPA: (payload: Partial<CAPA>) =>
    api.post<CAPA>('quality/capas/', payload).then(r => r.data),

  updateCAPA: (id: string, payload: Partial<CAPA>) =>
    api.patch<CAPA>(`quality/capas/${id}/`, payload).then(r => r.data),

  addStatusUpdate: (id: string, payload: { status: CAPAStatus; remarks: string }) =>
    api.post<CAPAStatusUpdate>(`quality/capas/${id}/status-updates/`, payload).then(r => r.data),
};
