import api, { PaginatedResponse } from './api';

// ─── Shared types ─────────────────────────────────────────────────

export type EnquiryStatus = 'NEW' | 'FOLLOWUP' | 'QUOTED' | 'WON' | 'LOST' | 'CANCELLED';
export type QuotationStatus = 'DRAFT' | 'SENT' | 'APPROVED' | 'REVISED' | 'REJECTED' | 'CONVERTED';
export type SOStatus = 'DRAFT' | 'CONFIRMED' | 'IN_PRODUCTION' | 'READY' | 'PARTIALLY_DISPATCHED' | 'DISPATCHED' | 'CLOSED' | 'CANCELLED';
export type InvoiceStatus = 'DRAFT' | 'GENERATED' | 'SENT' | 'PAID' | 'OVERDUE' | 'CANCELLED';
export type ArtworkStatus = 'PENDING' | 'APPROVED' | 'REJECTED';
export type ComplaintSeverity = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
export type ComplaintStatus = 'OPEN' | 'INVESTIGATING' | 'RESOLVED' | 'CLOSED';

// ─── Enquiry ──────────────────────────────────────────────────────

export interface FollowupEntry {
  id: string;
  date: string;
  mode: string;
  remarks: string;
  next_followup_date?: string;
  created_by_name: string;
}

export interface EnquiryListItem {
  id: string;
  enquiry_number: string;
  customer: string;
  customer_name: string;
  item_description: string;
  quantity: string;
  status: EnquiryStatus;
  enquiry_date: string;
  next_followup_date?: string;
  assigned_to_name: string;
  estimated_value?: string;
}

export interface Enquiry extends EnquiryListItem {
  uom?: string;
  uom_code?: string;
  remarks?: string;
  followups: FollowupEntry[];
  quotation_id?: string;
  quotation_number?: string;
}

// ─── Quotation ────────────────────────────────────────────────────

export interface QuotationLine {
  id?: string;
  line_number: number;
  item?: string;
  item_code?: string;
  item_name?: string;
  description: string;
  quantity: string;
  uom?: string;
  uom_code?: string;
  unit_price: string;
  discount_pct?: string;
  tax_rate?: string;
  amount: string;
  remarks?: string;
}

export interface QuotationListItem {
  id: string;
  quotation_number: string;
  revision: number;
  customer: string;
  customer_name: string;
  quotation_date: string;
  valid_until?: string;
  status: QuotationStatus;
  total_amount: string;
  currency?: string;
  enquiry_number?: string;
}

export interface Quotation extends QuotationListItem {
  lines: QuotationLine[];
  subtotal: string;
  tax_amount: string;
  discount_amount?: string;
  grand_total: string;
  terms?: string;
  notes?: string;
  so_id?: string;
  so_number?: string;
  parent_quotation_id?: string;
}

// ─── Sales Order ──────────────────────────────────────────────────

export interface SOLine {
  id: string;
  line_number: number;
  item: string;
  item_code: string;
  item_name: string;
  ordered_qty: string;
  dispatched_qty: string;
  pending_qty: string;
  unit_price: string;
  amount: string;
  artwork_status: ArtworkStatus;
  artwork_file_url?: string;
  required_date?: string;
  remarks?: string;
}

export interface SOListItem {
  id: string;
  so_number: string;
  customer: string;
  customer_name: string;
  order_date: string;
  delivery_date?: string;
  status: SOStatus;
  total_amount: string;
  quotation_number?: string;
}

export interface SalesOrder extends SOListItem {
  lines: SOLine[];
  billing_address?: string;
  shipping_address?: string;
  payment_terms?: string;
  notes?: string;
  subtotal: string;
  tax_amount: string;
  grand_total: string;
  // P1 – material readiness fields
  material_ready: boolean;
  material_ready_notified: boolean;
  material_ready_at?: string;
  plant?: string;
  customer?: string;
}

// P1 – Material Status response types
export interface MaterialComponent {
  component_code: string;
  component_name: string;
  required_qty: string;
  available_qty: string;
  shortage: string;
  status: 'OK' | 'SHORT';
}

export interface MaterialStatusLine {
  so_line: number;
  item: string;
  all_materials_ok: boolean;
  components: MaterialComponent[];
}

export interface MaterialStatusResult {
  so_number: string;
  material_ready: boolean;
  lines: MaterialStatusLine[];
}

// P3 – Cost builder types
export interface CostBuilderRMLine {
  component_code: string;
  component_name: string;
  qty_per_unit: string;
  avg_rm_cost: string;
  line_cost: string;
  warning?: string | null;
}

export interface CostBuilderResult {
  item_code: string;
  item_name: string;
  qty: string;
  rm_breakdown: CostBuilderRMLine[];
  rm_cost_per_unit: string;
  conversion_cost_per_unit: string;
  total_cost_per_unit: string;
  profit_pct: string;
  suggested_rate: string;
  bom_found: boolean;
  warning?: string | null;
}

// ─── Invoice ──────────────────────────────────────────────────────

export interface GSTBreakup {
  taxable_amount: string;
  cgst_rate?: string;
  cgst_amount?: string;
  sgst_rate?: string;
  sgst_amount?: string;
  igst_rate?: string;
  igst_amount?: string;
  total_tax: string;
  grand_total: string;
}

export interface DeliveryEvent {
  id: string;
  event_type: string;
  timestamp: string;
  location?: string;
  remarks?: string;
  created_by_name: string;
}

export interface InvoiceListItem {
  id: string;
  invoice_number: string;
  customer: string;
  customer_name: string;
  invoice_date: string;
  due_date?: string;
  status: InvoiceStatus;
  grand_total: string;
  irn_number?: string;
  eway_bill_number?: string;
  so_number?: string;
}

export interface Invoice extends InvoiceListItem {
  lines: QuotationLine[];
  gst_breakup: GSTBreakup;
  delivery_events: DeliveryEvent[];
  pod_url?: string;
  hsn_code?: string;
  place_of_supply?: string;
  customer_gstin?: string;
  our_gstin?: string;
  is_interstate: boolean;
}

// ─── Complaint ────────────────────────────────────────────────────

export interface ComplaintActivity {
  id: string;
  date: string;
  action: string;
  remarks: string;
  performed_by_name: string;
}

export interface ComplaintListItem {
  id: string;
  complaint_number: string;
  customer: string;
  customer_name: string;
  subject: string;
  severity: ComplaintSeverity;
  status: ComplaintStatus;
  received_date: string;
  resolved_date?: string;
  assigned_to_name?: string;
  capa_number?: string;
}

export interface Complaint extends ComplaintListItem {
  description: string;
  invoice_number?: string;
  so_number?: string;
  root_cause?: string;
  resolution?: string;
  activities: ComplaintActivity[];
  capa_id?: string;
}

// ─── Dashboard ────────────────────────────────────────────────────

export interface SalesDashboardData {
  pipeline_value: number;
  monthly_sales: { month: string; value: number }[];
  top_customers: { customer_name: string; revenue: number; orders: number }[];
  overdue_deliveries: { so_number: string; customer_name: string; delivery_date: string; days_overdue: number }[];
  enquiries_this_month: number;
  orders_this_month: number;
  invoiced_this_month: number;
  collection_pending: number;
}

// ─── Dispatch ────────────────────────────────────────────────────

export type DispatchStatus = 'PLANNED' | 'LOADED' | 'IN_TRANSIT' | 'DELIVERED' | 'CANCELLED';

export interface DispatchPlanLine {
  id?: string;
  so_line_id: string;
  so_number: string;
  customer_name: string;
  item_name: string;
  pending_qty: string;
  dispatch_qty: string;
  lot_number?: string;
}

export interface DispatchOrder {
  id: string;
  dispatch_number: string;
  dispatch_date: string;
  status: DispatchStatus;
  vehicle_number?: string;
  driver_name?: string;
  driver_phone?: string;
  transporter?: string;
  transporter_name?: string;
  lr_number?: string;
  loading_instructions?: string;
  gate_out_time?: string;
  gate_out_scanned_by?: string;
  pod_url?: string;
  freight_amount?: string;
  freight_paid?: boolean;
  lines: DispatchPlanLine[];
}

export interface DispatchListItem {
  id: string;
  dispatch_number: string;
  dispatch_date: string;
  customer_name: string;
  status: DispatchStatus;
  vehicle_number?: string;
  transporter_name?: string;
  freight_amount?: string;
  freight_paid: boolean;
}

// ─── Service ─────────────────────────────────────────────────────

export const salesService = {
  // Enquiries
  listEnquiries: (p?: Record<string, unknown>) =>
    api.get<PaginatedResponse<EnquiryListItem>>('sales/enquiries/', { params: p }).then(r => r.data),
  getEnquiry: (id: string) =>
    api.get<Enquiry>(`sales/enquiries/${id}/`).then(r => r.data),
  createEnquiry: (d: Partial<Enquiry>) =>
    api.post<Enquiry>('sales/enquiries/', d).then(r => r.data),
  updateEnquiry: (id: string, d: Partial<Enquiry>) =>
    api.patch<Enquiry>(`sales/enquiries/${id}/`, d).then(r => r.data),
  addFollowup: (id: string, d: { mode: string; remarks: string; next_followup_date?: string }) =>
    api.post<FollowupEntry>(`sales/enquiries/${id}/followups/`, d).then(r => r.data),
  convertToQuotation: (id: string) =>
    api.post<Quotation>(`sales/enquiries/${id}/convert-to-quotation/`).then(r => r.data),

  // Quotations
  listQuotations: (p?: Record<string, unknown>) =>
    api.get<PaginatedResponse<QuotationListItem>>('sales/quotations/', { params: p }).then(r => r.data),
  getQuotation: (id: string) =>
    api.get<Quotation>(`sales/quotations/${id}/`).then(r => r.data),
  createQuotation: (d: Partial<Quotation>) =>
    api.post<Quotation>('sales/quotations/', d).then(r => r.data),
  updateQuotation: (id: string, d: Partial<Quotation>) =>
    api.patch<Quotation>(`sales/quotations/${id}/`, d).then(r => r.data),
  approveQuotation: (id: string) =>
    api.post(`sales/quotations/${id}/approve/`).then(r => r.data),
  sendToCustomer: (id: string) =>
    api.post(`sales/quotations/${id}/send/`).then(r => r.data),
  createRevision: (id: string) =>
    api.post<Quotation>(`sales/quotations/${id}/revise/`).then(r => r.data),
  convertToSO: (id: string) =>
    api.post<SalesOrder>(`sales/quotations/${id}/convert-to-so/`).then(r => r.data),

  // Sales Orders
  listSOs: (p?: Record<string, unknown>) =>
    api.get<PaginatedResponse<SOListItem>>('sales/orders/', { params: p }).then(r => r.data),
  getSO: (id: string) =>
    api.get<SalesOrder>(`sales/orders/${id}/`).then(r => r.data),
  confirmSO: (id: string) =>
    api.post(`sales/orders/${id}/confirm/`).then(r => r.data),
  cancelSO: (id: string, reason: string) =>
    api.post(`sales/orders/${id}/cancel/`, { reason }).then(r => r.data),
  updateArtwork: (soId: string, lineId: string, status: ArtworkStatus) =>
    api.patch(`sales/orders/${soId}/lines/${lineId}/artwork/`, { artwork_status: status }).then(r => r.data),

  // P1 – Material readiness status
  getMaterialStatus: (soId: string) =>
    api.get<MaterialStatusResult>(`sales/orders/${soId}/material-status/`).then(r => r.data),

  // Invoices
  listInvoices: (p?: Record<string, unknown>) =>
    api.get<PaginatedResponse<InvoiceListItem>>('sales/invoices/', { params: p }).then(r => r.data),
  getInvoice: (id: string) =>
    api.get<Invoice>(`sales/invoices/${id}/`).then(r => r.data),
  addDeliveryEvent: (id: string, d: { event_type: string; location?: string; remarks?: string }) =>
    api.post<DeliveryEvent>(`sales/invoices/${id}/delivery-events/`, d).then(r => r.data),
  uploadPOD: (id: string, file: File) => {
    const fd = new FormData();
    fd.append('pod_file', file);
    return api.post<{ pod_url: string }>(`sales/invoices/${id}/pod/`, fd, {
      headers: { 'Content-Type': 'multipart/form-data' },
    }).then(r => r.data);
  },

  // Complaints
  listComplaints: (p?: Record<string, unknown>) =>
    api.get<PaginatedResponse<ComplaintListItem>>('sales/complaints/', { params: p }).then(r => r.data),
  getComplaint: (id: string) =>
    api.get<Complaint>(`sales/complaints/${id}/`).then(r => r.data),
  createComplaint: (d: Partial<Complaint>) =>
    api.post<Complaint>('sales/complaints/', d).then(r => r.data),
  updateComplaint: (id: string, d: Partial<Complaint>) =>
    api.patch<Complaint>(`sales/complaints/${id}/`, d).then(r => r.data),
  addActivity: (id: string, d: { action: string; remarks: string }) =>
    api.post<ComplaintActivity>(`sales/complaints/${id}/activities/`, d).then(r => r.data),
  linkCAPA: (id: string) =>
    api.post(`sales/complaints/${id}/create-capa/`).then(r => r.data),

  // Dashboard
  getDashboard: () =>
    api.get<SalesDashboardData>('sales/dashboard/').then(r => r.data),

  // P3 – Quotation cost builder
  buildQuotationCost: (itemId: string, qty: number, profitPct?: number) =>
    api.post<CostBuilderResult>('sales/quotations/cost-builder/', {
      item_id: itemId,
      qty,
      profit_pct: profitPct ?? 15,
    }).then(r => r.data),

  // Dispatch
  listDispatches: (p?: Record<string, unknown>) =>
    api.get<PaginatedResponse<DispatchListItem>>('dispatch/orders/', { params: p }).then(r => r.data),
  getDispatch: (id: string) =>
    api.get<DispatchOrder>(`dispatch/orders/${id}/`).then(r => r.data),
  createDispatch: (d: Partial<DispatchOrder>) =>
    api.post<DispatchOrder>('dispatch/orders/', d).then(r => r.data),
  updateDispatch: (id: string, d: Partial<DispatchOrder>) =>
    api.patch<DispatchOrder>(`dispatch/orders/${id}/`, d).then(r => r.data),
  scanGateOut: (id: string, data: { vehicle_number: string; remarks?: string }) =>
    api.post(`dispatch/orders/${id}/gate-out/`, data).then(r => r.data),
  uploadDispatchPOD: (id: string, file: File) => {
    const fd = new FormData();
    fd.append('pod_file', file);
    return api.post<{ pod_url: string }>(`dispatch/orders/${id}/pod/`, fd, {
      headers: { 'Content-Type': 'multipart/form-data' },
    }).then(r => r.data);
  },
  recordFreightPayment: (id: string, d: { amount: string; payment_ref?: string; remarks?: string }) =>
    api.post(`dispatch/orders/${id}/freight-payment/`, d).then(r => r.data),

  // Pending SO lines for dispatch planning
  getPendingSOLines: (p?: Record<string, unknown>) =>
    api.get<DispatchPlanLine[]>('sales/orders/pending-dispatch/', { params: p }).then(r => r.data),
};
