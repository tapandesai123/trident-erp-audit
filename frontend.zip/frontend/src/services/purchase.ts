import api, { PaginatedResponse } from './api';

// ─── Shared types ─────────────────────────────────────────────────

export type PRStatus =
  | 'DRAFT' | 'SUBMITTED' | 'HOD_APPROVED' | 'PLANT_HEAD_APPROVED'
  | 'DIRECTOR_APPROVED' | 'REJECTED' | 'CANCELLED' | 'PO_CREATED';

export type POStatus =
  | 'DRAFT' | 'SUBMITTED' | 'ACCOUNTS_CHECKED' | 'APPROVED'
  | 'PARTIALLY_RECEIVED' | 'FULLY_RECEIVED' | 'CANCELLED' | 'AMENDED' | 'CLOSED';

export type GEStatus = 'PENDING' | 'MRR_CREATED' | 'REJECTED';
export type MRRStatus = 'DRAFT' | 'QC_PENDING' | 'QC_PASSED' | 'QC_REJECTED' | 'COMPLETED';

// ─── PR types ─────────────────────────────────────────────────────

export interface PRLine {
  id?: number;
  line_number: number;
  item: string;
  item_code?: string;
  item_name?: string;
  item_uom_code?: string;
  quantity: string;
  uom: number;
  uom_code?: string;
  estimated_rate?: string;
  // Auto-populated (read-only after submit)
  last_vendor?: string;
  last_vendor_name?: string;
  last_rate?: string;
  last_po_date?: string;
  current_stock?: string;
  min_stock?: string;
  remarks: string;
}

export interface PRApproval {
  id: number;
  approver_name: string;
  action: 'APPROVED' | 'REJECTED' | 'RETURNED';
  level: number;
  remarks: string;
  acted_at: string;
}

export interface PR {
  id: string;
  pr_number: string;
  plant: number;
  department?: number;
  department_name?: string;
  pr_date: string;
  required_date?: string;
  priority: 'URGENT' | 'HIGH' | 'NORMAL' | 'LOW';
  status: PRStatus;
  remarks: string;
  requested_by: number;
  requested_by_name?: string;
  submitted_at?: string;
  final_approved_at?: string;
  total_estimated_value?: string;
  line_count?: number;
  lines: PRLine[];
  approvals?: PRApproval[];
  created_at: string;
  updated_at: string;
}

export interface PRListItem {
  id: string;
  pr_number: string;
  pr_date: string;
  required_date?: string;
  priority: string;
  status: PRStatus;
  requested_by_name?: string;
  department_name?: string;
  total_estimated_value?: string;
  line_count: number;
}

export interface PRParams {
  search?: string;
  status?: string;
  priority?: string;
  department?: string;
  pr_date_from?: string;
  pr_date_to?: string;
  ordering?: string;
  limit?: number;
  offset?: number;
}

// ─── PO types ─────────────────────────────────────────────────────

export interface POLine {
  id?: number;
  line_number: number;
  item: string;
  item_code?: string;
  item_name?: string;
  pr_line?: number;
  quantity: string;
  received_qty?: string;
  rate: string;
  discount_pct?: string;
  gst_rate?: string;
  amount?: string;
  gst_amount?: string;
  total_amount?: string;
  uom?: number;
  uom_code?: string;
  delivery_date?: string;
  remarks: string;
  // Derived
  pending_qty?: string;
  price_increase_pct?: number;
}

export interface PriceAlert {
  item_code: string;
  item_name: string;
  current_rate: number;
  last_rate: number;
  increase_pct: number;
  last_po: string;
}

export interface PriceCheckResult {
  has_increases: boolean;
  alerts: PriceAlert[];
}

export interface PO {
  id: string;
  po_number: string;
  plant: number;
  vendor: string;
  vendor_code?: string;
  vendor_name?: string;
  po_date: string;
  po_type: 'FIXED_QTY' | 'JOB_WORK' | 'SERVICE' | 'CAPITAL_GOODS' | 'IMPORT';
  delivery_date?: string;
  payment_terms: string;
  freight_terms: string;
  status: POStatus;
  tolerance_pct: string;
  subtotal: string;
  gst_amount: string;
  tcs_amount: string;
  total_amount: string;
  currency: string;
  accounts_checked: boolean;
  accounts_checked_by_name?: string;
  accounts_checked_at?: string;
  approved_by_name?: string;
  approved_at?: string;
  pr?: string;
  pr_number?: string;
  amendment_number: number;
  remarks: string;
  terms_conditions: string;
  lines: POLine[];
  receipt_percentage?: number;
  created_at: string;
  updated_at: string;
}

export interface POListItem {
  id: string;
  po_number: string;
  vendor_name?: string;
  po_date: string;
  po_type: string;
  total_amount: string;
  status: POStatus;
  receipt_percentage?: number;
  pr_number?: string;
}

export interface POParams {
  search?: string;
  status?: string;
  po_type?: string;
  vendor?: string;
  po_date_from?: string;
  po_date_to?: string;
  total_min?: string;
  total_max?: string;
  ordering?: string;
  limit?: number;
  offset?: number;
}

// ─── Gate Entry types ─────────────────────────────────────────────

export interface GELine {
  id?: number;
  line_number: number;
  item: string;
  item_code?: string;
  item_name?: string;
  po_line?: number;
  quantity: string;
  uom: number;
  uom_code?: string;
  roll_number: string;
  gross_weight_kg?: string;
  net_weight_kg?: string;
  deckle_mm?: string;
  remarks: string;
}

export interface ValidationError {
  line_number: number;
  item_code: string;
  issue: string;
  received: number;
  allowed: number;
}

export interface GEValidationResult {
  is_valid: boolean;
  errors: ValidationError[];
  warnings: ValidationError[];
}

export interface GateEntry {
  id: string;
  gate_entry_number: string;
  plant: number;
  entry_type: 'AGAINST_PO' | 'CUSTOMER_JOB_WORK' | 'FROM_JOB_WORKER' | 'RETURNABLE' | 'NON_RETURNABLE';
  vendor?: string;
  vendor_name?: string;
  po?: string;
  po_number?: string;
  vehicle_number: string;
  transporter_name: string;
  lr_number: string;
  lr_date?: string;
  driver_name: string;
  driver_phone: string;
  entry_datetime: string;
  bill_number: string;
  bill_date?: string;
  challan_number: string;
  challan_date?: string;
  bill_photo?: string;
  shipment_photo?: string;
  truck_photo?: string;
  gst_transporter_copy_received: boolean;
  status: GEStatus;
  remarks: string;
  lines: GELine[];
  created_at: string;
}

export interface GEListItem {
  id: string;
  gate_entry_number: string;
  entry_type: string;
  vendor_name?: string;
  po_number?: string;
  vehicle_number: string;
  entry_datetime: string;
  status: GEStatus;
  gst_transporter_copy_received: boolean;
}

export interface GEParams {
  search?: string;
  entry_type?: string;
  status?: string;
  vendor?: string;
  po?: string;
  date_from?: string;
  date_to?: string;
  gst_copy_received?: string;
  limit?: number;
  offset?: number;
}

// ─── MRR types ────────────────────────────────────────────────────

export interface MRRLine {
  id: number;
  line_number: number;
  item: string;
  item_code?: string;
  item_name?: string;
  quantity: string;
  accepted_qty?: string;
  rejected_qty: string;
  uom_code?: string;
  rate?: string;
  lot_number: string;
  roll_number: string;
  gross_weight_kg?: string;
  net_weight_kg?: string;
  qr_code_data: string;
  qr_printed: boolean;
  qc_status: 'PENDING' | 'PASSED' | 'REJECTED' | 'ON_HOLD';
  qc_remarks: string;
}

export interface QRLabel {
  item_code: string;
  item_name: string;
  lot_number: string;
  roll_number: string;
  quantity: string;
  qr_data: string;
  qr_image_base64: string;
}

export interface QRLabelData {
  mrr_number: string;
  labels: QRLabel[];
}

export interface MRR {
  id: string;
  mrr_number: string;
  gate_entry: string;
  gate_entry_number?: string;
  po?: string;
  po_number?: string;
  vendor?: string;
  vendor_name?: string;
  mrr_date: string;
  mrr_type: string;
  warehouse: number;
  warehouse_name?: string;
  status: MRRStatus;
  remarks: string;
  lines: MRRLine[];
  created_at: string;
}

export interface MRRListItem {
  id: string;
  mrr_number: string;
  gate_entry_number?: string;
  vendor_name?: string;
  mrr_date: string;
  warehouse_name?: string;
  status: MRRStatus;
}

export interface MRRParams {
  search?: string;
  status?: string;
  vendor?: string;
  date_from?: string;
  date_to?: string;
  limit?: number;
  offset?: number;
}

// ─── Pipeline / Report types ──────────────────────────────────────

export interface PipelineSummary {
  pr_not_approved: number;
  pr_approved_no_po: number;
  po_not_approved: number;
  po_approved_no_mrr: number;
  gate_entry_pending_mrr: number;
  mrr_qc_pending: number;
}

export interface TATData {
  avg_days: number;
  by_month: { month: string; avg_days: number }[];
}

// ─── Service ─────────────────────────────────────────────────────

export const purchaseService = {
  // ── PRs ─────────────────────────────────────────────────────────
  getPRs: (p?: PRParams) =>
    api.get<PaginatedResponse<PRListItem>>('purchase/requisitions/', { params: p }).then(r => r.data),

  getPR: (id: string) =>
    api.get<PR>(`purchase/requisitions/${id}/`).then(r => r.data),

  createPR: (data: Partial<PR>) =>
    api.post<PR>('purchase/requisitions/', data).then(r => r.data),

  updatePR: (id: string, data: Partial<PR>) =>
    api.patch<PR>(`purchase/requisitions/${id}/`, data).then(r => r.data),

  submitPR: (id: string) =>
    api.post<PR>(`purchase/requisitions/${id}/submit/`).then(r => r.data),

  approvePR: (id: string, action: 'APPROVED' | 'REJECTED' | 'RETURNED', level: number, remarks?: string) =>
    api.post<PR>(`purchase/requisitions/${id}/approve/`, { action, level, remarks }).then(r => r.data),

  getPendingPRApprovals: (p?: PRParams) =>
    api.get<PaginatedResponse<PRListItem>>('purchase/requisitions/pending_approval/', { params: p }).then(r => r.data),

  getMyPRs: (p?: PRParams) =>
    api.get<PaginatedResponse<PRListItem>>('purchase/requisitions/', { params: { ...p, my_prs: true } }).then(r => r.data),

  // ── POs ─────────────────────────────────────────────────────────
  getPOs: (p?: POParams) =>
    api.get<PaginatedResponse<POListItem>>('purchase/orders/', { params: p }).then(r => r.data),

  getPO: (id: string) =>
    api.get<PO>(`purchase/orders/${id}/`).then(r => r.data),

  createPO: (data: Partial<PO>) =>
    api.post<PO>('purchase/orders/', data).then(r => r.data),

  updatePO: (id: string, data: Partial<PO>) =>
    api.patch<PO>(`purchase/orders/${id}/`, data).then(r => r.data),

  createPOFromPR: (prId: string, vendorId: string, poType: string) =>
    api.post<PO>('purchase/orders/create_from_pr/', { pr_id: prId, vendor_id: vendorId, po_type: poType }).then(r => r.data),

  accountsCheck: (id: string) =>
    api.post<PO>(`purchase/orders/${id}/accounts_check/`).then(r => r.data),

  approvePO: (id: string, action: 'APPROVED' | 'REJECTED', remarks?: string) =>
    api.post<PO>(`purchase/orders/${id}/approve/`, { action, remarks }).then(r => r.data),

  priceCheck: (id: string) =>
    api.get<PriceCheckResult>(`purchase/orders/${id}/price_check/`).then(r => r.data),

  recalculatePO: (id: string) =>
    api.post<PO>(`purchase/orders/${id}/recalculate/`).then(r => r.data),

  getPOsWithPriceIncrease: () =>
    api.get<PaginatedResponse<POListItem>>('purchase/orders/with_price_increase/').then(r => r.data),

  getApprovedPRsNoPO: (p?: PRParams) =>
    api.get<PaginatedResponse<PRListItem>>('purchase/requisitions/approved_no_po/', { params: p }).then(r => r.data),

  // ── Gate Entries ─────────────────────────────────────────────────
  getGateEntries: (p?: GEParams) =>
    api.get<PaginatedResponse<GEListItem>>('purchase/gate-entries/', { params: p }).then(r => r.data),

  getGateEntry: (id: string) =>
    api.get<GateEntry>(`purchase/gate-entries/${id}/`).then(r => r.data),

  createGateEntry: (data: Partial<GateEntry>) =>
    api.post<GateEntry>('purchase/gate-entries/', data).then(r => r.data),

  validateGateEntry: (id: string) =>
    api.get<GEValidationResult>(`purchase/gate-entries/${id}/validate/`).then(r => r.data),

  getPendingMRREntries: (p?: GEParams) =>
    api.get<PaginatedResponse<GEListItem>>('purchase/gate-entries/pending_mrr/', { params: p }).then(r => r.data),

  getGSTCopyPending: (p?: GEParams) =>
    api.get<PaginatedResponse<GEListItem>>('purchase/gate-entries/gst_copy_pending/', { params: p }).then(r => r.data),

  uploadGEPhoto: (id: string, field: 'bill_photo' | 'shipment_photo' | 'truck_photo', file: File) => {
    const form = new FormData(); form.append(field, file);
    return api.patch<GateEntry>(`purchase/gate-entries/${id}/`, form, {
      headers: { 'Content-Type': 'multipart/form-data' },
    }).then(r => r.data);
  },

  // ── MRRs ─────────────────────────────────────────────────────────
  getMRRs: (p?: MRRParams) =>
    api.get<PaginatedResponse<MRRListItem>>('purchase/mrrs/', { params: p }).then(r => r.data),

  getMRR: (id: string) =>
    api.get<MRR>(`purchase/mrrs/${id}/`).then(r => r.data),

  createMRRFromGE: (gateEntryId: string, warehouseId: number, remarks?: string) =>
    api.post<MRR>('purchase/mrrs/create_from_gate_entry/', {
      gate_entry_id: gateEntryId, warehouse_id: warehouseId, remarks,
    }).then(r => r.data),

  getQRLabels: (id: string) =>
    api.get<QRLabelData>(`purchase/mrrs/${id}/qr_labels/`).then(r => r.data),

  markQRPrinted: (id: string) =>
    api.post<MRR>(`purchase/mrrs/${id}/mark_qr_printed/`).then(r => r.data),

  getQCPending: (p?: MRRParams) =>
    api.get<PaginatedResponse<MRRListItem>>('purchase/mrrs/qc_pending/', { params: p }).then(r => r.data),

  // ── Reports ─────────────────────────────────────────────────────
  getPipelineSummary: () =>
    api.get<PipelineSummary>('purchase/reports/pipeline_summary/').then(r => r.data),

  getTATData: () =>
    api.get<TATData>('purchase/reports/tat_pr_to_po/').then(r => r.data),
};
