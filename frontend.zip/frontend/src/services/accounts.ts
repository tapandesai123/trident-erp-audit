import api, { PaginatedResponse } from './api';

// ─── Voucher Types ─────────────────────────────────────────────────

export type VoucherType = 'PURCHASE' | 'PAYMENT' | 'RECEIPT' | 'JOURNAL';
export type VoucherStatus = 'DRAFT' | 'PENDING' | 'APPROVED' | 'POSTED' | 'CANCELLED';

export interface VoucherLine {
  id?: number;
  account_code: string;
  account_name?: string;
  narration: string;
  debit: string;
  credit: string;
  cost_center?: string;
  reference?: string;
}

export interface BillPassingChecklist {
  po_attached: boolean;
  grn_attached: boolean;
  invoice_attached: boolean;
  rates_match_po: boolean;
  qty_match_grn: boolean;
  gst_correct: boolean;
  tds_deducted: boolean;
}

export interface Voucher {
  id: number;
  voucher_number: string;
  voucher_type: VoucherType;
  date: string;
  narration: string;
  reference?: string;
  party?: string;
  party_name?: string;
  status: VoucherStatus;
  total_debit: string;
  total_credit: string;
  lines: VoucherLine[];
  bill_passing?: BillPassingChecklist;
  created_by_name?: string;
  created_at: string;
}

export interface VoucherCreatePayload {
  voucher_type: VoucherType;
  date: string;
  narration: string;
  reference?: string;
  party?: string;
  lines: VoucherLine[];
  bill_passing?: BillPassingChecklist;
}

// ─── Outstanding Types ─────────────────────────────────────────────

export interface OutstandingEntry {
  id: number;
  party_id: string;
  party_name: string;
  party_type: 'vendor' | 'customer';
  invoice_number: string;
  invoice_date: string;
  due_date: string;
  amount: string;
  paid: string;
  outstanding: string;
  days_overdue: number;
  aging_bucket: '0-30' | '30-60' | '60-90' | '90+';
}

export interface AgingSummary {
  party_id: string;
  party_name: string;
  total: string;
  bucket_0_30: string;
  bucket_30_60: string;
  bucket_60_90: string;
  bucket_90_plus: string;
}

// ─── GST Types ─────────────────────────────────────────────────────

export type GSTReturnType = 'GSTR-1' | 'GSTR-3B';
export type GSTReturnStatus = 'NOT_DUE' | 'DUE' | 'FILED' | 'OVERDUE';

export interface GSTReturn {
  id: number;
  return_type: GSTReturnType;
  period: string; // e.g. "2024-01"
  status: GSTReturnStatus;
  due_date: string;
  filed_date?: string;
  tax_liability?: string;
  itc_claimed?: string;
  net_payable?: string;
  filing_reference?: string;
}

export interface GSTReconciliation {
  period: string;
  books_taxable: string;
  gstr1_taxable: string;
  gstr2b_itc: string;
  books_itc: string;
  difference: string;
}

// ─── Dashboard Types ───────────────────────────────────────────────

export interface AccountsDashboard {
  total_payable: string;
  total_receivable: string;
  overdue_payable: string;
  overdue_receivable: string;
  tds_pending: string;
  monthly_expenses: Array<{ month: string; amount: string }>;
  top_vendors_payable: Array<{ name: string; amount: string }>;
  top_customers_receivable: Array<{ name: string; amount: string }>;
}

// ─── Service ───────────────────────────────────────────────────────

export const accountsService = {
  // Vouchers
  listVouchers: (params?: Record<string, string>) =>
    api.get<PaginatedResponse<Voucher>>('/accounts/vouchers/', { params }).then(r => r.data),

  getVoucher: (id: number) =>
    api.get<Voucher>(`/accounts/vouchers/${id}/`).then(r => r.data),

  createVoucher: (data: VoucherCreatePayload) =>
    api.post<Voucher>('/accounts/vouchers/', data).then(r => r.data),

  updateVoucher: (id: number, data: Partial<VoucherCreatePayload>) =>
    api.patch<Voucher>(`/accounts/vouchers/${id}/`, data).then(r => r.data),

  postVoucher: (id: number) =>
    api.post<Voucher>(`/accounts/vouchers/${id}/post/`).then(r => r.data),

  // Outstanding
  getAPAging: () =>
    api.get<AgingSummary[]>('/accounts/outstanding/ap/').then(r => r.data),

  getARAging: () =>
    api.get<AgingSummary[]>('/accounts/outstanding/ar/').then(r => r.data),

  getPartyOutstanding: (partyId: string, type: 'vendor' | 'customer') =>
    api.get<OutstandingEntry[]>(`/accounts/outstanding/${type}/${partyId}/`).then(r => r.data),

  // GST
  listGSTReturns: () =>
    api.get<GSTReturn[]>('/accounts/gst-returns/').then(r => r.data),

  uploadGSTFile: (returnId: number, file: File) => {
    const form = new FormData();
    form.append('file', file);
    return api.post(`/accounts/gst-returns/${returnId}/upload/`, form, {
      headers: { 'Content-Type': 'multipart/form-data' },
    }).then(r => r.data);
  },

  getGSTReconciliation: (period: string) =>
    api.get<GSTReconciliation[]>(`/accounts/gst-reconciliation/?period=${period}`).then(r => r.data),

  // Dashboard
  getDashboard: () =>
    api.get<AccountsDashboard>('/accounts/dashboard/').then(r => r.data),
};

// ─── Mock data for demo ─────────────────────────────────────────────

export function mockAccountsDashboard(): AccountsDashboard {
  return {
    total_payable: '4852340',
    total_receivable: '7123890',
    overdue_payable: '1243000',
    overdue_receivable: '2187000',
    tds_pending: '84320',
    monthly_expenses: [
      { month: 'Aug', amount: '1820000' },
      { month: 'Sep', amount: '2130000' },
      { month: 'Oct', amount: '1950000' },
      { month: 'Nov', amount: '2340000' },
      { month: 'Dec', amount: '2890000' },
      { month: 'Jan', amount: '3120000' },
    ],
    top_vendors_payable: [
      { name: 'Steel Authority Ltd', amount: '892300' },
      { name: 'Fastener World', amount: '654200' },
      { name: 'ABC Chemicals', amount: '432100' },
    ],
    top_customers_receivable: [
      { name: 'Reliance Industries', amount: '1432000' },
      { name: 'L&T Engineering', amount: '987400' },
      { name: 'BHEL', amount: '768200' },
    ],
  };
}

export function mockAgingSummary(type: 'ap' | 'ar'): AgingSummary[] {
  const parties = type === 'ap'
    ? ['Steel Authority Ltd', 'Fastener World', 'ABC Chemicals', 'Prime Metals', 'Sun Components']
    : ['Reliance Industries', 'L&T Engineering', 'BHEL', 'Tata Motors', 'ONGC'];
  return parties.map((name, i) => ({
    party_id: `${type}-${i + 1}`,
    party_name: name,
    total: String((Math.random() * 900000 + 100000).toFixed(0)),
    bucket_0_30: String((Math.random() * 400000 + 50000).toFixed(0)),
    bucket_30_60: String((Math.random() * 200000).toFixed(0)),
    bucket_60_90: String((Math.random() * 150000).toFixed(0)),
    bucket_90_plus: String((Math.random() * 100000).toFixed(0)),
  }));
}

export function mockGSTReturns(): GSTReturn[] {
  const months = ['2024-08', '2024-09', '2024-10', '2024-11', '2024-12', '2025-01'];
  const statuses: GSTReturnStatus[] = ['FILED', 'FILED', 'FILED', 'FILED', 'DUE', 'NOT_DUE'];
  const result: GSTReturn[] = [];
  months.forEach((period, i) => {
    (['GSTR-1', 'GSTR-3B'] as GSTReturnType[]).forEach(rt => {
      result.push({
        id: result.length + 1,
        return_type: rt,
        period,
        status: i >= 4 ? statuses[i] : 'FILED',
        due_date: `${period}-${rt === 'GSTR-1' ? '11' : '20'}`,
        filed_date: i < 4 ? `${period}-${rt === 'GSTR-1' ? '09' : '18'}` : undefined,
        tax_liability: String((Math.random() * 300000 + 50000).toFixed(0)),
        itc_claimed: String((Math.random() * 200000 + 30000).toFixed(0)),
        net_payable: String((Math.random() * 100000 + 10000).toFixed(0)),
      });
    });
  });
  return result;
}
