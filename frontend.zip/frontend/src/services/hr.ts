// frontend/src/services/hr.ts
import api from './api';

export const hrService = {
  list: (params?: Record<string, unknown>) =>
    api.get('/api/v1/hr/employees/', { params }).then(r => r.data),
  get: (id: string) =>
    api.get(`/api/v1/hr/employees/${id}/`).then(r => r.data),
  create: (data: unknown) =>
    api.post('/api/v1/hr/employees/', data).then(r => r.data),
  update: (id: string, data: unknown) =>
    api.patch(`/api/v1/hr/employees/${id}/`, data).then(r => r.data),
  delete: (id: string) =>
    api.delete(`/api/v1/hr/employees/${id}/`).then(r => r.data),

  // Departments
  listDepartments: () =>
    api.get('/api/v1/hr/departments/').then(r => r.data),

  // Attendance
  listAttendance: (params?: Record<string, unknown>) =>
    api.get('/api/v1/hr/attendance/', { params }).then(r => r.data),
  markAttendance: (data: unknown) =>
    api.post('/api/v1/hr/attendance/', data).then(r => r.data),
  getAttendanceSummary: (employeeId: string, month: string) =>
    api.get(`/api/v1/hr/employees/${employeeId}/attendance_summary/`, { params: { month } }).then(r => r.data),

  // Leave Requests
  listLeaveRequests: (params?: Record<string, unknown>) =>
    api.get('/api/v1/hr/leave-requests/', { params }).then(r => r.data),
  createLeaveRequest: (data: unknown) =>
    api.post('/api/v1/hr/leave-requests/', data).then(r => r.data),
  approveLeave: (id: string) =>
    api.post(`/api/v1/hr/leave-requests/${id}/approve/`).then(r => r.data),
  rejectLeave: (id: string, reason: string) =>
    api.post(`/api/v1/hr/leave-requests/${id}/reject/`, { reason }).then(r => r.data),
};
