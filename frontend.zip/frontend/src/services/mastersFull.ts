// frontend/src/services/mastersFull.ts
// Extended masters service including new Task 11 endpoints: Sauda, RGP, MLF
import api from './api';

export const saudaService = {
  list: (params?: Record<string, unknown>) =>
    api.get('/api/v1/purchase/sauda/', { params }).then(r => r.data),
  get: (id: string) =>
    api.get(`/api/v1/purchase/sauda/${id}/`).then(r => r.data),
  create: (data: unknown) =>
    api.post('/api/v1/purchase/sauda/', data).then(r => r.data),
  update: (id: string, data: unknown) =>
    api.patch(`/api/v1/purchase/sauda/${id}/`, data).then(r => r.data),
  poHistory: (id: string) =>
    api.get(`/api/v1/purchase/sauda/${id}/po_history/`).then(r => r.data),
  pendingReport: (id: string) =>
    api.get(`/api/v1/purchase/sauda/${id}/pending_report/`).then(r => r.data),
};

export const rgpService = {
  list: (params?: Record<string, unknown>) =>
    api.get('/api/v1/purchase/rgp/', { params }).then(r => r.data),
  get: (id: string) =>
    api.get(`/api/v1/purchase/rgp/${id}/`).then(r => r.data),
  create: (data: unknown) =>
    api.post('/api/v1/purchase/rgp/', data).then(r => r.data),
  update: (id: string, data: unknown) =>
    api.patch(`/api/v1/purchase/rgp/${id}/`, data).then(r => r.data),
  sendOut: (id: string) =>
    api.post(`/api/v1/purchase/rgp/${id}/send_out/`).then(r => r.data),
  markReturned: (id: string, mrrId: string) =>
    api.post(`/api/v1/purchase/rgp/${id}/mark_returned/`, { mrr_id: mrrId }).then(r => r.data),
  pendingReturns: () =>
    api.get('/api/v1/purchase/rgp/pending_returns/').then(r => r.data),
};

export const mlfService = {
  list: () =>
    api.get('/api/v1/core/mlf/').then(r => r.data),
  get: (id: string) =>
    api.get(`/api/v1/core/mlf/${id}/`).then(r => r.data),
  generateQuarter: () =>
    api.post('/api/v1/core/mlf/generate_quarter/').then(r => r.data),
  markPaid: (id: string, paidDate?: string) =>
    api.post(`/api/v1/core/mlf/${id}/mark_paid/`, { paid_date: paidDate }).then(r => r.data),
  usageSummary: () =>
    api.get('/api/v1/core/mlf/usage_summary/').then(r => r.data),
};

export const approvalsService = {
  getPending: () =>
    api.get('/api/v1/core/approvals/pending/').then(r => r.data),
  approve: (id: string) =>
    api.post(`/api/v1/core/approvals/${id}/approve/`).then(r => r.data),
  reject: (id: string, reason: string) =>
    api.post(`/api/v1/core/approvals/${id}/reject/`, { reason }).then(r => r.data),
};

export const ediService = {
  upload: (file: File, format: string) => {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('format', format);
    return api.post('/api/v1/sales/orders/edi_upload/', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    }).then(r => r.data);
  },
};
