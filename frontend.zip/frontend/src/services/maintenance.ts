// frontend/src/services/maintenance.ts
import api from './api';

export const maintenanceService = {
  // Work Requests
  listRequests: (params?: Record<string, unknown>) =>
    api.get('/api/v1/maintenance/work-requests/', { params }).then(r => r.data),
  getRequest: (id: string) =>
    api.get(`/api/v1/maintenance/work-requests/${id}/`).then(r => r.data),
  createRequest: (data: unknown) =>
    api.post('/api/v1/maintenance/work-requests/', data).then(r => r.data),
  updateRequest: (id: string, data: unknown) =>
    api.patch(`/api/v1/maintenance/work-requests/${id}/`, data).then(r => r.data),
  closeRequest: (id: string, data: unknown) =>
    api.post(`/api/v1/maintenance/work-requests/${id}/close/`, data).then(r => r.data),

  // PM Schedules
  listPMSchedules: (params?: Record<string, unknown>) =>
    api.get('/api/v1/maintenance/pm-schedules/', { params }).then(r => r.data),
  createPMSchedule: (data: unknown) =>
    api.post('/api/v1/maintenance/pm-schedules/', data).then(r => r.data),
  updatePMSchedule: (id: string, data: unknown) =>
    api.patch(`/api/v1/maintenance/pm-schedules/${id}/`, data).then(r => r.data),
  duePMSchedules: () =>
    api.get('/api/v1/maintenance/pm-schedules/due/').then(r => r.data),

  // AMC Contracts
  listAMC: (params?: Record<string, unknown>) =>
    api.get('/api/v1/maintenance/amc-contracts/', { params }).then(r => r.data),
  createAMC: (data: unknown) =>
    api.post('/api/v1/maintenance/amc-contracts/', data).then(r => r.data),
  expiringAMC: () =>
    api.get('/api/v1/maintenance/amc-contracts/expiring_soon/').then(r => r.data),
  startWork: (id: string) =>
    api.post(`/api/v1/maintenance/work-requests/${id}/start/`).then(r => r.data),
  completeWork: (id: string) =>
    api.post(`/api/v1/maintenance/work-requests/${id}/complete/`).then(r => r.data),
};
