// frontend/src/services/projects.ts
import api from './api';

export const projectsService = {
  list: (params?: Record<string, unknown>) =>
    api.get('/api/v1/projects/projects/', { params }).then(r => r.data),
  get: (id: string) =>
    api.get(`/api/v1/projects/projects/${id}/`).then(r => r.data),
  create: (data: unknown) =>
    api.post('/api/v1/projects/projects/', data).then(r => r.data),
  update: (id: string, data: unknown) =>
    api.patch(`/api/v1/projects/projects/${id}/`, data).then(r => r.data),
  delete: (id: string) =>
    api.delete(`/api/v1/projects/projects/${id}/`).then(r => r.data),
  dashboard: (id: string) =>
    api.get(`/api/v1/projects/projects/${id}/dashboard/`).then(r => r.data),

  // Milestones
  listMilestones: (projectId: string) =>
    api.get('/api/v1/projects/milestones/', { params: { project: projectId } }).then(r => r.data),
  createMilestone: (data: unknown) =>
    api.post('/api/v1/projects/milestones/', data).then(r => r.data),

  // Project Tasks
  listProjectTasks: (params?: Record<string, unknown>) =>
    api.get('/api/v1/projects/project-tasks/', { params }).then(r => r.data),
  createProjectTask: (data: unknown) =>
    api.post('/api/v1/projects/project-tasks/', data).then(r => r.data),
  updateProjectTask: (id: string, data: unknown) =>
    api.patch(`/api/v1/projects/project-tasks/${id}/`, data).then(r => r.data),
};
  listTasks: (projectId: string) =>
    api.get('/api/v1/projects/project-tasks/', { params: { project: projectId } }).then(r => r.data),
  updateTaskStatus: (id: string, status: string) =>
    api.patch(`/api/v1/projects/project-tasks/${id}/`, { status }).then(r => r.data),
};
