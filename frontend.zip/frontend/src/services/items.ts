import api, { PaginatedResponse } from './api';

export interface ItemGroup {
  id: number;
  code: string;
  name: string;
  item_type?: string;
}

export interface UOM {
  id: number;
  code: string;
  name: string;
}

export interface ItemVendorLink {
  id?: number;
  vendor: string;
  vendor_name?: string;
  vendor_code?: string;
  is_preferred: boolean;
  last_rate?: string;
  last_po_date?: string;
  last_po_number?: string;
  min_order_qty?: string;
  lead_time_days?: number;
  remarks: string;
}

export interface Item {
  id: string;
  code: string;
  name: string;
  description: string;
  item_group: number;
  item_group_name?: string;
  item_type: 'RAW_MATERIAL' | 'BOUGHT_OUT' | 'CONSUMABLE' | 'SPARE' | 'FINISHED_GOOD' | 'SEMI_FINISHED';
  uom: number;
  uom_code?: string;
  secondary_uom?: number;
  secondary_uom_code?: string;
  conversion_factor?: string;
  hsn_code: string;
  gst_rate: string;
  pack_size: string;
  // Stock levels
  min_stock: string;
  max_stock: string;
  reorder_level: string;
  lead_time_days: number;
  shelf_life_days?: number;
  // Paper-specific
  bf_rating?: number;
  gsm?: number;
  deckle_mm?: string;
  paper_type: string;
  // Approval
  approval_status: 'DRAFT' | 'PENDING' | 'APPROVED' | 'REJECTED';
  is_approved: boolean;
  approved_by_name?: string;
  approved_at?: string;
  rejection_reason: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
  vendor_links?: ItemVendorLink[];
}

export interface ItemListItem {
  id: string;
  code: string;
  name: string;
  item_type: string;
  item_group_name?: string;
  uom_code?: string;
  gsm?: number;
  bf_rating?: number;
  paper_type: string;
  approval_status: string;
  is_active: boolean;
}

export interface ItemParams {
  search?: string;
  item_type?: string;
  item_group?: string;
  approval_status?: string;
  paper_type?: string;
  bf_rating_min?: string;
  bf_rating_max?: string;
  gsm_min?: string;
  gsm_max?: string;
  ordering?: string;
  limit?: number;
  offset?: number;
}

export const itemsService = {
  getItems: (params?: ItemParams) =>
    api.get<PaginatedResponse<ItemListItem>>('masters/items/', { params }).then(r => r.data),

  getItem: (id: string) =>
    api.get<Item>(`masters/items/${id}/`).then(r => r.data),

  createItem: (data: Partial<Item>) =>
    api.post<Item>('masters/items/', data).then(r => r.data),

  updateItem: (id: string, data: Partial<Item>) =>
    api.patch<Item>(`masters/items/${id}/`, data).then(r => r.data),

  submitForApproval: (id: string) =>
    api.post<Item>(`masters/items/${id}/submit_for_approval/`).then(r => r.data),

  approveItem: (id: string, action: 'APPROVE' | 'REJECT', rejection_reason?: string) =>
    api.post<Item>(`masters/items/${id}/approve/`, { action, rejection_reason }).then(r => r.data),

  getPendingApprovals: (params?: { limit?: number; offset?: number }) =>
    api.get<PaginatedResponse<ItemListItem>>('masters/items/pending_approval/', { params }).then(r => r.data),

  getBelowMinimum: (params?: { limit?: number; offset?: number }) =>
    api.get<PaginatedResponse<ItemListItem>>('masters/items/below_minimum/', { params }).then(r => r.data),

  exportItems: (params?: ItemParams) =>
    api.get('masters/items/export_excel/', { params, responseType: 'blob' }).then(r => r.data),

  importItems: (file: File) => {
    const form = new FormData();
    form.append('file', file);
    return api.post('masters/items/import_excel/', form, {
      headers: { 'Content-Type': 'multipart/form-data' },
    }).then(r => r.data);
  },

  getVendorLinks: (itemId: string) =>
    api.get<ItemVendorLink[]>(`masters/items/${itemId}/vendor-links/`).then(r => r.data),

  addVendorLink: (itemId: string, data: Partial<ItemVendorLink>) =>
    api.post<ItemVendorLink>(`masters/items/${itemId}/vendor-links/`, data).then(r => r.data),

  removeVendorLink: (itemId: string, linkId: number) =>
    api.delete(`masters/items/${itemId}/vendor-links/${linkId}/`),

  getGroups: () =>
    api.get<ItemGroup[]>('masters/item-groups/').then(r => r.data),

  getUOMs: () =>
    api.get<UOM[]>('masters/uoms/').then(r => r.data),
};
