// frontend/src/services/production.ts
import api from './api';

export const productionService = {
  // BOMs
  listBOMs: (params?: Record<string, unknown>) =>
    api.get('/api/v1/production/boms/', { params }).then(r => r.data),
  getBOM: (id: string) =>
    api.get(`/api/v1/production/boms/${id}/`).then(r => r.data),
  createBOM: (data: unknown) =>
    api.post('/api/v1/production/boms/', data).then(r => r.data),
  updateBOM: (id: string, data: unknown) =>
    api.patch(`/api/v1/production/boms/${id}/`, data).then(r => r.data),

  // Work Centers
  listWorkCenters: () =>
    api.get('/api/v1/production/work-centers/').then(r => r.data),

  // P2 – Machine auto-allocation: suggest work centres by box width
  suggestWorkCenters: (boxWidthMm: number, machineType?: string) =>
    api.get('/api/v1/production/work-centers/suggest/', {
      params: { box_width_mm: boxWidthMm, ...(machineType ? { machine_type: machineType } : {}) },
    }).then(r => r.data),

  // Work Orders
  listWorkOrders: (params?: Record<string, unknown>) =>
    api.get('/api/v1/production/work-orders/', { params }).then(r => r.data),
  getWorkOrder: (id: string) =>
    api.get(`/api/v1/production/work-orders/${id}/`).then(r => r.data),
  createWorkOrder: (data: unknown) =>
    api.post('/api/v1/production/work-orders/', data).then(r => r.data),
  updateWorkOrder: (id: string, data: unknown) =>
    api.patch(`/api/v1/production/work-orders/${id}/`, data).then(r => r.data),
  advanceStatus: (id: string, status: string) =>
    api.post(`/api/v1/production/work-orders/${id}/advance_status/`, { status }).then(r => r.data),

  // Job Cards
  listJobCards: (params?: Record<string, unknown>) =>
    api.get('/api/v1/production/job-cards/', { params }).then(r => r.data),
  getJobCard: (id: string) =>
    api.get(`/api/v1/production/job-cards/${id}/`).then(r => r.data),
  createJobCard: (data: unknown) =>
    api.post('/api/v1/production/job-cards/', data).then(r => r.data),
  recordProduction: (id: string, data: unknown) =>
    api.post(`/api/v1/production/job-cards/${id}/record_production/`, data).then(r => r.data),

  // MRP
  listMRPRuns: () =>
    api.get('/api/v1/production/mrp-runs/').then(r => r.data),
  runMRP: (data: unknown) =>
    api.post('/api/v1/production/mrp-runs/', data).then(r => r.data),
  listMRPSuggestions: (runId: string) =>
    api.get('/api/v1/production/mrp-suggestions/', { params: { mrp_run: runId } }).then(r => r.data),

  // Downtime
  listDowntime: (params?: Record<string, unknown>) =>
    api.get('/api/v1/production/downtime/', { params }).then(r => r.data),
  createDowntime: (data: unknown) =>
    api.post('/api/v1/production/downtime/', data).then(r => r.data),
  getDowntimeSummary: (params?: Record<string, unknown>) =>
    api.get('/api/v1/production/downtime/summary/', { params }).then(r => r.data),

  // Machine Loading
  listLoadingPlans: (params?: Record<string, unknown>) =>
    api.get('/api/v1/production/loading-plans/', { params }).then(r => r.data),
};
