import api from './api';

// ─── P4 – Inventory Valuation types ────────────────────────────────

export interface ValuationRow {
  item_code: string;
  item_name: string;
  warehouse_code: string;
  warehouse_name: string;
  warehouse_type: string;
  uom: string;
  total_qty: number;
  total_value: number;
  lot_count: number;
}

export interface InventoryValuationSummary {
  rm_total: number;
  wip_total: number;
  fg_total: number;
  other_total: number;
  grand_total: number;
}

export interface InventoryValuationResult {
  report: string;
  plant: string;
  as_of_date: string;
  summary: InventoryValuationSummary;
  rm_rows: ValuationRow[];
  wip_rows: ValuationRow[];
  fg_rows: ValuationRow[];
  other_rows: ValuationRow[];
  rows: ValuationRow[];
  grand_total_value: number;
  row_count: number;
}

// ─── Report Types ───────────────────────────────────────────────────

export interface PurchaseMISData {
  monthly_spend: Array<{ month: string; amount: number; po_count: number }>;
  top_vendors: Array<{ name: string; amount: number; po_count: number }>;
  pr_to_po_tat: Array<{ month: string; avg_days: number }>;
  spend_by_category: Array<{ category: string; amount: number }>;
}

export interface SalesMISData {
  monthly_revenue: Array<{ month: string; revenue: number; orders: number }>;
  top_customers: Array<{ name: string; revenue: number; orders: number }>;
  so_fulfillment_rate: Array<{ month: string; rate: number; on_time: number; total: number }>;
  revenue_by_product: Array<{ product: string; revenue: number }>;
}

export interface StoresMISData {
  stock_value_trend: Array<{ month: string; value: number }>;
  stock_aging: Array<{ bucket: string; value: number; qty: number }>;
  turnover_ratio: Array<{ category: string; ratio: number }>;
  slow_moving: Array<{ item: string; days: number; value: number }>;
}

export interface ProductionMISData {
  machine_utilization: Array<{ machine: string; utilization: number; planned: number; actual: number }>;
  wo_completion_rate: Array<{ month: string; rate: number; completed: number; total: number }>;
  rejection_trend: Array<{ month: string; rate: number }>;
}

export interface QualityMISData {
  rejection_rate: Array<{ month: string; rate: number; inspected: number; rejected: number }>;
  capa_closure_rate: Array<{ month: string; rate: number; open: number; closed: number }>;
  defect_by_category: Array<{ category: string; count: number }>;
  supplier_quality: Array<{ vendor: string; rejection_rate: number }>;
}

export interface ReportBuilderConfig {
  report_type: string;
  date_from: string;
  date_to: string;
  filters: Record<string, string>;
  group_by?: string;
  columns?: string[];
}

export interface ReportBuilderResult {
  columns: Array<{ key: string; label: string; type: 'text' | 'number' | 'date' | 'currency' }>;
  rows: Array<Record<string, string | number>>;
  totals?: Record<string, number>;
}

// ─── Service ────────────────────────────────────────────────────────

export const reportsService = {
  getPurchaseMIS: (from: string, to: string) =>
    api.get<PurchaseMISData>('/reports/purchase/', { params: { from, to } }).then(r => r.data),

  getSalesMIS: (from: string, to: string) =>
    api.get<SalesMISData>('/reports/sales/', { params: { from, to } }).then(r => r.data),

  getStoresMIS: (from: string, to: string) =>
    api.get<StoresMISData>('/reports/stores/', { params: { from, to } }).then(r => r.data),

  getProductionMIS: (from: string, to: string) =>
    api.get<ProductionMISData>('/reports/production/', { params: { from, to } }).then(r => r.data),

  getQualityMIS: (from: string, to: string) =>
    api.get<QualityMISData>('/reports/quality/', { params: { from, to } }).then(r => r.data),

  buildReport: (config: ReportBuilderConfig) =>
    api.post<ReportBuilderResult>('/reports/builder/', config).then(r => r.data),

  exportReport: (config: ReportBuilderConfig, format: 'xlsx' | 'pdf' | 'csv') =>
    api.post(`/reports/builder/export/?format=${format}`, config, { responseType: 'blob' }).then(r => r.data),
};

// ─── Mock data ───────────────────────────────────────────────────────

const MONTHS = ['Aug', 'Sep', 'Oct', 'Nov', 'Dec', 'Jan'];

export function mockPurchaseMIS(): PurchaseMISData {
  return {
    monthly_spend: MONTHS.map(m => ({
      month: m, amount: Math.floor(Math.random() * 3000000 + 1500000), po_count: Math.floor(Math.random() * 40 + 10)
    })),
    top_vendors: ['Steel Authority', 'Fastener World', 'ABC Chemicals', 'Prime Metals', 'Sun Components'].map(name => ({
      name, amount: Math.floor(Math.random() * 900000 + 100000), po_count: Math.floor(Math.random() * 30 + 5)
    })),
    pr_to_po_tat: MONTHS.map(m => ({ month: m, avg_days: Math.floor(Math.random() * 8 + 2) })),
    spend_by_category: ['Raw Materials', 'Consumables', 'Packaging', 'Spares', 'Tools'].map(c => ({
      category: c, amount: Math.floor(Math.random() * 2000000 + 200000)
    })),
  };
}

export function mockSalesMIS(): SalesMISData {
  return {
    monthly_revenue: MONTHS.map(m => ({
      month: m, revenue: Math.floor(Math.random() * 5000000 + 2000000), orders: Math.floor(Math.random() * 50 + 20)
    })),
    top_customers: ['Reliance Industries', 'L&T Engineering', 'BHEL', 'Tata Motors', 'ONGC'].map(name => ({
      name, revenue: Math.floor(Math.random() * 1500000 + 300000), orders: Math.floor(Math.random() * 20 + 3)
    })),
    so_fulfillment_rate: MONTHS.map(m => {
      const total = Math.floor(Math.random() * 40 + 20);
      const on_time = Math.floor(total * (Math.random() * 0.2 + 0.75));
      return { month: m, rate: Math.round(on_time / total * 100), on_time, total };
    }),
    revenue_by_product: ['Flanges', 'Valves', 'Pipes', 'Fittings', 'Custom Parts'].map(p => ({
      product: p, revenue: Math.floor(Math.random() * 2000000 + 300000)
    })),
  };
}

export function mockStoresMIS(): StoresMISData {
  return {
    stock_value_trend: MONTHS.map(m => ({ month: m, value: Math.floor(Math.random() * 5000000 + 8000000) })),
    stock_aging: [
      { bucket: '0-30 days', value: 4200000, qty: 1230 },
      { bucket: '31-90 days', value: 2800000, qty: 845 },
      { bucket: '91-180 days', value: 1200000, qty: 320 },
      { bucket: '180+ days', value: 600000, qty: 110 },
    ],
    turnover_ratio: ['Raw Materials', 'WIP', 'Finished Goods', 'Consumables', 'Spares'].map(c => ({
      category: c, ratio: +(Math.random() * 8 + 1).toFixed(1)
    })),
    slow_moving: [
      { item: 'SS Plate 10mm', days: 245, value: 182000 },
      { item: 'Gasket Set A3', days: 198, value: 43200 },
      { item: 'O-Ring 50mm', days: 167, value: 12800 },
    ],
  };
}

export function mockProductionMIS(): ProductionMISData {
  return {
    machine_utilization: ['Lathe M1', 'VMC M2', 'HMC M3', 'Grinder M4', 'Drill M5'].map(machine => ({
      machine,
      utilization: Math.floor(Math.random() * 30 + 60),
      planned: 480,
      actual: Math.floor(Math.random() * 150 + 300),
    })),
    wo_completion_rate: MONTHS.map(m => {
      const total = Math.floor(Math.random() * 30 + 15);
      const completed = Math.floor(total * (Math.random() * 0.2 + 0.70));
      return { month: m, rate: Math.round(completed / total * 100), completed, total };
    }),
    rejection_trend: MONTHS.map(m => ({ month: m, rate: +(Math.random() * 4 + 1).toFixed(1) })),
  };
}

export function mockQualityMIS(): QualityMISData {
  return {
    rejection_rate: MONTHS.map(m => {
      const inspected = Math.floor(Math.random() * 200 + 100);
      const rejected = Math.floor(inspected * (Math.random() * 0.05 + 0.01));
      return { month: m, rate: +(rejected / inspected * 100).toFixed(1), inspected, rejected };
    }),
    capa_closure_rate: MONTHS.map(m => {
      const open = Math.floor(Math.random() * 10 + 3);
      const closed = Math.floor(Math.random() * 8 + 2);
      return { month: m, rate: Math.round(closed / (open + closed) * 100), open, closed };
    }),
    defect_by_category: ['Dimensional', 'Surface Finish', 'Material', 'Packaging', 'Documentation'].map(c => ({
      category: c, count: Math.floor(Math.random() * 30 + 5)
    })),
    supplier_quality: ['Steel Authority', 'Fastener World', 'ABC Chemicals', 'Prime Metals'].map(v => ({
      vendor: v, rejection_rate: +(Math.random() * 5 + 0.5).toFixed(1)
    })),
  };
}

// ─── Report Builder API ─────────────────────────────────────────────

export interface ReportResult {
  columns: Array<{ key: string; label: string; type: 'text' | 'number' | 'currency' | 'date' }>;
  rows: Array<Record<string, string | number>>;
  totals?: Record<string, string | number>;
  row_count: number;
}

export const reportsService = {
  list: (params?: Record<string, unknown>) =>
    api.get('/api/v1/reports/reports/', { params }).then(r => r.data),

  get: (id: string) =>
    api.get(`/api/v1/reports/reports/${id}/`).then(r => r.data),

  create: (data: unknown) =>
    api.post('/api/v1/reports/reports/', data).then(r => r.data),

  update: (id: string, data: unknown) =>
    api.patch(`/api/v1/reports/reports/${id}/`, data).then(r => r.data),

  run: (reportType: string, params: Record<string, unknown>): Promise<ReportResult> =>
    api.post('/api/v1/reports/run/', { report_type: reportType, ...params }).then(r => r.data),

  exportReport: (reportType: string, params: Record<string, unknown>, format: 'excel' | 'pdf') =>
    api.post('/api/v1/reports/export/', { report_type: reportType, format, ...params },
      { responseType: 'blob' }).then(r => r.data),

  getMIS: (module: string, period?: string) =>
    api.get(`/api/v1/reports/mis/${module}/`, { params: { period } }).then(r => r.data),

  // P4 – WIP + RM Inventory Valuation
  getInventoryValuation: (params?: { warehouse_id?: string; as_of_date?: string }) =>
    api.post<InventoryValuationResult>('/api/v1/reports/run/', {
      report_type: 'inventory_valuation',
      ...params,
    }).then(r => r.data),
};
