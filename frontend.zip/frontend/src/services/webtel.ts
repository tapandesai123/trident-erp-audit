// frontend/src/services/webtel.ts
import api from './api';

export const webtelService = {
  // IRN / e-Invoice
  listIRN: (params?: Record<string, unknown>) =>
    api.get('/api/v1/webtel/irn-requests/', { params }).then(r => r.data),
  generateIRN: (invoiceId: string) =>
    api.post(`/api/v1/webtel/irn-requests/${invoiceId}/generate/`).then(r => r.data),
  cancelIRN: (id: string, reason: string) =>
    api.post(`/api/v1/webtel/irn-requests/${id}/cancel/`, { reason }).then(r => r.data),

  // e-Way Bills
  listEway: (params?: Record<string, unknown>) =>
    api.get('/api/v1/webtel/eway-bills/', { params }).then(r => r.data),
  generateEway: (invoiceId: string, data: unknown) =>
    api.post(`/api/v1/webtel/eway-bills/`, { invoice_id: invoiceId, ...data as object }).then(r => r.data),
  cancelEway: (id: string, reason: string) =>
    api.post(`/api/v1/webtel/eway-bills/${id}/cancel/`, { reason }).then(r => r.data),

  // GSTR-2B Reconciliation
  listRecon: (params?: Record<string, unknown>) =>
    api.get('/api/v1/webtel/gstr2b/', { params }).then(r => r.data),
  fetchGstr2b: (period: string) =>
    api.post('/api/v1/webtel/gstr2b/', { return_period: period }).then(r => r.data),
  runReconciliation: (period: string) =>
    api.post('/api/v1/webtel/reconciliation/', { period }).then(r => r.data),
  getMismatchReport: (period: string) =>
    api.get('/api/v1/webtel/reconciliation/mismatch_report/', { params: { period } }).then(r => r.data),
  sendMismatchEmails: (period: string) =>
    api.post('/api/v1/webtel/reconciliation/send_mismatch_emails/', { period }).then(r => r.data),

  // GSTR Returns
  listReturns: (params?: Record<string, unknown>) =>
    api.get('/api/v1/webtel/gst-returns/', { params }).then(r => r.data),
  fileReturn: (id: string) =>
    api.post(`/api/v1/webtel/gst-returns/${id}/file/`).then(r => r.data),
};
