/**
 * StickerPrintModal — Task 16
 * Print A4 identification tag or 60×70mm roll label for an inventory lot.
 * Fetches PDF from backend, opens in new window, auto-triggers browser print dialog.
 */
import { useState } from 'react';
import { PrinterIcon, DocumentTextIcon, TagIcon } from '@heroicons/react/24/outline';

import Modal from '@/components/ui/Modal';
import Button from '@/components/ui/Button';
import { storesService } from '@/services/stores';

interface InventoryLotMin {
  id: string;
  lot_number: string;
  item_code?: string;
  item_name?: string;
}

interface Props {
  lot: InventoryLotMin;
  onClose: () => void;
}

type PrintSize = 'A4' | 'LABEL_60x70';

function openPdfBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  // Open in new window and inject a small script to auto-trigger print dialog
  const win = window.open(url, '_blank');
  if (win) {
    // After PDF loads, trigger print
    win.onload = () => {
      setTimeout(() => {
        win.focus();
        win.print();
      }, 500);
    };
  }
  // Fallback download if popup was blocked
  setTimeout(() => {
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    // Only download if window didn't open
    if (!win || win.closed) {
      a.click();
    }
    URL.revokeObjectURL(url);
  }, 2000);
}

export default function StickerPrintModal({ lot, onClose }: Props) {
  const [loading, setLoading] = useState<PrintSize | null>(null);
  const [error, setError] = useState('');

  async function handlePrint(size: PrintSize) {
    setError('');
    setLoading(size);
    try {
      const blob = await storesService.printTag(lot.id, size);
      const filename = size === 'A4'
        ? `Tag_A4_${lot.lot_number}.pdf`
        : `Label_60x70_${lot.lot_number}.pdf`;
      openPdfBlob(blob, filename);
    } catch (e: any) {
      setError(e?.response?.data?.error ?? 'Failed to generate PDF. Please try again.');
    } finally {
      setLoading(null);
    }
  }

  return (
    <Modal open onClose={onClose} title="Print Tag / Label" size="sm">
      <div className="p-5 space-y-5">
        {/* Lot info summary */}
        <div className="bg-neutral-50 border border-neutral-200 rounded-xl p-3">
          <p className="text-xs text-neutral-500 mb-0.5">Lot</p>
          <p className="text-sm font-semibold font-mono text-neutral-800">{lot.lot_number}</p>
          {lot.item_code && (
            <p className="text-xs text-neutral-600 mt-0.5">
              {lot.item_code} — {lot.item_name}
            </p>
          )}
        </div>

        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 text-sm rounded-lg p-3">
            {error}
          </div>
        )}

        {/* Print option cards */}
        <div className="space-y-3">
          {/* A4 Tag */}
          <button
            disabled={!!loading}
            onClick={() => handlePrint('A4')}
            className="w-full flex items-start gap-4 p-4 rounded-xl border-2 border-neutral-200 hover:border-primary-400 hover:bg-primary-50 transition-colors text-left disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <div className="mt-0.5 shrink-0 h-10 w-10 rounded-lg bg-primary-100 flex items-center justify-center">
              <DocumentTextIcon className="h-5 w-5 text-primary-700" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-semibold text-neutral-800 text-sm">Print A4 Tag</p>
              <p className="text-xs text-neutral-500 mt-0.5">
                Half-A4 size · Large QR (8×8 cm) · Item code, supplier, weight, location
                · 2 tags per A4 sheet
              </p>
            </div>
            {loading === 'A4' ? (
              <div className="h-5 w-5 border-2 border-primary-600 border-t-transparent rounded-full animate-spin mt-2.5 shrink-0" />
            ) : (
              <PrinterIcon className="h-5 w-5 text-neutral-400 mt-2.5 shrink-0" />
            )}
          </button>

          {/* 60×70 Label */}
          <button
            disabled={!!loading}
            onClick={() => handlePrint('LABEL_60x70')}
            className="w-full flex items-start gap-4 p-4 rounded-xl border-2 border-neutral-200 hover:border-amber-400 hover:bg-amber-50 transition-colors text-left disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <div className="mt-0.5 shrink-0 h-10 w-10 rounded-lg bg-amber-100 flex items-center justify-center">
              <TagIcon className="h-5 w-5 text-amber-700" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-semibold text-neutral-800 text-sm">Print 60×70mm Label</p>
              <p className="text-xs text-neutral-500 mt-0.5">
                Roll sticker size · Small QR (2×2 cm) · Item code, lot, weight, bin
                · 4 labels per A4 sheet (laser) or single for label printer
              </p>
            </div>
            {loading === 'LABEL_60x70' ? (
              <div className="h-5 w-5 border-2 border-amber-600 border-t-transparent rounded-full animate-spin mt-2.5 shrink-0" />
            ) : (
              <PrinterIcon className="h-5 w-5 text-neutral-400 mt-2.5 shrink-0" />
            )}
          </button>
        </div>

        <p className="text-xs text-neutral-400 text-center">
          PDF will open in a new tab — browser print dialog launches automatically
        </p>

        <div className="flex justify-end pt-1">
          <Button variant="ghost" onClick={onClose} disabled={!!loading}>
            Close
          </Button>
        </div>
      </div>
    </Modal>
  );
}
