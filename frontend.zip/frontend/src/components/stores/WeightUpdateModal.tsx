/**
 * WeightUpdateModal — Task 16
 * Update lot current weight/quantity, triggers QR re-generation.
 * On success: shows new QR image and prompts to print updated 60×70 label.
 */
import { useState } from 'react';
import { ArrowPathIcon, ScaleIcon } from '@heroicons/react/24/outline';

import Modal from '@/components/ui/Modal';
import Button from '@/components/ui/Button';
import FormField from '@/components/ui/FormField';
import Input from '@/components/ui/Input';
import Textarea from '@/components/ui/Textarea';
import { storesService } from '@/services/stores';

interface Props {
  lot: {
    id: string;
    lot_number: string;
    item_code?: string;
    current_qty?: number | string;
    uom_code?: string;
  };
  onSuccess?: (newWeight: number) => void;
  onClose: () => void;
}

const REASONS = [
  'Physical weighment difference',
  'Moisture loss / drying',
  'Trimming / cutting waste',
  'Data entry correction',
  'Re-weighment after splitting',
  'Other',
];

export default function WeightUpdateModal({ lot, onSuccess, onClose }: Props) {
  const [newWeight, setNewWeight] = useState('');
  const [reason, setReason] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [result, setResult] = useState<{ qr_base64: string; new_weight: number } | null>(null);
  const [printLoading, setPrintLoading] = useState(false);

  async function handleSubmit() {
    const w = parseFloat(newWeight);
    if (isNaN(w) || w < 0) {
      setError('Please enter a valid weight (≥ 0).');
      return;
    }
    if (!reason.trim()) {
      setError('Please provide a reason for the weight update.');
      return;
    }

    setError('');
    setLoading(true);
    try {
      const data = await storesService.updateWeight(lot.id, {
        new_weight: w,
        reason: reason.trim(),
      });
      setResult(data);
      onSuccess?.(data.new_weight);
    } catch (e: any) {
      setError(e?.response?.data?.error ?? 'Failed to update weight. Please try again.');
    } finally {
      setLoading(false);
    }
  }

  async function handlePrintLabel() {
    setPrintLoading(true);
    try {
      const blob = await storesService.printTag(lot.id, 'LABEL_60x70');
      const url = URL.createObjectURL(blob);
      const win = window.open(url, '_blank');
      if (win) {
        win.onload = () => setTimeout(() => { win.focus(); win.print(); }, 500);
      }
      setTimeout(() => URL.revokeObjectURL(url), 5000);
    } catch {
      // silent — user can retry from detail page
    } finally {
      setPrintLoading(false);
    }
  }

  /* ── Success state ──────────────────────────────────────────── */
  if (result) {
    return (
      <Modal open onClose={onClose} title="Weight Updated" size="sm">
        <div className="p-5 space-y-5">
          <div className="flex items-center gap-3 bg-green-50 border border-green-200 rounded-xl p-4">
            <ArrowPathIcon className="h-6 w-6 text-green-600 shrink-0" />
            <div>
              <p className="text-sm font-semibold text-green-800">Weight updated successfully</p>
              <p className="text-sm text-green-700 mt-0.5">
                New weight: <strong>{result.new_weight} kg</strong>
              </p>
            </div>
          </div>

          {/* New QR code */}
          <div className="flex flex-col items-center gap-3">
            <p className="text-xs text-neutral-500">Updated QR Code</p>
            <img
              src={`data:image/png;base64,${result.qr_base64}`}
              alt="Updated QR"
              className="w-36 h-36 border border-neutral-200 rounded-lg"
            />
            <p className="text-xs font-mono text-neutral-500">{lot.lot_number}</p>
          </div>

          <div className="flex gap-2 justify-center">
            <Button
              onClick={handlePrintLabel}
              loading={printLoading}
              variant="primary"
              size="sm"
            >
              🖨 Print Updated 60×70 Label
            </Button>
            <Button variant="ghost" onClick={onClose} size="sm">
              Done
            </Button>
          </div>
        </div>
      </Modal>
    );
  }

  /* ── Form state ─────────────────────────────────────────────── */
  return (
    <Modal open onClose={onClose} title="Update Weight" size="sm">
      <div className="p-5 space-y-4">
        {/* Lot info */}
        <div className="bg-neutral-50 border border-neutral-200 rounded-xl p-3 flex items-center gap-3">
          <ScaleIcon className="h-5 w-5 text-neutral-500 shrink-0" />
          <div>
            <p className="text-sm font-semibold font-mono text-neutral-800">{lot.lot_number}</p>
            {lot.item_code && (
              <p className="text-xs text-neutral-500">
                {lot.item_code} · Current: <strong>{lot.current_qty} {lot.uom_code}</strong>
              </p>
            )}
          </div>
        </div>

        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 text-sm rounded-lg p-3">
            {error}
          </div>
        )}

        <FormField label="New Weight / Quantity" required>
          <Input
            type="number"
            value={newWeight}
            onChange={e => setNewWeight(e.target.value)}
            placeholder="e.g. 245.600"
            step="0.001"
            min="0"
          />
        </FormField>

        <FormField label="Reason for Update" required>
          <select
            value={reason}
            onChange={e => setReason(e.target.value)}
            className="w-full rounded-lg border border-neutral-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary-400"
          >
            <option value="">Select reason…</option>
            {REASONS.map(r => <option key={r} value={r}>{r}</option>)}
          </select>
        </FormField>

        {reason === 'Other' && (
          <FormField label="Describe reason">
            <Textarea
              value={reason === 'Other' ? '' : reason}
              onChange={e => setReason(e.target.value)}
              rows={2}
              placeholder="Please describe the reason…"
            />
          </FormField>
        )}

        <p className="text-xs text-neutral-400">
          A transaction record will be created. QR code will be automatically regenerated with the new weight.
        </p>

        <div className="flex gap-2 justify-end pt-1">
          <Button variant="ghost" onClick={onClose} disabled={loading}>
            Cancel
          </Button>
          <Button onClick={handleSubmit} loading={loading}>
            Update Weight
          </Button>
        </div>
      </div>
    </Modal>
  );
}
