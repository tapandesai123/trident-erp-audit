import { formatCurrency } from '@/utils/format';

interface Props {
  subtotal: string | number;
  gstAmount: string | number;
  tcsAmount?: string | number;
  totalAmount: string | number;
  currency?: string;
  className?: string;
}

export default function POTotals({ subtotal, gstAmount, tcsAmount, totalAmount, currency = 'INR', className }: Props) {
  return (
    <div className={`bg-neutral-50 rounded-xl border border-neutral-100 p-4 ${className ?? ''}`}>
      <h4 className="text-xs font-semibold text-neutral-400 uppercase tracking-wide mb-3">Totals ({currency})</h4>
      <div className="space-y-2">
        <Row label="Subtotal" value={formatCurrency(subtotal)} />
        <Row label="GST" value={formatCurrency(gstAmount)} />
        {Number(tcsAmount ?? 0) > 0 && <Row label="TCS" value={formatCurrency(tcsAmount!)} />}
        <div className="border-t border-neutral-200 my-2" />
        <Row label="Total" value={formatCurrency(totalAmount)} bold />
      </div>
    </div>
  );
}

function Row({ label, value, bold }: { label: string; value: string; bold?: boolean }) {
  return (
    <div className="flex justify-between items-center">
      <span className={`text-sm ${bold ? 'font-bold text-neutral-900' : 'text-neutral-600'}`}>{label}</span>
      <span className={`text-sm font-mono ${bold ? 'font-bold text-neutral-900 text-base' : 'text-neutral-700'}`}>{value}</span>
    </div>
  );
}
