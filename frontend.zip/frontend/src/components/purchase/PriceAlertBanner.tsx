import { ExclamationTriangleIcon } from '@heroicons/react/24/outline';
import type { PriceAlert } from '@/services/purchase';
import { formatCurrency } from '@/utils/format';

interface Props {
  alerts: PriceAlert[];
  onDismiss?: () => void;
}

export default function PriceAlertBanner({ alerts, onDismiss }: Props) {
  if (!alerts.length) return null;

  return (
    <div className="rounded-xl border border-warning-200 bg-warning-50 p-4 mb-4">
      <div className="flex items-start gap-3">
        <ExclamationTriangleIcon className="h-5 w-5 text-warning-600 shrink-0 mt-0.5" />
        <div className="flex-1">
          <p className="text-sm font-semibold text-warning-800 mb-2">
            Price Increase Alert — {alerts.length} item{alerts.length > 1 ? 's' : ''} have higher rates than last PO
          </p>
          <div className="space-y-1.5">
            {alerts.map((a, i) => (
              <div key={i} className="text-xs text-warning-700 flex items-center gap-2 flex-wrap">
                <span className="font-mono font-semibold">{a.item_code}</span>
                <span>{a.item_name}</span>
                <span className="text-warning-500">·</span>
                <span>Last: {formatCurrency(a.last_rate)}</span>
                <span>→</span>
                <span className="font-semibold text-warning-900">Now: {formatCurrency(a.current_rate)}</span>
                <span className="font-bold text-danger-600 bg-danger-100 px-1.5 py-0.5 rounded">
                  +{a.increase_pct.toFixed(1)}%
                </span>
                <span className="text-neutral-400">vs {a.last_po}</span>
              </div>
            ))}
          </div>
        </div>
        {onDismiss && (
          <button onClick={onDismiss} className="text-warning-400 hover:text-warning-600 text-xs shrink-0">
            Dismiss
          </button>
        )}
      </div>
    </div>
  );
}
