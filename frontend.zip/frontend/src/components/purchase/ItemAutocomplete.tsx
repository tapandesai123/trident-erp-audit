import { useState, useRef, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { MagnifyingGlassIcon, XMarkIcon } from '@heroicons/react/24/outline';
import { itemsService } from '@/services/items';
import { useDebounce } from '@/hooks/useDebounce';
import { cn } from '@/utils/cn';

export interface SelectedItem {
  id: string;
  code: string;
  name: string;
  uom_id: number;
  uom_code: string;
  gst_rate: string;
  item_type: string;
}

interface Props {
  value?: SelectedItem | null;
  onChange: (item: SelectedItem | null) => void;
  label?: string;
  required?: boolean;
  error?: string;
  disabled?: boolean;
  placeholder?: string;
}

export default function ItemAutocomplete({
  value, onChange, label, required, error, disabled, placeholder = 'Search items…',
}: Props) {
  const [inputVal, setInputVal] = useState(value ? `${value.code} — ${value.name}` : '');
  const [open, setOpen] = useState(false);
  const debouncedQ = useDebounce(inputVal.includes('—') ? '' : inputVal, 300);
  const containerRef = useRef<HTMLDivElement>(null);

  const { data, isLoading } = useQuery({
    queryKey: ['item-search', debouncedQ],
    queryFn: () => itemsService.getItems({ search: debouncedQ, approval_status: 'APPROVED', limit: 8 }),
    enabled: debouncedQ.length >= 2 && open,
    staleTime: 30_000,
  });

  // Sync display when external value changes
  useEffect(() => {
    if (value) setInputVal(`${value.code} — ${value.name}`);
    else setInputVal('');
  }, [value]);

  // Close on outside click
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (!containerRef.current?.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const handleSelect = (item: typeof data extends { results: infer R[] } ? R : never) => {
    if (!item) return;
    const sel: SelectedItem = {
      id: item.id,
      code: item.code,
      name: item.name,
      uom_id: (item as unknown as { uom?: number }).uom ?? 0,
      uom_code: item.uom_code ?? '',
      gst_rate: (item as unknown as { gst_rate?: string }).gst_rate ?? '18',
      item_type: item.item_type,
    };
    onChange(sel);
    setInputVal(`${item.code} — ${item.name}`);
    setOpen(false);
  };

  const handleClear = () => {
    onChange(null);
    setInputVal('');
    setOpen(false);
  };

  return (
    <div ref={containerRef} className="relative w-full">
      {label && (
        <label className="form-label">
          {label}{required && <span className="text-danger-500 ml-0.5">*</span>}
        </label>
      )}
      <div className={cn(
        'relative flex items-center form-input p-0 overflow-hidden',
        error && 'border-danger-500',
        disabled && 'bg-neutral-50 cursor-not-allowed opacity-60',
      )}>
        <MagnifyingGlassIcon className="h-4 w-4 text-neutral-400 ml-3 shrink-0" />
        <input
          className="flex-1 px-2 py-2 text-sm bg-transparent outline-none"
          value={inputVal}
          onChange={e => { setInputVal(e.target.value); setOpen(true); }}
          onFocus={() => { if (!value) setOpen(true); }}
          placeholder={placeholder}
          disabled={disabled}
        />
        {value && (
          <button type="button" onClick={handleClear}
            className="mr-2 text-neutral-300 hover:text-neutral-500 transition-colors">
            <XMarkIcon className="h-4 w-4" />
          </button>
        )}
      </div>
      {error && <p className="form-error">{error}</p>}

      {/* Dropdown */}
      {open && !value && debouncedQ.length >= 2 && (
        <div className="absolute z-50 mt-1 w-full bg-white border border-neutral-200 rounded-xl shadow-lg overflow-hidden">
          {isLoading ? (
            <div className="px-4 py-3 text-sm text-neutral-400">Searching…</div>
          ) : !data?.results?.length ? (
            <div className="px-4 py-3 text-sm text-neutral-400">No approved items found</div>
          ) : (
            <ul className="max-h-56 overflow-y-auto divide-y divide-neutral-50">
              {data.results.map(item => (
                <li key={item.id}>
                  <button
                    type="button"
                    onMouseDown={() => handleSelect(item as Parameters<typeof handleSelect>[0])}
                    className="w-full text-left px-4 py-2.5 hover:bg-primary-50 transition-colors"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-mono text-xs font-semibold text-primary-800 shrink-0">{item.code}</span>
                      <span className="text-xs text-neutral-400 shrink-0">{item.uom_code}</span>
                    </div>
                    <p className="text-sm text-neutral-700 mt-0.5 truncate">{item.name}</p>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </div>
  );
}
