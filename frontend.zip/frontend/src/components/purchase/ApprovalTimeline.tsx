import { PRApproval } from '@/services/purchase';
import { CheckCircleIcon, XCircleIcon, ArrowUturnLeftIcon, ClockIcon } from '@heroicons/react/24/outline';
import { formatDateTime } from '@/utils/format';
import { cn } from '@/utils/cn';

const LEVEL_LABELS: Record<number, string> = {
  1: 'HOD',
  2: 'Plant Head',
  3: 'Director',
};

const ACTION_CONFIG = {
  APPROVED: { icon: CheckCircleIcon, color: 'text-success-600', bg: 'bg-success-50', label: 'Approved' },
  REJECTED: { icon: XCircleIcon, color: 'text-danger-500', bg: 'bg-danger-50', label: 'Rejected' },
  RETURNED: { icon: ArrowUturnLeftIcon, color: 'text-warning-600', bg: 'bg-warning-50', label: 'Returned for Revision' },
} as const;

interface Props {
  approvals?: PRApproval[];
  pendingLevel?: number;
  currentApproverName?: string;
}

export default function ApprovalTimeline({ approvals = [], pendingLevel, currentApproverName }: Props) {
  if (!approvals.length && !pendingLevel) return null;

  return (
    <div className="space-y-0">
      <h4 className="text-xs font-semibold text-neutral-400 uppercase tracking-wide mb-3">Approval History</h4>
      <div className="relative">
        {/* vertical line */}
        <div className="absolute left-4 top-0 bottom-0 w-px bg-neutral-100" />

        <div className="space-y-4">
          {approvals.map((a, i) => {
            const cfg = ACTION_CONFIG[a.action];
            const Icon = cfg.icon;
            return (
              <div key={i} className="flex gap-3 relative">
                <div className={cn('h-8 w-8 rounded-full flex items-center justify-center shrink-0 z-10', cfg.bg)}>
                  <Icon className={cn('h-4 w-4', cfg.color)} />
                </div>
                <div className="flex-1 pb-4">
                  <div className="flex items-baseline gap-2 flex-wrap">
                    <span className="text-sm font-semibold text-neutral-800">{cfg.label}</span>
                    <span className="text-xs text-neutral-500">
                      by {a.approver_name} ({LEVEL_LABELS[a.level] ?? `Level ${a.level}`})
                    </span>
                    <span className="text-xs text-neutral-400">{formatDateTime(a.acted_at)}</span>
                  </div>
                  {a.remarks && (
                    <p className="mt-1 text-xs text-neutral-500 bg-neutral-50 px-2 py-1 rounded border border-neutral-100">
                      {a.remarks}
                    </p>
                  )}
                </div>
              </div>
            );
          })}

          {pendingLevel && (
            <div className="flex gap-3 relative">
              <div className="h-8 w-8 rounded-full bg-primary-50 flex items-center justify-center shrink-0 z-10">
                <ClockIcon className="h-4 w-4 text-primary-600 animate-pulse" />
              </div>
              <div className="flex-1 pb-4">
                <div className="flex items-baseline gap-2">
                  <span className="text-sm font-semibold text-primary-700">Pending</span>
                  <span className="text-xs text-neutral-500">
                    {LEVEL_LABELS[pendingLevel] ?? `Level ${pendingLevel}`} Approval
                    {currentApproverName && ` — ${currentApproverName}`}
                  </span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
