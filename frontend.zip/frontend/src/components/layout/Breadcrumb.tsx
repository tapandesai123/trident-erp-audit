import { Link, useLocation } from 'react-router-dom';
import { HomeIcon, ChevronRightIcon } from '@heroicons/react/20/solid';
import { cn } from '@/utils/cn';

// Human-readable segment labels
const SEGMENT_LABELS: Record<string, string> = {
  masters: 'Masters',
  vendors: 'Vendors',
  items: 'Items',
  customers: 'Customers',
  purchase: 'Purchase',
  requisitions: 'Requisitions',
  orders: 'Orders',
  'gate-entries': 'Gate Entries',
  mrrs: 'MRRs',
  stores: 'Stores',
  inventory: 'Inventory',
  'bin-locations': 'Bin Locations',
  'physical-verification': 'Physical Verification',
  sales: 'Sales',
  enquiries: 'Enquiries',
  quotations: 'Quotations',
  despatches: 'Despatches',
  invoices: 'Invoices',
  accounts: 'Accounts',
  vouchers: 'Vouchers',
  outstanding: 'Outstanding',
  gst: 'GST',
  production: 'Production',
  boms: 'BOMs',
  'work-orders': 'Work Orders',
  'job-cards': 'Job Cards',
  quality: 'Quality',
  inspections: 'Inspections',
  capa: 'CAPA',
  dispatch: 'Dispatch',
  crm: 'CRM',
  hr: 'HR',
  payroll: 'Payroll',
  assets: 'Assets',
  maintenance: 'Maintenance',
  projects: 'Projects',
  tasks: 'Tasks',
  reports: 'Reports',
  webtel: 'Webtel',
  dashboard: 'Dashboard',
  new: 'New',
};

function toLabel(segment: string): string {
  // Check if it looks like an ID (numeric or UUID)
  if (/^\d+$/.test(segment)) return `#${segment}`;
  if (/^[0-9a-f-]{36}$/i.test(segment)) return 'Detail';
  return SEGMENT_LABELS[segment] ?? segment.replace(/-/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());
}

interface BreadcrumbProps {
  className?: string;
}

export default function Breadcrumb({ className }: BreadcrumbProps) {
  const { pathname } = useLocation();
  const segments = pathname.split('/').filter(Boolean);

  if (segments.length === 0) return null;

  const crumbs = segments.map((seg, i) => ({
    label: toLabel(seg),
    href: '/' + segments.slice(0, i + 1).join('/'),
    isLast: i === segments.length - 1,
  }));

  return (
    <nav aria-label="Breadcrumb" className={cn('flex items-center gap-1 text-xs', className)}>
      <Link to="/dashboard" className="text-neutral-400 hover:text-primary-700 transition-colors">
        <HomeIcon className="h-3.5 w-3.5" />
      </Link>
      {crumbs.map((crumb) => (
        <span key={crumb.href} className="flex items-center gap-1">
          <ChevronRightIcon className="h-3 w-3 text-neutral-300" />
          {crumb.isLast ? (
            <span className="text-neutral-600 font-medium">{crumb.label}</span>
          ) : (
            <Link to={crumb.href} className="text-neutral-400 hover:text-primary-700 transition-colors">
              {crumb.label}
            </Link>
          )}
        </span>
      ))}
    </nav>
  );
}
