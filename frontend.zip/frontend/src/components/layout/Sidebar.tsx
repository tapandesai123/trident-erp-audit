import { useState } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import {
  HomeIcon,
  BuildingStorefrontIcon,
  ShoppingCartIcon,
  ArchiveBoxIcon,
  ShoppingBagIcon,
  BanknotesIcon,
  CogIcon,
  BeakerIcon,
  TruckIcon,
  UserGroupIcon,
  UserIcon,
  CurrencyRupeeIcon,
  ComputerDesktopIcon,
  WrenchScrewdriverIcon,
  FolderIcon,
  ClipboardDocumentListIcon,
  ChartBarIcon,
  CloudIcon,
  ChevronDownIcon,
  ChevronRightIcon,
  Bars3Icon,
  XMarkIcon,
  DevicePhoneMobileIcon,
  ServerStackIcon,
} from '@heroicons/react/24/outline';
import { cn } from '@/utils/cn';

interface NavItem {
  label: string;
  href?: string;
  icon?: React.ReactNode;
  children?: { label: string; href: string }[];
}

const navGroups: NavItem[] = [
  {
    label: 'Dashboard',
    href: '/dashboard',
    icon: <HomeIcon className="h-5 w-5" />,
  },
  {
    label: 'Masters',
    icon: <BuildingStorefrontIcon className="h-5 w-5" />,
    children: [
      { label: 'Vendors', href: '/masters/vendors' },
      { label: 'Items', href: '/masters/items' },
      { label: 'Customers', href: '/masters/customers' },
    ],
  },
  {
    label: 'Purchase',
    icon: <ShoppingCartIcon className="h-5 w-5" />,
    children: [
      { label: 'Requisitions', href: '/purchase/requisitions' },
      { label: 'Orders', href: '/purchase/orders' },
      { label: 'Gate Entries', href: '/purchase/gate-entries' },
      { label: 'MRRs', href: '/purchase/mrrs' },
      { label: 'Vendor Sauda', href: '/purchase/sauda' },
      { label: 'Job Worker RGP', href: '/purchase/rgp' },
    ],
  },
  {
    label: 'Stores',
    icon: <ArchiveBoxIcon className="h-5 w-5" />,
    children: [
      { label: 'Dashboard', href: '/stores' },
      { label: 'Inventory', href: '/stores/inventory' },
      { label: 'Bin Locations', href: '/stores/bin-locations' },
      { label: 'Physical Verification', href: '/stores/physical-verification' },
      { label: 'Below Minimum', href: '/stores/below-minimum' },
    ],
  },
  {
    label: 'Sales',
    icon: <ShoppingBagIcon className="h-5 w-5" />,
    children: [
      { label: 'Dashboard', href: '/sales' },
      { label: 'Enquiries', href: '/sales/enquiries' },
      { label: 'Quotations', href: '/sales/quotations' },
      { label: 'Orders', href: '/sales/orders' },
      { label: 'Despatches', href: '/sales/despatches' },
      { label: 'Invoices', href: '/sales/invoices' },
      { label: 'Complaints', href: '/sales/complaints' },
      { label: 'Territories', href: '/sales/territories' },
      { label: 'Performance', href: '/sales/performance' },
      { label: 'EDI Import', href: '/sales/edi-import' },
    ],
  },
  {
    label: 'Accounts',
    icon: <BanknotesIcon className="h-5 w-5" />,
    children: [
      { label: 'Dashboard', href: '/accounts' },
      { label: 'Vouchers', href: '/accounts/vouchers' },
      { label: 'Outstanding AP/AR', href: '/accounts/outstanding' },
      { label: 'GST Returns', href: '/accounts/gst' },
      { label: 'MSME Compliance', href: '/accounts/msme-report' },
    ],
  },
  {
    label: 'Production',
    icon: <CogIcon className="h-5 w-5" />,
    children: [
      { label: 'Bill of Materials', href: '/production/boms' },
      { label: 'Work Orders', href: '/production/work-orders' },
      { label: 'Job Cards', href: '/production/job-cards' },
      { label: 'WIP Tracking', href: '/production/wip' },
      { label: 'Downtime', href: '/production/downtime' },
    ],
  },
  {
    label: 'Quality',
    icon: <BeakerIcon className="h-5 w-5" />,
    children: [
      { label: 'Inspections', href: '/quality/inspections' },
      { label: 'CAPA', href: '/quality/capa' },
    ],
  },
  {
    label: 'Dispatch',
    icon: <TruckIcon className="h-5 w-5" />,
    children: [
      { label: 'Plan Dispatch', href: '/dispatch/plan' },
      { label: 'Dispatch Orders', href: '/dispatch/orders' },
      { label: 'Transporter Payments', href: '/dispatch/payments' },
    ],
  },
  {
    label: 'CRM',
    icon: <UserGroupIcon className="h-5 w-5" />,
    children: [
      { label: 'Lead Pipeline', href: '/crm' },
    ],
  },
  {
    label: 'HR',
    icon: <UserIcon className="h-5 w-5" />,
    children: [
      { label: 'Employees', href: '/hr/employees' },
    ],
  },
  {
    label: 'Payroll',
    icon: <CurrencyRupeeIcon className="h-5 w-5" />,
    children: [
      { label: 'Salary Register', href: '/payroll' },
    ],
  },
  {
    label: 'Assets',
    icon: <ComputerDesktopIcon className="h-5 w-5" />,
    children: [
      { label: 'Asset Register', href: '/assets' },
    ],
  },
  {
    label: 'Maintenance',
    icon: <WrenchScrewdriverIcon className="h-5 w-5" />,
    children: [
      { label: 'Requests & AMC', href: '/maintenance' },
    ],
  },
  {
    label: 'Projects',
    icon: <FolderIcon className="h-5 w-5" />,
    children: [
      { label: 'All Projects', href: '/projects' },
    ],
  },
  {
    label: 'Tasks',
    icon: <ClipboardDocumentListIcon className="h-5 w-5" />,
    children: [
      { label: 'My Tasks', href: '/tasks' },
      { label: 'New Task', href: '/tasks/new' },
    ],
  },
  {
    label: 'Reports',
    icon: <ChartBarIcon className="h-5 w-5" />,
    children: [
      { label: 'MIS Dashboard', href: '/reports' },
      { label: 'Report Builder', href: '/reports/builder' },
    ],
  },
  {
    label: 'Webtel',
    icon: <CloudIcon className="h-5 w-5" />,
    children: [
      { label: 'E-Invoice & E-WB', href: '/webtel' },
    ],
  },
  {
    label: 'Mobile',
    icon: <DevicePhoneMobileIcon className="h-5 w-5" />,
    children: [
      { label: 'QR Scanner', href: '/mobile/scanner' },
      { label: 'Approvals', href: '/mobile/approvals' },
    ],
  },
  {
    label: 'System',
    icon: <ServerStackIcon className="h-5 w-5" />,
    children: [
      { label: 'MLF Billing', href: '/admin/mlf-billing' },
      { label: 'User Management', href: '/admin/users' },
      { label: 'Audit Log', href: '/admin/audit-log' },
    ],
  },
];

interface SidebarProps {
  collapsed: boolean;
  onToggle: () => void;
}

export default function Sidebar({ collapsed, onToggle }: SidebarProps) {
  const location = useLocation();
  const [openGroups, setOpenGroups] = useState<Record<string, boolean>>(() => {
    // Auto-open the group that contains the current path
    const initial: Record<string, boolean> = {};
    navGroups.forEach((g) => {
      if (g.children?.some((c) => location.pathname.startsWith(c.href))) {
        initial[g.label] = true;
      }
    });
    return initial;
  });

  const toggleGroup = (label: string) => {
    setOpenGroups((prev) => ({ ...prev, [label]: !prev[label] }));
  };

  return (
    <aside
      className={cn(
        'flex flex-col h-full bg-primary-900 transition-all duration-200 ease-in-out',
        collapsed ? 'w-16' : 'w-60'
      )}
    >
      {/* Logo */}
      <div className="flex items-center h-16 px-4 border-b border-primary-800 shrink-0">
        {!collapsed && (
          <div className="flex items-center gap-2.5 flex-1 min-w-0">
            <div className="h-8 w-8 rounded-lg bg-accent-500 flex items-center justify-center shrink-0">
              <span className="text-white font-bold text-sm">T</span>
            </div>
            <span className="text-white font-semibold text-sm truncate">Trident ERP</span>
          </div>
        )}
        <button
          onClick={onToggle}
          className="ml-auto p-1.5 rounded-md text-primary-300 hover:text-white hover:bg-primary-800 transition-colors"
          aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
        >
          {collapsed ? (
            <Bars3Icon className="h-5 w-5" />
          ) : (
            <XMarkIcon className="h-5 w-5" />
          )}
        </button>
      </div>

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto py-3 px-2 space-y-0.5">
        {navGroups.map((item) => {
          if (item.href) {
            // Leaf item
            return (
              <NavLink
                key={item.label}
                to={item.href}
                className={({ isActive }) =>
                  cn('sidebar-link', isActive ? 'bg-primary-800 text-white' : 'text-primary-100')
                }
                title={collapsed ? item.label : undefined}
              >
                <span className="shrink-0">{item.icon}</span>
                {!collapsed && <span className="truncate">{item.label}</span>}
              </NavLink>
            );
          }

          // Group with children
          const isOpen = openGroups[item.label];
          const isActive = item.children?.some((c) => location.pathname.startsWith(c.href));

          return (
            <div key={item.label}>
              <button
                onClick={() => toggleGroup(item.label)}
                className={cn(
                  'sidebar-link w-full text-left',
                  isActive ? 'text-white bg-primary-800' : 'text-primary-100'
                )}
                title={collapsed ? item.label : undefined}
              >
                <span className="shrink-0">{item.icon}</span>
                {!collapsed && (
                  <>
                    <span className="truncate flex-1">{item.label}</span>
                    {isOpen ? (
                      <ChevronDownIcon className="h-4 w-4 text-primary-400" />
                    ) : (
                      <ChevronRightIcon className="h-4 w-4 text-primary-400" />
                    )}
                  </>
                )}
              </button>
              {!collapsed && isOpen && item.children && (
                <div className="ml-4 mt-0.5 space-y-0.5 border-l border-primary-800 pl-3">
                  {item.children.map((child) => (
                    <NavLink
                      key={child.href}
                      to={child.href}
                      className={({ isActive }) =>
                        cn(
                          'flex items-center px-2 py-1.5 rounded-md text-xs font-medium transition-colors',
                          isActive
                            ? 'text-white bg-primary-700'
                            : 'text-primary-300 hover:text-white hover:bg-primary-800'
                        )
                      }
                    >
                      {child.label}
                    </NavLink>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </nav>
    </aside>
  );
}
