import { Menu, Transition } from '@headlessui/react';
import { Fragment } from 'react';
import {
  BellIcon,
  ChevronDownIcon,
  ArrowRightOnRectangleIcon,
  UserCircleIcon,
} from '@heroicons/react/24/outline';
import { useAuthStore } from '@/stores/authStore';
import { authService } from '@/services/auth';
import { cn } from '@/utils/cn';
import type { Plant } from '@/services/auth';

interface HeaderProps {
  plants?: Plant[];
  onMenuClick?: () => void;
}

export default function Header({ plants = [], onMenuClick }: HeaderProps) {
  const { user, plant, setPlant, logout, tokens } = useAuthStore();

  const handlePlantChange = (p: Plant) => {
    setPlant(p);
    // Invalidate queries after plant switch would be done here if QueryClient is accessible
  };

  const handleLogout = async () => {
    try {
      if (tokens?.refresh) await authService.logout(tokens.refresh);
    } finally {
      logout();
    }
  };

  return (
    <header className="h-16 bg-white border-b border-neutral-100 flex items-center px-6 gap-4 shrink-0">
      {/* Mobile menu button */}
      {onMenuClick && (
        <button
          onClick={onMenuClick}
          className="md:hidden p-1.5 rounded-md text-neutral-500 hover:text-neutral-700 hover:bg-neutral-100 transition-colors"
          aria-label="Toggle menu"
        >
          <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>
      )}
      {/* Plant selector */}
      {plants.length > 1 && (
        <Menu as="div" className="relative">
          <Menu.Button className="flex items-center gap-2 px-3 py-1.5 rounded-lg border border-neutral-200 hover:bg-neutral-50 transition-colors text-sm font-medium text-neutral-700">
            <span className="h-2 w-2 bg-success-500 rounded-full" />
            {plant?.name ?? 'Select Plant'}
            <ChevronDownIcon className="h-4 w-4 text-neutral-400" />
          </Menu.Button>
          <Transition
            as={Fragment}
            enter="transition ease-out duration-100"
            enterFrom="opacity-0 scale-95"
            enterTo="opacity-100 scale-100"
            leave="transition ease-in duration-75"
            leaveFrom="opacity-100 scale-100"
            leaveTo="opacity-0 scale-95"
          >
            <Menu.Items className="absolute left-0 mt-1 w-52 bg-white border border-neutral-100 rounded-xl shadow-dropdown z-40 overflow-hidden">
              {plants.map((p) => (
                <Menu.Item key={p.id}>
                  {({ active }) => (
                    <button
                      onClick={() => handlePlantChange(p)}
                      className={cn(
                        'w-full text-left px-4 py-2.5 text-sm transition-colors',
                        active ? 'bg-neutral-50 text-neutral-900' : 'text-neutral-700',
                        plant?.id === p.id && 'font-medium text-primary-800'
                      )}
                    >
                      <span className="block font-medium">{p.name}</span>
                      <span className="block text-xs text-neutral-400">{p.code}</span>
                    </button>
                  )}
                </Menu.Item>
              ))}
            </Menu.Items>
          </Transition>
        </Menu>
      )}

      <div className="flex-1" />

      {/* Notifications */}
      <button className="relative p-2 rounded-lg text-neutral-500 hover:text-neutral-700 hover:bg-neutral-100 transition-colors">
        <BellIcon className="h-5 w-5" />
        <span className="absolute top-1 right-1 h-4 w-4 bg-accent-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center">
          3
        </span>
      </button>

      {/* User menu */}
      <Menu as="div" className="relative">
        <Menu.Button className="flex items-center gap-2.5 px-3 py-1.5 rounded-lg hover:bg-neutral-50 transition-colors">
          <div className="h-8 w-8 rounded-full bg-primary-800 flex items-center justify-center">
            <span className="text-white text-xs font-semibold">
              {user?.first_name?.[0] ?? user?.username?.[0]?.toUpperCase() ?? 'U'}
            </span>
          </div>
          <div className="text-left hidden sm:block">
            <p className="text-sm font-medium text-neutral-900 leading-tight">
              {user?.full_name ?? user?.username}
            </p>
            <p className="text-xs text-neutral-500 leading-tight">{user?.email}</p>
          </div>
          <ChevronDownIcon className="h-4 w-4 text-neutral-400 hidden sm:block" />
        </Menu.Button>
        <Transition
          as={Fragment}
          enter="transition ease-out duration-100"
          enterFrom="opacity-0 scale-95"
          enterTo="opacity-100 scale-100"
          leave="transition ease-in duration-75"
          leaveFrom="opacity-100 scale-100"
          leaveTo="opacity-0 scale-95"
        >
          <Menu.Items className="absolute right-0 mt-1 w-48 bg-white border border-neutral-100 rounded-xl shadow-dropdown z-40 overflow-hidden">
            <div className="px-4 py-3 border-b border-neutral-100">
              <p className="text-sm font-medium text-neutral-900">{user?.full_name ?? user?.username}</p>
              <p className="text-xs text-neutral-400 truncate">{user?.email}</p>
            </div>
            <Menu.Item>
              {({ active }) => (
                <button
                  className={cn(
                    'w-full text-left px-4 py-2.5 text-sm flex items-center gap-2 transition-colors',
                    active ? 'bg-neutral-50 text-neutral-900' : 'text-neutral-700'
                  )}
                >
                  <UserCircleIcon className="h-4 w-4" />
                  Profile
                </button>
              )}
            </Menu.Item>
            <Menu.Item>
              {({ active }) => (
                <button
                  onClick={handleLogout}
                  className={cn(
                    'w-full text-left px-4 py-2.5 text-sm flex items-center gap-2 transition-colors',
                    active ? 'bg-danger-50 text-danger-700' : 'text-neutral-700'
                  )}
                >
                  <ArrowRightOnRectangleIcon className="h-4 w-4" />
                  Sign Out
                </button>
              )}
            </Menu.Item>
          </Menu.Items>
        </Transition>
      </Menu>
    </header>
  );
}
