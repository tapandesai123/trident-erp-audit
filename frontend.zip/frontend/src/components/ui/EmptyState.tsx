import { InboxIcon } from '@heroicons/react/24/outline';
import { cn } from '@/utils/cn';
import Button from './Button';

interface EmptyStateProps {
  title?: string;
  description?: string;
  icon?: React.ReactNode;
  action?: {
    label: string;
    onClick: () => void;
  };
  className?: string;
}

export default function EmptyState({
  title = 'No data found',
  description = 'There are no records to display yet.',
  icon,
  action,
  className,
}: EmptyStateProps) {
  return (
    <div className={cn('flex flex-col items-center justify-center py-16 text-center', className)}>
      <div className="p-4 bg-neutral-100 rounded-full mb-4">
        {icon ?? <InboxIcon className="h-8 w-8 text-neutral-400" />}
      </div>
      <h3 className="text-sm font-semibold text-neutral-700 mb-1">{title}</h3>
      <p className="text-sm text-neutral-500 max-w-xs">{description}</p>
      {action && (
        <Button variant="primary" size="sm" className="mt-4" onClick={action.onClick}>
          {action.label}
        </Button>
      )}
    </div>
  );
}
