import { cn } from '@/utils/cn';
import Button from './Button';
import { XMarkIcon, FunnelIcon } from '@heroicons/react/24/outline';

interface FilterPanelProps {
  open: boolean;
  onClose: () => void;
  onReset: () => void;
  children: React.ReactNode;
  title?: string;
  activeCount?: number;
}

export default function FilterPanel({
  open,
  onClose,
  onReset,
  children,
  title = 'Filters',
  activeCount = 0,
}: FilterPanelProps) {
  return (
    <>
      {/* Backdrop (mobile) */}
      {open && (
        <div
          className="fixed inset-0 bg-black/20 z-20 lg:hidden"
          onClick={onClose}
        />
      )}

      <aside
        className={cn(
          'shrink-0 bg-white border border-neutral-100 rounded-xl shadow-card overflow-hidden',
          'transition-all duration-200',
          open ? 'w-60' : 'w-0 border-0 shadow-none overflow-hidden',
          'lg:relative lg:z-auto'
        )}
      >
        <div className={cn('w-60', !open && 'hidden')}>
          <div className="flex items-center justify-between px-4 py-3 border-b border-neutral-100">
            <div className="flex items-center gap-2">
              <FunnelIcon className="h-4 w-4 text-neutral-500" />
              <span className="text-sm font-semibold text-neutral-700">{title}</span>
              {activeCount > 0 && (
                <span className="h-4 w-4 bg-primary-700 text-white text-[10px] font-bold rounded-full flex items-center justify-center">
                  {activeCount}
                </span>
              )}
            </div>
            <button
              onClick={onClose}
              className="p-1 rounded hover:bg-neutral-100 text-neutral-400 hover:text-neutral-600 transition-colors"
            >
              <XMarkIcon className="h-4 w-4" />
            </button>
          </div>

          <div className="p-4 space-y-4 overflow-y-auto max-h-[calc(100vh-200px)]">
            {children}
          </div>

          {activeCount > 0 && (
            <div className="px-4 py-3 border-t border-neutral-100">
              <Button variant="ghost" size="sm" className="w-full text-danger-500 hover:bg-danger-50" onClick={onReset}>
                Clear all filters
              </Button>
            </div>
          )}
        </div>
      </aside>
    </>
  );
}

interface FilterSectionProps {
  label: string;
  children: React.ReactNode;
}

export function FilterSection({ label, children }: FilterSectionProps) {
  return (
    <div>
      <p className="text-xs font-semibold text-neutral-400 uppercase tracking-wide mb-2">{label}</p>
      {children}
    </div>
  );
}

interface FilterRadioGroupProps {
  options: { value: string; label: string }[];
  value: string;
  onChange: (v: string) => void;
  allowAll?: boolean;
  allLabel?: string;
}

export function FilterRadioGroup({ options, value, onChange, allowAll = true, allLabel = 'All' }: FilterRadioGroupProps) {
  return (
    <div className="space-y-1.5">
      {allowAll && (
        <label className="flex items-center gap-2 cursor-pointer">
          <input
            type="radio"
            checked={value === ''}
            onChange={() => onChange('')}
            className="text-primary-700 focus:ring-primary-500"
          />
          <span className="text-sm text-neutral-600">{allLabel}</span>
        </label>
      )}
      {options.map(opt => (
        <label key={opt.value} className="flex items-center gap-2 cursor-pointer">
          <input
            type="radio"
            checked={value === opt.value}
            onChange={() => onChange(opt.value)}
            className="text-primary-700 focus:ring-primary-500"
          />
          <span className="text-sm text-neutral-600">{opt.label}</span>
        </label>
      ))}
    </div>
  );
}
