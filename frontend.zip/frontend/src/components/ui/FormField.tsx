import { cn } from '@/utils/cn';

interface FormFieldProps {
  label?: string;
  error?: string;
  helperText?: string;
  required?: boolean;
  children: React.ReactNode;
  className?: string;
  id?: string;
}

export default function FormField({
  label,
  error,
  helperText,
  required,
  children,
  className,
  id,
}: FormFieldProps) {
  return (
    <div className={cn('w-full', className)}>
      {label && (
        <label htmlFor={id} className="form-label">
          {label}
          {required && <span className="text-danger-500 ml-0.5">*</span>}
        </label>
      )}
      {children}
      {error && <p className="form-error">{error}</p>}
      {!error && helperText && <p className="text-xs text-neutral-500 mt-1">{helperText}</p>}
    </div>
  );
}
