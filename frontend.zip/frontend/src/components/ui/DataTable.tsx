import {
  useReactTable,
  getCoreRowModel,
  getSortedRowModel,
  flexRender,
  type ColumnDef,
  type SortingState,
  type RowSelectionState,
} from '@tanstack/react-table';
import { useState } from 'react';
import {
  ChevronUpIcon,
  ChevronDownIcon,
  ChevronLeftIcon,
  ChevronRightIcon,
  MagnifyingGlassIcon,
} from '@heroicons/react/20/solid';
import { cn } from '@/utils/cn';
import LoadingSpinner from './LoadingSpinner';
import EmptyState from './EmptyState';
import { DEFAULT_PAGE_SIZE, PAGE_SIZE_OPTIONS } from '@/utils/constants';

export type { ColumnDef };

interface DataTableProps<T> {
  data: T[];
  columns: ColumnDef<T, unknown>[];
  // Pagination (server-side)
  totalCount?: number;
  page?: number;
  pageSize?: number;
  onPageChange?: (page: number) => void;
  onPageSizeChange?: (size: number) => void;
  // Search
  searchValue?: string;
  onSearchChange?: (value: string) => void;
  searchPlaceholder?: string;
  // State
  loading?: boolean;
  // Row interaction
  onRowClick?: (row: T) => void;
  getRowId?: (row: T) => string;
  // Toolbar extras
  toolbarLeft?: React.ReactNode;
  toolbarRight?: React.ReactNode;
  // Empty state
  emptyTitle?: string;
  emptyDescription?: string;
  emptyAction?: { label: string; onClick: () => void };
  // Row selection
  enableRowSelection?: boolean;
  onSelectionChange?: (rows: T[]) => void;
  className?: string;
}

export default function DataTable<T>({
  data,
  columns,
  totalCount,
  page = 1,
  pageSize = DEFAULT_PAGE_SIZE,
  onPageChange,
  onPageSizeChange,
  searchValue = '',
  onSearchChange,
  searchPlaceholder = 'Search...',
  loading = false,
  onRowClick,
  toolbarLeft,
  toolbarRight,
  emptyTitle,
  emptyDescription,
  emptyAction,
  enableRowSelection = false,
  onSelectionChange,
  className,
}: DataTableProps<T>) {
  const [sorting, setSorting] = useState<SortingState>([]);
  const [rowSelection, setRowSelection] = useState<RowSelectionState>({});

  const table = useReactTable({
    data,
    columns,
    state: { sorting, rowSelection },
    onSortingChange: setSorting,
    onRowSelectionChange: (updater) => {
      const next = typeof updater === 'function' ? updater(rowSelection) : updater;
      setRowSelection(next);
      if (onSelectionChange) {
        const selectedRows = Object.keys(next)
          .filter((k) => next[k])
          .map((k) => data[parseInt(k)]);
        onSelectionChange(selectedRows.filter(Boolean));
      }
    },
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    enableRowSelection,
    manualPagination: true,
    pageCount: totalCount ? Math.ceil(totalCount / pageSize) : undefined,
  });

  const totalPages = totalCount ? Math.ceil(totalCount / pageSize) : 0;

  return (
    <div className={cn('bg-white rounded-xl border border-neutral-100 shadow-card overflow-hidden', className)}>
      {/* Toolbar */}
      {(onSearchChange || toolbarLeft || toolbarRight) && (
        <div className="px-4 py-3 border-b border-neutral-100 flex items-center gap-3 flex-wrap">
          {toolbarLeft}
          {onSearchChange && (
            <div className="relative flex-1 min-w-[200px] max-w-xs">
              <MagnifyingGlassIcon className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-neutral-400 pointer-events-none" />
              <input
                type="search"
                value={searchValue}
                onChange={(e) => onSearchChange(e.target.value)}
                placeholder={searchPlaceholder}
                className="form-input pl-9 py-1.5 text-sm h-9"
              />
            </div>
          )}
          {toolbarRight && <div className="ml-auto flex items-center gap-2">{toolbarRight}</div>}
        </div>
      )}

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="min-w-full">
          <thead className="bg-neutral-50 border-b border-neutral-100">
            {table.getHeaderGroups().map((hg) => (
              <tr key={hg.id}>
                {hg.headers.map((header) => {
                  const canSort = header.column.getCanSort();
                  const sortDir = header.column.getIsSorted();
                  return (
                    <th
                      key={header.id}
                      className={cn(
                        'table-th select-none',
                        canSort && 'cursor-pointer hover:bg-neutral-100 transition-colors'
                      )}
                      onClick={canSort ? header.column.getToggleSortingHandler() : undefined}
                      style={{ width: header.getSize() !== 150 ? header.getSize() : undefined }}
                    >
                      <span className="inline-flex items-center gap-1">
                        {header.isPlaceholder
                          ? null
                          : flexRender(header.column.columnDef.header, header.getContext())}
                        {canSort && (
                          <span className="text-neutral-400">
                            {sortDir === 'asc' ? (
                              <ChevronUpIcon className="h-3.5 w-3.5 text-primary-600" />
                            ) : sortDir === 'desc' ? (
                              <ChevronDownIcon className="h-3.5 w-3.5 text-primary-600" />
                            ) : (
                              <span className="h-3.5 w-3.5 opacity-0 group-hover:opacity-100 inline-block">↕</span>
                            )}
                          </span>
                        )}
                      </span>
                    </th>
                  );
                })}
              </tr>
            ))}
          </thead>
          <tbody className="divide-y divide-neutral-50">
            {loading ? (
              // Loading skeleton
              Array.from({ length: 5 }).map((_, i) => (
                <tr key={i} className="animate-pulse">
                  {columns.map((_, j) => (
                    <td key={j} className="table-td">
                      <div className="h-4 bg-neutral-100 rounded w-3/4" />
                    </td>
                  ))}
                </tr>
              ))
            ) : table.getRowModel().rows.length === 0 ? (
              <tr>
                <td colSpan={columns.length}>
                  <EmptyState
                    title={emptyTitle}
                    description={emptyDescription}
                    action={emptyAction}
                  />
                </td>
              </tr>
            ) : (
              table.getRowModel().rows.map((row) => (
                <tr
                  key={row.id}
                  className={cn('table-row', onRowClick && 'cursor-pointer')}
                  onClick={() => onRowClick?.(row.original)}
                >
                  {row.getVisibleCells().map((cell) => (
                    <td key={cell.id} className="table-td">
                      {flexRender(cell.column.columnDef.cell, cell.getContext())}
                    </td>
                  ))}
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      {(onPageChange || totalCount !== undefined) && (
        <div className="px-4 py-3 border-t border-neutral-100 flex items-center justify-between gap-4 flex-wrap">
          <div className="flex items-center gap-2">
            <span className="text-xs text-neutral-500">Rows per page</span>
            <select
              value={pageSize}
              onChange={(e) => onPageSizeChange?.(Number(e.target.value))}
              className="text-xs border border-neutral-200 rounded px-2 py-1 text-neutral-700 bg-white"
            >
              {PAGE_SIZE_OPTIONS.map((s) => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>
          </div>

          {totalCount !== undefined && (
            <span className="text-xs text-neutral-500">
              {Math.min((page - 1) * pageSize + 1, totalCount)}–{Math.min(page * pageSize, totalCount)} of {totalCount}
            </span>
          )}

          <div className="flex items-center gap-1">
            <button
              onClick={() => onPageChange?.(page - 1)}
              disabled={page <= 1 || loading}
              className="p-1 rounded hover:bg-neutral-100 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
            >
              <ChevronLeftIcon className="h-4 w-4 text-neutral-600" />
            </button>
            {/* Page number pills */}
            {Array.from({ length: Math.min(totalPages, 5) }, (_, i) => {
              const pg = i + 1;
              return (
                <button
                  key={pg}
                  onClick={() => onPageChange?.(pg)}
                  className={cn(
                    'px-2.5 py-0.5 rounded text-xs font-medium transition-colors',
                    page === pg
                      ? 'bg-primary-800 text-white'
                      : 'text-neutral-600 hover:bg-neutral-100'
                  )}
                >
                  {pg}
                </button>
              );
            })}
            {totalPages > 5 && page > 5 && (
              <button
                onClick={() => onPageChange?.(page)}
                className="px-2.5 py-0.5 rounded text-xs font-medium bg-primary-800 text-white"
              >
                {page}
              </button>
            )}
            <button
              onClick={() => onPageChange?.(page + 1)}
              disabled={page >= totalPages || loading}
              className="p-1 rounded hover:bg-neutral-100 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
            >
              <ChevronRightIcon className="h-4 w-4 text-neutral-600" />
            </button>
          </div>
          {loading && <LoadingSpinner size="sm" className="text-primary-600" />}
        </div>
      )}
    </div>
  );
}
