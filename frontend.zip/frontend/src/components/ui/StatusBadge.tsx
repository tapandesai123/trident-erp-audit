import Badge from './Badge';
import type { BadgeVariant } from '@/utils/status';
import { getStatusVariant, getStatusLabel } from '@/utils/status';

interface StatusBadgeProps {
  status: string;
  customMap?: Record<string, BadgeVariant>;
  className?: string;
}

export default function StatusBadge({ status, customMap, className }: StatusBadgeProps) {
  const variant = customMap?.[status] ?? getStatusVariant(status);
  const label = getStatusLabel(status);

  return (
    <Badge variant={variant} dot className={className}>
      {label}
    </Badge>
  );
}
