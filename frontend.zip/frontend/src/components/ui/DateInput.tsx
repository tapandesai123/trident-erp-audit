import { InputHTMLAttributes, forwardRef } from 'react';
import { cn } from '@/utils/cn';

interface DateInputProps extends Omit<InputHTMLAttributes<HTMLInputElement>, 'type'> {
  label?: string;
  error?: string;
  helperText?: string;
  required?: boolean;
}

const DateInput = forwardRef<HTMLInputElement, DateInputProps>(
  ({ label, error, helperText, className, id, required, ...props }, ref) => {
    const fieldId = id ?? label?.toLowerCase().replace(/\s+/g, '-');
    return (
      <div className="w-full">
        {label && (
          <label htmlFor={fieldId} className="form-label">
            {label}
            {required && <span className="text-danger-500 ml-0.5">*</span>}
          </label>
        )}
        <input
          ref={ref}
          id={fieldId}
          type="date"
          className={cn(
            'form-input',
            error && 'border-danger-500 focus:border-danger-500 focus:ring-danger-500',
            className
          )}
          {...props}
        />
        {error && <p className="form-error">{error}</p>}
        {!error && helperText && <p className="text-xs text-neutral-500 mt-1">{helperText}</p>}
      </div>
    );
  }
);
DateInput.displayName = 'DateInput';
export default DateInput;
