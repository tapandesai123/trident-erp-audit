import { cn } from '@/utils/cn';

interface CardProps {
  title?: string;
  value?: string | number;
  icon?: React.ReactNode;
  trend?: { value: number; label?: string };
  description?: string;
  children?: React.ReactNode;
  className?: string;
  onClick?: () => void;
}

export default function Card({
  title,
  value,
  icon,
  trend,
  description,
  children,
  className,
  onClick,
}: CardProps) {
  const isClickable = !!onClick;

  return (
    <div
      className={cn(
        'card',
        isClickable && 'cursor-pointer hover:shadow-md transition-shadow duration-150',
        className
      )}
      onClick={onClick}
    >
      {/* Summary card layout */}
      {(title || value !== undefined) && !children && (
        <div className="flex items-start justify-between">
          <div className="flex-1 min-w-0">
            {title && <p className="text-xs font-medium text-neutral-500 uppercase tracking-wide">{title}</p>}
            {value !== undefined && (
              <p className="mt-1 text-2xl font-bold text-neutral-900">{value}</p>
            )}
            {description && <p className="mt-0.5 text-xs text-neutral-500">{description}</p>}
            {trend && (
              <div className="mt-2 flex items-center gap-1">
                <span
                  className={cn(
                    'text-xs font-medium',
                    trend.value >= 0 ? 'text-success-700' : 'text-danger-500'
                  )}
                >
                  {trend.value >= 0 ? '↑' : '↓'} {Math.abs(trend.value)}%
                </span>
                {trend.label && <span className="text-xs text-neutral-400">{trend.label}</span>}
              </div>
            )}
          </div>
          {icon && (
            <div className="ml-4 p-2.5 bg-primary-50 rounded-lg text-primary-700 shrink-0">
              {icon}
            </div>
          )}
        </div>
      )}
      {/* Custom content */}
      {children}
    </div>
  );
}
