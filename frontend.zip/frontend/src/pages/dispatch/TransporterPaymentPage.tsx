import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { createColumnHelper } from '@tanstack/react-table';
import { CurrencyRupeeIcon, CheckCircleIcon } from '@heroicons/react/24/outline';

import { salesService, DispatchListItem } from '@/services/sales';
import DataTable from '@/components/ui/DataTable';
import Badge from '@/components/ui/Badge';
import Button from '@/components/ui/Button';
import PageHeader from '@/components/ui/PageHeader';
import Modal from '@/components/ui/Modal';
import FormField from '@/components/ui/FormField';
import Input from '@/components/ui/Input';
import Textarea from '@/components/ui/Textarea';
import { usePagination } from '@/hooks/usePagination';
import { useDebounce } from '@/hooks/useDebounce';
import { formatDate, formatCurrency } from '@/utils/format';
import { cn } from '@/utils/cn';

const col = createColumnHelper<DispatchListItem>();

function PaymentModal({ dispatch, onClose }: { dispatch: DispatchListItem; onClose: () => void }) {
  const qc = useQueryClient();
  const [form, setForm] = useState({ amount: dispatch.freight_amount ?? '', payment_ref: '', remarks: '' });
  const mut = useMutation({
    mutationFn: () => salesService.recordFreightPayment(dispatch.id, form),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['dispatches-freight'] }); onClose(); },
  });
  return (
    <Modal open onClose={onClose} title={`Record Payment — ${dispatch.dispatch_number}`} size="sm">
      <div className="space-y-4 p-4">
        <div className="text-xs text-neutral-500 space-y-1">
          <p>Transporter: <strong>{dispatch.transporter_name ?? '—'}</strong></p>
          <p>Vehicle: <strong>{dispatch.vehicle_number ?? '—'}</strong></p>
          <p>Freight Amount: <strong>{dispatch.freight_amount ? formatCurrency(dispatch.freight_amount) : '—'}</strong></p>
        </div>
        <FormField label="Amount Paid (₹)" required>
          <Input type="number" value={form.amount} onChange={e => setForm(f => ({ ...f, amount: e.target.value }))} />
        </FormField>
        <FormField label="Payment Reference">
          <Input value={form.payment_ref} onChange={e => setForm(f => ({ ...f, payment_ref: e.target.value }))} placeholder="Bank ref, cheque #…" />
        </FormField>
        <FormField label="Remarks">
          <Textarea value={form.remarks} onChange={e => setForm(f => ({ ...f, remarks: e.target.value }))} rows={2} />
        </FormField>
        <div className="flex gap-2 justify-end">
          <Button variant="ghost" onClick={onClose}>Cancel</Button>
          <Button onClick={() => mut.mutate()} loading={mut.isPending} disabled={!form.amount}>Mark Paid</Button>
        </div>
      </div>
    </Modal>
  );
}

export default function TransporterPaymentPage() {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const { page, pageSize, setPage, setPageSize } = usePagination();
  const [search, setSearch] = useState('');
  const dSearch = useDebounce(search, 300);
  const [paymentDispatch, setPaymentDispatch] = useState<DispatchListItem | null>(null);
  const [tab, setTab] = useState<'UNPAID' | 'PAID' | 'ALL'>('UNPAID');

  const { data, isLoading } = useQuery({
    queryKey: ['dispatches-freight', page, pageSize, dSearch, tab],
    queryFn: () => salesService.listDispatches({
      page, page_size: pageSize,
      search: dSearch || undefined,
      freight_paid: tab === 'ALL' ? undefined : tab === 'PAID' ? 'true' : 'false',
      has_freight: 'true',
    }),
  });

  const COLUMNS = [
    col.accessor('dispatch_number', {
      header: 'Dispatch #',
      cell: i => <span className="font-mono text-xs font-semibold text-primary-800">{i.getValue()}</span>,
      size: 140,
    }),
    col.accessor('dispatch_date', { header: 'Date', cell: i => formatDate(i.getValue()), size: 100 }),
    col.accessor('customer_name', { header: 'Customer', size: 160 }),
    col.accessor('vehicle_number', {
      header: 'Vehicle',
      cell: i => <span className="font-mono text-xs">{i.getValue() ?? '—'}</span>,
      size: 120,
    }),
    col.accessor('transporter_name', {
      header: 'Transporter',
      cell: i => i.getValue() ?? <span className="text-neutral-300">—</span>,
      size: 150,
    }),
    col.accessor('status', {
      header: 'Dispatch Status',
      cell: i => <Badge variant={i.getValue() === 'DELIVERED' ? 'success' : 'info'} size="sm">{i.getValue()}</Badge>,
      size: 130,
    }),
    col.accessor('freight_amount', {
      header: 'Freight Amount',
      cell: i => <span className="font-semibold">{i.getValue() ? formatCurrency(i.getValue()!) : '—'}</span>,
      size: 130,
    }),
    col.accessor('freight_paid', {
      header: 'Payment',
      cell: i => i.getValue()
        ? <div className="flex items-center gap-1 text-success-700"><CheckCircleIcon className="h-4 w-4" /><span className="text-xs font-medium">Paid</span></div>
        : <Badge variant="warning" size="sm">Pending</Badge>,
      size: 90,
    }),
    col.display({
      id: 'action',
      size: 100,
      cell: i => !i.row.original.freight_paid ? (
        <Button
          size="sm"
          variant="secondary"
          onClick={e => { e.stopPropagation(); setPaymentDispatch(i.row.original); }}
        >
          <CurrencyRupeeIcon className="h-3.5 w-3.5 mr-1" /> Pay
        </Button>
      ) : null,
    }),
  ];

  const tabs = [
    { key: 'UNPAID', label: 'Unpaid' },
    { key: 'PAID', label: 'Paid' },
    { key: 'ALL', label: 'All' },
  ];

  return (
    <div className="space-y-4">
      <PageHeader title="Transporter Payments" subtitle="Track and record freight payments to transporters" />

      {/* Tab bar */}
      <div className="border-b border-neutral-200">
        <nav className="-mb-px flex gap-0">
          {tabs.map(t => (
            <button
              key={t.key}
              onClick={() => { setTab(t.key as any); setPage(1); }}
              className={cn(
                'px-4 py-3 text-sm font-medium border-b-2 whitespace-nowrap transition-colors',
                tab === t.key
                  ? 'border-primary-700 text-primary-800'
                  : 'border-transparent text-neutral-500 hover:text-neutral-700 hover:border-neutral-300'
              )}
            >
              {t.label}
            </button>
          ))}
        </nav>
      </div>

      <DataTable
        data={data?.results ?? []}
        columns={COLUMNS}
        loading={isLoading}
        totalCount={data?.count}
        page={page} pageSize={pageSize}
        onPageChange={setPage} onPageSizeChange={setPageSize}
        searchValue={search} onSearchChange={setSearch}
        searchPlaceholder="Search dispatch, transporter, vehicle…"
        onRowClick={row => navigate(`/dispatch/orders/${row.id}`)}
        emptyTitle={tab === 'UNPAID' ? 'No unpaid freight found' : 'No records found'}
        emptyDescription={tab === 'UNPAID' ? 'All transporter payments are up to date.' : undefined}
      />

      {paymentDispatch && (
        <PaymentModal dispatch={paymentDispatch} onClose={() => setPaymentDispatch(null)} />
      )}
    </div>
  );
}
