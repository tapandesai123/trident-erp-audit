import { useState, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  DocumentArrowUpIcon, CheckCircleIcon, PhotoIcon,
} from '@heroicons/react/24/outline';

import { salesService } from '@/services/sales';
import PageHeader from '@/components/ui/PageHeader';
import Card from '@/components/ui/Card';
import Button from '@/components/ui/Button';
import Badge from '@/components/ui/Badge';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import { formatDate } from '@/utils/format';
import { cn } from '@/utils/cn';

export default function PODUploadPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const fileRef = useRef<HTMLInputElement>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [file, setFile] = useState<File | null>(null);

  const { data: dispatch, isLoading } = useQuery({
    queryKey: ['dispatch', id],
    queryFn: () => salesService.getDispatch(id!),
    enabled: !!id,
  });

  const uploadMut = useMutation({
    mutationFn: () => salesService.uploadDispatchPOD(id!, file!),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['dispatch', id] });
      setFile(null);
      setPreview(null);
    },
  });

  const handleFile = (f: File) => {
    setFile(f);
    if (f.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = e => setPreview(e.target?.result as string);
      reader.readAsDataURL(f);
    } else {
      setPreview(null);
    }
  };

  if (isLoading) return <div className="flex items-center justify-center h-64"><LoadingSpinner size="xl" /></div>;
  if (!dispatch) return null;

  return (
    <div className="space-y-4">
      <PageHeader
        title={`POD — ${dispatch.dispatch_number}`}
        subtitle="Upload Proof of Delivery"
        breadcrumbs={[{ label: 'Dispatch' }, { label: 'Orders', href: '/dispatch/orders' },
          { label: dispatch.dispatch_number, href: `/dispatch/orders/${id}` }, { label: 'POD' }]}
      />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Dispatch summary */}
        <Card>
          <div className="p-4 space-y-3">
            <h3 className="text-sm font-semibold text-neutral-700">Dispatch Details</h3>
            <div className="space-y-2 text-sm">
              {[
                { label: 'Dispatch #', value: dispatch.dispatch_number },
                { label: 'Date', value: formatDate(dispatch.dispatch_date) },
                { label: 'Vehicle', value: dispatch.vehicle_number ?? '—' },
                { label: 'Driver', value: dispatch.driver_name ?? '—' },
                { label: 'Transporter', value: dispatch.transporter_name ?? '—' },
                { label: 'LR Number', value: dispatch.lr_number ?? '—' },
                { label: 'Status', value: <Badge variant="info" size="sm">{dispatch.status}</Badge> },
              ].map(({ label, value }) => (
                <div key={label} className="flex justify-between items-center gap-2">
                  <span className="text-neutral-500">{label}</span>
                  <span className="text-neutral-800 text-sm">{value}</span>
                </div>
              ))}
            </div>

            <div className="border-t border-neutral-100 pt-3">
              <p className="text-xs font-semibold text-neutral-500 mb-2">Lines Delivered</p>
              <div className="space-y-1">
                {dispatch.lines.map((l, i) => (
                  <div key={i} className="flex justify-between text-xs text-neutral-600">
                    <span className="truncate">{l.item_name}</span>
                    <span className="font-semibold ml-2 shrink-0">{l.dispatch_qty}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </Card>

        {/* POD upload */}
        <Card>
          <div className="p-4 space-y-4">
            <h3 className="text-sm font-semibold text-neutral-700">Proof of Delivery</h3>

            {dispatch.pod_url ? (
              <div className="space-y-3">
                <div className="flex items-center gap-2 text-success-700">
                  <CheckCircleIcon className="h-5 w-5" />
                  <span className="text-sm font-medium">POD already uploaded</span>
                </div>
                {dispatch.pod_url.match(/\.(jpg|jpeg|png|gif|webp)$/i) ? (
                  <img src={dispatch.pod_url} alt="POD" className="w-full rounded-lg border border-neutral-200 max-h-64 object-contain" />
                ) : (
                  <a href={dispatch.pod_url} target="_blank" rel="noopener noreferrer"
                    className="flex items-center gap-2 text-primary-600 hover:underline text-sm">
                    <DocumentArrowUpIcon className="h-4 w-4" /> View Document
                  </a>
                )}
                <Button variant="secondary" size="sm" onClick={() => fileRef.current?.click()}>
                  Replace POD
                </Button>
              </div>
            ) : (
              <>
                <div
                  onClick={() => fileRef.current?.click()}
                  onDragOver={e => e.preventDefault()}
                  onDrop={e => { e.preventDefault(); const f = e.dataTransfer.files[0]; if (f) handleFile(f); }}
                  className={cn(
                    'border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-colors',
                    file ? 'border-primary-400 bg-primary-50' : 'border-neutral-200 hover:border-primary-300 hover:bg-neutral-50'
                  )}
                >
                  {preview ? (
                    <img src={preview} alt="Preview" className="max-h-40 mx-auto rounded-lg mb-2" />
                  ) : (
                    <PhotoIcon className="h-10 w-10 mx-auto text-neutral-300 mb-2" />
                  )}
                  <p className="text-sm font-medium text-neutral-700">
                    {file ? file.name : 'Drop POD here or click to browse'}
                  </p>
                  <p className="text-xs text-neutral-400 mt-1">Supports JPG, PNG, PDF</p>
                </div>
                <input
                  ref={fileRef} type="file" className="hidden"
                  accept="image/*,application/pdf"
                  onChange={e => { if (e.target.files?.[0]) handleFile(e.target.files[0]); }}
                />
              </>
            )}

            {file && !dispatch.pod_url && (
              <div className="flex gap-2 justify-end">
                <Button variant="ghost" onClick={() => { setFile(null); setPreview(null); }}>Clear</Button>
                <Button onClick={() => uploadMut.mutate()} loading={uploadMut.isPending}>
                  <DocumentArrowUpIcon className="h-4 w-4 mr-1" /> Upload POD
                </Button>
              </div>
            )}
          </div>
        </Card>
      </div>
    </div>
  );
}
