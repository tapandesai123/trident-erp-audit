import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { QrCodeIcon, CheckCircleIcon, PencilIcon } from '@heroicons/react/24/outline';

import { salesService, DispatchStatus } from '@/services/sales';
import PageHeader from '@/components/ui/PageHeader';
import Card from '@/components/ui/Card';
import Button from '@/components/ui/Button';
import Badge from '@/components/ui/Badge';
import Modal from '@/components/ui/Modal';
import FormField from '@/components/ui/FormField';
import Input from '@/components/ui/Input';
import Textarea from '@/components/ui/Textarea';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import { formatDate } from '@/utils/format';
import { cn } from '@/utils/cn';

const STATUS_VARIANT: Record<DispatchStatus, string> = {
  PLANNED: 'neutral', LOADED: 'warning', IN_TRANSIT: 'info', DELIVERED: 'success', CANCELLED: 'danger',
};

function VehicleModal({ dispatch, onClose }: { dispatch: ReturnType<typeof salesService.getDispatch> extends Promise<infer T> ? T : never; onClose: () => void }) {
  const qc = useQueryClient();
  const [form, setForm] = useState({
    vehicle_number: (dispatch as any).vehicle_number ?? '',
    driver_name: (dispatch as any).driver_name ?? '',
    driver_phone: (dispatch as any).driver_phone ?? '',
    transporter: (dispatch as any).transporter ?? '',
    lr_number: (dispatch as any).lr_number ?? '',
    loading_instructions: (dispatch as any).loading_instructions ?? '',
    freight_amount: (dispatch as any).freight_amount ?? '',
  });
  const mut = useMutation({
    mutationFn: () => salesService.updateDispatch((dispatch as any).id, form),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['dispatch', (dispatch as any).id] }); onClose(); },
  });
  const f = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
    setForm(prev => ({ ...prev, [k]: e.target.value }));

  return (
    <Modal open onClose={onClose} title="Vehicle & Transport Details" size="md">
      <div className="p-4 space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <FormField label="Vehicle Number" required>
            <Input value={form.vehicle_number} onChange={f('vehicle_number')} placeholder="MH12AB1234" />
          </FormField>
          <FormField label="LR Number">
            <Input value={form.lr_number} onChange={f('lr_number')} placeholder="Lorry receipt #" />
          </FormField>
          <FormField label="Driver Name">
            <Input value={form.driver_name} onChange={f('driver_name')} />
          </FormField>
          <FormField label="Driver Phone">
            <Input value={form.driver_phone} onChange={f('driver_phone')} type="tel" />
          </FormField>
          <FormField label="Transporter" className="col-span-2">
            <Input value={form.transporter} onChange={f('transporter')} placeholder="Transporter name / ID" />
          </FormField>
          <FormField label="Freight Amount (₹)">
            <Input type="number" value={form.freight_amount} onChange={f('freight_amount')} />
          </FormField>
        </div>
        <FormField label="Loading Instructions">
          <Textarea value={form.loading_instructions} onChange={f('loading_instructions')} rows={3} placeholder="Special handling, stacking notes…" />
        </FormField>
        <div className="flex gap-2 justify-end pt-2">
          <Button variant="ghost" onClick={onClose}>Cancel</Button>
          <Button onClick={() => mut.mutate()} loading={mut.isPending}>Save</Button>
        </div>
      </div>
    </Modal>
  );
}

function GateOutModal({ dispatchId, vehicleNumber, onClose }: { dispatchId: string; vehicleNumber?: string; onClose: () => void }) {
  const qc = useQueryClient();
  const [form, setForm] = useState({ vehicle_number: vehicleNumber ?? '', remarks: '' });
  const mut = useMutation({
    mutationFn: () => salesService.scanGateOut(dispatchId, form),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['dispatch', dispatchId] }); onClose(); },
  });
  return (
    <Modal open onClose={onClose} title="Gate Out Scanning" size="sm">
      <div className="p-4 space-y-4">
        <p className="text-xs text-neutral-500">Scan or confirm the vehicle number at gate out to mark this dispatch as IN_TRANSIT.</p>
        <FormField label="Vehicle Number" required>
          <Input value={form.vehicle_number} onChange={e => setForm(f => ({ ...f, vehicle_number: e.target.value }))}
            placeholder="Scan or type vehicle number…" className="font-mono" />
        </FormField>
        <FormField label="Remarks">
          <Input value={form.remarks} onChange={e => setForm(f => ({ ...f, remarks: e.target.value }))} />
        </FormField>
        <div className="flex gap-2 justify-end">
          <Button variant="ghost" onClick={onClose}>Cancel</Button>
          <Button onClick={() => mut.mutate()} loading={mut.isPending} disabled={!form.vehicle_number.trim()}>
            <QrCodeIcon className="h-4 w-4 mr-1" /> Confirm Gate Out
          </Button>
        </div>
      </div>
    </Modal>
  );
}

export default function DispatchOrderPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [modal, setModal] = useState<'vehicle' | 'gateout' | null>(null);

  const { data: dispatch, isLoading } = useQuery({
    queryKey: ['dispatch', id],
    queryFn: () => salesService.getDispatch(id!),
    enabled: !!id,
  });

  if (isLoading) return <div className="flex items-center justify-center h-64"><LoadingSpinner size="xl" /></div>;
  if (!dispatch) return null;

  const canGateOut = dispatch.status === 'PLANNED' || dispatch.status === 'LOADED';
  const canUploadPOD = dispatch.status === 'IN_TRANSIT' || dispatch.status === 'DELIVERED';

  return (
    <div className="space-y-4">
      <PageHeader
        title={`Dispatch — ${dispatch.dispatch_number}`}
        subtitle={`${dispatch.lines[0]?.customer_name ?? ''}`}
        breadcrumbs={[{ label: 'Dispatch' }, { label: 'Orders', href: '/dispatch/orders' }, { label: dispatch.dispatch_number }]}
        actions={
          <div className="flex gap-2">
            <Button variant="ghost" size="sm" onClick={() => setModal('vehicle')}>
              <PencilIcon className="h-4 w-4 mr-1" /> Vehicle Details
            </Button>
            {canGateOut && (
              <Button size="sm" onClick={() => setModal('gateout')}>
                <QrCodeIcon className="h-4 w-4 mr-1" /> Gate Out
              </Button>
            )}
            {canUploadPOD && (
              <Button variant="secondary" size="sm" onClick={() => navigate(`/dispatch/pod/${id}`)}>
                Upload POD
              </Button>
            )}
          </div>
        }
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Info */}
        <Card>
          <div className="p-4 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-neutral-700">Dispatch Details</h3>
              <Badge variant={STATUS_VARIANT[dispatch.status] as any}>{dispatch.status}</Badge>
            </div>
            <div className="space-y-2 text-sm border-t border-neutral-100 pt-3">
              {[
                { label: 'Dispatch Date', value: formatDate(dispatch.dispatch_date) },
                { label: 'Vehicle', value: dispatch.vehicle_number ?? '—' },
                { label: 'Driver', value: dispatch.driver_name ?? '—' },
                { label: 'Driver Phone', value: dispatch.driver_phone ?? '—' },
                { label: 'Transporter', value: dispatch.transporter_name ?? '—' },
                { label: 'LR Number', value: dispatch.lr_number ?? '—' },
                { label: 'Gate Out', value: dispatch.gate_out_time ? formatDate(dispatch.gate_out_time) : '—' },
                { label: 'Gate Out By', value: dispatch.gate_out_scanned_by ?? '—' },
              ].map(({ label, value }) => (
                <div key={label} className="flex justify-between items-start gap-2">
                  <span className="text-neutral-500 shrink-0">{label}</span>
                  <span className="text-neutral-800 text-right text-xs">{value}</span>
                </div>
              ))}
            </div>

            {dispatch.loading_instructions && (
              <div className="border-t border-neutral-100 pt-3">
                <p className="text-xs font-semibold text-neutral-500 mb-1">Loading Instructions</p>
                <p className="text-xs text-neutral-600 whitespace-pre-wrap">{dispatch.loading_instructions}</p>
              </div>
            )}
          </div>
        </Card>

        {/* Lines */}
        <Card className="lg:col-span-2">
          <div className="p-4">
            <h3 className="text-sm font-semibold text-neutral-700 mb-3">Dispatch Lines</h3>
            <table className="w-full text-sm">
              <thead>
                <tr className="text-xs text-neutral-500 border-b border-neutral-100">
                  <th className="py-2 pr-3 text-left font-medium">SO</th>
                  <th className="py-2 pr-3 text-left font-medium">Item</th>
                  <th className="py-2 pr-3 text-right font-medium">Dispatch Qty</th>
                  <th className="py-2 text-left font-medium">Lot</th>
                </tr>
              </thead>
              <tbody>
                {dispatch.lines.map((l, i) => (
                  <tr key={i} className="border-b border-neutral-50">
                    <td className="py-2.5 pr-3">
                      <p className="font-mono text-xs font-semibold text-primary-700">{l.so_number}</p>
                      <p className="text-xs text-neutral-400">{l.customer_name}</p>
                    </td>
                    <td className="py-2.5 pr-3 font-medium text-neutral-800">{l.item_name}</td>
                    <td className="py-2.5 pr-3 text-right font-bold text-primary-700">{l.dispatch_qty}</td>
                    <td className="py-2.5 font-mono text-xs text-neutral-500">{l.lot_number ?? '—'}</td>
                  </tr>
                ))}
              </tbody>
            </table>

            {dispatch.pod_url && (
              <div className="mt-4 pt-4 border-t border-neutral-100 flex items-center gap-2 text-sm">
                <CheckCircleIcon className="h-5 w-5 text-success-600" />
                <a href={dispatch.pod_url} target="_blank" rel="noopener noreferrer" className="text-primary-600 hover:underline">
                  View Proof of Delivery
                </a>
              </div>
            )}
          </div>
        </Card>
      </div>

      {modal === 'vehicle' && <VehicleModal dispatch={dispatch as any} onClose={() => setModal(null)} />}
      {modal === 'gateout' && id && (
        <GateOutModal dispatchId={id} vehicleNumber={dispatch.vehicle_number} onClose={() => setModal(null)} />
      )}
    </div>
  );
}
