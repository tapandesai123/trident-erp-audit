import { useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useQuery, useMutation } from '@tanstack/react-query';
import { TruckIcon, PlusCircleIcon } from '@heroicons/react/24/outline';

import { salesService, DispatchPlanLine } from '@/services/sales';
import PageHeader from '@/components/ui/PageHeader';
import Card from '@/components/ui/Card';
import Button from '@/components/ui/Button';
import FormField from '@/components/ui/FormField';
import Input from '@/components/ui/Input';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import { formatCurrency } from '@/utils/format';
import { cn } from '@/utils/cn';

export default function DispatchPlanPage() {
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const preselectedSO = params.get('so') ?? '';
  const [soFilter, setSoFilter] = useState(preselectedSO);
  const [selected, setSelected] = useState<Record<string, string>>({}); // lineId → dispatch_qty

  const { data: lines, isLoading } = useQuery({
    queryKey: ['pending-so-lines', soFilter],
    queryFn: () => salesService.getPendingSOLines({ so_id: soFilter || undefined }),
    staleTime: 30000,
  });

  const createMut = useMutation({
    mutationFn: () => {
      const planLines = (lines ?? [])
        .filter(l => selected[l.so_line_id] && parseFloat(selected[l.so_line_id]) > 0)
        .map(l => ({ ...l, dispatch_qty: selected[l.so_line_id] }));
      return salesService.createDispatch({ lines: planLines });
    },
    onSuccess: (d) => navigate(`/dispatch/orders/${d.id}`),
  });

  const toggleLine = (line: DispatchPlanLine) => {
    setSelected(prev => {
      const next = { ...prev };
      if (next[line.so_line_id]) {
        delete next[line.so_line_id];
      } else {
        next[line.so_line_id] = line.pending_qty;
      }
      return next;
    });
  };

  const updateQty = (lineId: string, qty: string) => {
    setSelected(prev => ({ ...prev, [lineId]: qty }));
  };

  const selectedCount = Object.keys(selected).length;

  return (
    <div className="space-y-4">
      <PageHeader
        title="Plan Dispatch"
        subtitle="Select pending SO lines to include in a dispatch"
        breadcrumbs={[{ label: 'Dispatch' }, { label: 'Plan Dispatch' }]}
      />

      <Card>
        <div className="p-4 flex items-center gap-4">
          <FormField label="Filter by SO" className="flex-1 max-w-xs">
            <Input
              value={soFilter}
              onChange={e => setSoFilter(e.target.value)}
              placeholder="SO number (optional)…"
            />
          </FormField>
          {selectedCount > 0 && (
            <div className="ml-auto flex items-center gap-3">
              <span className="text-sm text-neutral-600">{selectedCount} line{selectedCount !== 1 ? 's' : ''} selected</span>
              <Button onClick={() => createMut.mutate()} loading={createMut.isPending}>
                <TruckIcon className="h-4 w-4 mr-1" /> Create Dispatch Order
              </Button>
            </div>
          )}
        </div>
      </Card>

      {isLoading && <div className="flex items-center justify-center h-48"><LoadingSpinner size="xl" /></div>}

      {!isLoading && !lines?.length && (
        <Card>
          <div className="p-10 text-center text-neutral-400">
            <TruckIcon className="h-10 w-10 mx-auto mb-3 text-neutral-200" />
            <p className="text-sm font-medium">No pending dispatch lines found.</p>
            <p className="text-xs mt-1">All orders are fully dispatched or no orders match the filter.</p>
          </div>
        </Card>
      )}

      {lines && lines.length > 0 && (
        <Card>
          <div className="p-4">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-semibold text-neutral-700">Pending SO Lines</h3>
              <button
                onClick={() => {
                  if (selectedCount === lines.length) {
                    setSelected({});
                  } else {
                    const all: Record<string, string> = {};
                    lines.forEach(l => { all[l.so_line_id] = l.pending_qty; });
                    setSelected(all);
                  }
                }}
                className="text-xs text-primary-600 hover:text-primary-800 font-medium"
              >
                {selectedCount === lines.length ? 'Deselect All' : 'Select All'}
              </button>
            </div>

            <table className="w-full text-sm">
              <thead>
                <tr className="text-xs text-neutral-500 border-b border-neutral-100">
                  <th className="py-2 pr-3 text-left font-medium w-8"></th>
                  <th className="py-2 pr-3 text-left font-medium">SO / Customer</th>
                  <th className="py-2 pr-3 text-left font-medium">Item</th>
                  <th className="py-2 pr-3 text-right font-medium">Pending Qty</th>
                  <th className="py-2 pr-3 text-right font-medium">Dispatch Qty</th>
                  <th className="py-2 pr-3 text-left font-medium">Lot</th>
                </tr>
              </thead>
              <tbody>
                {lines.map(line => {
                  const isSelected = !!selected[line.so_line_id];
                  return (
                    <tr
                      key={line.so_line_id}
                      className={cn(
                        'border-b border-neutral-50 cursor-pointer transition-colors',
                        isSelected ? 'bg-primary-50' : 'hover:bg-neutral-50'
                      )}
                      onClick={() => toggleLine(line)}
                    >
                      <td className="py-2.5 pr-3">
                        <input
                          type="checkbox"
                          checked={isSelected}
                          onChange={() => {}}
                          className="rounded border-neutral-300 text-primary-600"
                        />
                      </td>
                      <td className="py-2.5 pr-3">
                        <p className="font-mono text-xs font-semibold text-primary-700">{line.so_number}</p>
                        <p className="text-xs text-neutral-500">{line.customer_name}</p>
                      </td>
                      <td className="py-2.5 pr-3">
                        <p className="font-medium text-neutral-800">{line.item_name}</p>
                        {line.lot_number && <p className="text-xs text-neutral-400">Lot: {line.lot_number}</p>}
                      </td>
                      <td className="py-2.5 pr-3 text-right font-semibold text-warning-600">{line.pending_qty}</td>
                      <td className="py-2.5 pr-3 text-right" onClick={e => e.stopPropagation()}>
                        {isSelected ? (
                          <input
                            type="number"
                            value={selected[line.so_line_id]}
                            max={parseFloat(line.pending_qty)}
                            min="0"
                            onChange={e => updateQty(line.so_line_id, e.target.value)}
                            className="w-20 border border-primary-300 rounded px-2 py-0.5 text-xs font-medium text-right focus:outline-none focus:ring-1 focus:ring-primary-400"
                          />
                        ) : (
                          <span className="text-neutral-300">—</span>
                        )}
                      </td>
                      <td className="py-2.5 pr-3 font-mono text-xs text-neutral-500">{line.lot_number ?? '—'}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </Card>
      )}
    </div>
  );
}
