import { useRef, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { createColumnHelper } from '@tanstack/react-table';
import toast from 'react-hot-toast';
import { ArrowLeftIcon, PrinterIcon, QrCodeIcon, PlusIcon, CheckIcon } from '@heroicons/react/24/outline';

import { purchaseService, MRRLine, GEListItem } from '@/services/purchase';
import { MRR_STATUS_LABELS } from '@/utils/purchase';
import Button from '@/components/ui/Button';
import Badge from '@/components/ui/Badge';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import Modal from '@/components/ui/Modal';
import Select from '@/components/ui/Select';
import DataTable from '@/components/ui/DataTable';
import { formatDate, formatNumber, formatCurrency } from '@/utils/format';
import { createColumnHelper as ccol } from '@tanstack/react-table';

const col = createColumnHelper<MRRLine>();

const QC_VARIANT: Record<string, 'neutral' | 'warning' | 'success' | 'danger'> = {
  PENDING: 'warning', PASSED: 'success', REJECTED: 'danger', ON_HOLD: 'neutral',
};

const LINE_COLUMNS = [
  col.accessor('line_number', { header: '#', size: 50 }),
  col.accessor('item_code', {
    header: 'Item',
    cell: i => (
      <div>
        <span className="font-mono text-xs font-semibold text-primary-800">{i.getValue()}</span>
        <p className="text-xs text-neutral-500 mt-0.5">{i.row.original.item_name}</p>
      </div>
    ),
  }),
  col.accessor('lot_number', {
    header: 'Lot #',
    cell: i => <span className="font-mono text-xs">{i.getValue() || '—'}</span>,
    size: 160,
  }),
  col.accessor('roll_number', {
    header: 'Roll #',
    cell: i => <span className="font-mono text-xs">{i.getValue() || '—'}</span>,
    size: 100,
  }),
  col.accessor('quantity', {
    header: 'Qty',
    cell: i => (
      <span className="font-medium">{formatNumber(i.getValue())} <span className="text-neutral-400 text-xs">{i.row.original.uom_code}</span></span>
    ),
    size: 90,
  }),
  col.accessor('gross_weight_kg', {
    header: 'Gross (kg)',
    cell: i => i.getValue() ? formatNumber(i.getValue()!) : <span className="text-neutral-300">—</span>,
    size: 90,
  }),
  col.accessor('net_weight_kg', {
    header: 'Net (kg)',
    cell: i => i.getValue() ? formatNumber(i.getValue()!) : <span className="text-neutral-300">—</span>,
    size: 90,
  }),
  col.accessor('rate', {
    header: 'Rate',
    cell: i => i.getValue() ? formatCurrency(i.getValue()!) : <span className="text-neutral-300">—</span>,
    size: 100,
  }),
  col.accessor('qc_status', {
    header: 'QC',
    cell: i => <Badge variant={QC_VARIANT[i.getValue()] ?? 'neutral'} size="sm">{i.getValue()}</Badge>,
    size: 90,
  }),
  col.accessor('qr_printed', {
    header: 'QR',
    cell: i => (
      <span className={`text-xs font-medium ${i.getValue() ? 'text-success-600' : 'text-neutral-400'}`}>
        {i.getValue() ? '✓ Printed' : 'Not printed'}
      </span>
    ),
    size: 90,
  }),
];

// Print view that renders QR labels formatted for printing
function PrintLabelsView({ mrr_number, labels }: { mrr_number: string; labels: { item_code: string; item_name: string; lot_number: string; roll_number: string; quantity: string; qr_image_base64: string }[] }) {
  return (
    <div className="p-4">
      <style>{`@media print { .no-print { display: none; } body { margin: 0; } }`}</style>
      <div className="no-print mb-4 flex items-center justify-between">
        <span className="text-sm font-semibold">QR Labels — {mrr_number}</span>
        <button onClick={() => window.print()} className="btn btn-primary text-sm">Print Now</button>
      </div>
      <div className="grid grid-cols-3 gap-4">
        {labels.map((label, i) => (
          <div key={i} className="border border-neutral-300 rounded-lg p-3 flex flex-col items-center gap-2 break-inside-avoid">
            <img src={`data:image/png;base64,${label.qr_image_base64}`} alt="QR" className="w-28 h-28 object-contain" />
            <div className="w-full text-center">
              <p className="text-xs font-mono font-bold">{label.item_code}</p>
              <p className="text-xs text-neutral-600 truncate">{label.item_name}</p>
              <p className="text-xs font-mono text-neutral-700 mt-1">Lot: {label.lot_number}</p>
              {label.roll_number && <p className="text-xs font-mono">Roll: {label.roll_number}</p>}
              <p className="text-xs font-semibold mt-1">Qty: {label.quantity}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// GE selection modal column
const geCol = ccol<GEListItem>();
const GE_COLS = [
  geCol.accessor('gate_entry_number', { header: 'GE Number', cell: i => <span className="font-mono text-xs font-semibold">{i.getValue()}</span> }),
  geCol.accessor('vendor_name', { header: 'Vendor' }),
  geCol.accessor('entry_datetime', { header: 'Date', cell: i => formatDate(i.getValue()), size: 100 }),
  geCol.accessor('po_number', { header: 'PO', cell: i => i.getValue() || '—', size: 130 }),
];

const STATUS_VARIANT: Record<string, 'neutral' | 'warning' | 'success' | 'danger'> = {
  DRAFT: 'neutral', QC_PENDING: 'warning', QC_PASSED: 'success', QC_REJECTED: 'danger', COMPLETED: 'success',
};

export default function MRRDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [printModal, setPrintModal] = useState(false);
  const [createModal, setCreateModal] = useState(false);
  const [selectedGE, setSelectedGE] = useState<GEListItem | null>(null);
  const [warehouseId, setWarehouseId] = useState('1'); // Placeholder — real app loads from API

  const { data: mrr, isLoading } = useQuery({
    queryKey: ['mrr', id],
    queryFn: () => purchaseService.getMRR(id!),
    enabled: !!id,
  });

  const { data: qrData, isLoading: loadingQR } = useQuery({
    queryKey: ['mrr-qr', id],
    queryFn: () => purchaseService.getQRLabels(id!),
    enabled: printModal && !!id,
  });

  const { data: pendingGEs } = useQuery({
    queryKey: ['ge-pending-mrr'],
    queryFn: () => purchaseService.getPendingMRREntries({ limit: 100 }),
    enabled: createModal,
  });

  const markPrintedMut = useMutation({
    mutationFn: () => purchaseService.markQRPrinted(id!),
    onSuccess: updated => {
      qc.setQueryData(['mrr', id], updated);
      toast.success('Marked as printed');
      setPrintModal(false);
    },
  });

  const createFromGEMut = useMutation({
    mutationFn: () => purchaseService.createMRRFromGE(selectedGE!.id, parseInt(warehouseId)),
    onSuccess: newMRR => {
      qc.invalidateQueries({ queryKey: ['mrrs'] });
      toast.success('MRR created');
      setCreateModal(false);
      navigate(`/purchase/mrrs/${newMRR.id}`);
    },
    onError: () => toast.error('Failed to create MRR'),
  });

  if (isLoading) return (
    <div className="flex items-center justify-center h-64"><LoadingSpinner size="xl" className="text-primary-600" /></div>
  );

  if (!mrr) {
    // If no ID yet (navigating to /mrrs without a specific record), show "Create from GE" prompt
    return (
      <div className="text-center py-24">
        <QrCodeIcon className="h-12 w-12 text-neutral-300 mx-auto mb-3" />
        <p className="text-neutral-500 mb-4">Select an MRR from the list, or create a new one from a gate entry.</p>
        <Button leftIcon={<PlusIcon className="h-4 w-4" />} onClick={() => { navigate('/purchase/mrrs'); }}>
          Back to MRR List
        </Button>
      </div>
    );
  }

  const allPrinted = mrr.lines.every(l => l.qr_printed);

  return (
    <div>
      <div className="flex items-start justify-between mb-6 gap-4">
        <div className="flex items-start gap-3">
          <button onClick={() => navigate(-1)} className="p-2 mt-0.5 rounded-lg hover:bg-neutral-100 text-neutral-400"><ArrowLeftIcon className="h-5 w-5" /></button>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h1 className="text-xl font-bold text-neutral-900">{mrr.mrr_number}</h1>
              <Badge variant={STATUS_VARIANT[mrr.status] ?? 'neutral'}>
                {MRR_STATUS_LABELS[mrr.status] ?? mrr.status}
              </Badge>
              {allPrinted && <Badge variant="success" size="sm" dot>All QRs Printed</Badge>}
            </div>
            <p className="text-sm text-neutral-500 mt-0.5">
              {mrr.vendor_name} · {formatDate(mrr.mrr_date)}
              {mrr.gate_entry_number && ` · GE: ${mrr.gate_entry_number}`}
              {mrr.warehouse_name && ` · ${mrr.warehouse_name}`}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <Button variant="outline" size="sm" leftIcon={<PrinterIcon className="h-4 w-4" />}
            onClick={() => setPrintModal(true)}>
            Print QR Labels
          </Button>
        </div>
      </div>

      <div className="card">
        <h3 className="text-sm font-semibold text-neutral-700 mb-4">
          Material Lines
          <span className="ml-2 text-xs font-normal text-neutral-400">({mrr.lines.length} lines · {mrr.lines.filter(l => l.qr_printed).length} QRs printed)</span>
        </h3>
        <DataTable data={mrr.lines} columns={LINE_COLUMNS} emptyTitle="No lines" />
      </div>

      {/* QR Print Modal */}
      <Modal open={printModal} onClose={() => setPrintModal(false)} title="QR Labels" size="2xl"
        footer={
          <>
            <Button variant="outline" onClick={() => setPrintModal(false)}>Close</Button>
            <Button variant="outline" leftIcon={<PrinterIcon className="h-4 w-4" />}
              onClick={() => window.print()}>
              Print
            </Button>
            <Button leftIcon={<CheckIcon className="h-4 w-4" />}
              loading={markPrintedMut.isPending} onClick={() => markPrintedMut.mutate()}>
              Mark as Printed
            </Button>
          </>
        }>
        {loadingQR ? (
          <div className="flex justify-center py-8"><LoadingSpinner size="lg" className="text-primary-600" /></div>
        ) : qrData?.labels?.length ? (
          <PrintLabelsView mrr_number={qrData.mrr_number} labels={qrData.labels} />
        ) : (
          <p className="text-sm text-neutral-400 text-center py-8">No QR labels generated</p>
        )}
      </Modal>
    </div>
  );
}

// Exported component for "Create MRR from GE" — used from GE list / dashboard
export function CreateMRRFromGEButton() {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [selectedGE, setSelectedGE] = useState<GEListItem | null>(null);
  const [warehouseId, setWarehouseId] = useState('1');

  const { data: pendingGEs } = useQuery({
    queryKey: ['ge-pending-mrr'],
    queryFn: () => purchaseService.getPendingMRREntries({ limit: 100 }),
    enabled: open,
  });

  const createMut = useMutation({
    mutationFn: () => purchaseService.createMRRFromGE(selectedGE!.id, parseInt(warehouseId)),
    onSuccess: newMRR => {
      qc.invalidateQueries({ queryKey: ['mrrs'] });
      toast.success('MRR created');
      setOpen(false);
      navigate(`/purchase/mrrs/${newMRR.id}`);
    },
    onError: () => toast.error('Failed to create MRR'),
  });

  const WAREHOUSE_OPTIONS = [{ value: '1', label: 'Main Warehouse' }, { value: '2', label: 'Secondary' }];
  const geCol2 = ccol<GEListItem>();
  const GE_COLS2 = [
    geCol2.accessor('gate_entry_number', { header: 'GE Number', cell: i => <span className="font-mono text-xs font-semibold">{i.getValue()}</span> }),
    geCol2.accessor('vendor_name', { header: 'Vendor' }),
    geCol2.accessor('entry_datetime', { header: 'Date', cell: i => formatDate(i.getValue()), size: 100 }),
  ];

  return (
    <>
      <Button size="sm" leftIcon={<PlusIcon className="h-4 w-4" />} onClick={() => setOpen(true)}>
        Create MRR from Gate Entry
      </Button>
      <Modal open={open} onClose={() => setOpen(false)} title="Create MRR from Gate Entry" size="lg"
        footer={
          <>
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button disabled={!selectedGE} loading={createMut.isPending} onClick={() => createMut.mutate()}>
              Create MRR
            </Button>
          </>
        }>
        <div className="space-y-4">
          <Select label="Warehouse" required options={WAREHOUSE_OPTIONS} value={warehouseId}
            onChange={e => setWarehouseId(e.target.value)} />
          <div>
            <p className="form-label mb-2">Select Gate Entry (Pending MRR)</p>
            <DataTable
              data={pendingGEs?.results ?? []}
              columns={GE_COLS2}
              loading={!pendingGEs}
              onRowClick={row => setSelectedGE(row)}
              toolbarLeft={selectedGE && (
                <span className="text-xs text-primary-700 bg-primary-50 px-2 py-1 rounded">
                  Selected: {selectedGE.gate_entry_number}
                </span>
              )}
              emptyTitle="No gate entries pending MRR"
            />
          </div>
        </div>
      </Modal>
    </>
  );
}
