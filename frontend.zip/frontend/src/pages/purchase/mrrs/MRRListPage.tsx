import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { createColumnHelper } from '@tanstack/react-table';

import { purchaseService, MRRListItem } from '@/services/purchase';
import { MRR_STATUS_LABELS } from '@/utils/purchase';
import DataTable from '@/components/ui/DataTable';
import Badge from '@/components/ui/Badge';
import PageHeader from '@/components/ui/PageHeader';
import Tabs from '@/components/ui/Tabs';
import { usePagination } from '@/hooks/usePagination';
import { useDebounce } from '@/hooks/useDebounce';
import { formatDate } from '@/utils/format';

const col = createColumnHelper<MRRListItem>();

const STATUS_VARIANT: Record<string, 'neutral' | 'warning' | 'success' | 'danger'> = {
  DRAFT: 'neutral', QC_PENDING: 'warning', QC_PASSED: 'success', QC_REJECTED: 'danger', COMPLETED: 'success',
};

const COLUMNS = [
  col.accessor('mrr_number', {
    header: 'MRR Number',
    cell: i => <span className="font-mono text-xs font-semibold text-primary-800">{i.getValue()}</span>,
    size: 170,
  }),
  col.accessor('gate_entry_number', {
    header: 'Gate Entry',
    cell: i => i.getValue()
      ? <span className="font-mono text-xs text-neutral-600">{i.getValue()}</span>
      : <span className="text-neutral-300">—</span>,
    size: 160,
  }),
  col.accessor('vendor_name', {
    header: 'Vendor',
    cell: i => i.getValue() ?? <span className="text-neutral-300">—</span>,
  }),
  col.accessor('mrr_date', {
    header: 'Date',
    cell: i => formatDate(i.getValue()),
    size: 110,
  }),
  col.accessor('warehouse_name', {
    header: 'Warehouse',
    cell: i => i.getValue() ?? <span className="text-neutral-300">—</span>,
    size: 130,
  }),
  col.accessor('status', {
    header: 'Status',
    cell: i => (
      <Badge variant={STATUS_VARIANT[i.getValue()] ?? 'neutral'} size="sm">
        {MRR_STATUS_LABELS[i.getValue()] ?? i.getValue()}
      </Badge>
    ),
    size: 130,
  }),
];

type MRRMode = 'all' | 'qc_pending';
const LIST_TABS = [
  { key: 'all', label: 'All MRRs' },
  { key: 'qc_pending', label: 'QC Pending' },
];

export default function MRRListPage() {
  const navigate = useNavigate();
  const { page, pageSize, offset, setPage, setPageSize } = usePagination();
  const [search, setSearch] = useState('');
  const debouncedSearch = useDebounce(search);
  const [mode, setMode] = useState<MRRMode>('all');

  const { data, isLoading } = useQuery({
    queryKey: ['mrrs', mode, { offset, limit: pageSize, search: debouncedSearch }],
    queryFn: () => {
      const p = { offset, limit: pageSize, search: debouncedSearch };
      if (mode === 'qc_pending') return purchaseService.getQCPending(p);
      return purchaseService.getMRRs(p);
    },
    placeholderData: prev => prev,
  });

  return (
    <div>
      <PageHeader title="Material Receipt Reports" description={`${data?.count ?? 0} MRRs`} />

      <Tabs tabs={LIST_TABS} active={mode} onChange={v => { setMode(v as MRRMode); setPage(1); }}
        variant="pills" className="mb-4" />

      <DataTable
        data={data?.results ?? []}
        columns={COLUMNS}
        totalCount={data?.count}
        page={page} pageSize={pageSize}
        onPageChange={setPage} onPageSizeChange={setPageSize}
        searchValue={search}
        onSearchChange={v => { setSearch(v); setPage(1); }}
        searchPlaceholder="Search MRR number, vendor…"
        loading={isLoading}
        onRowClick={row => navigate(`/purchase/mrrs/${row.id}`)}
        emptyTitle={mode === 'qc_pending' ? 'No MRRs pending QC' : 'No MRRs found'}
      />
    </div>
  );
}
