import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import {
  Bar, BarChart, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell,
} from 'recharts';
import {
  DocumentTextIcon, ShoppingCartIcon, TruckIcon, ClipboardDocumentCheckIcon,
  ArrowRightIcon, ExclamationTriangleIcon,
} from '@heroicons/react/24/outline';

import { purchaseService } from '@/services/purchase';
import PageHeader from '@/components/ui/PageHeader';
import Badge from '@/components/ui/Badge';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import { CreateMRRFromGEButton } from './mrrs/MRRDetailPage';
import { formatCurrency, formatDate } from '@/utils/format';
import { cn } from '@/utils/cn';

// Pipeline step card
function PipelineCard({
  icon: Icon, label, count, href, color, urgent,
}: {
  icon: React.ElementType; label: string; count: number; href: string; color: string; urgent?: boolean;
}) {
  const navigate = useNavigate();
  return (
    <button
      onClick={() => navigate(href)}
      className={cn(
        'group w-full text-left p-5 bg-white rounded-2xl border transition-all hover:shadow-lg hover:-translate-y-0.5',
        urgent && count > 0 ? 'border-warning-200 bg-warning-50' : 'border-neutral-100'
      )}
    >
      <div className="flex items-start justify-between mb-3">
        <div className={cn('h-10 w-10 rounded-xl flex items-center justify-center', color)}>
          <Icon className="h-5 w-5" />
        </div>
        {urgent && count > 0 && <ExclamationTriangleIcon className="h-4 w-4 text-warning-500" />}
      </div>
      <div className="flex items-end gap-2">
        <span className="text-3xl font-bold text-neutral-900">{count}</span>
        <ArrowRightIcon className="h-4 w-4 text-neutral-300 mb-1.5 group-hover:translate-x-1 transition-transform" />
      </div>
      <p className="text-sm text-neutral-500 mt-1">{label}</p>
    </button>
  );
}

export default function PurchaseDashboardPage() {
  const navigate = useNavigate();

  const { data: pipeline, isLoading: loadingPipeline } = useQuery({
    queryKey: ['purchase-pipeline'],
    queryFn: purchaseService.getPipelineSummary,
    refetchInterval: 60_000,
  });

  const { data: tat, isLoading: loadingTAT } = useQuery({
    queryKey: ['purchase-tat'],
    queryFn: purchaseService.getTATData,
  });

  const { data: priceIncreases } = useQuery({
    queryKey: ['pos-price-increase'],
    queryFn: purchaseService.getPOsWithPriceIncrease,
  });

  const PIPELINE_STEPS = [
    {
      icon: DocumentTextIcon,
      label: 'PRs Pending Approval',
      count: pipeline?.pr_not_approved ?? 0,
      href: '/purchase/requisitions?mode=pending_approval',
      color: 'bg-blue-100 text-blue-600',
      urgent: true,
    },
    {
      icon: DocumentTextIcon,
      label: 'Approved PRs — No PO',
      count: pipeline?.pr_approved_no_po ?? 0,
      href: '/purchase/requisitions',
      color: 'bg-indigo-100 text-indigo-600',
    },
    {
      icon: ShoppingCartIcon,
      label: 'POs Pending Approval',
      count: pipeline?.po_not_approved ?? 0,
      href: '/purchase/orders',
      color: 'bg-primary-100 text-primary-700',
      urgent: true,
    },
    {
      icon: ShoppingCartIcon,
      label: 'Approved POs — No Receipt',
      count: pipeline?.po_approved_no_mrr ?? 0,
      href: '/purchase/orders',
      color: 'bg-teal-100 text-teal-600',
    },
    {
      icon: TruckIcon,
      label: 'Gate Entries — MRR Pending',
      count: pipeline?.gate_entry_pending_mrr ?? 0,
      href: '/purchase/gate-entries?mode=pending_mrr',
      color: 'bg-orange-100 text-orange-600',
      urgent: true,
    },
    {
      icon: ClipboardDocumentCheckIcon,
      label: 'MRRs — QC Pending',
      count: pipeline?.mrr_qc_pending ?? 0,
      href: '/purchase/mrrs?mode=qc_pending',
      color: 'bg-warning-100 text-warning-700',
    },
  ];

  return (
    <div>
      <PageHeader
        title="Purchase Dashboard"
        description="Pipeline overview and key metrics"
        actions={<CreateMRRFromGEButton />}
      />

      {/* Pipeline cards */}
      {loadingPipeline ? (
        <div className="flex justify-center py-12"><LoadingSpinner size="xl" className="text-primary-600" /></div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4 mb-8">
          {PIPELINE_STEPS.map(step => (
            <PipelineCard key={step.label} {...step} />
          ))}
        </div>
      )}

      {/* Pipeline flow visualization */}
      <div className="card mb-6">
        <h3 className="text-sm font-semibold text-neutral-700 mb-4">Purchase Pipeline Flow</h3>
        <div className="flex items-center gap-1 overflow-x-auto pb-2">
          {[
            { label: 'PR Created', count: pipeline?.pr_not_approved, color: 'bg-blue-500' },
            { label: '→', count: null, color: '' },
            { label: 'PR Approved', count: pipeline?.pr_approved_no_po, color: 'bg-indigo-500' },
            { label: '→', count: null, color: '' },
            { label: 'PO Raised', count: pipeline?.po_not_approved, color: 'bg-primary-600' },
            { label: '→', count: null, color: '' },
            { label: 'PO Approved', count: pipeline?.po_approved_no_mrr, color: 'bg-teal-500' },
            { label: '→', count: null, color: '' },
            { label: 'Gate Entry', count: pipeline?.gate_entry_pending_mrr, color: 'bg-orange-500' },
            { label: '→', count: null, color: '' },
            { label: 'MRR / QC', count: pipeline?.mrr_qc_pending, color: 'bg-warning-500' },
          ].map((step, i) => {
            if (step.label === '→') return <span key={i} className="text-neutral-300 text-lg shrink-0">→</span>;
            return (
              <div key={i} className={cn('shrink-0 rounded-xl px-4 py-3 text-white text-center min-w-24', step.color)}>
                <p className="text-xl font-bold">{step.count ?? '—'}</p>
                <p className="text-xs opacity-80 mt-0.5">{step.label}</p>
              </div>
            );
          })}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        {/* TAT Chart */}
        <div className="card">
          <h3 className="text-sm font-semibold text-neutral-700 mb-4">PR → PO Turnaround Time (days)</h3>
          {loadingTAT ? (
            <div className="flex justify-center py-8"><LoadingSpinner className="text-primary-600" /></div>
          ) : tat?.by_month?.length ? (
            <>
              <div className="flex items-center gap-2 mb-4">
                <span className="text-3xl font-bold text-neutral-900">{tat.avg_days.toFixed(1)}</span>
                <span className="text-sm text-neutral-500">avg days overall</span>
              </div>
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={tat.by_month} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis dataKey="month" tick={{ fontSize: 11 }} />
                  <YAxis tick={{ fontSize: 11 }} />
                  <Tooltip formatter={(val: number) => [`${val.toFixed(1)} days`, 'Avg TAT']} />
                  <Bar dataKey="avg_days" radius={[4, 4, 0, 0]}>
                    {tat.by_month.map((_, i) => (
                      <Cell key={i} fill={i === tat.by_month.length - 1 ? '#1e40af' : '#93c5fd'} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </>
          ) : (
            <p className="text-sm text-neutral-400 text-center py-8">No TAT data available</p>
          )}
        </div>

        {/* POs with price increases */}
        <div className="card">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-semibold text-neutral-700">POs with Price Increases</h3>
            <button onClick={() => navigate('/purchase/orders')}
              className="text-xs text-primary-700 hover:underline">View all</button>
          </div>
          {!priceIncreases ? (
            <div className="flex justify-center py-8"><LoadingSpinner className="text-primary-600" /></div>
          ) : priceIncreases.results.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-sm text-success-600 font-medium">✓ No price increase alerts</p>
              <p className="text-xs text-neutral-400 mt-1">All active PO rates are within expected range</p>
            </div>
          ) : (
            <div className="space-y-2">
              {priceIncreases.results.slice(0, 6).map(po => (
                <div key={po.id}
                  onClick={() => navigate(`/purchase/orders/${po.id}`)}
                  className="flex items-center justify-between p-3 rounded-lg border border-warning-100 bg-warning-50 cursor-pointer hover:bg-warning-100 transition-colors">
                  <div>
                    <span className="font-mono text-xs font-semibold text-warning-800">{po.po_number}</span>
                    <p className="text-xs text-neutral-500 mt-0.5">{po.vendor_name} · {formatDate(po.po_date)}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-bold text-neutral-800">{formatCurrency(po.total_amount)}</p>
                    <Badge variant="warning" size="sm">Price↑</Badge>
                  </div>
                </div>
              ))}
              {priceIncreases.count > 6 && (
                <button onClick={() => navigate('/purchase/orders')}
                  className="w-full text-xs text-neutral-400 hover:text-primary-700 py-2">
                  +{priceIncreases.count - 6} more
                </button>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
