import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useForm, useFieldArray } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import toast from 'react-hot-toast';
import {
  ArrowLeftIcon, PlusIcon, TrashIcon, ShieldCheckIcon, PhotoIcon,
  CheckCircleIcon, ExclamationCircleIcon,
} from '@heroicons/react/24/outline';

import { purchaseService, GEValidationResult } from '@/services/purchase';
import { vendorsService } from '@/services/vendors';
import Button from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import Select from '@/components/ui/Select';
import DateInput from '@/components/ui/DateInput';
import Textarea from '@/components/ui/Textarea';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import { useUnsavedChanges } from '@/hooks/useUnsavedChanges';
import { cn } from '@/utils/cn';

const lineSchema = z.object({
  item: z.string().min(1, 'Item required'),
  item_code: z.string(),
  item_name: z.string(),
  po_line_id: z.string().optional(),
  quantity: z.coerce.number().min(0.001, 'Qty > 0'),
  uom: z.number(),
  uom_code: z.string(),
  roll_number: z.string(),
  gross_weight_kg: z.string().optional(),
  net_weight_kg: z.string().optional(),
  deckle_mm: z.string().optional(),
  remarks: z.string(),
});

const geSchema = z.object({
  po: z.string().optional(),
  entry_type: z.enum(['AGAINST_PO', 'CUSTOMER_JOB_WORK', 'FROM_JOB_WORKER', 'RETURNABLE', 'NON_RETURNABLE']),
  entry_datetime: z.string().min(1, 'Entry date/time required'),
  vehicle_number: z.string(),
  transporter_name: z.string(),
  lr_number: z.string(),
  lr_date: z.string().optional(),
  driver_name: z.string(),
  driver_phone: z.string(),
  bill_number: z.string(),
  bill_date: z.string().optional(),
  challan_number: z.string(),
  challan_date: z.string().optional(),
  gst_transporter_copy_received: z.boolean(),
  remarks: z.string(),
  lines: z.array(lineSchema).min(1, 'At least one line required'),
});

type GEFormValues = z.infer<typeof geSchema>;

const ENTRY_TYPE_OPTIONS = [
  { value: 'AGAINST_PO', label: 'Against PO' },
  { value: 'CUSTOMER_JOB_WORK', label: 'Customer Job Work' },
  { value: 'FROM_JOB_WORKER', label: 'From Job Worker' },
  { value: 'RETURNABLE', label: 'Returnable Gate Pass' },
  { value: 'NON_RETURNABLE', label: 'Non-Returnable' },
];

const DEFAULT_LINE = { item: '', item_code: '', item_name: '', po_line_id: '', quantity: 1, uom: 0, uom_code: '', roll_number: '', gross_weight_kg: '', net_weight_kg: '', deckle_mm: '', remarks: '' };
const DEFAULT_VALUES: Partial<GEFormValues> = {
  entry_type: 'AGAINST_PO',
  entry_datetime: new Date().toISOString().slice(0, 16),
  gst_transporter_copy_received: false,
  lines: [{ ...DEFAULT_LINE }],
};

// Photo upload button
function PhotoUpload({ label, field }: { label: string; field: 'bill_photo' | 'shipment_photo' | 'truck_photo' }) {
  const [preview, setPreview] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  return (
    <div className="flex flex-col items-center gap-1">
      <button type="button" onClick={() => fileRef.current?.click()}
        className={cn(
          'w-full h-24 border-2 border-dashed rounded-xl flex flex-col items-center justify-center gap-1 transition-colors',
          preview ? 'border-success-300 bg-success-50' : 'border-neutral-200 bg-neutral-50 hover:border-primary-300 hover:bg-primary-50'
        )}>
        {preview
          ? <img src={preview} alt={label} className="h-16 w-full object-cover rounded-lg" />
          : <><PhotoIcon className="h-6 w-6 text-neutral-300" /><span className="text-xs text-neutral-400">{label}</span></>
        }
      </button>
      <input ref={fileRef} type="file" accept="image/*" className="hidden"
        onChange={e => {
          const f = e.target.files?.[0];
          if (f) setPreview(URL.createObjectURL(f));
        }} />
    </div>
  );
}

export default function GEFormPage() {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [validationResult, setValidationResult] = useState<GEValidationResult | null>(null);
  const [createdId, setCreatedId] = useState<string | null>(null);
  const [validating, setValidating] = useState(false);

  const { data: vendors = [] } = useQuery({
    queryKey: ['vendors-list'],
    queryFn: () => vendorsService.getVendors({ limit: 200 }).then(r => r.results),
    staleTime: 60_000,
  });

  // Load approved POs for dropdown
  const { data: approvedPOs } = useQuery({
    queryKey: ['pos-approved'],
    queryFn: () => purchaseService.getPOs({ status: 'APPROVED', limit: 200 }).then(r => r.results),
    staleTime: 60_000,
  });

  const {
    register, handleSubmit, watch, setValue, reset, control,
    formState: { errors, isDirty, isSubmitting },
  } = useForm<GEFormValues>({ resolver: zodResolver(geSchema), defaultValues: DEFAULT_VALUES as GEFormValues });

  useUnsavedChanges(isDirty && !createdId);

  const { fields, append, remove, replace } = useFieldArray({ control, name: 'lines' });
  const selectedPOId = watch('po');

  // Auto-populate lines when PO selected
  const { data: selectedPO } = useQuery({
    queryKey: ['po', selectedPOId],
    queryFn: () => purchaseService.getPO(selectedPOId!),
    enabled: !!selectedPOId,
  });

  useEffect(() => {
    if (selectedPO?.lines?.length) {
      replace(selectedPO.lines.map(l => ({
        item: l.item,
        item_code: l.item_code ?? '',
        item_name: l.item_name ?? '',
        po_line_id: String(l.id ?? ''),
        quantity: parseFloat(String(l.quantity)),
        uom: l.uom ?? 0,
        uom_code: l.uom_code ?? '',
        roll_number: '',
        gross_weight_kg: '',
        net_weight_kg: '',
        deckle_mm: '',
        remarks: '',
      })));
    }
  }, [selectedPO, replace]);

  const mutation = useMutation({
    mutationFn: (data: GEFormValues) => {
      const payload = {
        ...data,
        po: data.po || null,
        lines: data.lines.map((l, i) => ({
          line_number: i + 1,
          item: l.item, uom: l.uom,
          quantity: l.quantity,
          roll_number: l.roll_number,
          gross_weight_kg: l.gross_weight_kg || null,
          net_weight_kg: l.net_weight_kg || null,
          deckle_mm: l.deckle_mm || null,
          remarks: l.remarks,
          ...(l.po_line_id && { po_line: parseInt(l.po_line_id) }),
        })),
      };
      return purchaseService.createGateEntry(payload);
    },
    onSuccess: async saved => {
      setCreatedId(saved.id);
      qc.invalidateQueries({ queryKey: ['gate-entries'] });
      toast.success('Gate entry created');
      navigate(`/purchase/gate-entries/${saved.id}`);
    },
    onError: (err: unknown) => {
      const e = err as { response?: { data?: Record<string, string[]> } };
      toast.error(e?.response?.data ? Object.values(e.response.data)[0]?.[0] ?? 'Save failed' : 'Save failed');
    },
  });

  const handleValidate = async () => {
    if (!createdId) { toast.error('Save first, then validate'); return; }
    setValidating(true);
    try {
      const result = await purchaseService.validateGateEntry(createdId);
      setValidationResult(result);
      if (result.is_valid) toast.success('Validation passed — quantities are within tolerance');
      else toast.error('Validation failed — check quantity errors');
    } catch { toast.error('Validation failed'); }
    finally { setValidating(false); }
  };

  const poOptions = (approvedPOs ?? []).map(po => ({ value: po.id, label: `${po.po_number} — ${po.vendor_name ?? ''}` }));
  const lines = watch('lines') ?? [];

  return (
    <div>
      <div className="flex items-center justify-between mb-6 gap-4">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate(-1)} className="p-2 rounded-lg hover:bg-neutral-100 text-neutral-400"><ArrowLeftIcon className="h-5 w-5" /></button>
          <h1 className="text-xl font-bold text-neutral-900">New Gate Entry</h1>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" leftIcon={<ShieldCheckIcon className="h-4 w-4" />}
            loading={validating} onClick={handleValidate}>
            Validate
          </Button>
          <Button variant="outline" type="button" onClick={() => navigate(-1)} disabled={isSubmitting}>Cancel</Button>
          <Button loading={isSubmitting} onClick={handleSubmit(d => mutation.mutate(d))}>Save Gate Entry</Button>
        </div>
      </div>

      {/* Validation result */}
      {validationResult && (
        <div className={cn('mb-4 p-4 rounded-xl border',
          validationResult.is_valid ? 'bg-success-50 border-success-200' : 'bg-danger-50 border-danger-200')}>
          <div className="flex items-center gap-2 mb-2">
            {validationResult.is_valid
              ? <CheckCircleIcon className="h-5 w-5 text-success-600" />
              : <ExclamationCircleIcon className="h-5 w-5 text-danger-500" />
            }
            <span className={`text-sm font-semibold ${validationResult.is_valid ? 'text-success-700' : 'text-danger-700'}`}>
              {validationResult.is_valid ? 'Validation Passed' : `${validationResult.errors.length} Tolerance Error(s)`}
            </span>
          </div>
          {[...validationResult.errors, ...validationResult.warnings].map((e, i) => (
            <p key={i} className="text-xs text-neutral-700 mt-1">
              Line {e.line_number} ({e.item_code}): {e.issue} — received {e.received}, allowed {e.allowed}
            </p>
          ))}
        </div>
      )}

      <form onSubmit={handleSubmit(d => mutation.mutate(d))} noValidate>
        {/* Header */}
        <div className="card mb-4">
          <h3 className="text-sm font-semibold text-neutral-700 mb-4">Entry Details</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <Select label="Entry Type" required options={ENTRY_TYPE_OPTIONS} {...register('entry_type')} />
            <Select label="Against PO" options={[{ value: '', label: '— Select PO —' }, ...poOptions]}
              {...register('po')} />
            <Input label="Entry Date & Time" type="datetime-local" required
              error={errors.entry_datetime?.message} {...register('entry_datetime')} />
          </div>
        </div>

        {/* Transport */}
        <div className="card mb-4">
          <h3 className="text-sm font-semibold text-neutral-700 mb-4">Transport Details</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <Input label="Vehicle Number" {...register('vehicle_number')} placeholder="e.g. MH12AB1234" />
            <Input label="Transporter Name" {...register('transporter_name')} />
            <Input label="LR Number" {...register('lr_number')} />
            <DateInput label="LR Date" {...register('lr_date')} />
            <Input label="Driver Name" {...register('driver_name')} />
            <Input label="Driver Phone" {...register('driver_phone')} />
          </div>
        </div>

        {/* Bill/Challan */}
        <div className="card mb-4">
          <h3 className="text-sm font-semibold text-neutral-700 mb-4">Bill / Challan</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <Input label="Bill Number" {...register('bill_number')} />
            <DateInput label="Bill Date" {...register('bill_date')} />
            <Input label="Challan Number" {...register('challan_number')} />
            <DateInput label="Challan Date" {...register('challan_date')} />
          </div>
          <div className="grid grid-cols-3 gap-4 mt-4">
            <PhotoUpload label="Bill Photo" field="bill_photo" />
            <PhotoUpload label="Shipment Photo" field="shipment_photo" />
            <PhotoUpload label="Truck Photo" field="truck_photo" />
          </div>
          <label className="flex items-center gap-2 mt-4 cursor-pointer">
            <input type="checkbox" className="rounded text-primary-700" {...register('gst_transporter_copy_received')} />
            <span className="text-sm font-medium text-neutral-700">GST Transporter Copy Received</span>
          </label>
        </div>

        {/* Line items */}
        <div className="card mb-4">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-semibold text-neutral-700">Material Lines</h3>
            {selectedPO && <span className="text-xs text-success-600">Auto-filled from {selectedPO.po_number}</span>}
          </div>
          <div className="space-y-3">
            {fields.map((field, i) => {
              const lineCode = lines[i]?.item_code;
              const lineName = lines[i]?.item_name;
              const lineUOM = lines[i]?.uom_code;
              return (
                <div key={field.id} className="p-4 border border-neutral-100 rounded-xl bg-neutral-50">
                  <div className="flex justify-between items-center mb-3">
                    <div>
                      <span className="text-xs font-semibold text-neutral-400 uppercase tracking-wide">Line {i + 1}</span>
                      {lineCode && <span className="ml-2 font-mono text-xs text-primary-700">{lineCode} — {lineName}</span>}
                    </div>
                    <button type="button" onClick={() => remove(i)} className="text-danger-400 hover:text-danger-600">
                      <TrashIcon className="h-4 w-4" />
                    </button>
                  </div>
                  {/* Hidden fields populated from PO */}
                  <input type="hidden" {...register(`lines.${i}.item`)} />
                  <input type="hidden" {...register(`lines.${i}.item_code`)} />
                  <input type="hidden" {...register(`lines.${i}.item_name`)} />
                  <input type="hidden" {...register(`lines.${i}.uom_code`)} />
                  <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-3">
                    <div className="col-span-2">
                      <Input label={`Qty (${lineUOM || 'UOM'})`} required type="number" step="any" min="0"
                        error={errors.lines?.[i]?.quantity?.message}
                        {...register(`lines.${i}.quantity`, { valueAsNumber: true })} />
                    </div>
                    <Input label="Roll No." {...register(`lines.${i}.roll_number`)} placeholder="e.g. R-001" />
                    <Input label="Gross Wt. (kg)" type="number" step="any" {...register(`lines.${i}.gross_weight_kg`)} />
                    <Input label="Net Wt. (kg)" type="number" step="any" {...register(`lines.${i}.net_weight_kg`)} />
                    <Input label="Deckle (mm)" type="number" step="any" {...register(`lines.${i}.deckle_mm`)} />
                    <div className="col-span-2 sm:col-span-4 lg:col-span-6">
                      <Input label="Remarks" {...register(`lines.${i}.remarks`)} placeholder="Optional" />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
          {!selectedPOId && (
            <div className="mt-4">
              <Button type="button" variant="outline" size="sm" leftIcon={<PlusIcon className="h-4 w-4" />}
                onClick={() => append({ ...DEFAULT_LINE })}>
                Add Line
              </Button>
            </div>
          )}
        </div>

        <div className="card mb-4">
          <Textarea label="Remarks" rows={2} {...register('remarks')} />
        </div>

        <div className="flex justify-end gap-2 pb-4">
          <Button variant="outline" type="button" onClick={() => navigate(-1)} disabled={isSubmitting}>Cancel</Button>
          <Button type="submit" loading={isSubmitting}>Save Gate Entry</Button>
        </div>
      </form>
    </div>
  );
}
