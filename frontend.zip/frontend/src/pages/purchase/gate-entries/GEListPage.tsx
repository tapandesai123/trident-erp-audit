import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { createColumnHelper } from '@tanstack/react-table';
import { PlusIcon } from '@heroicons/react/24/outline';

import { purchaseService, GEListItem } from '@/services/purchase';
import { GE_STATUS_LABELS } from '@/utils/purchase';
import DataTable from '@/components/ui/DataTable';
import Badge from '@/components/ui/Badge';
import Button from '@/components/ui/Button';
import PageHeader from '@/components/ui/PageHeader';
import Tabs from '@/components/ui/Tabs';
import { usePagination } from '@/hooks/usePagination';
import { useDebounce } from '@/hooks/useDebounce';
import { formatDate } from '@/utils/format';

const col = createColumnHelper<GEListItem>();

const ENTRY_TYPE_LABELS: Record<string, string> = {
  AGAINST_PO: 'Against PO', CUSTOMER_JOB_WORK: 'Customer JW',
  FROM_JOB_WORKER: 'From JW', RETURNABLE: 'Returnable', NON_RETURNABLE: 'Non-Returnable',
};

const STATUS_VARIANT: Record<string, 'neutral' | 'success' | 'danger' | 'warning'> = {
  PENDING: 'warning', MRR_CREATED: 'success', REJECTED: 'danger',
};

const COLUMNS = [
  col.accessor('gate_entry_number', {
    header: 'GE Number',
    cell: i => <span className="font-mono text-xs font-semibold text-primary-800">{i.getValue()}</span>,
    size: 160,
  }),
  col.accessor('entry_type', {
    header: 'Type',
    cell: i => <Badge variant="neutral" size="sm">{ENTRY_TYPE_LABELS[i.getValue()] ?? i.getValue()}</Badge>,
    size: 130,
  }),
  col.accessor('vendor_name', {
    header: 'Vendor',
    cell: i => i.getValue() ?? <span className="text-neutral-300">—</span>,
  }),
  col.accessor('po_number', {
    header: 'PO',
    cell: i => i.getValue()
      ? <span className="font-mono text-xs text-primary-700">{i.getValue()}</span>
      : <span className="text-neutral-300">—</span>,
    size: 150,
  }),
  col.accessor('vehicle_number', {
    header: 'Vehicle',
    cell: i => i.getValue() ? <span className="font-mono text-xs">{i.getValue()}</span> : <span className="text-neutral-300">—</span>,
    size: 110,
  }),
  col.accessor('entry_datetime', {
    header: 'Entry Time',
    cell: i => formatDate(i.getValue()),
    size: 130,
  }),
  col.accessor('gst_transporter_copy_received', {
    header: 'GST Copy',
    cell: i => (
      <span className={`text-xs font-medium ${i.getValue() ? 'text-success-600' : 'text-danger-500'}`}>
        {i.getValue() ? '✓ Received' : '✗ Pending'}
      </span>
    ),
    size: 100,
  }),
  col.accessor('status', {
    header: 'Status',
    cell: i => <Badge variant={STATUS_VARIANT[i.getValue()] ?? 'neutral'} size="sm">{GE_STATUS_LABELS[i.getValue()] ?? i.getValue()}</Badge>,
    size: 130,
  }),
];

type GEMode = 'all' | 'pending_mrr' | 'gst_pending';

const LIST_TABS = [
  { key: 'all', label: 'All Entries' },
  { key: 'pending_mrr', label: 'Pending MRR' },
  { key: 'gst_pending', label: 'GST Copy Pending' },
];

export default function GEListPage() {
  const navigate = useNavigate();
  const { page, pageSize, offset, setPage, setPageSize } = usePagination();
  const [search, setSearch] = useState('');
  const debouncedSearch = useDebounce(search);
  const [mode, setMode] = useState<GEMode>('all');

  const { data, isLoading } = useQuery({
    queryKey: ['gate-entries', mode, { offset, limit: pageSize, search: debouncedSearch }],
    queryFn: () => {
      const p = { offset, limit: pageSize, search: debouncedSearch };
      if (mode === 'pending_mrr') return purchaseService.getPendingMRREntries(p);
      if (mode === 'gst_pending') return purchaseService.getGSTCopyPending(p);
      return purchaseService.getGateEntries(p);
    },
    placeholderData: prev => prev,
  });

  return (
    <div>
      <PageHeader
        title="Gate Entries"
        description={`${data?.count ?? 0} entries`}
        actions={
          <Button size="sm" leftIcon={<PlusIcon className="h-4 w-4" />}
            onClick={() => navigate('/purchase/gate-entries/new')}>
            New Gate Entry
          </Button>
        }
      />

      <Tabs tabs={LIST_TABS} active={mode}
        onChange={v => { setMode(v as GEMode); setPage(1); }}
        variant="pills" className="mb-4" />

      <DataTable
        data={data?.results ?? []}
        columns={COLUMNS}
        totalCount={data?.count}
        page={page} pageSize={pageSize}
        onPageChange={setPage} onPageSizeChange={setPageSize}
        searchValue={search}
        onSearchChange={v => { setSearch(v); setPage(1); }}
        searchPlaceholder="Search GE number, vendor, PO, vehicle…"
        loading={isLoading}
        onRowClick={row => navigate(`/purchase/gate-entries/${row.id}`)}
        emptyTitle={mode === 'pending_mrr' ? 'No entries pending MRR' : mode === 'gst_pending' ? 'No GST copy pending' : 'No gate entries'}
        emptyAction={mode === 'all' ? { label: '+ New Gate Entry', onClick: () => navigate('/purchase/gate-entries/new') } : undefined}
      />
    </div>
  );
}
