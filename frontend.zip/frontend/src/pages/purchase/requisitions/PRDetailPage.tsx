import { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { createColumnHelper } from '@tanstack/react-table';
import toast from 'react-hot-toast';
import {
  ArrowLeftIcon, PencilIcon, PaperAirplaneIcon,
  CheckCircleIcon, XCircleIcon, ArrowUturnLeftIcon,
} from '@heroicons/react/24/outline';

import { purchaseService, PRLine } from '@/services/purchase';
import {
  PR_STATUS_LABELS, PR_STATUS_VARIANT, PRIORITY_CONFIG,
  getPRApprovalLevel,
} from '@/utils/purchase';
import Button from '@/components/ui/Button';
import Badge from '@/components/ui/Badge';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import Modal from '@/components/ui/Modal';
import Textarea from '@/components/ui/Textarea';
import Select from '@/components/ui/Select';
import DataTable from '@/components/ui/DataTable';
import ApprovalTimeline from '@/components/purchase/ApprovalTimeline';
import { formatDate, formatCurrency, formatNumber } from '@/utils/format';
import { cn } from '@/utils/cn';

const col = createColumnHelper<PRLine>();

function ReadOnlyBadge({ children }: { children: React.ReactNode }) {
  return (
    <span className="text-xs bg-neutral-100 text-neutral-500 px-1.5 py-0.5 rounded font-medium">
      {children}
    </span>
  );
}

const LINE_COLUMNS = [
  col.accessor('line_number', { header: '#', size: 50 }),
  col.accessor('item_code', {
    header: 'Item',
    cell: i => (
      <div>
        <span className="font-mono text-xs font-semibold text-primary-800">{i.getValue()}</span>
        <p className="text-xs text-neutral-600 mt-0.5">{i.row.original.item_name}</p>
      </div>
    ),
  }),
  col.accessor('quantity', {
    header: 'Qty',
    cell: i => (
      <span className="font-medium">{formatNumber(i.getValue())} <span className="text-neutral-400 text-xs">{i.row.original.uom_code}</span></span>
    ),
    size: 90,
  }),
  col.accessor('estimated_rate', {
    header: 'Est. Rate',
    cell: i => i.getValue() ? formatCurrency(i.getValue()!) : <span className="text-neutral-300">—</span>,
    size: 110,
  }),
  col.accessor('last_vendor_name', {
    header: 'Last Vendor',
    cell: i => i.getValue()
      ? <><ReadOnlyBadge>{i.getValue()}</ReadOnlyBadge></>
      : <span className="text-neutral-300 text-xs">—</span>,
    size: 130,
  }),
  col.accessor('last_rate', {
    header: 'Last Rate',
    cell: i => i.getValue()
      ? <ReadOnlyBadge>{formatCurrency(i.getValue()!)}</ReadOnlyBadge>
      : <span className="text-neutral-300 text-xs">—</span>,
    size: 100,
  }),
  col.accessor('last_po_date', {
    header: 'Last PO',
    cell: i => i.getValue() ? <ReadOnlyBadge>{formatDate(i.getValue()!)}</ReadOnlyBadge> : <span className="text-neutral-300 text-xs">—</span>,
    size: 100,
  }),
  col.accessor('current_stock', {
    header: 'Stock',
    cell: i => {
      const val = i.getValue();
      const min = i.row.original.min_stock;
      if (!val) return <span className="text-neutral-300 text-xs">—</span>;
      const isLow = min && parseFloat(String(val)) < parseFloat(String(min));
      return (
        <ReadOnlyBadge>
          <span className={isLow ? 'text-danger-600 font-bold' : ''}>
            {formatNumber(val)} {i.row.original.uom_code}
          </span>
        </ReadOnlyBadge>
      );
    },
    size: 100,
  }),
  col.accessor('remarks', {
    header: 'Remarks',
    cell: i => i.getValue() || <span className="text-neutral-300">—</span>,
  }),
];

export default function PRDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [actionModal, setActionModal] = useState<'submit' | 'approve' | 'reject' | 'return' | null>(null);
  const [approvalLevel, setApprovalLevel] = useState('1');
  const [remarks, setRemarks] = useState('');

  const { data: pr, isLoading } = useQuery({
    queryKey: ['pr', id],
    queryFn: () => purchaseService.getPR(id!),
    enabled: !!id,
  });

  const submitMut = useMutation({
    mutationFn: () => purchaseService.submitPR(id!),
    onSuccess: updated => {
      qc.setQueryData(['pr', id], updated);
      qc.invalidateQueries({ queryKey: ['prs'] });
      toast.success('PR submitted for approval');
      setActionModal(null);
    },
    onError: () => toast.error('Submit failed'),
  });

  const approveMut = useMutation({
    mutationFn: ({ action, level }: { action: 'APPROVED' | 'REJECTED' | 'RETURNED'; level: number }) =>
      purchaseService.approvePR(id!, action, level, remarks),
    onSuccess: updated => {
      qc.setQueryData(['pr', id], updated);
      qc.invalidateQueries({ queryKey: ['prs'] });
      const msgs = { APPROVED: 'PR approved', REJECTED: 'PR rejected', RETURNED: 'PR returned for revision' };
      const action = actionModal === 'approve' ? 'APPROVED' : actionModal === 'reject' ? 'REJECTED' : 'RETURNED';
      toast.success(msgs[action]);
      setActionModal(null);
      setRemarks('');
    },
    onError: () => toast.error('Action failed'),
  });

  if (isLoading) return (
    <div className="flex items-center justify-center h-64"><LoadingSpinner size="xl" className="text-primary-600" /></div>
  );
  if (!pr) return <div className="text-center py-24 text-neutral-400">PR not found</div>;

  const pendingLevel = getPRApprovalLevel(pr.status);
  const canSubmit = pr.status === 'DRAFT';
  const canApprove = pr.status === 'SUBMITTED' || pr.status === 'HOD_APPROVED' || pr.status === 'PLANT_HEAD_APPROVED';
  const canEdit = pr.status === 'DRAFT';
  const priorityCfg = PRIORITY_CONFIG[pr.priority] ?? PRIORITY_CONFIG.NORMAL;

  const LEVEL_OPTIONS = [
    { value: '1', label: 'Level 1 — HOD' },
    { value: '2', label: 'Level 2 — Plant Head' },
    { value: '3', label: 'Level 3 — Director' },
  ];

  return (
    <div>
      {/* Header */}
      <div className="flex items-start justify-between mb-6 gap-4">
        <div className="flex items-start gap-3">
          <button onClick={() => navigate(-1)} className="p-2 mt-0.5 rounded-lg hover:bg-neutral-100 text-neutral-400">
            <ArrowLeftIcon className="h-5 w-5" />
          </button>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h1 className="text-xl font-bold text-neutral-900">{pr.pr_number}</h1>
              <Badge variant={PR_STATUS_VARIANT[pr.status] ?? 'neutral'} size="sm">
                {PR_STATUS_LABELS[pr.status] ?? pr.status}
              </Badge>
              <span className={cn('inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold border', priorityCfg.cls)}>
                {priorityCfg.label}
              </span>
            </div>
            <p className="text-sm text-neutral-500 mt-0.5">
              {formatDate(pr.pr_date)}
              {pr.required_date && ` · Required by ${formatDate(pr.required_date)}`}
              {pr.requested_by_name && ` · ${pr.requested_by_name}`}
              {pr.department_name && ` · ${pr.department_name}`}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0 flex-wrap justify-end">
          {canEdit && (
            <Button variant="outline" size="sm" leftIcon={<PencilIcon className="h-4 w-4" />}
              onClick={() => navigate(`/purchase/requisitions/${id}/edit`)}>Edit</Button>
          )}
          {canSubmit && (
            <Button size="sm" leftIcon={<PaperAirplaneIcon className="h-4 w-4" />}
              onClick={() => setActionModal('submit')}>Submit for Approval</Button>
          )}
          {canApprove && (
            <>
              <Button variant="outline" size="sm"
                className="text-warning-600 border-warning-300 hover:bg-warning-50"
                leftIcon={<ArrowUturnLeftIcon className="h-4 w-4" />}
                onClick={() => setActionModal('return')}>Return</Button>
              <Button variant="outline" size="sm"
                className="text-danger-500 border-danger-300 hover:bg-danger-50"
                leftIcon={<XCircleIcon className="h-4 w-4" />}
                onClick={() => setActionModal('reject')}>Reject</Button>
              <Button size="sm" leftIcon={<CheckCircleIcon className="h-4 w-4" />}
                onClick={() => setActionModal('approve')}>Approve</Button>
            </>
          )}
        </div>
      </div>

      {/* Summary stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
        {[
          { label: 'Lines', value: pr.lines?.length ?? pr.line_count ?? 0 },
          { label: 'Est. Value', value: pr.total_estimated_value ? formatCurrency(pr.total_estimated_value) : '—' },
          { label: 'Submitted', value: pr.submitted_at ? formatDate(pr.submitted_at) : '—' },
          { label: 'Approved', value: pr.final_approved_at ? formatDate(pr.final_approved_at) : '—' },
        ].map(s => (
          <div key={s.label} className="card py-3 px-4">
            <p className="text-xs text-neutral-400 mb-0.5">{s.label}</p>
            <p className="text-sm font-semibold text-neutral-800">{s.value}</p>
          </div>
        ))}
      </div>

      {/* Remarks */}
      {pr.remarks && (
        <div className="mb-4 p-3 bg-blue-50 border border-blue-100 rounded-lg">
          <p className="text-xs font-semibold text-blue-600 mb-0.5">Remarks</p>
          <p className="text-sm text-blue-800">{pr.remarks}</p>
        </div>
      )}

      {/* Line items */}
      <div className="card mb-6">
        <h3 className="text-sm font-semibold text-neutral-700 mb-4">Line Items</h3>
        <DataTable
          data={pr.lines ?? []}
          columns={LINE_COLUMNS}
          emptyTitle="No line items"
        />
      </div>

      {/* Approval timeline */}
      {(pr.approvals?.length || pendingLevel) && (
        <div className="card">
          <ApprovalTimeline
            approvals={pr.approvals}
            pendingLevel={pendingLevel ?? undefined}
            currentApproverName={pr.current_approver_name}
          />
        </div>
      )}

      {/* Submit modal */}
      <Modal open={actionModal === 'submit'} onClose={() => setActionModal(null)} title="Submit PR for Approval" size="sm"
        footer={<><Button variant="outline" onClick={() => setActionModal(null)}>Cancel</Button>
          <Button loading={submitMut.isPending} onClick={() => submitMut.mutate()}>Submit</Button></>}>
        <p className="text-sm text-neutral-600">
          Submit <strong>{pr.pr_number}</strong> for approval? The system will auto-populate last vendor/rate and current stock levels.
        </p>
      </Modal>

      {/* Approve modal */}
      <Modal open={actionModal === 'approve'} onClose={() => setActionModal(null)} title="Approve PR" size="sm"
        footer={<><Button variant="outline" onClick={() => setActionModal(null)}>Cancel</Button>
          <Button loading={approveMut.isPending}
            onClick={() => approveMut.mutate({ action: 'APPROVED', level: parseInt(approvalLevel) })}>
            Approve
          </Button></>}>
        <div className="space-y-3">
          <Select label="Approval Level" options={LEVEL_OPTIONS} value={approvalLevel}
            onChange={e => setApprovalLevel(e.target.value)} />
          <Textarea label="Remarks (optional)" rows={2} value={remarks} onChange={e => setRemarks(e.target.value)} />
        </div>
      </Modal>

      {/* Reject modal */}
      <Modal open={actionModal === 'reject'} onClose={() => setActionModal(null)} title="Reject PR" size="sm"
        footer={<><Button variant="outline" onClick={() => setActionModal(null)}>Cancel</Button>
          <Button variant="danger" loading={approveMut.isPending}
            onClick={() => approveMut.mutate({ action: 'REJECTED', level: parseInt(approvalLevel) })}>
            Reject
          </Button></>}>
        <div className="space-y-3">
          <Select label="Your Level" options={LEVEL_OPTIONS} value={approvalLevel}
            onChange={e => setApprovalLevel(e.target.value)} />
          <Textarea label="Rejection Reason" required rows={3} value={remarks}
            onChange={e => setRemarks(e.target.value)} placeholder="Provide reason…" />
        </div>
      </Modal>

      {/* Return modal */}
      <Modal open={actionModal === 'return'} onClose={() => setActionModal(null)} title="Return PR for Revision" size="sm"
        footer={<><Button variant="outline" onClick={() => setActionModal(null)}>Cancel</Button>
          <Button className="bg-warning-500 hover:bg-warning-600 text-white" loading={approveMut.isPending}
            onClick={() => approveMut.mutate({ action: 'RETURNED', level: parseInt(approvalLevel) })}>
            Return
          </Button></>}>
        <div className="space-y-3">
          <Select label="Your Level" options={LEVEL_OPTIONS} value={approvalLevel}
            onChange={e => setApprovalLevel(e.target.value)} />
          <Textarea label="Revision Instructions" required rows={3} value={remarks}
            onChange={e => setRemarks(e.target.value)} placeholder="What needs to be revised?" />
        </div>
      </Modal>
    </div>
  );
}
