import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { createColumnHelper } from '@tanstack/react-table';
import { PlusIcon, FunnelIcon } from '@heroicons/react/24/outline';

import { purchaseService, PRListItem } from '@/services/purchase';
import { PR_STATUS_LABELS, PR_STATUS_VARIANT, PRIORITY_CONFIG } from '@/utils/purchase';
import DataTable from '@/components/ui/DataTable';
import Badge from '@/components/ui/Badge';
import Button from '@/components/ui/Button';
import PageHeader from '@/components/ui/PageHeader';
import Tabs from '@/components/ui/Tabs';
import FilterPanel, { FilterSection, FilterRadioGroup } from '@/components/ui/FilterPanel';
import { usePagination } from '@/hooks/usePagination';
import { useDebounce } from '@/hooks/useDebounce';
import { formatDate, formatCurrency } from '@/utils/format';
import { cn } from '@/utils/cn';

const col = createColumnHelper<PRListItem>();

type ListMode = 'all' | 'mine' | 'pending_approval';

const PR_STATUS_OPTIONS = [
  { value: 'DRAFT', label: 'Draft' },
  { value: 'SUBMITTED', label: 'Submitted' },
  { value: 'HOD_APPROVED', label: 'HOD Approved' },
  { value: 'PLANT_HEAD_APPROVED', label: 'Plant Head Approved' },
  { value: 'DIRECTOR_APPROVED', label: 'Director Approved' },
  { value: 'REJECTED', label: 'Rejected' },
  { value: 'PO_CREATED', label: 'PO Created' },
];

const PRIORITY_OPTIONS = [
  { value: 'URGENT', label: 'Urgent' },
  { value: 'HIGH', label: 'High' },
  { value: 'NORMAL', label: 'Normal' },
  { value: 'LOW', label: 'Low' },
];

const COLUMNS = [
  col.accessor('pr_number', {
    header: 'PR Number',
    cell: i => <span className="font-mono text-xs font-semibold text-primary-800">{i.getValue()}</span>,
    size: 150,
  }),
  col.accessor('priority', {
    header: 'Priority',
    cell: i => {
      const cfg = PRIORITY_CONFIG[i.getValue()] ?? PRIORITY_CONFIG.NORMAL;
      return (
        <span className={cn('inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold border', cfg.cls)}>
          {cfg.label}
        </span>
      );
    },
    size: 90,
  }),
  col.accessor('pr_date', {
    header: 'PR Date',
    cell: i => formatDate(i.getValue()),
    size: 110,
  }),
  col.accessor('required_date', {
    header: 'Required By',
    cell: i => {
      const val = i.getValue();
      if (!val) return <span className="text-neutral-300">—</span>;
      const isOverdue = new Date(val) < new Date() && i.row.original.status !== 'PO_CREATED';
      return <span className={isOverdue ? 'text-danger-600 font-semibold' : ''}>{formatDate(val)}</span>;
    },
    size: 115,
  }),
  col.accessor('requested_by_name', {
    header: 'Requested By',
    cell: i => (
      <div>
        <p className="text-sm text-neutral-800">{i.getValue() ?? '—'}</p>
        {i.row.original.department_name && (
          <p className="text-xs text-neutral-400">{i.row.original.department_name}</p>
        )}
      </div>
    ),
  }),
  col.accessor('line_count', {
    header: 'Lines',
    cell: i => <span className="text-xs bg-neutral-100 text-neutral-600 px-2 py-0.5 rounded-full font-medium">{i.getValue()}</span>,
    size: 70,
  }),
  col.accessor('total_estimated_value', {
    header: 'Est. Value',
    cell: i => i.getValue() ? formatCurrency(i.getValue()!) : <span className="text-neutral-300">—</span>,
    size: 120,
  }),
  col.accessor('status', {
    header: 'Status',
    cell: i => (
      <Badge variant={PR_STATUS_VARIANT[i.getValue()] ?? 'neutral'} size="sm">
        {PR_STATUS_LABELS[i.getValue()] ?? i.getValue()}
      </Badge>
    ),
    size: 160,
  }),
];

const LIST_TABS = [
  { key: 'all', label: 'All PRs' },
  { key: 'mine', label: 'My PRs' },
  { key: 'pending_approval', label: 'Pending My Approval' },
];

export default function PRListPage() {
  const navigate = useNavigate();
  const { page, pageSize, offset, setPage, setPageSize } = usePagination();
  const [search, setSearch] = useState('');
  const debouncedSearch = useDebounce(search);
  const [mode, setMode] = useState<ListMode>('all');
  const [filterOpen, setFilterOpen] = useState(false);
  const [filters, setFilters] = useState({ status: '', priority: '' });

  const activeFilterCount = Object.values(filters).filter(Boolean).length;

  const { data, isLoading } = useQuery({
    queryKey: ['prs', mode, { offset, limit: pageSize, search: debouncedSearch, ...filters }],
    queryFn: () => {
      const params = {
        offset, limit: pageSize, search: debouncedSearch,
        ...(filters.status && { status: filters.status }),
        ...(filters.priority && { priority: filters.priority }),
      };
      if (mode === 'pending_approval') return purchaseService.getPendingPRApprovals(params);
      if (mode === 'mine') return purchaseService.getMyPRs(params);
      return purchaseService.getPRs(params);
    },
    placeholderData: prev => prev,
  });

  return (
    <div>
      <PageHeader
        title="Purchase Requisitions"
        description={`${data?.count ?? 0} requisitions`}
        actions={
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" leftIcon={<FunnelIcon className="h-4 w-4" />}
              onClick={() => setFilterOpen(f => !f)}
              className={activeFilterCount > 0 ? 'border-primary-600 text-primary-700' : ''}>
              Filters{activeFilterCount > 0 && ` (${activeFilterCount})`}
            </Button>
            <Button size="sm" leftIcon={<PlusIcon className="h-4 w-4" />}
              onClick={() => navigate('/purchase/requisitions/new')}>
              New PR
            </Button>
          </div>
        }
      />

      <Tabs tabs={LIST_TABS} active={mode} onChange={v => { setMode(v as ListMode); setPage(1); }}
        variant="pills" className="mb-4" />

      <div className="flex gap-4">
        <FilterPanel open={filterOpen} onClose={() => setFilterOpen(false)}
          onReset={() => setFilters({ status: '', priority: '' })} activeCount={activeFilterCount}>
          <FilterSection label="Status">
            <FilterRadioGroup options={PR_STATUS_OPTIONS} value={filters.status}
              onChange={v => { setFilters(f => ({ ...f, status: v })); setPage(1); }} />
          </FilterSection>
          <FilterSection label="Priority">
            <FilterRadioGroup options={PRIORITY_OPTIONS} value={filters.priority}
              onChange={v => { setFilters(f => ({ ...f, priority: v })); setPage(1); }} />
          </FilterSection>
        </FilterPanel>

        <div className="flex-1 min-w-0">
          <DataTable
            data={data?.results ?? []}
            columns={COLUMNS}
            totalCount={data?.count}
            page={page} pageSize={pageSize}
            onPageChange={setPage} onPageSizeChange={setPageSize}
            searchValue={search}
            onSearchChange={v => { setSearch(v); setPage(1); }}
            searchPlaceholder="Search PR number, requester…"
            loading={isLoading}
            onRowClick={row => navigate(`/purchase/requisitions/${row.id}`)}
            emptyTitle={mode === 'pending_approval' ? 'No pending approvals' : 'No requisitions found'}
            emptyAction={mode === 'all' ? { label: '+ New PR', onClick: () => navigate('/purchase/requisitions/new') } : undefined}
          />
        </div>
      </div>
    </div>
  );
}
