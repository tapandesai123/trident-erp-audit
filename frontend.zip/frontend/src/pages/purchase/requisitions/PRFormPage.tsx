import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useForm, useFieldArray, useController } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import toast from 'react-hot-toast';
import { ArrowLeftIcon, PlusIcon, TrashIcon } from '@heroicons/react/24/outline';

import { purchaseService } from '@/services/purchase';
import Button from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import Select from '@/components/ui/Select';
import DateInput from '@/components/ui/DateInput';
import Textarea from '@/components/ui/Textarea';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import ItemAutocomplete, { SelectedItem } from '@/components/purchase/ItemAutocomplete';
import { useUnsavedChanges } from '@/hooks/useUnsavedChanges';

const lineSchema = z.object({
  item_id: z.string().min(1, 'Item required'),
  item_code: z.string(),
  item_name: z.string(),
  uom_id: z.number(),
  uom_code: z.string(),
  quantity: z.coerce.number().min(0.001, 'Qty must be > 0'),
  estimated_rate: z.string().optional(),
  remarks: z.string(),
});

const prSchema = z.object({
  pr_date: z.string().min(1, 'PR date required'),
  required_date: z.string().optional(),
  priority: z.enum(['URGENT', 'HIGH', 'NORMAL', 'LOW']),
  remarks: z.string(),
  lines: z.array(lineSchema).min(1, 'At least one line item required'),
});

type PRFormValues = z.infer<typeof prSchema>;

const PRIORITY_OPTIONS = [
  { value: 'URGENT', label: 'Urgent' },
  { value: 'HIGH', label: 'High' },
  { value: 'NORMAL', label: 'Normal' },
  { value: 'LOW', label: 'Low' },
];

const DEFAULT_LINE = { item_id: '', item_code: '', item_name: '', uom_id: 0, uom_code: '', quantity: 1, estimated_rate: '', remarks: '' };

const DEFAULT_VALUES: PRFormValues = {
  pr_date: new Date().toISOString().split('T')[0],
  required_date: '',
  priority: 'NORMAL',
  remarks: '',
  lines: [{ ...DEFAULT_LINE }],
};

// Line row with item autocomplete wired to form
function LineRow({
  index, control, register, errors, remove, setValue,
}: {
  index: number;
  control: ReturnType<typeof useForm<PRFormValues>>['control'];
  register: ReturnType<typeof useForm<PRFormValues>>['register'];
  errors: ReturnType<typeof useForm<PRFormValues>>['formState']['errors'];
  remove: () => void;
  setValue: ReturnType<typeof useForm<PRFormValues>>['setValue'];
}) {
  const { field: itemField } = useController({ control, name: `lines.${index}.item_id` });
  const itemCode = (control._getWatch(`lines.${index}.item_code`) as string) ?? '';
  const itemName = (control._getWatch(`lines.${index}.item_name`) as string) ?? '';
  const uomCode = (control._getWatch(`lines.${index}.uom_code`) as string) ?? '';

  const currentItem: SelectedItem | null = itemField.value
    ? { id: itemField.value, code: itemCode, name: itemName, uom_id: 0, uom_code: uomCode, gst_rate: '18', item_type: '' }
    : null;

  const handleItemChange = (item: SelectedItem | null) => {
    itemField.onChange(item?.id ?? '');
    setValue(`lines.${index}.item_code`, item?.code ?? '');
    setValue(`lines.${index}.item_name`, item?.name ?? '');
    setValue(`lines.${index}.uom_id`, item?.uom_id ?? 0);
    setValue(`lines.${index}.uom_code`, item?.uom_code ?? '');
  };

  return (
    <div className="p-4 border border-neutral-100 rounded-xl bg-neutral-50 relative">
      <div className="flex items-center justify-between mb-3">
        <span className="text-xs font-semibold text-neutral-400 uppercase tracking-wide">Line {index + 1}</span>
        <button type="button" onClick={remove}
          className="text-danger-400 hover:text-danger-600 transition-colors">
          <TrashIcon className="h-4 w-4" />
        </button>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-12 gap-3">
        {/* Item selector — spans most of the row */}
        <div className="lg:col-span-5">
          <ItemAutocomplete
            label="Item"
            required
            value={currentItem}
            onChange={handleItemChange}
            error={errors.lines?.[index]?.item_id?.message}
          />
        </div>
        {/* UOM — auto-filled, read-only */}
        <div className="lg:col-span-2">
          <label className="form-label">UOM</label>
          <div className="form-input bg-neutral-100 text-neutral-500 text-sm cursor-default">
            {uomCode || <span className="text-neutral-300">—</span>}
          </div>
        </div>
        <div className="lg:col-span-2">
          <Input label="Quantity" required type="number" step="any" min="0.001"
            error={errors.lines?.[index]?.quantity?.message}
            {...register(`lines.${index}.quantity`, { valueAsNumber: true })} />
        </div>
        <div className="lg:col-span-3">
          <Input label="Est. Rate (₹)" type="number" step="any" min="0"
            placeholder="Optional"
            {...register(`lines.${index}.estimated_rate`)} />
        </div>
        <div className="lg:col-span-full">
          <Input label="Remarks" placeholder="Optional note for this line"
            {...register(`lines.${index}.remarks`)} />
        </div>
      </div>
    </div>
  );
}

export default function PRFormPage() {
  const { id } = useParams<{ id: string }>();
  const isEdit = !!id && id !== 'new';
  const navigate = useNavigate();
  const qc = useQueryClient();

  const { data: existing, isLoading: loadingExisting } = useQuery({
    queryKey: ['pr', id],
    queryFn: () => purchaseService.getPR(id!),
    enabled: isEdit,
  });

  const {
    register, handleSubmit, reset, control, setValue,
    formState: { errors, isDirty, isSubmitting },
  } = useForm<PRFormValues>({ resolver: zodResolver(prSchema), defaultValues: DEFAULT_VALUES });

  useUnsavedChanges(isDirty);

  const { fields, append, remove } = useFieldArray({ control, name: 'lines' });

  useEffect(() => {
    if (existing) {
      reset({
        pr_date: existing.pr_date,
        required_date: existing.required_date ?? '',
        priority: existing.priority,
        remarks: existing.remarks,
        lines: existing.lines.map(l => ({
          item_id: l.item,
          item_code: l.item_code ?? '',
          item_name: l.item_name ?? '',
          uom_id: l.uom ?? 0,
          uom_code: l.uom_code ?? '',
          quantity: parseFloat(String(l.quantity)),
          estimated_rate: l.estimated_rate ?? '',
          remarks: l.remarks,
        })),
      });
    }
  }, [existing, reset]);

  const mutation = useMutation({
    mutationFn: (data: PRFormValues) => {
      const payload = {
        pr_date: data.pr_date,
        required_date: data.required_date || null,
        priority: data.priority,
        remarks: data.remarks,
        lines: data.lines.map((l, i) => ({
          line_number: i + 1,
          item: l.item_id,
          uom: l.uom_id,
          quantity: l.quantity,
          estimated_rate: l.estimated_rate || null,
          remarks: l.remarks,
        })),
      };
      return isEdit ? purchaseService.updatePR(id!, payload) : purchaseService.createPR(payload);
    },
    onSuccess: saved => {
      qc.invalidateQueries({ queryKey: ['prs'] });
      qc.setQueryData(['pr', saved.id], saved);
      toast.success(isEdit ? 'PR updated' : 'PR created');
      navigate(`/purchase/requisitions/${saved.id}`);
    },
    onError: (err: unknown) => {
      const e = err as { response?: { data?: Record<string, string[]> } };
      const msg = e?.response?.data ? Object.values(e.response.data)[0]?.[0] : null;
      toast.error(msg ?? 'Save failed');
    },
  });

  if (isEdit && loadingExisting) return (
    <div className="flex items-center justify-center h-64"><LoadingSpinner size="xl" className="text-primary-600" /></div>
  );

  return (
    <div>
      <div className="flex items-center justify-between mb-6 gap-4">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate(-1)} className="p-2 rounded-lg hover:bg-neutral-100 text-neutral-400">
            <ArrowLeftIcon className="h-5 w-5" />
          </button>
          <h1 className="text-xl font-bold text-neutral-900">{isEdit ? 'Edit PR' : 'New Purchase Requisition'}</h1>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" type="button" onClick={() => navigate(-1)} disabled={isSubmitting}>Cancel</Button>
          <Button loading={isSubmitting} onClick={handleSubmit(d => mutation.mutate(d))}>
            {isEdit ? 'Save Changes' : 'Create PR'}
          </Button>
        </div>
      </div>

      <form onSubmit={handleSubmit(d => mutation.mutate(d))} noValidate>
        {/* Header fields */}
        <div className="card mb-4">
          <h3 className="text-sm font-semibold text-neutral-700 mb-4">PR Header</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <DateInput label="PR Date" required error={errors.pr_date?.message} {...register('pr_date')} />
            <DateInput label="Required By Date" error={errors.required_date?.message} {...register('required_date')} />
            <Select label="Priority" required options={PRIORITY_OPTIONS} {...register('priority')} />
            <div className="lg:col-span-1">
              <Textarea label="Remarks" rows={1} {...register('remarks')} placeholder="Optional" />
            </div>
          </div>
        </div>

        {/* Lines */}
        <div className="card mb-4">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-semibold text-neutral-700">Line Items</h3>
            {errors.lines?.root && (
              <p className="text-xs text-danger-500">{errors.lines.root.message}</p>
            )}
          </div>
          <div className="space-y-3">
            {fields.map((field, i) => (
              <LineRow
                key={field.id}
                index={i}
                control={control}
                register={register}
                errors={errors}
                remove={() => remove(i)}
                setValue={setValue}
              />
            ))}
          </div>
          <div className="mt-4">
            <Button type="button" variant="outline" size="sm" leftIcon={<PlusIcon className="h-4 w-4" />}
              onClick={() => append({ ...DEFAULT_LINE })}>
              Add Line Item
            </Button>
          </div>
        </div>

        <div className="flex justify-end gap-2 pb-4">
          <Button variant="outline" type="button" onClick={() => navigate(-1)} disabled={isSubmitting}>Cancel</Button>
          <Button type="submit" loading={isSubmitting}>{isEdit ? 'Save Changes' : 'Create PR'}</Button>
        </div>
      </form>
    </div>
  );
}
