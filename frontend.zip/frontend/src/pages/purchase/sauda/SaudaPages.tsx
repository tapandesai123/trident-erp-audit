/**
 * Vendor Sauda Pages — Bulk Purchase Agreement Management
 * Task 11 — Part 3.1
 */
import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useNavigate, useParams } from 'react-router-dom';
import { saudaService } from '@/services/mastersFull';

// ─── Utility Components ────────────────────────────────────────────

function StatusBadge({ status }: { status: string }) {
  const map: Record<string, string> = {
    ACTIVE: 'bg-green-100 text-green-800',
    EXHAUSTED: 'bg-red-100 text-red-800',
    EXPIRED: 'bg-gray-100 text-gray-700',
    CANCELLED: 'bg-orange-100 text-orange-700',
  };
  return (
    <span className={`px-2 py-0.5 rounded-full text-xs font-semibold ${map[status] || 'bg-gray-100 text-gray-700'}`}>
      {status}
    </span>
  );
}

function BalanceBadge({ pct }: { pct: number }) {
  const color = pct > 50 ? 'text-green-700' : pct > 20 ? 'text-amber-700' : 'text-red-700';
  return <span className={`font-semibold ${color}`}>{pct.toFixed(1)}% used</span>;
}

function LoadingSpinner() {
  return (
    <div className="flex items-center justify-center h-48">
      <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-blue-600" />
    </div>
  );
}

// ─── Sauda List Page ──────────────────────────────────────────────

export function SaudaListPage() {
  const navigate = useNavigate();
  const [filters, setFilters] = useState<Record<string, string>>({});

  const { data, isLoading } = useQuery({
    queryKey: ['sauda-list', filters],
    queryFn: () => saudaService.list(filters),
  });

  const saudas = data?.results ?? data ?? [];

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Vendor Sauda</h1>
          <p className="text-sm text-gray-500 mt-1">Bulk purchase agreements — track ordered vs balance qty</p>
        </div>
        <button
          onClick={() => navigate('/purchase/sauda/new')}
          className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium"
        >
          + Create Sauda
        </button>
      </div>

      {/* Filters */}
      <div className="flex gap-3 mb-4">
        <select
          value={filters.status ?? ''}
          onChange={e => setFilters(f => ({ ...f, status: e.target.value }))}
          className="border rounded-lg px-3 py-2 text-sm"
        >
          <option value="">All Status</option>
          <option value="ACTIVE">Active</option>
          <option value="EXHAUSTED">Exhausted</option>
          <option value="EXPIRED">Expired</option>
          <option value="CANCELLED">Cancelled</option>
        </select>
        <input
          type="text"
          placeholder="Search vendor / item..."
          className="border rounded-lg px-3 py-2 text-sm flex-1 max-w-xs"
          onChange={e => setFilters(f => ({ ...f, search: e.target.value }))}
        />
      </div>

      {isLoading ? (
        <LoadingSpinner />
      ) : (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                {['Sauda #', 'Vendor', 'Item', 'Agreed Qty', 'Ordered Qty', 'Balance', 'Rate (₹)', 'Valid To', 'Status', ''].map(h => (
                  <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {saudas.length === 0 && (
                <tr><td colSpan={9} className="text-center py-10 text-gray-400">No saudas found</td></tr>
              )}
              {saudas.map((s: any) => (
                <tr key={s.id} className="hover:bg-gray-50 cursor-pointer" onClick={() => navigate(`/purchase/sauda/${s.id}`)}>
                  <td className="px-4 py-3 text-sm font-mono text-blue-600">{s.sauda_number}</td>
                  <td className="px-4 py-3 text-sm">{s.vendor_name}</td>
                  <td className="px-4 py-3 text-sm font-mono">{s.item_code}</td>
                  <td className="px-4 py-3 text-sm text-right">{Number(s.agreed_qty).toLocaleString()} {s.uom_name}</td>
                  <td className="px-4 py-3 text-sm text-right">{Number(s.ordered_qty).toLocaleString()}</td>
                  <td className="px-4 py-3 text-sm text-right">
                    {Number(s.balance_qty).toLocaleString()}
                    <br /><BalanceBadge pct={s.utilization_pct ?? 0} />
                  </td>
                  <td className="px-4 py-3 text-sm text-right">₹{Number(s.agreed_rate).toFixed(2)}</td>
                  <td className="px-4 py-3 text-sm">{s.valid_to}</td>
                  <td className="px-4 py-3"><StatusBadge status={s.status} /></td>
                  <td className="px-4 py-3 text-xs text-blue-500">View →</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

// ─── Sauda Form Page ──────────────────────────────────────────────

export function SaudaFormPage() {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [form, setForm] = useState({
    sauda_number: '', vendor: '', item: '', agreed_qty: '',
    agreed_rate: '', uom: '', valid_from: '', valid_to: '',
    tolerance_pct: '5', terms: '',
  });

  const createMutation = useMutation({
    mutationFn: (data: unknown) => saudaService.create(data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['sauda-list'] });
      navigate('/purchase/sauda');
    },
  });

  const set = (k: string, v: string) => setForm(f => ({ ...f, [k]: v }));

  return (
    <div className="p-6 max-w-2xl">
      <h1 className="text-2xl font-bold text-gray-900 mb-6">New Vendor Sauda</h1>

      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Sauda Number</label>
            <input className="w-full border rounded-lg px-3 py-2 text-sm"
              placeholder="Auto-generated if blank"
              value={form.sauda_number} onChange={e => set('sauda_number', e.target.value)} />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Vendor ID</label>
            <input className="w-full border rounded-lg px-3 py-2 text-sm"
              placeholder="Vendor ID"
              value={form.vendor} onChange={e => set('vendor', e.target.value)} />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Item ID</label>
            <input className="w-full border rounded-lg px-3 py-2 text-sm"
              placeholder="Item ID"
              value={form.item} onChange={e => set('item', e.target.value)} />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">UOM ID</label>
            <input className="w-full border rounded-lg px-3 py-2 text-sm"
              value={form.uom} onChange={e => set('uom', e.target.value)} />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Agreed Qty</label>
            <input type="number" className="w-full border rounded-lg px-3 py-2 text-sm"
              value={form.agreed_qty} onChange={e => set('agreed_qty', e.target.value)} />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Rate (₹)</label>
            <input type="number" step="0.01" className="w-full border rounded-lg px-3 py-2 text-sm"
              value={form.agreed_rate} onChange={e => set('agreed_rate', e.target.value)} />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Valid From</label>
            <input type="date" className="w-full border rounded-lg px-3 py-2 text-sm"
              value={form.valid_from} onChange={e => set('valid_from', e.target.value)} />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Valid To</label>
            <input type="date" className="w-full border rounded-lg px-3 py-2 text-sm"
              value={form.valid_to} onChange={e => set('valid_to', e.target.value)} />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Tolerance %</label>
            <input type="number" step="0.1" className="w-full border rounded-lg px-3 py-2 text-sm"
              value={form.tolerance_pct} onChange={e => set('tolerance_pct', e.target.value)} />
          </div>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Terms</label>
          <textarea className="w-full border rounded-lg px-3 py-2 text-sm" rows={3}
            value={form.terms} onChange={e => set('terms', e.target.value)} />
        </div>

        {createMutation.isError && (
          <div className="bg-red-50 text-red-700 p-3 rounded-lg text-sm">
            Failed to create sauda. Please check all fields.
          </div>
        )}

        <div className="flex gap-3 pt-2">
          <button
            onClick={() => createMutation.mutate(form)}
            disabled={createMutation.isPending}
            className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium disabled:opacity-50"
          >
            {createMutation.isPending ? 'Creating...' : 'Create Sauda'}
          </button>
          <button onClick={() => navigate('/purchase/sauda')}
            className="px-6 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── Sauda Detail Page ────────────────────────────────────────────

export function SaudaDetailPage() {
  const { id } = useParams<{ id: string }>();
  const [activeTab, setActiveTab] = useState<'pending' | 'po_history'>('pending');

  const { data: sauda, isLoading } = useQuery({
    queryKey: ['sauda', id],
    queryFn: () => saudaService.get(id!),
    enabled: !!id,
  });

  const { data: pendingReport } = useQuery({
    queryKey: ['sauda-pending', id],
    queryFn: () => saudaService.pendingReport(id!),
    enabled: !!id,
  });

  const { data: poHistory } = useQuery({
    queryKey: ['sauda-po-history', id],
    queryFn: () => saudaService.poHistory(id!),
    enabled: !!id && activeTab === 'po_history',
  });

  if (isLoading) return <LoadingSpinner />;
  if (!sauda) return <div className="p-6 text-red-500">Sauda not found</div>;

  const utilPct = sauda.utilization_pct ?? 0;
  const daysLeft = sauda.valid_to
    ? Math.ceil((new Date(sauda.valid_to).getTime() - Date.now()) / 86400000)
    : null;

  return (
    <div className="p-6 max-w-4xl">
      {/* Header */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-6">
        <div className="flex items-start justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">{sauda.sauda_number}</h1>
            <p className="text-gray-500 mt-1">{sauda.vendor_name} — {sauda.item_code}</p>
          </div>
          <StatusBadge status={sauda.status} />
        </div>

        <div className="mt-4">
          <div className="flex justify-between text-sm text-gray-600 mb-1">
            <span>Utilization: {utilPct.toFixed(1)}%</span>
            <span>{Number(sauda.ordered_qty).toLocaleString()} / {Number(sauda.agreed_qty).toLocaleString()} {sauda.uom_name}</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-3">
            <div
              className={`h-3 rounded-full transition-all ${utilPct > 80 ? 'bg-red-500' : utilPct > 50 ? 'bg-amber-500' : 'bg-green-500'}`}
              style={{ width: `${Math.min(utilPct, 100)}%` }}
            />
          </div>
        </div>

        <div className="grid grid-cols-4 gap-4 mt-4">
          <div className="bg-blue-50 rounded-lg p-3 text-center">
            <div className="text-xl font-bold text-blue-700">₹{Number(sauda.agreed_rate).toFixed(2)}</div>
            <div className="text-xs text-gray-500">Agreed Rate</div>
          </div>
          <div className="bg-green-50 rounded-lg p-3 text-center">
            <div className="text-xl font-bold text-green-700">{Number(sauda.balance_qty).toLocaleString()}</div>
            <div className="text-xs text-gray-500">Balance Qty</div>
          </div>
          <div className="bg-purple-50 rounded-lg p-3 text-center">
            <div className="text-xl font-bold text-purple-700">₹{Number(sauda.balance_value ?? 0).toLocaleString()}</div>
            <div className="text-xs text-gray-500">Balance Value</div>
          </div>
          <div className={`rounded-lg p-3 text-center ${daysLeft !== null && daysLeft < 30 ? 'bg-red-50' : 'bg-gray-50'}`}>
            <div className={`text-xl font-bold ${daysLeft !== null && daysLeft < 30 ? 'text-red-700' : 'text-gray-700'}`}>
              {daysLeft !== null ? `${daysLeft}d` : 'N/A'}
            </div>
            <div className="text-xs text-gray-500">Days Left</div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <div className="flex border-b">
          {(['pending', 'po_history'] as const).map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-6 py-3 text-sm font-medium border-b-2 transition-colors ${
                activeTab === tab ? 'border-blue-600 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              {tab === 'pending' ? 'Pending Balance' : 'PO History'}
            </button>
          ))}
        </div>

        <div className="p-6">
          {activeTab === 'pending' && pendingReport && (
            <div>
              {utilPct < 10 && (
                <div className="bg-red-50 border border-red-200 rounded-lg p-3 mb-4 text-red-700 text-sm">
                  ⚠️ Less than 10% balance remaining on this sauda. Consider creating a new agreement.
                </div>
              )}
              <dl className="grid grid-cols-2 gap-4">
                {[
                  ['Agreed Qty', `${pendingReport.agreed_qty} ${sauda.uom_name}`],
                  ['Ordered Qty', `${pendingReport.ordered_qty} ${sauda.uom_name}`],
                  ['Received Qty', `${pendingReport.received_qty} ${sauda.uom_name}`],
                  ['Balance Qty', `${pendingReport.balance_qty} ${sauda.uom_name}`],
                  ['Balance Value', `₹${Number(pendingReport.balance_value).toLocaleString()}`],
                  ['Utilization', `${pendingReport.utilization_pct}%`],
                ].map(([label, val]) => (
                  <div key={label} className="bg-gray-50 rounded-lg p-3">
                    <dt className="text-xs text-gray-500">{label}</dt>
                    <dd className="text-base font-semibold mt-0.5">{val}</dd>
                  </div>
                ))}
              </dl>
            </div>
          )}

          {activeTab === 'po_history' && (
            <table className="min-w-full text-sm">
              <thead>
                <tr className="border-b">
                  {['PO Number', 'Date', 'Item', 'Qty', 'Status'].map(h => (
                    <th key={h} className="text-left text-xs font-semibold text-gray-600 pb-2 pr-4">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {(poHistory ?? []).length === 0 && (
                  <tr><td colSpan={5} className="py-6 text-center text-gray-400">No POs yet</td></tr>
                )}
                {(poHistory ?? []).map((po: any, i: number) => (
                  <tr key={i} className="hover:bg-gray-50">
                    <td className="py-2 pr-4 font-mono text-blue-600">{po.po_number}</td>
                    <td className="py-2 pr-4">{po.po_date}</td>
                    <td className="py-2 pr-4">{po.item_code}</td>
                    <td className="py-2 pr-4 text-right">{po.qty}</td>
                    <td className="py-2"><StatusBadge status={po.po_status} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
}
