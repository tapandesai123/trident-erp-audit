/**
 * RGP Challan Pages — Returnable Gate Pass (Job Worker Repair)
 * Task 11 — Part 3.2
 */
import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useNavigate, useParams } from 'react-router-dom';
import { rgpService } from '@/services/mastersFull';

function StatusBadge({ status }: { status: string }) {
  const map: Record<string, string> = {
    DRAFT: 'bg-gray-100 text-gray-700',
    SENT: 'bg-blue-100 text-blue-800',
    PARTIAL: 'bg-amber-100 text-amber-800',
    RETURNED: 'bg-green-100 text-green-800',
    OVERDUE: 'bg-red-100 text-red-800',
  };
  return (
    <span className={`px-2 py-0.5 rounded-full text-xs font-semibold ${map[status] || 'bg-gray-100 text-gray-700'}`}>
      {status}
    </span>
  );
}

const STATUS_TIMELINE = ['DRAFT', 'SENT', 'PARTIAL', 'RETURNED'];

// ─── RGP List Page ────────────────────────────────────────────────

export function RGPListPage() {
  const navigate = useNavigate();
  const [filters, setFilters] = useState<Record<string, string>>({});

  const { data, isLoading } = useQuery({
    queryKey: ['rgp-list', filters],
    queryFn: () => rgpService.list(filters),
  });
  const { data: pendingReturns } = useQuery({
    queryKey: ['rgp-pending-returns'],
    queryFn: () => rgpService.pendingReturns(),
  });

  const rgps = data?.results ?? data ?? [];
  const today = new Date();

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Job Worker RGP</h1>
          <p className="text-sm text-gray-500 mt-1">Returnable Gate Pass for equipment sent for repair</p>
        </div>
        <button
          onClick={() => navigate('/purchase/rgp/new')}
          className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium"
        >
          + New RGP
        </button>
      </div>

      {/* Overdue Alert */}
      {(pendingReturns ?? []).length > 0 && (
        <div className="bg-red-50 border border-red-200 rounded-xl p-4 mb-4 flex items-center gap-3">
          <span className="text-red-600 text-xl">⚠️</span>
          <div>
            <p className="text-red-700 font-semibold">{pendingReturns.length} RGP(s) overdue for return</p>
            <p className="text-red-600 text-sm">Please follow up with job workers immediately.</p>
          </div>
        </div>
      )}

      {/* Filters */}
      <div className="flex gap-3 mb-4">
        <select
          value={filters.status ?? ''}
          onChange={e => setFilters(f => ({ ...f, status: e.target.value }))}
          className="border rounded-lg px-3 py-2 text-sm"
        >
          <option value="">All Status</option>
          <option value="DRAFT">Draft</option>
          <option value="SENT">Sent</option>
          <option value="PARTIAL">Partially Returned</option>
          <option value="RETURNED">Fully Returned</option>
          <option value="OVERDUE">Overdue</option>
        </select>
        <input
          type="text"
          placeholder="Search vendor / RGP#..."
          className="border rounded-lg px-3 py-2 text-sm flex-1 max-w-xs"
          onChange={e => setFilters(f => ({ ...f, search: e.target.value }))}
        />
      </div>

      {isLoading ? (
        <div className="flex justify-center py-16"><div className="animate-spin rounded-full h-10 w-10 border-b-2 border-blue-600" /></div>
      ) : (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                {['RGP #', 'Vendor', 'Challan Date', 'Expected Return', 'Items', 'Status', 'Days Overdue', ''].map(h => (
                  <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {rgps.length === 0 && (
                <tr><td colSpan={8} className="text-center py-10 text-gray-400">No RGP challans found</td></tr>
              )}
              {rgps.map((r: any) => {
                const daysOverdue = r.expected_return
                  ? Math.max(0, Math.ceil((today.getTime() - new Date(r.expected_return).getTime()) / 86400000))
                  : 0;
                const isOverdue = daysOverdue > 0 && r.status !== 'RETURNED';
                return (
                  <tr key={r.id} className="hover:bg-gray-50 cursor-pointer" onClick={() => navigate(`/purchase/rgp/${r.id}`)}>
                    <td className="px-4 py-3 text-sm font-mono text-blue-600">{r.rgp_number}</td>
                    <td className="px-4 py-3 text-sm">{r.vendor_name}</td>
                    <td className="px-4 py-3 text-sm">{r.challan_date}</td>
                    <td className="px-4 py-3 text-sm">{r.expected_return}</td>
                    <td className="px-4 py-3 text-sm text-center">{r.lines?.length ?? 0}</td>
                    <td className="px-4 py-3"><StatusBadge status={r.status} /></td>
                    <td className="px-4 py-3 text-sm">
                      {isOverdue ? (
                        <span className="text-red-600 font-semibold">{daysOverdue}d overdue</span>
                      ) : (
                        <span className="text-gray-400">—</span>
                      )}
                    </td>
                    <td className="px-4 py-3 text-xs text-blue-500">View →</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

// ─── RGP Form Page ────────────────────────────────────────────────

interface RGPLine {
  item: string;
  asset_tag: string;
  sent_qty: string;
  uom: string;
  description: string;
}

export function RGPFormPage() {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [header, setHeader] = useState({
    vendor: '', challan_date: '', expected_return: '', job_work_po: '', transport_details: '', remarks: '',
  });
  const [lines, setLines] = useState<RGPLine[]>([
    { item: '', asset_tag: '', sent_qty: '', uom: '', description: '' },
  ]);

  const setH = (k: string, v: string) => setHeader(h => ({ ...h, [k]: v }));
  const setL = (idx: number, k: string, v: string) => setLines(ls => ls.map((l, i) => i === idx ? { ...l, [k]: v } : l));
  const addLine = () => setLines(ls => [...ls, { item: '', asset_tag: '', sent_qty: '', uom: '', description: '' }]);
  const removeLine = (idx: number) => setLines(ls => ls.filter((_, i) => i !== idx));

  const createMutation = useMutation({
    mutationFn: (data: unknown) => rgpService.create(data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['rgp-list'] });
      navigate('/purchase/rgp');
    },
  });

  const handleSubmit = () => {
    createMutation.mutate({ ...header, lines });
  };

  return (
    <div className="p-6 max-w-3xl">
      <h1 className="text-2xl font-bold text-gray-900 mb-6">New RGP Challan</h1>

      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 space-y-4">
        <h2 className="font-semibold text-gray-700">Challan Details</h2>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Vendor (Job Worker)</label>
            <input className="w-full border rounded-lg px-3 py-2 text-sm"
              placeholder="Vendor ID"
              value={header.vendor} onChange={e => setH('vendor', e.target.value)} />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Challan Date</label>
            <input type="date" className="w-full border rounded-lg px-3 py-2 text-sm"
              value={header.challan_date} onChange={e => setH('challan_date', e.target.value)} />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Expected Return Date</label>
            <input type="date" className="w-full border rounded-lg px-3 py-2 text-sm"
              value={header.expected_return} onChange={e => setH('expected_return', e.target.value)} />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Job Work PO (optional)</label>
            <input className="w-full border rounded-lg px-3 py-2 text-sm"
              placeholder="PO ID"
              value={header.job_work_po} onChange={e => setH('job_work_po', e.target.value)} />
          </div>
          <div className="col-span-2">
            <label className="block text-sm font-medium text-gray-700 mb-1">Transport Details</label>
            <input className="w-full border rounded-lg px-3 py-2 text-sm"
              value={header.transport_details} onChange={e => setH('transport_details', e.target.value)} />
          </div>
        </div>

        <h2 className="font-semibold text-gray-700 pt-2">Items to Send</h2>
        <div className="space-y-3">
          {lines.map((line, idx) => (
            <div key={idx} className="grid grid-cols-5 gap-2 items-center p-3 bg-gray-50 rounded-lg">
              <input className="border rounded px-2 py-1.5 text-sm" placeholder="Item ID"
                value={line.item} onChange={e => setL(idx, 'item', e.target.value)} />
              <input className="border rounded px-2 py-1.5 text-sm" placeholder="Asset Tag / Serial"
                value={line.asset_tag} onChange={e => setL(idx, 'asset_tag', e.target.value)} />
              <input type="number" className="border rounded px-2 py-1.5 text-sm" placeholder="Qty"
                value={line.sent_qty} onChange={e => setL(idx, 'sent_qty', e.target.value)} />
              <input className="border rounded px-2 py-1.5 text-sm" placeholder="Nature of repair"
                value={line.description} onChange={e => setL(idx, 'description', e.target.value)} />
              <button onClick={() => removeLine(idx)} className="text-red-500 hover:text-red-700 text-sm">✕ Remove</button>
            </div>
          ))}
          <button onClick={addLine} className="text-sm text-blue-600 hover:text-blue-800">+ Add Item</button>
        </div>

        {createMutation.isError && (
          <div className="bg-red-50 text-red-700 p-3 rounded-lg text-sm">Failed to create RGP. Check all required fields.</div>
        )}

        <div className="flex gap-3 pt-2">
          <button
            onClick={handleSubmit}
            disabled={createMutation.isPending}
            className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium disabled:opacity-50"
          >
            {createMutation.isPending ? 'Creating...' : 'Create RGP Challan'}
          </button>
          <button onClick={() => navigate('/purchase/rgp')}
            className="px-6 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── RGP Detail Page ──────────────────────────────────────────────

export function RGPDetailPage() {
  const { id } = useParams<{ id: string }>();
  const qc = useQueryClient();
  const [showReturnModal, setShowReturnModal] = useState(false);
  const [mrrId, setMrrId] = useState('');

  const { data: rgp, isLoading } = useQuery({
    queryKey: ['rgp', id],
    queryFn: () => rgpService.get(id!),
    enabled: !!id,
  });

  const sendOutMutation = useMutation({
    mutationFn: () => rgpService.sendOut(id!),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['rgp', id] }),
  });

  const returnMutation = useMutation({
    mutationFn: () => rgpService.markReturned(id!, mrrId),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['rgp', id] });
      setShowReturnModal(false);
    },
  });

  if (isLoading) return <div className="flex justify-center py-16"><div className="animate-spin rounded-full h-10 w-10 border-b-2 border-blue-600" /></div>;
  if (!rgp) return <div className="p-6 text-red-500">RGP not found</div>;

  const currentStepIdx = STATUS_TIMELINE.indexOf(rgp.status);

  return (
    <div className="p-6 max-w-4xl">
      {/* Header */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-6">
        <div className="flex items-start justify-between mb-4">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">{rgp.rgp_number}</h1>
            <p className="text-gray-500 mt-1">{rgp.vendor_name} — Expected Return: {rgp.expected_return}</p>
          </div>
          <StatusBadge status={rgp.status} />
        </div>

        {/* Status Timeline */}
        <div className="flex items-center gap-0 mt-4">
          {STATUS_TIMELINE.map((step, idx) => (
            <React.Fragment key={step}>
              <div className={`flex-none flex flex-col items-center`}>
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${
                  idx <= currentStepIdx ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-400'
                }`}>
                  {idx <= currentStepIdx ? '✓' : idx + 1}
                </div>
                <span className="text-xs mt-1 text-gray-600">{step}</span>
              </div>
              {idx < STATUS_TIMELINE.length - 1 && (
                <div className={`flex-1 h-0.5 mx-2 mb-4 ${idx < currentStepIdx ? 'bg-blue-600' : 'bg-gray-200'}`} />
              )}
            </React.Fragment>
          ))}
        </div>

        {/* Actions */}
        <div className="flex gap-3 mt-4">
          {rgp.status === 'DRAFT' && (
            <button
              onClick={() => sendOutMutation.mutate()}
              disabled={sendOutMutation.isPending}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700"
            >
              Send Out to Job Worker
            </button>
          )}
          {['SENT', 'PARTIAL'].includes(rgp.status) && (
            <button
              onClick={() => setShowReturnModal(true)}
              className="px-4 py-2 bg-green-600 text-white rounded-lg text-sm font-medium hover:bg-green-700"
            >
              Return Against MRR
            </button>
          )}
        </div>
      </div>

      {/* Lines Table */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h2 className="font-semibold text-gray-700 mb-4">Items</h2>
        <table className="min-w-full text-sm">
          <thead>
            <tr className="border-b">
              {['Item Code', 'Description', 'Asset Tag', 'Sent Qty', 'Returned Qty', 'Pending Qty'].map(h => (
                <th key={h} className="text-left text-xs font-semibold text-gray-600 pb-2 pr-4">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {(rgp.lines ?? []).map((line: any, idx: number) => (
              <tr key={idx}>
                <td className="py-2 pr-4 font-mono">{line.item_code}</td>
                <td className="py-2 pr-4">{line.description || '—'}</td>
                <td className="py-2 pr-4">{line.asset_tag || '—'}</td>
                <td className="py-2 pr-4 text-right">{line.sent_qty}</td>
                <td className="py-2 pr-4 text-right text-green-600">{line.returned_qty}</td>
                <td className="py-2 pr-4 text-right font-semibold"
                    style={{ color: Number(line.pending_qty) > 0 ? '#dc2626' : '#16a34a' }}>
                  {line.pending_qty}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Return Modal */}
      {showReturnModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-6 w-full max-w-md shadow-xl">
            <h2 className="text-lg font-bold mb-4">Return Against MRR</h2>
            <p className="text-sm text-gray-600 mb-4">Enter the MRR ID that corresponds to the returned goods.</p>
            <input
              className="w-full border rounded-lg px-3 py-2 text-sm mb-4"
              placeholder="MRR ID"
              value={mrrId}
              onChange={e => setMrrId(e.target.value)}
            />
            {returnMutation.isError && (
              <div className="bg-red-50 text-red-700 p-3 rounded-lg text-sm mb-3">Reconciliation failed.</div>
            )}
            <div className="flex gap-3">
              <button
                onClick={() => returnMutation.mutate()}
                disabled={!mrrId || returnMutation.isPending}
                className="flex-1 py-2 bg-green-600 text-white rounded-lg font-medium disabled:opacity-50"
              >
                {returnMutation.isPending ? 'Processing...' : 'Reconcile'}
              </button>
              <button onClick={() => setShowReturnModal(false)}
                className="flex-1 py-2 border border-gray-300 rounded-lg">
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
