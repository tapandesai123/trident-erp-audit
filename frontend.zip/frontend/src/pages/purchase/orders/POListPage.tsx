import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { createColumnHelper } from '@tanstack/react-table';
import { PlusIcon, FunnelIcon } from '@heroicons/react/24/outline';

import { purchaseService, POListItem } from '@/services/purchase';
import { PO_STATUS_LABELS, PO_STATUS_VARIANT, RECEIPT_PCT_COLOR } from '@/utils/purchase';
import DataTable from '@/components/ui/DataTable';
import Badge from '@/components/ui/Badge';
import Button from '@/components/ui/Button';
import PageHeader from '@/components/ui/PageHeader';
import FilterPanel, { FilterSection, FilterRadioGroup } from '@/components/ui/FilterPanel';
import DateInput from '@/components/ui/DateInput';
import { usePagination } from '@/hooks/usePagination';
import { useDebounce } from '@/hooks/useDebounce';
import { formatDate, formatCurrency } from '@/utils/format';
import { cn } from '@/utils/cn';

const col = createColumnHelper<POListItem>();

const PO_STATUS_OPTIONS = [
  { value: 'DRAFT', label: 'Draft' },
  { value: 'SUBMITTED', label: 'Submitted' },
  { value: 'ACCOUNTS_CHECKED', label: 'Accounts Checked' },
  { value: 'APPROVED', label: 'Approved' },
  { value: 'PARTIALLY_RECEIVED', label: 'Partial Receipt' },
  { value: 'FULLY_RECEIVED', label: 'Fully Received' },
  { value: 'CANCELLED', label: 'Cancelled' },
];

const PO_TYPE_OPTIONS = [
  { value: 'FIXED_QTY', label: 'Fixed Qty' },
  { value: 'JOB_WORK', label: 'Job Work' },
  { value: 'SERVICE', label: 'Service' },
  { value: 'CAPITAL_GOODS', label: 'Capital Goods' },
  { value: 'IMPORT', label: 'Import' },
];

const COLUMNS = [
  col.accessor('po_number', {
    header: 'PO Number',
    cell: i => (
      <div>
        <span className="font-mono text-xs font-semibold text-primary-800">{i.getValue()}</span>
        {i.row.original.pr_number && (
          <p className="text-xs text-neutral-400">PR: {i.row.original.pr_number}</p>
        )}
      </div>
    ),
    size: 160,
  }),
  col.accessor('vendor_name', {
    header: 'Vendor',
    cell: i => i.getValue() ?? <span className="text-neutral-300">—</span>,
  }),
  col.accessor('po_date', {
    header: 'Date',
    cell: i => formatDate(i.getValue()),
    size: 110,
  }),
  col.accessor('po_type', {
    header: 'Type',
    cell: i => {
      const labels: Record<string, string> = {
        FIXED_QTY: 'Fixed Qty', JOB_WORK: 'Job Work', SERVICE: 'Service',
        CAPITAL_GOODS: 'Capital', IMPORT: 'Import',
      };
      return <Badge variant="neutral" size="sm">{labels[i.getValue()] ?? i.getValue()}</Badge>;
    },
    size: 100,
  }),
  col.accessor('total_amount', {
    header: 'Amount',
    cell: i => <span className="font-medium font-mono text-sm">{formatCurrency(i.getValue())}</span>,
    size: 130,
  }),
  col.accessor('receipt_percentage', {
    header: 'Receipt',
    cell: i => {
      const pct = i.getValue() ?? 0;
      return (
        <div className="flex items-center gap-2">
          <div className="w-16 h-1.5 bg-neutral-100 rounded-full overflow-hidden">
            <div
              className={cn('h-full rounded-full transition-all', pct >= 100 ? 'bg-success-500' : pct >= 50 ? 'bg-warning-500' : 'bg-primary-400')}
              style={{ width: `${Math.min(pct, 100)}%` }}
            />
          </div>
          <span className={cn('text-xs font-medium', RECEIPT_PCT_COLOR(pct))}>{pct.toFixed(0)}%</span>
        </div>
      );
    },
    size: 110,
  }),
  col.accessor('status', {
    header: 'Status',
    cell: i => (
      <Badge variant={PO_STATUS_VARIANT[i.getValue()] ?? 'neutral'} size="sm">
        {PO_STATUS_LABELS[i.getValue()] ?? i.getValue()}
      </Badge>
    ),
    size: 140,
  }),
];

export default function POListPage() {
  const navigate = useNavigate();
  const { page, pageSize, offset, setPage, setPageSize } = usePagination();
  const [search, setSearch] = useState('');
  const debouncedSearch = useDebounce(search);
  const [filterOpen, setFilterOpen] = useState(false);
  const [filters, setFilters] = useState({ status: '', po_type: '', po_date_from: '', po_date_to: '' });

  const activeFilterCount = [filters.status, filters.po_type, filters.po_date_from || filters.po_date_to].filter(Boolean).length;

  const { data, isLoading } = useQuery({
    queryKey: ['pos', { offset, limit: pageSize, search: debouncedSearch, ...filters }],
    queryFn: () => purchaseService.getPOs({
      offset, limit: pageSize, search: debouncedSearch,
      ...(filters.status && { status: filters.status }),
      ...(filters.po_type && { po_type: filters.po_type }),
      ...(filters.po_date_from && { po_date_from: filters.po_date_from }),
      ...(filters.po_date_to && { po_date_to: filters.po_date_to }),
    }),
    placeholderData: prev => prev,
  });

  return (
    <div>
      <PageHeader
        title="Purchase Orders"
        description={`${data?.count ?? 0} orders`}
        actions={
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" leftIcon={<FunnelIcon className="h-4 w-4" />}
              onClick={() => setFilterOpen(f => !f)}
              className={activeFilterCount > 0 ? 'border-primary-600 text-primary-700' : ''}>
              Filters{activeFilterCount > 0 && ` (${activeFilterCount})`}
            </Button>
            <Button size="sm" leftIcon={<PlusIcon className="h-4 w-4" />}
              onClick={() => navigate('/purchase/orders/new')}>
              New PO
            </Button>
          </div>
        }
      />

      <div className="flex gap-4">
        <FilterPanel open={filterOpen} onClose={() => setFilterOpen(false)}
          onReset={() => setFilters({ status: '', po_type: '', po_date_from: '', po_date_to: '' })}
          activeCount={activeFilterCount}>
          <FilterSection label="Status">
            <FilterRadioGroup options={PO_STATUS_OPTIONS} value={filters.status}
              onChange={v => { setFilters(f => ({ ...f, status: v })); setPage(1); }} />
          </FilterSection>
          <FilterSection label="PO Type">
            <FilterRadioGroup options={PO_TYPE_OPTIONS} value={filters.po_type}
              onChange={v => { setFilters(f => ({ ...f, po_type: v })); setPage(1); }} />
          </FilterSection>
          <FilterSection label="Date Range">
            <div className="space-y-2">
              <DateInput label="From" value={filters.po_date_from}
                onChange={e => { setFilters(f => ({ ...f, po_date_from: e.target.value })); setPage(1); }} />
              <DateInput label="To" value={filters.po_date_to}
                onChange={e => { setFilters(f => ({ ...f, po_date_to: e.target.value })); setPage(1); }} />
            </div>
          </FilterSection>
        </FilterPanel>

        <div className="flex-1 min-w-0">
          <DataTable
            data={data?.results ?? []}
            columns={COLUMNS}
            totalCount={data?.count}
            page={page} pageSize={pageSize}
            onPageChange={setPage} onPageSizeChange={setPageSize}
            searchValue={search}
            onSearchChange={v => { setSearch(v); setPage(1); }}
            searchPlaceholder="Search PO number, vendor…"
            loading={isLoading}
            onRowClick={row => navigate(`/purchase/orders/${row.id}`)}
            emptyTitle="No purchase orders"
            emptyAction={{ label: '+ New PO', onClick: () => navigate('/purchase/orders/new') }}
          />
        </div>
      </div>
    </div>
  );
}
