import { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { createColumnHelper } from '@tanstack/react-table';
import toast from 'react-hot-toast';
import {
  ArrowLeftIcon, PencilIcon, CheckCircleIcon, XCircleIcon,
  CalculatorIcon, ShieldCheckIcon, ExclamationCircleIcon,
} from '@heroicons/react/24/outline';

import { purchaseService, POLine } from '@/services/purchase';
import { PO_STATUS_LABELS, PO_STATUS_VARIANT, RECEIPT_PCT_COLOR } from '@/utils/purchase';
import Button from '@/components/ui/Button';
import Badge from '@/components/ui/Badge';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import Modal from '@/components/ui/Modal';
import Textarea from '@/components/ui/Textarea';
import DataTable from '@/components/ui/DataTable';
import PriceAlertBanner from '@/components/purchase/PriceAlertBanner';
import POTotals from '@/components/purchase/POTotals';
import { formatDate, formatCurrency, formatNumber, formatPercent, formatDateTime } from '@/utils/format';
import { cn } from '@/utils/cn';

const col = createColumnHelper<POLine>();

const LINE_COLUMNS = [
  col.accessor('line_number', { header: '#', size: 50 }),
  col.accessor('item_code', {
    header: 'Item',
    cell: i => (
      <div>
        <span className="font-mono text-xs font-semibold text-primary-800">{i.getValue()}</span>
        <p className="text-xs text-neutral-600 mt-0.5">{i.row.original.item_name}</p>
      </div>
    ),
  }),
  col.accessor('quantity', {
    header: 'Qty',
    cell: i => <span className="font-medium">{formatNumber(i.getValue())} <span className="text-neutral-400 text-xs">{i.row.original.uom_code}</span></span>,
    size: 90,
  }),
  col.accessor('rate', {
    header: 'Rate',
    cell: i => <span className="font-mono text-sm">{formatCurrency(i.getValue())}</span>,
    size: 110,
  }),
  col.accessor('discount_pct', {
    header: 'Disc%',
    cell: i => Number(i.getValue() ?? 0) > 0 ? <span className="text-success-600 text-xs font-medium">{i.getValue()}%</span> : <span className="text-neutral-300">—</span>,
    size: 70,
  }),
  col.accessor('gst_rate', {
    header: 'GST%',
    cell: i => i.getValue() ? `${i.getValue()}%` : <span className="text-neutral-300">—</span>,
    size: 70,
  }),
  col.accessor('amount', {
    header: 'Amount',
    cell: i => <span className="font-mono text-sm">{formatCurrency(i.getValue())}</span>,
    size: 120,
  }),
  col.accessor('received_qty', {
    header: 'Received',
    cell: i => {
      const received = parseFloat(String(i.getValue() ?? 0));
      const total = parseFloat(String(i.row.original.quantity));
      const pct = total > 0 ? received / total * 100 : 0;
      return (
        <div>
          <span className={cn('text-sm font-medium', RECEIPT_PCT_COLOR(pct))}>
            {formatNumber(i.getValue() ?? '0')}
          </span>
          <span className="text-neutral-400 text-xs ml-1">{i.row.original.uom_code}</span>
        </div>
      );
    },
    size: 100,
  }),
  col.accessor('pending_qty', {
    header: 'Pending',
    cell: i => {
      const pending = parseFloat(String(i.getValue() ?? 0));
      return (
        <span className={cn('text-sm font-medium', pending > 0 ? 'text-warning-700' : 'text-success-600')}>
          {formatNumber(i.getValue() ?? '0')} <span className="text-xs text-neutral-400">{i.row.original.uom_code}</span>
        </span>
      );
    },
    size: 100,
  }),
];

export default function PODetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [actionModal, setActionModal] = useState<'accounts' | 'approve' | 'reject' | null>(null);
  const [remarks, setRemarks] = useState('');
  const [priceAlertsDismissed, setPriceAlertsDismissed] = useState(false);

  const { data: po, isLoading } = useQuery({
    queryKey: ['po', id],
    queryFn: () => purchaseService.getPO(id!),
    enabled: !!id,
  });

  const { data: priceCheck } = useQuery({
    queryKey: ['po-price-check', id],
    queryFn: () => purchaseService.priceCheck(id!),
    enabled: !!id && !!po && ['DRAFT', 'SUBMITTED', 'ACCOUNTS_CHECKED'].includes(po?.status),
  });

  const accountsMut = useMutation({
    mutationFn: () => purchaseService.accountsCheck(id!),
    onSuccess: updated => {
      qc.setQueryData(['po', id], updated);
      qc.invalidateQueries({ queryKey: ['pos'] });
      toast.success('Accounts check complete');
      setActionModal(null);
    },
    onError: () => toast.error('Action failed'),
  });

  const approveMut = useMutation({
    mutationFn: ({ action }: { action: 'APPROVED' | 'REJECTED' }) =>
      purchaseService.approvePO(id!, action, remarks),
    onSuccess: updated => {
      qc.setQueryData(['po', id], updated);
      qc.invalidateQueries({ queryKey: ['pos'] });
      toast.success(actionModal === 'approve' ? 'PO approved' : 'PO rejected');
      setActionModal(null);
      setRemarks('');
    },
    onError: () => toast.error('Action failed'),
  });

  const recalcMut = useMutation({
    mutationFn: () => purchaseService.recalculatePO(id!),
    onSuccess: updated => {
      qc.setQueryData(['po', id], updated);
      toast.success('Totals recalculated');
    },
    onError: () => toast.error('Recalculate failed'),
  });

  if (isLoading) return (
    <div className="flex items-center justify-center h-64"><LoadingSpinner size="xl" className="text-primary-600" /></div>
  );
  if (!po) return <div className="text-center py-24 text-neutral-400">PO not found</div>;

  const canEdit = po.status === 'DRAFT';
  const canAccountsCheck = ['DRAFT', 'SUBMITTED'].includes(po.status) && !po.accounts_checked;
  const canApprove = ['SUBMITTED', 'ACCOUNTS_CHECKED'].includes(po.status);
  const receiptPct = po.receipt_percentage ?? 0;

  return (
    <div>
      {/* Price alerts */}
      {priceCheck?.has_increases && !priceAlertsDismissed && (
        <PriceAlertBanner alerts={priceCheck.alerts} onDismiss={() => setPriceAlertsDismissed(true)} />
      )}

      {/* Header */}
      <div className="flex items-start justify-between mb-6 gap-4">
        <div className="flex items-start gap-3">
          <button onClick={() => navigate(-1)} className="p-2 mt-0.5 rounded-lg hover:bg-neutral-100 text-neutral-400">
            <ArrowLeftIcon className="h-5 w-5" />
          </button>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h1 className="text-xl font-bold text-neutral-900">{po.po_number}</h1>
              <Badge variant={PO_STATUS_VARIANT[po.status] ?? 'neutral'} size="sm">
                {PO_STATUS_LABELS[po.status] ?? po.status}
              </Badge>
              {po.accounts_checked && (
                <Badge variant="success" size="sm" dot>Accounts Verified</Badge>
              )}
              {priceCheck?.has_increases && !priceAlertsDismissed && (
                <Badge variant="warning" size="sm">
                  <ExclamationCircleIcon className="h-3 w-3 inline mr-0.5" />
                  Price Increase
                </Badge>
              )}
            </div>
            <p className="text-sm text-neutral-500 mt-0.5">
              {po.vendor_name} · {formatDate(po.po_date)}
              {po.pr_number && ` · PR: ${po.pr_number}`}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0 flex-wrap justify-end">
          <Button variant="outline" size="sm" leftIcon={<CalculatorIcon className="h-4 w-4" />}
            loading={recalcMut.isPending} onClick={() => recalcMut.mutate()}>
            Recalculate
          </Button>
          {canAccountsCheck && (
            <Button variant="outline" size="sm" leftIcon={<ShieldCheckIcon className="h-4 w-4" />}
              onClick={() => setActionModal('accounts')}>
              Accounts Check
            </Button>
          )}
          {canApprove && (
            <>
              <Button variant="outline" size="sm" leftIcon={<XCircleIcon className="h-4 w-4" />}
                className="text-danger-500 border-danger-300 hover:bg-danger-50"
                onClick={() => setActionModal('reject')}>Reject</Button>
              <Button size="sm" leftIcon={<CheckCircleIcon className="h-4 w-4" />}
                onClick={() => setActionModal('approve')}>Approve</Button>
            </>
          )}
          {canEdit && (
            <Button variant="outline" size="sm" leftIcon={<PencilIcon className="h-4 w-4" />}
              onClick={() => navigate(`/purchase/orders/${id}/edit`)}>Edit</Button>
          )}
        </div>
      </div>

      {/* Vendor info + receipt progress */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div className="card col-span-2">
          <h3 className="text-xs font-semibold text-neutral-400 uppercase tracking-wide mb-3">Vendor & Order Details</h3>
          <dl className="grid grid-cols-2 sm:grid-cols-3 gap-x-6 gap-y-3">
            {[
              { label: 'Vendor', value: po.vendor_name },
              { label: 'PO Type', value: po.po_type.replace(/_/g, ' ') },
              { label: 'Delivery Date', value: po.delivery_date ? formatDate(po.delivery_date) : '—' },
              { label: 'Tolerance', value: `±${po.tolerance_pct}%` },
              { label: 'Payment Terms', value: po.payment_terms || '—' },
              { label: 'Freight Terms', value: po.freight_terms || '—' },
            ].map(({ label, value }) => (
              <div key={label}>
                <dt className="text-xs text-neutral-400 mb-0.5">{label}</dt>
                <dd className="text-sm text-neutral-800 font-medium">{value}</dd>
              </div>
            ))}
          </dl>
          {po.accounts_checked && (
            <p className="mt-3 text-xs text-success-600">
              ✓ Accounts verified by {po.accounts_checked_by_name} on {formatDateTime(po.accounts_checked_at)}
            </p>
          )}
        </div>

        <div className="card flex flex-col justify-between">
          <div>
            <h3 className="text-xs font-semibold text-neutral-400 uppercase tracking-wide mb-3">Receipt Progress</h3>
            <div className="flex items-end gap-2 mb-2">
              <span className={cn('text-3xl font-bold', RECEIPT_PCT_COLOR(receiptPct))}>{receiptPct.toFixed(0)}%</span>
              <span className="text-sm text-neutral-400 mb-1">received</span>
            </div>
            <div className="w-full h-2 bg-neutral-100 rounded-full overflow-hidden">
              <div
                className={cn('h-full rounded-full', receiptPct >= 100 ? 'bg-success-500' : receiptPct >= 50 ? 'bg-warning-500' : 'bg-primary-400')}
                style={{ width: `${Math.min(receiptPct, 100)}%` }}
              />
            </div>
          </div>
          <POTotals subtotal={po.subtotal} gstAmount={po.gst_amount} tcsAmount={po.tcs_amount}
            totalAmount={po.total_amount} currency={po.currency} className="mt-4 bg-transparent border-0 p-0" />
        </div>
      </div>

      {/* Line items */}
      <div className="card mb-6">
        <h3 className="text-sm font-semibold text-neutral-700 mb-4">Line Items</h3>
        <DataTable data={po.lines ?? []} columns={LINE_COLUMNS} emptyTitle="No line items" />
      </div>

      {/* Actions modals */}
      <Modal open={actionModal === 'accounts'} onClose={() => setActionModal(null)}
        title="Accounts Department Check" size="sm"
        footer={<><Button variant="outline" onClick={() => setActionModal(null)}>Cancel</Button>
          <Button loading={accountsMut.isPending} onClick={() => accountsMut.mutate()}>
            Confirm Check
          </Button></>}>
        <p className="text-sm text-neutral-600">
          Mark <strong>{po.po_number}</strong> as accounts-verified? This confirms the vendor details, payment terms, and pricing have been reviewed.
        </p>
      </Modal>

      <Modal open={actionModal === 'approve'} onClose={() => setActionModal(null)} title="Approve PO" size="sm"
        footer={<><Button variant="outline" onClick={() => setActionModal(null)}>Cancel</Button>
          <Button loading={approveMut.isPending} onClick={() => approveMut.mutate({ action: 'APPROVED' })}>Approve</Button></>}>
        <div className="space-y-3">
          {priceCheck?.has_increases && (
            <div className="p-2 bg-warning-50 border border-warning-200 rounded-lg text-xs text-warning-700">
              ⚠ This PO has price increases. Review them before approving.
            </div>
          )}
          <Textarea label="Remarks (optional)" rows={2} value={remarks} onChange={e => setRemarks(e.target.value)} />
        </div>
      </Modal>

      <Modal open={actionModal === 'reject'} onClose={() => setActionModal(null)} title="Reject PO" size="sm"
        footer={<><Button variant="outline" onClick={() => setActionModal(null)}>Cancel</Button>
          <Button variant="danger" loading={approveMut.isPending} onClick={() => approveMut.mutate({ action: 'REJECTED' })}>Reject</Button></>}>
        <Textarea label="Rejection Reason" required rows={3} value={remarks}
          onChange={e => setRemarks(e.target.value)} placeholder="Provide reason…" />
      </Modal>
    </div>
  );
}
