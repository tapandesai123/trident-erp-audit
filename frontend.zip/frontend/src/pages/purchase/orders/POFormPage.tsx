import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useForm, useFieldArray, useController } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import toast from 'react-hot-toast';
import { ArrowLeftIcon, PlusIcon, TrashIcon, DocumentDuplicateIcon } from '@heroicons/react/24/outline';

import { purchaseService, PRListItem } from '@/services/purchase';
import { vendorsService } from '@/services/vendors';
import Button from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import Select from '@/components/ui/Select';
import DateInput from '@/components/ui/DateInput';
import Textarea from '@/components/ui/Textarea';
import Modal from '@/components/ui/Modal';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import DataTable from '@/components/ui/DataTable';
import ItemAutocomplete, { SelectedItem } from '@/components/purchase/ItemAutocomplete';
import POTotals from '@/components/purchase/POTotals';
import { useUnsavedChanges } from '@/hooks/useUnsavedChanges';
import { formatDate, formatCurrency } from '@/utils/format';
import { createColumnHelper } from '@tanstack/react-table';

const lineSchema = z.object({
  item_id: z.string().min(1, 'Item required'),
  item_code: z.string(),
  item_name: z.string(),
  uom_id: z.number(),
  uom_code: z.string(),
  quantity: z.coerce.number().min(0.001, 'Qty > 0'),
  rate: z.coerce.number().min(0.0001, 'Rate required'),
  discount_pct: z.coerce.number().min(0).max(100).default(0),
  gst_rate: z.coerce.number().min(0).max(100).default(18),
  delivery_date: z.string().optional(),
  remarks: z.string(),
});

const poSchema = z.object({
  vendor: z.string().min(1, 'Vendor required'),
  po_date: z.string().min(1, 'PO date required'),
  po_type: z.enum(['FIXED_QTY', 'JOB_WORK', 'SERVICE', 'CAPITAL_GOODS', 'IMPORT']),
  delivery_date: z.string().optional(),
  payment_terms: z.string(),
  freight_terms: z.string(),
  tolerance_pct: z.coerce.number().min(0).max(100).default(10),
  remarks: z.string(),
  terms_conditions: z.string(),
  lines: z.array(lineSchema).min(1, 'At least one line required'),
});

type POFormValues = z.infer<typeof poSchema>;

const PO_TYPE_OPTIONS = [
  { value: 'FIXED_QTY', label: 'Fixed Quantity' },
  { value: 'JOB_WORK', label: 'Job Work' },
  { value: 'SERVICE', label: 'Service' },
  { value: 'CAPITAL_GOODS', label: 'Capital Goods' },
  { value: 'IMPORT', label: 'Import' },
];

const DEFAULT_LINE = { item_id: '', item_code: '', item_name: '', uom_id: 0, uom_code: '', quantity: 1, rate: 0, discount_pct: 0, gst_rate: 18, delivery_date: '', remarks: '' };
const DEFAULT_VALUES: Partial<POFormValues> = {
  po_date: new Date().toISOString().split('T')[0],
  po_type: 'FIXED_QTY',
  tolerance_pct: 10,
  lines: [{ ...DEFAULT_LINE }],
  payment_terms: '', freight_terms: '', remarks: '', terms_conditions: '',
};

const prCol = createColumnHelper<PRListItem>();
const PR_COLS = [
  prCol.accessor('pr_number', { header: 'PR Number', cell: i => <span className="font-mono text-xs font-semibold">{i.getValue()}</span> }),
  prCol.accessor('pr_date', { header: 'Date', cell: i => formatDate(i.getValue()), size: 100 }),
  prCol.accessor('line_count', { header: 'Lines', size: 60 }),
  prCol.accessor('total_estimated_value', { header: 'Est. Value', cell: i => formatCurrency(i.getValue() ?? '0'), size: 120 }),
];

function LineRow({ index, control, register, errors, remove, setValue }: {
  index: number; control: ReturnType<typeof useForm<POFormValues>>['control'];
  register: ReturnType<typeof useForm<POFormValues>>['register'];
  errors: ReturnType<typeof useForm<POFormValues>>['formState']['errors'];
  remove: () => void; setValue: ReturnType<typeof useForm<POFormValues>>['setValue'];
}) {
  const { field: itemField } = useController({ control, name: `lines.${index}.item_id` });
  const itemCode = (control._getWatch(`lines.${index}.item_code`) as string) ?? '';
  const itemName = (control._getWatch(`lines.${index}.item_name`) as string) ?? '';
  const uomCode = (control._getWatch(`lines.${index}.uom_code`) as string) ?? '';
  const currentItem: SelectedItem | null = itemField.value
    ? { id: itemField.value, code: itemCode, name: itemName, uom_id: 0, uom_code: uomCode, gst_rate: '18', item_type: '' }
    : null;
  const handleItemChange = (item: SelectedItem | null) => {
    itemField.onChange(item?.id ?? '');
    setValue(`lines.${index}.item_code`, item?.code ?? '');
    setValue(`lines.${index}.item_name`, item?.name ?? '');
    setValue(`lines.${index}.uom_id`, item?.uom_id ?? 0);
    setValue(`lines.${index}.uom_code`, item?.uom_code ?? '');
    if (item?.gst_rate) setValue(`lines.${index}.gst_rate`, parseFloat(item.gst_rate));
  };
  return (
    <div className="p-4 border border-neutral-100 rounded-xl bg-neutral-50">
      <div className="flex justify-between items-center mb-3">
        <span className="text-xs font-semibold text-neutral-400 uppercase tracking-wide">Line {index + 1}</span>
        <button type="button" onClick={remove} className="text-danger-400 hover:text-danger-600"><TrashIcon className="h-4 w-4" /></button>
      </div>
      <div className="grid grid-cols-12 gap-3">
        <div className="col-span-12 sm:col-span-5">
          <ItemAutocomplete label="Item" required value={currentItem} onChange={handleItemChange}
            error={errors.lines?.[index]?.item_id?.message} />
        </div>
        <div className="col-span-4 sm:col-span-1">
          <label className="form-label">UOM</label>
          <div className="form-input bg-neutral-100 text-neutral-500 text-sm">{uomCode || '—'}</div>
        </div>
        <div className="col-span-4 sm:col-span-2">
          <Input label="Qty" required type="number" step="any" min="0"
            error={errors.lines?.[index]?.quantity?.message}
            {...register(`lines.${index}.quantity`, { valueAsNumber: true })} />
        </div>
        <div className="col-span-4 sm:col-span-2">
          <Input label="Rate (₹)" required type="number" step="any" min="0"
            error={errors.lines?.[index]?.rate?.message}
            {...register(`lines.${index}.rate`, { valueAsNumber: true })} />
        </div>
        <div className="col-span-4 sm:col-span-1">
          <Input label="Disc%" type="number" step="0.01" min="0" max="100"
            {...register(`lines.${index}.discount_pct`, { valueAsNumber: true })} />
        </div>
        <div className="col-span-4 sm:col-span-1">
          <Input label="GST%" type="number" step="0.01" min="0" max="100"
            {...register(`lines.${index}.gst_rate`, { valueAsNumber: true })} />
        </div>
        <div className="col-span-6 sm:col-span-3">
          <DateInput label="Delivery Date" {...register(`lines.${index}.delivery_date`)} />
        </div>
        <div className="col-span-12 sm:col-span-9">
          <Input label="Remarks" placeholder="Optional" {...register(`lines.${index}.remarks`)} />
        </div>
      </div>
    </div>
  );
}

export default function POFormPage() {
  const { id } = useParams<{ id: string }>();
  const isEdit = !!id && id !== 'new';
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [fromPRModal, setFromPRModal] = useState(false);
  const [selectedPR, setSelectedPR] = useState<PRListItem | null>(null);

  const { data: vendors = [] } = useQuery({
    queryKey: ['vendors-list'],
    queryFn: () => vendorsService.getVendors({ limit: 200 }).then(r => r.results),
    staleTime: 60_000,
  });
  const { data: approvedPRs } = useQuery({
    queryKey: ['approved-prs-no-po'],
    queryFn: () => purchaseService.getApprovedPRsNoPO(),
    enabled: fromPRModal,
  });
  const { data: existing, isLoading: loadingExisting } = useQuery({
    queryKey: ['po', id],
    queryFn: () => purchaseService.getPO(id!),
    enabled: isEdit,
  });

  const {
    register, handleSubmit, reset, control, watch, setValue,
    formState: { errors, isDirty, isSubmitting },
  } = useForm<POFormValues>({
    resolver: zodResolver(poSchema),
    defaultValues: DEFAULT_VALUES as POFormValues,
  });

  useUnsavedChanges(isDirty);
  const { fields, append, remove } = useFieldArray({ control, name: 'lines' });

  // Live totals calculation
  const lines = watch('lines') ?? [];
  const { subtotal, gstTotal } = lines.reduce(
    (acc, l) => {
      const qty = l.quantity || 0;
      const rate = l.rate || 0;
      const disc = (l.discount_pct || 0) / 100;
      const gstRate = (l.gst_rate || 0) / 100;
      const base = qty * rate * (1 - disc);
      acc.subtotal += base;
      acc.gstTotal += base * gstRate;
      return acc;
    },
    { subtotal: 0, gstTotal: 0 }
  );

  useEffect(() => {
    if (existing) {
      reset({
        vendor: existing.vendor,
        po_date: existing.po_date,
        po_type: existing.po_type,
        delivery_date: existing.delivery_date ?? '',
        payment_terms: existing.payment_terms,
        freight_terms: existing.freight_terms,
        tolerance_pct: parseFloat(existing.tolerance_pct),
        remarks: existing.remarks,
        terms_conditions: existing.terms_conditions,
        lines: existing.lines.map(l => ({
          item_id: l.item,
          item_code: l.item_code ?? '',
          item_name: l.item_name ?? '',
          uom_id: l.uom ?? 0,
          uom_code: l.uom_code ?? '',
          quantity: parseFloat(String(l.quantity)),
          rate: parseFloat(String(l.rate)),
          discount_pct: parseFloat(String(l.discount_pct ?? 0)),
          gst_rate: parseFloat(String(l.gst_rate ?? 18)),
          delivery_date: l.delivery_date ?? '',
          remarks: l.remarks,
        })),
      });
    }
  }, [existing, reset]);

  const createFromPRMut = useMutation({
    mutationFn: ({ prId, vendorId }: { prId: string; vendorId: string }) =>
      purchaseService.createPOFromPR(prId, vendorId, 'FIXED_QTY'),
    onSuccess: saved => {
      qc.invalidateQueries({ queryKey: ['pos'] });
      toast.success('PO created from PR');
      navigate(`/purchase/orders/${saved.id}`);
    },
    onError: () => toast.error('Failed to create PO from PR'),
  });

  const mutation = useMutation({
    mutationFn: (data: POFormValues) => {
      const payload = {
        ...data,
        lines: data.lines.map((l, i) => ({
          line_number: i + 1, item: l.item_id, uom: l.uom_id,
          quantity: l.quantity, rate: l.rate,
          discount_pct: l.discount_pct ?? 0, gst_rate: l.gst_rate ?? 18,
          delivery_date: l.delivery_date || null, remarks: l.remarks,
        })),
      };
      return isEdit ? purchaseService.updatePO(id!, payload) : purchaseService.createPO(payload);
    },
    onSuccess: saved => {
      qc.invalidateQueries({ queryKey: ['pos'] });
      qc.setQueryData(['po', saved.id], saved);
      toast.success(isEdit ? 'PO updated' : 'PO created');
      navigate(`/purchase/orders/${saved.id}`);
    },
    onError: (err: unknown) => {
      const e = err as { response?: { data?: Record<string, string[]> } };
      toast.error(e?.response?.data ? Object.values(e.response.data)[0]?.[0] ?? 'Save failed' : 'Save failed');
    },
  });

  const vendorOptions = vendors.map(v => ({ value: v.id, label: `${v.code} — ${v.name}` }));

  if (isEdit && loadingExisting) return (
    <div className="flex items-center justify-center h-64"><LoadingSpinner size="xl" className="text-primary-600" /></div>
  );

  return (
    <div>
      <div className="flex items-center justify-between mb-6 gap-4">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate(-1)} className="p-2 rounded-lg hover:bg-neutral-100 text-neutral-400"><ArrowLeftIcon className="h-5 w-5" /></button>
          <h1 className="text-xl font-bold text-neutral-900">{isEdit ? 'Edit Purchase Order' : 'New Purchase Order'}</h1>
        </div>
        <div className="flex gap-2">
          {!isEdit && (
            <Button variant="outline" size="sm" leftIcon={<DocumentDuplicateIcon className="h-4 w-4" />}
              onClick={() => setFromPRModal(true)}>
              Create from PR
            </Button>
          )}
          <Button variant="outline" type="button" onClick={() => navigate(-1)} disabled={isSubmitting}>Cancel</Button>
          <Button loading={isSubmitting} onClick={handleSubmit(d => mutation.mutate(d))}>
            {isEdit ? 'Save Changes' : 'Create PO'}
          </Button>
        </div>
      </div>

      <form onSubmit={handleSubmit(d => mutation.mutate(d))} noValidate>
        <div className="card mb-4">
          <h3 className="text-sm font-semibold text-neutral-700 mb-4">PO Header</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <Select label="Vendor" required options={vendorOptions} placeholder="Select vendor"
              error={errors.vendor?.message} {...register('vendor')} />
            <DateInput label="PO Date" required error={errors.po_date?.message} {...register('po_date')} />
            <Select label="PO Type" required options={PO_TYPE_OPTIONS} {...register('po_type')} />
            <DateInput label="Expected Delivery" {...register('delivery_date')} />
            <Input label="Tolerance %" type="number" step="0.1" min="0" max="100"
              helperText="Allowed over/under receipt %" {...register('tolerance_pct', { valueAsNumber: true })} />
            <Input label="Freight Terms" {...register('freight_terms')} placeholder="e.g. FOR Destination" />
            <div className="sm:col-span-2 lg:col-span-3">
              <Textarea label="Payment Terms" rows={2} {...register('payment_terms')} />
            </div>
            <div className="sm:col-span-2 lg:col-span-3">
              <Textarea label="Terms & Conditions" rows={2} {...register('terms_conditions')} />
            </div>
            <div className="sm:col-span-2 lg:col-span-3">
              <Textarea label="Remarks" rows={1} {...register('remarks')} />
            </div>
          </div>
        </div>

        <div className="card mb-4">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-semibold text-neutral-700">Line Items</h3>
          </div>
          <div className="space-y-3">
            {fields.map((field, i) => (
              <LineRow key={field.id} index={i} control={control} register={register}
                errors={errors} remove={() => remove(i)} setValue={setValue} />
            ))}
          </div>
          <div className="mt-4 flex items-center justify-between">
            <Button type="button" variant="outline" size="sm" leftIcon={<PlusIcon className="h-4 w-4" />}
              onClick={() => append({ ...DEFAULT_LINE })}>
              Add Line
            </Button>
            {lines.length > 0 && (
              <div className="text-right">
                <p className="text-xs text-neutral-400">Subtotal: {formatCurrency(subtotal)} + GST: {formatCurrency(gstTotal)}</p>
                <p className="text-sm font-bold text-neutral-800">Total: {formatCurrency(subtotal + gstTotal)}</p>
              </div>
            )}
          </div>
        </div>

        <div className="flex justify-end gap-2 pb-4">
          <Button variant="outline" type="button" onClick={() => navigate(-1)} disabled={isSubmitting}>Cancel</Button>
          <Button type="submit" loading={isSubmitting}>{isEdit ? 'Save Changes' : 'Create PO'}</Button>
        </div>
      </form>

      {/* Create from PR modal */}
      <Modal open={fromPRModal} onClose={() => setFromPRModal(false)}
        title="Create PO from Approved PR" size="lg"
        footer={<>
          <Button variant="outline" onClick={() => setFromPRModal(false)}>Cancel</Button>
          <Button
            disabled={!selectedPR || !watch('vendor')}
            loading={createFromPRMut.isPending}
            onClick={() => {
              if (!selectedPR || !watch('vendor')) return;
              createFromPRMut.mutate({ prId: selectedPR.id, vendorId: watch('vendor') });
            }}>
            Create PO from Selected PR
          </Button>
        </>}>
        <div className="space-y-4">
          <Select label="Select Vendor for PO" required options={vendorOptions} placeholder="Select vendor"
            {...register('vendor')} />
          <DataTable
            data={approvedPRs?.results ?? []}
            columns={PR_COLS}
            loading={!approvedPRs}
            onRowClick={row => setSelectedPR(row)}
            emptyTitle="No approved PRs without a PO"
            toolbarLeft={
              selectedPR && (
                <div className="text-xs text-primary-700 bg-primary-50 px-2 py-1 rounded">
                  Selected: {selectedPR.pr_number}
                </div>
              )
            }
          />
        </div>
      </Modal>
    </div>
  );
}
