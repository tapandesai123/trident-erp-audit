import { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { PlusIcon, MagnifyingGlassIcon, UserCircleIcon } from '@heroicons/react/24/outline';
import PageHeader from '@/components/ui/PageHeader';
import Badge from '@/components/ui/Badge';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import { hrService } from '@/services/hr';

const STATUS_BADGE: Record<string, any> = { ACTIVE: 'success', ON_LEAVE: 'warning', RESIGNED: 'neutral', TERMINATED: 'danger' };

export function EmployeeListPage() {
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [dept, setDept] = useState('');
  const { data, isLoading } = useQuery({
    queryKey: ['employees', search, dept],
    queryFn: () => hrService.list({ search, department: dept || undefined }),
  });
  const { data: depts } = useQuery({ queryKey: ['departments'], queryFn: () => hrService.listDepartments() });
  const employees = Array.isArray(data) ? data : (data as any)?.results || [];
  const departments = Array.isArray(depts) ? depts : [];

  return (
    <div className="space-y-5">
      <PageHeader title="Employees"
        actions={<button className="btn btn-primary" onClick={() => navigate('/hr/employees/new')}><PlusIcon className="h-4 w-4 mr-1" />Add Employee</button>} />
      <div className="flex gap-3">
        <div className="relative flex-1"><MagnifyingGlassIcon className="absolute left-3 top-2.5 h-4 w-4 text-neutral-400" /><input className="input pl-9" placeholder="Search employees…" value={search} onChange={e => setSearch(e.target.value)} /></div>
        <select className="input w-48" value={dept} onChange={e => setDept(e.target.value)}>
          <option value="">All Departments</option>
          {departments.map((d: any) => <option key={d.id} value={d.id}>{d.name}</option>)}
        </select>
      </div>
      {isLoading ? <LoadingSpinner /> : (
        <div className="grid grid-cols-3 gap-4">
          {employees.length === 0
            ? <div className="col-span-3 card p-8 text-center text-neutral-400">No employees found.</div>
            : employees.map((e: any) => (
              <div key={e.id} className="card p-4 cursor-pointer hover:shadow-md transition-shadow" onClick={() => navigate(`/hr/employees/${e.id}`)}>
                <div className="flex items-center gap-3 mb-3">
                  <div className="h-12 w-12 rounded-full bg-primary-100 flex items-center justify-center flex-shrink-0">
                    <UserCircleIcon className="h-8 w-8 text-primary-600" />
                  </div>
                  <div>
                    <p className="font-semibold text-neutral-900">{e.first_name} {e.last_name}</p>
                    <p className="text-xs text-neutral-500">{e.employee_code || e.emp_code}</p>
                  </div>
                </div>
                <div className="space-y-1 text-sm">
                  <div className="flex justify-between"><span className="text-neutral-400">Department</span><span>{e.department_name || e.department?.name || '—'}</span></div>
                  <div className="flex justify-between"><span className="text-neutral-400">Designation</span><span>{e.designation || '—'}</span></div>
                  <div className="flex justify-between"><span className="text-neutral-400">Status</span><Badge variant={STATUS_BADGE[e.status] || 'neutral'}>{e.status}</Badge></div>
                </div>
              </div>
            ))}
        </div>
      )}
    </div>
  );
}

export function EmployeeDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { data: emp, isLoading } = useQuery({ queryKey: ['employee', id], queryFn: () => hrService.get(id!), enabled: !!id });
  const { data: attData } = useQuery({ queryKey: ['attendance', id], queryFn: () => hrService.listAttendance({ employee: id }), enabled: !!id });
  const attendance = Array.isArray(attData) ? attData : (attData as any)?.results || [];

  if (isLoading) return <LoadingSpinner />;
  if (!emp) return <div className="p-8 text-neutral-400">Employee not found.</div>;

  return (
    <div className="space-y-5">
      <PageHeader title={`${emp.first_name} ${emp.last_name}`} subtitle={emp.employee_code || emp.emp_code}
        actions={<button className="btn btn-secondary" onClick={() => navigate(`/hr/employees/${id}/edit`)}>Edit</button>} />
      <div className="grid grid-cols-3 gap-5">
        <div className="col-span-1 card p-4 space-y-3 h-fit">
          <div className="h-20 w-20 rounded-full bg-primary-100 flex items-center justify-center mx-auto mb-2"><UserCircleIcon className="h-14 w-14 text-primary-600" /></div>
          {[['Department', emp.department_name || emp.department?.name || '—'], ['Designation', emp.designation || '—'], ['Date Joined', emp.date_of_joining || '—'], ['Mobile', emp.mobile || '—'], ['Email', emp.email || '—'], ['PAN', emp.pan || '—'], ['Aadhar', emp.aadhar ? '****' + emp.aadhar.slice(-4) : '—']].map(([l, v]) => (
            <div key={l}><p className="text-xs text-neutral-400">{l}</p><p className="text-sm font-medium">{v}</p></div>
          ))}
        </div>
        <div className="col-span-2 space-y-4">
          <div className="card p-4">
            <h3 className="text-sm font-semibold text-neutral-700 mb-3">Recent Attendance</h3>
            <table className="table">
              <thead><tr><th>Date</th><th>In</th><th>Out</th><th>Hours</th><th>Status</th></tr></thead>
              <tbody>
                {attendance.length === 0
                  ? <tr><td colSpan={5} className="text-center py-4 text-neutral-400">No attendance records.</td></tr>
                  : attendance.slice(0, 15).map((a: any) => (
                    <tr key={a.id} className="hover:bg-neutral-50">
                      <td className="text-sm">{a.date}</td>
                      <td className="text-sm text-neutral-500">{a.in_time || '—'}</td>
                      <td className="text-sm text-neutral-500">{a.out_time || '—'}</td>
                      <td className="text-sm text-right tabular-nums">{a.working_hours || '—'}</td>
                      <td><Badge variant={a.status === 'PRESENT' ? 'success' : a.status === 'ABSENT' ? 'danger' : 'warning'}>{a.status}</Badge></td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
