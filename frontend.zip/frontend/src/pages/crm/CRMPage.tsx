import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { PlusIcon, MagnifyingGlassIcon } from '@heroicons/react/24/outline';
import PageHeader from '@/components/ui/PageHeader';
import Badge from '@/components/ui/Badge';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import { crmService } from '@/services/crm';

const LEAD_STATUS_BADGE: Record<string, any> = { NEW: 'info', CONTACTED: 'warning', QUALIFIED: 'success', LOST: 'danger', CONVERTED: 'neutral' };
const OPP_STAGE_BADGE: Record<string, any> = { PROSPECT: 'neutral', QUALIFIED: 'info', PROPOSAL: 'warning', NEGOTIATION: 'warning', WON: 'success', LOST: 'danger' };

export default function CRMPage() {
  const [tab, setTab] = useState<'leads' | 'opportunities' | 'visits'>('leads');
  const [search, setSearch] = useState('');
  const qc = useQueryClient();

  const { data: leadsData, isLoading: leadsLoading } = useQuery({
    queryKey: ['leads', search],
    queryFn: () => crmService.listLeads({ search }),
    enabled: tab === 'leads',
  });
  const { data: oppsData, isLoading: oppsLoading } = useQuery({
    queryKey: ['opportunities', search],
    queryFn: () => crmService.listOpportunities({ search }),
    enabled: tab === 'opportunities',
  });
  const { data: visitsData, isLoading: visitsLoading } = useQuery({
    queryKey: ['visit-logs', search],
    queryFn: () => crmService.listVisits({ search }),
    enabled: tab === 'visits',
  });

  const convertLead = useMutation({
    mutationFn: (id: string) => crmService.convertLead(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['leads'] }),
  });

  const leads = Array.isArray(leadsData) ? leadsData : (leadsData as any)?.results || [];
  const opps = Array.isArray(oppsData) ? oppsData : (oppsData as any)?.results || [];
  const visits = Array.isArray(visitsData) ? visitsData : (visitsData as any)?.results || [];

  const isLoading = tab === 'leads' ? leadsLoading : tab === 'opportunities' ? oppsLoading : visitsLoading;

  return (
    <div className="space-y-5">
      <PageHeader title="CRM" subtitle="Leads, Opportunities & Visit Logs"
        actions={<button className="btn btn-primary"><PlusIcon className="h-4 w-4 mr-1" />{tab === 'leads' ? 'New Lead' : tab === 'visits' ? 'Log Visit' : 'New Opportunity'}</button>} />
      <div className="flex gap-2 border-b border-neutral-200">
        {[{ k: 'leads', l: 'Leads' }, { k: 'opportunities', l: 'Opportunities' }, { k: 'visits', l: 'Visit Logs' }].map(({ k, l }) => (
          <button key={k} onClick={() => setTab(k as any)}
            className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors ${tab === k ? 'border-primary-600 text-primary-700' : 'border-transparent text-neutral-500 hover:text-neutral-700'}`}>
            {l}
          </button>
        ))}
      </div>
      <div className="relative"><MagnifyingGlassIcon className="absolute left-3 top-2.5 h-4 w-4 text-neutral-400" /><input className="input pl-9 w-72" placeholder="Search…" value={search} onChange={e => setSearch(e.target.value)} /></div>

      {isLoading ? <LoadingSpinner /> : (
        <>
          {tab === 'leads' && (
            <div className="card overflow-hidden">
              <table className="table">
                <thead><tr><th>Lead Name</th><th>Company</th><th>Source</th><th>Assigned To</th><th>Status</th><th>Created</th><th>Actions</th></tr></thead>
                <tbody>
                  {leads.length === 0
                    ? <tr><td colSpan={7} className="text-center py-8 text-neutral-400">No leads found.</td></tr>
                    : leads.map((l: any) => (
                      <tr key={l.id} className="hover:bg-neutral-50">
                        <td className="font-medium">{l.name}</td>
                        <td className="text-sm text-neutral-500">{l.company || '—'}</td>
                        <td className="text-sm text-neutral-500">{l.source || '—'}</td>
                        <td className="text-sm">{l.assigned_to_name || '—'}</td>
                        <td><Badge variant={LEAD_STATUS_BADGE[l.status] || 'neutral'}>{l.status}</Badge></td>
                        <td className="text-sm text-neutral-400">{l.created_at?.slice(0, 10)}</td>
                        <td>
                          {l.status !== 'CONVERTED' && l.status !== 'LOST' && (
                            <button className="text-xs text-primary-600 hover:underline" onClick={() => convertLead.mutate(l.id)}>Convert</button>
                          )}
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          )}
          {tab === 'opportunities' && (
            <div className="card overflow-hidden">
              <table className="table">
                <thead><tr><th>Opportunity</th><th>Customer</th><th>Stage</th><th>Value (₹)</th><th>Close Date</th><th>Owner</th></tr></thead>
                <tbody>
                  {opps.length === 0
                    ? <tr><td colSpan={6} className="text-center py-8 text-neutral-400">No opportunities.</td></tr>
                    : opps.map((o: any) => (
                      <tr key={o.id} className="hover:bg-neutral-50">
                        <td className="font-medium">{o.name || o.title}</td>
                        <td className="text-sm text-neutral-500">{o.customer_name || o.customer?.name}</td>
                        <td><Badge variant={OPP_STAGE_BADGE[o.stage] || 'neutral'}>{o.stage}</Badge></td>
                        <td className="text-right tabular-nums font-medium">₹{Number(o.value || o.estimated_value || 0).toLocaleString('en-IN')}</td>
                        <td className="text-sm text-neutral-500">{o.expected_close_date || o.close_date}</td>
                        <td className="text-sm">{o.owner_name || o.assigned_to_name || '—'}</td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          )}
          {tab === 'visits' && (
            <div className="card overflow-hidden">
              <table className="table">
                <thead><tr><th>Date</th><th>Customer</th><th>Visited By</th><th>Purpose</th><th>Outcome</th><th>Next Follow-up</th></tr></thead>
                <tbody>
                  {visits.length === 0
                    ? <tr><td colSpan={6} className="text-center py-8 text-neutral-400">No visit logs.</td></tr>
                    : visits.map((v: any) => (
                      <tr key={v.id} className="hover:bg-neutral-50">
                        <td className="text-sm font-medium">{v.visit_date || v.date}</td>
                        <td className="text-sm">{v.customer_name || v.customer?.name}</td>
                        <td className="text-sm">{v.visited_by_name || v.salesman_name}</td>
                        <td className="text-sm text-neutral-500">{v.purpose || '—'}</td>
                        <td className="text-sm">{v.outcome || '—'}</td>
                        <td className="text-sm text-neutral-400">{v.next_followup || '—'}</td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          )}
        </>
      )}
    </div>
  );
}
