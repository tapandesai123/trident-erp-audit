import { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { PlusIcon, MagnifyingGlassIcon } from '@heroicons/react/24/outline';
import PageHeader from '@/components/ui/PageHeader';
import Badge from '@/components/ui/Badge';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import { assetsService } from '@/services/assets';

const STATUS_BADGE: Record<string, any> = { ACTIVE: 'success', UNDER_REPAIR: 'warning', SCRAPPED: 'neutral', DISPOSED: 'danger' };
const COND_BADGE: Record<string, any> = { GOOD: 'success', FAIR: 'info', POOR: 'warning', CRITICAL: 'danger' };

export function AssetListPage() {
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('');

  const { data, isLoading } = useQuery({ queryKey: ['assets', search, category], queryFn: () => assetsService.list({ search, category: category || undefined }) });
  const { data: catData } = useQuery({ queryKey: ['asset-categories'], queryFn: () => assetsService.listCategories() });
  const assets = Array.isArray(data) ? data : (data as any)?.results || [];
  const categories = Array.isArray(catData) ? catData : [];

  return (
    <div className="space-y-5">
      <PageHeader title="Fixed Assets"
        actions={<button className="btn btn-primary" onClick={() => navigate('/assets/new')}><PlusIcon className="h-4 w-4 mr-1" />Add Asset</button>} />
      <div className="flex gap-3">
        <div className="relative flex-1"><MagnifyingGlassIcon className="absolute left-3 top-2.5 h-4 w-4 text-neutral-400" /><input className="input pl-9" placeholder="Search assets…" value={search} onChange={e => setSearch(e.target.value)} /></div>
        <select className="input w-48" value={category} onChange={e => setCategory(e.target.value)}>
          <option value="">All Categories</option>
          {categories.map((c: any) => <option key={c.id} value={c.id}>{c.name}</option>)}
        </select>
      </div>
      {isLoading ? <LoadingSpinner /> : (
        <div className="card overflow-hidden">
          <table className="table">
            <thead><tr><th>Asset Code</th><th>Name</th><th>Category</th><th>Location</th><th className="text-right">Cost (₹)</th><th className="text-right">WDV (₹)</th><th>Condition</th><th>Status</th></tr></thead>
            <tbody>
              {assets.length === 0
                ? <tr><td colSpan={8} className="text-center py-8 text-neutral-400">No assets found.</td></tr>
                : assets.map((a: any) => (
                  <tr key={a.id} className="hover:bg-neutral-50 cursor-pointer" onClick={() => navigate(`/assets/${a.id}`)}>
                    <td className="font-mono text-sm font-medium text-primary-700">{a.asset_code}</td>
                    <td><p className="font-medium">{a.name}</p><p className="text-xs text-neutral-400">{a.serial_number || '—'}</p></td>
                    <td className="text-sm text-neutral-500">{a.category_name || a.category?.name}</td>
                    <td className="text-sm text-neutral-500">{a.location || '—'}</td>
                    <td className="text-right tabular-nums">₹{Number(a.purchase_cost || 0).toLocaleString('en-IN')}</td>
                    <td className="text-right tabular-nums font-medium">₹{Number(a.current_book_value || 0).toLocaleString('en-IN')}</td>
                    <td><Badge variant={COND_BADGE[a.condition] || 'neutral'}>{a.condition || '—'}</Badge></td>
                    <td><Badge variant={STATUS_BADGE[a.status] || 'neutral'}>{a.status}</Badge></td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

export function AssetDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { data: asset, isLoading } = useQuery({ queryKey: ['asset', id], queryFn: () => assetsService.get(id!), enabled: !!id });

  if (isLoading) return <LoadingSpinner />;
  if (!asset) return <div className="p-8 text-neutral-400">Asset not found.</div>;
  const a = asset as any;

  return (
    <div className="space-y-5">
      <PageHeader title={a.name} subtitle={a.asset_code}
        actions={<button className="btn btn-secondary" onClick={() => navigate(`/assets/${id}/edit`)}>Edit</button>} />
      <div className="grid grid-cols-3 gap-5">
        <div className="col-span-1 space-y-4">
          <div className="card p-4 space-y-3">
            {[['Category', a.category_name || '—'], ['Serial No.', a.serial_number || '—'], ['Location', a.location || '—'], ['Purchase Date', a.purchase_date || '—'], ['Supplier', a.supplier_name || '—'], ['Useful Life', a.useful_life_years ? `${a.useful_life_years} years` : '—'], ['Depreciation', a.depreciation_method || '—']].map(([l, v]) => (
              <div key={l}><p className="text-xs text-neutral-400">{l}</p><p className="text-sm font-medium">{v}</p></div>
            ))}
          </div>
        </div>
        <div className="col-span-2 space-y-4">
          <div className="grid grid-cols-3 gap-4">
            {[['Purchase Cost', `₹${Number(a.purchase_cost || 0).toLocaleString('en-IN')}`], ['Accumulated Dep.', `₹${Number(a.accumulated_depreciation || 0).toLocaleString('en-IN')}`], ['Current WDV', `₹${Number(a.current_book_value || 0).toLocaleString('en-IN')}`]].map(([l, v]) => (
              <div key={l} className="card p-3"><p className="text-xs text-neutral-400">{l}</p><p className="text-lg font-bold text-neutral-900">{v}</p></div>
            ))}
          </div>
          {(a.depreciation_schedule || []).length > 0 && (
            <div className="card overflow-hidden">
              <div className="px-4 py-3 border-b border-neutral-100"><h3 className="text-sm font-semibold text-neutral-700">Depreciation Schedule</h3></div>
              <table className="table">
                <thead><tr><th>Year</th><th className="text-right">Opening WDV</th><th className="text-right">Depreciation</th><th className="text-right">Closing WDV</th></tr></thead>
                <tbody>
                  {a.depreciation_schedule.map((row: any) => (
                    <tr key={row.year} className="hover:bg-neutral-50">
                      <td className="text-sm">FY {row.year}</td>
                      <td className="text-right tabular-nums text-sm">₹{Number(row.opening_wdv).toLocaleString('en-IN')}</td>
                      <td className="text-right tabular-nums text-sm text-danger-600">₹{Number(row.depreciation).toLocaleString('en-IN')}</td>
                      <td className="text-right tabular-nums text-sm font-medium">₹{Number(row.closing_wdv).toLocaleString('en-IN')}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
