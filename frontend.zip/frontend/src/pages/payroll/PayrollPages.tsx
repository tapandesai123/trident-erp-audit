import { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { MagnifyingGlassIcon } from '@heroicons/react/24/outline';
import PageHeader from '@/components/ui/PageHeader';
import Badge from '@/components/ui/Badge';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import { payrollService } from '@/services/payroll';

const STATUS_BADGE: Record<string, any> = { DRAFT: 'neutral', PROCESSED: 'info', PAID: 'success', CANCELLED: 'danger' };

export function SalaryListPage() {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const now = new Date();
  const [month, setMonth] = useState(`${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`);
  const [search, setSearch] = useState('');

  const { data, isLoading } = useQuery({
    queryKey: ['salary-records', month, search],
    queryFn: () => payrollService.list({ month, search: search || undefined }),
  });
  const records = Array.isArray(data) ? data : (data as any)?.results || [];

  const processMutation = useMutation({
    mutationFn: () => payrollService.processPayroll({ month }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['salary-records'] }),
  });

  return (
    <div className="space-y-5">
      <PageHeader title="Payroll" subtitle={`Salary records for ${month}`}
        actions={
          <button className="btn btn-primary" disabled={processMutation.isPending} onClick={() => processMutation.mutate()}>
            {processMutation.isPending ? 'Processing…' : 'Process Payroll'}
          </button>
        } />
      <div className="flex gap-3">
        <input className="input w-44" type="month" value={month} onChange={e => setMonth(e.target.value)} />
        <div className="relative flex-1"><MagnifyingGlassIcon className="absolute left-3 top-2.5 h-4 w-4 text-neutral-400" /><input className="input pl-9" placeholder="Search employee…" value={search} onChange={e => setSearch(e.target.value)} /></div>
      </div>
      {isLoading ? <LoadingSpinner /> : (
        <div className="card overflow-hidden">
          <table className="table">
            <thead><tr><th>Employee</th><th>Department</th><th className="text-right">Basic</th><th className="text-right">Allowances</th><th className="text-right">Deductions</th><th className="text-right">Net Pay</th><th>Status</th><th>Payslip</th></tr></thead>
            <tbody>
              {records.length === 0
                ? <tr><td colSpan={8} className="text-center py-8 text-neutral-400">No salary records for {month}. Run Process Payroll to generate.</td></tr>
                : records.map((r: any) => (
                  <tr key={r.id} className="hover:bg-neutral-50">
                    <td className="font-medium">{r.employee_name || r.employee?.name}</td>
                    <td className="text-sm text-neutral-500">{r.department_name || r.employee?.department_name || '—'}</td>
                    <td className="text-right tabular-nums">₹{Number(r.basic_salary || 0).toLocaleString('en-IN')}</td>
                    <td className="text-right tabular-nums text-success-700">₹{Number(r.total_allowances || 0).toLocaleString('en-IN')}</td>
                    <td className="text-right tabular-nums text-danger-700">₹{Number(r.total_deductions || 0).toLocaleString('en-IN')}</td>
                    <td className="text-right tabular-nums font-semibold">₹{Number(r.net_pay || 0).toLocaleString('en-IN')}</td>
                    <td><Badge variant={STATUS_BADGE[r.status] || 'neutral'}>{r.status}</Badge></td>
                    <td><button className="text-xs text-primary-600 hover:underline" onClick={() => navigate(`/payroll/payslip/${r.id}`)}>View Payslip</button></td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

export function PayslipPage() {
  const { id } = useParams<{ id: string }>();
  const { data: payslip, isLoading } = useQuery({ queryKey: ['payslip', id], queryFn: () => payrollService.getPayslip(id!), enabled: !!id });

  if (isLoading) return <LoadingSpinner />;
  if (!payslip) return <div className="p-8 text-neutral-400">Payslip not found.</div>;

  const p = payslip as any;

  return (
    <div className="max-w-2xl mx-auto space-y-5">
      <PageHeader title="Payslip" subtitle={`${p.employee_name} — ${p.month}`}
        actions={<button className="btn btn-secondary" onClick={() => window.print()}>Print</button>} />
      <div className="card p-6 space-y-4 print:shadow-none">
        <div className="border-b border-neutral-200 pb-4">
          <h2 className="text-lg font-bold text-neutral-900">Trident Paper Box Industries</h2>
          <p className="text-sm text-neutral-500">Payslip for {p.month}</p>
        </div>
        <div className="grid grid-cols-2 gap-4 text-sm">
          {[['Employee', p.employee_name], ['Employee Code', p.employee_code], ['Department', p.department_name], ['Designation', p.designation], ['Bank Account', p.bank_account_number ? '****' + p.bank_account_number.slice(-4) : '—'], ['PAN', p.pan]].map(([l, v]) => (
            <div key={l}><p className="text-neutral-400 text-xs">{l}</p><p className="font-medium">{v || '—'}</p></div>
          ))}
        </div>
        <div className="grid grid-cols-2 gap-4 border-t border-neutral-100 pt-4">
          <div>
            <h4 className="text-sm font-semibold text-neutral-700 mb-2">Earnings</h4>
            <div className="space-y-1.5">
              {(p.earnings || []).map((e: any) => (
                <div key={e.name} className="flex justify-between text-sm"><span className="text-neutral-500">{e.name}</span><span className="tabular-nums">₹{Number(e.amount).toLocaleString('en-IN')}</span></div>
              ))}
              <div className="flex justify-between text-sm font-semibold border-t pt-1.5 mt-2"><span>Gross Pay</span><span className="tabular-nums">₹{Number(p.gross_pay || 0).toLocaleString('en-IN')}</span></div>
            </div>
          </div>
          <div>
            <h4 className="text-sm font-semibold text-neutral-700 mb-2">Deductions</h4>
            <div className="space-y-1.5">
              {(p.deductions || []).map((d: any) => (
                <div key={d.name} className="flex justify-between text-sm"><span className="text-neutral-500">{d.name}</span><span className="tabular-nums text-danger-600">₹{Number(d.amount).toLocaleString('en-IN')}</span></div>
              ))}
              <div className="flex justify-between text-sm font-semibold border-t pt-1.5 mt-2"><span>Total Deductions</span><span className="tabular-nums text-danger-700">₹{Number(p.total_deductions || 0).toLocaleString('en-IN')}</span></div>
            </div>
          </div>
        </div>
        <div className="bg-primary-50 rounded-lg p-4 flex justify-between items-center">
          <span className="font-bold text-primary-800">Net Pay</span>
          <span className="text-2xl font-bold text-primary-900">₹{Number(p.net_pay || 0).toLocaleString('en-IN')}</span>
        </div>
      </div>
    </div>
  );
}
