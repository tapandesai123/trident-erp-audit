import { useLocation } from 'react-router-dom';
import { WrenchScrewdriverIcon } from '@heroicons/react/24/outline';

export default function PlaceholderPage() {
  const { pathname } = useLocation();
  const title = pathname
    .split('/')
    .filter(Boolean)
    .map((s) => s.replace(/-/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase()))
    .join(' › ');

  return (
    <div className="flex flex-col items-center justify-center py-24 text-center">
      <div className="p-4 bg-primary-50 rounded-full mb-4">
        <WrenchScrewdriverIcon className="h-8 w-8 text-primary-400" />
      </div>
      <h2 className="text-lg font-semibold text-neutral-700 mb-1">{title}</h2>
      <p className="text-sm text-neutral-400">This module is under construction.</p>
    </div>
  );
}
