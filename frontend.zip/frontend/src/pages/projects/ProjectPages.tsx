import { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { PlusIcon, MagnifyingGlassIcon } from '@heroicons/react/24/outline';
import PageHeader from '@/components/ui/PageHeader';
import Badge from '@/components/ui/Badge';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import { projectsService } from '@/services/projects';

const STATUS_BADGE: Record<string, any> = { PLANNING: 'neutral', ACTIVE: 'info', ON_HOLD: 'warning', COMPLETED: 'success', CANCELLED: 'danger' };

export function ProjectListPage() {
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const { data, isLoading } = useQuery({ queryKey: ['projects', search], queryFn: () => projectsService.list({ search }) });
  const projects = Array.isArray(data) ? data : (data as any)?.results || [];

  return (
    <div className="space-y-5">
      <PageHeader title="Projects" actions={<button className="btn btn-primary" onClick={() => navigate('/projects/new')}><PlusIcon className="h-4 w-4 mr-1" />New Project</button>} />
      <div className="relative"><MagnifyingGlassIcon className="absolute left-3 top-2.5 h-4 w-4 text-neutral-400" /><input className="input pl-9 w-72" placeholder="Search projects…" value={search} onChange={e => setSearch(e.target.value)} /></div>
      {isLoading ? <LoadingSpinner /> : (
        <div className="grid grid-cols-2 gap-4">
          {projects.length === 0
            ? <div className="col-span-2 card p-8 text-center text-neutral-400">No projects found.</div>
            : projects.map((p: any) => (
              <div key={p.id} className="card p-4 cursor-pointer hover:shadow-md transition-shadow" onClick={() => navigate(`/projects/${p.id}`)}>
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <p className="font-semibold text-neutral-900">{p.name}</p>
                    <p className="text-xs text-neutral-400 mt-0.5">{p.project_code || p.code}</p>
                  </div>
                  <Badge variant={STATUS_BADGE[p.status] || 'neutral'}>{p.status}</Badge>
                </div>
                <p className="text-sm text-neutral-500 mb-3">{p.description?.slice(0, 80)}{p.description?.length > 80 ? '…' : ''}</p>
                <div className="flex justify-between text-sm">
                  <span className="text-neutral-400">Manager: <span className="text-neutral-700">{p.manager_name || '—'}</span></span>
                  <span className="text-neutral-400">Due: <span className="text-neutral-700 font-medium">{p.end_date || '—'}</span></span>
                </div>
                {p.completion_pct !== undefined && (
                  <div className="mt-3">
                    <div className="flex justify-between text-xs text-neutral-400 mb-1"><span>Progress</span><span>{p.completion_pct}%</span></div>
                    <div className="w-full bg-neutral-100 rounded-full h-1.5"><div className="bg-primary-500 rounded-full h-1.5" style={{ width: `${p.completion_pct}%` }} /></div>
                  </div>
                )}
              </div>
            ))}
        </div>
      )}
    </div>
  );
}

export function ProjectDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const { data: project, isLoading } = useQuery({ queryKey: ['project', id], queryFn: () => projectsService.get(id!), enabled: !!id });
  const { data: tasks } = useQuery({ queryKey: ['project-tasks', id], queryFn: () => projectsService.listTasks(id!), enabled: !!id });
  const { data: milestones } = useQuery({ queryKey: ['project-milestones', id], queryFn: () => projectsService.listMilestones(id!), enabled: !!id });

  const taskStatusMutation = useMutation({
    mutationFn: ({ tid, status }: { tid: string; status: string }) => projectsService.updateTaskStatus(tid, status),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['project-tasks', id] }),
  });

  if (isLoading) return <LoadingSpinner />;
  if (!project) return <div className="p-8 text-neutral-400">Project not found.</div>;
  const p = project as any;
  const taskList = Array.isArray(tasks) ? tasks : (tasks as any)?.results || [];
  const milestoneList = Array.isArray(milestones) ? milestones : (milestones as any)?.results || [];

  // Kanban columns
  const kanban: Record<string, any[]> = { TODO: [], IN_PROGRESS: [], DONE: [] };
  taskList.forEach((t: any) => { if (kanban[t.status]) kanban[t.status].push(t); });

  return (
    <div className="space-y-5">
      <PageHeader title={p.name} subtitle={p.project_code}
        actions={<button className="btn btn-secondary" onClick={() => navigate(`/projects/${id}/edit`)}>Edit</button>} />
      <div className="grid grid-cols-4 gap-4">
        {[['Status', p.status], ['Manager', p.manager_name || '—'], ['Start', p.start_date || '—'], ['End', p.end_date || '—']].map(([l, v]) => (
          <div key={l} className="card p-3"><p className="text-xs text-neutral-400">{l}</p><p className="text-sm font-semibold">{v}</p></div>
        ))}
      </div>
      {milestoneList.length > 0 && (
        <div className="card p-4">
          <h3 className="text-sm font-semibold text-neutral-700 mb-3">Milestones</h3>
          <div className="flex gap-3 overflow-x-auto pb-2">
            {milestoneList.map((m: any) => (
              <div key={m.id} className={`flex-shrink-0 px-3 py-2 rounded-lg border text-sm ${m.is_completed ? 'border-success-200 bg-success-50 text-success-700' : 'border-neutral-200 text-neutral-600'}`}>
                <p className="font-medium">{m.name}</p>
                <p className="text-xs opacity-70">{m.due_date}</p>
              </div>
            ))}
          </div>
        </div>
      )}
      <div>
        <h3 className="text-sm font-semibold text-neutral-700 mb-3">Task Board</h3>
        <div className="grid grid-cols-3 gap-4">
          {Object.entries(kanban).map(([col, items]) => (
            <div key={col} className="card overflow-hidden">
              <div className="px-4 py-2 border-b border-neutral-100 bg-neutral-50"><h4 className="text-xs font-semibold text-neutral-500 uppercase tracking-wide">{col.replace('_', ' ')} ({items.length})</h4></div>
              <div className="divide-y divide-neutral-100">
                {items.map((t: any) => (
                  <div key={t.id} className="px-4 py-3">
                    <p className="text-sm font-medium text-neutral-900">{t.title || t.name}</p>
                    <p className="text-xs text-neutral-400 mt-0.5">{t.assigned_to_name || '—'}</p>
                    <div className="flex gap-1 mt-2">
                      {['TODO','IN_PROGRESS','DONE'].filter(s => s !== col).map(s => (
                        <button key={s} className="text-xs text-primary-600 hover:underline"
                          onClick={() => taskStatusMutation.mutate({ tid: t.id, status: s })}>
                          → {s.replace('_', ' ')}
                        </button>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
