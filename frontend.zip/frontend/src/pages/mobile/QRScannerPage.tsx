import { useEffect, useRef, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useMutation } from '@tanstack/react-query';
import { QrCodeIcon, XMarkIcon, CheckCircleIcon, ExclamationTriangleIcon } from '@heroicons/react/24/outline';
import api from '@/services/api';

type ScanMode = 'gate-in' | 'gate-out' | 'location' | 'issue' | 'job_card_qc';

interface ParsedQR {
  type?: string;
  id?: string;
  job_card_id?: string;
  item_code?: string;
  lot_number?: string;
  weight?: number;
  gate_entry_number?: string;
  raw?: string;
}

const MODE_CONFIG: Record<ScanMode, { label: string; endpoint: string; color: string }> = {
  'gate-in':      { label: 'Gate In',         endpoint: '/api/v1/purchase/gate-entries/', color: 'bg-blue-600' },
  'gate-out':     { label: 'Gate Out',        endpoint: '/api/v1/sales/invoices/gate_out/', color: 'bg-green-600' },
  'location':     { label: 'Update Location', endpoint: '/api/v1/stores/location-update/', color: 'bg-orange-600' },
  'issue':        { label: 'Issue Material',  endpoint: '/api/v1/stores/issue/', color: 'bg-purple-600' },
  'job_card_qc':  { label: 'Job Card QC',     endpoint: '',                                color: 'bg-amber-600' },
};

function parseQRData(raw: string): ParsedQR {
  try { return { ...JSON.parse(raw), raw }; } catch { return { raw }; }
}

function ScanResultPanel({
  data,
  mode,
  onClose,
}: {
  data: string;
  mode: ScanMode;
  onClose: () => void;
}) {
  const navigate = useNavigate();
  const parsed = parseQRData(data);
  const cfg = MODE_CONFIG[mode];
  const [locationInput, setLocationInput] = useState('');

  // job_card_qc mode: navigate directly to JobCardDetailPage with ?qr=
  if (mode === 'job_card_qc') {
    const jobCardId = parsed.job_card_id || parsed.id || data;
    return (
      <div className="fixed inset-0 z-50 flex items-end">
        <div className="absolute inset-0 bg-black/60" onClick={onClose} />
        <div className="relative w-full bg-white rounded-t-3xl p-5 space-y-4 shadow-2xl">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-semibold text-neutral-900">Job Card QR Scanned</h3>
            <button onClick={onClose} className="p-1 rounded-full hover:bg-neutral-100">
              <XMarkIcon className="h-5 w-5 text-neutral-500" />
            </button>
          </div>
          <div className="bg-amber-50 rounded-xl p-4 text-sm">
            <p className="text-amber-700 font-medium">Job Card ID: {jobCardId}</p>
            <p className="text-amber-500 text-xs mt-1">This will open the QC entry form for this job card.</p>
          </div>
          <button
            className="w-full py-3.5 rounded-xl text-white font-semibold text-sm bg-amber-600"
            onClick={() => {
              // Navigate to job card QC form, passing qr as search param
              navigate(`/production/job-cards/${jobCardId}?qr=${encodeURIComponent(data)}`);
            }}
          >
            Open QC Entry Form
          </button>
        </div>
      </div>
    );
  }

  const actionMutation = useMutation({
    mutationFn: (payload: Record<string, unknown>) =>
      api.post(cfg.endpoint, payload).then(r => r.data),
  });

  const handleAction = () => {
    const payload: Record<string, unknown> = { qr_data: data, mode, ...parsed };
    if (mode === 'location') payload.new_location = locationInput;
    actionMutation.mutate(payload);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end">
      <div className="absolute inset-0 bg-black/60" onClick={onClose} />
      <div className="relative w-full bg-white rounded-t-3xl p-5 space-y-4 shadow-2xl">
        <div className="flex items-center justify-between">
          <h3 className="text-base font-semibold text-neutral-900">QR Scanned</h3>
          <button onClick={onClose} className="p-1 rounded-full hover:bg-neutral-100">
            <XMarkIcon className="h-5 w-5 text-neutral-500" />
          </button>
        </div>

        <div className="bg-neutral-50 rounded-xl p-4 space-y-2">
          {parsed.item_code && (
            <div className="flex justify-between text-sm">
              <span className="text-neutral-500">Item Code</span>
              <span className="font-medium font-mono">{parsed.item_code}</span>
            </div>
          )}
          {parsed.lot_number && (
            <div className="flex justify-between text-sm">
              <span className="text-neutral-500">Lot / Roll</span>
              <span className="font-medium font-mono">{parsed.lot_number}</span>
            </div>
          )}
          {parsed.weight !== undefined && (
            <div className="flex justify-between text-sm">
              <span className="text-neutral-500">Weight</span>
              <span className="font-medium">{parsed.weight} kg</span>
            </div>
          )}
          {parsed.gate_entry_number && (
            <div className="flex justify-between text-sm">
              <span className="text-neutral-500">Gate Entry</span>
              <span className="font-medium font-mono">{parsed.gate_entry_number}</span>
            </div>
          )}
          {!parsed.item_code && !parsed.lot_number && (
            <p className="text-xs text-neutral-400 font-mono break-all">{parsed.raw}</p>
          )}
        </div>

        {mode === 'location' && (
          <input
            className="input w-full"
            placeholder="New location (e.g., A3, B12)..."
            value={locationInput}
            onChange={e => setLocationInput(e.target.value)}
          />
        )}

        {actionMutation.isSuccess && (
          <div className="flex items-center gap-2 text-green-700 bg-green-50 rounded-xl px-4 py-3">
            <CheckCircleIcon className="h-5 w-5 flex-shrink-0" />
            <span className="text-sm font-medium">Action completed successfully</span>
          </div>
        )}
        {actionMutation.isError && (
          <div className="flex items-center gap-2 text-red-700 bg-red-50 rounded-xl px-4 py-3">
            <ExclamationTriangleIcon className="h-5 w-5 flex-shrink-0" />
            <span className="text-sm font-medium">Action failed — check network/permissions</span>
          </div>
        )}

        {!actionMutation.isSuccess && (
          <button
            onClick={handleAction}
            disabled={actionMutation.isPending || (mode === 'location' && !locationInput.trim())}
            className={`w-full py-3.5 rounded-xl text-white font-semibold text-sm ${cfg.color} disabled:opacity-50`}
          >
            {actionMutation.isPending ? 'Processing...' : `Confirm ${cfg.label}`}
          </button>
        )}
        {actionMutation.isSuccess && (
          <button onClick={onClose} className="w-full py-3.5 rounded-xl bg-neutral-900 text-white font-semibold text-sm">
            Scan Next
          </button>
        )}
      </div>
    </div>
  );
}

export default function QRScannerPage() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [result, setResult] = useState<string | null>(null);
  const [searchParams] = useSearchParams();
  const initialMode = (searchParams.get('mode') || 'gate-in') as ScanMode;
  const [scanMode, setScanMode] = useState<ScanMode>(
    Object.keys(MODE_CONFIG).includes(initialMode) ? initialMode : 'gate-in'
  );
  const [cameraError, setCameraError] = useState(false);
  const streamRef = useRef<MediaStream | null>(null);

  useEffect(() => {
    navigator.mediaDevices?.getUserMedia({ video: { facingMode: 'environment' } })
      .then(stream => {
        streamRef.current = stream;
        if (videoRef.current) { videoRef.current.srcObject = stream; }
      })
      .catch(() => setCameraError(true));

    return () => { streamRef.current?.getTracks().forEach(t => t.stop()); };
  }, []);

  useEffect(() => {
    if (result) return;
    let active = true;
    const scan = async () => {
      while (active) {
        await new Promise(r => setTimeout(r, 200));
        const video = videoRef.current;
        const canvas = canvasRef.current;
        if (!video || !canvas || video.readyState < 2) continue;
        const ctx = canvas.getContext('2d');
        if (!ctx) continue;
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        try {
          const jsQR = (await import('jsqr')).default;
          const code = jsQR(imageData.data, imageData.width, imageData.height);
          if (code && active) { setResult(code.data); }
        } catch { /* jsqr not installed */ }
      }
    };
    scan();
    return () => { active = false; };
  }, [result]);

  return (
    <div className="min-h-screen bg-black flex flex-col relative">
      <div className="bg-neutral-900 text-white px-4 py-3 flex items-center gap-3 z-10">
        <QrCodeIcon className="h-5 w-5 text-white" />
        <span className="font-semibold text-sm">QR Scanner</span>
        <div className="flex-1" />
        <select
          value={scanMode}
          onChange={e => setScanMode(e.target.value as ScanMode)}
          className="bg-neutral-800 text-white text-sm rounded-lg px-3 py-1.5 border border-neutral-700"
        >
          {(Object.keys(MODE_CONFIG) as ScanMode[]).map(m => (
            <option key={m} value={m}>{MODE_CONFIG[m].label}</option>
          ))}
        </select>
      </div>

      <div className={`h-1.5 ${MODE_CONFIG[scanMode].color}`} />

      <div className="flex-1 relative overflow-hidden">
        {cameraError ? (
          <div className="flex flex-col items-center justify-center h-full text-white space-y-3 px-8 text-center">
            <ExclamationTriangleIcon className="h-12 w-12 text-yellow-400" />
            <p className="font-semibold">Camera access denied</p>
            <p className="text-sm text-neutral-400">Allow camera permission in your browser settings to scan QR codes.</p>
          </div>
        ) : (
          <>
            <video ref={videoRef} autoPlay playsInline muted className="w-full h-full object-cover" />
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              <div className="w-56 h-56 relative">
                <div className="absolute top-0 left-0 w-8 h-8 border-t-4 border-l-4 border-white rounded-tl-lg" />
                <div className="absolute top-0 right-0 w-8 h-8 border-t-4 border-r-4 border-white rounded-tr-lg" />
                <div className="absolute bottom-0 left-0 w-8 h-8 border-b-4 border-l-4 border-white rounded-bl-lg" />
                <div className="absolute bottom-0 right-0 w-8 h-8 border-b-4 border-r-4 border-white rounded-br-lg" />
                <div className="absolute left-0 right-0 top-1/2 h-px bg-red-400 opacity-70" style={{ animation: 'scanline 2s linear infinite' }} />
              </div>
            </div>
            <p className="absolute bottom-6 left-0 right-0 text-center text-sm text-white/70">
              {scanMode === 'job_card_qc' ? 'Scan Job Card QR to enter QC data' : 'Point camera at QR code'}
            </p>
          </>
        )}
        <canvas ref={canvasRef} className="hidden" width={640} height={480} />
      </div>

      {result && (
        <ScanResultPanel
          data={result}
          mode={scanMode}
          onClose={() => setResult(null)}
        />
      )}

      <style>{`
        @keyframes scanline {
          0% { transform: translateY(-100px); }
          100% { transform: translateY(100px); }
        }
      `}</style>
    </div>
  );
}
