/**
 * Mobile Approvals Page — Large touch targets, optimized for phone screen
 * Task 11 — Part 4.2
 */
import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { approvalsService } from '@/services/mastersFull';

interface ApprovalItem {
  id: string;
  doc_type: string;
  doc_number: string;
  party_name: string;
  requested_by: string;
  amount_display: string;
  created_at: string;
}

function ApprovalCard({ item }: { item: ApprovalItem }) {
  const qc = useQueryClient();
  const [showRejectInput, setShowRejectInput] = useState(false);
  const [rejectReason, setRejectReason] = useState('');

  const approveMutation = useMutation({
    mutationFn: () => approvalsService.approve(item.id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['pending-approvals'] }),
  });

  const rejectMutation = useMutation({
    mutationFn: () => approvalsService.reject(item.id, rejectReason),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['pending-approvals'] });
      setShowRejectInput(false);
    },
  });

  const docTypeColors: Record<string, string> = {
    PR: 'text-orange-600 bg-orange-50',
    PO: 'text-blue-600 bg-blue-50',
    VOUCHER: 'text-purple-600 bg-purple-50',
    TASK: 'text-green-600 bg-green-50',
    LEAVE: 'text-pink-600 bg-pink-50',
    default: 'text-gray-600 bg-gray-50',
  };
  const colorClass = docTypeColors[item.doc_type] ?? docTypeColors.default;

  return (
    <div className="mx-3 mb-3 bg-white rounded-2xl shadow-sm border border-neutral-100 overflow-hidden">
      {/* Header */}
      <div className="px-4 py-3 border-b border-neutral-50">
        <div className="flex items-center justify-between mb-1">
          <span className={`text-xs font-bold uppercase px-2 py-0.5 rounded-full ${colorClass}`}>
            {item.doc_type}
          </span>
          <span className="text-xs font-semibold text-amber-600 bg-amber-50 px-2 py-0.5 rounded-full">
            {item.amount_display}
          </span>
        </div>
        <p className="font-bold text-neutral-900 text-base mt-1">{item.doc_number}</p>
        <p className="text-sm text-neutral-500">{item.party_name} · {item.requested_by}</p>
        <p className="text-xs text-neutral-400 mt-0.5">{new Date(item.created_at).toLocaleString()}</p>
      </div>

      {/* Reject Input */}
      {showRejectInput && (
        <div className="px-4 py-3 bg-red-50 border-b border-red-100">
          <input
            type="text"
            className="w-full border border-red-200 rounded-lg px-3 py-2 text-sm"
            placeholder="Rejection reason (required)"
            value={rejectReason}
            onChange={e => setRejectReason(e.target.value)}
            autoFocus
          />
          <div className="flex gap-2 mt-2">
            <button
              onClick={() => rejectMutation.mutate()}
              disabled={!rejectReason || rejectMutation.isPending}
              className="flex-1 py-2 bg-red-600 text-white rounded-lg text-sm font-medium disabled:opacity-50"
            >
              {rejectMutation.isPending ? 'Rejecting...' : 'Confirm Reject'}
            </button>
            <button
              onClick={() => setShowRejectInput(false)}
              className="px-4 py-2 border border-gray-200 rounded-lg text-sm"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Action Buttons */}
      {!showRejectInput && (
        <div className="flex">
          <button
            onClick={() => approveMutation.mutate()}
            disabled={approveMutation.isPending}
            className="flex-1 py-4 text-green-700 font-bold bg-green-50 hover:bg-green-100 active:bg-green-200 text-sm disabled:opacity-50 transition-colors"
          >
            {approveMutation.isPending ? (
              <span className="inline-block animate-spin mr-1">⟳</span>
            ) : '✓ '}
            Approve
          </button>
          <div className="w-px bg-neutral-200" />
          <button
            onClick={() => setShowRejectInput(true)}
            className="flex-1 py-4 text-red-700 font-bold bg-red-50 hover:bg-red-100 active:bg-red-200 text-sm transition-colors"
          >
            ✗ Reject
          </button>
        </div>
      )}
    </div>
  );
}

export function MobileApprovalsPage() {
  const { data, isLoading } = useQuery({
    queryKey: ['pending-approvals'],
    queryFn: () => approvalsService.getPending(),
    refetchInterval: 30000, // refresh every 30s
  });

  const items: ApprovalItem[] = data?.items ?? [];
  const total = data?.total ?? 0;

  return (
    <div className="min-h-screen bg-neutral-50 pb-20">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-800 to-blue-900 text-white px-5 pt-12 pb-6 safe-area-top">
        <h1 className="text-xl font-bold">Pending Approvals</h1>
        <p className="text-blue-300 text-sm mt-1">
          {isLoading ? 'Loading...' : `${total} item${total !== 1 ? 's' : ''} need${total === 1 ? 's' : ''} your attention`}
        </p>
      </div>

      {/* Content */}
      <div className="pt-4">
        {isLoading && (
          <div className="flex justify-center py-12">
            <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-blue-600" />
          </div>
        )}

        {!isLoading && items.length === 0 && (
          <div className="text-center py-16 px-6">
            <div className="text-5xl mb-4">✅</div>
            <h2 className="text-lg font-semibold text-gray-700">All caught up!</h2>
            <p className="text-gray-400 text-sm mt-1">No pending approvals at this time.</p>
          </div>
        )}

        {items.map(item => (
          <ApprovalCard key={item.id} item={item} />
        ))}
      </div>

      {/* Refresh hint */}
      {!isLoading && items.length > 0 && (
        <p className="text-center text-xs text-gray-400 mt-4 pb-6">
          Auto-refreshes every 30 seconds
        </p>
      )}
    </div>
  );
}
