import { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  PlusIcon, MagnifyingGlassIcon, ChatBubbleLeftIcon,
  ExclamationCircleIcon, UserCircleIcon, ClockIcon,
} from '@heroicons/react/24/outline';
import PageHeader from '@/components/ui/PageHeader';
import Badge from '@/components/ui/Badge';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import { tasksService } from '@/services/tasks';

type TStatus = 'TODO' | 'IN_PROGRESS' | 'DONE' | 'CANCELLED';
type TPriority = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';

const STATUS_BADGE_MAP: Record<TStatus, 'neutral' | 'info' | 'success' | 'danger'> = {
  TODO: 'neutral', IN_PROGRESS: 'info', DONE: 'success', CANCELLED: 'danger',
};
const PRIORITY_COLOR: Record<TPriority, string> = {
  LOW: 'text-neutral-500', MEDIUM: 'text-info-600', HIGH: 'text-warning-600', CRITICAL: 'text-danger-600',
};
const MODULES = ['Purchase', 'Sales', 'Production', 'Stores', 'Accounts', 'Quality', 'Dispatch', 'HR'];

export function TaskListPage() {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [tab, setTab] = useState<'mine' | 'by_me' | 'all'>('mine');
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');

  const params: Record<string, unknown> = {};
  if (tab === 'mine') params.assigned_to_me = true;
  if (tab === 'by_me') params.created_by_me = true;
  if (statusFilter !== 'ALL') params.status = statusFilter;
  if (search) params.search = search;

  const { data, isLoading } = useQuery({
    queryKey: ['tasks', tab, statusFilter, search],
    queryFn: () => tasksService.list(params),
  });

  const statusMutation = useMutation({
    mutationFn: ({ id, status }: { id: string; status: string }) => tasksService.updateStatus(id, status),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['tasks'] }),
  });

  const tasks = Array.isArray(data) ? data : data?.results || [];

  return (
    <div className="space-y-5">
      <PageHeader title="Tasks"
        actions={<button className="btn btn-primary" onClick={() => navigate('/tasks/new')}><PlusIcon className="h-4 w-4 mr-1" />New Task</button>} />
      <div className="flex gap-2 border-b border-neutral-200">
        {(['mine', 'by_me', 'all'] as const).map(t => (
          <button key={t} onClick={() => setTab(t)}
            className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors ${tab === t ? 'border-primary-600 text-primary-700' : 'border-transparent text-neutral-500 hover:text-neutral-700'}`}>
            {t === 'mine' ? 'My Tasks' : t === 'by_me' ? 'Created by Me' : 'All Tasks'}
          </button>
        ))}
      </div>
      <div className="flex gap-3">
        <div className="relative flex-1">
          <MagnifyingGlassIcon className="absolute left-3 top-2.5 h-4 w-4 text-neutral-400" />
          <input className="input pl-9" placeholder="Search…" value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <select className="input w-40" value={statusFilter} onChange={e => setStatusFilter(e.target.value)}>
          <option value="ALL">All Status</option>
          {['TODO', 'IN_PROGRESS', 'DONE', 'CANCELLED'].map(s => <option key={s} value={s}>{s.replace('_', ' ')}</option>)}
        </select>
      </div>
      {isLoading ? <LoadingSpinner /> : (
        <div className="card overflow-hidden">
          <table className="table">
            <thead><tr><th>Task</th><th>Priority</th><th>Status</th><th>Module</th><th>Assigned</th><th>Due</th><th>Change Status</th></tr></thead>
            <tbody>
              {tasks.length === 0
                ? <tr><td colSpan={7} className="text-center py-8 text-neutral-400">No tasks found.</td></tr>
                : tasks.map((t: any) => (
                  <tr key={t.id} className="hover:bg-neutral-50 cursor-pointer" onClick={() => navigate(`/tasks/${t.id}`)}>
                    <td><div className="flex items-center gap-2">{t.overdue && <ExclamationCircleIcon className="h-4 w-4 text-danger-500" />}<span className="font-medium">{t.title}</span></div></td>
                    <td><span className={`text-xs font-semibold ${PRIORITY_COLOR[t.priority as TPriority] || ''}`}>{t.priority}</span></td>
                    <td><Badge variant={STATUS_BADGE_MAP[t.status as TStatus] || 'neutral'}>{t.status?.replace('_', ' ')}</Badge></td>
                    <td className="text-sm text-neutral-500">{t.module || '—'}</td>
                    <td><div className="flex items-center gap-1.5"><UserCircleIcon className="h-4 w-4 text-neutral-400" /><span className="text-sm">{t.assigned_to_name || '—'}</span></div></td>
                    <td><div className="flex items-center gap-1"><ClockIcon className={`h-4 w-4 ${t.overdue ? 'text-danger-500' : 'text-neutral-400'}`} /><span className={`text-sm ${t.overdue ? 'text-danger-600' : ''}`}>{t.due_date}</span></div></td>
                    <td onClick={e => e.stopPropagation()}>
                      <select className="input py-1 text-xs w-32" value={t.status}
                        onChange={e => statusMutation.mutate({ id: t.id, status: e.target.value })}>
                        {['TODO', 'IN_PROGRESS', 'DONE', 'CANCELLED'].map(s => <option key={s} value={s}>{s.replace('_', ' ')}</option>)}
                      </select>
                    </td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

export function TaskDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [comment, setComment] = useState('');

  const { data: task, isLoading } = useQuery({ queryKey: ['task', id], queryFn: () => tasksService.get(id!), enabled: !!id });
  const addComment = useMutation({
    mutationFn: (text: string) => tasksService.addComment(id!, text),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['task', id] }); setComment(''); },
  });

  if (isLoading) return <LoadingSpinner />;
  if (!task) return <div className="p-8 text-neutral-400">Task not found.</div>;

  return (
    <div className="space-y-5">
      <PageHeader title={task.title} subtitle={`Task #${task.id}`}
        actions={<button className="btn btn-secondary" onClick={() => navigate(`/tasks/${id}/edit`)}>Edit</button>} />
      <div className="grid grid-cols-3 gap-5">
        <div className="col-span-2 space-y-4">
          <div className="card p-4"><h3 className="text-sm font-semibold text-neutral-700 mb-2">Description</h3><p className="text-neutral-600 whitespace-pre-wrap">{task.description || '—'}</p></div>
          <div className="card p-4">
            <h3 className="text-sm font-semibold text-neutral-700 mb-3 flex items-center gap-2"><ChatBubbleLeftIcon className="h-4 w-4" />Comments ({task.comments?.length || 0})</h3>
            <div className="space-y-3 mb-4">
              {(task.comments || []).map((c: any) => (
                <div key={c.id} className="flex gap-3"><UserCircleIcon className="h-8 w-8 text-neutral-400 flex-shrink-0" /><div className="flex-1 bg-neutral-50 rounded-lg p-3"><p className="text-xs font-semibold text-neutral-700 mb-1">{c.author_name} · {c.created_at}</p><p className="text-sm">{c.text || c.content}</p></div></div>
              ))}
            </div>
            <div className="flex gap-2">
              <input className="input flex-1" placeholder="Add comment…" value={comment} onChange={e => setComment(e.target.value)}
                onKeyDown={e => { if (e.key === 'Enter' && comment.trim()) addComment.mutate(comment.trim()); }} />
              <button className="btn btn-primary px-3" onClick={() => comment.trim() && addComment.mutate(comment.trim())}>Send</button>
            </div>
          </div>
        </div>
        <div className="card p-4 space-y-3 h-fit">
          {[['Status', task.status?.replace('_', ' ')], ['Priority', task.priority], ['Module', task.module || '—'], ['Assigned To', task.assigned_to_name || '—'], ['Due Date', task.due_date], ['Linked Doc', task.linked_doc || '—']].map(([l, v]) => (
            <div key={l}><p className="text-xs text-neutral-400 mb-0.5">{l}</p><p className="text-sm font-medium text-neutral-800">{v}</p></div>
          ))}
        </div>
      </div>
    </div>
  );
}

export function TaskFormPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const isEdit = !!id;
  const [form, setForm] = useState<any>({ title: '', description: '', priority: 'MEDIUM', module: '', due_date: '', assigned_to: '' });

  useQuery({ queryKey: ['task', id], queryFn: () => tasksService.get(id!).then(t => { setForm(t); return t; }), enabled: isEdit });

  const save = useMutation({
    mutationFn: (d: any) => isEdit ? tasksService.update(id!, d) : tasksService.create(d),
    onSuccess: (res) => { qc.invalidateQueries({ queryKey: ['tasks'] }); navigate(`/tasks/${res.id}`); },
  });

  const F = (f: string) => ({ value: form[f] || '', onChange: (e: any) => setForm((p: any) => ({ ...p, [f]: e.target.value })) });

  return (
    <div className="space-y-5 max-w-2xl">
      <PageHeader title={isEdit ? 'Edit Task' : 'New Task'} />
      <div className="card p-5 space-y-4">
        <div><label className="label">Title *</label><input className="input" {...F('title')} /></div>
        <div><label className="label">Description</label><textarea className="input" rows={3} {...F('description')} /></div>
        <div className="grid grid-cols-2 gap-4">
          <div><label className="label">Priority</label><select className="input" {...F('priority')}>{['LOW','MEDIUM','HIGH','CRITICAL'].map(p => <option key={p} value={p}>{p}</option>)}</select></div>
          <div><label className="label">Module</label><select className="input" {...F('module')}><option value="">— Select —</option>{MODULES.map(m => <option key={m} value={m}>{m}</option>)}</select></div>
          <div><label className="label">Due Date</label><input className="input" type="date" {...F('due_date')} /></div>
          <div><label className="label">Assigned To (ID)</label><input className="input" {...F('assigned_to')} /></div>
        </div>
        <div className="flex justify-end gap-2 pt-2">
          <button className="btn btn-secondary" onClick={() => navigate(-1)}>Cancel</button>
          <button className="btn btn-primary" disabled={save.isPending} onClick={() => save.mutate(form)}>
            {save.isPending ? 'Saving…' : isEdit ? 'Save Changes' : 'Create Task'}
          </button>
        </div>
      </div>
    </div>
  );
}
