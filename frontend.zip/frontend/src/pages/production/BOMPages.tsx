import { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { PlusIcon, MagnifyingGlassIcon, TrashIcon } from '@heroicons/react/24/outline';
import PageHeader from '@/components/ui/PageHeader';
import Badge from '@/components/ui/Badge';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import { productionService } from '@/services/production';

const STATUS_BADGE: Record<string, 'success' | 'warning' | 'neutral'> = {
  ACTIVE: 'success', DRAFT: 'warning', OBSOLETE: 'neutral',
};

export function BOMListPage() {
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const { data, isLoading } = useQuery({
    queryKey: ['boms', search],
    queryFn: () => productionService.listBOMs({ search }),
  });
  const boms = Array.isArray(data) ? data : data?.results || [];

  return (
    <div className="space-y-5">
      <PageHeader title="Bill of Materials"
        actions={<button className="btn btn-primary" onClick={() => navigate('/production/boms/new')}><PlusIcon className="h-4 w-4 mr-1" />New BOM</button>} />
      <div className="relative"><MagnifyingGlassIcon className="absolute left-3 top-2.5 h-4 w-4 text-neutral-400" /><input className="input pl-9 w-72" placeholder="Search BOM…" value={search} onChange={e => setSearch(e.target.value)} /></div>
      {isLoading ? <LoadingSpinner /> : (
        <div className="card overflow-hidden">
          <table className="table">
            <thead><tr><th>BOM No.</th><th>FG Code</th><th>FG Name</th><th>Rev.</th><th>Effective From</th><th>Status</th><th>Components</th></tr></thead>
            <tbody>
              {boms.length === 0
                ? <tr><td colSpan={7} className="text-center py-8 text-neutral-400">No BOMs found.</td></tr>
                : boms.map((b: any) => (
                  <tr key={b.id} className="hover:bg-neutral-50 cursor-pointer" onClick={() => navigate(`/production/boms/${b.id}`)}>
                    <td className="font-mono text-sm font-medium text-primary-700">{b.bom_number}</td>
                    <td className="text-sm">{b.fg_code || b.finished_good?.code}</td>
                    <td className="font-medium">{b.fg_name || b.finished_good?.name}</td>
                    <td className="text-center">Rev. {b.revision}</td>
                    <td className="text-sm text-neutral-500">{b.effective_from}</td>
                    <td><Badge variant={STATUS_BADGE[b.status] || 'neutral'}>{b.status}</Badge></td>
                    <td className="text-center text-sm">{b.lines_count ?? b.lines?.length ?? '—'}</td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

export function BOMDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { data: bom, isLoading } = useQuery({ queryKey: ['bom', id], queryFn: () => productionService.getBOM(id!), enabled: !!id });

  if (isLoading) return <LoadingSpinner />;
  if (!bom) return <div className="p-8 text-neutral-400">BOM not found.</div>;

  const lines = bom.lines || [];

  return (
    <div className="space-y-5">
      <PageHeader title={`BOM: ${bom.bom_number}`} subtitle={`Rev. ${bom.revision} — ${bom.fg_name || bom.finished_good?.name}`}
        actions={<button className="btn btn-secondary" onClick={() => navigate(`/production/boms/${id}/edit`)}>Edit</button>} />
      <div className="card overflow-hidden">
        <div className="px-4 py-3 border-b border-neutral-100 flex items-center justify-between">
          <h3 className="text-sm font-semibold text-neutral-700">Components ({lines.length})</h3>
          <Badge variant={STATUS_BADGE[bom.status] || 'neutral'}>{bom.status}</Badge>
        </div>
        <table className="table">
          <thead><tr><th>Code</th><th>Component</th><th>Qty/Unit</th><th>UOM</th><th>Wastage %</th><th>Net Qty</th><th>Remarks</th></tr></thead>
          <tbody>
            {lines.map((l: any) => (
              <tr key={l.id}>
                <td className="font-mono text-xs">{l.component_code || l.item?.code}</td>
                <td>{l.component_name || l.item?.name}</td>
                <td className="text-right tabular-nums">{l.qty_per_unit}</td>
                <td>{l.uom?.code || l.uom}</td>
                <td className="text-right tabular-nums">{l.wastage_pct ?? 0}%</td>
                <td className="text-right tabular-nums font-medium">{l.net_qty ?? l.qty_per_unit}</td>
                <td className="text-xs text-neutral-500">{l.remarks || '—'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export function BOMFormPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const isEdit = !!id;
  const [form, setForm] = useState<any>({ fg_code: '', fg_name: '', revision: 1, effective_from: '', status: 'DRAFT', lines: [] });
  const [newLine, setNewLine] = useState({ component_code: '', component_name: '', qty_per_unit: '', uom: '', wastage_pct: '0', remarks: '' });

  useQuery({ queryKey: ['bom', id], queryFn: () => productionService.getBOM(id!).then(b => { setForm(b); return b; }), enabled: isEdit });

  const save = useMutation({
    mutationFn: (d: any) => isEdit ? productionService.updateBOM(id!, d) : productionService.createBOM(d),
    onSuccess: (res) => { qc.invalidateQueries({ queryKey: ['boms'] }); navigate(`/production/boms/${res.id}`); },
  });

  const F = (f: string) => ({ value: form[f] || '', onChange: (e: any) => setForm((p: any) => ({ ...p, [f]: e.target.value })) });
  const addLine = () => {
    setForm((p: any) => ({ ...p, lines: [...(p.lines || []), { ...newLine, id: Date.now() }] }));
    setNewLine({ component_code: '', component_name: '', qty_per_unit: '', uom: '', wastage_pct: '0', remarks: '' });
  };

  return (
    <div className="space-y-5 max-w-4xl">
      <PageHeader title={isEdit ? 'Edit BOM' : 'New BOM'} />
      <div className="card p-5 space-y-4">
        <div className="grid grid-cols-3 gap-4">
          <div><label className="label">FG Code *</label><input className="input" {...F('fg_code')} /></div>
          <div><label className="label">FG Name *</label><input className="input" {...F('fg_name')} /></div>
          <div><label className="label">Revision</label><input className="input" type="number" {...F('revision')} /></div>
          <div><label className="label">Effective From</label><input className="input" type="date" {...F('effective_from')} /></div>
          <div><label className="label">Status</label><select className="input" {...F('status')}>{['DRAFT','ACTIVE','OBSOLETE'].map(s => <option key={s} value={s}>{s}</option>)}</select></div>
        </div>
        <div>
          <h3 className="text-sm font-semibold text-neutral-700 mb-3">Components</h3>
          <table className="table mb-3">
            <thead><tr><th>Code</th><th>Name</th><th>Qty/Unit</th><th>UOM</th><th>Wastage %</th><th>Remarks</th><th></th></tr></thead>
            <tbody>
              {(form.lines || []).map((l: any, i: number) => (
                <tr key={l.id || i}>
                  <td className="font-mono text-xs">{l.component_code}</td><td>{l.component_name}</td>
                  <td className="text-right">{l.qty_per_unit}</td><td>{l.uom}</td>
                  <td className="text-right">{l.wastage_pct}%</td><td className="text-xs">{l.remarks}</td>
                  <td><button onClick={() => setForm((p: any) => ({ ...p, lines: p.lines.filter((_: any, j: number) => j !== i) }))}><TrashIcon className="h-4 w-4 text-danger-500" /></button></td>
                </tr>
              ))}
              <tr>
                {['component_code','component_name','qty_per_unit','uom','wastage_pct','remarks'].map(f => (
                  <td key={f}><input className="input py-1 text-xs" value={(newLine as any)[f]} onChange={e => setNewLine(p => ({ ...p, [f]: e.target.value }))} /></td>
                ))}
                <td><button className="btn btn-secondary py-1 text-xs" onClick={addLine}>Add</button></td>
              </tr>
            </tbody>
          </table>
        </div>
        <div className="flex justify-end gap-2 pt-2">
          <button className="btn btn-secondary" onClick={() => navigate(-1)}>Cancel</button>
          <button className="btn btn-primary" disabled={save.isPending} onClick={() => save.mutate(form)}>
            {save.isPending ? 'Saving…' : isEdit ? 'Update BOM' : 'Create BOM'}
          </button>
        </div>
      </div>
    </div>
  );
}
