import { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { PlusIcon, MagnifyingGlassIcon, CpuChipIcon } from '@heroicons/react/24/outline';
import PageHeader from '@/components/ui/PageHeader';
import Badge from '@/components/ui/Badge';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import { productionService } from '@/services/production';

const STATUS_BADGE: Record<string, any> = {
  DRAFT: 'neutral', PLANNED: 'info', IN_PROGRESS: 'warning', COMPLETED: 'success', CANCELLED: 'danger',
};

export function WorkOrderListPage() {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('');

  const { data, isLoading } = useQuery({
    queryKey: ['work-orders', search, status],
    queryFn: () => productionService.listWorkOrders({ search, status: status || undefined }),
  });
  const orders = Array.isArray(data) ? data : data?.results || [];

  const advanceMutation = useMutation({
    mutationFn: ({ id, s }: { id: string; s: string }) => productionService.advanceStatus(id, s),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['work-orders'] }),
  });

  return (
    <div className="space-y-5">
      <PageHeader title="Work Orders"
        actions={<button className="btn btn-primary" onClick={() => navigate('/production/work-orders/new')}><PlusIcon className="h-4 w-4 mr-1" />New WO</button>} />
      <div className="flex gap-3">
        <div className="relative flex-1"><MagnifyingGlassIcon className="absolute left-3 top-2.5 h-4 w-4 text-neutral-400" /><input className="input pl-9" placeholder="Search…" value={search} onChange={e => setSearch(e.target.value)} /></div>
        <select className="input w-44" value={status} onChange={e => setStatus(e.target.value)}>
          <option value="">All Status</option>
          {['DRAFT','PLANNED','IN_PROGRESS','COMPLETED','CANCELLED'].map(s => <option key={s} value={s}>{s.replace('_', ' ')}</option>)}
        </select>
      </div>
      {isLoading ? <LoadingSpinner /> : (
        <div className="card overflow-hidden">
          <table className="table">
            <thead><tr><th>WO No.</th><th>FG</th><th>Qty</th><th>Machine</th><th>Planned Date</th><th>Status</th><th>Advance</th></tr></thead>
            <tbody>
              {orders.length === 0
                ? <tr><td colSpan={7} className="text-center py-8 text-neutral-400">No work orders.</td></tr>
                : orders.map((w: any) => (
                  <tr key={w.id} className="hover:bg-neutral-50 cursor-pointer" onClick={() => navigate(`/production/work-orders/${w.id}`)}>
                    <td className="font-mono text-sm font-medium text-primary-700">{w.wo_number}</td>
                    <td className="text-sm">{w.fg_name || w.finished_good?.name}</td>
                    <td className="text-right tabular-nums">{w.planned_qty} {w.uom?.code || ''}</td>
                    <td className="text-sm text-neutral-500">{w.work_center_name || w.work_center?.name || '—'}</td>
                    <td className="text-sm">{w.planned_date}</td>
                    <td><Badge variant={STATUS_BADGE[w.status] || 'neutral'}>{w.status?.replace('_', ' ')}</Badge></td>
                    <td onClick={e => e.stopPropagation()}>
                      {w.status !== 'COMPLETED' && w.status !== 'CANCELLED' && (
                        <select className="input py-1 text-xs w-32" value={w.status}
                          onChange={e => advanceMutation.mutate({ id: w.id, s: e.target.value })}>
                          {['DRAFT','PLANNED','IN_PROGRESS','COMPLETED'].map(s => <option key={s} value={s}>{s.replace('_', ' ')}</option>)}
                        </select>
                      )}
                    </td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

export function WorkOrderDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { data: wo, isLoading } = useQuery({
    queryKey: ['work-order', id],
    queryFn: () => productionService.getWorkOrder(id!),
    enabled: !!id,
  });
  const { data: jcData } = useQuery({
    queryKey: ['job-cards', id],
    queryFn: () => productionService.listJobCards({ work_order: id }),
    enabled: !!id,
  });
  const jobCards = Array.isArray(jcData) ? jcData : jcData?.results || [];

  if (isLoading) return <LoadingSpinner />;
  if (!wo) return <div className="p-8 text-neutral-400">Work order not found.</div>;

  // P2 – suggested_work_centers populated by backend auto-allocation
  const suggestions: Array<{ code: string; name: string; machine_type?: string }> =
    Array.isArray(wo.suggested_work_centers) ? wo.suggested_work_centers : [];

  return (
    <div className="space-y-5">
      <PageHeader title={`WO: ${wo.wo_number}`} subtitle={wo.fg_name || wo.finished_good?.name}
        actions={<button className="btn btn-secondary" onClick={() => navigate(`/production/work-orders/${id}/edit`)}>Edit</button>} />

      <div className="grid grid-cols-4 gap-4">
        {[
          ['Status', wo.status?.replace('_', ' ')],
          ['Planned Qty', `${wo.planned_qty} ${wo.uom?.code || ''}`],
          ['Actual Qty', wo.actual_qty ?? '—'],
          ['Planned Date', wo.planned_date],
        ].map(([l, v]) => (
          <div key={l} className="card p-3">
            <p className="text-xs text-neutral-400">{l}</p>
            <p className="text-lg font-semibold text-neutral-900">{v}</p>
          </div>
        ))}
      </div>

      {/* P2 – Machine Auto-Allocation suggestions card */}
      {suggestions.length > 0 && (
        <div className="card p-4">
          <div className="flex items-center gap-2 mb-3">
            <CpuChipIcon className="h-4 w-4 text-primary-600" />
            <h3 className="text-sm font-semibold text-neutral-700">Suggested Work Centres</h3>
            <span className="text-xs text-neutral-400">(auto-matched from box dimensions)</span>
          </div>
          <div className="flex flex-wrap gap-2">
            {suggestions.map((s, i) => (
              <div key={i} className="inline-flex items-center gap-2 rounded-lg border border-primary-200 bg-primary-50 px-3 py-1.5 text-sm">
                <span className="font-semibold text-primary-800">{s.code}</span>
                <span className="text-primary-600">{s.name}</span>
                {s.machine_type && (
                  <span className="text-[10px] uppercase tracking-wide bg-primary-100 text-primary-700 rounded px-1.5 py-0.5">
                    {s.machine_type.replace('_', ' ')}
                  </span>
                )}
              </div>
            ))}
          </div>
          <p className="mt-2 text-xs text-neutral-400">
            These machines can handle the finished good's box width. Select one when assigning Job Cards.
          </p>
        </div>
      )}

      <div className="card overflow-hidden">
        <div className="px-4 py-3 border-b border-neutral-100">
          <h3 className="text-sm font-semibold text-neutral-700">Job Cards ({jobCards.length})</h3>
        </div>
        <table className="table">
          <thead><tr><th>Job Card No.</th><th>Stage</th><th>Qty Planned</th><th>Qty Done</th><th>Status</th></tr></thead>
          <tbody>
            {jobCards.length === 0
              ? <tr><td colSpan={5} className="text-center py-4 text-neutral-400">No job cards.</td></tr>
              : jobCards.map((j: any) => (
                <tr key={j.id} className="hover:bg-neutral-50 cursor-pointer" onClick={() => navigate(`/production/job-cards/${j.id}`)}>
                  <td className="font-mono text-sm">{j.jc_number}</td>
                  <td className="text-sm">{j.stage_name || j.work_center?.name}</td>
                  <td className="text-right">{j.planned_qty}</td>
                  <td className="text-right">{j.actual_qty ?? '—'}</td>
                  <td><Badge variant={STATUS_BADGE[j.status] || 'neutral'}>{j.status}</Badge></td>
                </tr>
              ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export function WorkOrderFormPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const isEdit = !!id;
  const [form, setForm] = useState<any>({ fg_code: '', planned_qty: '', planned_date: '', priority: 'MEDIUM', notes: '' });
  const [boxWidth, setBoxWidth] = useState('');

  useQuery({
    queryKey: ['work-order', id],
    queryFn: () => productionService.getWorkOrder(id!).then(w => { setForm(w); return w; }),
    enabled: isEdit,
  });

  // P2 – Live machine suggestion query
  const { data: suggestionData } = useQuery({
    queryKey: ['wc-suggest', boxWidth],
    queryFn: () => productionService.suggestWorkCenters(parseFloat(boxWidth)),
    enabled: !!boxWidth && parseFloat(boxWidth) > 0,
  });
  const suggestions = suggestionData?.suggested_work_centers ?? [];

  const save = useMutation({
    mutationFn: (d: any) =>
      isEdit
        ? productionService.updateWorkOrder(id!, d)
        : productionService.createWorkOrder(d),
    onSuccess: (res: any) => {
      qc.invalidateQueries({ queryKey: ['work-orders'] });
      navigate(`/production/work-orders/${res.id}`);
    },
  });

  const F = (f: string) => ({
    value: form[f] || '',
    onChange: (e: any) => setForm((p: any) => ({ ...p, [f]: e.target.value })),
  });

  return (
    <div className="space-y-5 max-w-xl">
      <PageHeader title={isEdit ? 'Edit Work Order' : 'New Work Order'} />
      <div className="card p-5 space-y-4">
        <div><label className="label">FG Code *</label><input className="input" {...F('fg_code')} /></div>
        <div className="grid grid-cols-2 gap-4">
          <div><label className="label">Planned Qty *</label><input className="input" type="number" {...F('planned_qty')} /></div>
          <div><label className="label">Planned Date *</label><input className="input" type="date" {...F('planned_date')} /></div>
          <div><label className="label">Priority</label>
            <select className="input" {...F('priority')}>
              {['LOW','MEDIUM','HIGH','CRITICAL'].map(p => <option key={p}>{p}</option>)}
            </select>
          </div>
          {/* P2 – Box width field for machine suggestion */}
          <div>
            <label className="label">Box Width (mm)</label>
            <input
              className="input"
              type="number"
              placeholder="e.g. 380"
              value={boxWidth}
              onChange={e => setBoxWidth(e.target.value)}
            />
          </div>
        </div>

        {/* P2 – Show live machine suggestions */}
        {suggestions.length > 0 && (
          <div className="rounded-lg border border-primary-200 bg-primary-50 p-3 space-y-1.5">
            <div className="flex items-center gap-1.5 text-xs font-semibold text-primary-700">
              <CpuChipIcon className="h-3.5 w-3.5" /> Suggested Machines for {boxWidth}mm
            </div>
            <div className="flex flex-wrap gap-1.5">
              {suggestions.map((s: any, i: number) => (
                <span key={i} className="text-xs rounded border border-primary-300 bg-white px-2 py-0.5 text-primary-800">
                  {s.code} — {s.name}
                  {s.machine_type && <span className="ml-1 text-[10px] text-primary-500">({s.machine_type.replace('_', ' ')})</span>}
                </span>
              ))}
            </div>
          </div>
        )}
        {boxWidth && parseFloat(boxWidth) > 0 && suggestions.length === 0 && (
          <p className="text-xs text-neutral-400">No machines configured for {boxWidth}mm — check WorkCenter deckle settings.</p>
        )}

        <div><label className="label">Notes</label><textarea className="input" rows={2} {...F('notes')} /></div>
        <div className="flex justify-end gap-2">
          <button className="btn btn-secondary" onClick={() => navigate(-1)}>Cancel</button>
          <button className="btn btn-primary" disabled={save.isPending} onClick={() => save.mutate(form)}>
            {save.isPending ? 'Saving…' : isEdit ? 'Update' : 'Create'}
          </button>
        </div>
      </div>
    </div>
  );
}
