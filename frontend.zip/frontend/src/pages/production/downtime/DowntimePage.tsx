/**
 * Production Downtime Pages — Machine Downtime Recording & Reporting
 * Task 11 — Part 3.4
 */
import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { productionService } from '@/services/production';

const CATEGORIES = [
  { value: 'BREAKDOWN', label: 'Machine Breakdown', color: 'bg-red-100 text-red-800' },
  { value: 'PLANNED_MAINT', label: 'Planned Maintenance', color: 'bg-blue-100 text-blue-800' },
  { value: 'POWER_CUT', label: 'Power Failure', color: 'bg-yellow-100 text-yellow-800' },
  { value: 'NO_MATERIAL', label: 'No Raw Material', color: 'bg-orange-100 text-orange-800' },
  { value: 'NO_OPERATOR', label: 'No Operator', color: 'bg-purple-100 text-purple-800' },
  { value: 'CHANGEOVER', label: 'Product Changeover', color: 'bg-cyan-100 text-cyan-800' },
  { value: 'QC_HOLD', label: 'QC Hold', color: 'bg-pink-100 text-pink-800' },
  { value: 'OTHER', label: 'Other', color: 'bg-gray-100 text-gray-800' },
];

function CategoryBadge({ category }: { category: string }) {
  const cat = CATEGORIES.find(c => c.value === category);
  return (
    <span className={`px-2 py-0.5 rounded-full text-xs font-semibold ${cat?.color ?? 'bg-gray-100 text-gray-700'}`}>
      {cat?.label ?? category}
    </span>
  );
}

function formatDuration(mins: number | null) {
  if (!mins) return '—';
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  return h > 0 ? `${h}h ${m}m` : `${m}m`;
}

// ─── Downtime List Page ───────────────────────────────────────────

export function DowntimeListPage() {
  const navigate = useNavigate();
  const [filters, setFilters] = useState<Record<string, string>>({});

  const { data, isLoading } = useQuery({
    queryKey: ['downtime-list', filters],
    queryFn: () => productionService.listDowntime(filters),
  });

  const { data: summary } = useQuery({
    queryKey: ['downtime-summary'],
    queryFn: () => productionService.getDowntimeSummary(),
  });

  const records = data?.results ?? data ?? [];
  const byCat = summary?.by_category ?? [];
  const totalMins = byCat.reduce((sum: number, c: any) => sum + c.total_minutes, 0);

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Production Downtime</h1>
          <p className="text-sm text-gray-500 mt-1">Machine downtime entry and CAPA tracking</p>
        </div>
        <button
          onClick={() => navigate('/production/downtime/new')}
          className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium"
        >
          + Record Downtime
        </button>
      </div>

      {/* Summary Bar */}
      {byCat.length > 0 && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-5 mb-6">
          <h2 className="font-semibold text-gray-700 mb-3">This Period Summary — {formatDuration(totalMins)} total</h2>
          <div className="flex gap-3 flex-wrap">
            {byCat.map((c: any) => (
              <div key={c.category} className="flex items-center gap-2 bg-gray-50 rounded-lg px-3 py-2">
                <CategoryBadge category={c.category} />
                <span className="text-sm font-semibold">{formatDuration(c.total_minutes)}</span>
                <span className="text-xs text-gray-400">({c.count})</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Filters */}
      <div className="flex gap-3 mb-4">
        <select
          value={filters.category ?? ''}
          onChange={e => setFilters(f => ({ ...f, category: e.target.value }))}
          className="border rounded-lg px-3 py-2 text-sm"
        >
          <option value="">All Categories</option>
          {CATEGORIES.map(c => (
            <option key={c.value} value={c.value}>{c.label}</option>
          ))}
        </select>
        <input type="date" className="border rounded-lg px-3 py-2 text-sm"
          onChange={e => setFilters(f => ({ ...f, date_from: e.target.value }))}
          placeholder="From date" />
        <input type="date" className="border rounded-lg px-3 py-2 text-sm"
          onChange={e => setFilters(f => ({ ...f, date_to: e.target.value }))}
          placeholder="To date" />
      </div>

      {isLoading ? (
        <div className="flex justify-center py-16"><div className="animate-spin rounded-full h-10 w-10 border-b-2 border-blue-600" /></div>
      ) : (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                {['Work Center', 'Shift', 'Start Time', 'Duration', 'Category', 'Reason', 'Dept', 'CAPA'].map(h => (
                  <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {records.length === 0 && (
                <tr><td colSpan={8} className="text-center py-10 text-gray-400">No downtime records found</td></tr>
              )}
              {records.map((dt: any) => (
                <tr key={dt.id} className="hover:bg-gray-50">
                  <td className="px-4 py-3 text-sm font-medium">{dt.work_center_name}</td>
                  <td className="px-4 py-3 text-sm">{dt.shift_display}</td>
                  <td className="px-4 py-3 text-sm">{new Date(dt.downtime_start).toLocaleString()}</td>
                  <td className="px-4 py-3 text-sm font-semibold">{formatDuration(dt.duration_minutes)}</td>
                  <td className="px-4 py-3"><CategoryBadge category={dt.category} /></td>
                  <td className="px-4 py-3 text-sm text-gray-600 max-w-48 truncate">{dt.reason_detail}</td>
                  <td className="px-4 py-3 text-sm">{dt.responsible_dept || '—'}</td>
                  <td className="px-4 py-3 text-sm">
                    {dt.capa_required ? (
                      <span className="bg-red-100 text-red-700 px-2 py-0.5 rounded text-xs">CAPA Required</span>
                    ) : (
                      <span className="text-gray-300 text-xs">—</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

// ─── Downtime Form Page ───────────────────────────────────────────

export function DowntimeFormPage() {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [form, setForm] = useState({
    work_center: '', work_order: '', shift: 'A',
    downtime_start: '', downtime_end: '',
    category: '', reason_detail: '', responsible_dept: '', capa_required: false,
  });

  const { data: workCenters } = useQuery({
    queryKey: ['work-centers'],
    queryFn: () => productionService.listWorkCenters(),
  });

  const set = (k: string, v: string | boolean) => setForm(f => ({ ...f, [k]: v }));

  // Auto-calculate duration
  const durationMins = form.downtime_start && form.downtime_end
    ? Math.round((new Date(form.downtime_end).getTime() - new Date(form.downtime_start).getTime()) / 60000)
    : null;

  const createMutation = useMutation({
    mutationFn: (data: unknown) => productionService.createDowntime(data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['downtime-list'] });
      qc.invalidateQueries({ queryKey: ['downtime-summary'] });
      navigate('/production/downtime');
    },
  });

  return (
    <div className="p-6 max-w-2xl">
      <h1 className="text-2xl font-bold text-gray-900 mb-6">Record Downtime</h1>

      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Work Center</label>
            <select className="w-full border rounded-lg px-3 py-2 text-sm"
              value={form.work_center} onChange={e => set('work_center', e.target.value)}>
              <option value="">Select Work Center</option>
              {(workCenters?.results ?? workCenters ?? []).map((wc: any) => (
                <option key={wc.id} value={wc.id}>{wc.name}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Shift</label>
            <select className="w-full border rounded-lg px-3 py-2 text-sm"
              value={form.shift} onChange={e => set('shift', e.target.value)}>
              <option value="A">Shift A</option>
              <option value="B">Shift B</option>
              <option value="C">Shift C</option>
              <option value="G">General</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Start Time</label>
            <input type="datetime-local" className="w-full border rounded-lg px-3 py-2 text-sm"
              value={form.downtime_start} onChange={e => set('downtime_start', e.target.value)} />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">End Time</label>
            <input type="datetime-local" className="w-full border rounded-lg px-3 py-2 text-sm"
              value={form.downtime_end} onChange={e => set('downtime_end', e.target.value)} />
          </div>
        </div>

        {durationMins !== null && durationMins > 0 && (
          <div className="bg-blue-50 text-blue-700 px-3 py-2 rounded-lg text-sm">
            ⏱ Duration: <strong>{formatDuration(durationMins)}</strong>
          </div>
        )}

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
          <select className="w-full border rounded-lg px-3 py-2 text-sm"
            value={form.category} onChange={e => set('category', e.target.value)}>
            <option value="">Select Category</option>
            {CATEGORIES.map(c => (
              <option key={c.value} value={c.value}>{c.label}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Reason / Detail</label>
          <textarea className="w-full border rounded-lg px-3 py-2 text-sm" rows={3}
            value={form.reason_detail} onChange={e => set('reason_detail', e.target.value)} />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Responsible Dept (Man/Machine/Material/Method)</label>
          <input className="w-full border rounded-lg px-3 py-2 text-sm"
            value={form.responsible_dept} onChange={e => set('responsible_dept', e.target.value)} />
        </div>

        <div className="flex items-center gap-3">
          <input type="checkbox" id="capa_req" checked={form.capa_required}
            onChange={e => set('capa_required', e.target.checked)}
            className="h-4 w-4 rounded" />
          <label htmlFor="capa_req" className="text-sm font-medium text-gray-700">CAPA Required?</label>
        </div>

        {form.capa_required && (
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 text-sm text-amber-700">
            A CAPA record will be linked after saving. Please create CAPA in Quality module.
          </div>
        )}

        {createMutation.isError && (
          <div className="bg-red-50 text-red-700 p-3 rounded-lg text-sm">Failed to record downtime.</div>
        )}

        <div className="flex gap-3 pt-2">
          <button
            onClick={() => createMutation.mutate(form)}
            disabled={createMutation.isPending || !form.work_center || !form.category}
            className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium disabled:opacity-50"
          >
            {createMutation.isPending ? 'Saving...' : 'Save Downtime'}
          </button>
          <button onClick={() => navigate('/production/downtime')}
            className="px-6 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── Downtime Dashboard Widget ────────────────────────────────────

export function DowntimeDashboardWidget() {
  const { data: summary } = useQuery({
    queryKey: ['downtime-summary'],
    queryFn: () => productionService.getDowntimeSummary(),
  });

  const byCat = summary?.by_category ?? [];
  const byWC = summary?.by_work_center ?? [];

  const maxMins = Math.max(...byCat.map((c: any) => c.total_minutes), 1);

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-5">
      <h2 className="font-semibold text-gray-700 mb-4">Downtime by Category (this period)</h2>
      <div className="space-y-2">
        {byCat.slice(0, 6).map((c: any) => (
          <div key={c.category} className="flex items-center gap-3">
            <div className="w-28 text-xs text-gray-600 truncate">{c.category}</div>
            <div className="flex-1 bg-gray-100 rounded-full h-4 overflow-hidden">
              <div
                className="h-4 bg-blue-500 rounded-full"
                style={{ width: `${(c.total_minutes / maxMins) * 100}%` }}
              />
            </div>
            <div className="text-xs font-semibold w-16 text-right">{formatDuration(c.total_minutes)}</div>
          </div>
        ))}
      </div>
      {byWC.length > 0 && (
        <>
          <h3 className="font-semibold text-gray-600 mt-5 mb-3 text-sm">Top Machines by Downtime</h3>
          <div className="space-y-1">
            {byWC.slice(0, 5).map((wc: any, idx: number) => (
              <div key={idx} className="flex justify-between text-sm">
                <span className="text-gray-700">{wc.work_center}</span>
                <span className="font-semibold text-gray-900">{formatDuration(wc.total_minutes)}</span>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
