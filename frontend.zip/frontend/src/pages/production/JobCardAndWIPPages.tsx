import { useState } from 'react';
import { useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  PlusIcon, MagnifyingGlassIcon, QrCodeIcon,
  CheckCircleIcon, ExclamationTriangleIcon,
} from '@heroicons/react/24/outline';
import PageHeader from '@/components/ui/PageHeader';
import Badge from '@/components/ui/Badge';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import { productionService } from '@/services/production';
import api from '@/services/api';

const STATUS_BADGE: Record<string, any> = {
  OPEN: 'neutral', IN_PROGRESS: 'warning', COMPLETED: 'success', ON_HOLD: 'info',
};
const STAGES = ['OPEN', 'IN_PROGRESS', 'ON_HOLD', 'COMPLETED'];

export function JobCardPage() {
  const { id } = useParams<{ id: string }>();
  if (id) return <JobCardDetailPage />;
  return <JobCardListPage />;
}

export function JobCardListPage() {
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('');
  const { data, isLoading } = useQuery({
    queryKey: ['job-cards', search, status],
    queryFn: () => productionService.listJobCards({ search, status: status || undefined }),
  });
  const cards = Array.isArray(data) ? data : data?.results || [];

  return (
    <div className="space-y-5">
      <PageHeader title="Job Cards"
        actions={
          <div className="flex gap-2">
            <button className="btn btn-secondary" onClick={() => navigate('/mobile/scanner?mode=job_card_qc')}>
              <QrCodeIcon className="h-4 w-4 mr-1" />Scan QC
            </button>
            <button className="btn btn-primary" onClick={() => navigate('/production/job-cards/new')}>
              <PlusIcon className="h-4 w-4 mr-1" />New Job Card
            </button>
          </div>
        } />
      <div className="flex gap-3">
        <div className="relative flex-1"><MagnifyingGlassIcon className="absolute left-3 top-2.5 h-4 w-4 text-neutral-400" /><input className="input pl-9" placeholder="Search..." value={search} onChange={e => setSearch(e.target.value)} /></div>
        <select className="input w-40" value={status} onChange={e => setStatus(e.target.value)}>
          <option value="">All Status</option>
          {STAGES.map(s => <option key={s} value={s}>{s.replace('_', ' ')}</option>)}
        </select>
      </div>
      {isLoading ? <LoadingSpinner /> : (
        <div className="card overflow-hidden">
          <table className="table">
            <thead><tr><th>JC No.</th><th>Work Order</th><th>FG / Stage</th><th>Planned</th><th>Actual</th><th>Status</th></tr></thead>
            <tbody>
              {cards.length === 0
                ? <tr><td colSpan={6} className="text-center py-8 text-neutral-400">No job cards.</td></tr>
                : cards.map((j: any) => (
                  <tr key={j.id} className="hover:bg-neutral-50 cursor-pointer" onClick={() => navigate(`/production/job-cards/${j.id}`)}>
                    <td className="font-mono text-sm font-medium text-primary-700">{j.jc_number}</td>
                    <td className="text-sm text-neutral-500">{j.work_order_number || j.work_order?.wo_number}</td>
                    <td><p className="text-sm font-medium">{j.fg_name || '—'}</p><p className="text-xs text-neutral-400">{j.stage_name || j.work_center?.name}</p></td>
                    <td className="text-right tabular-nums">{j.planned_qty}</td>
                    <td className="text-right tabular-nums">{j.actual_qty ?? '—'}</td>
                    <td><Badge variant={STATUS_BADGE[j.status] || 'neutral'}>{j.status?.replace('_', ' ')}</Badge></td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

// ─── QC Entry Form (after QR scan) ────────────────────────────────
function QCScanForm({ qrCode, onDone }: { qrCode: string; onDone: () => void }) {
  const [stage, setStage] = useState('');
  const [qtyProduced, setQtyProduced] = useState('');
  const [qtyRejected, setQtyRejected] = useState('');
  const [rejectionReason, setRejectionReason] = useState('');
  const [toast, setToast] = useState<string | null>(null);

  const { data: jcData, isLoading: jcLoading, isError: jcError } = useQuery({
    queryKey: ['job-card-scan', qrCode],
    queryFn: () =>
      api.get('/api/v1/production/job-cards/scan/', { params: { qr: qrCode } }).then(r => r.data),
    enabled: !!qrCode,
  });

  const submitMutation = useMutation({
    mutationFn: (payload: any) =>
      api.post('/api/v1/quality/inspection-lots/from-scan/', payload).then(r => r.data),
    onSuccess: (data) => {
      let msg = `Inspection Lot created: ${data.inspection_lot_number}`;
      if (data.ncr_id) msg += `  |  NCR raised: ${data.ncr_id}`;
      setToast(msg);
      setTimeout(() => { setToast(null); onDone(); }, 3500);
    },
    onError: (err: any) => {
      setToast(`Error: ${err?.response?.data?.error || 'Submission failed'}`);
    },
  });

  if (jcLoading) return <LoadingSpinner />;
  if (jcError)
    return <div className="card p-4 text-red-600">Could not load job card from QR. Ensure the QR is valid.</div>;

  const jc = jcData;
  const showRejectionReason = parseInt(qtyRejected || '0') > 0;

  const handleSubmit = () => {
    if (!qtyProduced) return;
    submitMutation.mutate({
      job_card_qr: qrCode,
      stage: stage || jc?.current_stage,
      qty_produced: parseInt(qtyProduced),
      qty_rejected: parseInt(qtyRejected || '0'),
      rejection_reason: rejectionReason,
    });
  };

  const isSuccess = toast && !toast.startsWith('Error');

  return (
    <div className="space-y-4">
      {toast && (
        <div className={`p-3 rounded-lg text-sm font-medium border ${isSuccess ? 'bg-green-50 text-green-800 border-green-200' : 'bg-red-50 text-red-800 border-red-200'}`}>
          {isSuccess ? '✅ ' : '❌ '}{toast}
        </div>
      )}

      {jc && (
        <div className="card p-4 bg-blue-50 border border-blue-200">
          <p className="text-xs text-blue-500 font-medium uppercase tracking-wide mb-1">Scanned Job Card</p>
          <p className="text-sm font-semibold text-blue-900">{jc.jc_number} — {jc.work_order?.item_name}</p>
          <p className="text-xs text-blue-600 mt-0.5">WO: {jc.work_order?.wo_number} | Stage: {jc.current_stage}</p>
          <div className="flex gap-4 mt-2 text-xs text-blue-600">
            <span>Planned: {jc.planned_qty}</span>
            <span>Completed: {jc.completed_qty}</span>
          </div>
        </div>
      )}

      <div className="card p-4 space-y-3">
        <h3 className="text-sm font-semibold text-neutral-700">In-Process QC Entry</h3>

        <div>
          <label className="label">Stage / Operation</label>
          <input className="input" value={stage || jc?.current_stage || ''} onChange={e => setStage(e.target.value)} placeholder="e.g. Welding, Assembly..." />
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="label">Qty Produced <span className="text-red-500">*</span></label>
            <input className="input" type="number" min="0" value={qtyProduced} onChange={e => setQtyProduced(e.target.value)} />
          </div>
          <div>
            <label className="label">Qty Rejected</label>
            <input className="input" type="number" min="0" value={qtyRejected} onChange={e => setQtyRejected(e.target.value)} />
          </div>
        </div>

        {showRejectionReason && (
          <div>
            <label className="label">Rejection Reason</label>
            <textarea className="input" rows={2} value={rejectionReason} onChange={e => setRejectionReason(e.target.value)} placeholder="Describe the rejection cause..." />
          </div>
        )}

        <div className="flex gap-2 pt-1">
          <button
            className="btn btn-primary flex-1"
            disabled={!qtyProduced || submitMutation.isPending}
            onClick={handleSubmit}
          >
            {submitMutation.isPending ? 'Submitting...' : 'Submit QC Entry'}
          </button>
          <button className="btn btn-secondary" onClick={onDone}>Cancel</button>
        </div>
      </div>
    </div>
  );
}

export function JobCardDetailPage() {
  const { id } = useParams<{ id: string }>();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [prodQty, setProdQty] = useState('');
  const [rejQty, setRejQty] = useState('');
  const [remarks, setRemarks] = useState('');
  const [showQCForm, setShowQCForm] = useState(false);

  // Support ?qr=... from QRScannerPage redirect
  const qrFromScan = searchParams.get('qr') || '';

  const { data: jc, isLoading } = useQuery({
    queryKey: ['job-card', id],
    queryFn: () => productionService.getJobCard(id!),
    enabled: !!id,
  });

  const recordMutation = useMutation({
    mutationFn: (d: any) => productionService.recordProduction(id!, d),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['job-card', id] });
      setProdQty(''); setRejQty(''); setRemarks('');
    },
  });

  const effectiveQR = qrFromScan || (jc ? String(jc.id) : '');

  if (isLoading) return <LoadingSpinner />;
  if (!jc) return <div className="p-8 text-neutral-400">Job card not found.</div>;

  if (showQCForm || qrFromScan) {
    return (
      <div className="space-y-5">
        <PageHeader
          title={`QC Entry — ${jc.jc_number}`}
          subtitle={jc.fg_name || jc.work_order?.wo_number || ''}
        />
        <QCScanForm
          qrCode={effectiveQR}
          onDone={() => {
            setShowQCForm(false);
            navigate(`/production/job-cards/${id}`);
          }}
        />
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <PageHeader
        title={`Job Card: ${jc.jc_number}`}
        subtitle={jc.fg_name || jc.work_order?.wo_number || ''}
        actions={
          <button className="btn btn-secondary" onClick={() => setShowQCForm(true)}>
            <QrCodeIcon className="h-4 w-4 mr-1" />Record QC
          </button>
        }
      />
      <div className="grid grid-cols-4 gap-4">
        {[['Status', jc.status?.replace('_', ' ')], ['Planned Qty', jc.planned_qty], ['Actual Qty', jc.actual_qty ?? '—'], ['Rejection', jc.rejection_qty ?? '0']].map(([l, v]) => (
          <div key={l} className="card p-3"><p className="text-xs text-neutral-400">{l}</p><p className="text-lg font-semibold text-neutral-900">{v}</p></div>
        ))}
      </div>
      {jc.status !== 'COMPLETED' && (
        <div className="card p-4">
          <h3 className="text-sm font-semibold text-neutral-700 mb-3">Record Production</h3>
          <div className="flex gap-3 items-end">
            <div className="flex-1"><label className="label">Good Qty</label><input className="input" type="number" value={prodQty} onChange={e => setProdQty(e.target.value)} /></div>
            <div className="flex-1"><label className="label">Rejection Qty</label><input className="input" type="number" value={rejQty} onChange={e => setRejQty(e.target.value)} /></div>
            <div className="flex-1"><label className="label">Remarks</label><input className="input" value={remarks} onChange={e => setRemarks(e.target.value)} /></div>
            <button className="btn btn-primary" disabled={recordMutation.isPending || !prodQty}
              onClick={() => recordMutation.mutate({ actual_qty: prodQty, rejection_qty: rejQty || 0, remarks })}>
              {recordMutation.isPending ? 'Saving...' : 'Record'}
            </button>
          </div>
        </div>
      )}
      <div className="card p-4">
        <h3 className="text-sm font-semibold text-neutral-700 mb-2">Details</h3>
        <div className="grid grid-cols-3 gap-3 text-sm">
          {[['Machine', jc.work_center?.name || '—'], ['Shift', jc.shift || '—'], ['Operator', jc.operator_name || '—'], ['Start Time', jc.start_time || '—'], ['End Time', jc.end_time || '—']].map(([l, v]) => (
            <div key={l}><p className="text-xs text-neutral-400">{l}</p><p className="font-medium text-neutral-800">{v}</p></div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── QC Badge per WIP card ─────────────────────────────────────────
function WIPQCBadge({ workOrderId }: { workOrderId: string }) {
  const navigate = useNavigate();
  const { data, isLoading } = useQuery({
    queryKey: ['inspection-lots-wo', workOrderId],
    queryFn: () =>
      api.get('/api/v1/quality/inspection-lots/', { params: { work_order: workOrderId } })
        .then(r => Array.isArray(r.data) ? r.data : r.data?.results || []),
    enabled: !!workOrderId,
    staleTime: 30_000,
  });

  if (isLoading || !data || data.length === 0) return null;

  const hasNCR = data.some((lot: any) =>
    (lot.ncrs && lot.ncrs.length > 0) || lot.has_ncr
  );

  return (
    <button
      className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-xs font-semibold mt-1.5 ${
        hasNCR
          ? 'bg-red-100 text-red-700 border border-red-200'
          : 'bg-green-100 text-green-700 border border-green-200'
      }`}
      onClick={e => {
        e.stopPropagation();
        navigate(`/quality/inspection-lots/?work_order=${workOrderId}`);
      }}
      title={hasNCR ? 'NCR raised — click to view' : 'All QC checks clear'}
    >
      {hasNCR
        ? <><ExclamationTriangleIcon className="h-3 w-3" />&nbsp;NCR</>
        : <><CheckCircleIcon className="h-3 w-3" />&nbsp;QC OK</>
      }
    </button>
  );
}

export function WIPTrackingPage() {
  const { data, isLoading } = useQuery({
    queryKey: ['job-cards', 'wip'],
    queryFn: () => productionService.listJobCards({ status: 'IN_PROGRESS' }),
  });
  const cards = Array.isArray(data) ? data : data?.results || [];

  const grouped: Record<string, any[]> = {};
  cards.forEach((c: any) => {
    const key = c.stage_name || c.work_center?.name || 'Unknown';
    if (!grouped[key]) grouped[key] = [];
    grouped[key].push(c);
  });

  if (isLoading) return <LoadingSpinner />;

  return (
    <div className="space-y-5">
      <PageHeader title="WIP Tracking" subtitle="Live view of in-progress job cards by stage" />
      {Object.keys(grouped).length === 0 ? (
        <div className="card p-8 text-center text-neutral-400">No WIP jobs at the moment.</div>
      ) : (
        <div className="grid grid-cols-3 gap-4">
          {Object.entries(grouped).map(([stage, jobs]) => (
            <div key={stage} className="card overflow-hidden">
              <div className="px-4 py-2 bg-primary-50 border-b border-primary-100">
                <h3 className="text-sm font-semibold text-primary-800">{stage}</h3>
                <p className="text-xs text-primary-500">{jobs.length} jobs</p>
              </div>
              <div className="divide-y divide-neutral-100">
                {jobs.map((j: any) => (
                  <div key={j.id} className="px-4 py-3">
                    <p className="text-sm font-medium text-neutral-900">{j.jc_number}</p>
                    <p className="text-xs text-neutral-500 mt-0.5">{j.fg_name || '—'}</p>
                    <div className="flex justify-between mt-1.5">
                      <span className="text-xs text-neutral-400">Planned: {j.planned_qty}</span>
                      <span className="text-xs text-neutral-600 font-medium">Done: {j.actual_qty ?? 0}</span>
                    </div>
                    {j.planned_qty > 0 && (
                      <div className="w-full bg-neutral-100 rounded-full h-1.5 mt-2">
                        <div className="bg-primary-500 rounded-full h-1.5"
                          style={{ width: `${Math.min(100, ((j.actual_qty || 0) / j.planned_qty) * 100)}%` }} />
                      </div>
                    )}
                    {(j.work_order || j.work_order_id) && (
                      <WIPQCBadge workOrderId={String(j.work_order || j.work_order_id)} />
                    )}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
