import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useQuery, useMutation } from '@tanstack/react-query';
import {
  CheckCircleIcon,
  XCircleIcon,
  ExclamationCircleIcon,
} from '@heroicons/react/24/outline';

import { qualityService, QCParameter, InspectionResult } from '@/services/quality';
import PageHeader from '@/components/ui/PageHeader';
import Card from '@/components/ui/Card';
import Button from '@/components/ui/Button';
import FormField from '@/components/ui/FormField';
import Input from '@/components/ui/Input';
import Textarea from '@/components/ui/Textarea';
import Badge from '@/components/ui/Badge';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import { cn } from '@/utils/cn';

type ParamEntry = QCParameter & { observed_input: string; param_result: 'PASS' | 'FAIL' | null };

function evaluateParam(p: QCParameter, input: string): 'PASS' | 'FAIL' | null {
  if (!input) return null;
  if (p.is_numeric) {
    const val = parseFloat(input);
    if (isNaN(val)) return null;
    if (p.min_value !== undefined && val < p.min_value) return 'FAIL';
    if (p.max_value !== undefined && val > p.max_value) return 'FAIL';
    return 'PASS';
  }
  if (p.expected_value) {
    return input.trim().toLowerCase() === p.expected_value.toLowerCase() ? 'PASS' : 'FAIL';
  }
  return null;
}

export default function InspectionFormPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const isEdit = Boolean(id);

  const [lot, setLot] = useState('');
  const [item, setItem] = useState('');
  const [inspType, setInspType] = useState('INWARD');
  const [params, setParams] = useState<ParamEntry[]>([]);
  const [remarks, setRemarks] = useState('');
  const [createCapa, setCreateCapa] = useState(false);

  const { data: inspection, isLoading } = useQuery({
    queryKey: ['inspection', id],
    queryFn: () => qualityService.getInspection(id!),
    enabled: isEdit,
    staleTime: Infinity,
  });

  useEffect(() => {
    if (inspection) {
      setItem(inspection.item);
      setLot(inspection.lot_number ?? '');
      setInspType(inspection.inspection_type);
      const entries: ParamEntry[] = inspection.parameters.map(p => ({
        ...p,
        observed_input: p.observed_value ?? (p.observed_numeric?.toString() ?? ''),
        param_result: p.result ?? null,
      }));
      setParams(entries);
    }
  }, [inspection]);

  const loadParams = useQuery({
    queryKey: ['qc-params', item],
    queryFn: () => qualityService.getItemParameters(item),
    enabled: !!item && !isEdit,
    staleTime: 30000,
  });

  useEffect(() => {
    if (loadParams.data && !isEdit) {
      setParams(loadParams.data.map(p => ({
        ...p,
        observed_input: '',
        param_result: null,
      })));
    }
  }, [loadParams.data]);

  const updateParam = (idx: number, input: string) => {
    setParams(prev => {
      const next = [...prev];
      const p = next[idx];
      next[idx] = { ...p, observed_input: input, param_result: evaluateParam(p, input) };
      return next;
    });
  };

  const overallResult: InspectionResult | null = (() => {
    if (!params.length) return null;
    const evaluated = params.filter(p => p.param_result !== null);
    if (!evaluated.length) return null;
    if (evaluated.some(p => p.param_result === 'FAIL')) return 'FAIL';
    return 'PASS';
  })();

  const submitMut = useMutation({
    mutationFn: () => {
      const payload = {
        parameters: params.map(p => ({
          id: p.id,
          observed_value: !p.is_numeric ? p.observed_input : undefined,
          observed_numeric: p.is_numeric ? parseFloat(p.observed_input) : undefined,
        })),
        overall_remarks: remarks,
        result: overallResult ?? 'CONDITIONAL',
      };
      return qualityService.submitInspection(id!, payload);
    },
    onSuccess: async (insp) => {
      if (createCapa && overallResult === 'FAIL') {
        const capa = await qualityService.createCAPA({
          source_type: 'INSPECTION',
          source_ref: insp.inspection_number,
          inspection: insp.id,
          item: insp.item,
          defect_description: remarks || 'Quality inspection failed',
        });
        navigate(`/quality/capa/${capa.id}`);
      } else {
        navigate('/quality/inspections');
      }
    },
  });

  const createMut = useMutation({
    mutationFn: () => qualityService.createInspection({
      item, lot_number: lot || undefined, inspection_type: inspType as any,
    }),
    onSuccess: insp => navigate(`/quality/inspections/${insp.id}`),
  });

  if (isLoading) return <div className="flex items-center justify-center h-64"><LoadingSpinner size="xl" /></div>;

  const passCount = params.filter(p => p.param_result === 'PASS').length;
  const failCount = params.filter(p => p.param_result === 'FAIL').length;

  return (
    <div className="space-y-4">
      <PageHeader
        title={isEdit ? `Inspection — ${inspection?.inspection_number}` : 'New Inspection'}
        subtitle={isEdit ? inspection?.item_name : 'Record quality inspection results'}
        breadcrumbs={[
          { label: 'Quality' },
          { label: 'Inspections', href: '/quality/inspections' },
          { label: isEdit ? inspection?.inspection_number ?? '' : 'New' },
        ]}
      />

      {/* Source selection (new only) */}
      {!isEdit && (
        <Card>
          <div className="p-4 grid grid-cols-1 sm:grid-cols-3 gap-4">
            <FormField label="Inspection Type" required>
              <select
                value={inspType}
                onChange={e => setInspType(e.target.value)}
                className="w-full rounded-lg border border-neutral-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary-400"
              >
                <option value="INWARD">Inward</option>
                <option value="IN_PROCESS">In-Process</option>
                <option value="FINAL">Final</option>
              </select>
            </FormField>
            <FormField label="Item ID / Code" required>
              <Input
                value={item}
                onChange={e => setItem(e.target.value)}
                placeholder="Enter item ID…"
              />
            </FormField>
            <FormField label="Lot Number">
              <Input value={lot} onChange={e => setLot(e.target.value)} placeholder="Optional" />
            </FormField>
            <div className="sm:col-span-3 flex justify-end">
              <Button
                onClick={() => createMut.mutate()}
                loading={createMut.isPending}
                disabled={!item}
              >
                Load QC Parameters
              </Button>
            </div>
          </div>
        </Card>
      )}

      {/* Parameters */}
      {params.length > 0 && (
        <>
          {/* Summary bar */}
          <div className="flex items-center gap-4 px-4 py-3 bg-white border border-neutral-200 rounded-xl text-sm">
            <span className="text-neutral-500 font-medium">{params.length} Parameters</span>
            <div className="flex items-center gap-1.5 text-success-700">
              <CheckCircleIcon className="h-4 w-4" /> {passCount} Pass
            </div>
            <div className="flex items-center gap-1.5 text-danger-600">
              <XCircleIcon className="h-4 w-4" /> {failCount} Fail
            </div>
            <div className="ml-auto flex items-center gap-2">
              {overallResult && (
                <Badge variant={overallResult === 'PASS' ? 'success' : 'danger'} size="sm">
                  Overall: {overallResult}
                </Badge>
              )}
            </div>
          </div>

          <Card>
            <div className="p-4">
              <h3 className="text-sm font-semibold text-neutral-700 mb-3">QC Parameters</h3>
              <div className="space-y-3">
                {params.map((p, idx) => (
                  <div
                    key={p.id}
                    className={cn(
                      'rounded-xl border p-3 grid grid-cols-1 sm:grid-cols-4 gap-3 items-center',
                      p.param_result === 'FAIL' ? 'border-danger-300 bg-danger-50'
                        : p.param_result === 'PASS' ? 'border-success-200 bg-success-50'
                        : 'border-neutral-200 bg-white'
                    )}
                  >
                    <div className="sm:col-span-2">
                      <p className="text-sm font-medium text-neutral-800">{p.name}</p>
                      {p.is_numeric && (p.min_value !== undefined || p.max_value !== undefined) && (
                        <p className="text-xs text-neutral-400 mt-0.5">
                          Range: {p.min_value ?? '—'} to {p.max_value ?? '—'} {p.unit ?? ''}
                        </p>
                      )}
                      {!p.is_numeric && p.expected_value && (
                        <p className="text-xs text-neutral-400 mt-0.5">Expected: {p.expected_value}</p>
                      )}
                    </div>
                    <div>
                      <Input
                        type={p.is_numeric ? 'number' : 'text'}
                        value={p.observed_input}
                        onChange={e => updateParam(idx, e.target.value)}
                        placeholder={p.is_numeric ? `Enter value (${p.unit ?? ''})` : 'Enter result…'}
                        className={cn(
                          p.param_result === 'FAIL' ? 'border-danger-400'
                            : p.param_result === 'PASS' ? 'border-success-400' : ''
                        )}
                      />
                    </div>
                    <div className="flex items-center justify-end">
                      {p.param_result === 'PASS' && (
                        <div className="flex items-center gap-1 text-success-700 text-sm font-semibold">
                          <CheckCircleIcon className="h-5 w-5" /> PASS
                        </div>
                      )}
                      {p.param_result === 'FAIL' && (
                        <div className="flex items-center gap-1 text-danger-600 text-sm font-semibold">
                          <XCircleIcon className="h-5 w-5" /> FAIL
                        </div>
                      )}
                      {!p.param_result && (
                        <span className="text-xs text-neutral-300">—</span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </Card>

          <Card>
            <div className="p-4 space-y-4">
              <FormField label="Overall Remarks">
                <Textarea
                  value={remarks}
                  onChange={e => setRemarks(e.target.value)}
                  rows={3}
                  placeholder="Inspector remarks…"
                />
              </FormField>

              {overallResult === 'FAIL' && (
                <label className="flex items-center gap-2 text-sm text-neutral-700 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={createCapa}
                    onChange={e => setCreateCapa(e.target.checked)}
                    className="rounded border-neutral-300 text-primary-600 focus:ring-primary-400"
                  />
                  <ExclamationCircleIcon className="h-4 w-4 text-danger-600" />
                  Create CAPA for this failure
                </label>
              )}

              <div className="flex justify-end gap-2">
                <Button variant="ghost" onClick={() => navigate('/quality/inspections')}>Cancel</Button>
                <Button
                  onClick={() => submitMut.mutate()}
                  loading={submitMut.isPending}
                  disabled={!overallResult}
                  variant={overallResult === 'FAIL' ? 'danger' : 'primary'}
                >
                  Submit — {overallResult ?? 'Incomplete'}
                </Button>
              </div>
            </div>
          </Card>
        </>
      )}
    </div>
  );
}
