import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  PencilIcon,
  CheckCircleIcon,
  ClockIcon,
} from '@heroicons/react/24/outline';

import { qualityService, CAPAStatus } from '@/services/quality';
import PageHeader from '@/components/ui/PageHeader';
import Card from '@/components/ui/Card';
import Button from '@/components/ui/Button';
import Badge from '@/components/ui/Badge';
import Modal from '@/components/ui/Modal';
import FormField from '@/components/ui/FormField';
import Textarea from '@/components/ui/Textarea';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import { formatDate, formatDateTime } from '@/utils/format';
import { cn } from '@/utils/cn';

const STATUS_VARIANT: Record<CAPAStatus, 'success' | 'danger' | 'warning' | 'neutral' | 'info'> = {
  OPEN: 'warning',
  IN_PROGRESS: 'info',
  CLOSED: 'success',
  OVERDUE: 'danger',
};

const STATUS_TRANSITIONS: Record<CAPAStatus, CAPAStatus[]> = {
  OPEN: ['IN_PROGRESS'],
  IN_PROGRESS: ['CLOSED'],
  OVERDUE: ['IN_PROGRESS', 'CLOSED'],
  CLOSED: [],
};

const STATUS_LABELS: Record<CAPAStatus, string> = {
  OPEN: 'Open',
  IN_PROGRESS: 'In Progress',
  CLOSED: 'Closed',
  OVERDUE: 'Overdue',
};

function StatusUpdateModal({
  capaId,
  currentStatus,
  onClose,
}: {
  capaId: string;
  currentStatus: CAPAStatus;
  onClose: () => void;
}) {
  const qc = useQueryClient();
  const transitions = STATUS_TRANSITIONS[currentStatus] ?? [];
  const [newStatus, setNewStatus] = useState<CAPAStatus>(transitions[0] ?? 'CLOSED');
  const [remarks, setRemarks] = useState('');

  const mut = useMutation({
    mutationFn: () => qualityService.addStatusUpdate(capaId, { status: newStatus, remarks }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['capa', capaId] }); onClose(); },
  });

  return (
    <Modal open onClose={onClose} title="Update CAPA Status" size="sm">
      <div className="space-y-4 p-4">
        <FormField label="New Status" required>
          <select
            value={newStatus}
            onChange={e => setNewStatus(e.target.value as CAPAStatus)}
            className="w-full rounded-lg border border-neutral-200 px-3 py-2 text-sm"
          >
            {transitions.map(s => <option key={s} value={s}>{STATUS_LABELS[s]}</option>)}
          </select>
        </FormField>
        <FormField label="Remarks" required>
          <Textarea value={remarks} onChange={e => setRemarks(e.target.value)} rows={3} placeholder="Describe action taken…" />
        </FormField>
        <div className="flex gap-2 justify-end pt-1">
          <Button variant="ghost" onClick={onClose}>Cancel</Button>
          <Button onClick={() => mut.mutate()} loading={mut.isPending} disabled={!remarks.trim()}>
            Update Status
          </Button>
        </div>
      </div>
    </Modal>
  );
}

function EditModal({ capaId, onClose }: { capaId: string; onClose: () => void }) {
  const qc = useQueryClient();
  const { data: capa } = useQuery({ queryKey: ['capa', capaId], queryFn: () => qualityService.getCAPADetail(capaId) });
  const [form, setForm] = useState({
    root_cause: capa?.root_cause ?? '',
    corrective_actions: capa?.corrective_actions ?? '',
    preventive_actions: capa?.preventive_actions ?? '',
    due_date: capa?.due_date ?? '',
  });

  const mut = useMutation({
    mutationFn: () => qualityService.updateCAPA(capaId, form),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['capa', capaId] }); onClose(); },
  });

  return (
    <Modal open onClose={onClose} title="Edit CAPA" size="md">
      <div className="space-y-4 p-4">
        <FormField label="Root Cause">
          <Textarea value={form.root_cause} onChange={e => setForm(f => ({ ...f, root_cause: e.target.value }))} rows={3} />
        </FormField>
        <FormField label="Corrective Actions">
          <Textarea value={form.corrective_actions} onChange={e => setForm(f => ({ ...f, corrective_actions: e.target.value }))} rows={3} />
        </FormField>
        <FormField label="Preventive Actions">
          <Textarea value={form.preventive_actions} onChange={e => setForm(f => ({ ...f, preventive_actions: e.target.value }))} rows={3} />
        </FormField>
        <FormField label="Due Date">
          <input
            type="date"
            value={form.due_date}
            onChange={e => setForm(f => ({ ...f, due_date: e.target.value }))}
            className="w-full rounded-lg border border-neutral-200 px-3 py-2 text-sm"
          />
        </FormField>
        <div className="flex gap-2 justify-end pt-1">
          <Button variant="ghost" onClick={onClose}>Cancel</Button>
          <Button onClick={() => mut.mutate()} loading={mut.isPending}>Save Changes</Button>
        </div>
      </div>
    </Modal>
  );
}

export default function CAPADetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [modal, setModal] = useState<'status' | 'edit' | null>(null);

  const { data: capa, isLoading } = useQuery({
    queryKey: ['capa', id],
    queryFn: () => qualityService.getCAPADetail(id!),
    enabled: !!id,
  });

  if (isLoading) return <div className="flex items-center justify-center h-64"><LoadingSpinner size="xl" /></div>;
  if (!capa) return null;

  const canTransition = STATUS_TRANSITIONS[capa.status]?.length > 0;
  const isOverdue = new Date(capa.due_date) < new Date() && capa.status !== 'CLOSED';

  return (
    <div className="space-y-4">
      <PageHeader
        title={`CAPA — ${capa.capa_number}`}
        subtitle={capa.item_name}
        breadcrumbs={[
          { label: 'Quality' },
          { label: 'CAPA', href: '/quality/capa' },
          { label: capa.capa_number },
        ]}
        actions={
          <div className="flex gap-2">
            <Button variant="ghost" size="sm" onClick={() => setModal('edit')}>
              <PencilIcon className="h-4 w-4 mr-1" /> Edit
            </Button>
            {canTransition && (
              <Button size="sm" onClick={() => setModal('status')}>
                Update Status
              </Button>
            )}
          </div>
        }
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Info card */}
        <Card className="lg:col-span-1">
          <div className="p-4 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-neutral-700">CAPA Details</h3>
              <Badge variant={(STATUS_VARIANT[capa.status] as any) ?? 'neutral'}>{STATUS_LABELS[capa.status]}</Badge>
            </div>
            <div className="border-t border-neutral-100 pt-3 space-y-2">
              {[
                { label: 'CAPA Number', value: <span className="font-mono font-semibold">{capa.capa_number}</span> },
                { label: 'Source', value: `${capa.source_type} — ${capa.source_ref}` },
                { label: 'Item', value: capa.item_name },
                { label: 'Assigned To', value: capa.assigned_to_name },
                { label: 'Due Date', value: (
                  <span className={isOverdue ? 'text-danger-600 font-semibold' : ''}>
                    {formatDate(capa.due_date)}
                    {isOverdue && ' (Overdue)'}
                  </span>
                )},
                { label: 'Created', value: formatDate(capa.created_at) },
                { label: 'Created By', value: capa.created_by_name },
              ].map(({ label, value }) => (
                <div key={label} className="flex justify-between items-start gap-2 text-sm">
                  <span className="text-neutral-500 shrink-0">{label}</span>
                  <span className="text-neutral-800 text-right">{value}</span>
                </div>
              ))}
            </div>
            {capa.inspection && (
              <button
                onClick={() => navigate(`/quality/inspections/${capa.inspection}`)}
                className="w-full text-xs text-primary-600 hover:text-primary-800 text-left mt-2 underline"
              >
                → View Source Inspection
              </button>
            )}
          </div>
        </Card>

        {/* Content */}
        <div className="lg:col-span-2 space-y-4">
          <Card>
            <div className="p-4 space-y-4">
              <Section title="Defect Description" content={capa.defect_description} />
              <Section title="Root Cause Analysis" content={capa.root_cause} placeholder="Not entered yet." />
              <Section title="Corrective Actions" content={capa.corrective_actions} placeholder="Not entered yet." />
              <Section title="Preventive Actions" content={capa.preventive_actions} placeholder="Not entered yet." />
            </div>
          </Card>

          {/* Timeline */}
          <Card>
            <div className="p-4">
              <h3 className="text-sm font-semibold text-neutral-700 mb-3">Status Timeline</h3>
              {!capa.status_updates?.length
                ? <p className="text-sm text-neutral-400">No updates yet.</p>
                : (
                  <div className="space-y-3">
                    {capa.status_updates.map((upd, i) => (
                      <div key={upd.id} className="flex gap-3">
                        <div className="flex flex-col items-center">
                          <div className={cn(
                            'h-7 w-7 rounded-full flex items-center justify-center text-white text-xs font-bold shrink-0',
                            upd.status === 'CLOSED' ? 'bg-success-500' : 'bg-primary-600'
                          )}>
                            {upd.status === 'CLOSED' ? <CheckCircleIcon className="h-4 w-4" /> : <ClockIcon className="h-4 w-4" />}
                          </div>
                          {i < capa.status_updates.length - 1 && (
                            <div className="w-px flex-1 bg-neutral-200 mt-1" />
                          )}
                        </div>
                        <div className="pb-4">
                          <div className="flex items-center gap-2 mb-0.5">
                            <Badge variant={(STATUS_VARIANT[upd.status] as any) ?? 'neutral'} size="sm">
                              {STATUS_LABELS[upd.status]}
                            </Badge>
                            <span className="text-xs text-neutral-400">{upd.updated_by_name}</span>
                            <span className="text-xs text-neutral-300">·</span>
                            <span className="text-xs text-neutral-400">{formatDateTime(upd.updated_at)}</span>
                          </div>
                          <p className="text-sm text-neutral-600">{upd.remarks}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
            </div>
          </Card>
        </div>
      </div>

      {modal === 'status' && <StatusUpdateModal capaId={id!} currentStatus={capa.status} onClose={() => setModal(null)} />}
      {modal === 'edit' && <EditModal capaId={id!} onClose={() => setModal(null)} />}
    </div>
  );
}

function Section({ title, content, placeholder = '' }: { title: string; content?: string; placeholder?: string }) {
  return (
    <div>
      <p className="text-xs font-semibold text-neutral-500 uppercase tracking-wide mb-1">{title}</p>
      {content
        ? <p className="text-sm text-neutral-700 whitespace-pre-wrap">{content}</p>
        : <p className="text-sm text-neutral-300 italic">{placeholder}</p>}
    </div>
  );
}
