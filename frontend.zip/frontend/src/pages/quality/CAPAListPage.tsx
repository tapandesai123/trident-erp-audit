import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { createColumnHelper } from '@tanstack/react-table';
import { FunnelIcon } from '@heroicons/react/24/outline';

import { qualityService, CAPAListItem, CAPAStatus } from '@/services/quality';
import DataTable from '@/components/ui/DataTable';
import Badge from '@/components/ui/Badge';
import PageHeader from '@/components/ui/PageHeader';
import Tabs from '@/components/ui/Tabs';
import FilterPanel, { FilterSection, FilterRadioGroup } from '@/components/ui/FilterPanel';
import { usePagination } from '@/hooks/usePagination';
import { useDebounce } from '@/hooks/useDebounce';
import { formatDate } from '@/utils/format';
import { cn } from '@/utils/cn';

const col = createColumnHelper<CAPAListItem>();

const STATUS_VARIANT: Record<CAPAStatus, 'success' | 'danger' | 'warning' | 'neutral'> = {
  OPEN: 'warning',
  IN_PROGRESS: 'info' as any,
  CLOSED: 'success',
  OVERDUE: 'danger',
};

const COLUMNS = [
  col.accessor('capa_number', {
    header: 'CAPA #',
    cell: i => <span className="font-mono text-xs font-semibold text-primary-800">{i.getValue()}</span>,
    size: 140,
  }),
  col.accessor('source_ref', {
    header: 'Source',
    cell: i => (
      <div className="text-xs">
        <p className="font-medium text-neutral-700">{i.row.original.source_type}</p>
        <p className="font-mono text-neutral-400">{i.getValue()}</p>
      </div>
    ),
    size: 140,
  }),
  col.accessor('item_name', {
    header: 'Item / Defect',
    cell: i => (
      <div>
        <p className="text-sm font-medium text-neutral-800">{i.getValue()}</p>
        <p className="text-xs text-neutral-400 line-clamp-1">{i.row.original.defect_description}</p>
      </div>
    ),
  }),
  col.accessor('assigned_to_name', {
    header: 'Assigned To',
    size: 130,
  }),
  col.accessor('due_date', {
    header: 'Due Date',
    cell: i => {
      const due = new Date(i.getValue());
      const isOverdue = due < new Date() && i.row.original.status !== 'CLOSED';
      return (
        <span className={isOverdue ? 'text-danger-600 font-semibold text-sm' : 'text-sm'}>
          {formatDate(i.getValue())}
        </span>
      );
    },
    size: 100,
  }),
  col.accessor('status', {
    header: 'Status',
    cell: i => <Badge variant={STATUS_VARIANT[i.getValue()] ?? 'neutral'}>{i.getValue()}</Badge>,
    size: 110,
  }),
];

type StatusFilter = 'ALL' | CAPAStatus;

const TABS = [
  { key: 'ALL', label: 'All' },
  { key: 'OPEN', label: 'Open' },
  { key: 'IN_PROGRESS', label: 'In Progress' },
  { key: 'OVERDUE', label: 'Overdue' },
  { key: 'CLOSED', label: 'Closed' },
];

export default function CAPAListPage() {
  const navigate = useNavigate();
  const { page, pageSize, setPage, setPageSize } = usePagination();
  const [search, setSearch] = useState('');
  const debouncedSearch = useDebounce(search, 300);
  const [activeTab, setActiveTab] = useState<StatusFilter>('ALL');
  const [filterOpen, setFilterOpen] = useState(false);
  const [sourceType, setSourceType] = useState('');

  const { data, isLoading } = useQuery({
    queryKey: ['capas', page, pageSize, debouncedSearch, activeTab, sourceType],
    queryFn: () => qualityService.listCAPAs({
      page, page_size: pageSize,
      search: debouncedSearch || undefined,
      status: activeTab === 'ALL' ? undefined : activeTab,
      source_type: sourceType || undefined,
    }),
  });

  const activeFilters = [sourceType].filter(Boolean).length;

  return (
    <div className="space-y-4">
      <PageHeader
        title="CAPA"
        subtitle="Corrective and Preventive Actions"
      />

      <Tabs
        tabs={TABS.map(t => ({ ...t, label: t.label }))}
        activeKey={activeTab}
        onChange={k => { setActiveTab(k as StatusFilter); setPage(1); }}
      />

      <div className="flex gap-4">
        <div className="flex-1 min-w-0">
          <DataTable
            data={data?.results ?? []}
            columns={COLUMNS}
            loading={isLoading}
            totalCount={data?.count}
            page={page}
            pageSize={pageSize}
            onPageChange={setPage}
            onPageSizeChange={setPageSize}
            searchValue={search}
            onSearchChange={setSearch}
            searchPlaceholder="Search CAPA, item, defect…"
            onRowClick={row => navigate(`/quality/capa/${row.id}`)}
            toolbarLeft={
              <button
                onClick={() => setFilterOpen(o => !o)}
                className={cn(
                  'inline-flex items-center gap-1.5 px-3 py-1.5 text-sm rounded-lg border transition-colors',
                  filterOpen || activeFilters > 0
                    ? 'bg-primary-50 border-primary-300 text-primary-700'
                    : 'bg-white border-neutral-200 text-neutral-600 hover:bg-neutral-50'
                )}
              >
                <FunnelIcon className="h-4 w-4" />
                Filters
                {activeFilters > 0 && (
                  <span className="h-4 w-4 bg-primary-700 text-white text-[10px] font-bold rounded-full flex items-center justify-center">
                    {activeFilters}
                  </span>
                )}
              </button>
            }
            emptyTitle="No CAPAs found"
            emptyDescription="CAPAs are created from failed inspections."
          />
        </div>

        <FilterPanel
          open={filterOpen}
          onClose={() => setFilterOpen(false)}
          onReset={() => setSourceType('')}
          activeCount={activeFilters}
        >
          <FilterSection label="Source Type">
            <FilterRadioGroup
              name="sourceType"
              value={sourceType}
              onChange={setSourceType}
              options={[
                { value: '', label: 'All' },
                { value: 'INSPECTION', label: 'Inspection' },
                { value: 'CUSTOMER_COMPLAINT', label: 'Customer Complaint' },
                { value: 'AUDIT', label: 'Audit' },
                { value: 'OTHER', label: 'Other' },
              ]}
            />
          </FilterSection>
        </FilterPanel>
      </div>
    </div>
  );
}
