import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { createColumnHelper } from '@tanstack/react-table';
import { PlusIcon, FunnelIcon } from '@heroicons/react/24/outline';

import { qualityService, InspectionListItem } from '@/services/quality';
import DataTable from '@/components/ui/DataTable';
import Badge from '@/components/ui/Badge';
import Button from '@/components/ui/Button';
import PageHeader from '@/components/ui/PageHeader';
import FilterPanel, { FilterSection, FilterRadioGroup } from '@/components/ui/FilterPanel';
import { usePagination } from '@/hooks/usePagination';
import { useDebounce } from '@/hooks/useDebounce';
import { formatDate } from '@/utils/format';
import { cn } from '@/utils/cn';

const col = createColumnHelper<InspectionListItem>();

const RESULT_VARIANT: Record<string, 'success' | 'danger' | 'warning' | 'neutral'> = {
  PASS: 'success', FAIL: 'danger', CONDITIONAL: 'warning',
};
const TYPE_LABELS: Record<string, string> = {
  INWARD: 'Inward', IN_PROCESS: 'In-Process', FINAL: 'Final',
};
const TYPE_OPTIONS = [
  { value: 'INWARD', label: 'Inward' },
  { value: 'IN_PROCESS', label: 'In-Process' },
  { value: 'FINAL', label: 'Final' },
];
const RESULT_OPTIONS = [
  { value: 'PASS', label: 'Pass' },
  { value: 'FAIL', label: 'Fail' },
  { value: 'CONDITIONAL', label: 'Conditional' },
];

const COLUMNS = [
  col.accessor('inspection_number', {
    header: 'Inspection #',
    cell: i => <span className="font-mono text-xs font-semibold text-primary-800">{i.getValue()}</span>,
    size: 150,
  }),
  col.accessor('inspection_type', {
    header: 'Type',
    cell: i => (
      <span className={cn(
        'inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold border',
        i.getValue() === 'INWARD' ? 'bg-blue-50 text-blue-700 border-blue-200'
          : i.getValue() === 'IN_PROCESS' ? 'bg-violet-50 text-violet-700 border-violet-200'
          : 'bg-teal-50 text-teal-700 border-teal-200'
      )}>
        {TYPE_LABELS[i.getValue()] ?? i.getValue()}
      </span>
    ),
    size: 110,
  }),
  col.accessor('item_name', {
    header: 'Item',
    cell: i => (
      <div>
        <p className="text-sm font-medium text-neutral-800">{i.getValue()}</p>
        <p className="text-xs text-neutral-400">{i.row.original.item_code}</p>
      </div>
    ),
  }),
  col.accessor('lot_number', {
    header: 'Lot / MRR',
    cell: i => (
      <div className="text-xs">
        {i.getValue() && <p className="font-mono text-neutral-700">{i.getValue()}</p>}
        {i.row.original.mrr_number && <p className="text-neutral-400">{i.row.original.mrr_number}</p>}
        {!i.getValue() && !i.row.original.mrr_number && '—'}
      </div>
    ),
    size: 130,
  }),
  col.accessor('inspection_date', {
    header: 'Date',
    cell: i => formatDate(i.getValue()),
    size: 100,
  }),
  col.accessor('result', {
    header: 'Result',
    cell: i => {
      const v = i.getValue();
      if (!v) return <Badge variant="neutral" size="sm">Pending</Badge>;
      return <Badge variant={RESULT_VARIANT[v] ?? 'neutral'} size="sm">{v}</Badge>;
    },
    size: 100,
  }),
  col.accessor('inspector_name', {
    header: 'Inspector',
    cell: i => <span className="text-sm text-neutral-600">{i.getValue()}</span>,
    size: 130,
  }),
];

export default function InspectionListPage() {
  const navigate = useNavigate();
  const { page, pageSize, setPage, setPageSize } = usePagination();
  const [search, setSearch] = useState('');
  const debouncedSearch = useDebounce(search, 300);
  const [filterOpen, setFilterOpen] = useState(false);
  const [type, setType] = useState('');
  const [result, setResult] = useState('');

  const activeFilters = [type, result].filter(Boolean).length;

  const { data, isLoading } = useQuery({
    queryKey: ['inspections', page, pageSize, debouncedSearch, type, result],
    queryFn: () => qualityService.listInspections({
      page, page_size: pageSize,
      search: debouncedSearch || undefined,
      inspection_type: type || undefined,
      result: result || undefined,
    }),
  });

  return (
    <div className="space-y-4">
      <PageHeader
        title="Quality Inspections"
        subtitle="Inward and in-process inspection records"
        actions={
          <Button onClick={() => navigate('/quality/inspections/new')}>
            <PlusIcon className="h-4 w-4 mr-1" /> New Inspection
          </Button>
        }
      />

      <div className="flex gap-4">
        <div className="flex-1 min-w-0">
          <DataTable
            data={data?.results ?? []}
            columns={COLUMNS}
            loading={isLoading}
            totalCount={data?.count}
            page={page}
            pageSize={pageSize}
            onPageChange={setPage}
            onPageSizeChange={setPageSize}
            searchValue={search}
            onSearchChange={setSearch}
            searchPlaceholder="Search inspection, item, lot…"
            onRowClick={row => navigate(`/quality/inspections/${row.id}`)}
            toolbarLeft={
              <button
                onClick={() => setFilterOpen(o => !o)}
                className={cn(
                  'inline-flex items-center gap-1.5 px-3 py-1.5 text-sm rounded-lg border transition-colors',
                  filterOpen || activeFilters > 0
                    ? 'bg-primary-50 border-primary-300 text-primary-700'
                    : 'bg-white border-neutral-200 text-neutral-600 hover:bg-neutral-50'
                )}
              >
                <FunnelIcon className="h-4 w-4" />
                Filters
                {activeFilters > 0 && (
                  <span className="h-4 w-4 bg-primary-700 text-white text-[10px] font-bold rounded-full flex items-center justify-center">
                    {activeFilters}
                  </span>
                )}
              </button>
            }
            emptyTitle="No inspections found"
            emptyDescription="Create an inspection from an MRR or work order."
          />
        </div>

        <FilterPanel
          open={filterOpen}
          onClose={() => setFilterOpen(false)}
          onReset={() => { setType(''); setResult(''); }}
          activeCount={activeFilters}
        >
          <FilterSection label="Inspection Type">
            <FilterRadioGroup
              name="type"
              value={type}
              onChange={setType}
              options={[{ value: '', label: 'All' }, ...TYPE_OPTIONS]}
            />
          </FilterSection>
          <FilterSection label="Result">
            <FilterRadioGroup
              name="result"
              value={result}
              onChange={setResult}
              options={[{ value: '', label: 'All' }, ...RESULT_OPTIONS]}
            />
          </FilterSection>
        </FilterPanel>
      </div>
    </div>
  );
}
