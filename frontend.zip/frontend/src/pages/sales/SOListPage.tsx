import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { createColumnHelper } from '@tanstack/react-table';
import { FunnelIcon } from '@heroicons/react/24/outline';
import { CheckCircleIcon as CheckCircleSolid } from '@heroicons/react/24/solid';

import { salesService, SOListItem, SOStatus } from '@/services/sales';
import DataTable from '@/components/ui/DataTable';
import Badge from '@/components/ui/Badge';
import PageHeader from '@/components/ui/PageHeader';
import Tabs from '@/components/ui/Tabs';
import FilterPanel, { FilterSection, FilterRadioGroup } from '@/components/ui/FilterPanel';
import { usePagination } from '@/hooks/usePagination';
import { useDebounce } from '@/hooks/useDebounce';
import { formatDate, formatCurrency } from '@/utils/format';
import { cn } from '@/utils/cn';

const col = createColumnHelper<SOListItem & { material_ready?: boolean }>();

const STATUS_VARIANT: Record<SOStatus, string> = {
  DRAFT: 'neutral', CONFIRMED: 'info', IN_PRODUCTION: 'warning', READY: 'primary',
  PARTIALLY_DISPATCHED: 'warning', DISPATCHED: 'success', CLOSED: 'success', CANCELLED: 'danger',
};

const COLUMNS = [
  col.accessor('so_number', {
    header: 'SO Number',
    cell: i => <span className="font-mono text-xs font-semibold text-primary-800">{i.getValue()}</span>,
    size: 140,
  }),
  col.accessor('customer_name', { header: 'Customer', size: 180 }),
  col.accessor('quotation_number', {
    header: 'Quotation',
    cell: i => i.getValue() ? <span className="font-mono text-xs text-neutral-500">{i.getValue()}</span> : <span className="text-neutral-300">—</span>,
    size: 130,
  }),
  col.accessor('order_date', { header: 'Order Date', cell: i => formatDate(i.getValue()), size: 110 }),
  col.accessor('delivery_date', {
    header: 'Delivery Date',
    cell: i => {
      const val = i.getValue();
      if (!val) return <span className="text-neutral-300">—</span>;
      const overdue = new Date(val) < new Date() && !['DISPATCHED', 'CLOSED', 'CANCELLED'].includes(i.row.original.status);
      return <span className={cn('text-sm', overdue ? 'text-danger-600 font-semibold' : '')}>{formatDate(val)}</span>;
    },
    size: 120,
  }),
  col.accessor('total_amount', {
    header: 'Amount',
    cell: i => <span className="font-semibold">{formatCurrency(i.getValue())}</span>,
    size: 130,
  }),
  // P1 – Material ready indicator
  col.accessor('material_ready', {
    header: 'Material',
    cell: i => {
      const status = i.row.original.status;
      if (!['CONFIRMED', 'IN_PRODUCTION', 'READY'].includes(status)) return <span className="text-neutral-300">—</span>;
      return i.getValue()
        ? <span className="flex items-center gap-1 text-xs text-success-700 font-medium"><CheckCircleSolid className="h-3.5 w-3.5" /> Ready</span>
        : <span className="text-xs text-warning-600">Pending</span>;
    },
    size: 90,
  }),
  col.accessor('status', {
    header: 'Status',
    cell: i => <Badge variant={STATUS_VARIANT[i.getValue()] as any}>{i.getValue().replace('_', ' ')}</Badge>,
    size: 140,
  }),
];

const TABS = [
  { key: 'ALL', label: 'All' },
  { key: 'CONFIRMED', label: 'Confirmed' },
  { key: 'IN_PRODUCTION', label: 'In Production' },
  { key: 'READY', label: 'Ready' },
  { key: 'PARTIALLY_DISPATCHED', label: 'Part. Dispatched' },
  { key: 'DISPATCHED', label: 'Dispatched' },
];

export default function SOListPage() {
  const navigate = useNavigate();
  const { page, pageSize, setPage, setPageSize } = usePagination();
  const [search, setSearch] = useState('');
  const dSearch = useDebounce(search, 300);
  const [tab, setTab] = useState('ALL');
  const [filterOpen, setFilterOpen] = useState(false);

  const { data, isLoading } = useQuery({
    queryKey: ['sales-orders', page, pageSize, dSearch, tab],
    queryFn: () => salesService.listSOs({
      page, page_size: pageSize,
      search: dSearch || undefined,
      status: tab === 'ALL' ? undefined : tab,
    }),
  });

  return (
    <div className="space-y-4">
      <PageHeader title="Sales Orders" subtitle="Manage confirmed orders and dispatch tracking" />
      <Tabs tabs={TABS} active={tab} onChange={k => { setTab(k); setPage(1); }} />
      <DataTable
        data={data?.results ?? []}
        columns={COLUMNS}
        loading={isLoading}
        totalCount={data?.count}
        page={page} pageSize={pageSize}
        onPageChange={setPage} onPageSizeChange={setPageSize}
        searchValue={search} onSearchChange={setSearch}
        searchPlaceholder="Search SO, customer…"
        onRowClick={row => navigate(`/sales/orders/${row.id}`)}
        toolbarLeft={
          <button onClick={() => setFilterOpen(o => !o)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-sm rounded-lg border bg-white border-neutral-200 text-neutral-600 hover:bg-neutral-50 transition-colors">
            <FunnelIcon className="h-4 w-4" /> Filters
          </button>
        }
        emptyTitle="No sales orders found"
      />
    </div>
  );
}
