import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { PlusIcon, LinkIcon, PencilIcon } from '@heroicons/react/24/outline';

import { salesService, ComplaintStatus, ComplaintSeverity } from '@/services/sales';
import PageHeader from '@/components/ui/PageHeader';
import Card from '@/components/ui/Card';
import Button from '@/components/ui/Button';
import Badge from '@/components/ui/Badge';
import Modal from '@/components/ui/Modal';
import FormField from '@/components/ui/FormField';
import Input from '@/components/ui/Input';
import Textarea from '@/components/ui/Textarea';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import { formatDate, formatDateTime } from '@/utils/format';
import { cn } from '@/utils/cn';

const STATUS_VARIANT: Record<ComplaintStatus, string> = {
  OPEN: 'warning', INVESTIGATING: 'info', RESOLVED: 'success', CLOSED: 'neutral',
};

const SEVERITY_CLASSES: Record<ComplaintSeverity, string> = {
  LOW: 'bg-neutral-100 text-neutral-600',
  MEDIUM: 'bg-warning-100 text-warning-700',
  HIGH: 'bg-danger-100 text-danger-700',
  CRITICAL: 'bg-danger-200 text-danger-900 font-bold',
};

const STATUS_FLOW: ComplaintStatus[] = ['OPEN', 'INVESTIGATING', 'RESOLVED', 'CLOSED'];

function ActivityModal({ complaintId, onClose }: { complaintId: string; onClose: () => void }) {
  const qc = useQueryClient();
  const [form, setForm] = useState({ action: '', remarks: '' });
  const ACTIONS = ['Initial Contact', 'Investigation Started', 'Site Visit', 'Corrective Action Taken', 'Follow-up', 'Resolution Confirmed', 'Closed'];
  const mut = useMutation({
    mutationFn: () => salesService.addActivity(complaintId, form),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['complaint', complaintId] }); onClose(); },
  });
  return (
    <Modal open onClose={onClose} title="Add Activity" size="sm">
      <div className="space-y-4 p-4">
        <FormField label="Action" required>
          <select value={form.action} onChange={e => setForm(f => ({ ...f, action: e.target.value }))}
            className="w-full rounded-lg border border-neutral-200 px-3 py-2 text-sm">
            <option value="">Select action…</option>
            {ACTIONS.map(a => <option key={a}>{a}</option>)}
          </select>
        </FormField>
        <FormField label="Remarks" required>
          <Textarea value={form.remarks} onChange={e => setForm(f => ({ ...f, remarks: e.target.value }))} rows={3} />
        </FormField>
        <div className="flex gap-2 justify-end">
          <Button variant="ghost" onClick={onClose}>Cancel</Button>
          <Button onClick={() => mut.mutate()} loading={mut.isPending} disabled={!form.action || !form.remarks.trim()}>Save</Button>
        </div>
      </div>
    </Modal>
  );
}

function EditModal({ complaintId, onClose }: { complaintId: string; onClose: () => void }) {
  const qc = useQueryClient();
  const { data: c } = useQuery({ queryKey: ['complaint', complaintId], queryFn: () => salesService.getComplaint(complaintId) });
  const [form, setForm] = useState({ root_cause: '', resolution: '', status: 'OPEN' as ComplaintStatus, assigned_to_name: '' });
  useEffect(() => {
    if (c) setForm({ root_cause: c.root_cause ?? '', resolution: c.resolution ?? '', status: c.status, assigned_to_name: c.assigned_to_name ?? '' });
  }, [c]);
  const mut = useMutation({
    mutationFn: () => salesService.updateComplaint(complaintId, form as any),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['complaint', complaintId] }); onClose(); },
  });
  return (
    <Modal open onClose={onClose} title="Update Complaint" size="md">
      <div className="space-y-4 p-4">
        <FormField label="Status">
          <select value={form.status} onChange={e => setForm(f => ({ ...f, status: e.target.value as ComplaintStatus }))}
            className="w-full rounded-lg border border-neutral-200 px-3 py-2 text-sm">
            {STATUS_FLOW.map(s => <option key={s} value={s}>{s}</option>)}
          </select>
        </FormField>
        <FormField label="Root Cause">
          <Textarea value={form.root_cause} onChange={e => setForm(f => ({ ...f, root_cause: e.target.value }))} rows={3} />
        </FormField>
        <FormField label="Resolution">
          <Textarea value={form.resolution} onChange={e => setForm(f => ({ ...f, resolution: e.target.value }))} rows={3} />
        </FormField>
        <div className="flex gap-2 justify-end">
          <Button variant="ghost" onClick={onClose}>Cancel</Button>
          <Button onClick={() => mut.mutate()} loading={mut.isPending}>Save</Button>
        </div>
      </div>
    </Modal>
  );
}

export default function ComplaintDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [modal, setModal] = useState<'activity' | 'edit' | null>(null);

  const { data: c, isLoading } = useQuery({
    queryKey: ['complaint', id],
    queryFn: () => salesService.getComplaint(id!),
    enabled: !!id,
  });

  const capaMut = useMutation({
    mutationFn: () => salesService.linkCAPA(id!),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['complaint', id] }),
  });

  if (isLoading) return <div className="flex items-center justify-center h-64"><LoadingSpinner size="xl" /></div>;
  if (!c) return null;

  const statusIdx = STATUS_FLOW.indexOf(c.status);

  return (
    <div className="space-y-4">
      <PageHeader
        title={`Complaint — ${c.complaint_number}`}
        subtitle={c.customer_name}
        breadcrumbs={[{ label: 'Sales' }, { label: 'Complaints', href: '/sales/complaints' }, { label: c.complaint_number }]}
        actions={
          <div className="flex gap-2">
            <Button variant="ghost" size="sm" onClick={() => setModal('activity')}>
              <PlusIcon className="h-4 w-4 mr-1" /> Add Activity
            </Button>
            <Button variant="ghost" size="sm" onClick={() => setModal('edit')}>
              <PencilIcon className="h-4 w-4 mr-1" /> Update
            </Button>
            {!c.capa_id && (
              <Button variant="secondary" size="sm" onClick={() => capaMut.mutate()} loading={capaMut.isPending}>
                <LinkIcon className="h-4 w-4 mr-1" /> Create CAPA
              </Button>
            )}
            {c.capa_id && (
              <Button variant="secondary" size="sm" onClick={() => navigate(`/quality/capa/${c.capa_id}`)}>
                View CAPA {c.capa_number}
              </Button>
            )}
          </div>
        }
      />

      {/* Status stepper */}
      <Card>
        <div className="p-4">
          <div className="flex items-center gap-0">
            {STATUS_FLOW.map((s, i) => (
              <div key={s} className="flex items-center flex-1 last:flex-none">
                <div className={cn(
                  'flex flex-col items-center gap-1',
                )}>
                  <div className={cn(
                    'h-7 w-7 rounded-full flex items-center justify-center text-xs font-bold border-2 transition-colors',
                    i <= statusIdx
                      ? 'bg-primary-700 border-primary-700 text-white'
                      : 'bg-white border-neutral-300 text-neutral-400'
                  )}>
                    {i < statusIdx ? '✓' : i + 1}
                  </div>
                  <span className={cn('text-[10px] font-medium whitespace-nowrap', i <= statusIdx ? 'text-primary-700' : 'text-neutral-400')}>
                    {s}
                  </span>
                </div>
                {i < STATUS_FLOW.length - 1 && (
                  <div className={cn('flex-1 h-0.5 mx-1 mt-[-14px]', i < statusIdx ? 'bg-primary-700' : 'bg-neutral-200')} />
                )}
              </div>
            ))}
          </div>
        </div>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Info */}
        <Card>
          <div className="p-4 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-neutral-700">Details</h3>
              <span className={cn('inline-flex items-center px-2 py-0.5 rounded-full text-xs', SEVERITY_CLASSES[c.severity])}>
                {c.severity}
              </span>
            </div>
            <div className="space-y-2 text-sm border-t border-neutral-100 pt-3">
              {[
                { label: 'Customer', value: c.customer_name },
                { label: 'Received', value: formatDate(c.received_date) },
                { label: 'Resolved', value: c.resolved_date ? formatDate(c.resolved_date) : '—' },
                { label: 'Assigned To', value: c.assigned_to_name ?? '—' },
                { label: 'Invoice', value: c.invoice_number ?? '—' },
                { label: 'SO', value: c.so_number ?? '—' },
                { label: 'CAPA', value: c.capa_number ?? '—' },
              ].map(({ label, value }) => (
                <div key={label} className="flex justify-between items-start gap-2">
                  <span className="text-neutral-500 shrink-0">{label}</span>
                  <span className="text-neutral-800 text-right text-sm">{value}</span>
                </div>
              ))}
            </div>
          </div>
        </Card>

        <div className="lg:col-span-2 space-y-4">
          {/* Content */}
          <Card>
            <div className="p-4 space-y-4">
              <Section title="Subject" content={c.subject} />
              <Section title="Description" content={c.description} />
              <Section title="Root Cause" content={c.root_cause} placeholder="Not investigated yet." />
              <Section title="Resolution" content={c.resolution} placeholder="No resolution recorded yet." />
            </div>
          </Card>

          {/* Activity Log */}
          <Card>
            <div className="p-4">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-semibold text-neutral-700">Activity Log</h3>
                <button onClick={() => setModal('activity')} className="text-xs text-primary-600 hover:text-primary-800 font-medium">+ Add</button>
              </div>
              {!c.activities?.length
                ? <p className="text-sm text-neutral-400 text-center py-4">No activities recorded.</p>
                : (
                  <div className="space-y-3">
                    {[...c.activities].reverse().map((a, i, arr) => (
                      <div key={a.id} className="flex gap-3">
                        <div className="flex flex-col items-center">
                          <div className={cn('h-2 w-2 rounded-full mt-1.5 shrink-0', i === 0 ? 'bg-primary-600' : 'bg-neutral-300')} />
                          {i < arr.length - 1 && <div className="w-px flex-1 bg-neutral-200 mt-1" />}
                        </div>
                        <div className="pb-3">
                          <div className="flex items-center gap-2 mb-0.5">
                            <span className="text-xs font-semibold text-neutral-700">{a.action}</span>
                            <span className="text-xs text-neutral-400">— {a.performed_by_name}</span>
                          </div>
                          <p className="text-xs text-neutral-400">{formatDateTime(a.date)}</p>
                          <p className="text-xs text-neutral-600 mt-0.5">{a.remarks}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
            </div>
          </Card>
        </div>
      </div>

      {modal === 'activity' && id && <ActivityModal complaintId={id} onClose={() => setModal(null)} />}
      {modal === 'edit' && id && <EditModal complaintId={id} onClose={() => setModal(null)} />}
    </div>
  );
}

function Section({ title, content, placeholder = '' }: { title: string; content?: string; placeholder?: string }) {
  return (
    <div>
      <p className="text-xs font-semibold text-neutral-500 uppercase tracking-wide mb-1">{title}</p>
      {content ? <p className="text-sm text-neutral-700 whitespace-pre-wrap">{content}</p>
        : <p className="text-sm text-neutral-300 italic">{placeholder}</p>}
    </div>
  );
}
