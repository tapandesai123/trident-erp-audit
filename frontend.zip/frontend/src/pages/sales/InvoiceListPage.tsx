import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { createColumnHelper } from '@tanstack/react-table';
import { FunnelIcon, CheckBadgeIcon } from '@heroicons/react/24/outline';

import { salesService, InvoiceListItem, InvoiceStatus } from '@/services/sales';
import DataTable from '@/components/ui/DataTable';
import Badge from '@/components/ui/Badge';
import PageHeader from '@/components/ui/PageHeader';
import Tabs from '@/components/ui/Tabs';
import FilterPanel, { FilterSection, FilterRadioGroup } from '@/components/ui/FilterPanel';
import { usePagination } from '@/hooks/usePagination';
import { useDebounce } from '@/hooks/useDebounce';
import { formatDate, formatCurrency } from '@/utils/format';
import { cn } from '@/utils/cn';

const col = createColumnHelper<InvoiceListItem>();

const STATUS_VARIANT: Record<InvoiceStatus, string> = {
  DRAFT: 'neutral', GENERATED: 'info', SENT: 'primary', PAID: 'success', OVERDUE: 'danger', CANCELLED: 'neutral',
};

const COLUMNS = [
  col.accessor('invoice_number', {
    header: 'Invoice #',
    cell: i => <span className="font-mono text-xs font-semibold text-primary-800">{i.getValue()}</span>,
    size: 140,
  }),
  col.accessor('customer_name', { header: 'Customer', size: 180 }),
  col.accessor('so_number', {
    header: 'SO',
    cell: i => i.getValue() ? <span className="font-mono text-xs text-neutral-500">{i.getValue()}</span> : <span className="text-neutral-300">—</span>,
    size: 120,
  }),
  col.accessor('invoice_date', { header: 'Invoice Date', cell: i => formatDate(i.getValue()), size: 110 }),
  col.accessor('due_date', {
    header: 'Due Date',
    cell: i => {
      const val = i.getValue();
      if (!val) return <span className="text-neutral-300">—</span>;
      const overdue = new Date(val) < new Date() && !['PAID', 'CANCELLED'].includes(i.row.original.status);
      return <span className={cn('text-sm', overdue ? 'text-danger-600 font-semibold' : '')}>{formatDate(val)}</span>;
    },
    size: 110,
  }),
  col.accessor('grand_total', {
    header: 'Amount',
    cell: i => <span className="font-semibold">{formatCurrency(i.getValue())}</span>,
    size: 130,
  }),
  col.accessor('irn_number', {
    header: 'E-Invoice',
    cell: i => i.getValue()
      ? <div className="flex items-center gap-1"><CheckBadgeIcon className="h-4 w-4 text-success-600" /><span className="text-xs text-success-700 font-mono truncate max-w-20">{i.getValue()!.slice(0, 12)}…</span></div>
      : <span className="text-xs text-neutral-300">—</span>,
    size: 120,
  }),
  col.accessor('status', {
    header: 'Status',
    cell: i => <Badge variant={STATUS_VARIANT[i.getValue()] as any}>{i.getValue()}</Badge>,
    size: 90,
  }),
];

const TABS = [
  { key: 'ALL', label: 'All' },
  { key: 'GENERATED', label: 'Generated' },
  { key: 'SENT', label: 'Sent' },
  { key: 'OVERDUE', label: 'Overdue' },
  { key: 'PAID', label: 'Paid' },
];

export default function InvoiceListPage() {
  const navigate = useNavigate();
  const { page, pageSize, setPage, setPageSize } = usePagination();
  const [search, setSearch] = useState('');
  const dSearch = useDebounce(search, 300);
  const [tab, setTab] = useState('ALL');
  const [filterOpen, setFilterOpen] = useState(false);
  const [hasIRN, setHasIRN] = useState('');

  const { data, isLoading } = useQuery({
    queryKey: ['invoices', page, pageSize, dSearch, tab, hasIRN],
    queryFn: () => salesService.listInvoices({
      page, page_size: pageSize,
      search: dSearch || undefined,
      status: tab === 'ALL' ? undefined : tab,
      has_irn: hasIRN || undefined,
    }),
  });

  return (
    <div className="space-y-4">
      <PageHeader title="Invoices" subtitle="GST invoices with e-invoice and e-way bill status" />
      <Tabs tabs={TABS} active={tab} onChange={k => { setTab(k); setPage(1); }} />
      <div className="flex gap-4">
        <div className="flex-1 min-w-0">
          <DataTable
            data={data?.results ?? []}
            columns={COLUMNS}
            loading={isLoading}
            totalCount={data?.count}
            page={page} pageSize={pageSize}
            onPageChange={setPage} onPageSizeChange={setPageSize}
            searchValue={search} onSearchChange={setSearch}
            searchPlaceholder="Search invoice, customer, SO…"
            onRowClick={row => navigate(`/sales/invoices/${row.id}`)}
            toolbarLeft={
              <button onClick={() => setFilterOpen(o => !o)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-sm rounded-lg border bg-white border-neutral-200 text-neutral-600 hover:bg-neutral-50">
                <FunnelIcon className="h-4 w-4" /> Filters
              </button>
            }
            emptyTitle="No invoices found"
          />
        </div>
        <FilterPanel open={filterOpen} onClose={() => setFilterOpen(false)} onReset={() => setHasIRN('')} activeCount={hasIRN ? 1 : 0}>
          <FilterSection label="E-Invoice Status">
            <FilterRadioGroup name="hasIRN" value={hasIRN} onChange={setHasIRN}
              options={[{ value: '', label: 'All' }, { value: 'true', label: 'IRN Generated' }, { value: 'false', label: 'Pending IRN' }]} />
          </FilterSection>
        </FilterPanel>
      </div>
    </div>
  );
}
