import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  PaperAirplaneIcon, CheckCircleIcon, ArrowPathIcon, ArrowRightIcon,
  CalculatorIcon, InformationCircleIcon,
} from '@heroicons/react/24/outline';

import { salesService, QuotationStatus, CostBuilderResult } from '@/services/sales';
import PageHeader from '@/components/ui/PageHeader';
import Card from '@/components/ui/Card';
import Button from '@/components/ui/Button';
import Badge from '@/components/ui/Badge';
import Modal from '@/components/ui/Modal';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import { formatDate, formatCurrency } from '@/utils/format';
import { cn } from '@/utils/cn';

const STATUS_VARIANT: Record<QuotationStatus, string> = {
  DRAFT: 'neutral', SENT: 'info', APPROVED: 'success', REVISED: 'warning',
  REJECTED: 'danger', CONVERTED: 'primary',
};

function ConfirmModal({ title, message, onConfirm, onClose, loading }: {
  title: string; message: string; onConfirm: () => void; onClose: () => void; loading?: boolean;
}) {
  return (
    <Modal open onClose={onClose} title={title} size="sm">
      <div className="p-4 space-y-4">
        <p className="text-sm text-neutral-600">{message}</p>
        <div className="flex gap-2 justify-end">
          <Button variant="ghost" onClick={onClose}>Cancel</Button>
          <Button onClick={onConfirm} loading={loading}>Confirm</Button>
        </div>
      </div>
    </Modal>
  );
}

// P3 – Cost Builder Modal
function CostBuilderModal({
  lines,
  onClose,
}: {
  lines: Array<{ id?: string; item?: string; item_name?: string; description?: string; quantity: string }>;
  onClose: () => void;
}) {
  const fgLines = lines.filter((l: any) => l.item);
  const [selectedItemId, setSelectedItemId] = useState(fgLines[0]?.item ?? '');
  const [qty, setQty] = useState(fgLines[0]?.quantity ?? '100');
  const [profitPct, setProfitPct] = useState('15');
  const [result, setResult] = useState<CostBuilderResult | null>(null);

  const calcMut = useMutation({
    mutationFn: () => salesService.buildQuotationCost(
      selectedItemId,
      parseFloat(qty) || 1,
      parseFloat(profitPct) || 15,
    ),
    onSuccess: setResult,
  });

  const fmt = (v: string | number) =>
    `₹${parseFloat(String(v)).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 4 })}`;

  return (
    <Modal open onClose={onClose} title="Quotation Cost Builder" size="lg">
      <div className="p-4 space-y-5">
        {/* Controls */}
        <div className="grid grid-cols-3 gap-3">
          <div>
            <label className="block text-xs font-medium text-neutral-600 mb-1">Item (Finished Good)</label>
            <select
              className="w-full rounded-lg border border-neutral-200 px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary-400"
              value={selectedItemId}
              onChange={e => { setSelectedItemId(e.target.value); setResult(null); }}
            >
              {fgLines.map((l: any) => (
                <option key={l.item} value={l.item}>{l.item_name || l.description || l.item}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-neutral-600 mb-1">Quantity</label>
            <input
              type="number" min="1"
              className="w-full rounded-lg border border-neutral-200 px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary-400"
              value={qty}
              onChange={e => { setQty(e.target.value); setResult(null); }}
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-neutral-600 mb-1">Profit Margin %</label>
            <input
              type="number" min="0" max="100" step="0.5"
              className="w-full rounded-lg border border-neutral-200 px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary-400"
              value={profitPct}
              onChange={e => { setProfitPct(e.target.value); setResult(null); }}
            />
          </div>
        </div>

        <Button
          onClick={() => calcMut.mutate()}
          loading={calcMut.isPending}
          disabled={!selectedItemId}
          size="sm"
        >
          <CalculatorIcon className="h-4 w-4 mr-1" /> Calculate Cost
        </Button>

        {calcMut.isPending && (
          <div className="flex justify-center py-6"><LoadingSpinner size="lg" /></div>
        )}

        {result && (
          <div className="space-y-4">
            {/* Warning banner */}
            {result.warning && (
              <div className="flex items-start gap-2 rounded-lg bg-warning-50 border border-warning-200 p-3 text-sm text-warning-800">
                <InformationCircleIcon className="h-4 w-4 mt-0.5 shrink-0 text-warning-600" />
                {result.warning}
              </div>
            )}

            {/* Summary cards */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
              {[
                { label: 'RM Cost / Unit', value: fmt(result.rm_cost_per_unit), cls: 'bg-neutral-50 border-neutral-200' },
                { label: 'Conversion / Unit', value: fmt(result.conversion_cost_per_unit), cls: 'bg-neutral-50 border-neutral-200' },
                { label: 'Total Cost / Unit', value: fmt(result.total_cost_per_unit), cls: 'bg-neutral-50 border-neutral-200' },
                { label: `Suggested Rate (${result.profit_pct}% margin)`, value: fmt(result.suggested_rate), cls: 'bg-primary-50 border-primary-300' },
              ].map(({ label, value, cls }) => (
                <div key={label} className={cn('rounded-lg border p-3', cls)}>
                  <p className="text-xs text-neutral-500 mb-1 leading-tight">{label}</p>
                  <p className="text-base font-bold text-neutral-900">{value}</p>
                </div>
              ))}
            </div>

            {/* RM breakdown table */}
            {result.rm_breakdown.length > 0 && (
              <div className="border border-neutral-200 rounded-lg overflow-hidden">
                <div className="px-4 py-2.5 bg-neutral-50 border-b border-neutral-200">
                  <h4 className="text-xs font-semibold text-neutral-700 uppercase tracking-wide">Raw Material Breakdown</h4>
                </div>
                <table className="w-full text-xs">
                  <thead>
                    <tr className="text-neutral-500 border-b border-neutral-100">
                      <th className="px-4 py-2 text-left font-medium">Component</th>
                      <th className="px-4 py-2 text-right font-medium">Qty / Unit</th>
                      <th className="px-4 py-2 text-right font-medium">Avg RM Cost</th>
                      <th className="px-4 py-2 text-right font-medium">Line Cost</th>
                    </tr>
                  </thead>
                  <tbody>
                    {result.rm_breakdown.map((rm, i) => (
                      <tr key={i} className="border-t border-neutral-50 hover:bg-neutral-50">
                        <td className="px-4 py-2">
                          <span className="font-medium text-neutral-800">{rm.component_code}</span>
                          <span className="ml-2 text-neutral-400">{rm.component_name}</span>
                          {rm.warning && (
                            <span className="ml-2 text-warning-600 text-[10px]">⚠ {rm.warning}</span>
                          )}
                        </td>
                        <td className="px-4 py-2 text-right tabular-nums">{rm.qty_per_unit}</td>
                        <td className="px-4 py-2 text-right tabular-nums">{fmt(rm.avg_rm_cost)}</td>
                        <td className="px-4 py-2 text-right tabular-nums font-semibold">{fmt(rm.line_cost)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {!result.bom_found && (
              <p className="text-sm text-neutral-400 text-center py-2">
                No active BOM found — RM breakdown unavailable.
              </p>
            )}
          </div>
        )}

        <div className="flex justify-end border-t border-neutral-100 pt-3">
          <Button variant="ghost" onClick={onClose}>Close</Button>
        </div>
      </div>
    </Modal>
  );
}

export default function QuotationDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [modal, setModal] = useState<'approve' | 'send' | 'revise' | 'convert' | 'costBuilder' | null>(null);

  const { data: quot, isLoading } = useQuery({
    queryKey: ['quotation', id],
    queryFn: () => salesService.getQuotation(id!),
    enabled: !!id,
  });

  const approve = useMutation({
    mutationFn: () => salesService.approveQuotation(id!),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['quotation', id] }); setModal(null); },
  });

  const send = useMutation({
    mutationFn: () => salesService.sendToCustomer(id!),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['quotation', id] }); setModal(null); },
  });

  const revise = useMutation({
    mutationFn: () => salesService.createRevision(id!),
    onSuccess: (q: any) => navigate(`/sales/quotations/${q.id}`),
  });

  const convert = useMutation({
    mutationFn: () => salesService.convertToSO(id!),
    onSuccess: (so: any) => navigate(`/sales/orders/${so.id}`),
  });

  if (isLoading) return <div className="flex items-center justify-center h-64"><LoadingSpinner size="xl" /></div>;
  if (!quot) return null;

  const canApprove = quot.status === 'SENT';
  const canSend = quot.status === 'DRAFT' || quot.status === 'APPROVED';
  const canRevise = ['DRAFT', 'SENT', 'APPROVED'].includes(quot.status);
  const canConvert = quot.status === 'APPROVED';
  const hasFGLines = quot.lines.some((l: any) => l.item);

  return (
    <div className="space-y-4">
      <PageHeader
        title={`Quotation — ${quot.quotation_number}`}
        subtitle={`${quot.customer_name}${quot.revision > 0 ? ` · Revision ${quot.revision}` : ''}`}
        breadcrumbs={[{ label: 'Sales' }, { label: 'Quotations', href: '/sales/quotations' }, { label: quot.quotation_number }]}
        actions={
          <div className="flex gap-2 flex-wrap">
            {/* P3 – Cost Builder button */}
            {hasFGLines && (
              <Button variant="secondary" size="sm" onClick={() => setModal('costBuilder')}>
                <CalculatorIcon className="h-4 w-4 mr-1" /> Cost Builder
              </Button>
            )}
            {canSend && (
              <Button variant="secondary" size="sm" onClick={() => setModal('send')}>
                <PaperAirplaneIcon className="h-4 w-4 mr-1" /> Send to Customer
              </Button>
            )}
            {canApprove && (
              <Button variant="secondary" size="sm" onClick={() => setModal('approve')}>
                <CheckCircleIcon className="h-4 w-4 mr-1" /> Approve
              </Button>
            )}
            {canRevise && (
              <Button variant="secondary" size="sm" onClick={() => setModal('revise')}>
                <ArrowPathIcon className="h-4 w-4 mr-1" /> Create Revision
              </Button>
            )}
            {canConvert && (
              <Button size="sm" onClick={() => setModal('convert')}>
                <ArrowRightIcon className="h-4 w-4 mr-1" /> Convert to SO
              </Button>
            )}
            {quot.so_number && (
              <Button variant="secondary" size="sm" onClick={() => navigate(`/sales/orders/${quot.so_id}`)}>
                View SO {quot.so_number}
              </Button>
            )}
          </div>
        }
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Info */}
        <Card>
          <div className="p-4 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-neutral-700">Details</h3>
              <Badge variant={STATUS_VARIANT[quot.status] as any}>{quot.status}</Badge>
            </div>
            <div className="space-y-2 text-sm border-t border-neutral-100 pt-3">
              {[
                { label: 'Customer', value: quot.customer_name },
                { label: 'Date', value: formatDate(quot.quotation_date) },
                { label: 'Valid Until', value: quot.valid_until ? formatDate(quot.valid_until) : '—' },
                { label: 'Currency', value: quot.currency ?? 'INR' },
                { label: 'Enquiry', value: quot.enquiry_number ?? '—' },
                { label: 'Parent Rev', value: quot.parent_quotation_id ? `Rev ${quot.revision - 1}` : '—' },
              ].map(({ label, value }) => (
                <div key={label} className="flex justify-between items-start gap-2">
                  <span className="text-neutral-500 shrink-0">{label}</span>
                  <span className="text-neutral-800 text-right">{value}</span>
                </div>
              ))}
            </div>
            {quot.terms && (
              <div className="border-t border-neutral-100 pt-3">
                <p className="text-xs font-semibold text-neutral-500 mb-1">Terms & Conditions</p>
                <p className="text-xs text-neutral-600 whitespace-pre-wrap">{quot.terms}</p>
              </div>
            )}
          </div>
        </Card>

        {/* Line items + totals */}
        <div className="lg:col-span-2 space-y-4">
          <Card>
            <div className="p-4">
              <h3 className="text-sm font-semibold text-neutral-700 mb-3">Line Items</h3>
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-xs text-neutral-500 border-b border-neutral-100">
                    <th className="py-2 pr-3 text-left font-medium">#</th>
                    <th className="py-2 pr-3 text-left font-medium">Description</th>
                    <th className="py-2 pr-3 text-right font-medium">Qty</th>
                    <th className="py-2 pr-3 text-right font-medium">Unit Price</th>
                    <th className="py-2 pr-3 text-right font-medium">Disc %</th>
                    <th className="py-2 text-right font-medium">Amount</th>
                  </tr>
                </thead>
                <tbody>
                  {quot.lines.map((l: any) => (
                    <tr key={l.id ?? l.line_number} className="border-b border-neutral-50">
                      <td className="py-2.5 pr-3 text-neutral-400 text-xs">{l.line_number}</td>
                      <td className="py-2.5 pr-3">
                        <p className="font-medium text-neutral-800">{l.description}</p>
                        {l.item_code && <p className="text-xs text-neutral-400">{l.item_code}</p>}
                        {/* P3 – Show cost builder metadata on line if used */}
                        {l.cost_builder_used && l.cost_based_rate && parseFloat(l.cost_based_rate) > 0 && (
                          <p className="text-[10px] text-primary-600 mt-0.5 flex items-center gap-0.5">
                            <CalculatorIcon className="h-3 w-3" />
                            Cost rate: {formatCurrency(l.cost_based_rate)} · {l.profit_pct}% margin
                          </p>
                        )}
                      </td>
                      <td className="py-2.5 pr-3 text-right">{l.quantity} {l.uom_code}</td>
                      <td className="py-2.5 pr-3 text-right">{formatCurrency(l.unit_price)}</td>
                      <td className="py-2.5 pr-3 text-right text-neutral-500">{l.discount_pct ? `${l.discount_pct}%` : '—'}</td>
                      <td className="py-2.5 text-right font-semibold">{formatCurrency(l.amount)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>

          <Card>
            <div className="p-4">
              <div className="max-w-xs ml-auto space-y-2 text-sm">
                <div className="flex justify-between text-neutral-600">
                  <span>Subtotal</span><span>{formatCurrency(quot.subtotal)}</span>
                </div>
                {quot.discount_amount && parseFloat(quot.discount_amount) > 0 && (
                  <div className="flex justify-between text-success-700">
                    <span>Discount</span><span>- {formatCurrency(quot.discount_amount)}</span>
                  </div>
                )}
                <div className="flex justify-between text-neutral-600">
                  <span>Tax</span><span>{formatCurrency(quot.tax_amount)}</span>
                </div>
                <div className="flex justify-between font-bold text-base border-t border-neutral-200 pt-2">
                  <span>Grand Total</span><span>{formatCurrency(quot.grand_total)}</span>
                </div>
              </div>
            </div>
          </Card>
        </div>
      </div>

      {/* P3 – Cost Builder Modal */}
      {modal === 'costBuilder' && (
        <CostBuilderModal
          lines={quot.lines}
          onClose={() => setModal(null)}
        />
      )}

      {modal === 'approve' && (
        <ConfirmModal title="Approve Quotation" message="Mark this quotation as approved?" loading={approve.isPending}
          onConfirm={() => approve.mutate()} onClose={() => setModal(null)} />
      )}
      {modal === 'send' && (
        <ConfirmModal title="Send to Customer" message="Send this quotation to the customer via email?" loading={send.isPending}
          onConfirm={() => send.mutate()} onClose={() => setModal(null)} />
      )}
      {modal === 'revise' && (
        <ConfirmModal title="Create Revision" message="Create a new revision of this quotation? The current revision will be marked as revised." loading={revise.isPending}
          onConfirm={() => revise.mutate()} onClose={() => setModal(null)} />
      )}
      {modal === 'convert' && (
        <ConfirmModal title="Convert to Sales Order" message="Convert this approved quotation to a Sales Order?" loading={convert.isPending}
          onConfirm={() => convert.mutate()} onClose={() => setModal(null)} />
      )}
    </div>
  );
}
