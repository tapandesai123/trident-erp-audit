import { useRef, useState } from 'react';
import { useParams } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  CheckBadgeIcon, TruckIcon, DocumentArrowUpIcon, PlusIcon,
  ArrowDownTrayIcon, GlobeAltIcon,
} from '@heroicons/react/24/outline';

import { salesService } from '@/services/sales';
import api from '@/services/api';
import PageHeader from '@/components/ui/PageHeader';
import Card from '@/components/ui/Card';
import Button from '@/components/ui/Button';
import Badge from '@/components/ui/Badge';
import Modal from '@/components/ui/Modal';
import FormField from '@/components/ui/FormField';
import Input from '@/components/ui/Input';
import Textarea from '@/components/ui/Textarea';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import { formatDate, formatDateTime, formatCurrency } from '@/utils/format';
import { cn } from '@/utils/cn';

const STATUS_VARIANT: Record<string, string> = {
  DRAFT: 'neutral', GENERATED: 'info', SENT: 'primary', PAID: 'success', OVERDUE: 'danger', CANCELLED: 'neutral',
};

const DELIVERY_EVENTS = [
  'PICKED_UP', 'IN_TRANSIT', 'OUT_FOR_DELIVERY', 'CUSTOMER_GATE_ENTRY',
  'DELIVERED', 'RETURNED', 'POD_UPLOADED',
];

function DeliveryEventModal({ invoiceId, onClose }: { invoiceId: string; onClose: () => void }) {
  const qc = useQueryClient();
  const [form, setForm] = useState({ event_type: 'CUSTOMER_GATE_ENTRY', location: '', remarks: '' });
  const mut = useMutation({
    mutationFn: () => salesService.addDeliveryEvent(invoiceId, form),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['invoice', invoiceId] }); onClose(); },
  });
  return (
    <Modal open onClose={onClose} title="Add Delivery Event" size="sm">
      <div className="space-y-4 p-4">
        <FormField label="Event Type" required>
          <select value={form.event_type} onChange={e => setForm(f => ({ ...f, event_type: e.target.value }))}
            className="w-full rounded-lg border border-neutral-200 px-3 py-2 text-sm">
            {DELIVERY_EVENTS.map(e => <option key={e} value={e}>{e.replace(/_/g, ' ')}</option>)}
          </select>
        </FormField>
        <FormField label="Location">
          <Input value={form.location} onChange={e => setForm(f => ({ ...f, location: e.target.value }))} placeholder="City / checkpoint…" />
        </FormField>
        <FormField label="Remarks">
          <Textarea value={form.remarks} onChange={e => setForm(f => ({ ...f, remarks: e.target.value }))} rows={2} />
        </FormField>
        <div className="flex gap-2 justify-end">
          <Button variant="ghost" onClick={onClose}>Cancel</Button>
          <Button onClick={() => mut.mutate()} loading={mut.isPending}>Add Event</Button>
        </div>
      </div>
    </Modal>
  );
}

export default function InvoiceDetailPage() {
  const { id } = useParams<{ id: string }>();
  const qc = useQueryClient();
  const [eventModal, setEventModal] = useState(false);
  const [packingListLoading, setPackingListLoading] = useState(false);
  const podRef = useRef<HTMLInputElement>(null);

  const { data: inv, isLoading } = useQuery({
    queryKey: ['invoice', id],
    queryFn: () => salesService.getInvoice(id!),
    enabled: !!id,
  });

  const podMut = useMutation({
    mutationFn: (file: File) => salesService.uploadPOD(id!, file),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['invoice', id] }),
  });

  /** Download packing list as PDF blob, open in new tab */
  async function handleDownloadPackingList() {
    if (!id) return;
    setPackingListLoading(true);
    try {
      const resp = await api.get(`/sales/invoices/${id}/packing-list/`, {
        responseType: 'blob',
      });
      const blob = new Blob([resp.data], { type: 'application/pdf' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `PackingList_${inv?.invoice_number ?? id}.pdf`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (err) {
      alert('Failed to generate packing list PDF.');
    } finally {
      setPackingListLoading(false);
    }
  }

  if (isLoading) return <div className="flex items-center justify-center h-64"><LoadingSpinner size="xl" /></div>;
  if (!inv) return null;

  const gst = inv.gst_breakup;
  const isInter = inv.is_interstate;
  // Export invoice: invoice_type is EXPORT, or nepal_bhutan_export flag
  const isExport = inv.invoice_type === 'EXPORT' || inv.nepal_bhutan_export === true;

  return (
    <div className="space-y-4">
      <PageHeader
        title={`Invoice — ${inv.invoice_number}`}
        subtitle={inv.customer_name}
        breadcrumbs={[{ label: 'Sales' }, { label: 'Invoices', href: '/sales/invoices' }, { label: inv.invoice_number }]}
        actions={
          <div className="flex gap-2">
            {isExport && (
              <Button
                variant="primary"
                size="sm"
                onClick={handleDownloadPackingList}
                loading={packingListLoading}
              >
                <ArrowDownTrayIcon className="h-4 w-4 mr-1" />
                Download Packing List
              </Button>
            )}
            <Button variant="ghost" size="sm" onClick={() => setEventModal(true)}>
              <PlusIcon className="h-4 w-4 mr-1" /> Delivery Event
            </Button>
            <Button variant="secondary" size="sm" onClick={() => podRef.current?.click()}>
              <DocumentArrowUpIcon className="h-4 w-4 mr-1" /> Upload POD
            </Button>
            <input ref={podRef} type="file" accept="image/*,application/pdf" className="hidden"
              onChange={e => { if (e.target.files?.[0]) podMut.mutate(e.target.files[0]); }} />
          </div>
        }
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Invoice info */}
        <Card>
          <div className="p-4 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-neutral-700">Invoice Details</h3>
              <Badge variant={STATUS_VARIANT[inv.status] as any}>{inv.status}</Badge>
            </div>
            <div className="space-y-2 text-sm border-t border-neutral-100 pt-3">
              {[
                { label: 'Customer', value: inv.customer_name },
                { label: 'Invoice Date', value: formatDate(inv.invoice_date) },
                { label: 'Due Date', value: inv.due_date ? formatDate(inv.due_date) : '—' },
                { label: 'Place of Supply', value: inv.place_of_supply ?? '—' },
                { label: 'Our GSTIN', value: inv.our_gstin ?? '—' },
                { label: 'Customer GSTIN', value: inv.customer_gstin ?? '—' },
                { label: 'SO Number', value: inv.so_number ?? '—' },
              ].map(({ label, value }) => (
                <div key={label} className="flex justify-between items-start gap-2">
                  <span className="text-neutral-500 shrink-0">{label}</span>
                  <span className="text-neutral-800 text-right text-xs font-mono">{value}</span>
                </div>
              ))}
            </div>

            {/* E-Invoice / E-Way */}
            <div className="border-t border-neutral-100 pt-3 space-y-2">
              <div className="flex items-center gap-2">
                <CheckBadgeIcon className={cn('h-4 w-4', inv.irn_number ? 'text-success-600' : 'text-neutral-300')} />
                <div>
                  <p className="text-xs font-semibold text-neutral-600">IRN (E-Invoice)</p>
                  {inv.irn_number
                    ? <p className="text-xs font-mono text-success-700 break-all">{inv.irn_number}</p>
                    : <p className="text-xs text-neutral-400">Not generated</p>}
                </div>
              </div>
              <div className="flex items-center gap-2">
                <TruckIcon className={cn('h-4 w-4', inv.eway_bill_number ? 'text-success-600' : 'text-neutral-300')} />
                <div>
                  <p className="text-xs font-semibold text-neutral-600">E-Way Bill</p>
                  {inv.eway_bill_number
                    ? <p className="text-xs font-mono text-success-700">{inv.eway_bill_number}</p>
                    : <p className="text-xs text-neutral-400">Not generated</p>}
                </div>
              </div>
            </div>

            {inv.pod_url && (
              <a href={inv.pod_url} target="_blank" rel="noopener noreferrer"
                className="flex items-center gap-2 text-xs text-primary-600 hover:underline border-t border-neutral-100 pt-3">
                <DocumentArrowUpIcon className="h-4 w-4" /> View POD
              </a>
            )}
          </div>
        </Card>

        <div className="lg:col-span-2 space-y-4">
          {/* GST Breakup */}
          <Card>
            <div className="p-4">
              <h3 className="text-sm font-semibold text-neutral-700 mb-3">GST Breakup</h3>
              <div className="max-w-sm ml-auto space-y-1.5 text-sm">
                <div className="flex justify-between text-neutral-600">
                  <span>Taxable Amount</span>
                  <span className="font-medium">{formatCurrency(gst.taxable_amount)}</span>
                </div>
                {isInter ? (
                  <div className="flex justify-between text-neutral-600">
                    <span>IGST ({gst.igst_rate}%)</span>
                    <span>{formatCurrency(gst.igst_amount ?? '0')}</span>
                  </div>
                ) : (
                  <>
                    <div className="flex justify-between text-neutral-600">
                      <span>CGST ({gst.cgst_rate}%)</span>
                      <span>{formatCurrency(gst.cgst_amount ?? '0')}</span>
                    </div>
                    <div className="flex justify-between text-neutral-600">
                      <span>SGST ({gst.sgst_rate}%)</span>
                      <span>{formatCurrency(gst.sgst_amount ?? '0')}</span>
                    </div>
                  </>
                )}
                <div className="flex justify-between text-neutral-600 border-t border-neutral-100 pt-1">
                  <span>Total Tax</span>
                  <span className="font-medium">{formatCurrency(gst.total_tax)}</span>
                </div>
                <div className="flex justify-between font-bold text-base border-t border-neutral-200 pt-1.5">
                  <span>Grand Total</span>
                  <span>{formatCurrency(gst.grand_total)}</span>
                </div>
                <p className="text-xs text-neutral-400 pt-1">
                  {isInter ? 'Interstate supply — IGST applicable' : 'Intrastate supply — CGST + SGST applicable'}
                </p>
              </div>
            </div>
          </Card>

          {/* Delivery Tracking */}
          <Card>
            <div className="p-4">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-semibold text-neutral-700">Delivery Tracking</h3>
                <button onClick={() => setEventModal(true)}
                  className="text-xs text-primary-600 hover:text-primary-800 font-medium">+ Add Event</button>
              </div>
              {!inv.delivery_events?.length
                ? <p className="text-sm text-neutral-400 text-center py-4">No delivery events recorded.</p>
                : (
                  <div className="space-y-3">
                    {[...inv.delivery_events].reverse().map((ev, i, arr) => (
                      <div key={ev.id} className="flex gap-3">
                        <div className="flex flex-col items-center">
                          <div className={cn(
                            'h-2.5 w-2.5 rounded-full mt-1 shrink-0',
                            i === 0 ? 'bg-primary-600' : 'bg-neutral-300'
                          )} />
                          {i < arr.length - 1 && <div className="w-px flex-1 bg-neutral-200 mt-1" />}
                        </div>
                        <div className="pb-3">
                          <div className="flex items-center gap-2 mb-0.5">
                            <span className="text-xs font-semibold text-neutral-700">{ev.event_type.replace(/_/g, ' ')}</span>
                            {ev.location && <span className="text-xs text-neutral-400">· {ev.location}</span>}
                          </div>
                          <p className="text-xs text-neutral-500">{formatDateTime(ev.timestamp)}</p>
                          {ev.remarks && <p className="text-xs text-neutral-600 mt-0.5">{ev.remarks}</p>}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
            </div>
          </Card>
        </div>
      </div>

      {eventModal && id && <DeliveryEventModal invoiceId={id} onClose={() => setEventModal(false)} />}

      {/* Export Details — visible only for export invoices */}
      {isExport && (
        <Card>
          <div className="p-4">
            <div className="flex items-center gap-2 mb-3">
              <GlobeAltIcon className="h-4 w-4 text-primary-600" />
              <h3 className="text-sm font-semibold text-neutral-700">Export Details</h3>
              <Badge variant="info">Export</Badge>
              {inv.nepal_bhutan_export && <Badge variant="warning">Nepal/Bhutan</Badge>}
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-x-6 gap-y-3 text-sm">
              {[
                { label: 'Port of Loading',    value: inv.port_of_loading },
                { label: 'Port of Discharge',  value: inv.port_of_discharge },
                { label: 'Port Code',          value: inv.port_code },
                { label: 'Incoterms',          value: inv.incoterms },
                { label: 'Container No',       value: inv.container_number },
                { label: 'Container Size',     value: inv.container_size },
                { label: 'Seal No',            value: inv.seal_number },
                { label: 'No of Packages',     value: inv.no_of_packages },
                { label: 'Gross Weight (kg)',  value: inv.gross_weight_kg },
                { label: 'Net Weight (kg)',    value: inv.net_weight_kg },
                { label: 'Export Currency',    value: inv.export_currency },
                { label: 'Exchange Rate',      value: inv.exchange_rate },
                { label: 'Foreign Amount',     value: inv.foreign_amount },
                { label: 'IE Code',            value: inv.ie_code },
                { label: 'LUT Number',         value: inv.lut_number },
                { label: 'Shipping Bill No',   value: inv.shipping_bill_no },
                { label: 'LC Number',          value: inv.lc_number },
                { label: 'Bank (SWIFT)',       value: inv.bank_swift_code ? `${inv.bank_name} (${inv.bank_swift_code})` : inv.bank_name },
                { label: 'Country of Dest.',  value: inv.country_of_destination },
              ].map(({ label, value }) => (
                <div key={label}>
                  <p className="text-xs text-neutral-500 mb-0.5">{label}</p>
                  <p className="text-neutral-800 font-medium font-mono text-xs">{value ?? '—'}</p>
                </div>
              ))}
            </div>
            <div className="mt-4 pt-3 border-t border-neutral-100">
              <Button
                variant="primary"
                size="sm"
                onClick={handleDownloadPackingList}
                loading={packingListLoading}
              >
                <ArrowDownTrayIcon className="h-4 w-4 mr-1.5" />
                Download Packing List PDF
              </Button>
              <p className="text-xs text-neutral-400 mt-1.5">
                Generates complete export packing list with item-wise weight and FCY breakup.
              </p>
            </div>
          </div>
        </Card>
      )}
    </div>
  );
}
