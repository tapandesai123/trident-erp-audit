import { useQuery, useMutation } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { useState, useRef } from 'react';
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell,
} from 'recharts';
import {
  CurrencyRupeeIcon,
  ShoppingBagIcon,
  DocumentTextIcon,
  ExclamationTriangleIcon,
  UsersIcon,
  ArrowUpTrayIcon,
  XMarkIcon,
} from '@heroicons/react/24/outline';

import { salesService } from '@/services/sales';
import api from '@/services/api';
import PageHeader from '@/components/ui/PageHeader';
import Card from '@/components/ui/Card';
import Badge from '@/components/ui/Badge';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import { formatCurrency, formatDate } from '@/utils/format';
import { cn } from '@/utils/cn';

// ─── EDI Upload Modal ───────────────────────────────────────────────
function EDIUploadModal({ onClose }: { onClose: () => void }) {
  const fileRef = useRef<HTMLInputElement>(null);
  const [format, setFormat] = useState<'flipkart' | 'amazon' | 'custom'>('flipkart');
  const [result, setResult] = useState<{ created: number; skipped: number; errors: string[] } | null>(null);

  const uploadMutation = useMutation({
    mutationFn: (file: File) => {
      const fd = new FormData();
      fd.append('file', file);
      fd.append('format', format);
      return api.post('/api/v1/sales/orders/edi_upload/', fd, {
        headers: { 'Content-Type': 'multipart/form-data' },
      }).then(r => r.data);
    },
    onSuccess: (data) => setResult(data),
  });

  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (f) uploadMutation.mutate(f);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-md p-6 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-base font-semibold text-neutral-900">EDI / Excel Upload</h3>
          <button onClick={onClose} className="p-1 hover:bg-neutral-100 rounded-lg">
            <XMarkIcon className="h-5 w-5 text-neutral-500" />
          </button>
        </div>
        <p className="text-sm text-neutral-500">Upload customer PO Excel from e-commerce portals. Orders will be created as Draft for review.</p>

        <div>
          <label className="text-xs font-medium text-neutral-700">Format</label>
          <select className="input mt-1 w-full" value={format} onChange={e => setFormat(e.target.value as typeof format)}>
            <option value="flipkart">Flipkart PO Excel</option>
            <option value="amazon">Amazon SO Excel</option>
            <option value="custom">Custom Format</option>
          </select>
        </div>

        {!result && (
          <button
            onClick={() => fileRef.current?.click()}
            disabled={uploadMutation.isPending}
            className="w-full py-3 border-2 border-dashed border-neutral-300 rounded-xl text-sm text-neutral-600 hover:border-primary-400 hover:text-primary-600 transition-colors disabled:opacity-50"
          >
            {uploadMutation.isPending ? 'Uploading…' : '📂 Click to select Excel file (.xlsx)'}
          </button>
        )}
        <input ref={fileRef} type="file" accept=".xlsx,.xls,.csv" className="hidden" onChange={handleFile} />

        {uploadMutation.isError && (
          <div className="bg-red-50 border border-red-200 rounded-xl px-4 py-3 text-sm text-red-700">
            Upload failed. Check file format and try again.
          </div>
        )}

        {result && (
          <div className="bg-green-50 border border-green-200 rounded-xl px-4 py-3 space-y-1">
            <p className="text-sm font-semibold text-green-800">✓ {result.created} orders created as Draft</p>
            {result.skipped > 0 && <p className="text-xs text-green-700">{result.skipped} rows skipped (duplicate/invalid)</p>}
            {result.errors?.length > 0 && (
              <ul className="text-xs text-red-600 mt-1 space-y-0.5">
                {result.errors.map((e, i) => <li key={i}>• {e}</li>)}
              </ul>
            )}
          </div>
        )}

        <div className="flex gap-2 justify-end">
          <button onClick={onClose} className="btn btn-outline">Close</button>
          {result && <button onClick={() => setResult(null)} className="btn btn-primary">Upload Another</button>}
        </div>
      </div>
    </div>
  );
}

const CHART_COLORS = ['#2563eb', '#7c3aed', '#db2777', '#ea580c', '#16a34a',
  '#0891b2', '#9333ea', '#c026d3', '#d97706', '#65a30d'];

function KPI({ icon: Icon, label, value, sub, color = 'text-primary-600', onClick }: {
  icon: React.ElementType; label: string; value: string | number;
  sub?: string; color?: string; onClick?: () => void;
}) {
  return (
    <Card className={onClick ? 'cursor-pointer hover:shadow-md transition-shadow' : ''} onClick={onClick}>
      <div className="p-5 flex items-start gap-4">
        <div className={`p-2.5 rounded-xl bg-neutral-50`}>
          <Icon className={`h-5 w-5 ${color}`} />
        </div>
        <div className="min-w-0">
          <p className="text-xs text-neutral-500 font-medium mb-0.5">{label}</p>
          <p className="text-xl font-bold text-neutral-800">{value}</p>
          {sub && <p className="text-xs text-neutral-400 mt-0.5">{sub}</p>}
        </div>
      </div>
    </Card>
  );
}

export default function SalesDashboardPage() {
  const [showEDI, setShowEDI] = useState(false);
  const navigate = useNavigate();
  const { data, isLoading } = useQuery({
    queryKey: ['sales-dashboard'],
    queryFn: salesService.getDashboard,
  });

  if (isLoading) return (
    <div className="flex items-center justify-center h-64">
      <LoadingSpinner size="xl" className="text-primary-600" />
    </div>
  );
  if (!data) return null;

  return (
    <div className="space-y-6">
      {showEDI && <EDIUploadModal onClose={() => setShowEDI(false)} />}
      <PageHeader title="Sales Dashboard" subtitle="Pipeline, revenue, and delivery overview"
        actions={
          <button onClick={() => setShowEDI(true)} className="btn btn-outline flex items-center gap-1.5">
            <ArrowUpTrayIcon className="h-4 w-4" /> EDI Upload
          </button>
        } />

      {/* KPI row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <KPI icon={CurrencyRupeeIcon} label="Pipeline Value" value={formatCurrency(data.pipeline_value)} color="text-primary-600" />
        <KPI icon={ShoppingBagIcon} label="Orders This Month" value={data.orders_this_month} color="text-violet-600" />
        <KPI icon={DocumentTextIcon} label="Invoiced This Month" value={formatCurrency(data.invoiced_this_month)} color="text-teal-600" />
        <KPI
          icon={ExclamationTriangleIcon}
          label="Collection Pending"
          value={formatCurrency(data.collection_pending)}
          color="text-danger-600"
          onClick={() => navigate('/sales/invoices?status=OVERDUE')}
        />
      </div>

      {/* Charts row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Monthly sales */}
        <Card className="lg:col-span-2">
          <div className="p-4">
            <h3 className="text-sm font-semibold text-neutral-700 mb-4">Monthly Sales Revenue</h3>
            <ResponsiveContainer width="100%" height={240}>
              <BarChart data={data.monthly_sales} margin={{ left: 0, right: 10 }}>
                <XAxis dataKey="month" tick={{ fontSize: 11 }} />
                <YAxis tickFormatter={v => `₹${(v / 100000).toFixed(0)}L`} tick={{ fontSize: 11 }} />
                <Tooltip
                  formatter={(v: number) => [formatCurrency(v), 'Revenue']}
                  contentStyle={{ fontSize: 12 }}
                />
                <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                  {data.monthly_sales.map((_, i) => (
                    <Cell key={i} fill={i === data.monthly_sales.length - 1 ? '#2563eb' : '#93c5fd'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>

        {/* Top customers */}
        <Card>
          <div className="p-4">
            <div className="flex items-center gap-2 mb-4">
              <UsersIcon className="h-4 w-4 text-neutral-400" />
              <h3 className="text-sm font-semibold text-neutral-700">Top Customers</h3>
            </div>
            <div className="space-y-3">
              {data.top_customers.map((c, i) => (
                <div key={c.customer_name}>
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-neutral-400 w-4">{i + 1}</span>
                      <span className="text-sm text-neutral-700 font-medium truncate max-w-32">{c.customer_name}</span>
                    </div>
                    <span className="text-xs font-semibold text-neutral-800">{formatCurrency(c.revenue)}</span>
                  </div>
                  <div className="ml-6 h-1.5 bg-neutral-100 rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full"
                      style={{
                        width: `${(c.revenue / data.top_customers[0].revenue) * 100}%`,
                        background: CHART_COLORS[i % CHART_COLORS.length],
                      }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </Card>
      </div>

      {/* Overdue deliveries */}
      {data.overdue_deliveries.length > 0 && (
        <Card>
          <div className="p-4">
            <div className="flex items-center gap-2 mb-3">
              <ExclamationTriangleIcon className="h-4 w-4 text-danger-500" />
              <h3 className="text-sm font-semibold text-neutral-700">Overdue Deliveries</h3>
              <Badge variant="danger" size="sm">{data.overdue_deliveries.length}</Badge>
            </div>
            <table className="w-full text-sm">
              <thead>
                <tr className="text-xs text-neutral-500 border-b border-neutral-100">
                  <th className="py-2 pr-4 text-left font-medium">SO Number</th>
                  <th className="py-2 pr-4 text-left font-medium">Customer</th>
                  <th className="py-2 pr-4 text-left font-medium">Required By</th>
                  <th className="py-2 text-right font-medium">Days Overdue</th>
                </tr>
              </thead>
              <tbody>
                {data.overdue_deliveries.map(d => (
                  <tr
                    key={d.so_number}
                    className="border-b border-neutral-50 hover:bg-neutral-50 cursor-pointer"
                    onClick={() => navigate(`/sales/orders?search=${d.so_number}`)}
                  >
                    <td className="py-2.5 pr-4 font-mono text-xs font-semibold text-primary-700">{d.so_number}</td>
                    <td className="py-2.5 pr-4 text-neutral-700">{d.customer_name}</td>
                    <td className="py-2.5 pr-4 text-neutral-600">{formatDate(d.delivery_date)}</td>
                    <td className="py-2.5 text-right">
                      <Badge variant="danger" size="sm">{d.days_overdue}d</Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}
    </div>
  );
}
