import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { PlusIcon, ArrowRightIcon } from '@heroicons/react/24/outline';

import { salesService, EnquiryStatus } from '@/services/sales';
import PageHeader from '@/components/ui/PageHeader';
import Card from '@/components/ui/Card';
import Button from '@/components/ui/Button';
import Badge from '@/components/ui/Badge';
import FormField from '@/components/ui/FormField';
import Input from '@/components/ui/Input';
import Textarea from '@/components/ui/Textarea';
import Modal from '@/components/ui/Modal';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import { formatDate, formatDateTime } from '@/utils/format';
import { cn } from '@/utils/cn';

const STATUS_VARIANT: Record<EnquiryStatus, string> = {
  NEW: 'info', FOLLOWUP: 'warning', QUOTED: 'primary', WON: 'success', LOST: 'danger', CANCELLED: 'neutral',
};

const FOLLOWUP_MODES = ['Phone', 'Email', 'WhatsApp', 'Meeting', 'Site Visit'];

function FollowupModal({ enquiryId, onClose }: { enquiryId: string; onClose: () => void }) {
  const qc = useQueryClient();
  const [form, setForm] = useState({ mode: 'Phone', remarks: '', next_followup_date: '' });
  const mut = useMutation({
    mutationFn: () => salesService.addFollowup(enquiryId, form),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['enquiry', enquiryId] }); onClose(); },
  });
  return (
    <Modal open onClose={onClose} title="Add Followup" size="sm">
      <div className="space-y-4 p-4">
        <FormField label="Mode" required>
          <select value={form.mode} onChange={e => setForm(f => ({ ...f, mode: e.target.value }))}
            className="w-full rounded-lg border border-neutral-200 px-3 py-2 text-sm">
            {FOLLOWUP_MODES.map(m => <option key={m}>{m}</option>)}
          </select>
        </FormField>
        <FormField label="Remarks" required>
          <Textarea value={form.remarks} onChange={e => setForm(f => ({ ...f, remarks: e.target.value }))} rows={3} placeholder="Summary of discussion…" />
        </FormField>
        <FormField label="Next Followup Date">
          <Input type="date" value={form.next_followup_date} onChange={e => setForm(f => ({ ...f, next_followup_date: e.target.value }))} />
        </FormField>
        <div className="flex gap-2 justify-end pt-1">
          <Button variant="ghost" onClick={onClose}>Cancel</Button>
          <Button onClick={() => mut.mutate()} loading={mut.isPending} disabled={!form.remarks.trim()}>Save Followup</Button>
        </div>
      </div>
    </Modal>
  );
}

export default function EnquiryFormPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const isNew = !id;
  const [showFollowup, setShowFollowup] = useState(false);

  const [form, setForm] = useState({
    customer_name: '', item_description: '', quantity: '', estimated_value: '',
    enquiry_date: new Date().toISOString().slice(0, 10), remarks: '', status: 'NEW' as EnquiryStatus,
  });

  const { data: enquiry, isLoading } = useQuery({
    queryKey: ['enquiry', id],
    queryFn: () => salesService.getEnquiry(id!),
    enabled: !isNew,
  });

  useEffect(() => {
    if (enquiry) {
      setForm({
        customer_name: enquiry.customer_name,
        item_description: enquiry.item_description,
        quantity: enquiry.quantity,
        estimated_value: enquiry.estimated_value ?? '',
        enquiry_date: enquiry.enquiry_date,
        remarks: enquiry.remarks ?? '',
        status: enquiry.status,
      });
    }
  }, [enquiry]);

  const saveMut = useMutation({
    mutationFn: () => isNew
      ? salesService.createEnquiry(form as any)
      : salesService.updateEnquiry(id!, form as any),
    onSuccess: (e) => {
      qc.invalidateQueries({ queryKey: ['enquiries'] });
      if (isNew) navigate(`/sales/enquiries/${e.id}`);
    },
  });

  const convertMut = useMutation({
    mutationFn: () => salesService.convertToQuotation(id!),
    onSuccess: (q) => navigate(`/sales/quotations/${q.id}`),
  });

  if (!isNew && isLoading) return <div className="flex items-center justify-center h-64"><LoadingSpinner size="xl" /></div>;

  const f = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) =>
    setForm(prev => ({ ...prev, [k]: e.target.value }));

  return (
    <div className="space-y-4">
      <PageHeader
        title={isNew ? 'New Enquiry' : `Enquiry — ${enquiry?.enquiry_number}`}
        subtitle={isNew ? 'Record a new customer enquiry' : enquiry?.customer_name}
        breadcrumbs={[{ label: 'Sales' }, { label: 'Enquiries', href: '/sales/enquiries' }, { label: isNew ? 'New' : enquiry?.enquiry_number ?? '' }]}
        actions={!isNew ? (
          <div className="flex gap-2">
            <Button variant="ghost" size="sm" onClick={() => setShowFollowup(true)}>
              <PlusIcon className="h-4 w-4 mr-1" /> Add Followup
            </Button>
            {enquiry?.status !== 'QUOTED' && enquiry?.status !== 'WON' && enquiry?.status !== 'CANCELLED' && (
              <Button size="sm" onClick={() => convertMut.mutate()} loading={convertMut.isPending}>
                <ArrowRightIcon className="h-4 w-4 mr-1" /> Convert to Quotation
              </Button>
            )}
            {enquiry?.quotation_number && (
              <Button variant="secondary" size="sm" onClick={() => navigate(`/sales/quotations/${enquiry.quotation_id}`)}>
                View Quotation {enquiry.quotation_number}
              </Button>
            )}
          </div>
        ) : undefined}
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="lg:col-span-2">
          <div className="p-4 space-y-4">
            <h3 className="text-sm font-semibold text-neutral-700">Enquiry Details</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <FormField label="Customer Name" required>
                <Input value={form.customer_name} onChange={f('customer_name')} placeholder="Customer name…" />
              </FormField>
              <FormField label="Enquiry Date" required>
                <Input type="date" value={form.enquiry_date} onChange={f('enquiry_date')} />
              </FormField>
              <FormField label="Item / Description" required className="sm:col-span-2">
                <Input value={form.item_description} onChange={f('item_description')} placeholder="What is the customer enquiring about?" />
              </FormField>
              <FormField label="Quantity">
                <Input value={form.quantity} onChange={f('quantity')} placeholder="e.g. 5000 kg" />
              </FormField>
              <FormField label="Estimated Value (₹)">
                <Input type="number" value={form.estimated_value} onChange={f('estimated_value')} placeholder="0.00" />
              </FormField>
              {!isNew && (
                <FormField label="Status">
                  <select value={form.status} onChange={f('status')}
                    className="w-full rounded-lg border border-neutral-200 px-3 py-2 text-sm">
                    {(['NEW', 'FOLLOWUP', 'QUOTED', 'WON', 'LOST', 'CANCELLED'] as EnquiryStatus[]).map(s =>
                      <option key={s} value={s}>{s}</option>
                    )}
                  </select>
                </FormField>
              )}
              <FormField label="Remarks" className="sm:col-span-2">
                <Textarea value={form.remarks} onChange={f('remarks')} rows={3} placeholder="Additional notes…" />
              </FormField>
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <Button variant="ghost" onClick={() => navigate('/sales/enquiries')}>Cancel</Button>
              <Button onClick={() => saveMut.mutate()} loading={saveMut.isPending}>
                {isNew ? 'Create Enquiry' : 'Save Changes'}
              </Button>
            </div>
          </div>
        </Card>

        {/* Followup log */}
        {!isNew && (
          <Card>
            <div className="p-4">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-semibold text-neutral-700">Followup Log</h3>
                <button onClick={() => setShowFollowup(true)}
                  className="text-xs text-primary-600 hover:text-primary-800 font-medium">
                  + Add
                </button>
              </div>
              {!enquiry?.followups?.length
                ? <p className="text-xs text-neutral-400 text-center py-6">No followups recorded.</p>
                : (
                  <div className="space-y-3 max-h-96 overflow-y-auto">
                    {[...enquiry.followups].reverse().map(fu => (
                      <div key={fu.id} className="border-l-2 border-primary-200 pl-3 py-1">
                        <div className="flex items-center gap-2 mb-0.5">
                          <span className="text-xs font-semibold text-primary-700">{fu.mode}</span>
                          <span className="text-xs text-neutral-400">{formatDate(fu.date)}</span>
                        </div>
                        <p className="text-xs text-neutral-700">{fu.remarks}</p>
                        {fu.next_followup_date && (
                          <p className="text-xs text-neutral-400 mt-1">Next: {formatDate(fu.next_followup_date)}</p>
                        )}
                        <p className="text-xs text-neutral-300 mt-0.5">— {fu.created_by_name}</p>
                      </div>
                    ))}
                  </div>
                )}
            </div>
          </Card>
        )}
      </div>

      {showFollowup && id && <FollowupModal enquiryId={id} onClose={() => setShowFollowup(false)} />}
    </div>
  );
}
