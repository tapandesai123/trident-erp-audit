import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { createColumnHelper } from '@tanstack/react-table';
import { PlusIcon, FunnelIcon } from '@heroicons/react/24/outline';

import { salesService, EnquiryListItem, EnquiryStatus } from '@/services/sales';
import DataTable from '@/components/ui/DataTable';
import Badge from '@/components/ui/Badge';
import Button from '@/components/ui/Button';
import PageHeader from '@/components/ui/PageHeader';
import Tabs from '@/components/ui/Tabs';
import FilterPanel, { FilterSection, FilterRadioGroup } from '@/components/ui/FilterPanel';
import { usePagination } from '@/hooks/usePagination';
import { useDebounce } from '@/hooks/useDebounce';
import { formatDate, formatCurrency } from '@/utils/format';
import { cn } from '@/utils/cn';

const col = createColumnHelper<EnquiryListItem>();

const STATUS_VARIANT: Record<EnquiryStatus, 'success' | 'danger' | 'warning' | 'neutral' | 'primary' | 'info'> = {
  NEW: 'info', FOLLOWUP: 'warning', QUOTED: 'primary', WON: 'success', LOST: 'danger', CANCELLED: 'neutral',
};

const COLUMNS = [
  col.accessor('enquiry_number', {
    header: 'Enquiry #',
    cell: i => <span className="font-mono text-xs font-semibold text-primary-800">{i.getValue()}</span>,
    size: 140,
  }),
  col.accessor('customer_name', {
    header: 'Customer',
    cell: i => <span className="text-sm font-medium text-neutral-800">{i.getValue()}</span>,
    size: 180,
  }),
  col.accessor('item_description', {
    header: 'Item / Description',
    cell: i => <span className="text-sm text-neutral-600 line-clamp-1">{i.getValue()}</span>,
  }),
  col.accessor('quantity', {
    header: 'Qty',
    size: 80,
    cell: i => <span className="text-sm font-semibold">{i.getValue()}</span>,
  }),
  col.accessor('estimated_value', {
    header: 'Est. Value',
    cell: i => <span className="text-sm">{i.getValue() ? formatCurrency(i.getValue()!) : '—'}</span>,
    size: 120,
  }),
  col.accessor('enquiry_date', {
    header: 'Date',
    cell: i => formatDate(i.getValue()),
    size: 100,
  }),
  col.accessor('next_followup_date', {
    header: 'Next Followup',
    cell: i => {
      const val = i.getValue();
      if (!val) return <span className="text-neutral-300">—</span>;
      const isOverdue = new Date(val) < new Date();
      return <span className={cn('text-sm', isOverdue ? 'text-danger-600 font-semibold' : '')}>{formatDate(val)}</span>;
    },
    size: 120,
  }),
  col.accessor('assigned_to_name', {
    header: 'Assigned To',
    size: 130,
  }),
  col.accessor('status', {
    header: 'Status',
    cell: i => <Badge variant={STATUS_VARIANT[i.getValue()] as any}>{i.getValue()}</Badge>,
    size: 100,
  }),
];

const TABS = [
  { key: 'ALL', label: 'All' },
  { key: 'NEW', label: 'New' },
  { key: 'FOLLOWUP', label: 'Follow-up' },
  { key: 'QUOTED', label: 'Quoted' },
  { key: 'WON', label: 'Won' },
  { key: 'LOST', label: 'Lost' },
];

export default function EnquiryListPage() {
  const navigate = useNavigate();
  const { page, pageSize, setPage, setPageSize } = usePagination();
  const [search, setSearch] = useState('');
  const dSearch = useDebounce(search, 300);
  const [tab, setTab] = useState('ALL');
  const [filterOpen, setFilterOpen] = useState(false);
  const [assigned, setAssigned] = useState('');

  const { data, isLoading } = useQuery({
    queryKey: ['enquiries', page, pageSize, dSearch, tab, assigned],
    queryFn: () => salesService.listEnquiries({
      page, page_size: pageSize,
      search: dSearch || undefined,
      status: tab === 'ALL' ? undefined : tab,
      assigned_to: assigned || undefined,
    }),
  });

  return (
    <div className="space-y-4">
      <PageHeader
        title="Enquiries"
        subtitle="Manage customer enquiries and follow-ups"
        actions={
          <Button onClick={() => navigate('/sales/enquiries/new')}>
            <PlusIcon className="h-4 w-4 mr-1" /> New Enquiry
          </Button>
        }
      />
      <Tabs tabs={TABS} active={tab} onChange={k => { setTab(k); setPage(1); }} />
      <div className="flex gap-4">
        <div className="flex-1 min-w-0">
          <DataTable
            data={data?.results ?? []}
            columns={COLUMNS}
            loading={isLoading}
            totalCount={data?.count}
            page={page}
            pageSize={pageSize}
            onPageChange={setPage}
            onPageSizeChange={setPageSize}
            searchValue={search}
            onSearchChange={setSearch}
            searchPlaceholder="Search enquiry, customer, item…"
            onRowClick={row => navigate(`/sales/enquiries/${row.id}`)}
            toolbarLeft={
              <button
                onClick={() => setFilterOpen(o => !o)}
                className={cn(
                  'inline-flex items-center gap-1.5 px-3 py-1.5 text-sm rounded-lg border transition-colors',
                  filterOpen ? 'bg-primary-50 border-primary-300 text-primary-700' : 'bg-white border-neutral-200 text-neutral-600 hover:bg-neutral-50'
                )}
              >
                <FunnelIcon className="h-4 w-4" /> Filters
              </button>
            }
            emptyTitle="No enquiries found"
          />
        </div>
        <FilterPanel open={filterOpen} onClose={() => setFilterOpen(false)} onReset={() => setAssigned('')} activeCount={assigned ? 1 : 0}>
          <FilterSection label="Assigned To">
            <FilterRadioGroup name="assigned" value={assigned} onChange={setAssigned}
              options={[{ value: '', label: 'All' }, { value: 'me', label: 'Me' }]} />
          </FilterSection>
        </FilterPanel>
      </div>
    </div>
  );
}
