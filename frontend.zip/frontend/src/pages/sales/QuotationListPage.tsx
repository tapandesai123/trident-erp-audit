import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { createColumnHelper } from '@tanstack/react-table';
import { FunnelIcon } from '@heroicons/react/24/outline';

import { salesService, QuotationListItem, QuotationStatus } from '@/services/sales';
import DataTable from '@/components/ui/DataTable';
import Badge from '@/components/ui/Badge';
import Button from '@/components/ui/Button';
import PageHeader from '@/components/ui/PageHeader';
import Tabs from '@/components/ui/Tabs';
import FilterPanel, { FilterSection, FilterRadioGroup } from '@/components/ui/FilterPanel';
import { usePagination } from '@/hooks/usePagination';
import { useDebounce } from '@/hooks/useDebounce';
import { formatDate, formatCurrency } from '@/utils/format';
import { cn } from '@/utils/cn';

const col = createColumnHelper<QuotationListItem>();

const STATUS_VARIANT: Record<QuotationStatus, string> = {
  DRAFT: 'neutral', SENT: 'info', APPROVED: 'success', REVISED: 'warning',
  REJECTED: 'danger', CONVERTED: 'primary',
};

const COLUMNS = [
  col.accessor('quotation_number', {
    header: 'Quotation #',
    cell: i => (
      <div>
        <span className="font-mono text-xs font-semibold text-primary-800">{i.getValue()}</span>
        {i.row.original.revision > 0 && (
          <span className="ml-1 text-xs text-warning-600 font-medium">Rev {i.row.original.revision}</span>
        )}
      </div>
    ),
    size: 160,
  }),
  col.accessor('customer_name', { header: 'Customer', size: 180 }),
  col.accessor('enquiry_number', {
    header: 'Enquiry',
    cell: i => i.getValue()
      ? <span className="font-mono text-xs text-neutral-500">{i.getValue()}</span>
      : <span className="text-neutral-300">—</span>,
    size: 130,
  }),
  col.accessor('quotation_date', { header: 'Date', cell: i => formatDate(i.getValue()), size: 100 }),
  col.accessor('valid_until', {
    header: 'Valid Until',
    cell: i => {
      const val = i.getValue();
      if (!val) return <span className="text-neutral-300">—</span>;
      const expired = new Date(val) < new Date() && i.row.original.status !== 'CONVERTED';
      return <span className={cn('text-sm', expired ? 'text-danger-600 font-semibold' : '')}>{formatDate(val)}</span>;
    },
    size: 110,
  }),
  col.accessor('total_amount', {
    header: 'Total',
    cell: i => <span className="font-semibold text-sm">{formatCurrency(i.getValue())}</span>,
    size: 130,
  }),
  col.accessor('status', {
    header: 'Status',
    cell: i => <Badge variant={STATUS_VARIANT[i.getValue()] as any}>{i.getValue()}</Badge>,
    size: 100,
  }),
];

const TABS = [
  { key: 'ALL', label: 'All' },
  { key: 'DRAFT', label: 'Draft' },
  { key: 'SENT', label: 'Sent' },
  { key: 'APPROVED', label: 'Approved' },
  { key: 'REVISED', label: 'Revised' },
];

export default function QuotationListPage() {
  const navigate = useNavigate();
  const { page, pageSize, setPage, setPageSize } = usePagination();
  const [search, setSearch] = useState('');
  const dSearch = useDebounce(search, 300);
  const [tab, setTab] = useState('ALL');
  const [filterOpen, setFilterOpen] = useState(false);
  const [currency, setCurrency] = useState('');

  const { data, isLoading } = useQuery({
    queryKey: ['quotations', page, pageSize, dSearch, tab, currency],
    queryFn: () => salesService.listQuotations({
      page, page_size: pageSize,
      search: dSearch || undefined,
      status: tab === 'ALL' ? undefined : tab,
      currency: currency || undefined,
    }),
  });

  return (
    <div className="space-y-4">
      <PageHeader title="Quotations" subtitle="Manage customer quotations and revisions" />
      <Tabs tabs={TABS} active={tab} onChange={k => { setTab(k); setPage(1); }} />
      <div className="flex gap-4">
        <div className="flex-1 min-w-0">
          <DataTable
            data={data?.results ?? []}
            columns={COLUMNS}
            loading={isLoading}
            totalCount={data?.count}
            page={page} pageSize={pageSize}
            onPageChange={setPage} onPageSizeChange={setPageSize}
            searchValue={search} onSearchChange={setSearch}
            searchPlaceholder="Search quotation, customer…"
            onRowClick={row => navigate(`/sales/quotations/${row.id}`)}
            toolbarLeft={
              <button onClick={() => setFilterOpen(o => !o)}
                className={cn('inline-flex items-center gap-1.5 px-3 py-1.5 text-sm rounded-lg border transition-colors',
                  filterOpen ? 'bg-primary-50 border-primary-300 text-primary-700' : 'bg-white border-neutral-200 text-neutral-600 hover:bg-neutral-50')}>
                <FunnelIcon className="h-4 w-4" /> Filters
              </button>
            }
            emptyTitle="No quotations found"
          />
        </div>
        <FilterPanel open={filterOpen} onClose={() => setFilterOpen(false)} onReset={() => setCurrency('')} activeCount={currency ? 1 : 0}>
          <FilterSection label="Currency">
            <FilterRadioGroup name="currency" value={currency} onChange={setCurrency}
              options={[{ value: '', label: 'All' }, { value: 'INR', label: 'INR' }, { value: 'USD', label: 'USD' }, { value: 'EUR', label: 'EUR' }]} />
          </FilterSection>
        </FilterPanel>
      </div>
    </div>
  );
}
