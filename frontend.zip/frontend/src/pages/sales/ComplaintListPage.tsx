import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { createColumnHelper } from '@tanstack/react-table';
import { PlusIcon, FunnelIcon } from '@heroicons/react/24/outline';

import { salesService, ComplaintListItem, ComplaintSeverity, ComplaintStatus } from '@/services/sales';
import DataTable from '@/components/ui/DataTable';
import Badge from '@/components/ui/Badge';
import Button from '@/components/ui/Button';
import PageHeader from '@/components/ui/PageHeader';
import Tabs from '@/components/ui/Tabs';
import FilterPanel, { FilterSection, FilterRadioGroup } from '@/components/ui/FilterPanel';
import { usePagination } from '@/hooks/usePagination';
import { useDebounce } from '@/hooks/useDebounce';
import { formatDate } from '@/utils/format';
import { cn } from '@/utils/cn';

const col = createColumnHelper<ComplaintListItem>();

const SEVERITY_VARIANT: Record<ComplaintSeverity, string> = {
  LOW: 'neutral', MEDIUM: 'warning', HIGH: 'danger', CRITICAL: 'danger',
};

const SEVERITY_CLASSES: Record<ComplaintSeverity, string> = {
  LOW: 'bg-neutral-100 text-neutral-600 border border-neutral-200',
  MEDIUM: 'bg-warning-50 text-warning-700 border border-warning-200',
  HIGH: 'bg-danger-50 text-danger-600 border border-danger-200',
  CRITICAL: 'bg-danger-100 text-danger-800 border border-danger-400 font-bold',
};

const STATUS_VARIANT: Record<ComplaintStatus, string> = {
  OPEN: 'warning', INVESTIGATING: 'info', RESOLVED: 'success', CLOSED: 'neutral',
};

const COLUMNS = [
  col.accessor('complaint_number', {
    header: 'Complaint #',
    cell: i => <span className="font-mono text-xs font-semibold text-primary-800">{i.getValue()}</span>,
    size: 140,
  }),
  col.accessor('customer_name', { header: 'Customer', size: 160 }),
  col.accessor('subject', {
    header: 'Subject',
    cell: i => <span className="text-sm text-neutral-700 line-clamp-1">{i.getValue()}</span>,
  }),
  col.accessor('severity', {
    header: 'Severity',
    cell: i => (
      <span className={cn('inline-flex items-center px-2 py-0.5 rounded-full text-xs', SEVERITY_CLASSES[i.getValue()])}>
        {i.getValue()}
      </span>
    ),
    size: 90,
  }),
  col.accessor('received_date', { header: 'Received', cell: i => formatDate(i.getValue()), size: 100 }),
  col.accessor('resolved_date', {
    header: 'Resolved',
    cell: i => i.getValue() ? formatDate(i.getValue()!) : <span className="text-neutral-300">—</span>,
    size: 100,
  }),
  col.accessor('assigned_to_name', {
    header: 'Assigned To',
    cell: i => i.getValue() ?? <span className="text-neutral-300">—</span>,
    size: 130,
  }),
  col.accessor('capa_number', {
    header: 'CAPA',
    cell: i => i.getValue()
      ? <span className="font-mono text-xs text-primary-600">{i.getValue()}</span>
      : <span className="text-neutral-300">—</span>,
    size: 100,
  }),
  col.accessor('status', {
    header: 'Status',
    cell: i => <Badge variant={STATUS_VARIANT[i.getValue()] as any}>{i.getValue()}</Badge>,
    size: 110,
  }),
];

const TABS = [
  { key: 'ALL', label: 'All' },
  { key: 'OPEN', label: 'Open' },
  { key: 'INVESTIGATING', label: 'Investigating' },
  { key: 'RESOLVED', label: 'Resolved' },
  { key: 'CLOSED', label: 'Closed' },
];

export default function ComplaintListPage() {
  const navigate = useNavigate();
  const { page, pageSize, setPage, setPageSize } = usePagination();
  const [search, setSearch] = useState('');
  const dSearch = useDebounce(search, 300);
  const [tab, setTab] = useState('ALL');
  const [filterOpen, setFilterOpen] = useState(false);
  const [severity, setSeverity] = useState('');

  const { data, isLoading } = useQuery({
    queryKey: ['complaints', page, pageSize, dSearch, tab, severity],
    queryFn: () => salesService.listComplaints({
      page, page_size: pageSize,
      search: dSearch || undefined,
      status: tab === 'ALL' ? undefined : tab,
      severity: severity || undefined,
    }),
  });

  return (
    <div className="space-y-4">
      <PageHeader
        title="Customer Complaints"
        subtitle="Manage and resolve customer complaints"
        actions={
          <Button onClick={() => navigate('/sales/complaints/new')}>
            <PlusIcon className="h-4 w-4 mr-1" /> New Complaint
          </Button>
        }
      />
      <Tabs tabs={TABS} active={tab} onChange={k => { setTab(k); setPage(1); }} />
      <div className="flex gap-4">
        <div className="flex-1 min-w-0">
          <DataTable
            data={data?.results ?? []}
            columns={COLUMNS}
            loading={isLoading}
            totalCount={data?.count}
            page={page} pageSize={pageSize}
            onPageChange={setPage} onPageSizeChange={setPageSize}
            searchValue={search} onSearchChange={setSearch}
            searchPlaceholder="Search complaint, customer…"
            onRowClick={row => navigate(`/sales/complaints/${row.id}`)}
            toolbarLeft={
              <button onClick={() => setFilterOpen(o => !o)}
                className={cn('inline-flex items-center gap-1.5 px-3 py-1.5 text-sm rounded-lg border transition-colors',
                  filterOpen || severity ? 'bg-primary-50 border-primary-300 text-primary-700' : 'bg-white border-neutral-200 text-neutral-600 hover:bg-neutral-50')}>
                <FunnelIcon className="h-4 w-4" /> Filters {severity && <span className="h-4 w-4 bg-primary-700 text-white text-[10px] font-bold rounded-full flex items-center justify-center">1</span>}
              </button>
            }
            emptyTitle="No complaints found"
          />
        </div>
        <FilterPanel open={filterOpen} onClose={() => setFilterOpen(false)} onReset={() => setSeverity('')} activeCount={severity ? 1 : 0}>
          <FilterSection label="Severity">
            <FilterRadioGroup name="severity" value={severity} onChange={setSeverity}
              options={[
                { value: '', label: 'All' },
                { value: 'CRITICAL', label: 'Critical' },
                { value: 'HIGH', label: 'High' },
                { value: 'MEDIUM', label: 'Medium' },
                { value: 'LOW', label: 'Low' },
              ]} />
          </FilterSection>
        </FilterPanel>
      </div>
    </div>
  );
}
