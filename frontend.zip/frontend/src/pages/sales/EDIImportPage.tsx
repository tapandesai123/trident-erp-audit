/**
 * EDI Import Page — Task 21
 * /sales/edi-import
 *
 * Tabs:
 *   Upload  — select platform + file → POST → poll for result
 *   History — list of past batches
 */
import { useCallback, useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  ArrowUpTrayIcon,
  ClockIcon,
  CheckCircleIcon,
  XCircleIcon,
  ArrowDownTrayIcon,
  ArrowPathIcon,
  DocumentTextIcon,
} from '@heroicons/react/24/outline';
import api from '@/services/api';

// ─── Types ────────────────────────────────────────────────────────────────────

interface EDIBatch {
  id: number;
  uuid: string;
  platform: 'AMAZON' | 'FLIPKART' | 'MANUAL';
  status: 'PENDING' | 'PROCESSING' | 'COMPLETED' | 'FAILED';
  total_rows: number;
  success_rows: number;
  failed_rows: number;
  success_rate: number;
  error_log: { row: number; error: string }[];
  created_so_count?: number;
  uploaded_by_username: string;
  created_at: string;
}

// ─── API helpers ──────────────────────────────────────────────────────────────

const ediApi = {
  upload:    (form: FormData)    => api.post<{ batch_id: number; status: string }>('/api/v1/edi/upload/', form),
  batches:   ()                  => api.get<EDIBatch[]>('/api/v1/edi/batches/').then(r => r.data),
  batch:     (id: number)        => api.get<EDIBatch>(`/api/v1/edi/batches/${id}/`).then(r => r.data),
  errorUrl:  (id: number)        => `/api/v1/edi/batches/${id}/error-report/`,
};

// ─── Status badge ─────────────────────────────────────────────────────────────

const STATUS_STYLE: Record<string, string> = {
  PENDING:    'bg-neutral-100 text-neutral-600',
  PROCESSING: 'bg-blue-100 text-blue-700 animate-pulse',
  COMPLETED:  'bg-green-100 text-green-700',
  FAILED:     'bg-red-100 text-red-700',
};
const STATUS_ICON: Record<string, JSX.Element> = {
  PENDING:    <ClockIcon className="h-3.5 w-3.5" />,
  PROCESSING: <ArrowPathIcon className="h-3.5 w-3.5 animate-spin" />,
  COMPLETED:  <CheckCircleIcon className="h-3.5 w-3.5" />,
  FAILED:     <XCircleIcon className="h-3.5 w-3.5" />,
};

function StatusBadge({ status }: { status: string }) {
  return (
    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${STATUS_STYLE[status] || 'bg-neutral-100 text-neutral-500'}`}>
      {STATUS_ICON[status]}
      {status}
    </span>
  );
}

// ─── Upload Tab ───────────────────────────────────────────────────────────────

function UploadTab() {
  const [platform, setPlatform]       = useState<string>('AMAZON');
  const [file, setFile]               = useState<File | null>(null);
  const [activeBatchId, setActiveBatchId] = useState<number | null>(null);
  const [polling, setPolling]         = useState(false);
  const intervalRef                   = useRef<ReturnType<typeof setInterval> | null>(null);
  const qc                            = useQueryClient();

  // Poll for batch status while PROCESSING
  const { data: activeBatch } = useQuery({
    queryKey: ['edi-batch', activeBatchId],
    queryFn:  () => ediApi.batch(activeBatchId!),
    enabled:  !!activeBatchId && polling,
    refetchInterval: polling ? 3000 : false,
  });

  useEffect(() => {
    if (activeBatch && !['PROCESSING', 'PENDING'].includes(activeBatch.status)) {
      setPolling(false);
      qc.invalidateQueries({ queryKey: ['edi-batches'] });
    }
  }, [activeBatch, qc]);

  const uploadMutation = useMutation({
    mutationFn: (form: FormData) => ediApi.upload(form),
    onSuccess: (res) => {
      const batchId = res.data.batch_id;
      setActiveBatchId(batchId);
      setPolling(true);
      setFile(null);
    },
  });

  const handleUpload = () => {
    if (!file) return;
    const form = new FormData();
    form.append('platform', platform);
    form.append('file', file);
    uploadMutation.mutate(form);
  };

  const isRunning = activeBatch && ['PENDING', 'PROCESSING'].includes(activeBatch.status);

  return (
    <div className="space-y-6 max-w-2xl">
      {/* Form card */}
      <div className="card p-6 space-y-5">
        <div>
          <label className="label mb-1">Platform</label>
          <select
            className="input w-full sm:w-64"
            value={platform}
            onChange={e => setPlatform(e.target.value)}
            disabled={uploadMutation.isPending || !!isRunning}
          >
            <option value="AMAZON">Amazon</option>
            <option value="FLIPKART">Flipkart</option>
            <option value="MANUAL">Manual CSV</option>
          </select>
        </div>

        <div>
          <label className="label mb-1">Order File</label>
          <label className={`flex flex-col items-center justify-center border-2 border-dashed rounded-xl p-8 cursor-pointer transition-colors
            ${file ? 'border-primary-400 bg-primary-50' : 'border-neutral-300 hover:border-neutral-400 bg-neutral-50'}`}>
            <ArrowUpTrayIcon className={`h-8 w-8 mb-2 ${file ? 'text-primary-500' : 'text-neutral-400'}`} />
            {file ? (
              <p className="text-sm font-medium text-primary-700">{file.name}</p>
            ) : (
              <>
                <p className="text-sm font-medium text-neutral-600">Click to browse or drag & drop</p>
                <p className="text-xs text-neutral-400 mt-1">Accepts .xlsx, .xls, .csv</p>
              </>
            )}
            <input
              type="file"
              accept=".xlsx,.xls,.csv"
              className="hidden"
              onChange={e => setFile(e.target.files?.[0] || null)}
              disabled={uploadMutation.isPending || !!isRunning}
            />
          </label>
        </div>

        <div className="flex items-center gap-3">
          <button
            className="btn btn-primary"
            disabled={!file || uploadMutation.isPending || !!isRunning}
            onClick={handleUpload}
          >
            {uploadMutation.isPending ? (
              <><ArrowPathIcon className="h-4 w-4 mr-1.5 animate-spin" />Uploading…</>
            ) : (
              <><ArrowUpTrayIcon className="h-4 w-4 mr-1.5" />Upload & Process</>
            )}
          </button>
          {file && !isRunning && (
            <button className="btn btn-secondary" onClick={() => setFile(null)}>Clear</button>
          )}
        </div>

        {uploadMutation.isError && (
          <p className="text-sm text-red-600 mt-1">
            Upload failed: {(uploadMutation.error as any)?.response?.data?.error || 'Unknown error'}
          </p>
        )}
      </div>

      {/* Column guide */}
      <div className="card p-5">
        <h3 className="text-sm font-semibold text-neutral-700 mb-3 flex items-center gap-1.5">
          <DocumentTextIcon className="h-4 w-4 text-neutral-400" />
          Expected Column Format
        </h3>
        {platform === 'AMAZON' ? (
          <div className="text-xs text-neutral-500 font-mono leading-relaxed">
            Order ID | Order Date | Customer Name | ASIN | SKU | Qty | Ship-by Date | Ship Address | City | State | Pincode
          </div>
        ) : platform === 'FLIPKART' ? (
          <div className="text-xs text-neutral-500 font-mono leading-relaxed">
            Order ID | Order Date | Product Title | FSN | Qty | Customer Name | Ship To | City | State | Pin
          </div>
        ) : (
          <div className="text-xs text-neutral-500 font-mono leading-relaxed">
            Order ID | Order Date | Customer Name | SKU | Qty | City | State | Pincode
          </div>
        )}
      </div>

      {/* Live progress */}
      {activeBatch && (
        <div className="card p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-neutral-700">Processing Status</h3>
            <StatusBadge status={activeBatch.status} />
          </div>

          {isRunning ? (
            <div className="w-full bg-neutral-100 rounded-full h-2">
              <div className="bg-primary-500 h-2 rounded-full animate-pulse w-2/3" />
            </div>
          ) : (
            <>
              <div className="grid grid-cols-3 gap-3 text-center">
                {[
                  ['Total', activeBatch.total_rows, 'text-neutral-700'],
                  ['Success', activeBatch.success_rows, 'text-green-600'],
                  ['Failed', activeBatch.failed_rows, 'text-red-600'],
                ].map(([label, val, cls]) => (
                  <div key={label as string} className="card p-3 bg-neutral-50">
                    <p className={`text-lg font-bold ${cls}`}>{val}</p>
                    <p className="text-xs text-neutral-400">{label}</p>
                  </div>
                ))}
              </div>

              {activeBatch.status === 'COMPLETED' && (
                <p className="text-sm text-green-700 font-medium">
                  ✅ {activeBatch.success_rows} Sales Order{activeBatch.success_rows !== 1 ? 's' : ''} created successfully.
                </p>
              )}

              {activeBatch.failed_rows > 0 && (
                <a
                  href={ediApi.errorUrl(activeBatch.id)}
                  className="inline-flex items-center gap-1.5 text-sm text-red-600 hover:underline"
                >
                  <ArrowDownTrayIcon className="h-4 w-4" />
                  Download Error Report ({activeBatch.failed_rows} rows)
                </a>
              )}

              {activeBatch.error_log?.length > 0 && (
                <div className="mt-2">
                  <p className="text-xs font-medium text-neutral-500 mb-1">Error Preview (first 5):</p>
                  <div className="bg-red-50 rounded-lg p-3 space-y-1 max-h-40 overflow-y-auto">
                    {activeBatch.error_log.slice(0, 5).map((e, i) => (
                      <p key={i} className="text-xs text-red-700 font-mono">
                        Row {e.row}: {e.error}
                      </p>
                    ))}
                    {activeBatch.error_log.length > 5 && (
                      <p className="text-xs text-red-400">…and {activeBatch.error_log.length - 5} more</p>
                    )}
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      )}
    </div>
  );
}

// ─── History Tab ──────────────────────────────────────────────────────────────

function HistoryTab() {
  const [selectedId, setSelectedId] = useState<number | null>(null);

  const { data: batches = [], isLoading } = useQuery({
    queryKey: ['edi-batches'],
    queryFn:  ediApi.batches,
    refetchInterval: 10_000,
  });

  const { data: detail } = useQuery({
    queryKey: ['edi-batch', selectedId],
    queryFn:  () => ediApi.batch(selectedId!),
    enabled:  !!selectedId,
  });

  const PLATFORM_BADGE: Record<string, string> = {
    AMAZON:   'bg-orange-100 text-orange-700',
    FLIPKART: 'bg-yellow-100 text-yellow-700',
    MANUAL:   'bg-neutral-100 text-neutral-600',
  };

  if (isLoading) return (
    <div className="card p-8 text-center text-neutral-400 text-sm">Loading history…</div>
  );

  if (batches.length === 0) return (
    <div className="card p-8 text-center text-neutral-400 text-sm">No uploads yet.</div>
  );

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
      {/* Batch list */}
      <div className="lg:col-span-2 card overflow-hidden">
        <table className="table text-sm">
          <thead>
            <tr>
              <th>Platform</th>
              <th>Date</th>
              <th>Status</th>
              <th className="text-right">Total</th>
              <th className="text-right">OK</th>
              <th className="text-right">Errors</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {batches.map(b => (
              <tr
                key={b.id}
                className={`hover:bg-neutral-50 cursor-pointer ${selectedId === b.id ? 'bg-primary-50' : ''}`}
                onClick={() => setSelectedId(b.id)}
              >
                <td>
                  <span className={`inline-block px-2 py-0.5 rounded text-xs font-medium ${PLATFORM_BADGE[b.platform] || 'bg-neutral-100 text-neutral-500'}`}>
                    {b.platform}
                  </span>
                </td>
                <td className="text-neutral-500 text-xs">
                  {new Date(b.created_at).toLocaleDateString('en-IN', { day:'2-digit', month:'short', year:'numeric' })}
                </td>
                <td><StatusBadge status={b.status} /></td>
                <td className="text-right tabular-nums">{b.total_rows}</td>
                <td className="text-right tabular-nums text-green-600 font-medium">{b.success_rows}</td>
                <td className="text-right tabular-nums text-red-500">{b.failed_rows}</td>
                <td>
                  {b.failed_rows > 0 && (
                    <a
                      href={ediApi.errorUrl(b.id)}
                      title="Download error report"
                      className="text-neutral-400 hover:text-red-500 p-1"
                      onClick={e => e.stopPropagation()}
                    >
                      <ArrowDownTrayIcon className="h-4 w-4" />
                    </a>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Detail panel */}
      {detail ? (
        <div className="card p-4 space-y-3 self-start">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-neutral-800">{detail.platform} Batch</h3>
            <StatusBadge status={detail.status} />
          </div>
          <div className="text-xs text-neutral-500 space-y-1">
            <p>Uploaded by: <span className="font-medium text-neutral-700">{detail.uploaded_by_username || '—'}</span></p>
            <p>Date: <span className="font-medium text-neutral-700">{new Date(detail.created_at).toLocaleString('en-IN')}</span></p>
            <p>SOs Created: <span className="font-medium text-green-700">{detail.created_so_count ?? 0}</span></p>
            <p>Success rate: <span className="font-medium">{detail.success_rate}%</span></p>
          </div>

          {detail.error_log?.length > 0 && (
            <div>
              <p className="text-xs font-medium text-neutral-500 mb-1">Errors ({detail.error_log.length}):</p>
              <div className="bg-red-50 rounded p-2 max-h-52 overflow-y-auto space-y-1">
                {detail.error_log.map((e, i) => (
                  <p key={i} className="text-xs text-red-700 font-mono">Row {e.row}: {e.error}</p>
                ))}
              </div>
              <a href={ediApi.errorUrl(detail.id)}
                className="mt-2 inline-flex items-center gap-1 text-xs text-primary-600 hover:underline">
                <ArrowDownTrayIcon className="h-3.5 w-3.5" />Download full report
              </a>
            </div>
          )}
        </div>
      ) : (
        <div className="card p-6 text-center text-neutral-400 text-xs self-start">
          Click a row to view details
        </div>
      )}
    </div>
  );
}

// ─── Main Page ────────────────────────────────────────────────────────────────

const TABS = [
  { key: 'upload',  label: 'Upload',  icon: ArrowUpTrayIcon },
  { key: 'history', label: 'History', icon: ClockIcon },
];

export default function EDIImportPage() {
  const [activeTab, setActiveTab] = useState<'upload' | 'history'>('upload');

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-neutral-900">EDI Import</h1>
          <p className="text-sm text-neutral-500 mt-0.5">
            Upload Amazon / Flipkart order files to auto-create Sales Orders
          </p>
        </div>
      </div>

      {/* Tabs */}
      <div className="border-b border-neutral-200 flex gap-0">
        {TABS.map(t => {
          const Icon = t.icon;
          return (
            <button
              key={t.key}
              onClick={() => setActiveTab(t.key as any)}
              className={`flex items-center gap-1.5 px-4 py-2.5 text-sm font-medium border-b-2 transition-colors
                ${activeTab === t.key
                  ? 'border-primary-600 text-primary-700'
                  : 'border-transparent text-neutral-500 hover:text-neutral-700 hover:border-neutral-300'
                }`}
            >
              <Icon className="h-4 w-4" />
              {t.label}
            </button>
          );
        })}
      </div>

      {/* Tab content */}
      <div>
        {activeTab === 'upload'  && <UploadTab />}
        {activeTab === 'history' && <HistoryTab />}
      </div>
    </div>
  );
}
