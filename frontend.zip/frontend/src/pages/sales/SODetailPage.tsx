import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  CheckCircleIcon, XCircleIcon, TruckIcon, PaperClipIcon,
  BeakerIcon, ArrowPathIcon,
} from '@heroicons/react/24/outline';
import { CheckCircleIcon as CheckCircleSolid } from '@heroicons/react/24/solid';

import { salesService, SOStatus, ArtworkStatus } from '@/services/sales';
import PageHeader from '@/components/ui/PageHeader';
import Card from '@/components/ui/Card';
import Button from '@/components/ui/Button';
import Badge from '@/components/ui/Badge';
import Modal from '@/components/ui/Modal';
import FormField from '@/components/ui/FormField';
import Textarea from '@/components/ui/Textarea';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import { formatDate, formatCurrency } from '@/utils/format';
import { cn } from '@/utils/cn';

const STATUS_VARIANT: Record<SOStatus, string> = {
  DRAFT: 'neutral', CONFIRMED: 'info', IN_PRODUCTION: 'warning', READY: 'primary',
  PARTIALLY_DISPATCHED: 'warning', DISPATCHED: 'success', CLOSED: 'success', CANCELLED: 'danger',
};

const ARTWORK_VARIANT: Record<ArtworkStatus, string> = {
  PENDING: 'warning', APPROVED: 'success', REJECTED: 'danger',
};

export default function SODetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [cancelModal, setCancelModal] = useState(false);
  const [cancelReason, setCancelReason] = useState('');
  const [showMaterialStatus, setShowMaterialStatus] = useState(false);

  const { data: so, isLoading } = useQuery({
    queryKey: ['sales-order', id],
    queryFn: () => salesService.getSO(id!),
    enabled: !!id,
  });

  // P1 – Material status query (lazy – only fetches when panel is opened)
  const {
    data: materialStatus,
    isLoading: matLoading,
    refetch: refetchMat,
  } = useQuery({
    queryKey: ['so-material-status', id],
    queryFn: () => salesService.getMaterialStatus(id!),
    enabled: showMaterialStatus && !!id,
  });

  const confirm = useMutation({
    mutationFn: () => salesService.confirmSO(id!),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['sales-order', id] }),
  });

  const cancel = useMutation({
    mutationFn: () => salesService.cancelSO(id!, cancelReason),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['sales-order', id] }); setCancelModal(false); },
  });

  const artworkMut = useMutation({
    mutationFn: ({ lineId, status }: { lineId: string; status: ArtworkStatus }) =>
      salesService.updateArtwork(id!, lineId, status),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['sales-order', id] }),
  });

  if (isLoading) return <div className="flex items-center justify-center h-64"><LoadingSpinner size="xl" /></div>;
  if (!so) return null;

  const canConfirm = so.status === 'DRAFT';
  const canCancel = !['CANCELLED', 'CLOSED', 'DISPATCHED'].includes(so.status);
  const canDispatch = ['CONFIRMED', 'IN_PRODUCTION', 'READY', 'PARTIALLY_DISPATCHED'].includes(so.status);
  const showMatBtn = ['CONFIRMED', 'IN_PRODUCTION', 'READY'].includes(so.status);

  return (
    <div className="space-y-4">
      <PageHeader
        title={`SO — ${so.so_number}`}
        subtitle={so.customer_name}
        breadcrumbs={[{ label: 'Sales' }, { label: 'Orders', href: '/sales/orders' }, { label: so.so_number }]}
        actions={
          <div className="flex gap-2 flex-wrap">
            {canConfirm && (
              <Button size="sm" onClick={() => confirm.mutate()} loading={confirm.isPending}>
                <CheckCircleIcon className="h-4 w-4 mr-1" /> Confirm Order
              </Button>
            )}
            {showMatBtn && (
              <Button
                variant={so.material_ready ? 'secondary' : 'secondary'}
                size="sm"
                onClick={() => setShowMaterialStatus(true)}
                className={so.material_ready ? 'border-success-400 text-success-700 bg-success-50 hover:bg-success-100' : ''}
              >
                {so.material_ready
                  ? <><CheckCircleSolid className="h-4 w-4 mr-1 text-success-600" /> Material Ready</>
                  : <><BeakerIcon className="h-4 w-4 mr-1" /> Material Status</>
                }
              </Button>
            )}
            {canDispatch && (
              <Button variant="secondary" size="sm" onClick={() => navigate(`/dispatch/plan?so=${id}`)}>
                <TruckIcon className="h-4 w-4 mr-1" /> Plan Dispatch
              </Button>
            )}
            {canCancel && (
              <Button variant="danger" size="sm" onClick={() => setCancelModal(true)}>
                <XCircleIcon className="h-4 w-4 mr-1" /> Cancel
              </Button>
            )}
          </div>
        }
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Info card */}
        <Card>
          <div className="p-4 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-neutral-700">Order Details</h3>
              <Badge variant={STATUS_VARIANT[so.status] as any}>{so.status.replace('_', ' ')}</Badge>
            </div>
            <div className="space-y-2 text-sm border-t border-neutral-100 pt-3">
              {[
                { label: 'Customer', value: so.customer_name },
                { label: 'Order Date', value: formatDate(so.order_date) },
                { label: 'Delivery Date', value: so.delivery_date ? formatDate(so.delivery_date) : '—' },
                { label: 'Quotation', value: so.quotation_number ?? '—' },
                { label: 'Payment Terms', value: so.payment_terms ?? '—' },
              ].map(({ label, value }) => (
                <div key={label} className="flex justify-between items-start gap-2">
                  <span className="text-neutral-500 shrink-0">{label}</span>
                  <span className="text-neutral-800 text-right text-xs">{value}</span>
                </div>
              ))}
            </div>
            {/* P1 – material ready indicator */}
            {showMatBtn && (
              <div className={cn(
                'border rounded-lg p-3 text-xs flex items-center gap-2',
                so.material_ready
                  ? 'border-success-200 bg-success-50 text-success-800'
                  : 'border-warning-200 bg-warning-50 text-warning-800'
              )}>
                {so.material_ready
                  ? <CheckCircleSolid className="h-4 w-4 text-success-600 shrink-0" />
                  : <BeakerIcon className="h-4 w-4 text-warning-600 shrink-0" />
                }
                <span>
                  {so.material_ready
                    ? `Materials ready${so.material_ready_at ? ` since ${formatDate(so.material_ready_at)}` : ''}`
                    : 'Awaiting material availability check'
                  }
                </span>
              </div>
            )}
            <div className="border-t border-neutral-100 pt-3 space-y-1">
              <div className="flex justify-between text-sm text-neutral-600"><span>Subtotal</span><span>{formatCurrency(so.subtotal)}</span></div>
              <div className="flex justify-between text-sm text-neutral-600"><span>Tax</span><span>{formatCurrency(so.tax_amount)}</span></div>
              <div className="flex justify-between font-bold text-sm border-t border-neutral-100 pt-1"><span>Grand Total</span><span>{formatCurrency(so.grand_total)}</span></div>
            </div>
          </div>
        </Card>

        {/* Lines */}
        <Card className="lg:col-span-2">
          <div className="p-4">
            <h3 className="text-sm font-semibold text-neutral-700 mb-3">Order Lines</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-xs text-neutral-500 border-b border-neutral-100">
                    <th className="py-2 pr-3 text-left font-medium">#</th>
                    <th className="py-2 pr-3 text-left font-medium">Item</th>
                    <th className="py-2 pr-3 text-right font-medium">Ordered</th>
                    <th className="py-2 pr-3 text-right font-medium">Dispatched</th>
                    <th className="py-2 pr-3 text-right font-medium">Pending</th>
                    <th className="py-2 pr-3 text-right font-medium">Amount</th>
                    <th className="py-2 text-center font-medium">Artwork</th>
                  </tr>
                </thead>
                <tbody>
                  {so.lines.map(l => (
                    <tr key={l.id} className="border-b border-neutral-50 hover:bg-neutral-50">
                      <td className="py-2.5 pr-3 text-neutral-400 text-xs">{l.line_number}</td>
                      <td className="py-2.5 pr-3">
                        <p className="font-medium text-neutral-800">{l.item_name}</p>
                        <p className="text-xs text-neutral-400">{l.item_code}</p>
                        {l.required_date && (
                          <p className="text-xs text-neutral-400">Need by: {formatDate(l.required_date)}</p>
                        )}
                      </td>
                      <td className="py-2.5 pr-3 text-right">{l.ordered_qty}</td>
                      <td className="py-2.5 pr-3 text-right text-success-700 font-medium">{l.dispatched_qty}</td>
                      <td className={cn(
                        'py-2.5 pr-3 text-right font-bold',
                        parseFloat(l.pending_qty) > 0 ? 'text-warning-600' : 'text-neutral-400'
                      )}>
                        {l.pending_qty}
                      </td>
                      <td className="py-2.5 pr-3 text-right">{formatCurrency(l.amount)}</td>
                      <td className="py-2.5 text-center">
                        <div className="flex flex-col items-center gap-1">
                          <Badge variant={ARTWORK_VARIANT[l.artwork_status] as any} size="sm">
                            {l.artwork_status}
                          </Badge>
                          {l.artwork_status === 'PENDING' && (
                            <div className="flex gap-1">
                              <button
                                onClick={() => artworkMut.mutate({ lineId: l.id, status: 'APPROVED' })}
                                className="text-[10px] px-1.5 py-0.5 bg-success-100 text-success-700 rounded hover:bg-success-200"
                              >
                                Approve
                              </button>
                              <button
                                onClick={() => artworkMut.mutate({ lineId: l.id, status: 'REJECTED' })}
                                className="text-[10px] px-1.5 py-0.5 bg-danger-100 text-danger-700 rounded hover:bg-danger-200"
                              >
                                Reject
                              </button>
                            </div>
                          )}
                          {l.artwork_file_url && (
                            <a href={l.artwork_file_url} target="_blank" rel="noopener noreferrer"
                              className="text-[10px] text-primary-600 hover:underline flex items-center gap-0.5">
                              <PaperClipIcon className="h-2.5 w-2.5" /> File
                            </a>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </Card>
      </div>

      {/* P1 – Material Status Modal */}
      {showMaterialStatus && (
        <Modal open onClose={() => setShowMaterialStatus(false)} title="Material Availability Status" size="lg">
          <div className="p-4 space-y-4">
            {/* Summary banner */}
            {materialStatus && (
              <div className={cn(
                'flex items-center gap-3 rounded-lg p-3 text-sm font-medium',
                materialStatus.material_ready
                  ? 'bg-success-50 border border-success-200 text-success-800'
                  : 'bg-warning-50 border border-warning-200 text-warning-800'
              )}>
                {materialStatus.material_ready
                  ? <CheckCircleSolid className="h-5 w-5 text-success-600 shrink-0" />
                  : <BeakerIcon className="h-5 w-5 text-warning-600 shrink-0" />
                }
                {materialStatus.material_ready
                  ? 'All materials available — Work Order and Job Cards can be created.'
                  : 'Some materials are short. Production cannot start until shortages are resolved.'
                }
              </div>
            )}

            {matLoading && <div className="flex justify-center py-8"><LoadingSpinner size="lg" /></div>}

            {materialStatus?.lines.map((line, li) => (
              <div key={li} className="border border-neutral-200 rounded-lg overflow-hidden">
                <div className={cn(
                  'px-4 py-2.5 flex items-center justify-between text-sm font-semibold',
                  line.all_materials_ok ? 'bg-success-50 text-success-800' : 'bg-warning-50 text-warning-800'
                )}>
                  <span>Line {line.so_line} — {line.item}</span>
                  <Badge variant={line.all_materials_ok ? 'success' : 'warning'} size="sm">
                    {line.all_materials_ok ? 'All OK' : 'Shortfall'}
                  </Badge>
                </div>
                {line.components.length > 0 && (
                  <table className="w-full text-xs">
                    <thead>
                      <tr className="bg-neutral-50 text-neutral-500">
                        <th className="px-4 py-2 text-left font-medium">Component</th>
                        <th className="px-4 py-2 text-right font-medium">Required</th>
                        <th className="px-4 py-2 text-right font-medium">Available</th>
                        <th className="px-4 py-2 text-right font-medium">Shortage</th>
                        <th className="px-4 py-2 text-center font-medium">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {line.components.map((c, ci) => (
                        <tr key={ci} className="border-t border-neutral-100">
                          <td className="px-4 py-2">
                            <span className="font-medium text-neutral-800">{c.component_code}</span>
                            <span className="ml-2 text-neutral-400">{c.component_name}</span>
                          </td>
                          <td className="px-4 py-2 text-right tabular-nums">{c.required_qty}</td>
                          <td className="px-4 py-2 text-right tabular-nums text-success-700">{c.available_qty}</td>
                          <td className={cn('px-4 py-2 text-right tabular-nums font-semibold',
                            parseFloat(c.shortage) > 0 ? 'text-danger-600' : 'text-neutral-400'
                          )}>
                            {parseFloat(c.shortage) > 0 ? c.shortage : '—'}
                          </td>
                          <td className="px-4 py-2 text-center">
                            <Badge variant={c.status === 'OK' ? 'success' : 'danger'} size="sm">{c.status}</Badge>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
                {line.components.length === 0 && (
                  <p className="px-4 py-3 text-xs text-neutral-400">No BOM components found for this item.</p>
                )}
              </div>
            ))}

            {materialStatus?.lines.length === 0 && !matLoading && (
              <p className="text-sm text-neutral-500 text-center py-4">No BOM data available for this order.</p>
            )}

            <div className="flex justify-end gap-2 pt-2">
              <Button variant="ghost" size="sm" onClick={() => refetchMat()}>
                <ArrowPathIcon className="h-4 w-4 mr-1" /> Refresh
              </Button>
              <Button size="sm" onClick={() => setShowMaterialStatus(false)}>Close</Button>
            </div>
          </div>
        </Modal>
      )}

      {cancelModal && (
        <Modal open onClose={() => setCancelModal(false)} title="Cancel Sales Order" size="sm">
          <div className="p-4 space-y-4">
            <p className="text-sm text-neutral-600">Please provide a reason for cancellation.</p>
            <FormField label="Reason" required>
              <Textarea value={cancelReason} onChange={e => setCancelReason(e.target.value)} rows={3} />
            </FormField>
            <div className="flex gap-2 justify-end">
              <Button variant="ghost" onClick={() => setCancelModal(false)}>Back</Button>
              <Button variant="danger" onClick={() => cancel.mutate()} loading={cancel.isPending} disabled={!cancelReason.trim()}>
                Cancel Order
              </Button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}

import { salesService, SOStatus, ArtworkStatus } from '@/services/sales';
import PageHeader from '@/components/ui/PageHeader';
import Card from '@/components/ui/Card';
import Button from '@/components/ui/Button';
import Badge from '@/components/ui/Badge';
import Modal from '@/components/ui/Modal';
import FormField from '@/components/ui/FormField';
import Textarea from '@/components/ui/Textarea';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import { formatDate, formatCurrency } from '@/utils/format';
import { cn } from '@/utils/cn';

const STATUS_VARIANT: Record<SOStatus, string> = {
  DRAFT: 'neutral', CONFIRMED: 'info', IN_PRODUCTION: 'warning', READY: 'primary',
  PARTIALLY_DISPATCHED: 'warning', DISPATCHED: 'success', CLOSED: 'success', CANCELLED: 'danger',
};

const ARTWORK_VARIANT: Record<ArtworkStatus, string> = {
  PENDING: 'warning', APPROVED: 'success', REJECTED: 'danger',
};

export default function SODetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [cancelModal, setCancelModal] = useState(false);
  const [cancelReason, setCancelReason] = useState('');

  const { data: so, isLoading } = useQuery({
    queryKey: ['sales-order', id],
    queryFn: () => salesService.getSO(id!),
    enabled: !!id,
  });

  const confirm = useMutation({
    mutationFn: () => salesService.confirmSO(id!),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['sales-order', id] }),
  });

  const cancel = useMutation({
    mutationFn: () => salesService.cancelSO(id!, cancelReason),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['sales-order', id] }); setCancelModal(false); },
  });

  const artworkMut = useMutation({
    mutationFn: ({ lineId, status }: { lineId: string; status: ArtworkStatus }) =>
      salesService.updateArtwork(id!, lineId, status),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['sales-order', id] }),
  });

  if (isLoading) return <div className="flex items-center justify-center h-64"><LoadingSpinner size="xl" /></div>;
  if (!so) return null;

  const canConfirm = so.status === 'DRAFT';
  const canCancel = !['CANCELLED', 'CLOSED', 'DISPATCHED'].includes(so.status);
  const canDispatch = ['CONFIRMED', 'IN_PRODUCTION', 'READY', 'PARTIALLY_DISPATCHED'].includes(so.status);

  return (
    <div className="space-y-4">
      <PageHeader
        title={`SO — ${so.so_number}`}
        subtitle={so.customer_name}
        breadcrumbs={[{ label: 'Sales' }, { label: 'Orders', href: '/sales/orders' }, { label: so.so_number }]}
        actions={
          <div className="flex gap-2 flex-wrap">
            {canConfirm && (
              <Button size="sm" onClick={() => confirm.mutate()} loading={confirm.isPending}>
                <CheckCircleIcon className="h-4 w-4 mr-1" /> Confirm Order
              </Button>
            )}
            {canDispatch && (
              <Button variant="secondary" size="sm" onClick={() => navigate(`/dispatch/plan?so=${id}`)}>
                <TruckIcon className="h-4 w-4 mr-1" /> Plan Dispatch
              </Button>
            )}
            {canCancel && (
              <Button variant="danger" size="sm" onClick={() => setCancelModal(true)}>
                <XCircleIcon className="h-4 w-4 mr-1" /> Cancel
              </Button>
            )}
          </div>
        }
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Info card */}
        <Card>
          <div className="p-4 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-neutral-700">Order Details</h3>
              <Badge variant={STATUS_VARIANT[so.status] as any}>{so.status.replace('_', ' ')}</Badge>
            </div>
            <div className="space-y-2 text-sm border-t border-neutral-100 pt-3">
              {[
                { label: 'Customer', value: so.customer_name },
                { label: 'Order Date', value: formatDate(so.order_date) },
                { label: 'Delivery Date', value: so.delivery_date ? formatDate(so.delivery_date) : '—' },
                { label: 'Quotation', value: so.quotation_number ?? '—' },
                { label: 'Payment Terms', value: so.payment_terms ?? '—' },
              ].map(({ label, value }) => (
                <div key={label} className="flex justify-between items-start gap-2">
                  <span className="text-neutral-500 shrink-0">{label}</span>
                  <span className="text-neutral-800 text-right text-xs">{value}</span>
                </div>
              ))}
            </div>
            <div className="border-t border-neutral-100 pt-3 space-y-1">
              <div className="flex justify-between text-sm text-neutral-600"><span>Subtotal</span><span>{formatCurrency(so.subtotal)}</span></div>
              <div className="flex justify-between text-sm text-neutral-600"><span>Tax</span><span>{formatCurrency(so.tax_amount)}</span></div>
              <div className="flex justify-between font-bold text-sm border-t border-neutral-100 pt-1"><span>Grand Total</span><span>{formatCurrency(so.grand_total)}</span></div>
            </div>
          </div>
        </Card>

        {/* Lines */}
        <Card className="lg:col-span-2">
          <div className="p-4">
            <h3 className="text-sm font-semibold text-neutral-700 mb-3">Order Lines</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-xs text-neutral-500 border-b border-neutral-100">
                    <th className="py-2 pr-3 text-left font-medium">#</th>
                    <th className="py-2 pr-3 text-left font-medium">Item</th>
                    <th className="py-2 pr-3 text-right font-medium">Ordered</th>
                    <th className="py-2 pr-3 text-right font-medium">Dispatched</th>
                    <th className="py-2 pr-3 text-right font-medium">Pending</th>
                    <th className="py-2 pr-3 text-right font-medium">Amount</th>
                    <th className="py-2 text-center font-medium">Artwork</th>
                  </tr>
                </thead>
                <tbody>
                  {so.lines.map(l => (
                    <tr key={l.id} className="border-b border-neutral-50 hover:bg-neutral-50">
                      <td className="py-2.5 pr-3 text-neutral-400 text-xs">{l.line_number}</td>
                      <td className="py-2.5 pr-3">
                        <p className="font-medium text-neutral-800">{l.item_name}</p>
                        <p className="text-xs text-neutral-400">{l.item_code}</p>
                        {l.required_date && (
                          <p className="text-xs text-neutral-400">Need by: {formatDate(l.required_date)}</p>
                        )}
                      </td>
                      <td className="py-2.5 pr-3 text-right">{l.ordered_qty}</td>
                      <td className="py-2.5 pr-3 text-right text-success-700 font-medium">{l.dispatched_qty}</td>
                      <td className={cn(
                        'py-2.5 pr-3 text-right font-bold',
                        parseFloat(l.pending_qty) > 0 ? 'text-warning-600' : 'text-neutral-400'
                      )}>
                        {l.pending_qty}
                      </td>
                      <td className="py-2.5 pr-3 text-right">{formatCurrency(l.amount)}</td>
                      <td className="py-2.5 text-center">
                        <div className="flex flex-col items-center gap-1">
                          <Badge variant={ARTWORK_VARIANT[l.artwork_status] as any} size="sm">
                            {l.artwork_status}
                          </Badge>
                          {l.artwork_status === 'PENDING' && (
                            <div className="flex gap-1">
                              <button
                                onClick={() => artworkMut.mutate({ lineId: l.id, status: 'APPROVED' })}
                                className="text-[10px] px-1.5 py-0.5 bg-success-100 text-success-700 rounded hover:bg-success-200"
                              >
                                Approve
                              </button>
                              <button
                                onClick={() => artworkMut.mutate({ lineId: l.id, status: 'REJECTED' })}
                                className="text-[10px] px-1.5 py-0.5 bg-danger-100 text-danger-700 rounded hover:bg-danger-200"
                              >
                                Reject
                              </button>
                            </div>
                          )}
                          {l.artwork_file_url && (
                            <a href={l.artwork_file_url} target="_blank" rel="noopener noreferrer"
                              className="text-[10px] text-primary-600 hover:underline flex items-center gap-0.5">
                              <PaperClipIcon className="h-2.5 w-2.5" /> File
                            </a>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </Card>
      </div>

      {cancelModal && (
        <Modal open onClose={() => setCancelModal(false)} title="Cancel Sales Order" size="sm">
          <div className="p-4 space-y-4">
            <p className="text-sm text-neutral-600">Please provide a reason for cancellation.</p>
            <FormField label="Reason" required>
              <Textarea value={cancelReason} onChange={e => setCancelReason(e.target.value)} rows={3} />
            </FormField>
            <div className="flex gap-2 justify-end">
              <Button variant="ghost" onClick={() => setCancelModal(false)}>Back</Button>
              <Button variant="danger" onClick={() => cancel.mutate()} loading={cancel.isPending} disabled={!cancelReason.trim()}>
                Cancel Order
              </Button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}
