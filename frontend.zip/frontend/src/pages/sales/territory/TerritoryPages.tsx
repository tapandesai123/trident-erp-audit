/**
 * Sales Territory & Performance Pages
 * Task 11 — Part 3.6
 */
import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import api from '@/services/api';

// Service
const territoryService = {
  list: () => api.get('/api/v1/sales/territories/').then(r => r.data),
  get: (id: string) => api.get(`/api/v1/sales/territories/${id}/`).then(r => r.data),
  performance: (params?: Record<string, unknown>) =>
    api.get('/api/v1/sales/salesman-performance/', { params }).then(r => r.data),
  salesmen: (params?: Record<string, unknown>) =>
    api.get('/api/v1/crm/salesmen/', { params }).then(r => r.data),
};

// ─── Territory Dashboard ──────────────────────────────────────────

export function TerritoryDashboardPage() {
  const [selectedRegion, setSelectedRegion] = useState<string | null>(null);
  const [selectedZone, setSelectedZone] = useState<string | null>(null);

  const { data: territories, isLoading } = useQuery({
    queryKey: ['territories'],
    queryFn: () => territoryService.list(),
  });

  const regions = territories?.results ?? territories ?? [];

  // Derive zones from selected region
  const zones = selectedRegion
    ? (regions.find((r: any) => r.id === selectedRegion)?.zones ?? [])
    : [];

  // Derive territories from selected zone
  const territoryList = selectedZone
    ? (zones.find((z: any) => z.id === selectedZone)?.territories ?? [])
    : [];

  if (isLoading) {
    return <div className="flex justify-center py-16"><div className="animate-spin rounded-full h-10 w-10 border-b-2 border-blue-600" /></div>;
  }

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Sales Territories</h1>
          <p className="text-sm text-gray-500 mt-1">RSM → ZSM → TSM hierarchy with customer assignments</p>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-6">
        {/* Regions */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200">
          <div className="px-4 py-3 border-b bg-gray-50 rounded-t-xl">
            <h2 className="font-semibold text-gray-700 text-sm">Regions (RSM Level)</h2>
          </div>
          <div className="divide-y">
            {regions.length === 0 && (
              <p className="text-center py-8 text-gray-400 text-sm">No regions configured</p>
            )}
            {regions.map((region: any) => (
              <div
                key={region.id}
                onClick={() => { setSelectedRegion(region.id); setSelectedZone(null); }}
                className={`px-4 py-3 cursor-pointer hover:bg-blue-50 transition-colors ${
                  selectedRegion === region.id ? 'bg-blue-50 border-l-4 border-l-blue-600' : ''
                }`}
              >
                <p className="font-medium text-sm">{region.name}</p>
                <p className="text-xs text-gray-500 mt-0.5">RSM: {region.rsm_name ?? 'Unassigned'}</p>
                <div className="flex gap-3 mt-1">
                  <span className="text-xs text-gray-400">{region.zone_count ?? 0} zones</span>
                  <span className="text-xs text-blue-600">₹{Number(region.mtd_sales ?? 0).toLocaleString()}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Zones */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200">
          <div className="px-4 py-3 border-b bg-gray-50 rounded-t-xl">
            <h2 className="font-semibold text-gray-700 text-sm">Zones (ZSM Level)</h2>
          </div>
          <div className="divide-y">
            {!selectedRegion && (
              <p className="text-center py-8 text-gray-400 text-sm">Select a region</p>
            )}
            {selectedRegion && zones.length === 0 && (
              <p className="text-center py-8 text-gray-400 text-sm">No zones in this region</p>
            )}
            {zones.map((zone: any) => (
              <div
                key={zone.id}
                onClick={() => setSelectedZone(zone.id)}
                className={`px-4 py-3 cursor-pointer hover:bg-blue-50 transition-colors ${
                  selectedZone === zone.id ? 'bg-blue-50 border-l-4 border-l-blue-600' : ''
                }`}
              >
                <p className="font-medium text-sm">{zone.name}</p>
                <p className="text-xs text-gray-500">ZSM: {zone.zsm_name ?? 'Unassigned'}</p>
                <div className="mt-1.5">
                  <div className="flex justify-between text-xs mb-0.5">
                    <span>Target vs Actual</span>
                    <span>{zone.target_pct ?? 0}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-1.5">
                    <div
                      className={`h-1.5 rounded-full ${(zone.target_pct ?? 0) >= 100 ? 'bg-green-500' : 'bg-blue-500'}`}
                      style={{ width: `${Math.min(zone.target_pct ?? 0, 100)}%` }}
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Territories */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200">
          <div className="px-4 py-3 border-b bg-gray-50 rounded-t-xl">
            <h2 className="font-semibold text-gray-700 text-sm">Territories (TSM Level)</h2>
          </div>
          <div className="divide-y">
            {!selectedZone && (
              <p className="text-center py-8 text-gray-400 text-sm">Select a zone</p>
            )}
            {selectedZone && territoryList.length === 0 && (
              <p className="text-center py-8 text-gray-400 text-sm">No territories in this zone</p>
            )}
            {territoryList.map((terr: any) => (
              <div key={terr.id} className="px-4 py-3">
                <p className="font-medium text-sm">{terr.name}</p>
                <p className="text-xs text-gray-500">TSM: {terr.tsm_name ?? 'Unassigned'}</p>
                <div className="grid grid-cols-2 gap-2 mt-2">
                  <div className="bg-gray-50 rounded p-1.5 text-center">
                    <div className="text-sm font-semibold">{terr.customer_count ?? 0}</div>
                    <div className="text-xs text-gray-400">Customers</div>
                  </div>
                  <div className="bg-blue-50 rounded p-1.5 text-center">
                    <div className="text-sm font-semibold text-blue-700">₹{Number(terr.mtd_sales ?? 0).toLocaleString()}</div>
                    <div className="text-xs text-gray-400">MTD Sales</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Salesman Performance Page ────────────────────────────────────

export function SalesmanPerformancePage() {
  const [filters, setFilters] = useState<Record<string, string>>({});

  const { data, isLoading } = useQuery({
    queryKey: ['salesman-performance', filters],
    queryFn: () => territoryService.performance(filters),
  });

  const salesmen = data?.results ?? data ?? [];

  const exportExcel = () => {
    // Trigger CSV download
    const headers = ['Salesman', 'Region/Zone', 'MTD Orders', 'MTD Collections', 'Pending Orders', 'Last Activity'];
    const rows = salesmen.map((s: any) => [
      s.name, `${s.region}/${s.zone}`, s.mtd_orders, s.mtd_collections, s.pending_orders, s.last_activity
    ]);
    const csv = [headers, ...rows].map(r => r.join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `salesman-performance-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
  };

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Salesman Performance</h1>
          <p className="text-sm text-gray-500 mt-1">MTD orders, collections, and activity tracking</p>
        </div>
        <button onClick={exportExcel}
          className="px-4 py-2 border border-gray-300 rounded-lg text-sm font-medium hover:bg-gray-50">
          ⬇ Export CSV
        </button>
      </div>

      {/* Filters */}
      <div className="flex gap-3 mb-4">
        <input type="text" placeholder="Search salesman..."
          className="border rounded-lg px-3 py-2 text-sm"
          onChange={e => setFilters(f => ({ ...f, search: e.target.value }))} />
        <input type="month" className="border rounded-lg px-3 py-2 text-sm"
          onChange={e => setFilters(f => ({ ...f, month: e.target.value }))} />
      </div>

      {isLoading ? (
        <div className="flex justify-center py-16"><div className="animate-spin rounded-full h-10 w-10 border-b-2 border-blue-600" /></div>
      ) : (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                {['Salesman', 'Region / Zone', 'MTD Orders', 'MTD Collections', 'Pending Orders', 'Last Activity'].map(h => (
                  <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {salesmen.length === 0 && (
                <tr><td colSpan={6} className="text-center py-10 text-gray-400">No data available</td></tr>
              )}
              {salesmen.map((s: any, idx: number) => (
                <tr key={idx} className="hover:bg-gray-50">
                  <td className="px-4 py-3 text-sm font-medium">{s.name}</td>
                  <td className="px-4 py-3 text-sm text-gray-500">{s.region ?? '—'} / {s.zone ?? '—'}</td>
                  <td className="px-4 py-3 text-sm text-right">{s.mtd_orders ?? 0}</td>
                  <td className="px-4 py-3 text-sm text-right">₹{Number(s.mtd_collections ?? 0).toLocaleString()}</td>
                  <td className="px-4 py-3 text-sm text-right">{s.pending_orders ?? 0}</td>
                  <td className="px-4 py-3 text-sm text-gray-500">{s.last_activity ?? '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
