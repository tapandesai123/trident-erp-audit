import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  ArrowLeftIcon,
  ArrowsRightLeftIcon,
  AdjustmentsHorizontalIcon,
  QrCodeIcon,
  PrinterIcon,
  ScaleIcon,
  ExclamationTriangleIcon,
  XCircleIcon,
} from '@heroicons/react/24/outline';

import { storesService } from '@/services/stores';
import PageHeader from '@/components/ui/PageHeader';
import Button from '@/components/ui/Button';
import Badge from '@/components/ui/Badge';
import Card from '@/components/ui/Card';
import Modal from '@/components/ui/Modal';
import FormField from '@/components/ui/FormField';
import Input from '@/components/ui/Input';
import Textarea from '@/components/ui/Textarea';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import { formatDate, formatDateTime } from '@/utils/format';
import { cn } from '@/utils/cn';
import StickerPrintModal from '@/components/stores/StickerPrintModal';
import WeightUpdateModal from '@/components/stores/WeightUpdateModal';

const QC_VARIANT: Record<string, 'success' | 'danger' | 'warning' | 'neutral'> = {
  PASSED: 'success', REJECTED: 'danger', PENDING: 'warning', WAIVED: 'neutral',
};

// ─── FIFO Warning Modal ────────────────────────────────────────────

interface FIFOWarningModalProps {
  olderLotNumber: string;
  olderLotDate: string;
  fifoEnforcement: 'HARD' | 'WARN';
  onCancel: () => void;
  onOverride: (reason: string) => void;
}

function FIFOWarningModal({
  olderLotNumber,
  olderLotDate,
  fifoEnforcement,
  onCancel,
  onOverride,
}: FIFOWarningModalProps) {
  const [overrideReason, setOverrideReason] = useState('');
  const isHard = fifoEnforcement === 'HARD';

  return (
    <Modal open onClose={onCancel} title="FIFO Violation Detected" size="sm">
      <div className="p-4 space-y-4">
        <div className={`flex items-start gap-3 p-3 rounded-lg ${isHard ? 'bg-danger-50 border border-danger-200' : 'bg-warning-50 border border-warning-200'}`}>
          {isHard
            ? <XCircleIcon className="h-6 w-6 text-danger-600 flex-shrink-0 mt-0.5" />
            : <ExclamationTriangleIcon className="h-6 w-6 text-warning-600 flex-shrink-0 mt-0.5" />
          }
          <div>
            <p className={`font-semibold text-sm ${isHard ? 'text-danger-800' : 'text-warning-800'}`}>
              {isHard ? 'FIFO Hard Block' : 'FIFO Warning'}
            </p>
            <p className="text-sm text-neutral-700 mt-1">
              Lot <span className="font-mono font-bold">{olderLotNumber}</span> received on{' '}
              <span className="font-semibold">{olderLotDate}</span> should be issued first.
            </p>
          </div>
        </div>

        {!isHard && (
          <FormField label="Override Reason" required>
            <Textarea
              value={overrideReason}
              onChange={e => setOverrideReason(e.target.value)}
              rows={3}
              placeholder="Provide reason for overriding FIFO order..."
            />
          </FormField>
        )}

        <div className="flex gap-2 justify-end pt-2">
          <Button variant="ghost" onClick={onCancel}>Cancel</Button>
          {!isHard && (
            <Button
              variant="warning"
              onClick={() => onOverride(overrideReason)}
              disabled={!overrideReason.trim()}
            >
              Override (with reason)
            </Button>
          )}
        </div>
      </div>
    </Modal>
  );
}

// ─── Issue Lot Modal ───────────────────────────────────────────────

function IssueLotModal({ lot, onClose }: { lot: any; onClose: () => void }) {
  const qc = useQueryClient();
  const [qty, setQty] = useState('');
  const [fifoWarning, setFifoWarning] = useState<{
    olderLotNumber: string;
    olderLotDate: string;
    enforcement: 'HARD' | 'WARN';
  } | null>(null);
  const [pendingPayload, setPendingPayload] = useState<any>(null);

  const issueMutation = useMutation({
    mutationFn: ({ payload, override }: { payload: any; override?: string }) =>
      storesService.createIssue(payload, override),
    onSuccess: (data: any) => {
      if (data?.fifo_warning) {
        // Warn mode — show warning modal
        setFifoWarning({
          olderLotNumber: data.older_lot_number,
          olderLotDate: data.older_lot_date,
          enforcement: 'WARN',
        });
      } else {
        qc.invalidateQueries({ queryKey: ['lot', lot.id] });
        onClose();
      }
    },
  });

  // First, check FIFO before submitting
  const { data: fifoCheck, isFetching: checkingFifo } = useQuery({
    queryKey: ['fifo-check', lot.id, lot.item_id, lot.plant_id],
    queryFn: () => storesService.checkFifo(lot.id, lot.item_id, lot.plant_id),
    enabled: !!lot.id,
  });

  const handleSubmit = () => {
    if (!qty || parseFloat(qty) <= 0) return;

    const payload = {
      issue_date: new Date().toISOString().slice(0, 10),
      issue_type: 'PRODUCTION',
      from_warehouse: lot.warehouse_id,
      lines: [{ item_id: lot.item_id, lot_id: lot.id, requested_qty: qty }],
    };

    if (fifoCheck?.violated) {
      setFifoWarning({
        olderLotNumber: fifoCheck.older_lot_number,
        olderLotDate: fifoCheck.older_lot_date,
        enforcement: lot.plant_fifo_enforcement || 'WARN',
      });
      setPendingPayload(payload);
    } else {
      issueMutation.mutate({ payload });
    }
  };

  const handleOverride = (reason: string) => {
    if (pendingPayload) {
      issueMutation.mutate({ payload: { ...pendingPayload, override_reason: reason }, override: reason });
      setFifoWarning(null);
    }
  };

  return (
    <>
      <Modal open onClose={onClose} title="Issue Lot" size="sm">
        <div className="space-y-4 p-4">
          <FormField label="Quantity to Issue" required>
            <Input
              type="number"
              value={qty}
              onChange={e => setQty(e.target.value)}
              placeholder={`Max: ${lot.quantity} ${lot.uom_code}`}
            />
          </FormField>
          {checkingFifo && (
            <p className="text-xs text-neutral-400 flex items-center gap-1">
              <LoadingSpinner size="xs" /> Checking FIFO compliance...
            </p>
          )}
          {fifoCheck?.violated && !fifoWarning && (
            <div className="flex items-center gap-2 p-2 bg-warning-50 border border-warning-200 rounded-lg text-xs text-warning-800">
              <ExclamationTriangleIcon className="h-4 w-4 flex-shrink-0" />
              Older lot <span className="font-mono font-bold mx-1">{fifoCheck.older_lot_number}</span> available — FIFO check will be triggered.
            </div>
          )}
          <div className="flex gap-2 justify-end pt-2">
            <Button variant="ghost" onClick={onClose}>Cancel</Button>
            <Button onClick={handleSubmit} loading={issueMutation.isPending} disabled={!qty}>
              Issue
            </Button>
          </div>
        </div>
      </Modal>

      {fifoWarning && (
        <FIFOWarningModal
          olderLotNumber={fifoWarning.olderLotNumber}
          olderLotDate={fifoWarning.olderLotDate}
          fifoEnforcement={fifoWarning.enforcement}
          onCancel={() => { setFifoWarning(null); setPendingPayload(null); }}
          onOverride={handleOverride}
        />
      )}
    </>
  );
}

const LOT_STATUS_VARIANT: Record<string, 'success' | 'danger' | 'warning' | 'neutral'> = {
  AVAILABLE: 'success', QUARANTINE: 'danger', RESERVED: 'warning', CONSUMED: 'neutral',
};

function TransferModal({ lotId, onClose }: { lotId: string; onClose: () => void }) {
  const qc = useQueryClient();
  const [form, setForm] = useState({ target_bin: '', qty: '', remarks: '' });
  const mut = useMutation({
    mutationFn: () => storesService.transferLot(lotId, form),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['lot', lotId] }); onClose(); },
  });
  return (
    <Modal open onClose={onClose} title="Transfer Lot" size="sm">
      <div className="space-y-4 p-4">
        <FormField label="Target Bin" required>
          <Input value={form.target_bin} onChange={e => setForm(f => ({ ...f, target_bin: e.target.value }))} placeholder="e.g. A-01-02" />
        </FormField>
        <FormField label="Quantity">
          <Input type="number" value={form.qty} onChange={e => setForm(f => ({ ...f, qty: e.target.value }))} placeholder="Leave blank for full lot" />
        </FormField>
        <FormField label="Remarks">
          <Textarea value={form.remarks} onChange={e => setForm(f => ({ ...f, remarks: e.target.value }))} rows={2} />
        </FormField>
        <div className="flex gap-2 justify-end pt-2">
          <Button variant="ghost" onClick={onClose}>Cancel</Button>
          <Button onClick={() => mut.mutate()} loading={mut.isPending}>Transfer</Button>
        </div>
      </div>
    </Modal>
  );
}

function AdjustModal({ lotId, onClose }: { lotId: string; onClose: () => void }) {
  const qc = useQueryClient();
  const [form, setForm] = useState({ adjustment_qty: '', reason: '', remarks: '' });
  const REASONS = ['Physical count variance', 'Damaged goods', 'Sample consumed', 'Data entry error', 'Other'];
  const mut = useMutation({
    mutationFn: () => storesService.adjustLot(lotId, form),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['lot', lotId] }); onClose(); },
  });
  return (
    <Modal open onClose={onClose} title="Adjust Quantity" size="sm">
      <div className="space-y-4 p-4">
        <FormField label="Adjustment Qty (+ or -)" required>
          <Input type="number" value={form.adjustment_qty} onChange={e => setForm(f => ({ ...f, adjustment_qty: e.target.value }))} placeholder="e.g. -5 or +10" />
        </FormField>
        <FormField label="Reason" required>
          <select
            value={form.reason}
            onChange={e => setForm(f => ({ ...f, reason: e.target.value }))}
            className="w-full rounded-lg border border-neutral-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary-400"
          >
            <option value="">Select reason…</option>
            {REASONS.map(r => <option key={r} value={r}>{r}</option>)}
          </select>
        </FormField>
        <FormField label="Remarks">
          <Textarea value={form.remarks} onChange={e => setForm(f => ({ ...f, remarks: e.target.value }))} rows={2} />
        </FormField>
        <div className="flex gap-2 justify-end pt-2">
          <Button variant="ghost" onClick={onClose}>Cancel</Button>
          <Button onClick={() => mut.mutate()} loading={mut.isPending} variant="warning">Adjust</Button>
        </div>
      </div>
    </Modal>
  );
}

function QRModal({ lotId, onClose }: { lotId: string; onClose: () => void }) {
  const { data } = useQuery({
    queryKey: ['lot-qr', lotId],
    queryFn: () => storesService.getLotQR(lotId),
  });
  return (
    <Modal open onClose={onClose} title="QR Code" size="sm">
      <div className="flex flex-col items-center gap-4 p-6">
        {data?.qr_url
          ? <img src={data.qr_url} alt="QR Code" className="h-48 w-48 border border-neutral-200 rounded-lg" />
          : <div className="h-48 w-48 bg-neutral-100 rounded-lg flex items-center justify-center"><LoadingSpinner /></div>
        }
        <p className="text-xs font-mono text-neutral-500 text-center break-all">{data?.qr_data}</p>
        <Button variant="ghost" onClick={onClose}>Close</Button>
      </div>
    </Modal>
  );
}

export default function InventoryDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [modal, setModal] = useState<'transfer' | 'adjust' | 'qr' | 'print' | 'weight' | 'issue' | null>(null);

  const { data: lot, isLoading } = useQuery({
    queryKey: ['lot', id],
    queryFn: () => storesService.getLot(id!),
    enabled: !!id,
  });

  if (isLoading) return <div className="flex items-center justify-center h-64"><LoadingSpinner size="xl" /></div>;
  if (!lot) return null;

  return (
    <div className="space-y-4">
      <PageHeader
        title={`Lot ${lot.lot_number}`}
        subtitle={lot.item_name}
        breadcrumbs={[
          { label: 'Stores' },
          { label: 'Inventory', href: '/stores/inventory' },
          { label: lot.lot_number },
        ]}
        actions={
          <div className="flex gap-2 flex-wrap">
            <Button variant="ghost" size="sm" onClick={() => setModal('qr')}>
              <QrCodeIcon className="h-4 w-4 mr-1" /> QR Code
            </Button>
            <Button variant="ghost" size="sm" onClick={() => setModal('print')}>
              <PrinterIcon className="h-4 w-4 mr-1" /> Print Tag
            </Button>
            <Button variant="ghost" size="sm" onClick={() => setModal('weight')}>
              <ScaleIcon className="h-4 w-4 mr-1" /> Update Weight
            </Button>
            <Button variant="secondary" size="sm" onClick={() => setModal('adjust')}>
              <AdjustmentsHorizontalIcon className="h-4 w-4 mr-1" /> Adjust
            </Button>
            <Button variant="warning" size="sm" onClick={() => setModal('issue')}>
              Issue Lot
            </Button>
            <Button size="sm" onClick={() => setModal('transfer')}>
              <ArrowsRightLeftIcon className="h-4 w-4 mr-1" /> Transfer
            </Button>
          </div>
        }
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Lot Info */}
        <Card className="lg:col-span-1">
          <div className="p-4 space-y-3">
            <h3 className="text-sm font-semibold text-neutral-700 border-b border-neutral-100 pb-2">Lot Details</h3>
            {[
              { label: 'Lot Number', value: <span className="font-mono font-semibold">{lot.lot_number}</span> },
              { label: 'Roll Number', value: lot.roll_number || '—' },
              { label: 'Item Code', value: <span className="font-mono">{lot.item_code}</span> },
              { label: 'Quantity', value: `${lot.quantity} ${lot.uom_code}` },
              { label: 'Warehouse', value: lot.warehouse_name },
              { label: 'Bin', value: <span className="font-mono bg-neutral-100 px-1.5 py-0.5 rounded text-xs">{lot.bin_code}</span> },
              { label: 'Status', value: <Badge variant={LOT_STATUS_VARIANT[lot.status] ?? 'neutral'}>{lot.status}</Badge> },
              { label: 'QC Status', value: <Badge variant={QC_VARIANT[lot.qc_status] ?? 'neutral'}>{lot.qc_status}</Badge> },
              { label: 'Age', value: `${lot.age_days} days` },
              { label: 'Received', value: formatDate(lot.received_date) },
              { label: 'MRR', value: lot.mrr_number || '—' },
            ].map(({ label, value }) => (
              <div key={label} className="flex justify-between items-center text-sm">
                <span className="text-neutral-500">{label}</span>
                <span className="text-neutral-800">{value}</span>
              </div>
            ))}
          </div>
        </Card>

        {/* Transaction History */}
        <Card className="lg:col-span-2">
          <div className="p-4">
            <h3 className="text-sm font-semibold text-neutral-700 border-b border-neutral-100 pb-2 mb-3">Transaction History</h3>
            {!lot.transactions?.length
              ? <p className="text-sm text-neutral-400 py-4 text-center">No transactions recorded.</p>
              : (
                <table className="w-full text-sm">
                  <thead>
                    <tr className="text-xs text-neutral-500 border-b border-neutral-100">
                      <th className="py-2 pr-3 text-left font-medium">Date</th>
                      <th className="py-2 pr-3 text-left font-medium">Type</th>
                      <th className="py-2 pr-3 text-left font-medium">Reference</th>
                      <th className="py-2 pr-3 text-right font-medium">Qty In</th>
                      <th className="py-2 pr-3 text-right font-medium">Qty Out</th>
                      <th className="py-2 pr-3 text-left font-medium">By</th>
                    </tr>
                  </thead>
                  <tbody>
                    {lot.transactions.map(t => (
                      <tr key={t.id} className="border-b border-neutral-50 hover:bg-neutral-50">
                        <td className="py-2 pr-3 text-neutral-600">{formatDateTime(t.date)}</td>
                        <td className="py-2 pr-3"><Badge variant="neutral" size="sm">{t.type}</Badge></td>
                        <td className="py-2 pr-3 font-mono text-xs text-neutral-600">{t.reference}</td>
                        <td className="py-2 pr-3 text-right text-success-700 font-medium">{t.qty_in || '—'}</td>
                        <td className="py-2 pr-3 text-right text-danger-600 font-medium">{t.qty_out || '—'}</td>
                        <td className="py-2 pr-3 text-neutral-500">{t.user_name}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
          </div>
        </Card>
      </div>

      {modal === 'transfer' && <TransferModal lotId={id!} onClose={() => setModal(null)} />}
      {modal === 'adjust' && <AdjustModal lotId={id!} onClose={() => setModal(null)} />}
      {modal === 'qr' && <QRModal lotId={id!} onClose={() => setModal(null)} />}
      {modal === 'issue' && lot && (
        <IssueLotModal lot={lot} onClose={() => setModal(null)} />
      )}

      {modal === 'print' && lot && (
        <StickerPrintModal
          lot={{ id: lot.id, lot_number: lot.lot_number, item_code: lot.item_code, item_name: lot.item_name }}
          onClose={() => setModal(null)}
        />
      )}
      {modal === 'weight' && lot && (
        <WeightUpdateModal
          lot={{
            id: lot.id,
            lot_number: lot.lot_number,
            item_code: lot.item_code,
            current_qty: lot.quantity,
            uom_code: lot.uom_code,
          }}
          onSuccess={() => { qc.invalidateQueries({ queryKey: ['lot', id] }); }}
          onClose={() => setModal(null)}
        />
      )}
    </div>
  );
}
