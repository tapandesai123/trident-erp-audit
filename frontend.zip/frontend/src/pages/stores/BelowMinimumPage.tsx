import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { createColumnHelper } from '@tanstack/react-table';
import { PlusIcon, ExclamationTriangleIcon } from '@heroicons/react/24/outline';

import { storesService, BelowMinimumItem } from '@/services/stores';
import DataTable from '@/components/ui/DataTable';
import PageHeader from '@/components/ui/PageHeader';
import Button from '@/components/ui/Button';
import { usePagination } from '@/hooks/usePagination';
import { useDebounce } from '@/hooks/useDebounce';
import { cn } from '@/utils/cn';

const col = createColumnHelper<BelowMinimumItem>();

const COLUMNS = [
  col.accessor('item_code', {
    header: 'Item Code',
    cell: i => <span className="font-mono text-xs font-semibold text-primary-800">{i.getValue()}</span>,
    size: 120,
  }),
  col.accessor('item_name', {
    header: 'Item Name',
    cell: i => (
      <div>
        <p className="text-sm font-medium text-neutral-800">{i.getValue()}</p>
        <p className="text-xs text-neutral-400">{i.row.original.item_group}</p>
      </div>
    ),
  }),
  col.accessor('warehouse_name', {
    header: 'Warehouse',
    size: 130,
  }),
  col.accessor('current_stock', {
    header: 'Current Stock',
    cell: i => (
      <span className="font-semibold text-danger-600">
        {i.getValue()} {i.row.original.uom_code}
      </span>
    ),
    size: 110,
  }),
  col.accessor('min_stock', {
    header: 'Min Stock',
    cell: i => (
      <span className="text-neutral-600">
        {i.getValue()} {i.row.original.uom_code}
      </span>
    ),
    size: 100,
  }),
  col.accessor('shortage', {
    header: 'Shortage',
    cell: i => (
      <span className="font-bold text-danger-700">
        {i.getValue()} {i.row.original.uom_code}
      </span>
    ),
    size: 100,
  }),
  col.accessor('shortage_pct', {
    header: 'Deficit %',
    cell: i => {
      const pct = i.getValue();
      return (
        <div className="flex items-center gap-2">
          <div className="h-1.5 w-16 bg-neutral-200 rounded-full overflow-hidden">
            <div
              className={cn(
                'h-full rounded-full',
                pct >= 80 ? 'bg-danger-500' : pct >= 50 ? 'bg-warning-500' : 'bg-orange-400'
              )}
              style={{ width: `${Math.min(pct, 100)}%` }}
            />
          </div>
          <span className={cn(
            'text-xs font-semibold',
            pct >= 80 ? 'text-danger-600' : pct >= 50 ? 'text-warning-600' : 'text-orange-500'
          )}>
            {pct.toFixed(0)}%
          </span>
        </div>
      );
    },
    size: 130,
  }),
  col.display({
    id: 'action',
    size: 100,
    cell: i => (
      <CreatePRButton item={i.row.original} />
    ),
  }),
];

function CreatePRButton({ item }: { item: BelowMinimumItem }) {
  const navigate = useNavigate();
  return (
    <Button
      size="sm"
      variant="secondary"
      onClick={e => {
        e.stopPropagation();
        navigate(`/purchase/requisitions/new?item=${item.item}&qty=${item.shortage}`);
      }}
    >
      <PlusIcon className="h-3.5 w-3.5 mr-1" /> Create PR
    </Button>
  );
}

export default function BelowMinimumPage() {
  const { page, pageSize, setPage, setPageSize } = usePagination();
  const [search, setSearch] = useState('');
  const debouncedSearch = useDebounce(search, 300);

  const { data, isLoading } = useQuery({
    queryKey: ['below-minimum', page, pageSize, debouncedSearch],
    queryFn: () => storesService.listBelowMinimum({
      page, page_size: pageSize,
      search: debouncedSearch || undefined,
    }),
  });

  return (
    <div className="space-y-4">
      <PageHeader
        title="Below Minimum Stock"
        subtitle="Items that require replenishment"
      />

      {data && data.count > 0 && (
        <div className="flex items-center gap-2 px-4 py-3 bg-danger-50 border border-danger-200 rounded-xl text-sm text-danger-700">
          <ExclamationTriangleIcon className="h-5 w-5 shrink-0" />
          <strong>{data.count} item{data.count !== 1 ? 's' : ''}</strong> below minimum stock threshold.
          Create PRs to reorder.
        </div>
      )}

      <DataTable
        data={data?.results ?? []}
        columns={COLUMNS}
        loading={isLoading}
        totalCount={data?.count}
        page={page}
        pageSize={pageSize}
        onPageChange={setPage}
        onPageSizeChange={setPageSize}
        searchValue={search}
        onSearchChange={setSearch}
        searchPlaceholder="Search item…"
        emptyTitle="All items above minimum stock"
        emptyDescription="No reorder action required at this time."
      />
    </div>
  );
}
