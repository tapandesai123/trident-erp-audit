import { useQuery } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell, PieChart, Pie, Legend,
} from 'recharts';
import {
  CubeIcon,
  ExclamationTriangleIcon,
  ClockIcon,
  CurrencyRupeeIcon,
} from '@heroicons/react/24/outline';

import { storesService } from '@/services/stores';
import PageHeader from '@/components/ui/PageHeader';
import Card from '@/components/ui/Card';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import { formatCurrency } from '@/utils/format';

const COLORS = ['#2563eb', '#7c3aed', '#db2777', '#ea580c', '#65a30d'];
const AGING_COLORS = ['#22c55e', '#f59e0b', '#ef4444', '#7f1d1d'];

function StatCard({
  icon: Icon,
  label,
  value,
  sub,
  color = 'text-primary-600',
  onClick,
}: {
  icon: React.ElementType;
  label: string;
  value: string | number;
  sub?: string;
  color?: string;
  onClick?: () => void;
}) {
  return (
    <Card className={onClick ? 'cursor-pointer hover:shadow-md transition-shadow' : ''} onClick={onClick}>
      <div className="p-5 flex items-start gap-4">
        <div className={`p-2 rounded-xl bg-neutral-50 ${color.replace('text-', 'text-')}`}>
          <Icon className={`h-6 w-6 ${color}`} />
        </div>
        <div>
          <p className="text-xs text-neutral-500 font-medium mb-0.5">{label}</p>
          <p className="text-2xl font-bold text-neutral-800">{value}</p>
          {sub && <p className="text-xs text-neutral-400 mt-0.5">{sub}</p>}
        </div>
      </div>
    </Card>
  );
}

export default function StoresDashboardPage() {
  const navigate = useNavigate();
  const { data, isLoading } = useQuery({
    queryKey: ['stores-dashboard'],
    queryFn: storesService.getDashboard,
  });

  if (isLoading) return (
    <div className="flex items-center justify-center h-64">
      <LoadingSpinner size="xl" className="text-primary-600" />
    </div>
  );
  if (!data) return null;

  return (
    <div className="space-y-6">
      <PageHeader title="Stores Dashboard" subtitle="Inventory overview and analytics" />

      {/* KPI row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          icon={CurrencyRupeeIcon}
          label="Total Stock Value"
          value={formatCurrency(data.total_value)}
          color="text-primary-600"
        />
        <StatCard
          icon={CubeIcon}
          label="Total Lots"
          value={data.total_lots.toLocaleString()}
          color="text-violet-600"
        />
        <StatCard
          icon={ExclamationTriangleIcon}
          label="QC Pending"
          value={data.qc_pending_count}
          sub="Lots awaiting inspection"
          color="text-warning-600"
          onClick={() => navigate('/stores/inventory?qc_status=PENDING')}
        />
        <StatCard
          icon={ExclamationTriangleIcon}
          label="Below Minimum"
          value={data.below_minimum_count}
          sub="Items needing reorder"
          color="text-danger-600"
          onClick={() => navigate('/stores/below-minimum')}
        />
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Stock value by warehouse */}
        <Card>
          <div className="p-4">
            <h3 className="text-sm font-semibold text-neutral-700 mb-4">Stock Value by Warehouse</h3>
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={data.stock_value_by_warehouse} margin={{ left: 10, right: 10 }}>
                <XAxis dataKey="warehouse" tick={{ fontSize: 11 }} />
                <YAxis
                  tickFormatter={v => `₹${(v / 100000).toFixed(0)}L`}
                  tick={{ fontSize: 11 }}
                />
                <Tooltip
                  formatter={(v: number) => [formatCurrency(v), 'Stock Value']}
                  contentStyle={{ fontSize: 12 }}
                />
                <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                  {data.stock_value_by_warehouse.map((_, i) => (
                    <Cell key={i} fill={COLORS[i % COLORS.length]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>

        {/* Aging analysis */}
        <Card>
          <div className="p-4">
            <h3 className="text-sm font-semibold text-neutral-700 mb-4">Stock Aging Analysis</h3>
            <ResponsiveContainer width="100%" height={260}>
              <PieChart>
                <Pie
                  data={data.aging_buckets}
                  dataKey="qty"
                  nameKey="label"
                  cx="50%"
                  cy="50%"
                  outerRadius={90}
                  label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                  labelLine={false}
                  fontSize={11}
                >
                  {data.aging_buckets.map((_, i) => (
                    <Cell key={i} fill={AGING_COLORS[i % AGING_COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip formatter={(v: number) => [v.toLocaleString(), 'Lots']} contentStyle={{ fontSize: 12 }} />
                <Legend wrapperStyle={{ fontSize: 12 }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </Card>
      </div>

      {/* Aging table */}
      <Card>
        <div className="p-4">
          <h3 className="text-sm font-semibold text-neutral-700 mb-3">Aging Breakdown</h3>
          <table className="w-full text-sm">
            <thead>
              <tr className="text-xs text-neutral-500 border-b border-neutral-100">
                <th className="py-2 pr-4 text-left font-medium">Age Bucket</th>
                <th className="py-2 pr-4 text-right font-medium">Lots</th>
                <th className="py-2 pr-4 text-right font-medium">Value</th>
                <th className="py-2 text-right font-medium">% of Total</th>
              </tr>
            </thead>
            <tbody>
              {data.aging_buckets.map((bucket, i) => (
                <tr key={bucket.label} className="border-b border-neutral-50">
                  <td className="py-2.5 pr-4">
                    <div className="flex items-center gap-2">
                      <span className="h-2.5 w-2.5 rounded-full" style={{ background: AGING_COLORS[i % AGING_COLORS.length] }} />
                      {bucket.label}
                    </div>
                  </td>
                  <td className="py-2.5 pr-4 text-right font-semibold">{bucket.qty.toLocaleString()}</td>
                  <td className="py-2.5 pr-4 text-right">{formatCurrency(bucket.value)}</td>
                  <td className="py-2.5 text-right text-neutral-500">
                    {data.total_value > 0 ? ((bucket.value / data.total_value) * 100).toFixed(1) : 0}%
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
