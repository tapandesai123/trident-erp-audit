import { useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { createColumnHelper } from '@tanstack/react-table';
import {
  FunnelIcon, ChevronDownIcon, ChevronRightIcon,
  PrinterIcon, TagIcon,
} from '@heroicons/react/24/outline';

import { storesService, InventoryLot } from '@/services/stores';
import DataTable from '@/components/ui/DataTable';
import Badge from '@/components/ui/Badge';
import Button from '@/components/ui/Button';
import PageHeader from '@/components/ui/PageHeader';
import FilterPanel, { FilterSection, FilterRadioGroup } from '@/components/ui/FilterPanel';
import Modal from '@/components/ui/Modal';
import { usePagination } from '@/hooks/usePagination';
import { useDebounce } from '@/hooks/useDebounce';
import { formatDate } from '@/utils/format';
import { cn } from '@/utils/cn';

const col = createColumnHelper<InventoryLot>();

const QC_VARIANT: Record<string, 'success' | 'danger' | 'warning' | 'neutral'> = {
  PASSED: 'success', REJECTED: 'danger', PENDING: 'warning', WAIVED: 'neutral',
};
const LOT_STATUS_VARIANT: Record<string, 'success' | 'danger' | 'warning' | 'neutral'> = {
  AVAILABLE: 'success', QUARANTINE: 'danger', RESERVED: 'warning', CONSUMED: 'neutral',
};
const STATUS_OPTIONS = [
  { value: 'AVAILABLE', label: 'Available' },
  { value: 'RESERVED',  label: 'Reserved' },
  { value: 'QUARANTINE', label: 'Quarantine' },
  { value: 'CONSUMED',  label: 'Consumed' },
];
const QC_OPTIONS = [
  { value: 'PENDING',  label: 'Pending' },
  { value: 'PASSED',   label: 'Passed' },
  { value: 'REJECTED', label: 'Rejected' },
  { value: 'WAIVED',   label: 'Waived' },
];

// ─── Transaction History sub-row ─────────────────────────────────
function TransactionHistory({ lot }: { lot: InventoryLot }) {
  const { data } = useQuery({
    queryKey: ['lot-transactions', lot.id],
    queryFn: () => storesService.getLot(lot.id),
    select: d => d.transactions ?? [],
  });
  if (!data?.length) return <p className="text-xs text-neutral-400 py-2 px-4">No transactions found.</p>;
  return (
    <div className="px-4 py-2 bg-neutral-50">
      <table className="w-full text-xs">
        <thead>
          <tr className="text-neutral-500 border-b border-neutral-200">
            <th className="py-1 pr-3 text-left font-medium">Date</th>
            <th className="py-1 pr-3 text-left font-medium">Type</th>
            <th className="py-1 pr-3 text-left font-medium">Reference</th>
            <th className="py-1 pr-3 text-right font-medium">Qty In</th>
            <th className="py-1 pr-3 text-right font-medium">Qty Out</th>
            <th className="py-1 pr-3 text-left font-medium">By</th>
          </tr>
        </thead>
        <tbody>
          {data.map(t => (
            <tr key={t.id} className="border-b border-neutral-100 last:border-0">
              <td className="py-1 pr-3 text-neutral-600">{formatDate(t.date)}</td>
              <td className="py-1 pr-3 text-neutral-700">{t.type}</td>
              <td className="py-1 pr-3 font-mono text-neutral-600">{t.reference}</td>
              <td className="py-1 pr-3 text-right text-success-700">{t.qty_in || '—'}</td>
              <td className="py-1 pr-3 text-right text-danger-600">{t.qty_out || '—'}</td>
              <td className="py-1 pr-3 text-neutral-500">{t.user_name}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// ─── Batch Print Modal ────────────────────────────────────────────
function openPdfBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const win = window.open(url, '_blank');
  if (win) {
    win.onload = () => setTimeout(() => { win.focus(); win.print(); }, 500);
  }
  setTimeout(() => URL.revokeObjectURL(url), 10_000);
}

function BatchPrintModal({ selectedLots, onClose }: { selectedLots: InventoryLot[]; onClose: () => void }) {
  const [loading, setLoading] = useState<'A4' | 'LABEL_60x70' | null>(null);
  const [error, setError] = useState('');

  async function handleBatch(size: 'A4' | 'LABEL_60x70') {
    setError('');
    setLoading(size);
    try {
      const blob = await storesService.batchPrint(selectedLots.map(l => l.id), size);
      openPdfBlob(blob, `BatchPrint_${selectedLots.length}lots_${size}.pdf`);
    } catch (e: any) {
      setError(e?.response?.data?.error ?? 'Batch PDF generation failed.');
    } finally {
      setLoading(null);
    }
  }

  return (
    <Modal open onClose={onClose} title={`Batch Print — ${selectedLots.length} lots`} size="sm">
      <div className="p-5 space-y-4">
        <div className="bg-neutral-50 border border-neutral-200 rounded-xl max-h-44 overflow-y-auto">
          {selectedLots.map(lot => (
            <div key={lot.id} className="flex items-center justify-between px-3 py-2 border-b border-neutral-100 last:border-0">
              <span className="text-xs font-mono font-semibold text-primary-700">{lot.lot_number}</span>
              <span className="text-xs text-neutral-500">{lot.item_code} · {lot.warehouse_name}</span>
            </div>
          ))}
        </div>

        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 text-sm rounded-lg p-3">{error}</div>
        )}

        <p className="text-xs text-neutral-500">
          All {selectedLots.length} lots merged into a single PDF.
          Browser print dialog opens automatically.
        </p>

        <div className="grid grid-cols-2 gap-3">
          {/* A4 Tag */}
          <button
            disabled={!!loading}
            onClick={() => handleBatch('A4')}
            className="flex flex-col items-center gap-2 p-4 rounded-xl border-2 border-neutral-200
                       hover:border-primary-400 hover:bg-primary-50 transition-colors
                       disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <PrinterIcon className="h-7 w-7 text-primary-600" />
            <span className="text-sm font-semibold text-neutral-800">A4 Tags</span>
            <span className="text-xs text-neutral-500 text-center">Half-A4 · 2 per page<br />Large QR + full metadata</span>
            {loading === 'A4' && (
              <div className="h-4 w-4 border-2 border-primary-600 border-t-transparent rounded-full animate-spin mt-1" />
            )}
          </button>

          {/* 60×70 Label */}
          <button
            disabled={!!loading}
            onClick={() => handleBatch('LABEL_60x70')}
            className="flex flex-col items-center gap-2 p-4 rounded-xl border-2 border-neutral-200
                       hover:border-amber-400 hover:bg-amber-50 transition-colors
                       disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <TagIcon className="h-7 w-7 text-amber-600" />
            <span className="text-sm font-semibold text-neutral-800">60×70mm Labels</span>
            <span className="text-xs text-neutral-500 text-center">4 per A4 · Compact QR<br />For roll / label printer</span>
            {loading === 'LABEL_60x70' && (
              <div className="h-4 w-4 border-2 border-amber-600 border-t-transparent rounded-full animate-spin mt-1" />
            )}
          </button>
        </div>

        <div className="flex justify-end pt-1">
          <Button variant="ghost" onClick={onClose} disabled={!!loading}>Close</Button>
        </div>
      </div>
    </Modal>
  );
}

// ─── Main Page ────────────────────────────────────────────────────
export default function InventoryListPage() {
  const navigate = useNavigate();
  const { page, pageSize, setPage, setPageSize } = usePagination();
  const [search, setSearch] = useState('');
  const debouncedSearch = useDebounce(search, 300);
  const [filterOpen, setFilterOpen] = useState(false);
  const [warehouse, setWarehouse] = useState('');
  const [status, setStatus]       = useState('');
  const [qcStatus, setQcStatus]   = useState('');
  const [expandedRows, setExpandedRows] = useState<Set<string>>(new Set());

  // ── Selection state ──
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [batchPrintOpen, setBatchPrintOpen] = useState(false);

  const { data: warehouses } = useQuery({
    queryKey: ['warehouses'],
    queryFn: storesService.listWarehouses,
  });

  const activeFilters = [warehouse, status, qcStatus].filter(Boolean).length;

  const { data, isLoading } = useQuery({
    queryKey: ['inventory', page, pageSize, debouncedSearch, warehouse, status, qcStatus],
    queryFn: () => storesService.listInventory({
      page, page_size: pageSize,
      search: debouncedSearch || undefined,
      warehouse: warehouse || undefined,
      status: status || undefined,
      qc_status: qcStatus || undefined,
    }),
  });

  const rows = data?.results ?? [];

  const toggleRow = (id: string) => {
    setExpandedRows(prev => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  const toggleSelect = useCallback((id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setSelectedIds(prev => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  }, []);

  const allSelected  = rows.length > 0 && selectedIds.size === rows.length;
  const someSelected = selectedIds.size > 0 && !allSelected;
  const selectedLots = rows.filter(r => selectedIds.has(r.id));

  const toggleSelectAll = () =>
    setSelectedIds(allSelected ? new Set() : new Set(rows.map(r => r.id)));

  const COLUMNS = [
    // ── checkbox ──
    col.display({
      id: 'select',
      size: 36,
      header: () => (
        <input
          type="checkbox"
          checked={allSelected}
          ref={el => { if (el) el.indeterminate = someSelected; }}
          onChange={toggleSelectAll}
          onClick={e => e.stopPropagation()}
          className="h-3.5 w-3.5 rounded border-neutral-400 text-primary-600 cursor-pointer"
        />
      ),
      cell: i => (
        <input
          type="checkbox"
          checked={selectedIds.has(i.row.original.id)}
          onChange={() => {}}
          onClick={e => toggleSelect(i.row.original.id, e)}
          className="h-3.5 w-3.5 rounded border-neutral-400 text-primary-600 cursor-pointer"
        />
      ),
    }),
    // ── expand ──
    col.display({
      id: 'expand',
      size: 32,
      cell: i => (
        <button
          onClick={e => { e.stopPropagation(); toggleRow(i.row.original.id); }}
          className="p-1 rounded hover:bg-neutral-100"
        >
          {expandedRows.has(i.row.original.id)
            ? <ChevronDownIcon className="h-3 w-3 text-neutral-500" />
            : <ChevronRightIcon className="h-3 w-3 text-neutral-500" />}
        </button>
      ),
    }),
    col.accessor('lot_number', {
      header: 'Lot #',
      cell: i => <span className="font-mono text-xs font-semibold text-primary-800">{i.getValue()}</span>,
      size: 130,
    }),
    col.accessor('roll_number', {
      header: 'Roll #',
      cell: i => <span className="font-mono text-xs text-neutral-600">{i.getValue() || '—'}</span>,
      size: 100,
    }),
    col.accessor('item_name', {
      header: 'Item',
      cell: i => (
        <div>
          <p className="text-sm font-medium text-neutral-800">{i.getValue()}</p>
          <p className="text-xs text-neutral-400">{i.row.original.item_code}</p>
        </div>
      ),
    }),
    col.accessor('quantity', {
      header: 'Qty',
      cell: i => <span className="text-sm font-semibold">{i.getValue()} {i.row.original.uom_code}</span>,
      size: 90,
    }),
    col.accessor('warehouse_name', {
      header: 'Warehouse',
      size: 130,
    }),
    col.accessor('bin_code', {
      header: 'Bin',
      cell: i => <span className="font-mono text-xs bg-neutral-100 px-1.5 py-0.5 rounded">{i.getValue()}</span>,
      size: 80,
    }),
    col.accessor('qc_status', {
      header: 'QC Status',
      cell: i => <Badge variant={QC_VARIANT[i.getValue()] ?? 'neutral'}>{i.getValue()}</Badge>,
      size: 100,
    }),
    col.accessor('status', {
      header: 'Status',
      cell: i => <Badge variant={LOT_STATUS_VARIANT[i.getValue()] ?? 'neutral'}>{i.getValue()}</Badge>,
      size: 100,
    }),
    col.accessor('age_days', {
      header: 'Age (days)',
      cell: i => {
        const age = i.getValue();
        return (
          <span className={cn(
            'text-sm font-medium',
            age > 90 ? 'text-danger-600' : age > 30 ? 'text-warning-600' : 'text-neutral-600'
          )}>
            {age}d
          </span>
        );
      },
      size: 90,
    }),
  ];

  return (
    <div className="space-y-4">
      <PageHeader
        title="Inventory"
        subtitle="Manage inventory lots across all warehouses"
      />

      {/* ── Batch action bar (shown when rows are checked) ── */}
      {selectedIds.size > 0 && (
        <div className="flex items-center gap-3 px-4 py-2.5 bg-primary-50 border border-primary-200 rounded-xl">
          <span className="text-sm font-semibold text-primary-800">
            {selectedIds.size} lot{selectedIds.size !== 1 ? 's' : ''} selected
          </span>
          <div className="flex-1" />
          <Button size="sm" variant="primary" onClick={() => setBatchPrintOpen(true)}>
            <PrinterIcon className="h-4 w-4 mr-1.5" />
            Batch Print Labels
          </Button>
          <Button size="sm" variant="ghost" onClick={() => setSelectedIds(new Set())}>
            Clear selection
          </Button>
        </div>
      )}

      <div className="flex gap-4">
        <div className="flex-1 min-w-0">
          <DataTable
            data={rows}
            columns={COLUMNS}
            loading={isLoading}
            totalCount={data?.count}
            page={page}
            pageSize={pageSize}
            onPageChange={setPage}
            onPageSizeChange={setPageSize}
            searchValue={search}
            onSearchChange={setSearch}
            searchPlaceholder="Search lot, item, roll..."
            onRowClick={row => navigate(`/stores/inventory/${row.id}`)}
            toolbarLeft={
              <button
                onClick={() => setFilterOpen(o => !o)}
                className={cn(
                  'inline-flex items-center gap-1.5 px-3 py-1.5 text-sm rounded-lg border transition-colors',
                  filterOpen || activeFilters > 0
                    ? 'bg-primary-50 border-primary-300 text-primary-700'
                    : 'bg-white border-neutral-200 text-neutral-600 hover:bg-neutral-50'
                )}
              >
                <FunnelIcon className="h-4 w-4" />
                Filters
                {activeFilters > 0 && (
                  <span className="h-4 w-4 bg-primary-700 text-white text-[10px] font-bold rounded-full flex items-center justify-center">
                    {activeFilters}
                  </span>
                )}
              </button>
            }
            emptyTitle="No inventory lots found"
            emptyDescription="Adjust filters or receive items via MRR."
          />

          {/* Expanded transaction rows */}
          {rows.map(row =>
            expandedRows.has(row.id) ? (
              <div key={`expand-${row.id}`} className="border border-neutral-200 rounded-xl mt-1 overflow-hidden">
                <div className="bg-neutral-50 px-4 py-1.5 text-xs font-semibold text-neutral-500 border-b border-neutral-200">
                  Transaction History — {row.lot_number}
                </div>
                <TransactionHistory lot={row} />
              </div>
            ) : null
          )}
        </div>

        <FilterPanel
          open={filterOpen}
          onClose={() => setFilterOpen(false)}
          onReset={() => { setWarehouse(''); setStatus(''); setQcStatus(''); }}
          activeCount={activeFilters}
        >
          <FilterSection label="Warehouse">
            <FilterRadioGroup
              name="warehouse"
              value={warehouse}
              onChange={setWarehouse}
              options={[
                { value: '', label: 'All' },
                ...(warehouses ?? []).map(w => ({ value: w.id, label: w.name })),
              ]}
            />
          </FilterSection>
          <FilterSection label="Status">
            <FilterRadioGroup
              name="status"
              value={status}
              onChange={setStatus}
              options={[{ value: '', label: 'All' }, ...STATUS_OPTIONS]}
            />
          </FilterSection>
          <FilterSection label="QC Status">
            <FilterRadioGroup
              name="qcStatus"
              value={qcStatus}
              onChange={setQcStatus}
              options={[{ value: '', label: 'All' }, ...QC_OPTIONS]}
            />
          </FilterSection>
        </FilterPanel>
      </div>

      {/* Batch print modal */}
      {batchPrintOpen && selectedLots.length > 0 && (
        <BatchPrintModal
          selectedLots={selectedLots}
          onClose={() => { setBatchPrintOpen(false); setSelectedIds(new Set()); }}
        />
      )}
    </div>
  );
}
