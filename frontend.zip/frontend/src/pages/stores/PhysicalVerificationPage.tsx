import { useState, useRef } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  QrCodeIcon,
  PlayIcon,
  CheckCircleIcon,
  ExclamationTriangleIcon,
} from '@heroicons/react/24/outline';

import { storesService, VerificationLine } from '@/services/stores';
import PageHeader from '@/components/ui/PageHeader';
import Card from '@/components/ui/Card';
import Button from '@/components/ui/Button';
import FormField from '@/components/ui/FormField';
import Input from '@/components/ui/Input';
import Badge from '@/components/ui/Badge';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import { cn } from '@/utils/cn';

type Phase = 'setup' | 'scanning' | 'review';

export default function PhysicalVerificationPage() {
  const qc = useQueryClient();
  const [phase, setPhase] = useState<Phase>('setup');
  const [verificationId, setVerificationId] = useState('');
  const [warehouse, setWarehouse] = useState('');
  const [bay, setBay] = useState('');
  const [lines, setLines] = useState<VerificationLine[]>([]);
  const [qrInput, setQrInput] = useState('');
  const [scanError, setScanError] = useState('');
  const [scanning, setScanning] = useState(false);
  const qrRef = useRef<HTMLInputElement>(null);

  const { data: warehouses } = useQuery({
    queryKey: ['warehouses'],
    queryFn: storesService.listWarehouses,
  });

  const createMut = useMutation({
    mutationFn: () => storesService.createVerification({ warehouse, bay: bay || undefined }),
    onSuccess: (v) => {
      setVerificationId(v.id);
      setPhase('scanning');
      setTimeout(() => qrRef.current?.focus(), 100);
    },
  });

  const scanMut = useMutation({
    mutationFn: (qrData: string) => storesService.scanQR(verificationId, qrData),
    onSuccess: (line) => {
      setLines(prev => {
        const idx = prev.findIndex(l => l.lot_number === line.lot_number);
        if (idx >= 0) {
          const next = [...prev];
          next[idx] = line;
          return next;
        }
        return [...prev, line];
      });
      setQrInput('');
      setScanError('');
    },
    onError: () => setScanError('QR not recognised or lot not in this warehouse/bay.'),
  });

  const submitMut = useMutation({
    mutationFn: () => storesService.submitVerification(verificationId),
    onSuccess: () => {
      setPhase('setup');
      setLines([]);
      setVerificationId('');
    },
  });

  const handleScan = () => {
    if (!qrInput.trim()) return;
    setScanning(true);
    scanMut.mutate(qrInput.trim(), { onSettled: () => setScanning(false) });
  };

  const updateCounted = (idx: number, val: string) => {
    setLines(prev => {
      const next = [...prev];
      next[idx] = { ...next[idx], counted_qty: val };
      return next;
    });
  };

  const variance = (line: VerificationLine) => {
    if (!line.counted_qty) return null;
    return parseFloat(line.counted_qty) - parseFloat(line.system_qty);
  };

  const totalVariances = lines.filter(l => {
    const v = variance(l);
    return v !== null && v !== 0;
  }).length;

  return (
    <div className="space-y-4">
      <PageHeader
        title="Physical Verification"
        subtitle="Reconcile system vs physical stock"
      />

      {phase === 'setup' && (
        <Card>
          <div className="p-6 max-w-md space-y-4">
            <h3 className="text-sm font-semibold text-neutral-700">Start New Verification</h3>
            <FormField label="Warehouse" required>
              <select
                value={warehouse}
                onChange={e => setWarehouse(e.target.value)}
                className="w-full rounded-lg border border-neutral-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary-400"
              >
                <option value="">Select warehouse…</option>
                {warehouses?.map(w => <option key={w.id} value={w.id}>{w.name}</option>)}
              </select>
            </FormField>
            <FormField label="Bay / Section (optional)">
              <Input value={bay} onChange={e => setBay(e.target.value)} placeholder="e.g. Bay A" />
            </FormField>
            <Button onClick={() => createMut.mutate()} disabled={!warehouse} loading={createMut.isPending}>
              <PlayIcon className="h-4 w-4 mr-1" /> Start Verification
            </Button>
          </div>
        </Card>
      )}

      {phase === 'scanning' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* Scanner panel */}
          <Card>
            <div className="p-4 space-y-4">
              <div className="flex items-center gap-2">
                <QrCodeIcon className="h-5 w-5 text-primary-600" />
                <h3 className="text-sm font-semibold text-neutral-700">Scan / Enter QR Data</h3>
                <Badge variant="info" size="sm">{lines.length} scanned</Badge>
              </div>
              <p className="text-xs text-neutral-500">
                Scan a QR code or type the lot number. Press Enter or click Scan.
              </p>
              <div className="flex gap-2">
                <Input
                  ref={qrRef}
                  value={qrInput}
                  onChange={e => { setQrInput(e.target.value); setScanError(''); }}
                  onKeyDown={e => e.key === 'Enter' && handleScan()}
                  placeholder="Scan QR or type lot number…"
                  className="font-mono"
                />
                <Button onClick={handleScan} loading={scanning} size="sm">Scan</Button>
              </div>
              {scanError && (
                <p className="text-xs text-danger-600 flex items-center gap-1">
                  <ExclamationTriangleIcon className="h-3.5 w-3.5" /> {scanError}
                </p>
              )}

              <div className="border-t border-neutral-100 pt-4 flex justify-between">
                <Button variant="ghost" size="sm" onClick={() => setPhase('review')}>
                  Review & Submit
                </Button>
                <span className="text-xs text-neutral-400">
                  {totalVariances > 0 && `${totalVariances} variance(s) detected`}
                </span>
              </div>
            </div>
          </Card>

          {/* Live count list */}
          <Card>
            <div className="p-4">
              <h3 className="text-sm font-semibold text-neutral-700 mb-3">Counted Items</h3>
              {!lines.length
                ? <p className="text-sm text-neutral-400 text-center py-8">No items scanned yet.</p>
                : (
                  <div className="space-y-2 max-h-96 overflow-y-auto">
                    {lines.map((line, idx) => {
                      const v = variance(line);
                      return (
                        <div
                          key={line.lot_number}
                          className={cn(
                            'rounded-lg border p-3',
                            v !== null && v < 0 ? 'border-danger-200 bg-danger-50'
                              : v !== null && v > 0 ? 'border-warning-200 bg-warning-50'
                              : 'border-neutral-200 bg-white'
                          )}
                        >
                          <div className="flex justify-between items-start mb-2">
                            <div>
                              <span className="font-mono text-xs font-bold text-primary-700">{line.lot_number}</span>
                              <p className="text-xs text-neutral-500">{line.item_name} · {line.bin_code}</p>
                            </div>
                            {v !== null && v !== 0 && (
                              <span className={cn('text-xs font-bold', v < 0 ? 'text-danger-600' : 'text-warning-600')}>
                                {v > 0 ? '+' : ''}{v}
                              </span>
                            )}
                          </div>
                          <div className="flex items-center gap-3 text-xs">
                            <span className="text-neutral-500">System: <strong>{line.system_qty}</strong></span>
                            <span className="text-neutral-300">|</span>
                            <span className="text-neutral-500">Counted:</span>
                            <input
                              type="number"
                              value={line.counted_qty ?? ''}
                              onChange={e => updateCounted(idx, e.target.value)}
                              className="w-20 border border-neutral-200 rounded px-2 py-0.5 text-xs font-medium"
                              placeholder="Enter qty"
                            />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
            </div>
          </Card>
        </div>
      )}

      {phase === 'review' && (
        <Card>
          <div className="p-4">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-semibold text-neutral-700">Review & Reconcile</h3>
              <div className="flex gap-2">
                <Button variant="ghost" size="sm" onClick={() => setPhase('scanning')}>
                  ← Back to Scanning
                </Button>
                <Button
                  size="sm"
                  onClick={() => submitMut.mutate()}
                  loading={submitMut.isPending}
                  variant={totalVariances > 0 ? 'warning' : 'primary'}
                >
                  <CheckCircleIcon className="h-4 w-4 mr-1" />
                  Submit Reconciliation {totalVariances > 0 && `(${totalVariances} variances)`}
                </Button>
              </div>
            </div>

            <table className="w-full text-sm">
              <thead>
                <tr className="text-xs text-neutral-500 border-b border-neutral-100">
                  <th className="py-2 pr-3 text-left font-medium">Lot #</th>
                  <th className="py-2 pr-3 text-left font-medium">Item</th>
                  <th className="py-2 pr-3 text-left font-medium">Bin</th>
                  <th className="py-2 pr-3 text-right font-medium">System Qty</th>
                  <th className="py-2 pr-3 text-right font-medium">Counted Qty</th>
                  <th className="py-2 pr-3 text-right font-medium">Variance</th>
                </tr>
              </thead>
              <tbody>
                {lines.map(line => {
                  const v = variance(line);
                  return (
                    <tr
                      key={line.lot_number}
                      className={cn(
                        'border-b border-neutral-50',
                        v !== null && v < 0 ? 'bg-danger-50' : v !== null && v > 0 ? 'bg-warning-50' : ''
                      )}
                    >
                      <td className="py-2 pr-3 font-mono text-xs font-bold text-primary-700">{line.lot_number}</td>
                      <td className="py-2 pr-3">
                        <p className="text-neutral-800">{line.item_name}</p>
                        <p className="text-xs text-neutral-400">{line.item_code}</p>
                      </td>
                      <td className="py-2 pr-3 font-mono text-xs text-neutral-500">{line.bin_code}</td>
                      <td className="py-2 pr-3 text-right font-semibold">{line.system_qty}</td>
                      <td className="py-2 pr-3 text-right font-semibold">{line.counted_qty ?? <span className="text-neutral-300">—</span>}</td>
                      <td className={cn(
                        'py-2 pr-3 text-right font-bold',
                        v === null ? 'text-neutral-300' : v < 0 ? 'text-danger-600' : v > 0 ? 'text-warning-600' : 'text-success-600'
                      )}>
                        {v === null ? '—' : v === 0 ? '✓' : (v > 0 ? '+' : '') + v}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </Card>
      )}
    </div>
  );
}
