import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { ViewColumnsIcon, ListBulletIcon } from '@heroicons/react/24/outline';

import { storesService, BinLocation, InventoryLot } from '@/services/stores';
import PageHeader from '@/components/ui/PageHeader';
import Card from '@/components/ui/Card';
import Badge from '@/components/ui/Badge';
import Modal from '@/components/ui/Modal';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import { cn } from '@/utils/cn';

function occupancyColor(pct: number) {
  if (pct >= 90) return 'bg-danger-500';
  if (pct >= 70) return 'bg-warning-500';
  return 'bg-success-500';
}

function occupancyBg(pct: number) {
  if (pct >= 90) return 'bg-danger-50 border-danger-200';
  if (pct >= 70) return 'bg-warning-50 border-warning-200';
  if (pct > 0) return 'bg-success-50 border-success-200';
  return 'bg-neutral-50 border-neutral-200';
}

function BinLotsModal({ bin, onClose }: { bin: BinLocation; onClose: () => void }) {
  const { data: lots, isLoading } = useQuery({
    queryKey: ['bin-lots', bin.id],
    queryFn: () => storesService.getBinLots(bin.id),
  });
  return (
    <Modal open onClose={onClose} title={`Bin ${bin.code} — Lots`} size="lg">
      <div className="p-4">
        {isLoading && <div className="flex justify-center py-8"><LoadingSpinner /></div>}
        {!isLoading && !lots?.length && (
          <p className="text-center text-neutral-400 py-8">No lots in this bin.</p>
        )}
        {lots && lots.length > 0 && (
          <table className="w-full text-sm">
            <thead>
              <tr className="text-xs text-neutral-500 border-b border-neutral-100">
                <th className="py-2 pr-3 text-left font-medium">Lot #</th>
                <th className="py-2 pr-3 text-left font-medium">Item</th>
                <th className="py-2 pr-3 text-right font-medium">Qty</th>
                <th className="py-2 pr-3 text-center font-medium">QC</th>
                <th className="py-2 pr-3 text-center font-medium">Status</th>
              </tr>
            </thead>
            <tbody>
              {lots.map((lot: InventoryLot) => (
                <tr key={lot.id} className="border-b border-neutral-50">
                  <td className="py-2 pr-3 font-mono text-xs font-semibold text-primary-700">{lot.lot_number}</td>
                  <td className="py-2 pr-3">
                    <p className="font-medium text-neutral-800">{lot.item_name}</p>
                    <p className="text-xs text-neutral-400">{lot.item_code}</p>
                  </td>
                  <td className="py-2 pr-3 text-right font-semibold">{lot.quantity} {lot.uom_code}</td>
                  <td className="py-2 pr-3 text-center">
                    <Badge variant={lot.qc_status === 'PASSED' ? 'success' : lot.qc_status === 'REJECTED' ? 'danger' : 'warning'} size="sm">
                      {lot.qc_status}
                    </Badge>
                  </td>
                  <td className="py-2 pr-3 text-center">
                    <Badge variant={lot.status === 'AVAILABLE' ? 'success' : 'warning'} size="sm">{lot.status}</Badge>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </Modal>
  );
}

export default function BinLocationPage() {
  const [selectedWarehouse, setSelectedWarehouse] = useState('');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [selectedBin, setSelectedBin] = useState<BinLocation | null>(null);

  const { data: warehouses } = useQuery({
    queryKey: ['warehouses'],
    queryFn: storesService.listWarehouses,
  });

  const { data: binsData, isLoading } = useQuery({
    queryKey: ['bins', selectedWarehouse],
    queryFn: () => storesService.listBins({
      warehouse: selectedWarehouse || undefined,
      page_size: 200,
    }),
    enabled: true,
  });

  const bins = binsData?.results ?? [];

  return (
    <div className="space-y-4">
      <PageHeader
        title="Bin Locations"
        subtitle="View warehouse bin occupancy and lot assignments"
      />

      {/* Warehouse selector */}
      <Card>
        <div className="p-4 flex items-center gap-4">
          <label className="text-sm font-medium text-neutral-700 shrink-0">Warehouse:</label>
          <div className="flex gap-2 flex-wrap">
            <button
              onClick={() => setSelectedWarehouse('')}
              className={cn(
                'px-3 py-1.5 rounded-lg text-sm border transition-colors',
                !selectedWarehouse
                  ? 'bg-primary-700 text-white border-primary-700'
                  : 'bg-white text-neutral-600 border-neutral-200 hover:bg-neutral-50'
              )}
            >
              All
            </button>
            {warehouses?.map(w => (
              <button
                key={w.id}
                onClick={() => setSelectedWarehouse(w.id)}
                className={cn(
                  'px-3 py-1.5 rounded-lg text-sm border transition-colors',
                  selectedWarehouse === w.id
                    ? 'bg-primary-700 text-white border-primary-700'
                    : 'bg-white text-neutral-600 border-neutral-200 hover:bg-neutral-50'
                )}
              >
                {w.name}
              </button>
            ))}
          </div>
          <div className="ml-auto flex gap-1 border border-neutral-200 rounded-lg overflow-hidden">
            <button
              onClick={() => setViewMode('grid')}
              className={cn('p-1.5 transition-colors', viewMode === 'grid' ? 'bg-neutral-100' : 'hover:bg-neutral-50')}
            >
              <ViewColumnsIcon className="h-4 w-4 text-neutral-600" />
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={cn('p-1.5 transition-colors', viewMode === 'list' ? 'bg-neutral-100' : 'hover:bg-neutral-50')}
            >
              <ListBulletIcon className="h-4 w-4 text-neutral-600" />
            </button>
          </div>
        </div>
      </Card>

      {/* Occupancy legend */}
      <div className="flex items-center gap-4 text-xs text-neutral-500">
        <span className="font-medium">Occupancy:</span>
        {[
          { color: 'bg-neutral-200', label: 'Empty' },
          { color: 'bg-success-500', label: '< 70%' },
          { color: 'bg-warning-500', label: '70–89%' },
          { color: 'bg-danger-500', label: '≥ 90%' },
        ].map(({ color, label }) => (
          <div key={label} className="flex items-center gap-1.5">
            <span className={cn('h-3 w-3 rounded-sm', color)} />
            <span>{label}</span>
          </div>
        ))}
      </div>

      {isLoading && (
        <div className="flex items-center justify-center h-48">
          <LoadingSpinner size="xl" className="text-primary-600" />
        </div>
      )}

      {!isLoading && viewMode === 'grid' && (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 xl:grid-cols-8 gap-2">
          {bins.map(bin => (
            <button
              key={bin.id}
              onClick={() => setSelectedBin(bin)}
              className={cn(
                'rounded-xl border p-3 text-left hover:shadow-md transition-all',
                occupancyBg(bin.occupancy_pct)
              )}
            >
              <p className="font-mono text-xs font-bold text-neutral-700 mb-1">{bin.code}</p>
              <div className="h-1.5 bg-neutral-200 rounded-full overflow-hidden mb-1">
                <div
                  className={cn('h-full rounded-full transition-all', occupancyColor(bin.occupancy_pct))}
                  style={{ width: `${Math.min(bin.occupancy_pct, 100)}%` }}
                />
              </div>
              <p className="text-[10px] text-neutral-500">{bin.lot_count} lots</p>
            </button>
          ))}
        </div>
      )}

      {!isLoading && viewMode === 'list' && (
        <Card>
          <table className="w-full text-sm">
            <thead>
              <tr className="text-xs text-neutral-500 border-b border-neutral-100">
                <th className="px-4 py-2 text-left font-medium">Bin Code</th>
                <th className="px-4 py-2 text-left font-medium">Warehouse</th>
                <th className="px-4 py-2 text-left font-medium">Location</th>
                <th className="px-4 py-2 text-center font-medium">Lots</th>
                <th className="px-4 py-2 text-right font-medium">Occupancy</th>
              </tr>
            </thead>
            <tbody>
              {bins.map(bin => (
                <tr
                  key={bin.id}
                  onClick={() => setSelectedBin(bin)}
                  className="border-b border-neutral-50 hover:bg-neutral-50 cursor-pointer"
                >
                  <td className="px-4 py-2.5 font-mono text-xs font-semibold text-primary-700">{bin.code}</td>
                  <td className="px-4 py-2.5 text-neutral-700">{bin.warehouse_name}</td>
                  <td className="px-4 py-2.5 text-neutral-500">
                    Row {bin.row_label} · Col {bin.column_label}
                    {bin.level_label && ` · Lvl ${bin.level_label}`}
                  </td>
                  <td className="px-4 py-2.5 text-center text-neutral-600">{bin.lot_count}</td>
                  <td className="px-4 py-2.5">
                    <div className="flex items-center gap-2 justify-end">
                      <div className="h-1.5 w-20 bg-neutral-200 rounded-full overflow-hidden">
                        <div
                          className={cn('h-full rounded-full', occupancyColor(bin.occupancy_pct))}
                          style={{ width: `${Math.min(bin.occupancy_pct, 100)}%` }}
                        />
                      </div>
                      <span className="text-xs text-neutral-500 w-8 text-right">{bin.occupancy_pct}%</span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      )}

      {selectedBin && <BinLotsModal bin={selectedBin} onClose={() => setSelectedBin(null)} />}
    </div>
  );
}
