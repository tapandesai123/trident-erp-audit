import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useForm, useWatch } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import toast from 'react-hot-toast';
import { ArrowLeftIcon, SparklesIcon } from '@heroicons/react/24/outline';

import { itemsService } from '@/services/items';
import Button from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import Select from '@/components/ui/Select';
import Textarea from '@/components/ui/Textarea';
import Tabs from '@/components/ui/Tabs';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import { useUnsavedChanges } from '@/hooks/useUnsavedChanges';

// ── Zod schema ────────────────────────────────────────────────────
const itemSchema = z.object({
  code: z.string().min(1, 'Code required').max(30),
  name: z.string().min(1, 'Name required').max(300),
  description: z.string(),
  item_group: z.string().min(1, 'Item group required'),
  item_type: z.enum(['RAW_MATERIAL', 'BOUGHT_OUT', 'CONSUMABLE', 'SPARE', 'FINISHED_GOOD', 'SEMI_FINISHED']),
  uom: z.string().min(1, 'UOM required'),
  secondary_uom: z.string().optional(),
  conversion_factor: z.string().optional(),
  hsn_code: z.string().regex(/^\d{4,8}$/, 'HSN must be 4–8 digits').or(z.literal('')),
  gst_rate: z.string(),
  pack_size: z.string(),
  // Stock
  min_stock: z.string(),
  max_stock: z.string(),
  reorder_level: z.string(),
  lead_time_days: z.coerce.number().min(0),
  shelf_life_days: z.string().optional(),
  // Replenishment / Auto PR
  auto_pr_enabled: z.boolean().default(false),
  auto_pr_lead_days: z.coerce.number().min(1).max(365).default(7),
  // Paper
  paper_type: z.string(),
  bf_rating: z.string().optional(),
  gsm: z.string().optional(),
  deckle_mm: z.string().optional(),
}).superRefine((data, ctx) => {
  if (data.item_type === 'RAW_MATERIAL' && data.paper_type) {
    if (!data.gsm) ctx.addIssue({ code: 'custom', path: ['gsm'], message: 'GSM required for paper items' });
    if (!data.bf_rating) ctx.addIssue({ code: 'custom', path: ['bf_rating'], message: 'BF rating required for paper items' });
  }
});

type ItemFormValues = z.infer<typeof itemSchema>;

const ITEM_TYPE_OPTIONS = [
  { value: 'RAW_MATERIAL', label: 'Raw Material' },
  { value: 'BOUGHT_OUT', label: 'Bought Out Part' },
  { value: 'CONSUMABLE', label: 'Consumable' },
  { value: 'SPARE', label: 'Spare Part' },
  { value: 'FINISHED_GOOD', label: 'Finished Good' },
  { value: 'SEMI_FINISHED', label: 'Semi-Finished' },
];

const PAPER_TYPE_OPTIONS = [
  { value: 'KRAFT', label: 'Kraft' },
  { value: 'FLUTE', label: 'Flute' },
  { value: 'LINER', label: 'Liner' },
  { value: 'TESTLINER', label: 'Test Liner' },
  { value: 'SEMI_CHEMICAL', label: 'Semi Chemical' },
  { value: 'DUPLEX', label: 'Duplex' },
];

const GST_RATE_OPTIONS = [
  { value: '0', label: '0%' },
  { value: '5', label: '5%' },
  { value: '12', label: '12%' },
  { value: '18', label: '18%' },
  { value: '28', label: '28%' },
];

const DEFAULT_VALUES: ItemFormValues = {
  code: '', name: '', description: '',
  item_group: '', item_type: 'RAW_MATERIAL', uom: '',
  secondary_uom: '', conversion_factor: '',
  hsn_code: '', gst_rate: '18', pack_size: '',
  min_stock: '0', max_stock: '0', reorder_level: '0', lead_time_days: 7,
  auto_pr_enabled: false, auto_pr_lead_days: 7,
  paper_type: '', bf_rating: '', gsm: '', deckle_mm: '',
};

const FORM_TABS = [
  { key: 'general', label: 'General' },
  { key: 'stock', label: 'Stock Levels' },
  { key: 'replenishment', label: 'Replenishment' },
  { key: 'paper', label: 'Paper Specs' },
];

export default function ItemFormPage() {
  const { id } = useParams<{ id: string }>();
  const isEdit = !!id && id !== 'new';
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [activeTab, setActiveTab] = useState('general');

  const { data: groups = [] } = useQuery({ queryKey: ['item-groups'], queryFn: itemsService.getGroups, staleTime: Infinity });
  const { data: uoms = [] } = useQuery({ queryKey: ['uoms'], queryFn: itemsService.getUOMs, staleTime: Infinity });

  const { data: existing, isLoading: loadingExisting } = useQuery({
    queryKey: ['item', id],
    queryFn: () => itemsService.getItem(id!),
    enabled: isEdit,
  });

  const {
    register, handleSubmit, watch, reset, control, setValue,
    formState: { errors, isDirty, isSubmitting },
  } = useForm<ItemFormValues>({
    resolver: zodResolver(itemSchema),
    defaultValues: DEFAULT_VALUES,
  });

  useUnsavedChanges(isDirty);

  const [itemType, paperType, bfRating, gsm, deckle, autoPrEnabled] = useWatch({
    control,
    name: ['item_type', 'paper_type', 'bf_rating', 'gsm', 'deckle_mm', 'auto_pr_enabled'],
  });

  const isPaperItem = itemType === 'RAW_MATERIAL';

  // Auto-generate name preview for paper items
  const paperNamePreview = isPaperItem && paperType
    ? [
        PAPER_TYPE_OPTIONS.find(p => p.value === paperType)?.label,
        bfRating ? `BF${bfRating}` : null,
        gsm ? `${gsm}GSM` : null,
        deckle ? `${deckle}mm` : null,
      ].filter(Boolean).join(' ')
    : null;

  useEffect(() => {
    if (existing) {
      reset({
        ...DEFAULT_VALUES,
        ...existing,
        item_group: String(existing.item_group),
        uom: String(existing.uom),
        secondary_uom: existing.secondary_uom ? String(existing.secondary_uom) : '',
        gst_rate: existing.gst_rate ?? '18',
        min_stock: existing.min_stock ?? '0',
        max_stock: existing.max_stock ?? '0',
        reorder_level: existing.reorder_level ?? '0',
        bf_rating: existing.bf_rating ? String(existing.bf_rating) : '',
        gsm: existing.gsm ? String(existing.gsm) : '',
        deckle_mm: existing.deckle_mm ?? '',
        paper_type: existing.paper_type ?? '',
        auto_pr_enabled: existing.auto_pr_enabled ?? false,
        auto_pr_lead_days: existing.auto_pr_lead_days ?? 7,
      });
    }
  }, [existing, reset]);

  const mutation = useMutation({
    mutationFn: (data: ItemFormValues) => {
      const payload = {
        ...data,
        item_group: Number(data.item_group),
        uom: Number(data.uom),
        secondary_uom: data.secondary_uom ? Number(data.secondary_uom) : null,
        bf_rating: data.bf_rating ? Number(data.bf_rating) : null,
        gsm: data.gsm ? Number(data.gsm) : null,
        shelf_life_days: data.shelf_life_days ? Number(data.shelf_life_days) : null,
        conversion_factor: data.conversion_factor || null,
      };
      return isEdit ? itemsService.updateItem(id!, payload) : itemsService.createItem(payload);
    },
    onSuccess: saved => {
      qc.invalidateQueries({ queryKey: ['items'] });
      qc.setQueryData(['item', saved.id], saved);
      toast.success(isEdit ? 'Item updated' : 'Item created');
      navigate(`/masters/items/${saved.id}`);
    },
    onError: (err: unknown) => {
      const e = err as { response?: { data?: Record<string, string[]> } };
      const msg = e?.response?.data ? Object.values(e.response.data)[0]?.[0] : null;
      toast.error(msg ?? 'Save failed');
    },
  });

  const groupOptions = groups.map(g => ({ value: String(g.id), label: g.name }));
  const uomOptions = uoms.map(u => ({ value: String(u.id), label: `${u.code} (${u.name})` }));

  if (isEdit && loadingExisting) return (
    <div className="flex items-center justify-center h-64">
      <LoadingSpinner size="xl" className="text-primary-600" />
    </div>
  );

  const visibleTabs = FORM_TABS.filter(t => t.key !== 'paper' || isPaperItem);

  return (
    <div>
      <div className="flex items-center justify-between mb-6 gap-4">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate(-1)} className="p-2 rounded-lg hover:bg-neutral-100 text-neutral-400 transition-colors">
            <ArrowLeftIcon className="h-5 w-5" />
          </button>
          <h1 className="text-xl font-bold text-neutral-900">{isEdit ? 'Edit Item' : 'New Item'}</h1>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" type="button" onClick={() => navigate(-1)} disabled={isSubmitting}>Cancel</Button>
          <Button loading={isSubmitting} onClick={handleSubmit(d => mutation.mutate(d))}>
            {isEdit ? 'Save Changes' : 'Create Item'}
          </Button>
        </div>
      </div>

      <Tabs tabs={visibleTabs} active={activeTab} onChange={setActiveTab} className="mb-6" />

      <form onSubmit={handleSubmit(d => mutation.mutate(d))} noValidate>
        <div className="card space-y-5">

          {activeTab === 'general' && (
            <>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                <Input label="Item Code" required error={errors.code?.message} {...register('code')} />
                <Input
                  label="Item Name"
                  required
                  className="lg:col-span-2"
                  error={errors.name?.message}
                  {...register('name')}
                  helperText={paperNamePreview ? undefined : undefined}
                  rightAddon={paperNamePreview ? (
                    <button type="button" title="Use generated name"
                      onClick={() => setValue('name', paperNamePreview, { shouldDirty: true })}>
                      <SparklesIcon className="h-4 w-4 text-accent-500 hover:text-accent-600" />
                    </button>
                  ) : undefined}
                />
                {paperNamePreview && (
                  <div className="lg:col-span-3 -mt-2">
                    <p className="text-xs text-neutral-500">
                      Auto-name: <strong className="text-neutral-700">{paperNamePreview}</strong>
                      <button type="button" onClick={() => setValue('name', paperNamePreview, { shouldDirty: true })}
                        className="ml-2 text-primary-700 hover:underline">use this</button>
                    </p>
                  </div>
                )}
                <Select label="Item Type" required options={ITEM_TYPE_OPTIONS} error={errors.item_type?.message} {...register('item_type')} />
                <Select label="Item Group" required options={groupOptions} placeholder="Select group" error={errors.item_group?.message} {...register('item_group')} />
                <Select label="Primary UOM" required options={uomOptions} placeholder="Select UOM" error={errors.uom?.message} {...register('uom')} />
                <Select label="Secondary UOM" options={uomOptions} placeholder="Optional" {...register('secondary_uom')} />
                {watch('secondary_uom') && (
                  <Input label="Conversion Factor" type="number" step="any" {...register('conversion_factor')}
                    helperText="1 Primary UOM = X Secondary UOM" />
                )}
                <Input label="HSN Code" maxLength={8} error={errors.hsn_code?.message} {...register('hsn_code')} placeholder="e.g. 48041100" />
                <Select label="GST Rate" options={GST_RATE_OPTIONS} {...register('gst_rate')} />
                <Input label="Pack Size" {...register('pack_size')} placeholder="e.g. 50 KGS/BAG" />
              </div>
              <Textarea label="Description" rows={3} {...register('description')} />
            </>
          )}

          {activeTab === 'stock' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              <Input label="Minimum Stock" type="number" step="any" min="0" {...register('min_stock')} />
              <Input label="Maximum Stock" type="number" step="any" min="0" {...register('max_stock')} />
              <Input label="Reorder Level" type="number" step="any" min="0" {...register('reorder_level')} />
              <Input label="Lead Time (days)" type="number" min="0" {...register('lead_time_days')} />
              <Input label="Shelf Life (days)" type="number" min="0" {...register('shelf_life_days')} placeholder="Optional" />
            </div>
          )}

          {activeTab === 'replenishment' && (
            <div className="space-y-5">
              <div>
                <p className="text-xs text-neutral-500 mb-4">
                  When enabled, the system analyses daily consumption history and automatically
                  raises a Purchase Requisition when projected stock falls below the lead days threshold.
                  Applies to Consumable, Spare Part, and Raw Material items.
                </p>
                <div className="flex items-start gap-3 p-4 rounded-lg border border-neutral-200 bg-neutral-50">
                  <input
                    id="auto_pr_enabled"
                    type="checkbox"
                    className="mt-0.5 h-4 w-4 rounded border-neutral-300 text-primary-600 focus:ring-primary-500 cursor-pointer"
                    {...register('auto_pr_enabled')}
                  />
                  <label htmlFor="auto_pr_enabled" className="cursor-pointer">
                    <p className="text-sm font-medium text-neutral-900">Enable Auto PR Generation</p>
                    <p className="text-xs text-neutral-500 mt-0.5">
                      System will automatically raise a Purchase Requisition based on 30-day
                      average consumption when stock falls below the lead days threshold.
                    </p>
                  </label>
                </div>
              </div>

              {autoPrEnabled && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
                  <div>
                    <Input
                      label="Lead Days Threshold"
                      type="number"
                      min="1"
                      max="365"
                      {...register('auto_pr_lead_days')}
                      helperText="Auto PR triggers when projected stock days falls below this value"
                      error={errors.auto_pr_lead_days?.message}
                    />
                  </div>
                  <div className="flex items-end pb-1">
                    <div className="p-3 rounded-lg bg-amber-50 border border-amber-200 text-xs text-amber-800 leading-relaxed w-full">
                      <strong>How it works:</strong> Each morning at 7:00 AM, the system checks
                      average daily consumption (last 30 days) and current stock. If stock covers
                      fewer than <strong>{watch('auto_pr_lead_days') || 7} days</strong>, a PR is
                      automatically raised and the Purchase team is notified.
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {activeTab === 'paper' && isPaperItem && (
            <div className="space-y-4">
              <p className="text-xs text-neutral-500">
                Paper specifications auto-generate the item name. Fill in the fields below and use the ✦ button on the Name field to apply.
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <Select label="Paper Type" required options={PAPER_TYPE_OPTIONS} placeholder="Select type"
                  error={errors.paper_type?.message} {...register('paper_type')} />
                <Input label="BF Rating" type="number" min="0" error={errors.bf_rating?.message} {...register('bf_rating')} placeholder="e.g. 14" />
                <Input label="GSM" type="number" min="0" error={errors.gsm?.message} {...register('gsm')} placeholder="e.g. 120" />
                <Input label="Deckle (mm)" type="number" step="0.1" min="0" {...register('deckle_mm')} placeholder="e.g. 1000" />
              </div>
            </div>
          )}
        </div>

        <div className="mt-6 flex justify-end gap-2 pb-4">
          <Button variant="outline" type="button" onClick={() => navigate(-1)} disabled={isSubmitting}>Cancel</Button>
          <Button type="submit" loading={isSubmitting}>{isEdit ? 'Save Changes' : 'Create Item'}</Button>
        </div>
      </form>
    </div>
  );
}
