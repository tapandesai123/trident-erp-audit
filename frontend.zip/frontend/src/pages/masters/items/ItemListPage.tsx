import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { createColumnHelper } from '@tanstack/react-table';
import toast from 'react-hot-toast';
import { PlusIcon, ArrowDownTrayIcon, ArrowUpTrayIcon, FunnelIcon } from '@heroicons/react/24/outline';

import { itemsService, ItemListItem } from '@/services/items';
import DataTable from '@/components/ui/DataTable';
import StatusBadge from '@/components/ui/StatusBadge';
import Button from '@/components/ui/Button';
import Badge from '@/components/ui/Badge';
import PageHeader from '@/components/ui/PageHeader';
import Tabs from '@/components/ui/Tabs';
import FilterPanel, { FilterSection, FilterRadioGroup } from '@/components/ui/FilterPanel';
import { usePagination } from '@/hooks/usePagination';
import { useDebounce } from '@/hooks/useDebounce';

const col = createColumnHelper<ItemListItem>();

type ListMode = 'all' | 'pending' | 'low_stock';

const ITEM_TYPE_OPTIONS = [
  { value: 'RAW_MATERIAL', label: 'Raw Material' },
  { value: 'BOUGHT_OUT', label: 'Bought Out' },
  { value: 'CONSUMABLE', label: 'Consumable' },
  { value: 'SPARE', label: 'Spare Part' },
  { value: 'FINISHED_GOOD', label: 'Finished Good' },
  { value: 'SEMI_FINISHED', label: 'Semi-Finished' },
];

const PAPER_TYPE_OPTIONS = [
  { value: 'KRAFT', label: 'Kraft' },
  { value: 'FLUTE', label: 'Flute' },
  { value: 'LINER', label: 'Liner' },
  { value: 'TESTLINER', label: 'Test Liner' },
  { value: 'SEMI_CHEMICAL', label: 'Semi Chemical' },
  { value: 'DUPLEX', label: 'Duplex' },
];

const STATUS_OPTIONS = [
  { value: 'DRAFT', label: 'Draft' },
  { value: 'PENDING', label: 'Pending Approval' },
  { value: 'APPROVED', label: 'Approved' },
  { value: 'REJECTED', label: 'Rejected' },
];

const COLUMNS = [
  col.accessor('code', {
    header: 'Code',
    cell: i => <span className="font-mono text-xs font-semibold text-primary-800">{i.getValue()}</span>,
    size: 120,
  }),
  col.accessor('name', {
    header: 'Name',
    cell: i => (
      <div>
        <p className="font-medium text-neutral-900">{i.getValue()}</p>
        {i.row.original.item_group_name && (
          <p className="text-xs text-neutral-400">{i.row.original.item_group_name}</p>
        )}
      </div>
    ),
  }),
  col.accessor('item_type', {
    header: 'Type',
    cell: i => {
      const labels: Record<string, string> = {
        RAW_MATERIAL: 'Raw Material', BOUGHT_OUT: 'Bought Out',
        CONSUMABLE: 'Consumable', SPARE: 'Spare', FINISHED_GOOD: 'Finished', SEMI_FINISHED: 'Semi-Finished',
      };
      return <Badge variant="info" size="sm">{labels[i.getValue()] ?? i.getValue()}</Badge>;
    },
    size: 120,
  }),
  col.accessor('uom_code', { header: 'UOM', size: 70 }),
  col.accessor('gsm', {
    header: 'GSM',
    cell: i => i.getValue() ?? <span className="text-neutral-300">—</span>,
    size: 70,
  }),
  col.accessor('bf_rating', {
    header: 'BF',
    cell: i => i.getValue() ?? <span className="text-neutral-300">—</span>,
    size: 60,
  }),
  col.accessor('approval_status', {
    header: 'Status',
    cell: i => <StatusBadge status={i.getValue()} />,
    size: 130,
  }),
];

const LIST_TABS = [
  { key: 'all', label: 'All Items' },
  { key: 'pending', label: 'Pending Approval' },
  { key: 'low_stock', label: 'Below Minimum Stock' },
];

export default function ItemListPage() {
  const navigate = useNavigate();
  const { page, pageSize, offset, setPage, setPageSize } = usePagination();
  const [search, setSearch] = useState('');
  const debouncedSearch = useDebounce(search);
  const [mode, setMode] = useState<ListMode>('all');
  const [filterOpen, setFilterOpen] = useState(false);
  const [filters, setFilters] = useState({ item_type: '', paper_type: '', approval_status: '' });
  const [exporting, setExporting] = useState(false);

  const activeFilterCount = Object.values(filters).filter(Boolean).length;

  const queryFn = () => {
    const params = { offset, limit: pageSize, search: debouncedSearch,
      ...(filters.item_type && { item_type: filters.item_type }),
      ...(filters.paper_type && { paper_type: filters.paper_type }),
      ...(filters.approval_status && { approval_status: filters.approval_status }),
    };
    if (mode === 'pending') return itemsService.getPendingApprovals({ offset, limit: pageSize });
    if (mode === 'low_stock') return itemsService.getBelowMinimum({ offset, limit: pageSize });
    return itemsService.getItems(params);
  };

  const { data, isLoading } = useQuery({
    queryKey: ['items', mode, { offset, limit: pageSize, search: debouncedSearch, ...filters }],
    queryFn,
    placeholderData: prev => prev,
  });

  const handleExport = async () => {
    setExporting(true);
    try {
      const blob = await itemsService.exportItems({ search: debouncedSearch, ...filters });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `items_${new Date().toISOString().split('T')[0]}.xlsx`;
      a.click();
      URL.revokeObjectURL(url);
      toast.success('Export started');
    } catch {
      toast.error('Export failed');
    } finally {
      setExporting(false);
    }
  };

  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const tid = toast.loading('Importing items…');
    itemsService.importItems(file)
      .then(() => toast.success('Import complete', { id: tid }))
      .catch(() => toast.error('Import failed', { id: tid }));
    e.target.value = '';
  };

  return (
    <div>
      <PageHeader
        title="Items"
        description={`${data?.count ?? 0} items total`}
        actions={
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" leftIcon={<FunnelIcon className="h-4 w-4" />}
              onClick={() => setFilterOpen(f => !f)}
              className={activeFilterCount > 0 ? 'border-primary-600 text-primary-700' : ''}>
              Filters{activeFilterCount > 0 && ` (${activeFilterCount})`}
            </Button>
            <Button variant="outline" size="sm" leftIcon={<ArrowDownTrayIcon className="h-4 w-4" />}
              onClick={handleExport} loading={exporting}>Export</Button>
            <label>
              <Button variant="outline" size="sm" leftIcon={<ArrowUpTrayIcon className="h-4 w-4" />} as="span">Import</Button>
              <input type="file" accept=".xlsx,.xls" className="hidden" onChange={handleImport} />
            </label>
            <Button size="sm" leftIcon={<PlusIcon className="h-4 w-4" />}
              onClick={() => navigate('/masters/items/new')}>
              New Item
            </Button>
          </div>
        }
      />

      {/* Mode tabs */}
      <Tabs
        tabs={LIST_TABS}
        active={mode}
        onChange={v => { setMode(v as ListMode); setPage(1); }}
        variant="pills"
        className="mb-4"
      />

      <div className="flex gap-4">
        <FilterPanel
          open={filterOpen && mode === 'all'}
          onClose={() => setFilterOpen(false)}
          onReset={() => setFilters({ item_type: '', paper_type: '', approval_status: '' })}
          activeCount={activeFilterCount}
        >
          <FilterSection label="Item Type">
            <FilterRadioGroup
              options={ITEM_TYPE_OPTIONS}
              value={filters.item_type}
              onChange={v => { setFilters(f => ({ ...f, item_type: v })); setPage(1); }}
            />
          </FilterSection>
          <FilterSection label="Paper Type">
            <FilterRadioGroup
              options={PAPER_TYPE_OPTIONS}
              value={filters.paper_type}
              onChange={v => { setFilters(f => ({ ...f, paper_type: v })); setPage(1); }}
            />
          </FilterSection>
          <FilterSection label="Approval Status">
            <FilterRadioGroup
              options={STATUS_OPTIONS}
              value={filters.approval_status}
              onChange={v => { setFilters(f => ({ ...f, approval_status: v })); setPage(1); }}
            />
          </FilterSection>
        </FilterPanel>

        <div className="flex-1 min-w-0">
          <DataTable
            data={data?.results ?? []}
            columns={COLUMNS}
            totalCount={data?.count}
            page={page} pageSize={pageSize}
            onPageChange={setPage} onPageSizeChange={setPageSize}
            searchValue={search}
            onSearchChange={mode === 'all' ? v => { setSearch(v); setPage(1); } : undefined}
            searchPlaceholder="Search code, name, HSN…"
            loading={isLoading}
            onRowClick={row => navigate(`/masters/items/${row.id}`)}
            emptyTitle={mode === 'pending' ? 'No pending approvals' : mode === 'low_stock' ? 'No items below minimum stock' : 'No items found'}
            emptyAction={mode === 'all' ? { label: '+ New Item', onClick: () => navigate('/masters/items/new') } : undefined}
          />
        </div>
      </div>
    </div>
  );
}
