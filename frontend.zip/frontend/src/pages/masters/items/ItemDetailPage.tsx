import { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { createColumnHelper } from '@tanstack/react-table';
import toast from 'react-hot-toast';
import {
  PencilIcon, ArrowLeftIcon, CheckCircleIcon, XCircleIcon,
  PaperAirplaneIcon, StarIcon,
} from '@heroicons/react/24/outline';

import { itemsService, ItemVendorLink } from '@/services/items';
import Button from '@/components/ui/Button';
import StatusBadge from '@/components/ui/StatusBadge';
import Badge from '@/components/ui/Badge';
import Tabs, { TabItem } from '@/components/ui/Tabs';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import Modal from '@/components/ui/Modal';
import Textarea from '@/components/ui/Textarea';
import DataTable from '@/components/ui/DataTable';
import { formatDate, formatDateTime, formatCurrency, formatNumber } from '@/utils/format';
import { cn } from '@/utils/cn';

function Field({ label, value, mono }: { label: string; value?: React.ReactNode; mono?: boolean }) {
  return (
    <div>
      <dt className="text-xs text-neutral-400 font-medium mb-0.5">{label}</dt>
      <dd className={cn('text-sm text-neutral-800', mono && 'font-mono')}>{value || <span className="text-neutral-300">—</span>}</dd>
    </div>
  );
}

const vcol = createColumnHelper<ItemVendorLink>();

const VENDOR_LINK_COLUMNS = [
  vcol.accessor('vendor_code', { header: 'Code', size: 100, cell: i => <span className="font-mono text-xs">{i.getValue() as string}</span> }),
  vcol.accessor('vendor_name', { header: 'Vendor' }),
  vcol.accessor('is_preferred', {
    header: 'Preferred',
    cell: i => i.getValue() ? <StarIcon className="h-4 w-4 text-accent-500 fill-accent-500" /> : null,
    size: 90,
  }),
  vcol.accessor('last_rate', {
    header: 'Last Rate',
    cell: i => formatCurrency(i.getValue() as string),
    size: 120,
  }),
  vcol.accessor('last_po_date', {
    header: 'Last PO Date',
    cell: i => formatDate(i.getValue() as string),
    size: 120,
  }),
  vcol.accessor('min_order_qty', { header: 'MOQ', size: 80 }),
  vcol.accessor('lead_time_days', { header: 'Lead (days)', size: 100 }),
];

const TABS: TabItem[] = [
  { key: 'general', label: 'General Info' },
  { key: 'stock', label: 'Stock Levels' },
  { key: 'paper', label: 'Paper Specs' },
  { key: 'vendors', label: 'Linked Vendors' },
];

export default function ItemDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [activeTab, setActiveTab] = useState('general');
  const [actionModal, setActionModal] = useState<'submit' | 'approve' | 'reject' | null>(null);
  const [rejectionReason, setRejectionReason] = useState('');

  const { data: item, isLoading } = useQuery({
    queryKey: ['item', id],
    queryFn: () => itemsService.getItem(id!),
    enabled: !!id,
  });

  const submitMutation = useMutation({
    mutationFn: () => itemsService.submitForApproval(id!),
    onSuccess: updated => {
      qc.setQueryData(['item', id], updated);
      qc.invalidateQueries({ queryKey: ['items'] });
      toast.success('Submitted for approval');
      setActionModal(null);
    },
    onError: () => toast.error('Submit failed'),
  });

  const approveMutation = useMutation({
    mutationFn: ({ action, reason }: { action: 'APPROVE' | 'REJECT'; reason?: string }) =>
      itemsService.approveItem(id!, action, reason),
    onSuccess: updated => {
      qc.setQueryData(['item', id], updated);
      qc.invalidateQueries({ queryKey: ['items'] });
      toast.success(actionModal === 'approve' ? 'Item approved' : 'Item rejected');
      setActionModal(null);
    },
    onError: () => toast.error('Action failed'),
  });

  if (isLoading) return (
    <div className="flex items-center justify-center h-64">
      <LoadingSpinner size="xl" className="text-primary-600" />
    </div>
  );
  if (!item) return <div className="text-center py-24 text-neutral-400">Item not found</div>;

  const isPaper = item.item_type === 'RAW_MATERIAL' && !!item.paper_type;
  const visibleTabs = TABS.filter(t => t.key !== 'paper' || isPaper);

  const canSubmit = item.approval_status === 'DRAFT' || item.approval_status === 'REJECTED';
  const canApprove = item.approval_status === 'PENDING';

  return (
    <div>
      <div className="flex items-start justify-between mb-6 gap-4">
        <div className="flex items-start gap-3">
          <button onClick={() => navigate(-1)} className="p-2 mt-0.5 rounded-lg hover:bg-neutral-100 text-neutral-400 transition-colors">
            <ArrowLeftIcon className="h-5 w-5" />
          </button>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h1 className="text-xl font-bold text-neutral-900">{item.name}</h1>
              <StatusBadge status={item.approval_status} />
              <Badge variant="info" size="sm">{item.item_type.replace(/_/g, ' ')}</Badge>
            </div>
            <p className="text-sm text-neutral-500 mt-0.5">
              {item.code} · {item.uom_code} · Created {formatDate(item.created_at)}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2 shrink-0 flex-wrap justify-end">
          {canSubmit && (
            <Button size="sm" variant="outline" leftIcon={<PaperAirplaneIcon className="h-4 w-4" />}
              onClick={() => setActionModal('submit')}>
              Submit for Approval
            </Button>
          )}
          {canApprove && (
            <>
              <Button size="sm" variant="outline" leftIcon={<XCircleIcon className="h-4 w-4" />}
                className="text-danger-500 border-danger-300 hover:bg-danger-50"
                onClick={() => setActionModal('reject')}>
                Reject
              </Button>
              <Button size="sm" leftIcon={<CheckCircleIcon className="h-4 w-4" />}
                onClick={() => setActionModal('approve')}>
                Approve
              </Button>
            </>
          )}
          <Button variant="outline" size="sm" leftIcon={<PencilIcon className="h-4 w-4" />}
            onClick={() => navigate(`/masters/items/${id}/edit`)}>
            Edit
          </Button>
        </div>
      </div>

      {item.rejection_reason && (
        <div className="mb-4 p-3 bg-danger-50 border border-danger-200 rounded-lg">
          <p className="text-xs font-semibold text-danger-700 mb-0.5">Rejection Reason</p>
          <p className="text-sm text-danger-600">{item.rejection_reason}</p>
        </div>
      )}

      <Tabs tabs={visibleTabs} active={activeTab} onChange={setActiveTab} className="mb-6" />

      <div className="card">
        {activeTab === 'general' && (
          <dl className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-4">
            <Field label="Item Code" value={item.code} mono />
            <Field label="Item Name" value={item.name} />
            <Field label="Item Group" value={item.item_group_name} />
            <Field label="Item Type" value={item.item_type.replace(/_/g, ' ')} />
            <Field label="Primary UOM" value={item.uom_code} />
            {item.secondary_uom_code && (
              <>
                <Field label="Secondary UOM" value={item.secondary_uom_code} />
                <Field label="Conversion Factor" value={item.conversion_factor} />
              </>
            )}
            <Field label="HSN Code" value={item.hsn_code} mono />
            <Field label="GST Rate" value={`${item.gst_rate}%`} />
            <Field label="Pack Size" value={item.pack_size} />
            {item.description && (
              <div className="col-span-full">
                <Field label="Description" value={<p className="whitespace-pre-line">{item.description}</p>} />
              </div>
            )}
            {item.is_approved && (
              <>
                <Field label="Approved By" value={item.approved_by_name} />
                <Field label="Approved At" value={formatDateTime(item.approved_at)} />
              </>
            )}
          </dl>
        )}

        {activeTab === 'stock' && (
          <dl className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-4">
            <Field label="Minimum Stock" value={`${formatNumber(item.min_stock)} ${item.uom_code ?? ''}`} />
            <Field label="Maximum Stock" value={`${formatNumber(item.max_stock)} ${item.uom_code ?? ''}`} />
            <Field label="Reorder Level" value={`${formatNumber(item.reorder_level)} ${item.uom_code ?? ''}`} />
            <Field label="Lead Time" value={`${item.lead_time_days} days`} />
            {item.shelf_life_days && <Field label="Shelf Life" value={`${item.shelf_life_days} days`} />}
          </dl>
        )}

        {activeTab === 'paper' && isPaper && (
          <dl className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-4">
            <Field label="Paper Type" value={item.paper_type.replace(/_/g, ' ')} />
            <Field label="BF Rating" value={item.bf_rating ? `BF ${item.bf_rating}` : undefined} />
            <Field label="GSM" value={item.gsm ? `${item.gsm} GSM` : undefined} />
            <Field label="Deckle (mm)" value={item.deckle_mm ? `${item.deckle_mm} mm` : undefined} />
          </dl>
        )}

        {activeTab === 'vendors' && (
          <DataTable
            data={item.vendor_links ?? []}
            columns={VENDOR_LINK_COLUMNS}
            emptyTitle="No linked vendors"
            emptyDescription="Vendor links help track sourcing and pricing for this item."
          />
        )}
      </div>

      {/* Submit modal */}
      <Modal open={actionModal === 'submit'} onClose={() => setActionModal(null)} title="Submit for Approval" size="sm"
        footer={
          <>
            <Button variant="outline" onClick={() => setActionModal(null)}>Cancel</Button>
            <Button loading={submitMutation.isPending} onClick={() => submitMutation.mutate()}>Submit</Button>
          </>
        }>
        <p className="text-sm text-neutral-600">Submit <strong>{item.name}</strong> for approval? You won't be able to edit it while it's under review.</p>
      </Modal>

      {/* Approve modal */}
      <Modal open={actionModal === 'approve'} onClose={() => setActionModal(null)} title="Approve Item" size="sm"
        footer={
          <>
            <Button variant="outline" onClick={() => setActionModal(null)}>Cancel</Button>
            <Button loading={approveMutation.isPending} onClick={() => approveMutation.mutate({ action: 'APPROVE' })}>Approve</Button>
          </>
        }>
        <p className="text-sm text-neutral-600">Approve <strong>{item.name}</strong>? This item can then be used in purchase orders and stock transactions.</p>
      </Modal>

      {/* Reject modal */}
      <Modal open={actionModal === 'reject'} onClose={() => setActionModal(null)} title="Reject Item" size="sm"
        footer={
          <>
            <Button variant="outline" onClick={() => setActionModal(null)}>Cancel</Button>
            <Button variant="danger" loading={approveMutation.isPending}
              onClick={() => approveMutation.mutate({ action: 'REJECT', reason: rejectionReason })}>
              Reject
            </Button>
          </>
        }>
        <Textarea label="Rejection Reason" rows={3} required value={rejectionReason}
          onChange={e => setRejectionReason(e.target.value)} placeholder="Describe the issue…" />
      </Modal>
    </div>
  );
}
