import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { createColumnHelper } from '@tanstack/react-table';
import toast from 'react-hot-toast';
import { PlusIcon, ArrowDownTrayIcon, ArrowUpTrayIcon, FunnelIcon } from '@heroicons/react/24/outline';

import { customersService, CustomerListItem } from '@/services/customers';
import DataTable from '@/components/ui/DataTable';
import Badge from '@/components/ui/Badge';
import Button from '@/components/ui/Button';
import PageHeader from '@/components/ui/PageHeader';
import FilterPanel, { FilterSection, FilterRadioGroup } from '@/components/ui/FilterPanel';
import { usePagination } from '@/hooks/usePagination';
import { useDebounce } from '@/hooks/useDebounce';
import { formatCurrency } from '@/utils/format';

const col = createColumnHelper<CustomerListItem>();

const CUSTOMER_TYPE_OPTIONS = [
  { value: 'DIRECT', label: 'Direct' },
  { value: 'DEALER', label: 'Dealer' },
  { value: 'E_COMMERCE', label: 'E-Commerce' },
  { value: 'INSTITUTIONAL', label: 'Institutional' },
];

const TYPE_VARIANT: Record<string, 'primary' | 'success' | 'warning' | 'info' | 'neutral'> = {
  DIRECT: 'primary', DEALER: 'success', E_COMMERCE: 'warning', INSTITUTIONAL: 'info',
};

const TYPE_LABELS: Record<string, string> = {
  DIRECT: 'Direct', DEALER: 'Dealer', E_COMMERCE: 'E-Commerce', INSTITUTIONAL: 'Institutional',
};

const COLUMNS = [
  col.accessor('code', {
    header: 'Code',
    cell: i => <span className="font-mono text-xs font-semibold text-primary-800">{i.getValue()}</span>,
    size: 100,
  }),
  col.accessor('name', {
    header: 'Name',
    cell: i => (
      <div>
        <p className="font-medium text-neutral-900">{i.getValue()}</p>
        {i.row.original.customer_group_name && (
          <p className="text-xs text-neutral-400">{i.row.original.customer_group_name}</p>
        )}
      </div>
    ),
  }),
  col.accessor('customer_type', {
    header: 'Type',
    cell: i => <Badge variant={TYPE_VARIANT[i.getValue()] ?? 'neutral'} size="sm">{TYPE_LABELS[i.getValue()] ?? i.getValue()}</Badge>,
    size: 120,
  }),
  col.accessor('city', { header: 'City', size: 120 }),
  col.accessor('gstin', {
    header: 'GSTIN',
    cell: i => i.getValue() ? <span className="font-mono text-xs">{i.getValue()}</span> : <span className="text-neutral-300">—</span>,
    size: 160,
  }),
  col.accessor('credit_limit', {
    header: 'Credit Limit',
    cell: i => formatCurrency(i.getValue()),
    size: 130,
  }),
  col.accessor('sales_territory', {
    header: 'Territory',
    cell: i => i.getValue() || <span className="text-neutral-300">—</span>,
    size: 120,
  }),
];

export default function CustomerListPage() {
  const navigate = useNavigate();
  const { page, pageSize, offset, setPage, setPageSize } = usePagination();
  const [search, setSearch] = useState('');
  const debouncedSearch = useDebounce(search);
  const [filterOpen, setFilterOpen] = useState(false);
  const [filters, setFilters] = useState({ customer_type: '', sales_territory: '' });
  const [exporting, setExporting] = useState(false);

  const activeFilterCount = Object.values(filters).filter(Boolean).length;

  const { data, isLoading } = useQuery({
    queryKey: ['customers', { offset, limit: pageSize, search: debouncedSearch, ...filters }],
    queryFn: () => customersService.getCustomers({
      offset, limit: pageSize, search: debouncedSearch,
      ...(filters.customer_type && { customer_type: filters.customer_type }),
      ...(filters.sales_territory && { sales_territory: filters.sales_territory }),
    }),
    placeholderData: prev => prev,
  });

  const handleExport = async () => {
    setExporting(true);
    try {
      const blob = await customersService.exportCustomers({ search: debouncedSearch, ...filters });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a'); a.href = url;
      a.download = `customers_${new Date().toISOString().split('T')[0]}.xlsx`;
      a.click(); URL.revokeObjectURL(url);
      toast.success('Export started');
    } catch { toast.error('Export failed'); }
    finally { setExporting(false); }
  };

  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]; if (!file) return;
    const tid = toast.loading('Importing…');
    customersService.importCustomers(file)
      .then(() => toast.success('Import complete', { id: tid }))
      .catch(() => toast.error('Import failed', { id: tid }));
    e.target.value = '';
  };

  return (
    <div>
      <PageHeader
        title="Customers"
        description={`${data?.count ?? 0} customers total`}
        actions={
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" leftIcon={<FunnelIcon className="h-4 w-4" />}
              onClick={() => setFilterOpen(f => !f)}
              className={activeFilterCount > 0 ? 'border-primary-600 text-primary-700' : ''}>
              Filters{activeFilterCount > 0 && ` (${activeFilterCount})`}
            </Button>
            <Button variant="outline" size="sm" leftIcon={<ArrowDownTrayIcon className="h-4 w-4" />}
              onClick={handleExport} loading={exporting}>Export</Button>
            <label>
              <Button variant="outline" size="sm" leftIcon={<ArrowUpTrayIcon className="h-4 w-4" />} as="span">Import</Button>
              <input type="file" accept=".xlsx,.xls" className="hidden" onChange={handleImport} />
            </label>
            <Button size="sm" leftIcon={<PlusIcon className="h-4 w-4" />}
              onClick={() => navigate('/masters/customers/new')}>
              New Customer
            </Button>
          </div>
        }
      />

      <div className="flex gap-4">
        <FilterPanel
          open={filterOpen}
          onClose={() => setFilterOpen(false)}
          onReset={() => setFilters({ customer_type: '', sales_territory: '' })}
          activeCount={activeFilterCount}
        >
          <FilterSection label="Customer Type">
            <FilterRadioGroup
              options={CUSTOMER_TYPE_OPTIONS}
              value={filters.customer_type}
              onChange={v => { setFilters(f => ({ ...f, customer_type: v })); setPage(1); }}
            />
          </FilterSection>
        </FilterPanel>

        <div className="flex-1 min-w-0">
          <DataTable
            data={data?.results ?? []}
            columns={COLUMNS}
            totalCount={data?.count}
            page={page} pageSize={pageSize}
            onPageChange={setPage} onPageSizeChange={setPageSize}
            searchValue={search}
            onSearchChange={v => { setSearch(v); setPage(1); }}
            searchPlaceholder="Search code, name, GSTIN, city…"
            loading={isLoading}
            onRowClick={row => navigate(`/masters/customers/${row.id}`)}
            emptyTitle="No customers found"
            emptyAction={{ label: '+ New Customer', onClick: () => navigate('/masters/customers/new') }}
          />
        </div>
      </div>
    </div>
  );
}
