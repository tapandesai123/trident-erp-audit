import { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { createColumnHelper } from '@tanstack/react-table';
import { PencilIcon, ArrowLeftIcon, PhoneIcon, MapPinIcon } from '@heroicons/react/24/outline';

import { customersService, CustomerShipAddress } from '@/services/customers';
import Button from '@/components/ui/Button';
import Badge from '@/components/ui/Badge';
import Tabs, { TabItem } from '@/components/ui/Tabs';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import DataTable from '@/components/ui/DataTable';
import { formatCurrency, formatDate } from '@/utils/format';
import { cn } from '@/utils/cn';

function Field({ label, value, mono }: { label: string; value?: React.ReactNode; mono?: boolean }) {
  return (
    <div>
      <dt className="text-xs text-neutral-400 font-medium mb-0.5">{label}</dt>
      <dd className={cn('text-sm text-neutral-800', mono && 'font-mono')}>{value || <span className="text-neutral-300">—</span>}</dd>
    </div>
  );
}

const sacol = createColumnHelper<CustomerShipAddress>();

const SHIP_ADDRESS_COLUMNS = [
  sacol.accessor('label', {
    header: 'Label',
    cell: i => (
      <div className="flex items-center gap-1.5">
        <span className="font-medium text-neutral-800">{i.getValue()}</span>
        {i.row.original.is_default && <Badge variant="primary" size="sm">Default</Badge>}
      </div>
    ),
  }),
  sacol.accessor('address_line1', { header: 'Address' }),
  sacol.accessor('city', { header: 'City', size: 100 }),
  sacol.accessor('state', { header: 'State', size: 100 }),
  sacol.accessor('pincode', { header: 'PIN', size: 80, cell: i => <span className="font-mono text-xs">{i.getValue()}</span> }),
  sacol.accessor('gstin', {
    header: 'GSTIN',
    cell: i => i.getValue() ? <span className="font-mono text-xs">{i.getValue()}</span> : <span className="text-neutral-300">—</span>,
    size: 160,
  }),
  sacol.accessor('contact_person', { header: 'Contact', size: 140 }),
];

const TYPE_LABELS: Record<string, string> = {
  DIRECT: 'Direct', DEALER: 'Dealer', E_COMMERCE: 'E-Commerce', INSTITUTIONAL: 'Institutional',
};
const TYPE_VARIANT: Record<string, 'primary' | 'success' | 'warning' | 'info' | 'neutral'> = {
  DIRECT: 'primary', DEALER: 'success', E_COMMERCE: 'warning', INSTITUTIONAL: 'info',
};

const TABS: TabItem[] = [
  { key: 'general', label: 'General Info' },
  { key: 'contacts', label: 'Contacts' },
  { key: 'addresses', label: 'Ship Addresses' },
  { key: 'sales', label: 'Sales Info' },
];

export default function CustomerDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('general');

  const { data: customer, isLoading } = useQuery({
    queryKey: ['customer', id],
    queryFn: () => customersService.getCustomer(id!),
    enabled: !!id,
  });

  const { data: shipAddresses = [] } = useQuery({
    queryKey: ['customer-ship-addresses', id],
    queryFn: () => customersService.getShipAddresses(id!),
    enabled: !!id && activeTab === 'addresses',
  });

  if (isLoading) return (
    <div className="flex items-center justify-center h-64">
      <LoadingSpinner size="xl" className="text-primary-600" />
    </div>
  );
  if (!customer) return <div className="text-center py-24 text-neutral-400">Customer not found</div>;

  return (
    <div>
      <div className="flex items-start justify-between mb-6 gap-4">
        <div className="flex items-start gap-3">
          <button onClick={() => navigate(-1)} className="p-2 mt-0.5 rounded-lg hover:bg-neutral-100 text-neutral-400 transition-colors">
            <ArrowLeftIcon className="h-5 w-5" />
          </button>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h1 className="text-xl font-bold text-neutral-900">{customer.name}</h1>
              <Badge variant={TYPE_VARIANT[customer.customer_type] ?? 'neutral'}>
                {TYPE_LABELS[customer.customer_type] ?? customer.customer_type}
              </Badge>
              {!customer.is_active && <Badge variant="neutral">Inactive</Badge>}
              {customer.portal_enabled && <Badge variant="success" dot>Portal Active</Badge>}
            </div>
            <p className="text-sm text-neutral-500 mt-0.5">
              {customer.code} · Created {formatDate(customer.created_at)}
            </p>
          </div>
        </div>
        <Button variant="outline" size="sm" leftIcon={<PencilIcon className="h-4 w-4" />}
          onClick={() => navigate(`/masters/customers/${id}/edit`)}>
          Edit
        </Button>
      </div>

      <Tabs tabs={TABS} active={activeTab} onChange={setActiveTab} className="mb-6" />

      <div className="card">
        {activeTab === 'general' && (
          <dl className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-4">
            <Field label="Customer Code" value={customer.code} mono />
            <Field label="Legal Name" value={customer.legal_name} />
            <Field label="Customer Group" value={customer.customer_group_name} />
            <Field label="Customer Type" value={TYPE_LABELS[customer.customer_type]} />
            <Field label="Contact Person" value={customer.contact_person} />
            <Field label="Phone" value={customer.phone} />
            <Field label="Mobile" value={customer.mobile} />
            <Field label="Email" value={customer.email && <a href={`mailto:${customer.email}`} className="text-primary-700 hover:underline">{customer.email}</a>} />
            <Field label="Website" value={customer.website && <a href={customer.website} target="_blank" rel="noopener noreferrer" className="text-primary-700 hover:underline">{customer.website}</a>} />
            <div className="col-span-full border-t border-neutral-100 pt-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-4">
              <Field label="Address" value={[customer.address_line1, customer.address_line2, customer.city, customer.state, customer.pincode].filter(Boolean).join(', ')} />
            </div>
          </dl>
        )}

        {activeTab === 'contacts' && (
          <div>
            {!customer.contacts?.length ? (
              <p className="text-sm text-neutral-400 text-center py-8">No contacts recorded</p>
            ) : (
              <div className="space-y-3">
                {customer.contacts.map((c, i) => (
                  <div key={i} className="p-4 bg-neutral-50 rounded-lg border border-neutral-100">
                    <div className="flex items-center gap-2 mb-1.5">
                      <span className="font-semibold text-neutral-800">{c.name}</span>
                      {c.is_primary && <Badge variant="primary" size="sm" dot>Primary</Badge>}
                      {c.designation && <span className="text-xs text-neutral-500">{c.designation}</span>}
                    </div>
                    <div className="flex flex-wrap gap-4">
                      {c.phone && <span className="flex items-center gap-1 text-sm text-neutral-600"><PhoneIcon className="h-3.5 w-3.5" />{c.phone}</span>}
                      {c.email && <a href={`mailto:${c.email}`} className="text-sm text-primary-700 hover:underline">{c.email}</a>}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {activeTab === 'addresses' && (
          <DataTable
            data={shipAddresses}
            columns={SHIP_ADDRESS_COLUMNS}
            emptyTitle="No shipping addresses"
            emptyDescription="Add shipping addresses to use on sales orders and invoices."
          />
        )}

        {activeTab === 'sales' && (
          <dl className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-4">
            <Field label="GSTIN" value={customer.gstin} mono />
            <Field label="PAN" value={customer.pan} mono />
            <Field label="GST Type" value={customer.gst_type} />
            <Field label="Credit Days" value={`${customer.credit_days} days`} />
            <Field label="Credit Limit" value={formatCurrency(customer.credit_limit)} />
            <div className="col-span-full border-t border-neutral-100 pt-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-4">
              <Field label="Sales Region" value={customer.sales_region} />
              <Field label="Sales Zone" value={customer.sales_zone} />
              <Field label="Sales Territory" value={customer.sales_territory} />
            </div>
            {customer.payment_terms && (
              <div className="col-span-full">
                <Field label="Payment Terms" value={customer.payment_terms} />
              </div>
            )}
            {customer.notes && (
              <div className="col-span-full">
                <Field label="Notes" value={<p className="whitespace-pre-line">{customer.notes}</p>} />
              </div>
            )}
          </dl>
        )}
      </div>
    </div>
  );
}
