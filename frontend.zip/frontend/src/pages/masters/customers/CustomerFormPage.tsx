import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useForm, useFieldArray } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import toast from 'react-hot-toast';
import { ArrowLeftIcon, PlusIcon, TrashIcon } from '@heroicons/react/24/outline';

import { customersService } from '@/services/customers';
import Button from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import Select from '@/components/ui/Select';
import Textarea from '@/components/ui/Textarea';
import Tabs from '@/components/ui/Tabs';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import { useUnsavedChanges } from '@/hooks/useUnsavedChanges';

const gstinRegex = /^\d{2}[A-Z]{5}\d{4}[A-Z]{1}[A-Z\d]{1}Z[A-Z\d]{1}$/;
const panRegex = /^[A-Z]{5}\d{4}[A-Z]{1}$/;

const shipAddressSchema = z.object({
  id: z.number().optional(),
  label: z.string().min(1, 'Label required'),
  address_line1: z.string().min(1, 'Address required'),
  address_line2: z.string(),
  city: z.string().min(1, 'City required'),
  state: z.string().min(1, 'State required'),
  pincode: z.string().min(1, 'Pincode required'),
  gstin: z.string().regex(gstinRegex, 'Invalid GSTIN').or(z.literal('')),
  contact_person: z.string(),
  phone: z.string(),
  is_default: z.boolean(),
  is_active: z.boolean(),
});

const contactSchema = z.object({
  id: z.number().optional(),
  name: z.string().min(1, 'Name required'),
  designation: z.string(),
  phone: z.string(),
  mobile: z.string(),
  email: z.string().email('Invalid email').or(z.literal('')),
  is_primary: z.boolean(),
});

const customerSchema = z.object({
  code: z.string().min(1, 'Code required').max(20),
  name: z.string().min(1, 'Name required'),
  legal_name: z.string(),
  customer_group: z.string().optional(),
  customer_type: z.enum(['DIRECT', 'DEALER', 'E_COMMERCE', 'INSTITUTIONAL']),
  address_line1: z.string(),
  address_line2: z.string(),
  city: z.string(),
  state: z.string(),
  pincode: z.string(),
  country: z.string(),
  phone: z.string(),
  mobile: z.string(),
  email: z.string().email('Invalid email').or(z.literal('')),
  website: z.string().url('Invalid URL').or(z.literal('')),
  contact_person: z.string(),
  gstin: z.string().regex(gstinRegex, 'Invalid GSTIN').or(z.literal('')),
  pan: z.string().regex(panRegex, 'Invalid PAN').or(z.literal('')),
  gst_type: z.enum(['REGULAR', 'COMPOSITION', 'UNREGISTERED', 'INTERNATIONAL']),
  credit_days: z.coerce.number().min(0),
  credit_limit: z.string(),
  payment_terms: z.string(),
  sales_region: z.string(),
  sales_zone: z.string(),
  sales_territory: z.string(),
  portal_enabled: z.boolean(),
  notes: z.string(),
  contacts: z.array(contactSchema),
  ship_addresses: z.array(shipAddressSchema),
});

type CustomerFormValues = z.infer<typeof customerSchema>;

const CUSTOMER_TYPE_OPTIONS = [
  { value: 'DIRECT', label: 'Direct' },
  { value: 'DEALER', label: 'Dealer' },
  { value: 'E_COMMERCE', label: 'E-Commerce' },
  { value: 'INSTITUTIONAL', label: 'Institutional' },
];
const GST_TYPE_OPTIONS = [
  { value: 'REGULAR', label: 'Regular' },
  { value: 'COMPOSITION', label: 'Composition' },
  { value: 'UNREGISTERED', label: 'Unregistered' },
  { value: 'INTERNATIONAL', label: 'International' },
];
const FORM_TABS = [
  { key: 'general', label: 'General' },
  { key: 'address', label: 'Address' },
  { key: 'statutory', label: 'Statutory & Commercial' },
  { key: 'sales', label: 'Sales Info' },
  { key: 'contacts', label: 'Contacts' },
  { key: 'ship_addresses', label: 'Ship Addresses' },
];

const DEFAULT_VALUES: CustomerFormValues = {
  code: '', name: '', legal_name: '', customer_group: '', customer_type: 'DIRECT',
  address_line1: '', address_line2: '', city: '', state: '', pincode: '', country: 'India',
  phone: '', mobile: '', email: '', website: '', contact_person: '',
  gstin: '', pan: '', gst_type: 'REGULAR',
  credit_days: 30, credit_limit: '0', payment_terms: '',
  sales_region: '', sales_zone: '', sales_territory: '',
  portal_enabled: false, notes: '',
  contacts: [],
  ship_addresses: [],
};

export default function CustomerFormPage() {
  const { id } = useParams<{ id: string }>();
  const isEdit = !!id && id !== 'new';
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [activeTab, setActiveTab] = useState('general');

  const { data: groups = [] } = useQuery({ queryKey: ['customer-groups'], queryFn: customersService.getGroups, staleTime: Infinity });

  const { data: existing, isLoading: loadingExisting } = useQuery({
    queryKey: ['customer', id],
    queryFn: () => customersService.getCustomer(id!),
    enabled: isEdit,
  });

  const {
    register, handleSubmit, reset, control,
    formState: { errors, isDirty, isSubmitting },
  } = useForm<CustomerFormValues>({
    resolver: zodResolver(customerSchema),
    defaultValues: DEFAULT_VALUES,
  });

  useUnsavedChanges(isDirty);

  const { fields: contacts, append: addContact, remove: removeContact } = useFieldArray({ control, name: 'contacts' });
  const { fields: shipAddresses, append: addAddress, remove: removeAddress } = useFieldArray({ control, name: 'ship_addresses' });

  useEffect(() => {
    if (existing) {
      reset({
        ...DEFAULT_VALUES,
        ...existing,
        customer_group: existing.customer_group ? String(existing.customer_group) : '',
        credit_limit: existing.credit_limit ?? '0',
        contacts: existing.contacts ?? [],
        ship_addresses: existing.ship_addresses ?? [],
      });
    }
  }, [existing, reset]);

  const mutation = useMutation({
    mutationFn: (data: CustomerFormValues) => {
      const payload = { ...data, customer_group: data.customer_group ? Number(data.customer_group) : null };
      return isEdit ? customersService.updateCustomer(id!, payload) : customersService.createCustomer(payload);
    },
    onSuccess: saved => {
      qc.invalidateQueries({ queryKey: ['customers'] });
      qc.setQueryData(['customer', saved.id], saved);
      toast.success(isEdit ? 'Customer updated' : 'Customer created');
      navigate(`/masters/customers/${saved.id}`);
    },
    onError: (err: unknown) => {
      const e = err as { response?: { data?: Record<string, string[]> } };
      const msg = e?.response?.data ? Object.values(e.response.data)[0]?.[0] : null;
      toast.error(msg ?? 'Save failed');
    },
  });

  const groupOptions = groups.map(g => ({ value: String(g.id), label: g.name }));

  if (isEdit && loadingExisting) return (
    <div className="flex items-center justify-center h-64">
      <LoadingSpinner size="xl" className="text-primary-600" />
    </div>
  );

  return (
    <div>
      <div className="flex items-center justify-between mb-6 gap-4">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate(-1)} className="p-2 rounded-lg hover:bg-neutral-100 text-neutral-400 transition-colors">
            <ArrowLeftIcon className="h-5 w-5" />
          </button>
          <h1 className="text-xl font-bold text-neutral-900">{isEdit ? 'Edit Customer' : 'New Customer'}</h1>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" type="button" onClick={() => navigate(-1)} disabled={isSubmitting}>Cancel</Button>
          <Button loading={isSubmitting} onClick={handleSubmit(d => mutation.mutate(d))}>
            {isEdit ? 'Save Changes' : 'Create Customer'}
          </Button>
        </div>
      </div>

      <Tabs tabs={FORM_TABS} active={activeTab} onChange={setActiveTab} className="mb-6" />

      <form onSubmit={handleSubmit(d => mutation.mutate(d))} noValidate>
        <div className="card space-y-5">

          {activeTab === 'general' && (
            <>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                <Input label="Customer Code" required error={errors.code?.message} {...register('code')} />
                <Input label="Customer Name" required className="lg:col-span-2" error={errors.name?.message} {...register('name')} />
                <Input label="Legal Name" {...register('legal_name')} />
                <Select label="Customer Type" required options={CUSTOMER_TYPE_OPTIONS} error={errors.customer_type?.message} {...register('customer_type')} />
                <Select label="Customer Group" options={groupOptions} placeholder="Select group" {...register('customer_group')} />
              </div>
              <hr className="border-neutral-100" />
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                <Input label="Contact Person" {...register('contact_person')} />
                <Input label="Phone" {...register('phone')} />
                <Input label="Mobile" {...register('mobile')} />
                <Input label="Email" type="email" error={errors.email?.message} {...register('email')} />
                <Input label="Website" error={errors.website?.message} {...register('website')} placeholder="https://" />
              </div>
              <Textarea label="Notes" rows={3} {...register('notes')} />
            </>
          )}

          {activeTab === 'address' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Input label="Address Line 1" className="sm:col-span-2" {...register('address_line1')} />
              <Input label="Address Line 2" className="sm:col-span-2" {...register('address_line2')} />
              <Input label="City" {...register('city')} />
              <Input label="State" {...register('state')} />
              <Input label="Pincode" maxLength={10} {...register('pincode')} />
              <Input label="Country" {...register('country')} />
            </div>
          )}

          {activeTab === 'statutory' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              <Input label="GSTIN" maxLength={15} error={errors.gstin?.message} {...register('gstin')} placeholder="22AAAAA0000A1Z5" />
              <Input label="PAN" maxLength={10} error={errors.pan?.message} {...register('pan')} placeholder="ABCDE1234F" />
              <Select label="GST Type" options={GST_TYPE_OPTIONS} {...register('gst_type')} />
              <Input label="Credit Days" type="number" min="0" {...register('credit_days')} />
              <Input label="Credit Limit (₹)" type="number" min="0" step="1000" {...register('credit_limit')} />
              <div className="sm:col-span-2 lg:col-span-3">
                <Textarea label="Payment Terms" rows={2} {...register('payment_terms')} />
              </div>
            </div>
          )}

          {activeTab === 'sales' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              <Input label="Sales Region" {...register('sales_region')} />
              <Input label="Sales Zone" {...register('sales_zone')} />
              <Input label="Sales Territory" {...register('sales_territory')} />
              <label className="flex items-center gap-2 cursor-pointer col-span-full">
                <input type="checkbox" className="rounded text-primary-700" {...register('portal_enabled')} />
                <span className="text-sm font-medium text-neutral-700">Enable Customer Portal Access</span>
              </label>
            </div>
          )}

          {activeTab === 'contacts' && (
            <div className="space-y-4">
              {contacts.map((field, i) => (
                <div key={field.id} className="p-4 border border-neutral-100 rounded-lg bg-neutral-50">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-xs font-semibold text-neutral-400 uppercase tracking-wide">Contact {i + 1}</span>
                    <div className="flex items-center gap-3">
                      <label className="flex items-center gap-1.5 text-xs text-neutral-600 cursor-pointer">
                        <input type="checkbox" className="rounded text-primary-700" {...register(`contacts.${i}.is_primary`)} />
                        Primary
                      </label>
                      <button type="button" onClick={() => removeContact(i)} className="text-danger-400 hover:text-danger-600 transition-colors">
                        <TrashIcon className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                    <Input label="Name" required error={errors.contacts?.[i]?.name?.message} {...register(`contacts.${i}.name`)} />
                    <Input label="Designation" {...register(`contacts.${i}.designation`)} />
                    <Input label="Phone" {...register(`contacts.${i}.phone`)} />
                    <Input label="Mobile" {...register(`contacts.${i}.mobile`)} />
                    <Input label="Email" type="email" error={errors.contacts?.[i]?.email?.message} {...register(`contacts.${i}.email`)} />
                  </div>
                </div>
              ))}
              <Button type="button" variant="outline" size="sm" leftIcon={<PlusIcon className="h-4 w-4" />}
                onClick={() => addContact({ name: '', designation: '', phone: '', mobile: '', email: '', is_primary: contacts.length === 0 })}>
                Add Contact
              </Button>
            </div>
          )}

          {activeTab === 'ship_addresses' && (
            <div className="space-y-4">
              {shipAddresses.map((field, i) => (
                <div key={field.id} className="p-4 border border-neutral-100 rounded-lg bg-neutral-50">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-xs font-semibold text-neutral-400 uppercase tracking-wide">
                      Address {i + 1}
                    </span>
                    <div className="flex items-center gap-3">
                      <label className="flex items-center gap-1.5 text-xs text-neutral-600 cursor-pointer">
                        <input type="checkbox" className="rounded text-primary-700" {...register(`ship_addresses.${i}.is_default`)} />
                        Default
                      </label>
                      <button type="button" onClick={() => removeAddress(i)} className="text-danger-400 hover:text-danger-600 transition-colors">
                        <TrashIcon className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                    <Input label="Label" required error={errors.ship_addresses?.[i]?.label?.message}
                      {...register(`ship_addresses.${i}.label`)} placeholder="e.g. Warehouse, Factory" />
                    <Input label="Address Line 1" required className="sm:col-span-2 lg:col-span-2"
                      error={errors.ship_addresses?.[i]?.address_line1?.message}
                      {...register(`ship_addresses.${i}.address_line1`)} />
                    <Input label="Address Line 2" {...register(`ship_addresses.${i}.address_line2`)} />
                    <Input label="City" required error={errors.ship_addresses?.[i]?.city?.message} {...register(`ship_addresses.${i}.city`)} />
                    <Input label="State" required error={errors.ship_addresses?.[i]?.state?.message} {...register(`ship_addresses.${i}.state`)} />
                    <Input label="Pincode" required maxLength={10} error={errors.ship_addresses?.[i]?.pincode?.message} {...register(`ship_addresses.${i}.pincode`)} />
                    <Input label="GSTIN (optional)" maxLength={15} error={errors.ship_addresses?.[i]?.gstin?.message} {...register(`ship_addresses.${i}.gstin`)} />
                    <Input label="Contact Person" {...register(`ship_addresses.${i}.contact_person`)} />
                    <Input label="Phone" {...register(`ship_addresses.${i}.phone`)} />
                  </div>
                </div>
              ))}
              <Button type="button" variant="outline" size="sm" leftIcon={<PlusIcon className="h-4 w-4" />}
                onClick={() => addAddress({
                  label: '', address_line1: '', address_line2: '', city: '', state: '',
                  pincode: '', gstin: '', contact_person: '', phone: '',
                  is_default: shipAddresses.length === 0, is_active: true,
                })}>
                Add Shipping Address
              </Button>
            </div>
          )}
        </div>

        <div className="mt-6 flex justify-end gap-2 pb-4">
          <Button variant="outline" type="button" onClick={() => navigate(-1)} disabled={isSubmitting}>Cancel</Button>
          <Button type="submit" loading={isSubmitting}>{isEdit ? 'Save Changes' : 'Create Customer'}</Button>
        </div>
      </form>
    </div>
  );
}
