/**
 * MLF Billing Admin Page — Monthly License Fee Simulation
 * Task 11 — Part 3.5
 * Only visible to admin/superuser roles.
 */
import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { mlfService } from '@/services/mastersFull';

function StatusBadge({ status }: { status: string }) {
  const map: Record<string, string> = {
    DRAFT: 'bg-gray-100 text-gray-700',
    ISSUED: 'bg-blue-100 text-blue-800',
    PAID: 'bg-green-100 text-green-800',
    OVERDUE: 'bg-red-100 text-red-800',
  };
  return (
    <span className={`px-2 py-0.5 rounded-full text-xs font-semibold ${map[status] || 'bg-gray-100 text-gray-700'}`}>
      {status}
    </span>
  );
}

function formatINR(amount: number) {
  return `₹${Number(amount).toLocaleString('en-IN', { maximumFractionDigits: 2 })}`;
}

export function MLFBillingPage() {
  const qc = useQueryClient();
  const [showUsage, setShowUsage] = useState(false);

  const { data: billingRecords, isLoading } = useQuery({
    queryKey: ['mlf-billing'],
    queryFn: () => mlfService.list(),
  });

  const { data: usageSummary } = useQuery({
    queryKey: ['mlf-usage'],
    queryFn: () => mlfService.usageSummary(),
    enabled: showUsage,
  });

  const generateMutation = useMutation({
    mutationFn: () => mlfService.generateQuarter(),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['mlf-billing'] }),
  });

  const markPaidMutation = useMutation({
    mutationFn: (id: string) => mlfService.markPaid(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['mlf-billing'] }),
  });

  const records = billingRecords?.results ?? billingRecords ?? [];
  const totalBilled = records
    .filter((r: any) => !r.is_free_period)
    .reduce((sum: number, r: any) => sum + Number(r.total_amount), 0);
  const totalPaid = records
    .filter((r: any) => r.status === 'PAID')
    .reduce((sum: number, r: any) => sum + Number(r.total_amount), 0);

  const currentRecord = records[0];
  const nextBillingDate = currentRecord?.period_end
    ? new Date(new Date(currentRecord.period_end).getTime() + 86400000).toISOString().slice(0, 10)
    : 'TBD';

  return (
    <div className="p-6 max-w-5xl">
      {/* Free Year Banner */}
      <div className="bg-gradient-to-r from-blue-700 to-blue-900 text-white rounded-xl p-5 mb-6">
        <div className="flex items-center gap-3">
          <span className="text-3xl">🎁</span>
          <div>
            <h2 className="text-xl font-bold">Monthly License Fee — Year 1 FREE</h2>
            <p className="text-blue-200 mt-0.5">Free subscription period: Apr 2026 – Mar 2027. Year 2 onwards: ₹14,670/month with 7% annual inflation.</p>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-4 gap-4 mb-6">
        {[
          { label: 'Base Rate (Year 2)', value: '₹14,670/mo' },
          { label: 'Annual Inflation', value: '7%' },
          { label: 'Total Billed YTD', value: formatINR(totalBilled) },
          { label: 'Total Paid', value: formatINR(totalPaid) },
        ].map(stat => (
          <div key={stat.label} className="bg-white rounded-xl shadow-sm border border-gray-200 p-4 text-center">
            <div className="text-xl font-bold text-gray-900">{stat.value}</div>
            <div className="text-xs text-gray-500 mt-1">{stat.label}</div>
          </div>
        ))}
      </div>

      {/* Actions */}
      <div className="flex gap-3 mb-6">
        <button
          onClick={() => generateMutation.mutate()}
          disabled={generateMutation.isPending}
          className="px-4 py-2 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 disabled:opacity-50"
        >
          {generateMutation.isPending ? 'Generating...' : '+ Generate Next Quarter'}
        </button>
        <button
          onClick={() => setShowUsage(!showUsage)}
          className="px-4 py-2 border border-gray-300 rounded-lg font-medium hover:bg-gray-50"
        >
          {showUsage ? 'Hide' : 'Show'} Usage Stats
        </button>
      </div>

      {/* Usage Stats Panel */}
      {showUsage && usageSummary && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-5 mb-6">
          <h3 className="font-semibold text-gray-700 mb-4">System Usage</h3>
          <div className="grid grid-cols-3 gap-4 mb-4">
            <div className="bg-blue-50 rounded-lg p-3 text-center">
              <div className="text-2xl font-bold text-blue-700">{usageSummary.active_users_today}</div>
              <div className="text-xs text-gray-500">Active Users Today</div>
            </div>
            <div className="bg-green-50 rounded-lg p-3 text-center">
              <div className="text-2xl font-bold text-green-700">{usageSummary.login_count_this_month}</div>
              <div className="text-xs text-gray-500">Logins This Month</div>
            </div>
            <div className="bg-purple-50 rounded-lg p-3 text-center">
              <div className="text-2xl font-bold text-purple-700">{usageSummary.latest_snapshot?.active_users ?? 0}</div>
              <div className="text-xs text-gray-500">Users (Last Snapshot)</div>
            </div>
          </div>

          {Object.keys(usageSummary.module_transactions ?? {}).length > 0 && (
            <div>
              <h4 className="text-sm font-semibold text-gray-600 mb-2">Module Transactions This Month</h4>
              <div className="grid grid-cols-4 gap-2">
                {Object.entries(usageSummary.module_transactions).map(([module, count]) => (
                  <div key={module} className="bg-gray-50 rounded-lg p-2 text-center">
                    <div className="text-lg font-bold">{String(count)}</div>
                    <div className="text-xs text-gray-500 truncate">{module}</div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Billing Table */}
      {isLoading ? (
        <div className="flex justify-center py-16"><div className="animate-spin rounded-full h-10 w-10 border-b-2 border-blue-600" /></div>
      ) : (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                {['Quarter', 'Period', 'Base Rate', 'Subtotal', 'GST', 'Total', 'Status', 'Due Date', 'Actions'].map(h => (
                  <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {records.length === 0 && (
                <tr><td colSpan={9} className="text-center py-10 text-gray-400">No billing records yet. Click "Generate Next Quarter" to start.</td></tr>
              )}
              {records.map((r: any) => (
                <tr key={r.id} className={r.is_free_period ? 'bg-green-50' : 'hover:bg-gray-50'}>
                  <td className="px-4 py-3 text-sm font-semibold">{r.quarter}</td>
                  <td className="px-4 py-3 text-sm text-gray-500">{r.period_start} – {r.period_end}</td>
                  <td className="px-4 py-3 text-sm">{r.is_free_period ? <span className="text-green-600 font-semibold">FREE</span> : formatINR(r.base_rate)}</td>
                  <td className="px-4 py-3 text-sm">{r.is_free_period ? '—' : formatINR(r.subtotal)}</td>
                  <td className="px-4 py-3 text-sm">{r.is_free_period ? '—' : formatINR(r.gst_amount)}</td>
                  <td className="px-4 py-3 text-sm font-semibold">{r.is_free_period ? '₹0' : formatINR(r.total_amount)}</td>
                  <td className="px-4 py-3"><StatusBadge status={r.status} /></td>
                  <td className="px-4 py-3 text-sm">{r.due_date ?? '—'}</td>
                  <td className="px-4 py-3">
                    {!r.is_free_period && r.status !== 'PAID' && (
                      <button
                        onClick={() => markPaidMutation.mutate(r.id)}
                        disabled={markPaidMutation.isPending}
                        className="text-xs bg-green-600 text-white px-3 py-1 rounded-lg hover:bg-green-700 disabled:opacity-50"
                      >
                        Mark Paid
                      </button>
                    )}
                    {r.status === 'PAID' && (
                      <span className="text-xs text-green-600">Paid {r.paid_date}</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
