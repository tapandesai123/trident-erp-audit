import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import PageHeader from '@/components/ui/PageHeader';
import Badge from '@/components/ui/Badge';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import { webtelService } from '@/services/webtel';

const IRN_BADGE: Record<string, any> = { PENDING: 'warning', GENERATED: 'success', CANCELLED: 'danger', FAILED: 'danger' };
const EWAY_BADGE: Record<string, any> = { ACTIVE: 'success', CANCELLED: 'danger', EXPIRED: 'warning' };

export default function WebtelPage() {
  const [tab, setTab] = useState<'irn' | 'eway' | 'gstr2b'>('irn');
  const qc = useQueryClient();

  const { data: irnData, isLoading: irnLoading } = useQuery({ queryKey: ['irn-requests'], queryFn: () => webtelService.listIRN(), enabled: tab === 'irn' });
  const { data: ewayData, isLoading: ewayLoading } = useQuery({ queryKey: ['eway-bills'], queryFn: () => webtelService.listEway(), enabled: tab === 'eway' });
  const { data: reconData, isLoading: reconLoading } = useQuery({ queryKey: ['gstr2b-recon'], queryFn: () => webtelService.listRecon(), enabled: tab === 'gstr2b' });

  const [syncPeriod, setSyncPeriod] = useState(new Date().toLocaleDateString('en-IN', { month: '2-digit', year: 'numeric' }).replace('/', ''));

  const syncGstr2b = useMutation({
    mutationFn: () => webtelService.fetchGstr2b(syncPeriod),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['gstr2b-recon'] }),
  });
    mutationFn: (id: string) => webtelService.generateIRN(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['irn-requests'] }),
  });
  const cancelIRN = useMutation({
    mutationFn: ({ id, reason }: { id: string; reason: string }) => webtelService.cancelIRN(id, reason),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['irn-requests'] }),
  });

  const irn = Array.isArray(irnData) ? irnData : (irnData as any)?.results || [];
  const eway = Array.isArray(ewayData) ? ewayData : (ewayData as any)?.results || [];
  const recon = Array.isArray(reconData) ? reconData : (reconData as any)?.results || [];

  const isLoading = tab === 'irn' ? irnLoading : tab === 'eway' ? ewayLoading : reconLoading;

  return (
    <div className="space-y-5">
      <PageHeader title="Webtel — GST Integration" subtitle="e-Invoice, e-Way Bill & GST Reconciliation" />
      <div className="flex gap-2 border-b border-neutral-200 items-center justify-between">
        <div className="flex gap-2">
          {[{ k: 'irn', l: 'e-Invoice (IRN)' }, { k: 'eway', l: 'e-Way Bills' }, { k: 'gstr2b', l: 'GSTR-2B Recon' }].map(({ k, l }) => (
            <button key={k} onClick={() => setTab(k as any)}
              className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors ${tab === k ? 'border-primary-600 text-primary-700' : 'border-transparent text-neutral-500 hover:text-neutral-700'}`}>
              {l}
            </button>
          ))}
        </div>
        {tab === 'gstr2b' && (
          <div className="flex items-center gap-2 pb-1">
            <input
              type="text"
              value={syncPeriod}
              onChange={e => setSyncPeriod(e.target.value)}
              placeholder="MMYYYY"
              className="border border-neutral-300 rounded px-2 py-1 text-sm w-24"
            />
            <button
              onClick={() => syncGstr2b.mutate()}
              disabled={syncGstr2b.isPending}
              className="px-3 py-1 bg-primary-600 text-white text-sm rounded hover:bg-primary-700 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {syncGstr2b.isPending ? 'Syncing…' : 'Sync GSTR-2B'}
            </button>
            {syncGstr2b.isError && <span className="text-xs text-danger-600">Sync failed</span>}
            {syncGstr2b.isSuccess && <span className="text-xs text-success-600">Synced!</span>}
          </div>
        )}
      </div>

      {isLoading ? <LoadingSpinner /> : (
        <>
          {tab === 'irn' && (
            <div className="card overflow-hidden">
              <table className="table">
                <thead><tr><th>Invoice No.</th><th>IRN</th><th>Date</th><th>Party</th><th className="text-right">Value (₹)</th><th>Status</th><th>Actions</th></tr></thead>
                <tbody>
                  {irn.length === 0
                    ? <tr><td colSpan={7} className="text-center py-8 text-neutral-400">No IRN requests found.</td></tr>
                    : irn.map((i: any) => (
                      <tr key={i.id} className="hover:bg-neutral-50">
                        <td className="font-mono text-sm">{i.invoice_number}</td>
                        <td className="font-mono text-xs text-neutral-400">{i.irn ? i.irn.slice(0, 20) + '…' : '—'}</td>
                        <td className="text-sm text-neutral-500">{i.invoice_date}</td>
                        <td className="text-sm">{i.party_name}</td>
                        <td className="text-right tabular-nums">₹{Number(i.total_value || 0).toLocaleString('en-IN')}</td>
                        <td><Badge variant={IRN_BADGE[i.status] || 'neutral'}>{i.status}</Badge></td>
                        <td>
                          {i.status === 'PENDING' && <button className="text-xs text-primary-600 hover:underline mr-2" onClick={() => genIRN.mutate(i.id)}>Generate IRN</button>}
                          {i.status === 'GENERATED' && <button className="text-xs text-danger-600 hover:underline" onClick={() => { const r = prompt('Cancellation reason?'); if (r) cancelIRN.mutate({ id: i.id, reason: r }); }}>Cancel</button>}
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          )}
          {tab === 'eway' && (
            <div className="card overflow-hidden">
              <table className="table">
                <thead><tr><th>e-Way Bill No.</th><th>Invoice No.</th><th>Party</th><th className="text-right">Value (₹)</th><th>Valid Until</th><th>Distance (km)</th><th>Status</th></tr></thead>
                <tbody>
                  {eway.length === 0
                    ? <tr><td colSpan={7} className="text-center py-8 text-neutral-400">No e-Way bills found.</td></tr>
                    : eway.map((e: any) => (
                      <tr key={e.id} className="hover:bg-neutral-50">
                        <td className="font-mono text-sm">{e.eway_bill_number || e.ewb_number}</td>
                        <td className="font-mono text-xs">{e.invoice_number}</td>
                        <td className="text-sm">{e.party_name}</td>
                        <td className="text-right tabular-nums">₹{Number(e.total_value || 0).toLocaleString('en-IN')}</td>
                        <td className="text-sm">{e.valid_until || e.ewb_validity}</td>
                        <td className="text-center">{e.distance || '—'}</td>
                        <td><Badge variant={EWAY_BADGE[e.status] || 'neutral'}>{e.status}</Badge></td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          )}
          {tab === 'gstr2b' && (
            <div className="card overflow-hidden">
              <table className="table">
                <thead><tr><th>Vendor</th><th>GSTIN</th><th>Invoice No.</th><th>Date</th><th className="text-right">Taxable Value</th><th className="text-right">Tax</th><th>Match</th></tr></thead>
                <tbody>
                  {recon.length === 0
                    ? <tr><td colSpan={7} className="text-center py-8 text-neutral-400">No 2B reconciliation data. Import GSTR-2B to start.</td></tr>
                    : recon.map((r: any) => (
                      <tr key={r.id} className="hover:bg-neutral-50">
                        <td className="text-sm font-medium">{r.vendor_name}</td>
                        <td className="font-mono text-xs">{r.gstin}</td>
                        <td className="text-sm">{r.invoice_number}</td>
                        <td className="text-sm text-neutral-400">{r.invoice_date}</td>
                        <td className="text-right tabular-nums">₹{Number(r.taxable_value || 0).toLocaleString('en-IN')}</td>
                        <td className="text-right tabular-nums">₹{Number(r.tax_amount || 0).toLocaleString('en-IN')}</td>
                        <td><Badge variant={r.match_status === 'MATCHED' ? 'success' : r.match_status === 'MISMATCH' ? 'danger' : 'warning'}>{r.match_status || 'PENDING'}</Badge></td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          )}
        </>
      )}
    </div>
  );
}
