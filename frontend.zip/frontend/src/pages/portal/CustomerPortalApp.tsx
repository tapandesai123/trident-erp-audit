/**
 * Customer Portal App — Trident ERP
 * Task 14 — Standalone portal with NO ERP sidebar/header.
 * Routes: /portal/login, /portal/otp, /portal/dashboard,
 *         /portal/orders, /portal/orders/new, /portal/orders/:soNumber,
 *         /portal/invoices, /portal/outstanding, /portal/complaints
 */
import React, { useState, useEffect, createContext, useContext } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import axios from 'axios';

// ─── Portal API Client ─────────────────────────────────────────────

const portalApi = axios.create({ baseURL: '/api/portal/' });

// In-memory token storage — never use localStorage (XSS risk, BUG-020)
let _inMemoryToken: string | null = null;

portalApi.interceptors.request.use((config) => {
  if (_inMemoryToken) config.headers.Authorization = `Bearer ${_inMemoryToken}`;
  return config;
});

const portalService = {
  login: (email: string, password: string) =>
    portalApi.post('auth/login/', { email, password }).then(r => r.data),
  requestOTP: (email: string) =>
    portalApi.post('auth/request-otp/', { email }).then(r => r.data),
  verifyOTP: (email: string, otp: string) =>
    portalApi.post('auth/verify-otp/', { email, otp }).then(r => r.data),
  orders: () => portalApi.get('orders/').then(r => r.data),
  orderDetail: (soNumber: string) => portalApi.get(`orders/${soNumber}/`).then(r => r.data),
  createOrder: (data: any) => portalApi.post('orders/', data).then(r => r.data),
  invoices: () => portalApi.get('invoices/').then(r => r.data),
  outstanding: () => portalApi.get('outstanding/').then(r => r.data),
  complaints: () => portalApi.get('complaints/').then(r => r.data),
  createComplaint: (data: any) => portalApi.post('complaints/', data).then(r => r.data),
};

// ─── Auth Context ─────────────────────────────────────────────────

interface PortalAuth {
  token: string | null;
  customerName: string | null;
  login: (token: string, customerName: string) => void;
  logout: () => void;
}

const PortalAuthContext = createContext<PortalAuth>({
  token: null,
  customerName: null,
  login: () => {},
  logout: () => {},
});

const usePortalAuth = () => useContext(PortalAuthContext);

function PortalAuthProvider({ children }: { children: React.ReactNode }) {
  const [token, setToken] = useState<string | null>(null); // memory only — no localStorage
  const [customerName, setCustomerName] = useState<string | null>(null);

  const login = (tok: string, name: string) => {
    _inMemoryToken = tok; // keep in sync for axios interceptor
    setToken(tok);
    setCustomerName(name);
  };

  const logout = () => {
    _inMemoryToken = null;
    setToken(null);
    setCustomerName(null);
  };

  return (
    <PortalAuthContext.Provider value={{ token, customerName, login, logout }}>
      {children}
    </PortalAuthContext.Provider>
  );
}

// ─── Tiny Router ─────────────────────────────────────────────────

function usePortalRoute() {
  const [path, setPath] = useState(window.location.pathname);

  useEffect(() => {
    const handle = () => setPath(window.location.pathname);
    window.addEventListener('popstate', handle);
    return () => window.removeEventListener('popstate', handle);
  }, []);

  const navigate = (to: string) => {
    window.history.pushState({}, '', to);
    setPath(to);
  };

  return { path, navigate };
}

// ─── UI Helpers ──────────────────────────────────────────────────

function PortalLayout({ children, title }: { children: React.ReactNode; title?: string }) {
  const { customerName, logout } = usePortalAuth();
  const { navigate } = usePortalRoute();

  const navItems = [
    { label: 'Dashboard', path: '/portal/dashboard' },
    { label: 'My Orders', path: '/portal/orders' },
    { label: 'Invoices', path: '/portal/invoices' },
    { label: 'Outstanding', path: '/portal/outstanding' },
    { label: 'Complaints', path: '/portal/complaints' },
  ];

  return (
    <div style={{ minHeight: '100vh', background: '#f1f5f9', fontFamily: 'Inter, system-ui, sans-serif' }}>
      {/* Topbar */}
      <header style={{
        background: '#1e3a5f', color: '#fff', padding: '0 24px',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between', height: 56,
        boxShadow: '0 2px 8px rgba(0,0,0,0.2)',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 32 }}>
          <span style={{ fontWeight: 700, fontSize: 18, letterSpacing: '-0.5px' }}>
            🏭 Trident Portal
          </span>
          <nav style={{ display: 'flex', gap: 4 }}>
            {navItems.map(item => (
              <button
                key={item.path}
                onClick={() => navigate(item.path)}
                style={{
                  background: window.location.pathname.startsWith(item.path) ? 'rgba(255,255,255,0.15)' : 'transparent',
                  border: 'none', color: '#fff', padding: '6px 14px', borderRadius: 6,
                  cursor: 'pointer', fontSize: 14, fontWeight: 500,
                }}
              >
                {item.label}
              </button>
            ))}
          </nav>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <span style={{ fontSize: 14, opacity: 0.85 }}>👤 {customerName}</span>
          <button
            onClick={logout}
            style={{ background: 'rgba(255,255,255,0.15)', border: 'none', color: '#fff',
              padding: '6px 14px', borderRadius: 6, cursor: 'pointer', fontSize: 13 }}
          >
            Logout
          </button>
        </div>
      </header>

      {/* Content */}
      <main style={{ maxWidth: 1200, margin: '0 auto', padding: '24px 16px' }}>
        {title && (
          <h1 style={{ fontSize: 22, fontWeight: 700, color: '#1e293b', marginBottom: 20 }}>
            {title}
          </h1>
        )}
        {children}
      </main>
    </div>
  );
}

function Card({ children, style }: { children: React.ReactNode; style?: React.CSSProperties }) {
  return (
    <div style={{
      background: '#fff', borderRadius: 12, padding: 20,
      boxShadow: '0 1px 4px rgba(0,0,0,0.08)', border: '1px solid #e2e8f0',
      ...style,
    }}>
      {children}
    </div>
  );
}

function SummaryCard({ label, value, color }: { label: string; value: string | number; color?: string }) {
  return (
    <Card style={{ textAlign: 'center', flex: 1 }}>
      <div style={{ fontSize: 28, fontWeight: 700, color: color || '#1e3a5f' }}>{value}</div>
      <div style={{ fontSize: 13, color: '#64748b', marginTop: 4 }}>{label}</div>
    </Card>
  );
}

function Badge({ text, type }: { text: string; type?: 'success' | 'warning' | 'danger' | 'info' | 'default' }) {
  const colors: Record<string, { bg: string; color: string }> = {
    success: { bg: '#dcfce7', color: '#166534' },
    warning: { bg: '#fef9c3', color: '#92400e' },
    danger: { bg: '#fee2e2', color: '#991b1b' },
    info: { bg: '#dbeafe', color: '#1e40af' },
    default: { bg: '#f1f5f9', color: '#475569' },
  };
  const c = colors[type || 'default'];
  return (
    <span style={{
      background: c.bg, color: c.color, padding: '2px 10px',
      borderRadius: 99, fontSize: 12, fontWeight: 600,
    }}>
      {text}
    </span>
  );
}

function Spinner() {
  return <div style={{ textAlign: 'center', padding: 40, color: '#64748b' }}>Loading…</div>;
}

function Alert({ msg, type }: { msg: string; type: 'error' | 'success' }) {
  return (
    <div style={{
      padding: '10px 16px', borderRadius: 8, marginBottom: 12,
      background: type === 'error' ? '#fee2e2' : '#dcfce7',
      color: type === 'error' ? '#991b1b' : '#166534',
      fontSize: 14,
    }}>
      {msg}
    </div>
  );
}

function Input({ label, ...props }: { label: string } & React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <div style={{ marginBottom: 14 }}>
      <label style={{ display: 'block', fontSize: 13, fontWeight: 600, color: '#374151', marginBottom: 4 }}>
        {label}
      </label>
      <input
        {...props}
        style={{
          width: '100%', padding: '8px 12px', border: '1px solid #d1d5db',
          borderRadius: 8, fontSize: 14, outline: 'none', boxSizing: 'border-box',
        }}
      />
    </div>
  );
}

function Btn({ children, onClick, variant = 'primary', disabled, style }: any) {
  const styles: Record<string, React.CSSProperties> = {
    primary: { background: '#1e3a5f', color: '#fff', border: 'none' },
    outline: { background: '#fff', color: '#1e3a5f', border: '1px solid #1e3a5f' },
    danger: { background: '#dc2626', color: '#fff', border: 'none' },
  };
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      style={{
        padding: '9px 18px', borderRadius: 8, cursor: disabled ? 'not-allowed' : 'pointer',
        fontSize: 14, fontWeight: 600, opacity: disabled ? 0.6 : 1,
        ...styles[variant], ...style,
      }}
    >
      {children}
    </button>
  );
}

function statusBadgeType(status: string) {
  const map: Record<string, any> = {
    DRAFT: 'default', CONFIRMED: 'info', IN_PRODUCTION: 'info',
    READY: 'success', PARTIALLY_DESPATCHED: 'warning',
    FULLY_DESPATCHED: 'success', INVOICED: 'success',
    ON_HOLD: 'warning', CANCELLED: 'danger',
    PAID: 'success', PAYMENT_PENDING: 'warning', CONFIRMED_INV: 'info',
    OPEN: 'warning', RESOLVED: 'success', CLOSED: 'default',
  };
  return map[status] || 'default';
}

function fmtINR(n: number) {
  return '₹' + Number(n).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

// ═══════════════════════════════════════════════════════════════════
// PAGES
// ═══════════════════════════════════════════════════════════════════

// ── Login Page ────────────────────────────────────────────────────
function LoginPage() {
  const { login } = usePortalAuth();
  const { navigate } = usePortalRoute();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const { mutate, isPending } = useMutation({
    mutationFn: () => portalService.login(email, password),
    onSuccess: (data: any) => {
      login(data.access, data.customer_name);
      navigate('/portal/dashboard');
    },
    onError: (e: any) => setError(e.response?.data?.detail || 'Login failed.'),
  });

  return (
    <div style={{
      minHeight: '100vh', background: '#1e3a5f',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
    }}>
      <div style={{ width: 400 }}>
        <div style={{ textAlign: 'center', marginBottom: 28 }}>
          <div style={{ fontSize: 36, marginBottom: 8 }}>🏭</div>
          <h1 style={{ color: '#fff', fontSize: 22, fontWeight: 700, margin: 0 }}>Trident Customer Portal</h1>
          <p style={{ color: 'rgba(255,255,255,0.65)', fontSize: 14, marginTop: 6 }}>Sign in to manage your orders</p>
        </div>
        <Card>
          {error && <Alert msg={error} type="error" />}
          <Input label="Email" type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="you@company.com" />
          <Input label="Password" type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="••••••••" />
          <Btn onClick={() => mutate()} disabled={isPending} style={{ width: '100%', marginTop: 4 }}>
            {isPending ? 'Signing in…' : 'Sign In'}
          </Btn>
          <div style={{ textAlign: 'center', marginTop: 14 }}>
            <button
              onClick={() => navigate('/portal/otp')}
              style={{ background: 'none', border: 'none', color: '#1e3a5f', cursor: 'pointer', fontSize: 13 }}
            >
              Sign in with OTP instead →
            </button>
          </div>
        </Card>
      </div>
    </div>
  );
}

// ── OTP Page ─────────────────────────────────────────────────────
function OTPPage() {
  const { login } = usePortalAuth();
  const { navigate } = usePortalRoute();
  const [step, setStep] = useState<'email' | 'otp'>('email');
  const [email, setEmail] = useState('');
  const [otp, setOtp] = useState('');
  const [error, setError] = useState('');
  const [info, setInfo] = useState('');

  const requestMut = useMutation({
    mutationFn: () => portalService.requestOTP(email),
    onSuccess: () => { setStep('otp'); setInfo('OTP sent to your email. Check your inbox.'); },
    onError: () => { setStep('otp'); setInfo('OTP sent if email is registered.'); },
  });

  const verifyMut = useMutation({
    mutationFn: () => portalService.verifyOTP(email, otp),
    onSuccess: (data: any) => { login(data.access, data.customer_name); navigate('/portal/dashboard'); },
    onError: (e: any) => setError(e.response?.data?.detail || 'Invalid OTP.'),
  });

  return (
    <div style={{
      minHeight: '100vh', background: '#1e3a5f',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
    }}>
      <div style={{ width: 400 }}>
        <div style={{ textAlign: 'center', marginBottom: 28 }}>
          <div style={{ fontSize: 36, marginBottom: 8 }}>🔐</div>
          <h1 style={{ color: '#fff', fontSize: 22, fontWeight: 700, margin: 0 }}>OTP Login</h1>
          <p style={{ color: 'rgba(255,255,255,0.65)', fontSize: 14, marginTop: 6 }}>Passwordless sign-in</p>
        </div>
        <Card>
          {error && <Alert msg={error} type="error" />}
          {info && <Alert msg={info} type="success" />}
          {step === 'email' ? (
            <>
              <Input label="Email" type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="you@company.com" />
              <Btn onClick={() => requestMut.mutate()} disabled={requestMut.isPending} style={{ width: '100%' }}>
                {requestMut.isPending ? 'Sending…' : 'Send OTP'}
              </Btn>
            </>
          ) : (
            <>
              <p style={{ color: '#374151', marginBottom: 12, fontSize: 14 }}>Enter the 6-digit OTP sent to <strong>{email}</strong></p>
              <Input label="OTP" type="text" value={otp} onChange={e => setOtp(e.target.value)} maxLength={6} placeholder="123456" />
              <Btn onClick={() => verifyMut.mutate()} disabled={verifyMut.isPending} style={{ width: '100%' }}>
                {verifyMut.isPending ? 'Verifying…' : 'Verify OTP'}
              </Btn>
            </>
          )}
          <div style={{ textAlign: 'center', marginTop: 12 }}>
            <button
              onClick={() => navigate('/portal/login')}
              style={{ background: 'none', border: 'none', color: '#1e3a5f', cursor: 'pointer', fontSize: 13 }}
            >
              ← Back to password login
            </button>
          </div>
        </Card>
      </div>
    </div>
  );
}

// ── Dashboard ─────────────────────────────────────────────────────
function DashboardPage() {
  const { navigate } = usePortalRoute();
  const { data: orders, isLoading: oLoading } = useQuery({ queryKey: ['portal-orders'], queryFn: portalService.orders });
  const { data: outstanding, isLoading: uLoading } = useQuery({ queryKey: ['portal-outstanding'], queryFn: portalService.outstanding });
  const { data: complaints, isLoading: cLoading } = useQuery({ queryKey: ['portal-complaints'], queryFn: portalService.complaints });

  const openOrders = Array.isArray(orders) ? orders.filter((o: any) => !['INVOICED', 'FULLY_DESPATCHED'].includes(o.status)).length : 0;
  const pendingAmount = outstanding?.total_outstanding ?? 0;
  const activeComplaints = Array.isArray(complaints) ? complaints.filter((c: any) => !['RESOLVED', 'CLOSED'].includes(c.status)).length : 0;

  return (
    <PortalLayout title="Dashboard">
      <div style={{ display: 'flex', gap: 16, marginBottom: 28 }}>
        <SummaryCard label="Open Orders" value={oLoading ? '…' : openOrders} color="#1e3a5f" />
        <SummaryCard label="Pending Amount" value={uLoading ? '…' : fmtINR(pendingAmount)} color="#dc2626" />
        <SummaryCard label="Active Complaints" value={cLoading ? '…' : activeComplaints} color="#d97706" />
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
        <Card>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
            <h3 style={{ margin: 0, fontSize: 15, fontWeight: 700, color: '#1e293b' }}>Recent Orders</h3>
            <Btn onClick={() => navigate('/portal/orders')} variant="outline" style={{ fontSize: 12, padding: '4px 12px' }}>View All</Btn>
          </div>
          {oLoading ? <Spinner /> : (
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
              <thead>
                <tr style={{ borderBottom: '1px solid #e2e8f0' }}>
                  <th style={{ textAlign: 'left', padding: '4px 8px', color: '#64748b' }}>SO #</th>
                  <th style={{ textAlign: 'left', padding: '4px 8px', color: '#64748b' }}>Status</th>
                  <th style={{ textAlign: 'right', padding: '4px 8px', color: '#64748b' }}>Amount</th>
                </tr>
              </thead>
              <tbody>
                {(orders as any[] || []).slice(0, 5).map((o: any) => (
                  <tr key={o.so_number} style={{ borderBottom: '1px solid #f1f5f9', cursor: 'pointer' }}
                    onClick={() => navigate(`/portal/orders/${o.so_number}`)}>
                    <td style={{ padding: '6px 8px', fontWeight: 600 }}>{o.so_number}</td>
                    <td style={{ padding: '6px 8px' }}><Badge text={o.status} type={statusBadgeType(o.status)} /></td>
                    <td style={{ padding: '6px 8px', textAlign: 'right' }}>{fmtINR(o.total_amount)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </Card>

        <Card>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
            <h3 style={{ margin: 0, fontSize: 15, fontWeight: 700, color: '#1e293b' }}>Ageing Summary</h3>
            <Btn onClick={() => navigate('/portal/outstanding')} variant="outline" style={{ fontSize: 12, padding: '4px 12px' }}>Details</Btn>
          </div>
          {uLoading ? <Spinner /> : outstanding ? (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {Object.entries(outstanding.ageing || {}).map(([key, val]: any) => (
                <div key={key} style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0', borderBottom: '1px solid #f1f5f9', fontSize: 13 }}>
                  <span style={{ color: '#64748b', textTransform: 'capitalize' }}>{key.replace(/_/g, ' ')}</span>
                  <span style={{ fontWeight: 600, color: val > 0 ? '#dc2626' : '#16a34a' }}>{fmtINR(val)}</span>
                </div>
              ))}
            </div>
          ) : null}
        </Card>
      </div>
    </PortalLayout>
  );
}

// ── Orders List ───────────────────────────────────────────────────
function OrdersPage() {
  const { navigate } = usePortalRoute();
  const { data: orders, isLoading } = useQuery({ queryKey: ['portal-orders'], queryFn: portalService.orders });

  return (
    <PortalLayout title="My Orders">
      <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 16 }}>
        <Btn onClick={() => navigate('/portal/orders/new')}>+ New Order</Btn>
      </div>
      <Card>
        {isLoading ? <Spinner /> : (
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 14 }}>
            <thead>
              <tr style={{ borderBottom: '2px solid #e2e8f0', textAlign: 'left' }}>
                {['SO Number', 'Date', 'PO Ref', 'Items', 'Total Amount', 'Delivery Date', 'Status', ''].map(h => (
                  <th key={h} style={{ padding: '8px 10px', color: '#64748b', fontWeight: 600, fontSize: 12 }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {(orders as any[] || []).length === 0 ? (
                <tr><td colSpan={8} style={{ textAlign: 'center', padding: 32, color: '#94a3b8' }}>No orders found.</td></tr>
              ) : (orders as any[]).map((o: any) => (
                <tr key={o.so_number} style={{ borderBottom: '1px solid #f1f5f9' }}>
                  <td style={{ padding: '10px', fontWeight: 600, color: '#1e3a5f' }}>{o.so_number}</td>
                  <td style={{ padding: '10px', color: '#64748b' }}>{o.so_date}</td>
                  <td style={{ padding: '10px', color: '#64748b' }}>{o.customer_po_number || '—'}</td>
                  <td style={{ padding: '10px', color: '#64748b' }}>{o.items_count}</td>
                  <td style={{ padding: '10px', fontWeight: 600 }}>{fmtINR(o.total_amount)}</td>
                  <td style={{ padding: '10px', color: '#64748b' }}>{o.delivery_date || '—'}</td>
                  <td style={{ padding: '10px' }}><Badge text={o.status} type={statusBadgeType(o.status)} /></td>
                  <td style={{ padding: '10px' }}>
                    <Btn onClick={() => navigate(`/portal/orders/${o.so_number}`)} variant="outline" style={{ fontSize: 12, padding: '4px 10px' }}>
                      Details →
                    </Btn>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </Card>
    </PortalLayout>
  );
}

// ── New Order ─────────────────────────────────────────────────────
function NewOrderPage() {
  const { navigate } = usePortalRoute();
  const qc = useQueryClient();
  const [po, setPO] = useState('');
  const [deliveryDate, setDeliveryDate] = useState('');
  const [remarks, setRemarks] = useState('');
  const [lines, setLines] = useState([{ description: '', qty: '', unit_rate: '', required_date: '' }]);
  const [error, setError] = useState('');

  const addLine = () => setLines([...lines, { description: '', qty: '', unit_rate: '', required_date: '' }]);
  const updateLine = (i: number, key: string, val: string) => {
    const updated = [...lines];
    (updated[i] as any)[key] = val;
    setLines(updated);
  };

  const { mutate, isPending } = useMutation({
    mutationFn: () => portalService.createOrder({
      customer_po_number: po,
      required_delivery_date: deliveryDate || undefined,
      remarks,
      lines: lines.map(l => ({
        description: l.description,
        qty: parseFloat(l.qty) || 0,
        unit_rate: parseFloat(l.unit_rate) || 0,
        required_date: l.required_date || undefined,
      })),
    }),
    onSuccess: (data: any) => {
      qc.invalidateQueries({ queryKey: ['portal-orders'] });
      navigate(`/portal/orders/${data.so_number}`);
    },
    onError: (e: any) => setError(e.response?.data?.detail || JSON.stringify(e.response?.data)),
  });

  return (
    <PortalLayout title="Place New Order">
      {error && <Alert msg={error} type="error" />}
      <Card style={{ marginBottom: 16 }}>
        <h3 style={{ margin: '0 0 14px', fontSize: 15, fontWeight: 700 }}>Order Details</h3>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 12 }}>
          <Input label="Your PO Number" value={po} onChange={e => setPO(e.target.value)} placeholder="Optional" />
          <Input label="Required Delivery Date" type="date" value={deliveryDate} onChange={e => setDeliveryDate(e.target.value)} />
          <Input label="Remarks" value={remarks} onChange={e => setRemarks(e.target.value)} placeholder="Optional" />
        </div>
      </Card>

      <Card style={{ marginBottom: 16 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
          <h3 style={{ margin: 0, fontSize: 15, fontWeight: 700 }}>Order Lines</h3>
          <Btn onClick={addLine} variant="outline" style={{ fontSize: 12 }}>+ Add Line</Btn>
        </div>
        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
          <thead>
            <tr style={{ borderBottom: '1px solid #e2e8f0' }}>
              {['#', 'Description', 'Qty', 'Unit Rate (₹)', 'Required Date'].map(h => (
                <th key={h} style={{ textAlign: 'left', padding: '6px 8px', color: '#64748b', fontSize: 12 }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {lines.map((line, i) => (
              <tr key={i} style={{ borderBottom: '1px solid #f8fafc' }}>
                <td style={{ padding: '6px 8px', color: '#64748b', width: 32 }}>{i + 1}</td>
                <td style={{ padding: '4px 8px' }}>
                  <input value={line.description} onChange={e => updateLine(i, 'description', e.target.value)}
                    style={{ width: '100%', padding: '6px 8px', border: '1px solid #e2e8f0', borderRadius: 6, fontSize: 13 }}
                    placeholder="Item description" />
                </td>
                <td style={{ padding: '4px 8px' }}>
                  <input value={line.qty} onChange={e => updateLine(i, 'qty', e.target.value)} type="number"
                    style={{ width: 90, padding: '6px 8px', border: '1px solid #e2e8f0', borderRadius: 6, fontSize: 13 }} />
                </td>
                <td style={{ padding: '4px 8px' }}>
                  <input value={line.unit_rate} onChange={e => updateLine(i, 'unit_rate', e.target.value)} type="number"
                    style={{ width: 100, padding: '6px 8px', border: '1px solid #e2e8f0', borderRadius: 6, fontSize: 13 }} />
                </td>
                <td style={{ padding: '4px 8px' }}>
                  <input value={line.required_date} onChange={e => updateLine(i, 'required_date', e.target.value)} type="date"
                    style={{ padding: '6px 8px', border: '1px solid #e2e8f0', borderRadius: 6, fontSize: 13 }} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>

      <div style={{ display: 'flex', gap: 12 }}>
        <Btn onClick={() => mutate()} disabled={isPending}>
          {isPending ? 'Placing Order…' : 'Place Order'}
        </Btn>
        <Btn onClick={() => navigate('/portal/orders')} variant="outline">Cancel</Btn>
      </div>
    </PortalLayout>
  );
}

// ── Order Detail ──────────────────────────────────────────────────
function OrderDetailPage({ soNumber }: { soNumber: string }) {
  const { navigate } = usePortalRoute();
  const { data, isLoading, error } = useQuery({
    queryKey: ['portal-order', soNumber],
    queryFn: () => portalService.orderDetail(soNumber),
  });

  if (isLoading) return <PortalLayout title="Order Detail"><Spinner /></PortalLayout>;
  if (error || !data) return <PortalLayout title="Order Detail"><Alert msg="Order not found." type="error" /></PortalLayout>;

  const so = data as any;
  const despatches: any[] = so.despatches || [];

  return (
    <PortalLayout title={`Order: ${so.so_number}`}>
      <Btn onClick={() => navigate('/portal/orders')} variant="outline" style={{ marginBottom: 16, fontSize: 12 }}>
        ← Back to Orders
      </Btn>

      <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 16, marginBottom: 16 }}>
        <Card>
          <h3 style={{ margin: '0 0 12px', fontSize: 15, fontWeight: 700 }}>Order Info</h3>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, fontSize: 13 }}>
            {[
              ['SO Number', so.so_number],
              ['Date', so.so_date],
              ['Status', <Badge text={so.status} type={statusBadgeType(so.status)} />],
              ['PO Reference', so.customer_po_number || '—'],
              ['Delivery Date', so.required_delivery_date || '—'],
              ['Total Amount', fmtINR(so.total_amount)],
            ].map(([label, val]) => (
              <div key={label as string}>
                <div style={{ color: '#64748b', fontSize: 11, marginBottom: 2 }}>{label}</div>
                <div style={{ fontWeight: 600, color: '#1e293b' }}>{val}</div>
              </div>
            ))}
          </div>
          {so.remarks && <p style={{ margin: '12px 0 0', fontSize: 13, color: '#64748b' }}>Remarks: {so.remarks}</p>}
        </Card>

        <Card>
          <h3 style={{ margin: '0 0 12px', fontSize: 15, fontWeight: 700 }}>Despatch Tracking</h3>
          {despatches.length === 0 ? (
            <p style={{ color: '#94a3b8', fontSize: 13 }}>No despatches yet.</p>
          ) : despatches.map((d: any, i: number) => (
            <div key={d.dc_number} style={{
              display: 'flex', gap: 10, paddingBottom: 12,
              borderBottom: i < despatches.length - 1 ? '1px solid #f1f5f9' : 'none', marginBottom: 8,
            }}>
              <div style={{
                width: 28, height: 28, borderRadius: '50%', flexShrink: 0,
                background: d.reached ? '#16a34a' : d.gate_out_time ? '#3b82f6' : '#e2e8f0',
                display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12, color: '#fff',
              }}>
                {d.reached ? '✓' : d.gate_out_time ? '🚚' : '⏳'}
              </div>
              <div style={{ fontSize: 12 }}>
                <div style={{ fontWeight: 600 }}>{d.dc_number}</div>
                <div style={{ color: '#64748b' }}>{d.date}</div>
                {d.vehicle_number && <div style={{ color: '#64748b' }}>Vehicle: {d.vehicle_number}</div>}
                {d.driver_phone && <div style={{ color: '#64748b' }}>Driver: {d.driver_phone}</div>}
                {d.gate_out_time && <div style={{ color: '#3b82f6' }}>Gate out: {new Date(d.gate_out_time).toLocaleString('en-IN')}</div>}
                <Badge text={d.status} type={d.status === 'DELIVERED' ? 'success' : d.status === 'GATE_OUT' ? 'info' : 'default'} />
              </div>
            </div>
          ))}
        </Card>
      </div>

      <Card>
        <h3 style={{ margin: '0 0 12px', fontSize: 15, fontWeight: 700 }}>Order Lines</h3>
        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
          <thead>
            <tr style={{ borderBottom: '1px solid #e2e8f0', textAlign: 'left' }}>
              {['#', 'Description', 'Ordered Qty', 'Despatched', 'Pending', 'Rate', 'Total'].map(h => (
                <th key={h} style={{ padding: '6px 10px', color: '#64748b', fontSize: 12 }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {(so.lines || []).map((l: any) => (
              <tr key={l.line_no} style={{ borderBottom: '1px solid #f8fafc' }}>
                <td style={{ padding: '8px 10px', color: '#64748b' }}>{l.line_no}</td>
                <td style={{ padding: '8px 10px', fontWeight: 500 }}>{l.description}</td>
                <td style={{ padding: '8px 10px' }}>{l.ordered_qty}</td>
                <td style={{ padding: '8px 10px', color: '#16a34a' }}>{l.despatched_qty}</td>
                <td style={{ padding: '8px 10px', color: l.pending_qty > 0 ? '#d97706' : '#16a34a' }}>{l.pending_qty}</td>
                <td style={{ padding: '8px 10px' }}>{fmtINR(l.unit_rate)}</td>
                <td style={{ padding: '8px 10px', fontWeight: 600 }}>{fmtINR(l.line_total)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </PortalLayout>
  );
}

// ── Invoices Page ─────────────────────────────────────────────────
function InvoicesPage() {
  const { data: invoices, isLoading } = useQuery({ queryKey: ['portal-invoices'], queryFn: portalService.invoices });

  const handleDownload = (inv: any) => {
    const url = `/api/portal/invoices/${inv.id}/pdf/`;
    const a = document.createElement('a');
    a.href = url;
    // Token is in-memory only (no localStorage) — handled by axios interceptor
    window.open(url, '_blank');
  };

  return (
    <PortalLayout title="Invoices">
      <Card>
        {isLoading ? <Spinner /> : (
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 14 }}>
            <thead>
              <tr style={{ borderBottom: '2px solid #e2e8f0', textAlign: 'left' }}>
                {['Invoice #', 'Date', 'Total Amount', 'Outstanding', 'IRN', 'Status', ''].map(h => (
                  <th key={h} style={{ padding: '8px 10px', color: '#64748b', fontWeight: 600, fontSize: 12 }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {(invoices as any[] || []).length === 0 ? (
                <tr><td colSpan={7} style={{ textAlign: 'center', padding: 32, color: '#94a3b8' }}>No invoices found.</td></tr>
              ) : (invoices as any[]).map((inv: any) => (
                <tr key={inv.invoice_number} style={{ borderBottom: '1px solid #f1f5f9' }}>
                  <td style={{ padding: '10px', fontWeight: 600, color: '#1e3a5f' }}>{inv.invoice_number}</td>
                  <td style={{ padding: '10px', color: '#64748b' }}>{inv.date}</td>
                  <td style={{ padding: '10px', fontWeight: 600 }}>{fmtINR(inv.total_amount)}</td>
                  <td style={{ padding: '10px', color: inv.outstanding_amount > 0 ? '#dc2626' : '#16a34a', fontWeight: 600 }}>
                    {fmtINR(inv.outstanding_amount)}
                  </td>
                  <td style={{ padding: '10px', fontSize: 11, color: '#64748b', fontFamily: 'monospace' }}>
                    {inv.irn ? inv.irn.slice(0, 12) + '…' : '—'}
                  </td>
                  <td style={{ padding: '10px' }}>
                    {inv.is_paid ? <Badge text="Paid" type="success" /> : <Badge text={inv.status} type={statusBadgeType(inv.status)} />}
                  </td>
                  <td style={{ padding: '10px' }}>
                    <Btn onClick={() => handleDownload(inv)} variant="outline" style={{ fontSize: 12, padding: '4px 10px' }}>
                      ⬇ PDF
                    </Btn>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </Card>
    </PortalLayout>
  );
}

// ── Outstanding ───────────────────────────────────────────────────
function OutstandingPage() {
  const { data, isLoading } = useQuery({ queryKey: ['portal-outstanding'], queryFn: portalService.outstanding });

  if (isLoading) return <PortalLayout title="Outstanding"><Spinner /></PortalLayout>;

  const od = data as any;
  const ageing = od?.ageing || {};

  return (
    <PortalLayout title="Outstanding Dues">
      <div style={{ display: 'flex', gap: 12, marginBottom: 24 }}>
        <SummaryCard label="Total Outstanding" value={fmtINR(od?.total_outstanding || 0)} color="#dc2626" />
        {Object.entries(ageing).map(([key, val]: any) => (
          <SummaryCard key={key} label={key.replace(/_/g, ' ').replace(/(\d)/g, ' $1').trim()} value={fmtINR(val)} />
        ))}
      </div>

      <Card>
        <h3 style={{ margin: '0 0 14px', fontSize: 15, fontWeight: 700 }}>Invoice-wise Detail</h3>
        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
          <thead>
            <tr style={{ borderBottom: '1px solid #e2e8f0', textAlign: 'left' }}>
              {['Invoice #', 'Date', 'Due Date', 'Total', 'Outstanding', 'Overdue Days', 'Bucket'].map(h => (
                <th key={h} style={{ padding: '6px 10px', color: '#64748b', fontSize: 12 }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {(od?.invoices || []).map((inv: any) => (
              <tr key={inv.invoice_number} style={{
                borderBottom: '1px solid #f8fafc',
                background: inv.overdue_days > 90 ? '#fff1f2' : inv.overdue_days > 60 ? '#fffbeb' : undefined,
              }}>
                <td style={{ padding: '8px 10px', fontWeight: 600 }}>{inv.invoice_number}</td>
                <td style={{ padding: '8px 10px', color: '#64748b' }}>{inv.date}</td>
                <td style={{ padding: '8px 10px', color: '#64748b' }}>{inv.due_date}</td>
                <td style={{ padding: '8px 10px' }}>{fmtINR(inv.total_amount)}</td>
                <td style={{ padding: '8px 10px', fontWeight: 600, color: '#dc2626' }}>{fmtINR(inv.outstanding_amount)}</td>
                <td style={{ padding: '8px 10px', color: inv.overdue_days > 0 ? '#dc2626' : '#16a34a', fontWeight: 600 }}>
                  {inv.overdue_days > 0 ? `${inv.overdue_days} days` : 'Current'}
                </td>
                <td style={{ padding: '8px 10px' }}>
                  <Badge text={inv.bucket} type={inv.overdue_days > 60 ? 'danger' : inv.overdue_days > 0 ? 'warning' : 'success'} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </PortalLayout>
  );
}

// ── Complaints ────────────────────────────────────────────────────
function ComplaintsPage() {
  const qc = useQueryClient();
  const [showForm, setShowForm] = useState(false);
  const [category, setCategory] = useState('QUALITY');
  const [details, setDetails] = useState('');
  const [contact, setContact] = useState('');
  const [success, setSuccess] = useState('');
  const [error, setError] = useState('');

  const { data: complaints, isLoading } = useQuery({ queryKey: ['portal-complaints'], queryFn: portalService.complaints });

  const { mutate, isPending } = useMutation({
    mutationFn: () => portalService.createComplaint({ category, complaint_details: details, customer_contact: contact }),
    onSuccess: (data: any) => {
      qc.invalidateQueries({ queryKey: ['portal-complaints'] });
      setSuccess(`Complaint ${data.complaint_number} submitted successfully.`);
      setShowForm(false);
      setDetails(''); setContact('');
    },
    onError: (e: any) => setError(e.response?.data?.detail || 'Failed to submit complaint.'),
  });

  const categories = ['QUALITY', 'DELIVERY', 'QUANTITY', 'BILLING', 'PACKAGING', 'OTHER'];

  return (
    <PortalLayout title="Complaints">
      {success && <Alert msg={success} type="success" />}

      <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 16 }}>
        <Btn onClick={() => setShowForm(!showForm)}>
          {showForm ? 'Cancel' : '+ New Complaint'}
        </Btn>
      </div>

      {showForm && (
        <Card style={{ marginBottom: 16 }}>
          <h3 style={{ margin: '0 0 14px', fontSize: 15, fontWeight: 700 }}>New Complaint</h3>
          {error && <Alert msg={error} type="error" />}
          <div style={{ marginBottom: 12 }}>
            <label style={{ display: 'block', fontSize: 13, fontWeight: 600, color: '#374151', marginBottom: 4 }}>Category</label>
            <select value={category} onChange={e => setCategory(e.target.value)}
              style={{ padding: '8px 12px', border: '1px solid #d1d5db', borderRadius: 8, fontSize: 14, width: '100%' }}>
              {categories.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
          <div style={{ marginBottom: 12 }}>
            <label style={{ display: 'block', fontSize: 13, fontWeight: 600, color: '#374151', marginBottom: 4 }}>Complaint Details</label>
            <textarea value={details} onChange={e => setDetails(e.target.value)} rows={4}
              style={{ width: '100%', padding: '8px 12px', border: '1px solid #d1d5db', borderRadius: 8, fontSize: 14, boxSizing: 'border-box' }}
              placeholder="Describe the issue in detail…" />
          </div>
          <Input label="Contact Person" value={contact} onChange={e => setContact(e.target.value)} placeholder="Your name / phone" />
          <Btn onClick={() => mutate()} disabled={isPending || !details}>
            {isPending ? 'Submitting…' : 'Submit Complaint'}
          </Btn>
        </Card>
      )}

      <Card>
        {isLoading ? <Spinner /> : (
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 14 }}>
            <thead>
              <tr style={{ borderBottom: '2px solid #e2e8f0', textAlign: 'left' }}>
                {['Complaint #', 'Date', 'Category', 'Status', 'Details'].map(h => (
                  <th key={h} style={{ padding: '8px 10px', color: '#64748b', fontWeight: 600, fontSize: 12 }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {(complaints as any[] || []).length === 0 ? (
                <tr><td colSpan={5} style={{ textAlign: 'center', padding: 32, color: '#94a3b8' }}>No complaints.</td></tr>
              ) : (complaints as any[]).map((c: any) => (
                <tr key={c.complaint_number} style={{ borderBottom: '1px solid #f1f5f9' }}>
                  <td style={{ padding: '10px', fontWeight: 600 }}>{c.complaint_number}</td>
                  <td style={{ padding: '10px', color: '#64748b' }}>{c.date}</td>
                  <td style={{ padding: '10px' }}><Badge text={c.category} /></td>
                  <td style={{ padding: '10px' }}><Badge text={c.status} type={statusBadgeType(c.status)} /></td>
                  <td style={{ padding: '10px', color: '#64748b', maxWidth: 300 }}>{c.details}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </Card>
    </PortalLayout>
  );
}

// ═══════════════════════════════════════════════════════════════════
// ROOT ROUTER
// ═══════════════════════════════════════════════════════════════════

function PortalRouter() {
  const { token } = usePortalAuth();
  const { path, navigate } = usePortalRoute();

  // Redirect unauthenticated users
  useEffect(() => {
    if (!token && !path.startsWith('/portal/login') && !path.startsWith('/portal/otp')) {
      navigate('/portal/login');
    } else if (token && (path === '/portal' || path === '/portal/login' || path === '/portal/otp')) {
      navigate('/portal/dashboard');
    }
  }, [token, path]);

  if (!token && path.startsWith('/portal/login')) return <LoginPage />;
  if (!token && path.startsWith('/portal/otp')) return <OTPPage />;
  if (!token) return <LoginPage />;

  if (path === '/portal' || path === '/portal/dashboard') return <DashboardPage />;
  if (path === '/portal/orders') return <OrdersPage />;
  if (path === '/portal/orders/new') return <NewOrderPage />;
  if (path.startsWith('/portal/orders/')) {
    const soNumber = path.replace('/portal/orders/', '');
    return <OrderDetailPage soNumber={soNumber} />;
  }
  if (path.startsWith('/portal/invoices')) return <InvoicesPage />;
  if (path.startsWith('/portal/outstanding')) return <OutstandingPage />;
  if (path.startsWith('/portal/complaints')) return <ComplaintsPage />;

  return <DashboardPage />;
}

export default function CustomerPortalApp() {
  return (
    <PortalAuthProvider>
      <PortalRouter />
    </PortalAuthProvider>
  );
}
