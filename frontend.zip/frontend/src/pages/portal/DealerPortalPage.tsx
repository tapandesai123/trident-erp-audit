/**
 * Dealer Portal — Redirects to the full CustomerPortalApp.
 * The real portal is now at /portal/* routes handled by CustomerPortalApp.
 */
import { useEffect } from 'react';

export default function DealerPortalPage() {
  useEffect(() => {
    window.location.replace('/portal/dashboard');
  }, []);

  return (
    <div style={{
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      minHeight: '60vh', color: '#64748b', fontSize: 15,
    }}>
      Redirecting to Customer Portal…
    </div>
  );
}
