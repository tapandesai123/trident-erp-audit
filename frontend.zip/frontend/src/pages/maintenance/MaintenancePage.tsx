import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { PlusIcon, MagnifyingGlassIcon } from '@heroicons/react/24/outline';
import PageHeader from '@/components/ui/PageHeader';
import Badge from '@/components/ui/Badge';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import { maintenanceService } from '@/services/maintenance';

const REQ_STATUS_BADGE: Record<string, any> = { OPEN: 'danger', IN_PROGRESS: 'warning', COMPLETED: 'success', CANCELLED: 'neutral' };
const PRIORITY_BADGE: Record<string, any> = { LOW: 'neutral', MEDIUM: 'info', HIGH: 'warning', CRITICAL: 'danger' };

export default function MaintenancePage() {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [tab, setTab] = useState<'requests' | 'schedules' | 'amc'>('requests');
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('');

  const { data: reqData, isLoading: reqLoading } = useQuery({
    queryKey: ['maintenance-requests', search, status],
    queryFn: () => maintenanceService.listRequests({ search, status: status || undefined }),
  });
  const { data: pmData, isLoading: pmLoading } = useQuery({ queryKey: ['pm-schedules'], queryFn: () => maintenanceService.listPMSchedules() });
  const { data: amcData, isLoading: amcLoading } = useQuery({ queryKey: ['amc-contracts'], queryFn: () => maintenanceService.listAMC() });

  const requests = Array.isArray(reqData) ? reqData : (reqData as any)?.results || [];
  const schedules = Array.isArray(pmData) ? pmData : (pmData as any)?.results || [];
  const amcs = Array.isArray(amcData) ? amcData : (amcData as any)?.results || [];

  const startMutation = useMutation({
    mutationFn: (id: string) => maintenanceService.startWork(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['maintenance-requests'] }),
  });
  const completeMutation = useMutation({
    mutationFn: (id: string) => maintenanceService.completeWork(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['maintenance-requests'] }),
  });

  return (
    <div className="space-y-5">
      <PageHeader title="Maintenance"
        actions={<button className="btn btn-primary" onClick={() => navigate('/maintenance/new')}><PlusIcon className="h-4 w-4 mr-1" />New Request</button>} />
      <div className="flex gap-2 border-b border-neutral-200">
        {[{ key: 'requests', label: 'Work Requests' }, { key: 'schedules', label: 'PM Schedules' }, { key: 'amc', label: 'AMC Contracts' }].map(({ key, label }) => (
          <button key={key} onClick={() => setTab(key as any)}
            className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors ${tab === key ? 'border-primary-600 text-primary-700' : 'border-transparent text-neutral-500 hover:text-neutral-700'}`}>
            {label}
          </button>
        ))}
      </div>

      {tab === 'requests' && (
        <>
          <div className="flex gap-3">
            <div className="relative flex-1"><MagnifyingGlassIcon className="absolute left-3 top-2.5 h-4 w-4 text-neutral-400" /><input className="input pl-9" placeholder="Search requests…" value={search} onChange={e => setSearch(e.target.value)} /></div>
            <select className="input w-40" value={status} onChange={e => setStatus(e.target.value)}>
              <option value="">All Status</option>
              {['OPEN','IN_PROGRESS','COMPLETED','CANCELLED'].map(s => <option key={s} value={s}>{s.replace('_', ' ')}</option>)}
            </select>
          </div>
          {reqLoading ? <LoadingSpinner /> : (
            <div className="card overflow-hidden">
              <table className="table">
                <thead><tr><th>Request No.</th><th>Asset / Machine</th><th>Reported By</th><th>Priority</th><th>Status</th><th>Reported On</th><th>Actions</th></tr></thead>
                <tbody>
                  {requests.length === 0
                    ? <tr><td colSpan={7} className="text-center py-8 text-neutral-400">No requests found.</td></tr>
                    : requests.map((r: any) => (
                      <tr key={r.id} className="hover:bg-neutral-50">
                        <td className="font-mono text-sm">{r.request_number}</td>
                        <td><p className="font-medium text-sm">{r.asset_name || r.asset?.name || r.machine_name}</p><p className="text-xs text-neutral-400">{r.description?.slice(0, 50)}</p></td>
                        <td className="text-sm text-neutral-500">{r.reported_by_name || '—'}</td>
                        <td><Badge variant={PRIORITY_BADGE[r.priority] || 'neutral'}>{r.priority}</Badge></td>
                        <td><Badge variant={REQ_STATUS_BADGE[r.status] || 'neutral'}>{r.status?.replace('_', ' ')}</Badge></td>
                        <td className="text-sm text-neutral-500">{r.reported_date || r.created_at?.slice(0, 10)}</td>
                        <td>
                          {r.status === 'OPEN' && <button className="text-xs text-primary-600 hover:underline mr-2" onClick={() => startMutation.mutate(r.id)}>Start</button>}
                          {r.status === 'IN_PROGRESS' && <button className="text-xs text-success-600 hover:underline" onClick={() => completeMutation.mutate(r.id)}>Complete</button>}
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          )}
        </>
      )}

      {tab === 'schedules' && (
        pmLoading ? <LoadingSpinner /> : (
          <div className="card overflow-hidden">
            <table className="table">
              <thead><tr><th>Machine</th><th>Maintenance Type</th><th>Frequency</th><th>Last Done</th><th>Next Due</th><th>Status</th></tr></thead>
              <tbody>
                {schedules.length === 0
                  ? <tr><td colSpan={6} className="text-center py-8 text-neutral-400">No PM schedules.</td></tr>
                  : schedules.map((s: any) => (
                    <tr key={s.id} className="hover:bg-neutral-50">
                      <td className="font-medium text-sm">{s.asset_name || s.asset?.name}</td>
                      <td className="text-sm">{s.maintenance_type}</td>
                      <td className="text-sm text-neutral-500">{s.frequency_display || `Every ${s.frequency_days} days`}</td>
                      <td className="text-sm text-neutral-500">{s.last_performed_date || '—'}</td>
                      <td className="text-sm font-medium">{s.next_due_date}</td>
                      <td><Badge variant={s.is_overdue ? 'danger' : s.is_due_soon ? 'warning' : 'success'}>{s.is_overdue ? 'OVERDUE' : s.is_due_soon ? 'DUE SOON' : 'ON TRACK'}</Badge></td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        )
      )}

      {tab === 'amc' && (
        amcLoading ? <LoadingSpinner /> : (
          <div className="card overflow-hidden">
            <table className="table">
              <thead><tr><th>Contract No.</th><th>Asset/Equipment</th><th>Vendor</th><th className="text-right">Amount (₹)</th><th>Start Date</th><th>End Date</th><th>Status</th></tr></thead>
              <tbody>
                {amcs.length === 0
                  ? <tr><td colSpan={7} className="text-center py-8 text-neutral-400">No AMC contracts.</td></tr>
                  : amcs.map((a: any) => (
                    <tr key={a.id} className="hover:bg-neutral-50">
                      <td className="font-mono text-sm">{a.contract_number}</td>
                      <td className="font-medium text-sm">{a.asset_name || a.asset?.name || a.equipment_description}</td>
                      <td className="text-sm text-neutral-500">{a.vendor_name || a.vendor?.name}</td>
                      <td className="text-right tabular-nums">₹{Number(a.contract_amount || 0).toLocaleString('en-IN')}</td>
                      <td className="text-sm text-neutral-500">{a.start_date}</td>
                      <td className="text-sm font-medium">{a.end_date}</td>
                      <td><Badge variant={a.is_expired ? 'danger' : a.is_expiring_soon ? 'warning' : 'success'}>{a.is_expired ? 'EXPIRED' : a.is_expiring_soon ? 'EXPIRING SOON' : 'ACTIVE'}</Badge></td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        )
      )}
    </div>
  );
}
