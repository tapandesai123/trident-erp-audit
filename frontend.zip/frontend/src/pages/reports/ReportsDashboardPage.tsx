import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { PlusIcon, DocumentChartBarIcon, TableCellsIcon, ClockIcon } from '@heroicons/react/24/outline';
import PageHeader from '@/components/ui/PageHeader';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import { reportsService } from '@/services/reports';

export default function ReportsDashboardPage() {
  const navigate = useNavigate();
  const { data, isLoading } = useQuery({ queryKey: ['report-configs'], queryFn: () => reportsService.list() });
  const reports = Array.isArray(data) ? data : (data as any)?.results || [];

  const grouped: Record<string, any[]> = {};
  reports.forEach((r: any) => { const m = r.module || 'General'; if (!grouped[m]) grouped[m] = []; grouped[m].push(r); });

  return (
    <div className="space-y-5">
      <PageHeader title="Reports" subtitle="Custom and standard reports across all modules"
        actions={<button className="btn btn-primary" onClick={() => navigate('/reports/builder')}><PlusIcon className="h-4 w-4 mr-1" />New Report</button>} />
      {isLoading ? <LoadingSpinner /> : (
        Object.keys(grouped).length === 0 ? (
          <div className="card p-12 text-center">
            <DocumentChartBarIcon className="h-16 w-16 text-neutral-300 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-neutral-700 mb-2">No Reports Yet</h3>
            <p className="text-neutral-400 mb-4">Create your first custom report using the Report Builder.</p>
            <button className="btn btn-primary" onClick={() => navigate('/reports/builder')}>Create Report</button>
          </div>
        ) : (
          <div className="space-y-6">
            {Object.entries(grouped).map(([module, reps]) => (
              <div key={module}>
                <h3 className="text-sm font-semibold text-neutral-500 uppercase tracking-wide mb-3">{module}</h3>
                <div className="grid grid-cols-3 gap-3">
                  {reps.map((r: any) => (
                    <div key={r.id} className="card p-4 cursor-pointer hover:shadow-md transition-shadow"
                      onClick={() => navigate(`/reports/builder?id=${r.id}`)}>
                      <div className="flex items-start gap-3">
                        <div className="h-10 w-10 rounded-lg bg-primary-50 flex items-center justify-center flex-shrink-0">
                          {r.type === 'TABLE' ? <TableCellsIcon className="h-5 w-5 text-primary-600" /> : <DocumentChartBarIcon className="h-5 w-5 text-primary-600" />}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-medium text-neutral-900 text-sm truncate">{r.name}</p>
                          <p className="text-xs text-neutral-400 mt-0.5">{r.description?.slice(0, 60)}</p>
                          {r.last_run && (
                            <div className="flex items-center gap-1 mt-1.5">
                              <ClockIcon className="h-3 w-3 text-neutral-300" />
                              <span className="text-xs text-neutral-300">Last run: {r.last_run.slice(0, 10)}</span>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )
      )}
    </div>
  );
}
