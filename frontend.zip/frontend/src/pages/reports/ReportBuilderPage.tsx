import { useState } from 'react';
import { useMutation, useQuery } from '@tanstack/react-query';
import {
  PlayIcon, ArrowDownTrayIcon, AdjustmentsHorizontalIcon, TableCellsIcon,
  BuildingStorefrontIcon,
} from '@heroicons/react/24/outline';
import PageHeader from '@/components/ui/PageHeader';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import { reportsService, ReportResult, InventoryValuationResult, ValuationRow } from '@/services/reports';

const REPORT_TYPES = [
  { value: 'purchase_ledger', label: 'Purchase Ledger', module: 'Purchase', description: 'All purchases by vendor/period' },
  { value: 'payment_register', label: 'Payment Register', module: 'Accounts', description: 'All payments made in period' },
  { value: 'outstanding_ap', label: 'AP Outstanding', module: 'Accounts', description: 'Vendor-wise outstanding bills' },
  { value: 'outstanding_ar', label: 'AR Outstanding', module: 'Accounts', description: 'Customer-wise outstanding invoices' },
  { value: 'gst_summary', label: 'GST Summary', module: 'Accounts', description: 'GST collected & paid summary' },
  { value: 'sales_register', label: 'Sales Register', module: 'Sales', description: 'All invoices by customer/period' },
  { value: 'stock_ledger', label: 'Stock Ledger', module: 'Stores', description: 'Item-wise stock movement' },
  { value: 'stock_valuation', label: 'Stock Valuation', module: 'Stores', description: 'Current stock with value' },
  // P4 – Enhanced valuation with RM / WIP / FG breakdown
  { value: 'inventory_valuation', label: 'Inventory Valuation', module: 'Stores', description: 'RM + WIP + FG stock value with subtotals' },
  { value: 'vendor_analysis', label: 'Vendor Analysis', module: 'Purchase', description: 'Vendor performance metrics' },
  { value: 'customer_analysis', label: 'Customer Analysis', module: 'Sales', description: 'Customer revenue analysis' },
  { value: 'inspection_summary', label: 'Inspection Summary', module: 'Quality', description: 'QC results by period' },
  { value: 'capa_status', label: 'CAPA Status', module: 'Quality', description: 'Open/closed CAPA list' },
];

const GROUP_BY_OPTIONS: Record<string, string[]> = {
  purchase_ledger: ['Vendor', 'Month', 'Category', 'Item'],
  sales_register: ['Customer', 'Month', 'Product', 'Region'],
  stock_ledger: ['Item', 'Category', 'Location'],
  default: ['Month', 'Category'],
};



function formatCell(value: string | number, type: string): string {
  if (type === 'currency' && typeof value === 'number') {
    return `₹${value.toLocaleString('en-IN')}`;
  }
  return String(value);
}

export default function ReportBuilderPage() {
  const [reportType, setReportType] = useState('purchase_ledger');
  const [dateFrom, setDateFrom] = useState('2024-08-01');
  const [dateTo, setDateTo] = useState('2025-01-31');
  const [groupBy, setGroupBy] = useState('Vendor');
  const [generated, setGenerated] = useState(false);

  const [reportResult, setReportResult] = useState<ReportResult | null>(null);
  // P4 – Inventory valuation result (separate from generic report result)
  const [valuationResult, setValuationResult] = useState<InventoryValuationResult | null>(null);

  const isValuation = reportType === 'inventory_valuation';

  const generateMutation = useMutation({
    mutationFn: () => {
      if (isValuation) {
        return reportsService.getInventoryValuation({});
      }
      return reportsService.run(reportType, { date_from: dateFrom, date_to: dateTo, group_by: groupBy });
    },
    onSuccess: (data: any) => {
      if (isValuation) {
        setValuationResult(data as InventoryValuationResult);
        setReportResult(null);
      } else {
        setReportResult(data as ReportResult);
        setValuationResult(null);
      }
      setGenerated(true);
    },
    onError: () => {
      setReportResult({ columns: [], rows: [], totals: {}, row_count: 0 });
      setValuationResult(null);
      setGenerated(true);
    },
  });

  const selectedReport = REPORT_TYPES.find(r => r.value === reportType);
  const groupByOptions = GROUP_BY_OPTIONS[reportType] || GROUP_BY_OPTIONS.default;

  const handleGenerate = () => {
    setGenerated(false);
    generateMutation.mutate();
  };
  const generating = generateMutation.isPending;

  const handleExport = (format: string) => {
    reportsService.exportReport(reportType, { date_from: dateFrom, date_to: dateTo, group_by: groupBy }, format as 'excel' | 'pdf')
      .then(blob => {
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a'); a.href = url;
        a.download = `report-${reportType}.${format === 'excel' ? 'xlsx' : 'pdf'}`;
        a.click(); URL.revokeObjectURL(url);
      }).catch(() => alert(`Export failed — please try again`));
  };

  // Group by module
  const modules = [...new Set(REPORT_TYPES.map(r => r.module))];

  return (
    <div className="space-y-5">
      <PageHeader
        title="Report Builder"
        subtitle="Configure and generate custom reports"
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Config panel */}
        <div className="lg:col-span-1 space-y-4">
          <div className="bg-white rounded-2xl border border-neutral-100 p-5">
            <h3 className="text-sm font-semibold text-neutral-800 mb-3 flex items-center gap-2">
              <AdjustmentsHorizontalIcon className="h-4 w-4" />
              Report Configuration
            </h3>

            <div className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-neutral-500 mb-1.5">Report Type *</label>
                <div className="space-y-1 max-h-56 overflow-y-auto pr-1">
                  {modules.map(module => (
                    <div key={module}>
                      <p className="text-xs font-semibold text-neutral-400 uppercase tracking-wide px-2 py-1">{module}</p>
                      {REPORT_TYPES.filter(r => r.module === module).map(r => (
                        <button
                          key={r.value}
                          onClick={() => setReportType(r.value)}
                          className={`w-full text-left px-3 py-2 rounded-xl transition ${
                            reportType === r.value
                              ? 'bg-primary-50 border border-primary-200 text-primary-700'
                              : 'hover:bg-neutral-50 text-neutral-700'
                          }`}
                        >
                          <p className="text-sm font-medium">{r.label}</p>
                          <p className="text-xs text-neutral-400">{r.description}</p>
                        </button>
                      ))}
                    </div>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-neutral-500 mb-1.5">From</label>
                  <input
                    type="date"
                    value={dateFrom}
                    onChange={e => setDateFrom(e.target.value)}
                    className="w-full px-3 py-2 text-sm border border-neutral-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-neutral-500 mb-1.5">To</label>
                  <input
                    type="date"
                    value={dateTo}
                    onChange={e => setDateTo(e.target.value)}
                    className="w-full px-3 py-2 text-sm border border-neutral-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-neutral-500 mb-1.5">Group By</label>
                <select
                  value={groupBy}
                  onChange={e => setGroupBy(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-neutral-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-500"
                >
                  {groupByOptions.map(opt => (
                    <option key={opt} value={opt}>{opt}</option>
                  ))}
                </select>
              </div>

              <button
                onClick={handleGenerate}
                disabled={generating}
                className="w-full flex items-center justify-center gap-2 px-4 py-2.5 bg-primary-600 text-white text-sm font-medium rounded-xl hover:bg-primary-700 transition disabled:opacity-50"
              >
                {generating ? (
                  <>
                    <div className="h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    Generating…
                  </>
                ) : (
                  <>
                    <PlayIcon className="h-4 w-4" />
                    Generate Report
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Results panel */}
        <div className="lg:col-span-2">
          {!generated && !generating && (
            <div className="bg-white rounded-2xl border border-dashed border-neutral-200 h-64 flex flex-col items-center justify-center text-neutral-400">
              <TableCellsIcon className="h-10 w-10 mb-2" />
              <p className="text-sm">Configure report parameters and click Generate</p>
            </div>
          )}

          {generating && (
            <div className="bg-white rounded-2xl border border-neutral-100 h-64 flex flex-col items-center justify-center gap-3">
              <div className="h-8 w-8 border-2 border-primary-500 border-t-transparent rounded-full animate-spin" />
              <p className="text-sm text-neutral-500">Generating {selectedReport?.label}…</p>
            </div>
          )}

          {generated && !generating && valuationResult && (
            /* P4 – Inventory Valuation enhanced display */
            <div className="space-y-5">
              {/* Summary cards */}
              <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
                {[
                  { label: 'Raw Materials', value: valuationResult.summary.rm_total, cls: 'border-blue-200 bg-blue-50', text: 'text-blue-800' },
                  { label: 'WIP', value: valuationResult.summary.wip_total, cls: 'border-amber-200 bg-amber-50', text: 'text-amber-800' },
                  { label: 'Finished Goods', value: valuationResult.summary.fg_total, cls: 'border-green-200 bg-green-50', text: 'text-green-800' },
                  { label: 'Other', value: valuationResult.summary.other_total, cls: 'border-neutral-200 bg-neutral-50', text: 'text-neutral-700' },
                  { label: 'Grand Total', value: valuationResult.summary.grand_total, cls: 'border-primary-300 bg-primary-50', text: 'text-primary-900' },
                ].map(({ label, value, cls, text }) => (
                  <div key={label} className={`rounded-xl border p-3 ${cls}`}>
                    <p className="text-xs text-neutral-500 mb-1">{label}</p>
                    <p className={`text-base font-bold ${text}`}>
                      ₹{value.toLocaleString('en-IN', { maximumFractionDigits: 0 })}
                    </p>
                  </div>
                ))}
              </div>

              {/* Section tables */}
              {([
                { key: 'rm_rows', label: 'Raw Materials', rows: valuationResult.rm_rows, cls: 'border-blue-200', hdr: 'bg-blue-50 text-blue-800' },
                { key: 'wip_rows', label: 'Work In Progress (WIP)', rows: valuationResult.wip_rows, cls: 'border-amber-200', hdr: 'bg-amber-50 text-amber-800' },
                { key: 'fg_rows', label: 'Finished Goods', rows: valuationResult.fg_rows, cls: 'border-green-200', hdr: 'bg-green-50 text-green-800' },
                { key: 'other_rows', label: 'Other', rows: valuationResult.other_rows, cls: 'border-neutral-200', hdr: 'bg-neutral-50 text-neutral-700' },
              ] as Array<{ key: string; label: string; rows: ValuationRow[]; cls: string; hdr: string }>)
                .filter(s => s.rows.length > 0)
                .map(section => (
                  <div key={section.key} className={`rounded-2xl border overflow-hidden ${section.cls}`}>
                    <div className={`px-4 py-2.5 flex items-center justify-between ${section.hdr}`}>
                      <div className="flex items-center gap-2">
                        <BuildingStorefrontIcon className="h-4 w-4" />
                        <span className="text-sm font-semibold">{section.label}</span>
                        <span className="text-xs opacity-70">({section.rows.length} items)</span>
                      </div>
                      <span className="text-sm font-bold">
                        ₹{section.rows.reduce((s, r) => s + r.total_value, 0).toLocaleString('en-IN', { maximumFractionDigits: 0 })}
                      </span>
                    </div>
                    <div className="overflow-x-auto bg-white">
                      <table className="w-full text-xs">
                        <thead>
                          <tr className="border-b border-neutral-100 text-neutral-500">
                            <th className="px-4 py-2 text-left font-medium">Item Code</th>
                            <th className="px-4 py-2 text-left font-medium">Item Name</th>
                            <th className="px-4 py-2 text-left font-medium">Warehouse</th>
                            <th className="px-4 py-2 text-right font-medium">Qty</th>
                            <th className="px-4 py-2 text-right font-medium">UOM</th>
                            <th className="px-4 py-2 text-right font-medium">Value (₹)</th>
                            <th className="px-4 py-2 text-right font-medium">Lots</th>
                          </tr>
                        </thead>
                        <tbody>
                          {section.rows.map((row, i) => (
                            <tr key={i} className="border-t border-neutral-50 hover:bg-neutral-50">
                              <td className="px-4 py-2 font-mono font-medium text-neutral-700">{row.item_code}</td>
                              <td className="px-4 py-2 text-neutral-600">{row.item_name}</td>
                              <td className="px-4 py-2 text-neutral-500">{row.warehouse_name || row.warehouse_code}</td>
                              <td className="px-4 py-2 text-right tabular-nums">{row.total_qty.toLocaleString('en-IN', { maximumFractionDigits: 3 })}</td>
                              <td className="px-4 py-2 text-right text-neutral-400">{row.uom}</td>
                              <td className="px-4 py-2 text-right tabular-nums font-semibold text-neutral-800">
                                {row.total_value.toLocaleString('en-IN', { maximumFractionDigits: 2 })}
                              </td>
                              <td className="px-4 py-2 text-right text-neutral-400">{row.lot_count}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                ))}
            </div>
          )}

          {generated && !generating && reportResult && !valuationResult && (
            <div className="bg-white rounded-2xl border border-neutral-100 overflow-hidden">
              <div className="px-5 py-4 border-b border-neutral-100 flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-semibold text-neutral-900">{selectedReport?.label}</h3>
                  <p className="text-xs text-neutral-400 mt-0.5">
                    {dateFrom} to {dateTo} · Grouped by {groupBy} · {reportResult?.rows?.length ?? 0} rows
                  </p>
                </div>
                <div className="flex gap-2">
                  {['xlsx', 'csv', 'pdf'].map(fmt => (
                    <button
                      key={fmt}
                      onClick={() => handleExport(fmt)}
                      className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-neutral-600 bg-neutral-50 border border-neutral-100 rounded-lg hover:bg-neutral-100"
                    >
                      <ArrowDownTrayIcon className="h-3.5 w-3.5" />
                      {fmt.toUpperCase()}
                    </button>
                  ))}
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="bg-neutral-50 border-b border-neutral-100">
                      {(reportResult?.columns ?? []).map(col => (
                        <th
                          key={col.key}
                          className={`text-xs font-semibold text-neutral-500 px-4 py-3 ${
                            col.type !== 'text' ? 'text-right' : 'text-left'
                          }`}
                        >
                          {col.label}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-neutral-50">
                    {(reportResult?.rows ?? []).map((row, i) => (
                      <tr key={i} className="hover:bg-neutral-50">
                        {(reportResult?.columns ?? []).map(col => (
                          <td
                            key={col.key}
                            className={`px-4 py-3 text-sm ${
                              col.type === 'text' ? 'text-neutral-800' : 'text-right font-medium text-neutral-900'
                            }`}
                          >
                            {formatCell(row[col.key], col.type)}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                  {reportResult?.totals && (
                    <tfoot>
                      <tr className="bg-neutral-50 border-t-2 border-neutral-200 font-semibold">
                        <td className="px-4 py-3 text-sm">Total</td>
                        {(reportResult?.columns ?? []).slice(1).map(col => (
                          <td key={col.key} className="px-4 py-3 text-sm text-right">
                            {formatCell(reportResult?.totals?.[col.key] || '', col.type)}
                          </td>
                        ))}
                      </tr>
                    </tfoot>
                  )}
                </table>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
