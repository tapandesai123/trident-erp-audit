import { useQuery } from '@tanstack/react-query';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import { BanknotesIcon, ArrowTrendingUpIcon, ArrowTrendingDownIcon, ExclamationTriangleIcon } from '@heroicons/react/24/outline';
import PageHeader from '@/components/ui/PageHeader';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import { accountsService } from '@/services/accounts';

function StatCard({ label, value, sub, icon: Icon, color }: any) {
  return (
    <div className="card p-4 flex items-center gap-4">
      <div className={`h-12 w-12 rounded-xl ${color} flex items-center justify-center flex-shrink-0`}>
        <Icon className="h-6 w-6" />
      </div>
      <div>
        <p className="text-xs text-neutral-400 mb-0.5">{label}</p>
        <p className="text-xl font-bold text-neutral-900">₹{Number(value || 0).toLocaleString('en-IN')}</p>
        {sub && <p className="text-xs text-neutral-400 mt-0.5">{sub}</p>}
      </div>
    </div>
  );
}

export default function AccountsDashboardPage() {
  const { data: dash, isLoading } = useQuery({
    queryKey: ['accounts-dashboard'],
    queryFn: () => accountsService.getDashboard(),
  });

  if (isLoading) return <LoadingSpinner />;

  const d = dash || {};
  const expenses = (d as any).monthly_expenses || [];
  const topVendors = (d as any).top_vendors_payable || [];
  const topCustomers = (d as any).top_customers_receivable || [];

  return (
    <div className="space-y-5">
      <PageHeader title="Accounts Dashboard" subtitle="Financial overview" />
      <div className="grid grid-cols-4 gap-4">
        <StatCard label="Total Receivable" value={(d as any).total_receivable} icon={ArrowTrendingUpIcon} color="bg-success-100 text-success-700" />
        <StatCard label="Total Payable" value={(d as any).total_payable} icon={ArrowTrendingDownIcon} color="bg-warning-100 text-warning-700" />
        <StatCard label="Overdue Receivable" value={(d as any).overdue_receivable} sub="Past due date" icon={ExclamationTriangleIcon} color="bg-danger-100 text-danger-700" />
        <StatCard label="TDS Pending" value={(d as any).tds_pending} icon={BanknotesIcon} color="bg-info-100 text-info-700" />
      </div>
      <div className="grid grid-cols-3 gap-5">
        <div className="card p-4 col-span-2">
          <h3 className="text-sm font-semibold text-neutral-700 mb-3">Monthly Expenses (₹)</h3>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={expenses}>
              <XAxis dataKey="month" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} tickFormatter={(v) => `${(v / 100000).toFixed(0)}L`} />
              <Tooltip formatter={(v: any) => [`₹${Number(v).toLocaleString('en-IN')}`, 'Amount']} />
              <Bar dataKey="amount" fill="#2563eb" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="space-y-4">
          <div className="card p-4">
            <h3 className="text-sm font-semibold text-neutral-700 mb-2">Top Payables</h3>
            <div className="space-y-2">
              {topVendors.map((v: any) => (
                <div key={v.name} className="flex justify-between items-center text-sm">
                  <span className="text-neutral-600 truncate">{v.name}</span>
                  <span className="font-semibold tabular-nums ml-2">₹{Number(v.amount).toLocaleString('en-IN')}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="card p-4">
            <h3 className="text-sm font-semibold text-neutral-700 mb-2">Top Receivables</h3>
            <div className="space-y-2">
              {topCustomers.map((c: any) => (
                <div key={c.name} className="flex justify-between items-center text-sm">
                  <span className="text-neutral-600 truncate">{c.name}</span>
                  <span className="font-semibold tabular-nums ml-2">₹{Number(c.amount).toLocaleString('en-IN')}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
