import { useState, useEffect } from 'react';
import { useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { PlusIcon, TrashIcon, CheckCircleIcon, ExclamationCircleIcon } from '@heroicons/react/24/outline';
import PageHeader from '@/components/ui/PageHeader';
import { VoucherType, VoucherLine, BillPassingChecklist, accountsService } from '@/services/accounts';

const VOUCHER_TYPES: Array<{ value: VoucherType; label: string }> = [
  { value: 'PURCHASE', label: 'Purchase Voucher' },
  { value: 'PAYMENT', label: 'Payment Voucher' },
  { value: 'RECEIPT', label: 'Receipt Voucher' },
  { value: 'JOURNAL', label: 'Journal Voucher' },
];

const SAMPLE_ACCOUNTS = [
  { code: '1101', name: 'Cash' },
  { code: '1102', name: 'Bank - HDFC' },
  { code: '1103', name: 'Bank - SBI' },
  { code: '2101', name: 'Sundry Creditors' },
  { code: '2102', name: 'Sundry Debtors' },
  { code: '3101', name: 'Purchase - Raw Materials' },
  { code: '3102', name: 'Purchase - Consumables' },
  { code: '4101', name: 'Sales' },
  { code: '5101', name: 'GST Input - CGST' },
  { code: '5102', name: 'GST Input - SGST' },
  { code: '5103', name: 'GST Input - IGST' },
  { code: '5201', name: 'GST Output - CGST' },
  { code: '5202', name: 'GST Output - SGST' },
  { code: '6101', name: 'TDS Payable' },
  { code: '7101', name: 'Depreciation' },
  { code: '7102', name: 'Salary & Wages' },
  { code: '7103', name: 'Power & Fuel' },
];

const BILL_PASSING_ITEMS: Array<{ key: keyof BillPassingChecklist; label: string; description: string }> = [
  { key: 'po_attached', label: 'PO Attached', description: 'Purchase Order copy attached to voucher' },
  { key: 'grn_attached', label: 'GRN Attached', description: 'Goods Receipt Note / MRR attached' },
  { key: 'invoice_attached', label: 'Invoice Attached', description: 'Vendor invoice original attached' },
  { key: 'rates_match_po', label: 'Rates Match PO', description: 'Invoice rates match PO rates (within tolerance)' },
  { key: 'qty_match_grn', label: 'Qty Match GRN', description: 'Invoice quantity matches GRN quantity' },
  { key: 'gst_correct', label: 'GST Correct', description: 'GST computation verified (CGST/SGST/IGST correct)' },
  { key: 'tds_deducted', label: 'TDS Deducted', description: 'TDS deducted as applicable (194C/194J etc.)' },
];

function emptyLine(): VoucherLine {
  return { account_code: '', narration: '', debit: '', credit: '' };
}

export default function VoucherFormPage() {
  const navigate = useNavigate();
  const { id } = useParams();
  const [searchParams] = useSearchParams();
  const isEdit = !!id;

  const [voucherType, setVoucherType] = useState<VoucherType>('PURCHASE');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [narration, setNarration] = useState('');
  const [reference, setReference] = useState('');
  const [lines, setLines] = useState<VoucherLine[]>([emptyLine(), emptyLine()]);
  const [billPassing, setBillPassing] = useState<BillPassingChecklist>({
    po_attached: false, grn_attached: false, invoice_attached: false,
    rates_match_po: false, qty_match_grn: false, gst_correct: false, tds_deducted: false,
  });
  const [submitting, setSubmitting] = useState(false);

  const totalDebit = lines.reduce((sum, l) => sum + (parseFloat(l.debit) || 0), 0);
  const totalCredit = lines.reduce((sum, l) => sum + (parseFloat(l.credit) || 0), 0);
  const isBalanced = Math.abs(totalDebit - totalCredit) < 0.01 && totalDebit > 0;

  const isPurchaseVoucher = voucherType === 'PURCHASE';
  const billPassingComplete = !isPurchaseVoucher || Object.values(billPassing).every(Boolean);
  const checklistCount = Object.values(billPassing).filter(Boolean).length;

  const addLine = () => setLines(l => [...l, emptyLine()]);
  const removeLine = (i: number) => setLines(l => l.filter((_, idx) => idx !== i));

  const updateLine = (i: number, field: keyof VoucherLine, value: string) => {
    setLines(prev => {
      const next = [...prev];
      next[i] = { ...next[i], [field]: value };
      // Auto-clear opposite entry
      if (field === 'debit' && value) next[i].credit = '';
      if (field === 'credit' && value) next[i].debit = '';
      return next;
    });
  };

  const qc = useQueryClient();
  const saveMutation = useMutation({
    mutationFn: (data: any) => accountsService.createVoucher(data),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['vouchers'] }); navigate('/accounts/vouchers'); },
    onError: () => setSubmitting(false),
  });

  const handleSubmit = async (_action: 'draft' | 'submit') => {
    if (!isBalanced) return;
    setSubmitting(true);
    saveMutation.mutate({ voucher_type: voucherType, date, narration, reference, party, lines, bill_passing: billPassing });
  };

  return (
    <div className="space-y-5 max-w-5xl">
      <PageHeader
        title={isEdit ? `Edit Voucher` : 'New Voucher'}
        subtitle="Double-entry bookkeeping — debits must equal credits"
        backHref="/accounts/vouchers"
      />

      {/* Header */}
      <div className="bg-white rounded-2xl border border-neutral-100 p-5">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div>
            <label className="block text-xs font-medium text-neutral-500 mb-1.5">Voucher Type *</label>
            <select
              value={voucherType}
              onChange={e => setVoucherType(e.target.value as VoucherType)}
              className="w-full px-3 py-2 text-sm border border-neutral-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-500"
            >
              {VOUCHER_TYPES.map(t => (
                <option key={t.value} value={t.value}>{t.label}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-neutral-500 mb-1.5">Date *</label>
            <input
              type="date"
              value={date}
              onChange={e => setDate(e.target.value)}
              className="w-full px-3 py-2 text-sm border border-neutral-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-500"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-neutral-500 mb-1.5">Reference / Bill No.</label>
            <input
              type="text"
              value={reference}
              onChange={e => setReference(e.target.value)}
              placeholder="e.g. INV/2025/001"
              className="w-full px-3 py-2 text-sm border border-neutral-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-500"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-neutral-500 mb-1.5">Narration *</label>
            <input
              type="text"
              value={narration}
              onChange={e => setNarration(e.target.value)}
              placeholder="Brief description…"
              className="w-full px-3 py-2 text-sm border border-neutral-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-500"
            />
          </div>
        </div>
      </div>

      {/* Journal Lines */}
      <div className="bg-white rounded-2xl border border-neutral-100 overflow-hidden">
        <div className="px-5 py-4 border-b border-neutral-100 flex items-center justify-between">
          <div>
            <h3 className="text-sm font-semibold text-neutral-800">Ledger Lines</h3>
            <p className="text-xs text-neutral-400 mt-0.5">Each line must either debit or credit an account — not both</p>
          </div>
          {/* Balance indicator */}
          <div className={`flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-medium ${
            isBalanced ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'
          }`}>
            {isBalanced
              ? <><CheckCircleIcon className="h-4 w-4" /> Balanced</>
              : <><ExclamationCircleIcon className="h-4 w-4" /> Unbalanced — Dr: ₹{totalDebit.toLocaleString('en-IN')} Cr: ₹{totalCredit.toLocaleString('en-IN')}</>
            }
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-neutral-50 border-b border-neutral-100">
                <th className="text-left text-xs font-semibold text-neutral-500 px-4 py-2.5 w-48">Account</th>
                <th className="text-left text-xs font-semibold text-neutral-500 px-4 py-2.5">Narration</th>
                <th className="text-left text-xs font-semibold text-neutral-500 px-4 py-2.5 w-32">Cost Center</th>
                <th className="text-right text-xs font-semibold text-neutral-500 px-4 py-2.5 w-32">Debit (Dr)</th>
                <th className="text-right text-xs font-semibold text-neutral-500 px-4 py-2.5 w-32">Credit (Cr)</th>
                <th className="w-10" />
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-50">
              {lines.map((line, i) => (
                <tr key={i} className="hover:bg-neutral-50 transition">
                  <td className="px-4 py-2">
                    <select
                      value={line.account_code}
                      onChange={e => updateLine(i, 'account_code', e.target.value)}
                      className="w-full px-2 py-1.5 text-sm border border-neutral-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500"
                    >
                      <option value="">Select account…</option>
                      {SAMPLE_ACCOUNTS.map(a => (
                        <option key={a.code} value={a.code}>{a.code} — {a.name}</option>
                      ))}
                    </select>
                  </td>
                  <td className="px-4 py-2">
                    <input
                      type="text"
                      value={line.narration}
                      onChange={e => updateLine(i, 'narration', e.target.value)}
                      placeholder="Line narration…"
                      className="w-full px-2 py-1.5 text-sm border border-neutral-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500"
                    />
                  </td>
                  <td className="px-4 py-2">
                    <input
                      type="text"
                      value={line.cost_center || ''}
                      onChange={e => updateLine(i, 'cost_center', e.target.value)}
                      placeholder="CC…"
                      className="w-full px-2 py-1.5 text-sm border border-neutral-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500"
                    />
                  </td>
                  <td className="px-4 py-2">
                    <input
                      type="number"
                      value={line.debit}
                      onChange={e => updateLine(i, 'debit', e.target.value)}
                      placeholder="0.00"
                      min="0"
                      step="0.01"
                      className="w-full px-2 py-1.5 text-sm border border-neutral-200 rounded-lg text-right focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                    />
                  </td>
                  <td className="px-4 py-2">
                    <input
                      type="number"
                      value={line.credit}
                      onChange={e => updateLine(i, 'credit', e.target.value)}
                      placeholder="0.00"
                      min="0"
                      step="0.01"
                      className="w-full px-2 py-1.5 text-sm border border-neutral-200 rounded-lg text-right focus:outline-none focus:ring-2 focus:ring-primary-500"
                    />
                  </td>
                  <td className="px-4 py-2">
                    {lines.length > 2 && (
                      <button
                        onClick={() => removeLine(i)}
                        className="text-neutral-300 hover:text-red-500 transition"
                      >
                        <TrashIcon className="h-4 w-4" />
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr className="bg-neutral-50 border-t border-neutral-200">
                <td colSpan={3} className="px-4 py-3 text-sm font-semibold text-neutral-700">Total</td>
                <td className={`px-4 py-3 text-sm font-bold text-right ${isBalanced ? 'text-green-700' : 'text-red-600'}`}>
                  ₹{totalDebit.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                </td>
                <td className={`px-4 py-3 text-sm font-bold text-right ${isBalanced ? 'text-green-700' : 'text-red-600'}`}>
                  ₹{totalCredit.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                </td>
                <td />
              </tr>
            </tfoot>
          </table>
        </div>

        <div className="px-5 py-3 border-t border-neutral-100">
          <button
            onClick={addLine}
            className="flex items-center gap-1.5 text-sm text-primary-600 hover:text-primary-700 font-medium"
          >
            <PlusIcon className="h-4 w-4" />
            Add Line
          </button>
        </div>
      </div>

      {/* Bill Passing Checklist (Purchase vouchers only) */}
      {isPurchaseVoucher && (
        <div className="bg-white rounded-2xl border border-neutral-100 p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold text-neutral-800">Bill Passing Checklist</h3>
              <p className="text-xs text-neutral-400 mt-0.5">Required for purchase vouchers — all 7 items must be verified</p>
            </div>
            <div className={`px-3 py-1.5 rounded-xl text-xs font-semibold ${
              billPassingComplete ? 'bg-green-50 text-green-700' : 'bg-amber-50 text-amber-700'
            }`}>
              {checklistCount}/7 checked
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {BILL_PASSING_ITEMS.map(item => (
              <label
                key={item.key}
                className={`flex items-start gap-3 p-3 rounded-xl border cursor-pointer transition ${
                  billPassing[item.key]
                    ? 'bg-green-50 border-green-200'
                    : 'bg-neutral-50 border-neutral-100 hover:border-neutral-200'
                }`}
              >
                <input
                  type="checkbox"
                  checked={billPassing[item.key]}
                  onChange={e => setBillPassing(prev => ({ ...prev, [item.key]: e.target.checked }))}
                  className="mt-0.5 h-4 w-4 rounded text-green-600 border-neutral-300 focus:ring-green-500"
                />
                <div>
                  <p className={`text-sm font-medium ${billPassing[item.key] ? 'text-green-800' : 'text-neutral-700'}`}>
                    {item.label}
                  </p>
                  <p className="text-xs text-neutral-400 mt-0.5">{item.description}</p>
                </div>
              </label>
            ))}
          </div>
          {!billPassingComplete && (
            <div className="mt-3 flex items-center gap-2 text-xs text-amber-700 bg-amber-50 rounded-xl px-3 py-2">
              <ExclamationCircleIcon className="h-4 w-4 flex-shrink-0" />
              All checklist items must be verified before submitting a purchase voucher
            </div>
          )}
        </div>
      )}

      {/* Actions */}
      <div className="flex items-center justify-between">
        <button
          onClick={() => navigate('/accounts/vouchers')}
          className="px-4 py-2 text-sm text-neutral-600 bg-white border border-neutral-200 rounded-xl hover:bg-neutral-50 transition"
        >
          Cancel
        </button>
        <div className="flex gap-3">
          <button
            onClick={() => handleSubmit('draft')}
            disabled={submitting}
            className="px-4 py-2 text-sm text-neutral-700 bg-white border border-neutral-200 rounded-xl hover:bg-neutral-50 transition disabled:opacity-50"
          >
            Save as Draft
          </button>
          <button
            onClick={() => handleSubmit('submit')}
            disabled={!isBalanced || !narration || (isPurchaseVoucher && !billPassingComplete) || submitting}
            className="px-5 py-2 text-sm font-medium text-white bg-primary-600 rounded-xl hover:bg-primary-700 transition disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {submitting ? 'Submitting…' : 'Submit for Approval'}
          </button>
        </div>
      </div>
    </div>
  );
}
