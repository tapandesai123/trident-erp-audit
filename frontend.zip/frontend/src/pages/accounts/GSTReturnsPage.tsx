import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import PageHeader from '@/components/ui/PageHeader';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import Badge from '@/components/ui/Badge';
import { accountsService } from '@/services/accounts';

const STATUS_BADGE: Record<string, any> = {
  FILED: 'success', PENDING: 'warning', DRAFT: 'neutral', NIL: 'info',
};

export default function GSTReturnsPage() {
  const [period, setPeriod] = useState('');

  const { data: returns, isLoading } = useQuery({
    queryKey: ['gst-returns'],
    queryFn: () => accountsService.listGSTReturns(),
  });
  const { data: recon, isLoading: reconLoading } = useQuery({
    queryKey: ['gst-recon', period],
    queryFn: () => accountsService.getGSTReconciliation(period),
    enabled: !!period,
  });

  const list = Array.isArray(returns) ? returns : [];
  const reconList = Array.isArray(recon) ? recon : [];

  return (
    <div className="space-y-5">
      <PageHeader title="GST Returns" subtitle="GSTR-1, GSTR-3B, GSTR-9 and 2B Reconciliation" />
      {isLoading ? <LoadingSpinner /> : (
        <div className="card overflow-hidden">
          <table className="table">
            <thead><tr><th>Return Type</th><th>Period</th><th>Due Date</th><th>Filed Date</th><th>Taxable Value (₹)</th><th>Tax Amount (₹)</th><th>Status</th><th>Actions</th></tr></thead>
            <tbody>
              {list.length === 0
                ? <tr><td colSpan={8} className="text-center py-8 text-neutral-400">No returns found.</td></tr>
                : list.map((r: any) => (
                  <tr key={r.id} className="hover:bg-neutral-50">
                    <td className="font-medium text-sm">{r.return_type}</td>
                    <td className="text-sm text-neutral-500">{r.period}</td>
                    <td className="text-sm text-neutral-500">{r.due_date}</td>
                    <td className="text-sm">{r.filed_date || '—'}</td>
                    <td className="text-right tabular-nums">₹{Number(r.taxable_value || 0).toLocaleString('en-IN')}</td>
                    <td className="text-right tabular-nums">₹{Number(r.tax_amount || 0).toLocaleString('en-IN')}</td>
                    <td><Badge variant={STATUS_BADGE[r.status] || 'neutral'}>{r.status}</Badge></td>
                    <td>
                      <button className="text-xs text-primary-600 hover:underline mr-2"
                        onClick={() => { if (r.period) setPeriod(r.period); }}>Reconcile</button>
                      <button className="text-xs text-neutral-500 hover:underline">Download</button>
                    </td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
      )}
      {period && (
        <div className="card overflow-hidden">
          <div className="px-4 py-3 border-b border-neutral-100 flex items-center justify-between">
            <h3 className="text-sm font-semibold text-neutral-700">2B Reconciliation — {period}</h3>
            <button className="text-xs text-neutral-400 hover:text-neutral-600" onClick={() => setPeriod('')}>Close</button>
          </div>
          {reconLoading ? <LoadingSpinner /> : (
            <table className="table">
              <thead><tr><th>Vendor GSTIN</th><th>Invoice No.</th><th>Invoice Date</th><th>Taxable Value</th><th>IGST</th><th>CGST</th><th>SGST</th><th>Match Status</th></tr></thead>
              <tbody>
                {reconList.length === 0
                  ? <tr><td colSpan={8} className="text-center py-6 text-neutral-400">No mismatches found.</td></tr>
                  : reconList.map((r: any) => (
                    <tr key={r.id} className="hover:bg-neutral-50">
                      <td className="font-mono text-xs">{r.gstin}</td>
                      <td className="text-sm">{r.invoice_number}</td>
                      <td className="text-sm text-neutral-500">{r.invoice_date}</td>
                      <td className="text-right tabular-nums">₹{Number(r.taxable_value || 0).toLocaleString('en-IN')}</td>
                      <td className="text-right tabular-nums text-xs">{r.igst || '—'}</td>
                      <td className="text-right tabular-nums text-xs">{r.cgst || '—'}</td>
                      <td className="text-right tabular-nums text-xs">{r.sgst || '—'}</td>
                      <td><Badge variant={r.match_status === 'MATCHED' ? 'success' : r.match_status === 'MISMATCH' ? 'danger' : 'warning'}>{r.match_status || 'PENDING'}</Badge></td>
                    </tr>
                  ))}
              </tbody>
            </table>
          )}
        </div>
      )}
    </div>
  );
}
