import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import PageHeader from '@/components/ui/PageHeader';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import { accountsService } from '@/services/accounts';

function AgingTable({ data }: { data: any[] }) {
  return (
    <table className="table">
      <thead>
        <tr>
          <th>Party</th>
          <th className="text-right">Current</th>
          <th className="text-right">1-30 Days</th>
          <th className="text-right">31-60 Days</th>
          <th className="text-right">61-90 Days</th>
          <th className="text-right">90+ Days</th>
          <th className="text-right">Total</th>
        </tr>
      </thead>
      <tbody>
        {data.length === 0
          ? <tr><td colSpan={7} className="text-center py-8 text-neutral-400">No data.</td></tr>
          : data.map((row: any) => (
            <tr key={row.party_name} className="hover:bg-neutral-50">
              <td className="font-medium">{row.party_name || row.name}</td>
              {['current', 'days_1_30', 'days_31_60', 'days_61_90', 'days_90_plus'].map(k => (
                <td key={k} className="text-right tabular-nums text-sm">
                  <span className={k.includes('90') && Number(row[k]) > 0 ? 'text-danger-600 font-semibold' : ''}>
                    {Number(row[k] || 0) > 0 ? `₹${Number(row[k]).toLocaleString('en-IN')}` : '—'}
                  </span>
                </td>
              ))}
              <td className="text-right tabular-nums font-semibold">₹{Number(row.total || row.total_outstanding || 0).toLocaleString('en-IN')}</td>
            </tr>
          ))}
      </tbody>
    </table>
  );
}

export default function OutstandingPage() {
  const [tab, setTab] = useState<'ar' | 'ap'>('ar');

  const { data: arData, isLoading: arLoading } = useQuery({ queryKey: ['ar-aging'], queryFn: () => accountsService.getARAging() });
  const { data: apData, isLoading: apLoading } = useQuery({ queryKey: ['ap-aging'], queryFn: () => accountsService.getAPAging() });

  const isLoading = tab === 'ar' ? arLoading : apLoading;
  const data = (tab === 'ar' ? arData : apData) as any[] || [];

  return (
    <div className="space-y-5">
      <PageHeader title="Outstanding Management" subtitle="Aging analysis — AR & AP" />
      <div className="flex gap-2 border-b border-neutral-200">
        {[{ key: 'ar', label: 'Receivables (AR)' }, { key: 'ap', label: 'Payables (AP)' }].map(({ key, label }) => (
          <button key={key} onClick={() => setTab(key as any)}
            className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors ${tab === key ? 'border-primary-600 text-primary-700' : 'border-transparent text-neutral-500 hover:text-neutral-700'}`}>
            {label}
          </button>
        ))}
      </div>
      {isLoading ? <LoadingSpinner /> : (
        <div className="card overflow-hidden">
          <AgingTable data={data} />
        </div>
      )}
    </div>
  );
}
