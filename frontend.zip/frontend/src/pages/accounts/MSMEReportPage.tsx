import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import PageHeader from '@/components/ui/PageHeader';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import api from '@/services/api';

const today = new Date().toISOString().split('T')[0];

function fmt(n: number) {
  return '₹' + Number(n).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function SummaryCard({ label, value, sub }: { label: string; value: string | number; sub?: string }) {
  return (
    <div className="card p-5 flex flex-col gap-1">
      <p className="text-xs font-medium text-neutral-500 uppercase tracking-wide">{label}</p>
      <p className="text-2xl font-bold text-neutral-800 tabular-nums">{value}</p>
      {sub && <p className="text-xs text-neutral-400">{sub}</p>}
    </div>
  );
}

export default function MSMEReportPage() {
  const [asOfDate, setAsOfDate] = useState(today);

  const { data, isLoading, error } = useQuery({
    queryKey: ['msme-report', asOfDate],
    queryFn: async () => {
      const res = await api.get(`/accounts/msme-report/?as_of_date=${asOfDate}`);
      return res.data as { summary: any; bills: any[] };
    },
  });

  const summary = data?.summary;
  const bills = data?.bills ?? [];

  function handleExport() {
    const url = `/api/accounts/msme-report/export/?as_of_date=${asOfDate}`;
    const a = document.createElement('a');
    a.href = url;
    a.download = `MSME_Compliance_Report_${asOfDate}.xlsx`;
    a.click();
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="MSME Compliance Report"
        subtitle="Overdue bills from MSME-registered vendors (> 45 days) with interest liability"
      />

      {/* Controls */}
      <div className="card p-4 flex flex-wrap items-end gap-4">
        <div className="flex flex-col gap-1">
          <label className="text-xs font-medium text-neutral-600 uppercase tracking-wide">As of Date</label>
          <input
            type="date"
            value={asOfDate}
            max={today}
            onChange={e => setAsOfDate(e.target.value)}
            className="input w-44"
          />
        </div>
        <button
          onClick={handleExport}
          className="btn btn-outline flex items-center gap-2"
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
              d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
          </svg>
          Export to Excel
        </button>
      </div>

      {/* Summary Cards */}
      {summary && (
        <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
          <SummaryCard
            label="Total MSME Vendors"
            value={summary.total_msme_vendors}
            sub="with overdue bills"
          />
          <SummaryCard
            label="Overdue Bills"
            value={summary.total_overdue_bills}
            sub="bills > 45 days"
          />
          <SummaryCard
            label="Overdue Amount"
            value={fmt(summary.total_overdue_amount)}
            sub="outstanding"
          />
          <SummaryCard
            label="Interest Liability"
            value={fmt(summary.total_interest)}
            sub="@ 3% p.a. on delayed days"
          />
        </div>
      )}

      {/* Table */}
      <div className="card overflow-hidden">
        <div className="px-5 py-3 border-b border-neutral-100 flex items-center justify-between">
          <h3 className="text-sm font-semibold text-neutral-700">
            Bill-wise Overdue Detail
          </h3>
          <span className="text-xs text-neutral-400 bg-red-50 text-red-600 px-2 py-0.5 rounded">
            Red rows = overdue &gt; 45 days (all shown are flagged)
          </span>
        </div>

        {isLoading ? (
          <div className="flex justify-center py-12"><LoadingSpinner /></div>
        ) : error ? (
          <div className="p-6 text-center text-danger-600">Failed to load report.</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="table">
              <thead>
                <tr>
                  <th>Vendor</th>
                  <th>MSME Type</th>
                  <th>Bill #</th>
                  <th>Bill Date</th>
                  <th>Due Date</th>
                  <th className="text-right">Amount (₹)</th>
                  <th className="text-right">Days Overdue</th>
                  <th className="text-right">Interest (₹)</th>
                </tr>
              </thead>
              <tbody>
                {bills.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="text-center py-10 text-neutral-400">
                      No overdue MSME bills as of {asOfDate}.
                    </td>
                  </tr>
                ) : (
                  bills.map((bill: any, i: number) => (
                    <tr
                      key={i}
                      className={bill.days_overdue > 45 ? 'bg-red-50 hover:bg-red-100' : 'hover:bg-neutral-50'}
                    >
                      <td>
                        <div className="font-medium text-neutral-800">{bill.vendor_name}</div>
                        {bill.msme_number && (
                          <div className="text-xs text-neutral-400">{bill.msme_number}</div>
                        )}
                      </td>
                      <td>
                        <span className={`badge ${bill.msme_type === 'MICRO' ? 'badge-blue' : bill.msme_type === 'SMALL' ? 'badge-amber' : 'badge-green'}`}>
                          {bill.msme_type || '—'}
                        </span>
                      </td>
                      <td className="font-mono text-sm">{bill.bill_number}</td>
                      <td className="text-sm text-neutral-600">{bill.bill_date}</td>
                      <td className="text-sm text-neutral-600">{bill.due_date}</td>
                      <td className="text-right tabular-nums font-medium">
                        {fmt(bill.amount)}
                      </td>
                      <td className="text-right tabular-nums">
                        <span className="font-semibold text-red-700">{bill.days_overdue}</span>
                        <span className="text-neutral-400 text-xs ml-1">days</span>
                      </td>
                      <td className="text-right tabular-nums text-orange-700 font-medium">
                        {fmt(bill.interest_liability)}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
              {bills.length > 0 && summary && (
                <tfoot>
                  <tr className="bg-neutral-50 font-semibold border-t-2 border-neutral-200">
                    <td colSpan={5} className="text-right text-sm text-neutral-600 pr-4">Totals</td>
                    <td className="text-right tabular-nums">{fmt(summary.total_overdue_amount)}</td>
                    <td></td>
                    <td className="text-right tabular-nums text-orange-700">{fmt(summary.total_interest)}</td>
                  </tr>
                </tfoot>
              )}
            </table>
          </div>
        )}
      </div>

      {/* Note */}
      <p className="text-xs text-neutral-400 text-center">
        Interest calculated as: Outstanding Amount × 3% p.a. × Days Overdue / 365
        &nbsp;|&nbsp; Pursuant to Section 16 of MSMED Act, 2006.
      </p>
    </div>
  );
}
