import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { PlusIcon, MagnifyingGlassIcon, DocumentTextIcon, BanknotesIcon, ReceiptPercentIcon } from '@heroicons/react/24/outline';
import PageHeader from '@/components/ui/PageHeader';
import Badge from '@/components/ui/Badge';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import { accountsService, VoucherType, VoucherStatus } from '@/services/accounts';

const TYPE_CONFIG: Record<VoucherType, { label: string; color: string; icon: React.ElementType }> = {
  PURCHASE: { label: 'Purchase', color: 'bg-orange-100 text-orange-700', icon: DocumentTextIcon },
  PAYMENT:  { label: 'Payment',  color: 'bg-red-100 text-red-700',    icon: BanknotesIcon },
  RECEIPT:  { label: 'Receipt',  color: 'bg-green-100 text-green-700', icon: ReceiptPercentIcon },
  JOURNAL:  { label: 'Journal',  color: 'bg-purple-100 text-purple-700', icon: DocumentTextIcon },
};

const STATUS_BADGE: Record<VoucherStatus, 'neutral' | 'warning' | 'success' | 'info' | 'danger'> = {
  DRAFT: 'neutral', PENDING: 'warning', APPROVED: 'info', POSTED: 'success', CANCELLED: 'danger',
};

export default function VoucherListPage() {
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [type, setType] = useState('');
  const [status, setStatus] = useState('');

  const { data, isLoading } = useQuery({
    queryKey: ['vouchers', search, type, status],
    queryFn: () => accountsService.listVouchers({ search, voucher_type: type, status } as any),
  });
  const vouchers = Array.isArray(data) ? data : (data as any)?.results || [];

  return (
    <div className="space-y-5">
      <PageHeader title="Vouchers"
        actions={<button className="btn btn-primary" onClick={() => navigate('/accounts/vouchers/new')}><PlusIcon className="h-4 w-4 mr-1" />New Voucher</button>} />
      <div className="flex gap-3 flex-wrap">
        <div className="relative flex-1 min-w-[200px]"><MagnifyingGlassIcon className="absolute left-3 top-2.5 h-4 w-4 text-neutral-400" /><input className="input pl-9" placeholder="Search…" value={search} onChange={e => setSearch(e.target.value)} /></div>
        <select className="input w-36" value={type} onChange={e => setType(e.target.value)}>
          <option value="">All Types</option>
          {Object.entries(TYPE_CONFIG).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
        </select>
        <select className="input w-36" value={status} onChange={e => setStatus(e.target.value)}>
          <option value="">All Status</option>
          {['DRAFT','PENDING','APPROVED','POSTED','CANCELLED'].map(s => <option key={s} value={s}>{s}</option>)}
        </select>
      </div>
      {isLoading ? <LoadingSpinner /> : (
        <div className="card overflow-hidden">
          <table className="table">
            <thead><tr><th>Voucher No.</th><th>Type</th><th>Date</th><th>Party</th><th>Narration</th><th className="text-right">Amount (₹)</th><th>Status</th></tr></thead>
            <tbody>
              {vouchers.length === 0
                ? <tr><td colSpan={7} className="text-center py-8 text-neutral-400">No vouchers found.</td></tr>
                : vouchers.map((v: any) => {
                    const cfg = TYPE_CONFIG[v.voucher_type as VoucherType] || TYPE_CONFIG.JOURNAL;
                    const Icon = cfg.icon;
                    return (
                      <tr key={v.id} className="hover:bg-neutral-50 cursor-pointer" onClick={() => navigate(`/accounts/vouchers/${v.id}`)}>
                        <td className="font-mono text-sm font-medium text-primary-700">{v.voucher_number}</td>
                        <td><span className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-xs font-medium ${cfg.color}`}><Icon className="h-3 w-3" />{cfg.label}</span></td>
                        <td className="text-sm text-neutral-500">{v.date}</td>
                        <td className="text-sm">{v.party_name || '—'}</td>
                        <td className="text-sm text-neutral-500 max-w-xs truncate">{v.narration}</td>
                        <td className="text-right tabular-nums font-medium">₹{Number(v.total_debit || 0).toLocaleString('en-IN')}</td>
                        <td><Badge variant={STATUS_BADGE[v.status as VoucherStatus] || 'neutral'}>{v.status}</Badge></td>
                      </tr>
                    );
                  })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
