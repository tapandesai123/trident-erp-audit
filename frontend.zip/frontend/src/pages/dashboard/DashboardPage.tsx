import { useQuery } from '@tanstack/react-query';
import {
  ShoppingCartIcon,
  ArchiveBoxXMarkIcon,
  ClipboardDocumentCheckIcon,
  ExclamationCircleIcon,
  TruckIcon,
} from '@heroicons/react/24/outline';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { Bar, Pie } from 'react-chartjs-2';
import api from '@/services/api';
import Card from '@/components/ui/Card';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import PageHeader from '@/components/ui/PageHeader';
import { formatCurrency } from '@/utils/format';

ChartJS.register(CategoryScale, LinearScale, BarElement, ArcElement, Title, Tooltip, Legend);

interface DashboardSummary {
  pending_prs: number;
  pending_pos: number;
  low_stock_items: number;
  overdue_tasks: number;
  todays_gate_entries: number;
}

interface PipelineSummary {
  stages: { stage: string; count: number; value: number }[];
}

interface MonthlyPurchase {
  months: string[];
  values: number[];
}

function useDashboard() {
  const summary = useQuery<DashboardSummary>({
    queryKey: ['dashboard', 'summary'],
    queryFn: async () => {
      const { data } = await api.get('reports/dashboard_summary/');
      return data;
    },
  });

  const pipeline = useQuery<PipelineSummary>({
    queryKey: ['dashboard', 'pipeline'],
    queryFn: async () => {
      const { data } = await api.get('purchase/reports/pipeline_summary/');
      return data;
    },
  });

  const monthlyPurchase = useQuery<MonthlyPurchase>({
    queryKey: ['dashboard', 'monthly-purchase'],
    queryFn: async () => {
      const { data } = await api.get('purchase/reports/monthly_value/');
      return data;
    },
  });

  return { summary, pipeline, monthlyPurchase };
}

const SUMMARY_CARDS = [
  {
    key: 'pending_prs' as const,
    title: 'Pending PRs',
    icon: <ShoppingCartIcon className="h-5 w-5" />,
    href: '/purchase/requisitions?status=PENDING',
  },
  {
    key: 'pending_pos' as const,
    title: 'Pending POs',
    icon: <ClipboardDocumentCheckIcon className="h-5 w-5" />,
    href: '/purchase/orders?status=PENDING',
  },
  {
    key: 'low_stock_items' as const,
    title: 'Low Stock Items',
    icon: <ArchiveBoxXMarkIcon className="h-5 w-5" />,
    href: '/stores/inventory?filter=low_stock',
  },
  {
    key: 'overdue_tasks' as const,
    title: 'Overdue Tasks',
    icon: <ExclamationCircleIcon className="h-5 w-5" />,
    href: '/tasks?filter=overdue',
  },
  {
    key: 'todays_gate_entries' as const,
    title: "Today's Gate Entries",
    icon: <TruckIcon className="h-5 w-5" />,
    href: '/purchase/gate-entries',
  },
];

const PIPELINE_COLORS = [
  'rgba(30, 64, 175, 0.85)',
  'rgba(245, 158, 11, 0.85)',
  'rgba(34, 197, 94, 0.85)',
  'rgba(239, 68, 68, 0.85)',
  'rgba(99, 102, 241, 0.85)',
];

export default function DashboardPage() {
  const { summary, pipeline, monthlyPurchase } = useDashboard();

  return (
    <div>
      <PageHeader
        title="Dashboard"
        description="Overview of your ERP operations"
      />

      {/* Summary Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4 mb-8">
        {SUMMARY_CARDS.map((card) => (
          <Card
            key={card.key}
            title={card.title}
            value={
              summary.isLoading
                ? '—'
                : summary.data?.[card.key] ?? 0
            }
            icon={card.icon}
            className="cursor-pointer hover:shadow-md transition-shadow"
          />
        ))}
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Monthly Purchase Bar Chart */}
        <div className="lg:col-span-2 card">
          <h3 className="text-sm font-semibold text-neutral-700 mb-4">Monthly Purchase Value (INR)</h3>
          {monthlyPurchase.isLoading ? (
            <div className="flex items-center justify-center h-48">
              <LoadingSpinner size="lg" className="text-primary-600" />
            </div>
          ) : monthlyPurchase.data ? (
            <Bar
              data={{
                labels: monthlyPurchase.data.months,
                datasets: [
                  {
                    label: 'Purchase Value',
                    data: monthlyPurchase.data.values,
                    backgroundColor: 'rgba(30, 64, 175, 0.75)',
                    borderColor: 'rgba(30, 64, 175, 1)',
                    borderWidth: 1,
                    borderRadius: 4,
                  },
                ],
              }}
              options={{
                responsive: true,
                plugins: {
                  legend: { display: false },
                  tooltip: {
                    callbacks: {
                      label: (ctx) => formatCurrency(ctx.raw as number),
                    },
                  },
                },
                scales: {
                  y: {
                    ticks: {
                      callback: (v) =>
                        '₹' + Intl.NumberFormat('en-IN', { notation: 'compact' }).format(Number(v)),
                    },
                    grid: { color: 'rgba(0,0,0,0.04)' },
                  },
                  x: { grid: { display: false } },
                },
              }}
            />
          ) : (
            <div className="flex items-center justify-center h-48 text-sm text-neutral-400">
              No data available
            </div>
          )}
        </div>

        {/* Pipeline Pie Chart */}
        <div className="card">
          <h3 className="text-sm font-semibold text-neutral-700 mb-4">Sales Pipeline</h3>
          {pipeline.isLoading ? (
            <div className="flex items-center justify-center h-48">
              <LoadingSpinner size="lg" className="text-primary-600" />
            </div>
          ) : pipeline.data?.stages?.length ? (
            <div>
              <Pie
                data={{
                  labels: pipeline.data.stages.map((s) => s.stage),
                  datasets: [
                    {
                      data: pipeline.data.stages.map((s) => s.value),
                      backgroundColor: PIPELINE_COLORS,
                      borderWidth: 2,
                      borderColor: '#fff',
                    },
                  ],
                }}
                options={{
                  responsive: true,
                  plugins: {
                    legend: { position: 'bottom', labels: { font: { size: 11 } } },
                    tooltip: {
                      callbacks: {
                        label: (ctx) =>
                          ` ${ctx.label}: ${formatCurrency(ctx.raw as number)}`,
                      },
                    },
                  },
                }}
              />
              <div className="mt-4 space-y-1">
                {pipeline.data.stages.map((s) => (
                  <div key={s.stage} className="flex items-center justify-between text-xs">
                    <span className="text-neutral-600">{s.stage}</span>
                    <span className="font-medium text-neutral-800">{s.count} deals</span>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="flex items-center justify-center h-48 text-sm text-neutral-400">
              No pipeline data
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
