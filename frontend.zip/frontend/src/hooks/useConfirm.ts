import { useState, useCallback } from 'react';

interface ConfirmState {
  open: boolean;
  title?: string;
  message?: string;
  confirmLabel?: string;
  onConfirm: () => void;
}

const DEFAULT_STATE: ConfirmState = {
  open: false,
  onConfirm: () => {},
};

export function useConfirm() {
  const [state, setState] = useState<ConfirmState>(DEFAULT_STATE);

  const confirm = useCallback(
    (opts: { title?: string; message?: string; confirmLabel?: string; onConfirm: () => void }) => {
      setState({ open: true, ...opts });
    },
    []
  );

  const close = useCallback(() => {
    setState(DEFAULT_STATE);
  }, []);

  const handleConfirm = useCallback(() => {
    state.onConfirm();
    close();
  }, [state, close]);

  return {
    confirmState: state,
    confirm,
    closeConfirm: close,
    handleConfirm,
  };
}
