import { useState } from 'react';
import { DEFAULT_PAGE_SIZE } from '@/utils/constants';

export function usePagination(initialPageSize = DEFAULT_PAGE_SIZE) {
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(initialPageSize);

  const offset = (page - 1) * pageSize;

  const reset = () => setPage(1);

  const handlePageSizeChange = (size: number) => {
    setPageSize(size);
    setPage(1);
  };

  return {
    page,
    pageSize,
    offset,
    limit: pageSize,
    setPage,
    setPageSize: handlePageSizeChange,
    reset,
    // Query params for API
    queryParams: { limit: pageSize, offset },
  };
}
