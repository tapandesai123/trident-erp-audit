import { useEffect } from 'react';
import { useBeforeUnload, unstable_useBlocker as useBlocker } from 'react-router-dom';

/**
 * Warns the user before:
 * 1. Closing/refreshing the tab (browser beforeunload)
 * 2. Navigating away via React Router
 */
export function useUnsavedChanges(isDirty: boolean) {
  // Browser refresh / close
  useBeforeUnload(
    (e) => {
      if (isDirty) {
        e.preventDefault();
        e.returnValue = '';
      }
    },
    { capture: true }
  );

  // React Router navigation
  const blocker = useBlocker(isDirty);

  useEffect(() => {
    if (blocker.state === 'blocked') {
      const ok = window.confirm('You have unsaved changes. Are you sure you want to leave?');
      if (ok) blocker.proceed();
      else blocker.reset();
    }
  }, [blocker]);
}
