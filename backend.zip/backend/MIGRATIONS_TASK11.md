# Task 11 — Migrations

Run these in order after deploying Task 11 code:

```bash
# 1. Generate all new migrations
python manage.py makemigrations purchase    # VendorSauda, SaudaPOLink, RGPChallan, RGPLine, MRR.rgp_reference
python manage.py makemigrations sales      # Invoice export fields (30+ new fields)
python manage.py makemigrations production # ProductionDowntime
python manage.py makemigrations core       # MLFBillingRecord, MLFUsageSnapshot

# 2. Apply all migrations
python manage.py migrate

# 3. Verify new tables
python manage.py shell -c "
from apps.purchase.models import VendorSauda, RGPChallan
from apps.sales.models import Invoice
from apps.production.models import ProductionDowntime
from apps.core.models import MLFBillingRecord
print('All models OK')
print('Invoice has port_of_loading:', hasattr(Invoice, 'port_of_loading'))
print('VendorSauda exists:', VendorSauda.objects.count())
"

# 4. Seed demo data
python manage.py seed_masters

# 5. Run tests
python manage.py test apps.purchase.tests apps.sales.tests apps.production.tests
```

## New Tables Summary

| App       | New Model(s)                          |
|-----------|---------------------------------------|
| purchase  | VendorSauda, SaudaPOLink              |
| purchase  | RGPChallan, RGPLine                   |
| purchase  | MRR.rgp_reference (FK added)          |
| sales     | Invoice (30 export fields added)      |
| production| ProductionDowntime                    |
| core      | MLFBillingRecord, MLFUsageSnapshot    |
