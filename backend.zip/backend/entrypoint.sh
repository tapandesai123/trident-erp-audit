#!/bin/bash
set -e

echo "=== Trident ERP Backend Startup ==="
echo "Django settings: $DJANGO_SETTINGS_MODULE"
echo "Database URL: ${DATABASE_URL//:*@/:***@}"  # mask password

# Wait for DB to be ready (extra safety beyond Docker healthcheck)
echo "Waiting for database..."
until python -c "
import psycopg, os, sys
try:
    conn = psycopg.connect(os.environ['DATABASE_URL'])
    conn.close()
    print('DB ready')
except Exception as e:
    print(f'DB not ready: {e}')
    sys.exit(1)
" 2>&1; do
  echo "  retrying in 2s..."
  sleep 2
done

echo "Running migrations..."
python manage.py migrate --noinput

echo "Collecting static files..."
python manage.py collectstatic --noinput --clear

echo "Starting Gunicorn..."
exec gunicorn config.wsgi:application \
  --bind 0.0.0.0:8000 \
  --workers 2 \
  --timeout 120 \
  --reload \
  --access-logfile - \
  --error-logfile - \
  --log-level info
