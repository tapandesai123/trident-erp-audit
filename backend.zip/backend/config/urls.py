"""Trident ERP URL Configuration."""
from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from drf_spectacular.views import SpectacularAPIView, SpectacularSwaggerView, SpectacularRedocView

api_v1_patterns = [
    path("auth/", include("apps.core.api.urls_auth")),
    path("core/", include("apps.core.api.urls")),
    path("masters/", include("apps.masters.api.urls")),
    path("purchase/", include("apps.purchase.api.urls")),
    path("stores/", include("apps.stores.api.urls")),
    path("sales/", include("apps.sales.api.urls")),
    path("accounts/", include("apps.accounts.api.urls")),
    path("production/", include("apps.production.api.urls")),
    path("quality/", include("apps.quality.api.urls")),
    path("tasks/", include("apps.tasks.api.urls")),
    path("reports/", include("apps.reports.api.urls")),
    path("webtel/", include("apps.webtel.api.urls")),
    path("hr/", include("apps.hr.api.urls")),
    path("assets/", include("apps.assets.api.urls")),
    path("projects/", include("apps.projects.api.urls")),
    path("payroll/", include("apps.payroll.api.urls")),
    path("crm/", include("apps.crm.api.urls")),
    path("dispatch/", include("apps.dispatch.api.urls")),
    path("maintenance/", include("apps.maintenance.api.urls")),
    path("edi/", include("apps.edi.api.urls")),
]

urlpatterns = [
    path("admin/", admin.site.urls),

    # API v1
    path("api/v1/", include(api_v1_patterns)),

    # Customer Portal API (standalone — separate auth)
    path("api/portal/", include("apps.portal.api.urls")),

    # OpenAPI schema & docs
    path("api/schema/", SpectacularAPIView.as_view(), name="schema"),
    path("api/docs/", SpectacularSwaggerView.as_view(url_name="schema"), name="swagger-ui"),
    path("api/redoc/", SpectacularRedocView.as_view(url_name="schema"), name="redoc"),

    # Health check
    path("api/health/", include("apps.core.api.urls_health")),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    try:
        import debug_toolbar
        urlpatterns += [path("__debug__/", include(debug_toolbar.urls))]
    except ImportError:
        pass
