"""
Trident ERP - Base Django Settings
"""
import os
from pathlib import Path
from datetime import timedelta

import environ

env = environ.Env(DEBUG=(bool, False))

BASE_DIR = Path(__file__).resolve().parent.parent.parent

environ.Env.read_env(os.path.join(BASE_DIR, ".env"))

SECRET_KEY = env("SECRET_KEY", default="insecure-dev-key-change-me")

# ─── Security: Fail fast on insecure SECRET_KEY (BUG-021) ─────────
_INSECURE_DEFAULTS = {
    'dev-secret-key-change-in-production',
    'insecure-dev-key-change-me',
    '',
}
if SECRET_KEY in _INSECURE_DEFAULTS and not env.bool('DJANGO_ALLOW_INSECURE_KEY', default=False):
    from django.core.exceptions import ImproperlyConfigured
    raise ImproperlyConfigured(
        'SECRET_KEY is set to an insecure default. Set a strong random key in your .env file. '
        'Generate with: python -c "import secrets; print(secrets.token_hex(50))"'
    )

# ─── Portal JWT Secret (BUG-019) ──────────────────────────────────
PORTAL_JWT_SECRET_KEY = env('PORTAL_JWT_SECRET_KEY', default='')
DEBUG = env("DEBUG", default=False)
ALLOWED_HOSTS = env.list("ALLOWED_HOSTS", default=["*"])

# ─── Installed Apps ───────────────────────────────────────────────
DJANGO_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
]

THIRD_PARTY_APPS = [
    "rest_framework",
    "rest_framework_simplejwt",
    "rest_framework_simplejwt.token_blacklist",
    "corsheaders",
    "django_filters",
    "django_extensions",
    "django_celery_beat",
    "django_celery_results",
    "drf_spectacular",
    "import_export",
    "auditlog",
    "simple_history",
    "django_otp",
    "django_otp.plugins.otp_totp",
]

LOCAL_APPS = [
    "apps.core",
    "apps.masters",
    "apps.purchase",
    "apps.stores",
    "apps.sales",
    "apps.accounts",
    "apps.production",
    "apps.quality",
    "apps.tasks",
    "apps.webtel",
    "apps.reports",
    "apps.hr",
    "apps.assets",
    "apps.projects",
    "apps.payroll",
    "apps.crm",
    "apps.dispatch",
    "apps.maintenance",
    "apps.portal",
    "apps.edi",
]

INSTALLED_APPS = DJANGO_APPS + THIRD_PARTY_APPS + LOCAL_APPS

# ─── Middleware ───────────────────────────────────────────────────
MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "whitenoise.middleware.WhiteNoiseMiddleware",
    "corsheaders.middleware.CorsMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
    "auditlog.middleware.AuditlogMiddleware",
    "simple_history.middleware.HistoryRequestMiddleware",
    "apps.core.middleware.PlantContextMiddleware",
]

ROOT_URLCONF = "config.urls"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [BASE_DIR / "templates"],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.debug",
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
            ],
        },
    },
]

WSGI_APPLICATION = "config.wsgi.application"

# ─── Database ─────────────────────────────────────────────────────
DATABASES = {
    "default": env.db("DATABASE_URL", default="postgresql://trident:trident_dev_2026@localhost:5432/trident_erp"),
}
DATABASES["default"]["CONN_MAX_AGE"] = 600
DATABASES["default"]["CONN_HEALTH_CHECKS"] = True

# ─── Cache ────────────────────────────────────────────────────────
CACHES = {
    "default": {
        "BACKEND": "django.core.cache.backends.redis.RedisCache",
        "LOCATION": env("REDIS_URL", default="redis://localhost:6379/0"),
    }
}

# ─── Auth ─────────────────────────────────────────────────────────
AUTH_USER_MODEL = "core.User"

AUTH_PASSWORD_VALIDATORS = [
    {"NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator"},
    {"NAME": "django.contrib.auth.password_validation.MinimumLengthValidator", "OPTIONS": {"min_length": 8}},
    {"NAME": "django.contrib.auth.password_validation.CommonPasswordValidator"},
    {"NAME": "django.contrib.auth.password_validation.NumericPasswordValidator"},
]

# ─── REST Framework ───────────────────────────────────────────────
REST_FRAMEWORK = {
    "DEFAULT_AUTHENTICATION_CLASSES": [
        "rest_framework_simplejwt.authentication.JWTAuthentication",
        "rest_framework.authentication.SessionAuthentication",
    ],
    "DEFAULT_PERMISSION_CLASSES": [
        "rest_framework.permissions.IsAuthenticated",
    ],
    "DEFAULT_FILTER_BACKENDS": [
        "django_filters.rest_framework.DjangoFilterBackend",
        "rest_framework.filters.SearchFilter",
        "rest_framework.filters.OrderingFilter",
    ],
    "DEFAULT_PAGINATION_CLASS": "apps.core.pagination.StandardPagination",
    "PAGE_SIZE": 25,
    "DEFAULT_SCHEMA_CLASS": "drf_spectacular.openapi.AutoSchema",
    "DEFAULT_THROTTLE_CLASSES": [
        "rest_framework.throttling.AnonRateThrottle",
        "rest_framework.throttling.UserRateThrottle",
    ],
    "DEFAULT_THROTTLE_RATES": {
        "anon": "20/minute",
        "user": "200/minute",
    },
    "DATETIME_FORMAT": "%Y-%m-%dT%H:%M:%S%z",
    "DATE_FORMAT": "%Y-%m-%d",
}

# ─── JWT ──────────────────────────────────────────────────────────
SIMPLE_JWT = {
    "ACCESS_TOKEN_LIFETIME": timedelta(minutes=60),
    "REFRESH_TOKEN_LIFETIME": timedelta(days=7),
    "ROTATE_REFRESH_TOKENS": True,
    "BLACKLIST_AFTER_ROTATION": True,
    "AUTH_HEADER_TYPES": ("Bearer",),
    "TOKEN_OBTAIN_SERIALIZER": "apps.core.api.serializers.CustomTokenObtainPairSerializer",
}

# ─── CORS ─────────────────────────────────────────────────────────
CORS_ALLOWED_ORIGINS = env.list("CORS_ALLOWED_ORIGINS", default=[
    "http://localhost:3000",
    "http://localhost:5173",
])
CORS_ALLOW_CREDENTIALS = True

# ─── CSRF ─────────────────────────────────────────────────────────
CSRF_TRUSTED_ORIGINS = env.list("CSRF_TRUSTED_ORIGINS", default=[
    "http://localhost:3000",
    "http://localhost:5173",
    "http://localhost:8000",
])

# ─── Celery ───────────────────────────────────────────────────────
CELERY_BROKER_URL = env("CELERY_BROKER_URL", default="redis://localhost:6379/1")
CELERY_RESULT_BACKEND = "django-db"
CELERY_ACCEPT_CONTENT = ["json"]
CELERY_TASK_SERIALIZER = "json"
CELERY_RESULT_SERIALIZER = "json"
CELERY_TIMEZONE = "Asia/Kolkata"
CELERY_BEAT_SCHEDULER = "django_celery_beat.schedulers:DatabaseScheduler"

# ─── File Storage ─────────────────────────────────────────────────
STORAGES = {
    "default": {
        "BACKEND": env("DEFAULT_FILE_STORAGE", default="django.core.files.storage.FileSystemStorage"),
    },
    "staticfiles": {
        "BACKEND": "django.contrib.staticfiles.storage.StaticFilesStorage",
    },
}
MEDIA_URL = "/media/"
MEDIA_ROOT = BASE_DIR / "media"
STATIC_URL = "/static/"
STATIC_ROOT = BASE_DIR / "staticfiles"

# ─── Email ────────────────────────────────────────────────────────
EMAIL_BACKEND = env("EMAIL_BACKEND", default="django.core.mail.backends.console.EmailBackend")
EMAIL_HOST = env("EMAIL_HOST", default="smtp.gmail.com")
EMAIL_PORT = env.int("EMAIL_PORT", default=587)
EMAIL_USE_TLS = True
EMAIL_HOST_USER = env("EMAIL_HOST_USER", default="")
EMAIL_HOST_PASSWORD = env("EMAIL_HOST_PASSWORD", default="")
DEFAULT_FROM_EMAIL = env("DEFAULT_FROM_EMAIL", default="erp@tridentpaperbox.com")

# ─── Internationalization ─────────────────────────────────────────
LANGUAGE_CODE = "en-us"
TIME_ZONE = "Asia/Kolkata"
USE_I18N = True
USE_TZ = True

# ─── OpenAPI / Swagger ────────────────────────────────────────────
SPECTACULAR_SETTINGS = {
    "TITLE": "Trident ERP API",
    "DESCRIPTION": "Enterprise Resource Planning API for Trident Paper Box Industries",
    "VERSION": "1.0.0",
    "SERVE_INCLUDE_SCHEMA": False,
    "COMPONENT_SPLIT_REQUEST": True,
}

# ─── Audit ────────────────────────────────────────────────────────
AUDITLOG_INCLUDE_ALL_MODELS = True

# ─── Trident ERP Custom Settings ─────────────────────────────────
TRIDENT = {
    "COMPANY_NAME": "Trident Paper Box Industries",
    "DEFAULT_PLANT_CODE": "PARDI",
    "FINANCIAL_YEAR_START_MONTH": 4,  # April
    "DEFAULT_TOLERANCE_PCT": 10.0,
    "FIFO_ENFORCEMENT": "ALERT",  # ALERT or BLOCK
    "QR_CODE_SIZE": "A4",  # A4, HALF_A4, STICKER_60x70
    "MLF_BASE_RATE": 14670.00,  # ₹/month from Year 2
    "MLF_INFLATION_PCT": 7.0,
    "MLF_FREE_YEAR_END": "2027-03-31",
    "SMS_PROVIDER": "MSG91",  # MSG91 or TWILIO
    "MSG91_AUTH_KEY": env("MSG91_AUTH_KEY", default=""),
    "MSG91_SENDER_ID": env("MSG91_SENDER_ID", default="TRDNTP"),
    "OTP_TEMPLATE_ID": env("MSG91_OTP_TEMPLATE_ID", default=""),
    # Twilio (alternate provider)
    "TWILIO_ACCOUNT_SID":  env("TWILIO_ACCOUNT_SID",  default=""),
    "TWILIO_AUTH_TOKEN":   env("TWILIO_AUTH_TOKEN",   default=""),
    "TWILIO_FROM_NUMBER":  env("TWILIO_FROM_NUMBER",  default=""),
}

# ─── Celery Beat Schedule ─────────────────────────────────────────
from celery.schedules import crontab  # noqa: E402

CELERY_BEAT_SCHEDULE = {
    # Stores tasks (Section 4)
    "check-minmax-alerts":  {"task": "stores.check_minmax_alerts",  "schedule": crontab(hour=8, minute=0)},
    # Production delay alerts (F4)
    "check-production-delays": {"task": "apps.production.tasks.check_production_delays", "schedule": crontab(minute=0)},  # Every hour
    # BUG-011: Auto-close completed WOs daily at 1:00 AM
    "auto-close-wos": {
        "task": "apps.production.tasks.auto_close_completed_work_orders",
        "schedule": crontab(hour=1, minute=0),
    },
    # SO material availability → notify production (P1)
    "check-so-material-availability": {
        "task": "apps.production.tasks.check_material_availability_for_so",
        "schedule": crontab(hour=7, minute=30),  # 7:30 AM daily
    },
    "send-minmax-emails":   {"task": "stores.send_minmax_emails",   "schedule": crontab(hour=8, minute=15)},
    "weekly-pv-auto":       {"task": "stores.auto_generate_pv", "schedule": crontab(day_of_week=1)},
    # Accounts tasks (Section 6)
    "send-overdue-ar-reminders": {
        "task": "accounts.send_overdue_reminders",
        "schedule": crontab(hour=9, minute=0),          # 9:00 AM daily
    },
    "send-overdue-payment-sms": {
        "task": "accounts.send_overdue_payment_sms",
        "schedule": crontab(hour=9, minute=10),         # 9:10 AM daily (after email reminders)
    },
    "auto-flag-overdue-bills": {
        "task": "accounts.auto_flag_overdue_bills",
        "schedule": crontab(hour=7, minute=0),          # 7:00 AM daily
    },
    "monthly-gst-summary": {
        "task": "accounts.generate_monthly_gst_summary",
        "schedule": crontab(day_of_month=2, hour=8),   # 2nd of each month
    },
    "tds-deposit-reminder": {
        "task": "accounts.tds_deposit_reminder",
        "schedule": crontab(day_of_month=5, hour=9),   # 5th of each month
    },
    # Webtel tasks (Section 7)
    "webtel-refresh-tokens": {
        "task": "webtel.refresh_all_tokens",
        "schedule": crontab(minute=0, hour="*/5"),     # Every 5 hours
    },
    "webtel-auto-irn": {
        "task": "webtel.auto_generate_irn_for_confirmed_invoices",
        "schedule": crontab(minute="*/30"),            # Every 30 minutes
    },
    "webtel-expiring-eway": {
        "task": "webtel.check_expiring_eway_bills",
        "schedule": crontab(hour=7, minute=0),         # 7:00 AM daily
    },
    "webtel-monthly-gstr2b": {
        "task": "webtel.monthly_gstr2b_fetch",
        "schedule": crontab(day_of_month=14, hour=6),  # 14th of each month
    },
    "webtel-mismatch-emails": {
        "task": "webtel.send_monthly_mismatch_emails",
        "schedule": crontab(day_of_month=16, hour=9),  # 16th of each month
    },
    # Tasks module
    "tasks-mark-overdue": {
        "task": "tasks.mark_overdue_tasks",
        "schedule": crontab(hour=7, minute=0),          # 7:00 AM daily
    },
    "tasks-send-reminders": {
        "task": "tasks.send_task_reminders",
        "schedule": crontab(hour=8, minute=0),          # 8:00 AM daily
    },
    "tasks-weekly-digest": {
        "task": "tasks.send_weekly_task_digest",
        "schedule": crontab(day_of_week=1, hour=9),    # Monday 9:00 AM
    },
    # Purchase tasks
    "purchase-check-po-delivery": {
        "task": "purchase.check_po_delivery_dates",
        "schedule": crontab(hour=8, minute=30),         # 8:30 AM daily
    },
    "purchase-pr-approval-reminders": {
        "task": "purchase.send_pr_approval_reminders",
        "schedule": crontab(hour=9, minute=30),         # 9:30 AM daily
    },
    "purchase-weekly-summary": {
        "task": "purchase.weekly_purchase_summary",
        "schedule": crontab(day_of_week=1, hour=9, minute=15),  # Monday 9:15 AM
    },
    # Sales tasks
    "sales-check-quotation-expiry": {
        "task": "sales.check_quotation_expiry",
        "schedule": crontab(hour=6, minute=0),          # 6:00 AM daily
    },
    "sales-so-delivery-reminders": {
        "task": "sales.send_so_delivery_reminders",
        "schedule": crontab(hour=8, minute=45),         # 8:45 AM daily
    },
    "sales-weekly-summary": {
        "task": "sales.weekly_sales_summary",
        "schedule": crontab(day_of_week=1, hour=9, minute=30),  # Monday 9:30 AM
    },
    # Masters tasks
    "masters-pending-item-approvals": {
        "task": "masters.check_pending_item_approvals",
        "schedule": crontab(hour=10, minute=0),         # 10:00 AM daily
    },
    "masters-vendor-gstin-check": {
        "task": "masters.check_vendor_gstin_expiry",
        "schedule": crontab(day_of_month=1, hour=7),    # 1st of each month, 7:00 AM
    },
    # Stores — Auto PR from consumable consumption history
    "stores-auto-pr-consumption": {
        "task": "apps.stores.tasks.auto_raise_consumption_prs",
        "schedule": crontab(hour=7, minute=0),           # 7:00 AM daily
    },
}

DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

# ── Webtel GSP API Configuration ────────────────────────────────
WEBTEL_CONFIG = {
    "BASE_URL": env("WEBTEL_BASE_URL", default="https://api.webtel.in/gsp/v3"),
    "CLIENT_ID": env("WEBTEL_CLIENT_ID", default=""),
    "CLIENT_SECRET": env("WEBTEL_CLIENT_SECRET", default=""),
    "GSP_USERNAME": env("WEBTEL_GSP_USERNAME", default=""),
    "GSP_PASSWORD": env("WEBTEL_GSP_PASSWORD", default=""),
    "SANDBOX": env.bool("WEBTEL_SANDBOX", default=True),
}
