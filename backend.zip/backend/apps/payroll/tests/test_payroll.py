"""
Payroll & Compliance Module Tests — Section 14

22 test cases covering:
  - Statutory rate computations (PF, ESI, PT)
  - TDS computation (new & old regime, slabs, rebates, cess)
  - PayrollPeriod creation and validation
  - PayrollRun creation and status transitions
  - EmployeePayslip generation and approval
  - PFContribution / ESIContribution / ProfessionalTax records
  - Duplicate-period guard
  - PT annual cap enforcement
"""
from decimal import Decimal
from datetime import date
import calendar

from django.test import TestCase
from django.contrib.auth import get_user_model

from apps.core.models import Plant, Company
from apps.payroll.models import (
    PayrollPeriod, PayrollRun, EmployeePayslip,
    TaxDeclaration, PFContribution, ESIContribution, ProfessionalTax,
)
from apps.payroll import services
from apps.payroll.services import (
    _compute_pt, _compute_income_tax_new_regime,
    _compute_income_tax_old_regime, PT_ANNUAL_CAP,
    PF_WAGE_CEILING, ESI_WAGE_CEILING,
)

User = get_user_model()


# ─── Fixtures ─────────────────────────────────────────────────────

def make_base():
    company = Company.objects.create(name="PAY Test Co", financial_year_start=4)
    plant = Plant.objects.create(company=company, code="PAY1", name="Payroll Plant 1")
    user = User.objects.create_user(username="payroll_mgr", email="pm@test.com", password="x")
    return dict(company=company, plant=plant, user=user)


def make_period(plant, month=5, year=2025, user=None):
    return services.create_payroll_period(
        plant=plant,
        month=month,
        year=year,
        working_days=26,
        created_by=user,
    )


def make_employee(plant, salary_structure=None):
    """Create a minimal Employee for payroll tests."""
    from apps.hr.models import Employee, Department, Designation
    dept, _ = Department.objects.get_or_create(
        plant=plant, code="ENG",
        defaults={"name": "Engineering"},
    )
    desg, _ = Designation.objects.get_or_create(
        plant=plant, code="SE",
        defaults={"name": "Software Engineer", "grade": "L3"},
    )
    emp_count = Employee.objects.count()
    user = User.objects.create_user(
        username=f"emp_{emp_count}", email=f"emp{emp_count}@test.com", password="x"
    )
    emp = Employee.objects.create(
        plant=plant,
        employee_code=f"EMP{emp_count + 1:04d}",
        first_name="Test",
        last_name=f"Employee{emp_count}",
        department=dept,
        designation=desg,
        date_of_joining=date(2023, 1, 1),
        ctc=Decimal("600000"),  # 6 LPA
        uan="100123456789",
        esic_number="3112000100",
        pan="ABCDE1234F",
        salary_structure=salary_structure,
        user=user,
    )
    return emp


# ═══════════════════════════════════════════════════════════════════
# STATUTORY COMPUTATION TESTS
# ═══════════════════════════════════════════════════════════════════

class TestStatutoryComputations(TestCase):
    def test_01_pf_ee_contribution_on_basic_below_ceiling(self):
        """Employee PF = 12% of basic when basic < 15,000."""
        from apps.hr.services import calculate_pf_esi
        result = calculate_pf_esi(Decimal("12000"), Decimal("18000"))
        self.assertEqual(result["employee_pf"], Decimal("1440.00"))  # 12% of 12000

    def test_02_pf_capped_at_wage_ceiling(self):
        """PF computed on 15,000 even if basic is 25,000."""
        from apps.hr.services import calculate_pf_esi
        result = calculate_pf_esi(Decimal("25000"), Decimal("35000"))
        self.assertEqual(result["employee_pf"], Decimal("1800.00"))  # 12% of 15000

    def test_03_esi_applicable_when_gross_below_ceiling(self):
        """ESI applies when gross ≤ 21,000."""
        from apps.hr.services import calculate_pf_esi
        result = calculate_pf_esi(Decimal("10000"), Decimal("18000"))
        self.assertTrue(result["esi_applicable"])
        self.assertEqual(result["employee_esi"], Decimal("135.00"))   # 0.75% of 18000
        self.assertEqual(result["employer_esi"], Decimal("585.00"))   # 3.25% of 18000

    def test_04_esi_not_applicable_above_ceiling(self):
        """ESI does NOT apply when gross > 21,000."""
        from apps.hr.services import calculate_pf_esi
        result = calculate_pf_esi(Decimal("20000"), Decimal("25000"))
        self.assertFalse(result["esi_applicable"])
        self.assertEqual(result["employee_esi"], Decimal("0.00"))
        self.assertEqual(result["employer_esi"], Decimal("0.00"))

    def test_05_pt_zero_below_slab(self):
        """PT is ₹0 for gross salary ≤ ₹10,000 (MH slab)."""
        pt = _compute_pt(Decimal("8000"))
        self.assertEqual(pt, Decimal("0.00"))

    def test_06_pt_200_above_slab(self):
        """PT is ₹200/month for gross > ₹10,000 (MH)."""
        pt = _compute_pt(Decimal("15000"))
        self.assertEqual(pt, Decimal("200.00"))

    def test_07_pt_annual_cap_enforced(self):
        """PT is capped at ₹2,500/year — no more once cap reached."""
        ytd = Decimal("2400")  # already deducted ₹2,400 this FY
        pt = _compute_pt(Decimal("20000"), ytd_pt=ytd)
        self.assertEqual(pt, Decimal("100.00"))  # only 100 remaining

    def test_08_pt_zero_once_cap_exceeded(self):
        """PT = 0 when annual cap already hit."""
        pt = _compute_pt(Decimal("20000"), ytd_pt=Decimal("2500"))
        self.assertEqual(pt, Decimal("0.00"))


# ═══════════════════════════════════════════════════════════════════
# TDS / INCOME TAX TESTS
# ═══════════════════════════════════════════════════════════════════

class TestTDSComputation(TestCase):
    def test_09_new_regime_zero_tax_below_rebate(self):
        """New regime: zero tax when taxable income ≤ 7 LPA (87A rebate)."""
        tax = _compute_income_tax_new_regime(Decimal("700000"))
        self.assertEqual(tax, Decimal("0.00"))

    def test_10_new_regime_tax_above_rebate_threshold(self):
        """New regime: tax computed for income > 7 LPA."""
        tax = _compute_income_tax_new_regime(Decimal("1000000"))
        self.assertGreater(tax, Decimal("0.00"))

    def test_11_old_regime_full_rebate_below_5lpa(self):
        """Old regime: zero tax up to ₹5 LPA (87A rebate)."""
        tax = _compute_income_tax_old_regime(Decimal("500000"))
        self.assertEqual(tax, Decimal("0.00"))

    def test_12_old_regime_cess_added(self):
        """4% health & education cess added to base tax."""
        # Income of 10 LPA: base tax = (5L*5% + 5L*20%) = 1,25,000; with cess = 1,30,000
        tax = _compute_income_tax_old_regime(Decimal("1000000"))
        self.assertAlmostEqual(float(tax), 125000 * 1.04, delta=100)

    def test_13_compute_tds_service_creates_declaration(self):
        """compute_tds() creates a TaxDeclaration with correct monthly TDS."""
        f = make_base()
        emp = make_employee(f["plant"])
        decl = services.compute_tds(
            employee=emp,
            financial_year="2025-26",
            projected_annual_salary=Decimal("600000"),
            tax_regime="NEW",
            submitted_by=f["user"],
            auto_approve=True,
        )
        self.assertEqual(decl.status, "APPROVED")
        # 6 LPA is below 7 LPA rebate limit in new regime → zero tax
        self.assertEqual(decl.monthly_tds, Decimal("0.00"))
        self.assertEqual(decl.projected_annual_tax, Decimal("0.00"))

    def test_14_compute_tds_high_income(self):
        """High CTC employee should have non-zero monthly TDS."""
        f = make_base()
        emp = make_employee(f["plant"])
        emp.ctc = Decimal("2400000")
        emp.save()
        decl = services.compute_tds(
            employee=emp,
            financial_year="2025-26",
            projected_annual_salary=Decimal("2400000"),
            tax_regime="NEW",
            submitted_by=f["user"],
            auto_approve=True,
        )
        self.assertGreater(decl.monthly_tds, Decimal("0.00"))
        self.assertGreater(decl.projected_annual_tax, Decimal("0.00"))


# ═══════════════════════════════════════════════════════════════════
# PAYROLL PERIOD & RUN TESTS
# ═══════════════════════════════════════════════════════════════════

class TestPayrollPeriod(TestCase):
    def setUp(self):
        self.f = make_base()

    def test_15_create_payroll_period(self):
        period = make_period(self.f["plant"], user=self.f["user"])
        self.assertEqual(period.period_code, "2025-05")
        self.assertEqual(period.status, "OPEN")
        self.assertEqual(period.working_days, 26)

    def test_16_period_start_end_correct(self):
        period = make_period(self.f["plant"], month=2, year=2025, user=self.f["user"])
        self.assertEqual(period.period_start, date(2025, 2, 1))
        self.assertEqual(period.period_end, date(2025, 2, 28))

    def test_17_duplicate_period_raises(self):
        make_period(self.f["plant"], user=self.f["user"])
        with self.assertRaises(ValueError):
            make_period(self.f["plant"], user=self.f["user"])

    def test_18_period_working_days_auto_computed(self):
        """Without explicit working_days, system derives from calendar."""
        period = services.create_payroll_period(
            plant=self.f["plant"],
            month=6,
            year=2025,
            created_by=self.f["user"],
        )
        # June 2025 has 30 days; we verify it's a reasonable number
        self.assertGreater(period.working_days, 20)
        self.assertLess(period.working_days, 30)

    def test_19_payroll_run_created_on_process(self):
        """process_payroll_run() creates a PayrollRun in REVIEW status."""
        from apps.hr.models import SalaryStructure, SalaryComponent, SalaryStructureLine

        # Build minimal salary structure so hr.generate_payroll works
        period = make_period(self.f["plant"], user=self.f["user"])
        struct = SalaryStructure.objects.create(code="BASIC_STR", name="Basic Structure")
        basic_comp = SalaryComponent.objects.create(
            code="BASIC", name="Basic Salary",
            component_type="EARNING", calc_type="FIXED",
            default_amount=Decimal("25000"),
        )
        SalaryStructureLine.objects.create(structure=struct, component=basic_comp)
        emp = make_employee(self.f["plant"], salary_structure=struct)

        run = services.process_payroll_run(period=period, processed_by=self.f["user"])
        self.assertTrue(run.run_number.startswith("PRN/"))
        self.assertEqual(run.status, "REVIEW")
        self.assertGreaterEqual(run.employee_count, 1)

    def test_20_payslip_generated_for_employee(self):
        """After process_payroll_run, an EmployeePayslip exists for the employee."""
        from apps.hr.models import SalaryStructure, SalaryComponent, SalaryStructureLine

        period = services.create_payroll_period(
            plant=self.f["plant"], month=7, year=2025, working_days=26,
            created_by=self.f["user"]
        )
        struct = SalaryStructure.objects.create(code="STR2", name="Structure 2")
        comp = SalaryComponent.objects.create(
            code="BASIC2", name="Basic Salary 2",
            component_type="EARNING", calc_type="FIXED",
            default_amount=Decimal("18000"),
        )
        SalaryStructureLine.objects.create(structure=struct, component=comp)
        emp = make_employee(self.f["plant"], salary_structure=struct)

        run = services.process_payroll_run(period=period, processed_by=self.f["user"])
        payslip = EmployeePayslip.objects.filter(employee=emp, period=period).first()
        self.assertIsNotNone(payslip)
        self.assertEqual(payslip.status, "DRAFT")
        self.assertGreater(payslip.gross_earnings, Decimal("0"))

    def test_21_approve_payslip(self):
        """approve_payslip() changes status to APPROVED and records approver."""
        from apps.hr.models import SalaryStructure, SalaryComponent, SalaryStructureLine

        period = services.create_payroll_period(
            plant=self.f["plant"], month=8, year=2025, working_days=26,
            created_by=self.f["user"]
        )
        struct = SalaryStructure.objects.create(code="STR3", name="Structure 3")
        comp = SalaryComponent.objects.create(
            code="BASIC3", name="Basic 3",
            component_type="EARNING", calc_type="FIXED",
            default_amount=Decimal("20000"),
        )
        SalaryStructureLine.objects.create(structure=struct, component=comp)
        emp = make_employee(self.f["plant"], salary_structure=struct)

        run = services.process_payroll_run(period=period, processed_by=self.f["user"])
        payslip = EmployeePayslip.objects.filter(employee=emp).first()
        approved = services.approve_payslip(payslip, approved_by=self.f["user"], publish=True)
        self.assertEqual(approved.status, "PUBLISHED")
        self.assertEqual(approved.approved_by, self.f["user"])

    def test_22_approving_approved_payslip_raises(self):
        """Cannot approve an already-approved payslip."""
        f = make_base()
        period = services.create_payroll_period(
            plant=f["plant"], month=9, year=2025, working_days=26,
            created_by=f["user"]
        )
        from apps.hr.models import SalaryStructure, SalaryComponent, SalaryStructureLine
        struct = SalaryStructure.objects.create(code="STR4", name="Structure 4")
        comp = SalaryComponent.objects.create(
            code="BASIC4", name="Basic 4",
            component_type="EARNING", calc_type="FIXED",
            default_amount=Decimal("22000"),
        )
        SalaryStructureLine.objects.create(structure=struct, component=comp)
        emp = make_employee(f["plant"], salary_structure=struct)

        run = services.process_payroll_run(period=period, processed_by=f["user"])
        payslip = EmployeePayslip.objects.filter(employee=emp).first()
        services.approve_payslip(payslip, approved_by=f["user"])
        with self.assertRaises(ValueError):
            services.approve_payslip(payslip, approved_by=f["user"])
