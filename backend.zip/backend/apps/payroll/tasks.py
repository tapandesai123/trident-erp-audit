"""Payroll & Compliance Celery tasks."""
from celery import shared_task


@shared_task(bind=True, max_retries=3, default_retry_delay=120)
def process_payroll_run_task(self, period_id: int, user_id: int = None):
    """
    Async: trigger full payroll processing for a period.
    Example: process_payroll_run_task.delay(period_id=5, user_id=1)
    """
    try:
        from apps.payroll.models import PayrollPeriod
        from apps.payroll.services import process_payroll_run

        period = PayrollPeriod.objects.get(pk=period_id)
        user = None
        if user_id:
            from django.contrib.auth import get_user_model
            user = get_user_model().objects.filter(pk=user_id).first()

        run = process_payroll_run(period=period, processed_by=user)
        return {
            "run_number": run.run_number,
            "employee_count": run.employee_count,
            "total_net": str(run.total_net_payable),
            "status": run.status,
        }
    except Exception as exc:
        raise self.retry(exc=exc)


@shared_task(bind=True, max_retries=3, default_retry_delay=120)
def post_payroll_vouchers_task(self, run_id: int, user_id: int = None):
    """
    Async: post accounting vouchers for an approved payroll run.
    """
    try:
        from apps.payroll.models import PayrollRun
        from apps.payroll.services import post_payroll_voucher

        run = PayrollRun.objects.get(pk=run_id)
        user = None
        if user_id:
            from django.contrib.auth import get_user_model
            user = get_user_model().objects.filter(pk=user_id).first()

        run = post_payroll_voucher(run, posted_by=user)
        return {
            "run_number": run.run_number,
            "status": run.status,
            "salary_voucher": run.salary_voucher.voucher_number if run.salary_voucher else None,
        }
    except Exception as exc:
        raise self.retry(exc=exc)


@shared_task
def compute_tds_for_all_employees(plant_id: int, financial_year: str, user_id: int = None):
    """
    Batch: compute TDS for all ACTIVE employees in a plant for a financial year.
    Uses employee CTC and any approved Form-12BB declaration.
    """
    from apps.hr.models import Employee
    from apps.payroll.services import compute_tds

    user = None
    if user_id:
        from django.contrib.auth import get_user_model
        user = get_user_model().objects.filter(pk=user_id).first()

    employees = Employee.objects.filter(plant_id=plant_id, status="ACTIVE")
    processed = []
    errors = []

    for emp in employees:
        try:
            decl = compute_tds(
                employee=emp,
                financial_year=financial_year,
                submitted_by=user,
                auto_approve=False,
            )
            processed.append({
                "employee": emp.employee_code,
                "monthly_tds": str(decl.monthly_tds),
            })
        except Exception as e:
            errors.append({"employee": emp.employee_code, "error": str(e)})

    return {
        "plant_id": plant_id,
        "financial_year": financial_year,
        "processed": processed,
        "errors": errors,
    }


@shared_task
def send_payslip_ready_alerts(payroll_run_id: int):
    """
    Notify employees when payslips are published.
    Called after bulk publish on a PayrollRun.
    """
    from apps.payroll.models import EmployeePayslip
    from apps.core.models import Notification

    payslips = EmployeePayslip.objects.filter(
        payroll_run_id=payroll_run_id,
        status="PUBLISHED",
    ).select_related("employee__user", "period")

    notified = 0
    for slip in payslips:
        linked_user = getattr(slip.employee, "user", None)
        if linked_user:
            Notification.objects.get_or_create(
                user=linked_user,
                module="payroll",
                resource="EmployeePayslip",
                resource_id=slip.pk,
                title=f"Payslip Ready: {slip.period.period_code}",
                defaults={
                    "message": (
                        f"Your payslip for {slip.period.period_code} is available. "
                        f"Net pay: ₹{slip.net_salary:,.2f}."
                    ),
                    "notification_type": "IN_APP",
                },
            )
            notified += 1

    return {"payslips_notified": notified, "run_id": payroll_run_id}


@shared_task
def send_tax_declaration_reminders(plant_id: int, financial_year: str):
    """
    Remind employees who haven't submitted Form-12BB for a FY.
    Schedule: monthly during April–June.
    """
    from apps.hr.models import Employee
    from apps.payroll.models import TaxDeclaration
    from apps.core.models import Notification

    declared_emp_ids = TaxDeclaration.objects.filter(
        plant_id=plant_id, financial_year=financial_year
    ).values_list("employee_id", flat=True)

    missing = Employee.objects.filter(
        plant_id=plant_id, status="ACTIVE",
    ).exclude(pk__in=declared_emp_ids).select_related("user")

    reminded = 0
    for emp in missing:
        linked_user = getattr(emp, "user", None)
        if linked_user:
            Notification.objects.get_or_create(
                user=linked_user,
                module="payroll",
                resource="TaxDeclaration",
                resource_id=emp.pk,
                title=f"Action Required: Submit Form-12BB for FY {financial_year}",
                defaults={
                    "message": (
                        f"Please submit your income tax declaration (Form-12BB) "
                        f"for FY {financial_year} to avoid maximum TDS deduction."
                    ),
                    "notification_type": "IN_APP",
                },
            )
            reminded += 1

    return {
        "plant_id": plant_id,
        "financial_year": financial_year,
        "reminders_sent": reminded,
    }
