"""
Payroll & Compliance Module Models — Section 14

Extends apps.hr for formal payslip generation, statutory compliance
registers, and TDS/income-tax declarations.

Models:
  PayrollPeriod       — Calendar period with working-day count and holiday list
  PayrollRun          — Batch execution header (wraps hr.Payroll, adds approval/posting)
  EmployeePayslip     — Formal employee-facing payslip document per period
  PayslipLine         — Component breakdown on a payslip (references hr.SalaryComponent)
  TaxDeclaration      — Employee's Form-12BB / annual IT declaration
  TaxDeclarationItem  — Line items (80C, HRA exemption, etc.)
  PFContribution      — Monthly PF contribution register per employee (ECR format)
  ESIContribution     — Monthly ESI contribution register per employee
  ProfessionalTax     — Monthly Professional Tax deduction per employee
"""
from decimal import Decimal
from django.db import models
from django.conf import settings
from apps.core.models import UUIDModel, TimeStampedModel, Plant


# ═══════════════════════════════════════════════════════════════════
# PAYROLL PERIOD
# ═══════════════════════════════════════════════════════════════════

class PayrollPeriod(UUIDModel, TimeStampedModel):
    """
    Defines a statutory pay period (month + year) for a plant.
    Captures working-day count and holiday list used across payslip
    calculations and attendance-based proration.
    """
    STATUS_CHOICES = [
        ("OPEN", "Open"),
        ("LOCKED", "Locked"),       # payroll finalized, no more edits
        ("CLOSED", "Closed"),       # accounting posted and archived
    ]

    plant = models.ForeignKey(Plant, on_delete=models.PROTECT, related_name="payroll_periods")
    period_code = models.CharField(max_length=20, unique=True,
                                   help_text="e.g. 2025-05 (YYYY-MM)")
    month = models.PositiveSmallIntegerField(help_text="1=Jan … 12=Dec")
    year = models.PositiveSmallIntegerField()
    period_start = models.DateField()
    period_end = models.DateField()
    total_calendar_days = models.PositiveSmallIntegerField(default=30)
    working_days = models.PositiveSmallIntegerField(default=26,
                                                    help_text="Standard working days in month")
    holidays = models.JSONField(default=list,
                                help_text="List of holiday dates (YYYY-MM-DD)")
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default="OPEN")
    notes = models.TextField(blank=True)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="payroll_periods_created",
    )

    class Meta:
        unique_together = [["plant", "month", "year"]]
        ordering = ["-year", "-month"]

    def __str__(self):
        return f"{self.period_code} — {self.plant.code} [{self.status}]"


# ═══════════════════════════════════════════════════════════════════
# PAYROLL RUN
# ═══════════════════════════════════════════════════════════════════

class PayrollRun(UUIDModel, TimeStampedModel):
    """
    Batch payroll execution for a period.  Sits above hr.Payroll and adds:
    - formal approval workflow
    - accounting post status
    - statutory register generation flags
    """
    STATUS_CHOICES = [
        ("DRAFT", "Draft"),
        ("PROCESSING", "Processing"),
        ("REVIEW", "Under Review"),
        ("APPROVED", "Approved"),
        ("POSTED", "Posted"),       # salary voucher posted to accounts
        ("CANCELLED", "Cancelled"),
    ]

    period = models.OneToOneField(
        PayrollPeriod, on_delete=models.PROTECT, related_name="payroll_run"
    )
    run_number = models.CharField(max_length=50, unique=True)
    status = models.CharField(max_length=15, choices=STATUS_CHOICES, default="DRAFT")

    # Aggregates (populated on process)
    employee_count = models.PositiveIntegerField(default=0)
    total_gross = models.DecimalField(max_digits=18, decimal_places=2, default=0)
    total_employee_deductions = models.DecimalField(max_digits=18, decimal_places=2, default=0)
    total_net_payable = models.DecimalField(max_digits=18, decimal_places=2, default=0)
    total_employer_pf = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    total_employer_esi = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    total_tds = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    total_professional_tax = models.DecimalField(max_digits=14, decimal_places=2, default=0)

    # Accounting vouchers
    salary_voucher = models.ForeignKey(
        "accounts.Voucher", on_delete=models.SET_NULL,
        null=True, blank=True, related_name="payroll_runs_salary",
    )
    pf_voucher = models.ForeignKey(
        "accounts.Voucher", on_delete=models.SET_NULL,
        null=True, blank=True, related_name="payroll_runs_pf",
    )
    esi_voucher = models.ForeignKey(
        "accounts.Voucher", on_delete=models.SET_NULL,
        null=True, blank=True, related_name="payroll_runs_esi",
    )
    tds_voucher = models.ForeignKey(
        "accounts.Voucher", on_delete=models.SET_NULL,
        null=True, blank=True, related_name="payroll_runs_tds",
    )

    # Statutory flags
    pf_register_generated = models.BooleanField(default=False)
    esi_register_generated = models.BooleanField(default=False)
    pt_register_generated = models.BooleanField(default=False)

    processed_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="payroll_runs_processed",
    )
    approved_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="payroll_runs_approved",
    )
    approved_at = models.DateTimeField(null=True, blank=True)
    posted_at = models.DateTimeField(null=True, blank=True)
    notes = models.TextField(blank=True)

    class Meta:
        ordering = ["-period__year", "-period__month"]

    def __str__(self):
        return f"{self.run_number} | {self.period.period_code} | {self.status}"


# ═══════════════════════════════════════════════════════════════════
# EMPLOYEE PAYSLIP
# ═══════════════════════════════════════════════════════════════════

class EmployeePayslip(UUIDModel, TimeStampedModel):
    """
    Formal payslip document for one employee for one period.
    PDF-ready; all values locked on approval.
    """
    STATUS_CHOICES = [
        ("DRAFT", "Draft"),
        ("APPROVED", "Approved"),
        ("PUBLISHED", "Published"),     # visible to employee
        ("REVISED", "Revised"),
        ("CANCELLED", "Cancelled"),
    ]

    payroll_run = models.ForeignKey(
        PayrollRun, on_delete=models.CASCADE, related_name="payslips"
    )
    employee = models.ForeignKey(
        "hr.Employee", on_delete=models.PROTECT, related_name="payslips"
    )
    period = models.ForeignKey(
        PayrollPeriod, on_delete=models.PROTECT, related_name="payslips"
    )
    payslip_number = models.CharField(max_length=50, unique=True)
    status = models.CharField(max_length=15, choices=STATUS_CHOICES, default="DRAFT")

    # Attendance for the period
    working_days = models.DecimalField(max_digits=5, decimal_places=1, default=0)
    days_present = models.DecimalField(max_digits=5, decimal_places=1, default=0)
    days_absent = models.DecimalField(max_digits=5, decimal_places=1, default=0)
    days_leave = models.DecimalField(max_digits=5, decimal_places=1, default=0)
    overtime_hours = models.DecimalField(max_digits=6, decimal_places=2, default=0)
    lop_days = models.DecimalField(max_digits=5, decimal_places=1, default=0,
                                   verbose_name="LOP Days",
                                   help_text="Loss-of-pay days")

    # Salary amounts
    gross_earnings = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    total_deductions = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    net_salary = models.DecimalField(max_digits=14, decimal_places=2, default=0)

    # Statutory breakdown (for quick compliance access)
    employee_pf = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    employer_pf = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    employee_esi = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    employer_esi = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    tds_amount = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    professional_tax = models.DecimalField(max_digits=10, decimal_places=2, default=0)

    # Payment details
    payment_date = models.DateField(null=True, blank=True)
    payment_mode = models.CharField(
        max_length=20,
        choices=[("BANK_TRANSFER", "Bank Transfer"), ("CASH", "Cash"), ("CHEQUE", "Cheque")],
        default="BANK_TRANSFER",
    )
    bank_transfer_ref = models.CharField(max_length=100, blank=True)

    approved_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="payslips_approved",
    )
    approved_at = models.DateTimeField(null=True, blank=True)
    remarks = models.TextField(blank=True)

    class Meta:
        unique_together = [["payroll_run", "employee"]]
        ordering = ["employee__employee_code"]
        indexes = [
            models.Index(fields=["period", "status"]),
            models.Index(fields=["employee", "status"]),
        ]

    def __str__(self):
        return (
            f"{self.payslip_number} | {self.employee.employee_code} "
            f"| {self.period.period_code} | ₹{self.net_salary}"
        )


# ═══════════════════════════════════════════════════════════════════
# PAYSLIP LINE
# ═══════════════════════════════════════════════════════════════════

class PayslipLine(models.Model):
    """
    Individual salary component line on a payslip.
    References hr.SalaryComponent (no duplication).
    """
    payslip = models.ForeignKey(
        EmployeePayslip, on_delete=models.CASCADE, related_name="lines"
    )
    component = models.ForeignKey(
        "hr.SalaryComponent", on_delete=models.PROTECT, related_name="payslip_lines"
    )
    component_type = models.CharField(max_length=30)   # denormalized for reporting
    computed_amount = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    override_amount = models.DecimalField(max_digits=14, decimal_places=2,
                                          null=True, blank=True)
    is_taxable = models.BooleanField(default=True)

    @property
    def amount(self) -> Decimal:
        return (
            self.override_amount
            if self.override_amount is not None
            else self.computed_amount
        )

    class Meta:
        unique_together = [["payslip", "component"]]
        ordering = ["component__sequence"]

    def __str__(self):
        return f"{self.payslip.payslip_number} / {self.component.code} = ₹{self.amount}"


# ═══════════════════════════════════════════════════════════════════
# TAX DECLARATION (Form 12BB)
# ═══════════════════════════════════════════════════════════════════

class TaxDeclaration(UUIDModel, TimeStampedModel):
    """
    Employee's annual income-tax declaration (Form 12BB).
    Used to compute projected annual tax and derive monthly TDS.
    One per employee per financial year.
    """
    STATUS_CHOICES = [
        ("DRAFT", "Draft"),
        ("SUBMITTED", "Submitted"),
        ("APPROVED", "Approved — TDS Updated"),
        ("REVISED", "Revised"),
    ]

    employee = models.ForeignKey(
        "hr.Employee", on_delete=models.PROTECT, related_name="tax_declarations"
    )
    plant = models.ForeignKey(Plant, on_delete=models.PROTECT, related_name="tax_declarations")
    financial_year = models.CharField(max_length=10, help_text="e.g. 2025-26")
    status = models.CharField(max_length=15, choices=STATUS_CHOICES, default="DRAFT")

    # Regime
    tax_regime = models.CharField(
        max_length=10,
        choices=[("OLD", "Old Regime"), ("NEW", "New Regime")],
        default="NEW",
    )

    # Projected income (auto-computed from payroll; employee may override)
    projected_annual_salary = models.DecimalField(max_digits=16, decimal_places=2, default=0)
    other_income = models.DecimalField(max_digits=14, decimal_places=2, default=0,
                                        help_text="Income from house property, FD interest, etc.")

    # Deductions declared
    section_80c = models.DecimalField(max_digits=12, decimal_places=2, default=0,
                                       verbose_name="80C (max 1.5L)",
                                       help_text="PF, PPF, ELSS, LIC, tuition fees…")
    section_80d = models.DecimalField(max_digits=12, decimal_places=2, default=0,
                                       verbose_name="80D — Health Insurance")
    section_80ccd_nps = models.DecimalField(max_digits=12, decimal_places=2, default=0,
                                             verbose_name="80CCD(1B) — NPS (max 50K)")
    section_80tta = models.DecimalField(max_digits=12, decimal_places=2, default=0,
                                         verbose_name="80TTA — Savings interest (max 10K)")
    hra_exemption = models.DecimalField(max_digits=12, decimal_places=2, default=0,
                                         verbose_name="HRA Exemption")
    other_deductions = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    home_loan_principal = models.DecimalField(max_digits=12, decimal_places=2, default=0,
                                               verbose_name="Home Loan Principal (80C)")
    home_loan_interest = models.DecimalField(max_digits=12, decimal_places=2, default=0,
                                              verbose_name="Home Loan Interest (Sec 24)")

    # Computed tax liability
    total_taxable_income = models.DecimalField(max_digits=16, decimal_places=2, default=0)
    projected_annual_tax = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    monthly_tds = models.DecimalField(max_digits=12, decimal_places=2, default=0,
                                       help_text="Projected TDS per month")
    tax_already_deducted = models.DecimalField(max_digits=14, decimal_places=2, default=0,
                                                help_text="TDS deducted till computation month")

    submitted_at = models.DateTimeField(null=True, blank=True)
    approved_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="tax_declarations_approved",
    )
    approved_at = models.DateTimeField(null=True, blank=True)
    notes = models.TextField(blank=True)

    class Meta:
        unique_together = [["employee", "financial_year"]]
        ordering = ["-financial_year", "employee"]

    def __str__(self):
        return (
            f"{self.employee.employee_code} | FY {self.financial_year} "
            f"| TDS ₹{self.monthly_tds}/mo | {self.status}"
        )


class TaxDeclarationItem(models.Model):
    """
    Proof-of-investment line item submitted along with Form 12BB.
    """
    SECTION_CHOICES = [
        ("80C", "Section 80C"),
        ("80D", "Section 80D"),
        ("80CCD", "Section 80CCD(1B)"),
        ("80TTA", "Section 80TTA"),
        ("HRA", "HRA Exemption"),
        ("SEC24", "Section 24 — Home Loan Interest"),
        ("OTHER", "Other"),
    ]

    declaration = models.ForeignKey(
        TaxDeclaration, on_delete=models.CASCADE, related_name="items"
    )
    section = models.CharField(max_length=10, choices=SECTION_CHOICES)
    description = models.CharField(max_length=200)
    declared_amount = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    proof_document = models.CharField(max_length=300, blank=True,
                                       help_text="Document reference / upload path")
    is_verified = models.BooleanField(default=False)

    class Meta:
        ordering = ["section"]

    def __str__(self):
        return f"{self.declaration.employee.employee_code} | {self.section} | ₹{self.declared_amount}"


# ═══════════════════════════════════════════════════════════════════
# PF CONTRIBUTION REGISTER
# ═══════════════════════════════════════════════════════════════════

class PFContribution(UUIDModel, TimeStampedModel):
    """
    Monthly PF contribution record per employee.
    Supports EPFO ECR (Electronic Challan cum Return) generation.

    Employee contribution: 12% of basic (capped at PF wage ceiling).
    Employer contribution split:
      EPF: 3.67% of basic  (into EPF account)
      EPS: 8.33% of basic  (into Pension Scheme, capped at ₹1,250/month)
    """
    payroll_run = models.ForeignKey(
        PayrollRun, on_delete=models.CASCADE, related_name="pf_contributions"
    )
    payslip = models.OneToOneField(
        EmployeePayslip, on_delete=models.CASCADE, related_name="pf_contribution"
    )
    employee = models.ForeignKey(
        "hr.Employee", on_delete=models.PROTECT, related_name="pf_contributions"
    )
    period = models.ForeignKey(
        PayrollPeriod, on_delete=models.PROTECT, related_name="pf_contributions"
    )

    uan = models.CharField(max_length=12, blank=True, verbose_name="UAN")
    pf_wage = models.DecimalField(max_digits=10, decimal_places=2, default=0,
                                   help_text="Basic wages used for PF computation")
    pf_wage_capped = models.DecimalField(max_digits=10, decimal_places=2, default=0,
                                          help_text="min(pf_wage, 15000)")

    employee_contribution = models.DecimalField(max_digits=10, decimal_places=2, default=0,
                                                 verbose_name="EE PF (12%)")
    employer_epf = models.DecimalField(max_digits=10, decimal_places=2, default=0,
                                        verbose_name="ER EPF (3.67%)")
    employer_eps = models.DecimalField(max_digits=10, decimal_places=2, default=0,
                                        verbose_name="ER EPS (8.33%)")
    employer_edli = models.DecimalField(max_digits=10, decimal_places=2, default=0,
                                         verbose_name="ER EDLI (0.5%)")
    employer_admin = models.DecimalField(max_digits=10, decimal_places=2, default=0,
                                          verbose_name="Admin Charges (0.5%)")

    @property
    def total_employer_contribution(self) -> Decimal:
        return (
            Decimal(str(self.employer_epf))
            + Decimal(str(self.employer_eps))
            + Decimal(str(self.employer_edli))
            + Decimal(str(self.employer_admin))
        )

    @property
    def total_contribution(self) -> Decimal:
        return Decimal(str(self.employee_contribution)) + self.total_employer_contribution

    is_excluded = models.BooleanField(default=False,
                                       help_text="True if employee opted out or not eligible")
    remarks = models.CharField(max_length=200, blank=True)

    class Meta:
        unique_together = [["payroll_run", "employee"]]
        ordering = ["employee__employee_code"]

    def __str__(self):
        return (
            f"PF | {self.employee.employee_code} | {self.period.period_code} "
            f"| EE: ₹{self.employee_contribution} / ER: ₹{self.total_employer_contribution}"
        )


# ═══════════════════════════════════════════════════════════════════
# ESI CONTRIBUTION REGISTER
# ═══════════════════════════════════════════════════════════════════

class ESIContribution(UUIDModel, TimeStampedModel):
    """
    Monthly ESI contribution record per employee.
    Employee: 0.75% of gross (if gross ≤ ₹21,000).
    Employer: 3.25% of gross.
    """
    payroll_run = models.ForeignKey(
        PayrollRun, on_delete=models.CASCADE, related_name="esi_contributions"
    )
    payslip = models.OneToOneField(
        EmployeePayslip, on_delete=models.CASCADE, related_name="esi_contribution"
    )
    employee = models.ForeignKey(
        "hr.Employee", on_delete=models.PROTECT, related_name="esi_contributions"
    )
    period = models.ForeignKey(
        PayrollPeriod, on_delete=models.PROTECT, related_name="esi_contributions"
    )

    esic_number = models.CharField(max_length=20, blank=True, verbose_name="ESIC No.")
    gross_wages = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    esi_applicable = models.BooleanField(default=False,
                                          help_text="True if gross <= ESI wage ceiling")
    employee_contribution = models.DecimalField(max_digits=10, decimal_places=2, default=0,
                                                 verbose_name="EE ESI (0.75%)")
    employer_contribution = models.DecimalField(max_digits=10, decimal_places=2, default=0,
                                                 verbose_name="ER ESI (3.25%)")

    @property
    def total_contribution(self) -> Decimal:
        return (
            Decimal(str(self.employee_contribution))
            + Decimal(str(self.employer_contribution))
        )

    is_excluded = models.BooleanField(default=False)
    remarks = models.CharField(max_length=200, blank=True)

    class Meta:
        unique_together = [["payroll_run", "employee"]]
        ordering = ["employee__employee_code"]

    def __str__(self):
        return (
            f"ESI | {self.employee.employee_code} | {self.period.period_code} "
            f"| EE: ₹{self.employee_contribution} / ER: ₹{self.employer_contribution}"
        )


# ═══════════════════════════════════════════════════════════════════
# PROFESSIONAL TAX
# ═══════════════════════════════════════════════════════════════════

class ProfessionalTax(UUIDModel, TimeStampedModel):
    """
    Monthly Professional Tax (PT) deduction per employee.
    Slabs vary by state; default uses Maharashtra-style slabs.
    Max ₹2,500/year.
    """
    payroll_run = models.ForeignKey(
        PayrollRun, on_delete=models.CASCADE, related_name="professional_taxes"
    )
    payslip = models.OneToOneField(
        EmployeePayslip, on_delete=models.CASCADE, related_name="professional_tax_record"
    )
    employee = models.ForeignKey(
        "hr.Employee", on_delete=models.PROTECT, related_name="professional_taxes"
    )
    period = models.ForeignKey(
        PayrollPeriod, on_delete=models.PROTECT, related_name="professional_taxes"
    )

    state_code = models.CharField(max_length=5, default="MH",
                                   help_text="State code, e.g. MH, KA, TN")
    gross_salary = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    pt_amount = models.DecimalField(max_digits=8, decimal_places=2, default=0,
                                     verbose_name="PT Deducted (₹)")
    ytd_pt = models.DecimalField(max_digits=10, decimal_places=2, default=0,
                                  verbose_name="Year-to-date PT",
                                  help_text="Running total for annual ₹2500 cap")
    is_excluded = models.BooleanField(default=False,
                                       help_text="True if state not applicable or exempted")

    class Meta:
        unique_together = [["payroll_run", "employee"]]
        ordering = ["employee__employee_code"]

    def __str__(self):
        return (
            f"PT | {self.employee.employee_code} | {self.period.period_code} "
            f"| ₹{self.pt_amount}"
        )

