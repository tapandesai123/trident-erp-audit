"""Payroll & Compliance API Viewsets."""
from decimal import Decimal
from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated

from apps.payroll.models import (
    PayrollPeriod, PayrollRun, EmployeePayslip, PayslipLine,
    TaxDeclaration, TaxDeclarationItem,
    PFContribution, ESIContribution, ProfessionalTax,
)
from apps.payroll.api.serializers import (
    PayrollPeriodListSerializer, PayrollPeriodDetailSerializer, PayrollPeriodCreateSerializer,
    PayrollRunListSerializer, PayrollRunDetailSerializer, PayrollRunCreateSerializer,
    EmployeePayslipListSerializer, EmployeePayslipDetailSerializer, EmployeePayslipCreateSerializer,
    TaxDeclarationListSerializer, TaxDeclarationDetailSerializer, TaxDeclarationCreateSerializer,
    PFContributionListSerializer, PFContributionDetailSerializer,
    ESIContributionListSerializer, ESIContributionDetailSerializer,
    ProfessionalTaxListSerializer, ProfessionalTaxDetailSerializer,
)
from apps.payroll import services


# ─── PayrollPeriod ────────────────────────────────────────────────

class PayrollPeriodViewSet(viewsets.ModelViewSet):
    queryset = PayrollPeriod.objects.select_related("plant")
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return PayrollPeriodListSerializer
        if self.action in ("create", "update", "partial_update"):
            return PayrollPeriodCreateSerializer
        return PayrollPeriodDetailSerializer

    def get_queryset(self):
        # BUG-032 fix: always enforce user's plant; optional params narrow further
        user_plant = getattr(self.request.user, 'plant', None)
        qs = super().get_queryset().filter(plant=user_plant)
        period_status = self.request.query_params.get("status")
        year = self.request.query_params.get("year")
        if period_status:
            qs = qs.filter(status=period_status)
        if year:
            qs = qs.filter(year=year)
        return qs

    def create(self, request, *args, **kwargs):
        from apps.core.models import Plant
        try:
            plant = Plant.objects.get(pk=request.data["plant"])
            period = services.create_payroll_period(
                plant=plant,
                month=int(request.data["month"]),
                year=int(request.data["year"]),
                working_days=int(request.data["working_days"]) if request.data.get("working_days") else None,
                holidays=request.data.get("holidays", []),
                notes=request.data.get("notes", ""),
                created_by=request.user,
            )
            return Response(
                PayrollPeriodDetailSerializer(period).data,
                status=status.HTTP_201_CREATED,
            )
        except Exception as e:
            return Response({"detail": str(e)}, status=status.HTTP_400_BAD_REQUEST)


# ─── PayrollRun ───────────────────────────────────────────────────

class PayrollRunViewSet(viewsets.ModelViewSet):
    queryset = PayrollRun.objects.select_related(
        "period", "period__plant",
        "salary_voucher", "pf_voucher", "esi_voucher", "tds_voucher",
        "approved_by",
    )
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return PayrollRunListSerializer
        if self.action in ("create", "update", "partial_update"):
            return PayrollRunCreateSerializer
        return PayrollRunDetailSerializer

    def get_queryset(self):
        # BUG-032 fix: enforce user's plant
        user_plant = getattr(self.request.user, 'plant', None)
        qs = super().get_queryset().filter(period__plant=user_plant)
        run_status = self.request.query_params.get("status")
        if run_status:
            qs = qs.filter(status=run_status)
        return qs

    @action(detail=False, methods=["post"], url_path="process")
    def process(self, request):
        """
        Trigger a full payroll run for a period.
        Body: { "period": <id>, "force_reprocess": false }
        """
        try:
            period = PayrollPeriod.objects.get(pk=request.data["period"])
            run = services.process_payroll_run(
                period=period,
                processed_by=request.user,
                force_reprocess=request.data.get("force_reprocess", False),
            )
            return Response(PayrollRunDetailSerializer(run).data, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({"detail": str(e)}, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=True, methods=["post"], url_path="approve")
    def approve(self, request, pk=None):
        """Approve a payroll run."""
        run = self.get_object()
        if run.status != "REVIEW":
            return Response(
                {"detail": f"Run must be in REVIEW status to approve (current: '{run.status}')."},
                status=status.HTTP_400_BAD_REQUEST,
            )
        from django.utils import timezone
        run.status = "APPROVED"
        run.approved_by = request.user
        run.approved_at = timezone.now()
        if request.data.get("notes"):
            run.notes = request.data["notes"]
        run.save(update_fields=["status", "approved_by", "approved_at", "notes"])
        return Response(PayrollRunDetailSerializer(run).data)

    @action(detail=True, methods=["post"], url_path="post-vouchers")
    def post_vouchers(self, request, pk=None):
        """Post accounting vouchers for an approved run."""
        run = self.get_object()
        try:
            run = services.post_payroll_voucher(run, posted_by=request.user)
            return Response(PayrollRunDetailSerializer(run).data)
        except Exception as e:
            return Response({"detail": str(e)}, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=True, methods=["post"], url_path="publish-payslips")
    def publish_payslips(self, request, pk=None):
        """Bulk-approve and publish all payslips in a run."""
        run = self.get_object()
        if run.status not in ("APPROVED", "POSTED"):
            return Response(
                {"detail": "Payslips can only be published after the run is approved."},
                status=status.HTTP_400_BAD_REQUEST,
            )
        count = 0
        for payslip in run.payslips.filter(status="DRAFT"):
            services.approve_payslip(payslip, approved_by=request.user, publish=True)
            count += 1
        return Response({"published": count, "run": run.run_number})

    @action(detail=True, methods=["get"], url_path="summary")
    def summary(self, request, pk=None):
        """Return cost summary for a payroll run."""
        run = self.get_object()
        return Response({
            "run_number": run.run_number,
            "period": run.period.period_code,
            "status": run.status,
            "employee_count": run.employee_count,
            "total_gross": run.total_gross,
            "total_deductions": run.total_employee_deductions,
            "total_net_payable": run.total_net_payable,
            "total_employer_pf": run.total_employer_pf,
            "total_employer_esi": run.total_employer_esi,
            "total_tds": run.total_tds,
            "total_professional_tax": run.total_professional_tax,
            "total_employer_cost": str(
                run.total_gross + run.total_employer_pf + run.total_employer_esi
            ),
            "vouchers": {
                "salary": getattr(run.salary_voucher, "voucher_number", None),
                "pf": getattr(run.pf_voucher, "voucher_number", None),
                "esi": getattr(run.esi_voucher, "voucher_number", None),
                "tds": getattr(run.tds_voucher, "voucher_number", None),
            },
        })


# ─── EmployeePayslip ──────────────────────────────────────────────

class EmployeePayslipViewSet(viewsets.ModelViewSet):
    queryset = EmployeePayslip.objects.select_related(
        "employee", "period", "payroll_run", "approved_by"
    ).prefetch_related("lines__component")
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return EmployeePayslipListSerializer
        if self.action in ("create", "update", "partial_update"):
            return EmployeePayslipCreateSerializer
        return EmployeePayslipDetailSerializer

    def get_queryset(self):
        # BUG-032 fix: enforce user's plant via period__plant
        user_plant = getattr(self.request.user, 'plant', None)
        qs = super().get_queryset().filter(period__plant=user_plant)
        period = self.request.query_params.get("period")
        payroll_run = self.request.query_params.get("payroll_run")
        employee = self.request.query_params.get("employee")
        slip_status = self.request.query_params.get("status")
        if period:
            qs = qs.filter(period=period)
        if payroll_run:
            qs = qs.filter(payroll_run=payroll_run)
        if employee:
            qs = qs.filter(employee=employee)
        if slip_status:
            qs = qs.filter(status=slip_status)
        return qs

    @action(detail=True, methods=["post"], url_path="approve")
    def approve(self, request, pk=None):
        """Approve and optionally publish a single payslip."""
        payslip = self.get_object()
        try:
            payslip = services.approve_payslip(
                payslip=payslip,
                approved_by=request.user,
                publish=request.data.get("publish", False),
            )
            return Response(EmployeePayslipDetailSerializer(payslip).data)
        except Exception as e:
            return Response({"detail": str(e)}, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=True, methods=["get"], url_path="download")
    def download(self, request, pk=None):
        """Return structured payslip data suitable for PDF generation."""
        payslip = self.get_object()
        emp = payslip.employee

        earnings = []
        deductions = []
        for line in payslip.lines.select_related("component").all():
            entry = {
                "code": line.component.code,
                "name": line.component.name,
                "amount": str(line.amount),
                "is_taxable": line.is_taxable,
            }
            if line.component_type in ("EARNING",):
                earnings.append(entry)
            elif line.component_type in ("DEDUCTION", "STATUTORY", "EMPLOYER_CONTRIBUTION"):
                deductions.append(entry)

        return Response({
            "payslip_number": payslip.payslip_number,
            "period": payslip.period.period_code,
            "employee": {
                "code": emp.employee_code,
                "name": emp.full_name,
                "designation": str(emp.designation),
                "department": str(emp.department),
                "pan": emp.pan,
                "uan": emp.uan,
                "bank_account": emp.bank_account_number,
                "bank_ifsc": emp.bank_ifsc,
            },
            "attendance": {
                "working_days": str(payslip.working_days),
                "days_present": str(payslip.days_present),
                "days_absent": str(payslip.days_absent),
                "lop_days": str(payslip.lop_days),
                "overtime_hours": str(payslip.overtime_hours),
            },
            "earnings": earnings,
            "deductions": deductions,
            "summary": {
                "gross_earnings": str(payslip.gross_earnings),
                "total_deductions": str(payslip.total_deductions),
                "net_salary": str(payslip.net_salary),
                "employee_pf": str(payslip.employee_pf),
                "employee_esi": str(payslip.employee_esi),
                "tds": str(payslip.tds_amount),
                "professional_tax": str(payslip.professional_tax),
            },
            "payment": {
                "mode": payslip.payment_mode,
                "date": str(payslip.payment_date) if payslip.payment_date else None,
                "ref": payslip.bank_transfer_ref,
            },
            "status": payslip.status,
        })


# ─── TaxDeclaration ───────────────────────────────────────────────

class TaxDeclarationViewSet(viewsets.ModelViewSet):
    queryset = TaxDeclaration.objects.select_related(
        "employee", "plant", "approved_by"
    ).prefetch_related("items")
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return TaxDeclarationListSerializer
        if self.action in ("create", "update", "partial_update"):
            return TaxDeclarationCreateSerializer
        return TaxDeclarationDetailSerializer

    def get_queryset(self):
        qs = super().get_queryset()
        employee = self.request.query_params.get("employee")
        fy = self.request.query_params.get("financial_year")
        decl_status = self.request.query_params.get("status")
        if employee:
            qs = qs.filter(employee=employee)
        if fy:
            qs = qs.filter(financial_year=fy)
        if decl_status:
            qs = qs.filter(status=decl_status)
        return qs

    @action(detail=False, methods=["post"], url_path="compute-tds")
    def compute_tds(self, request):
        """
        Compute or recompute TDS for an employee for a financial year.
        Also creates/updates the TaxDeclaration record.
        """
        try:
            from apps.hr.models import Employee
            employee = Employee.objects.get(pk=request.data["employee"])
            decl = services.compute_tds(
                employee=employee,
                financial_year=request.data["financial_year"],
                projected_annual_salary=(
                    Decimal(str(request.data["projected_annual_salary"]))
                    if request.data.get("projected_annual_salary") else None
                ),
                other_income=Decimal(str(request.data.get("other_income", "0"))),
                tax_regime=request.data.get("tax_regime", "NEW"),
                section_80c=Decimal(str(request.data.get("section_80c", "0"))),
                section_80d=Decimal(str(request.data.get("section_80d", "0"))),
                section_80ccd_nps=Decimal(str(request.data.get("section_80ccd_nps", "0"))),
                section_80tta=Decimal(str(request.data.get("section_80tta", "0"))),
                hra_exemption=Decimal(str(request.data.get("hra_exemption", "0"))),
                home_loan_interest=Decimal(str(request.data.get("home_loan_interest", "0"))),
                home_loan_principal=Decimal(str(request.data.get("home_loan_principal", "0"))),
                other_deductions=Decimal(str(request.data.get("other_deductions", "0"))),
                tax_already_deducted=Decimal(str(request.data.get("tax_already_deducted", "0"))),
                remaining_months=int(request.data.get("remaining_months", 12)),
                submitted_by=request.user,
                auto_approve=request.data.get("auto_approve", False),
            )
            return Response(TaxDeclarationDetailSerializer(decl).data)
        except Exception as e:
            return Response({"detail": str(e)}, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=True, methods=["post"], url_path="approve")
    def approve(self, request, pk=None):
        """Approve a tax declaration — TDS will be used in next payroll run."""
        decl = self.get_object()
        if decl.status not in ("SUBMITTED", "DRAFT"):
            return Response(
                {"detail": f"Declaration in status '{decl.status}' cannot be approved."},
                status=status.HTTP_400_BAD_REQUEST,
            )
        from django.utils import timezone
        decl.status = "APPROVED"
        decl.approved_by = request.user
        decl.approved_at = timezone.now()
        decl.save(update_fields=["status", "approved_by", "approved_at"])
        return Response(TaxDeclarationDetailSerializer(decl).data)


# ─── PFContribution ───────────────────────────────────────────────

class PFContributionViewSet(viewsets.ReadOnlyModelViewSet):
    """PF contribution records are created during payroll processing."""
    queryset = PFContribution.objects.select_related("employee", "period", "payroll_run")
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return PFContributionListSerializer
        return PFContributionDetailSerializer

    def get_queryset(self):
        qs = super().get_queryset()
        period = self.request.query_params.get("period")
        run = self.request.query_params.get("payroll_run")
        employee = self.request.query_params.get("employee")
        if period:
            qs = qs.filter(period=period)
        if run:
            qs = qs.filter(payroll_run=run)
        if employee:
            qs = qs.filter(employee=employee)
        return qs

    @action(detail=False, methods=["get"], url_path="ecr-register")
    def ecr_register(self, request):
        """
        Export PF ECR (Electronic Challan cum Return) register for a period.
        Returns structured JSON; caller renders to CSV/text.
        """
        period_id = request.query_params.get("period")
        if not period_id:
            return Response(
                {"detail": "period query parameter is required."},
                status=status.HTTP_400_BAD_REQUEST,
            )
        records = self.get_queryset().filter(period=period_id, is_excluded=False)
        data = []
        for rec in records:
            data.append({
                "uan": rec.uan,
                "employee_code": rec.employee.employee_code,
                "employee_name": rec.employee.full_name,
                "pf_wages": str(rec.pf_wage_capped),
                "employee_pf": str(rec.employee_contribution),
                "employer_epf": str(rec.employer_epf),
                "employer_eps": str(rec.employer_eps),
                "edli": str(rec.employer_edli),
                "admin": str(rec.employer_admin),
                "total": str(rec.total_contribution),
            })
        return Response({"period": period_id, "records": data, "count": len(data)})


# ─── ESIContribution ──────────────────────────────────────────────

class ESIContributionViewSet(viewsets.ReadOnlyModelViewSet):
    """ESI contribution records are created during payroll processing."""
    queryset = ESIContribution.objects.select_related("employee", "period", "payroll_run")
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return ESIContributionListSerializer
        return ESIContributionDetailSerializer

    def get_queryset(self):
        qs = super().get_queryset()
        period = self.request.query_params.get("period")
        run = self.request.query_params.get("payroll_run")
        employee = self.request.query_params.get("employee")
        if period:
            qs = qs.filter(period=period)
        if run:
            qs = qs.filter(payroll_run=run)
        if employee:
            qs = qs.filter(employee=employee)
        return qs


# ─── ProfessionalTax ──────────────────────────────────────────────

class ProfessionalTaxViewSet(viewsets.ReadOnlyModelViewSet):
    """PT records are created during payroll processing."""
    queryset = ProfessionalTax.objects.select_related("employee", "period", "payroll_run")
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return ProfessionalTaxListSerializer
        return ProfessionalTaxDetailSerializer

    def get_queryset(self):
        qs = super().get_queryset()
        period = self.request.query_params.get("period")
        run = self.request.query_params.get("payroll_run")
        employee = self.request.query_params.get("employee")
        if period:
            qs = qs.filter(period=period)
        if run:
            qs = qs.filter(payroll_run=run)
        if employee:
            qs = qs.filter(employee=employee)
        return qs
