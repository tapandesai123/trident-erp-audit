"""Payroll & Compliance API Serializers — 3 variants per major model."""
from rest_framework import serializers
from apps.payroll.models import (
    PayrollPeriod, PayrollRun, EmployeePayslip, PayslipLine,
    TaxDeclaration, TaxDeclarationItem,
    PFContribution, ESIContribution, ProfessionalTax,
)


# ─── PayrollPeriod ────────────────────────────────────────────────

class PayrollPeriodListSerializer(serializers.ModelSerializer):
    plant_code = serializers.CharField(source="plant.code", read_only=True)

    class Meta:
        model = PayrollPeriod
        fields = [
            "id", "uuid", "period_code", "month", "year",
            "plant", "plant_code",
            "period_start", "period_end",
            "working_days", "status",
        ]


class PayrollPeriodDetailSerializer(serializers.ModelSerializer):
    plant_code = serializers.CharField(source="plant.code", read_only=True)

    class Meta:
        model = PayrollPeriod
        fields = "__all__"


class PayrollPeriodCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = PayrollPeriod
        fields = [
            "plant", "month", "year",
            "working_days", "holidays", "notes",
        ]


# ─── PayrollRun ───────────────────────────────────────────────────

class PayrollRunListSerializer(serializers.ModelSerializer):
    period_code = serializers.CharField(source="period.period_code", read_only=True)
    plant_code = serializers.CharField(source="period.plant.code", read_only=True)
    approved_by_name = serializers.SerializerMethodField()

    class Meta:
        model = PayrollRun
        fields = [
            "id", "uuid", "run_number",
            "period", "period_code", "plant_code",
            "status", "employee_count",
            "total_gross", "total_net_payable",
            "total_employer_pf", "total_employer_esi",
            "total_tds", "total_professional_tax",
            "approved_by_name", "approved_at",
        ]

    def get_approved_by_name(self, obj):
        return obj.approved_by.get_full_name() if obj.approved_by else None


class PayrollRunDetailSerializer(serializers.ModelSerializer):
    period_code = serializers.CharField(source="period.period_code", read_only=True)
    salary_voucher_number = serializers.CharField(
        source="salary_voucher.voucher_number", read_only=True
    )
    pf_voucher_number = serializers.CharField(
        source="pf_voucher.voucher_number", read_only=True
    )
    esi_voucher_number = serializers.CharField(
        source="esi_voucher.voucher_number", read_only=True
    )
    tds_voucher_number = serializers.CharField(
        source="tds_voucher.voucher_number", read_only=True
    )

    class Meta:
        model = PayrollRun
        fields = "__all__"


class PayrollRunCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = PayrollRun
        fields = ["period", "notes"]


# ─── PayslipLine ──────────────────────────────────────────────────

class PayslipLineSerializer(serializers.ModelSerializer):
    component_code = serializers.CharField(source="component.code", read_only=True)
    component_name = serializers.CharField(source="component.name", read_only=True)
    amount = serializers.DecimalField(max_digits=14, decimal_places=2, read_only=True)

    class Meta:
        model = PayslipLine
        fields = [
            "id", "component", "component_code", "component_name",
            "component_type", "computed_amount", "override_amount",
            "amount", "is_taxable",
        ]


# ─── EmployeePayslip ──────────────────────────────────────────────

class EmployeePayslipListSerializer(serializers.ModelSerializer):
    employee_code = serializers.CharField(source="employee.employee_code", read_only=True)
    employee_name = serializers.CharField(source="employee.full_name", read_only=True)
    period_code = serializers.CharField(source="period.period_code", read_only=True)

    class Meta:
        model = EmployeePayslip
        fields = [
            "id", "uuid", "payslip_number",
            "employee", "employee_code", "employee_name",
            "period", "period_code",
            "status",
            "working_days", "days_present", "lop_days",
            "gross_earnings", "total_deductions", "net_salary",
            "employee_pf", "employee_esi", "tds_amount", "professional_tax",
            "payment_date", "payment_mode",
        ]


class EmployeePayslipDetailSerializer(serializers.ModelSerializer):
    employee_code = serializers.CharField(source="employee.employee_code", read_only=True)
    employee_name = serializers.CharField(source="employee.full_name", read_only=True)
    period_code = serializers.CharField(source="period.period_code", read_only=True)
    lines = PayslipLineSerializer(many=True, read_only=True)
    approved_by_name = serializers.SerializerMethodField()

    class Meta:
        model = EmployeePayslip
        fields = "__all__"

    def get_approved_by_name(self, obj):
        return obj.approved_by.get_full_name() if obj.approved_by else None


class EmployeePayslipCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = EmployeePayslip
        fields = [
            "payroll_run", "employee", "period",
            "working_days", "days_present", "days_absent",
            "days_leave", "lop_days", "overtime_hours",
            "remarks",
        ]


# ─── TaxDeclarationItem ───────────────────────────────────────────

class TaxDeclarationItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = TaxDeclarationItem
        fields = [
            "id", "section", "description",
            "declared_amount", "proof_document", "is_verified",
        ]


# ─── TaxDeclaration ───────────────────────────────────────────────

class TaxDeclarationListSerializer(serializers.ModelSerializer):
    employee_code = serializers.CharField(source="employee.employee_code", read_only=True)
    employee_name = serializers.CharField(source="employee.full_name", read_only=True)

    class Meta:
        model = TaxDeclaration
        fields = [
            "id", "uuid", "employee", "employee_code", "employee_name",
            "financial_year", "tax_regime", "status",
            "projected_annual_salary", "total_taxable_income",
            "projected_annual_tax", "monthly_tds",
        ]


class TaxDeclarationDetailSerializer(serializers.ModelSerializer):
    employee_code = serializers.CharField(source="employee.employee_code", read_only=True)
    employee_name = serializers.CharField(source="employee.full_name", read_only=True)
    items = TaxDeclarationItemSerializer(many=True, read_only=True)

    class Meta:
        model = TaxDeclaration
        fields = "__all__"


class TaxDeclarationCreateSerializer(serializers.ModelSerializer):
    items = TaxDeclarationItemSerializer(many=True, required=False)

    class Meta:
        model = TaxDeclaration
        fields = [
            "employee", "financial_year", "tax_regime",
            "projected_annual_salary", "other_income",
            "section_80c", "section_80d", "section_80ccd_nps",
            "section_80tta", "hra_exemption",
            "home_loan_principal", "home_loan_interest",
            "other_deductions", "notes", "items",
        ]

    def create(self, validated_data):
        items_data = validated_data.pop("items", [])
        decl = TaxDeclaration.objects.create(**validated_data)
        for item in items_data:
            TaxDeclarationItem.objects.create(declaration=decl, **item)
        return decl


# ─── PFContribution ───────────────────────────────────────────────

class PFContributionListSerializer(serializers.ModelSerializer):
    employee_code = serializers.CharField(source="employee.employee_code", read_only=True)
    employee_name = serializers.CharField(source="employee.full_name", read_only=True)
    period_code = serializers.CharField(source="period.period_code", read_only=True)
    total_contribution = serializers.DecimalField(
        max_digits=12, decimal_places=2, read_only=True
    )

    class Meta:
        model = PFContribution
        fields = [
            "id", "uuid", "employee", "employee_code", "employee_name",
            "period", "period_code",
            "uan", "pf_wage", "pf_wage_capped",
            "employee_contribution", "employer_epf", "employer_eps",
            "employer_edli", "employer_admin",
            "total_contribution", "is_excluded",
        ]


class PFContributionDetailSerializer(serializers.ModelSerializer):
    employee_code = serializers.CharField(source="employee.employee_code", read_only=True)
    total_contribution = serializers.DecimalField(
        max_digits=12, decimal_places=2, read_only=True
    )
    total_employer_contribution = serializers.DecimalField(
        max_digits=12, decimal_places=2, read_only=True
    )

    class Meta:
        model = PFContribution
        fields = "__all__"


# ─── ESIContribution ──────────────────────────────────────────────

class ESIContributionListSerializer(serializers.ModelSerializer):
    employee_code = serializers.CharField(source="employee.employee_code", read_only=True)
    employee_name = serializers.CharField(source="employee.full_name", read_only=True)
    period_code = serializers.CharField(source="period.period_code", read_only=True)
    total_contribution = serializers.DecimalField(
        max_digits=12, decimal_places=2, read_only=True
    )

    class Meta:
        model = ESIContribution
        fields = [
            "id", "uuid", "employee", "employee_code", "employee_name",
            "period", "period_code",
            "esic_number", "gross_wages", "esi_applicable",
            "employee_contribution", "employer_contribution",
            "total_contribution", "is_excluded",
        ]


class ESIContributionDetailSerializer(serializers.ModelSerializer):
    employee_code = serializers.CharField(source="employee.employee_code", read_only=True)
    total_contribution = serializers.DecimalField(
        max_digits=12, decimal_places=2, read_only=True
    )

    class Meta:
        model = ESIContribution
        fields = "__all__"


# ─── ProfessionalTax ──────────────────────────────────────────────

class ProfessionalTaxListSerializer(serializers.ModelSerializer):
    employee_code = serializers.CharField(source="employee.employee_code", read_only=True)
    employee_name = serializers.CharField(source="employee.full_name", read_only=True)
    period_code = serializers.CharField(source="period.period_code", read_only=True)

    class Meta:
        model = ProfessionalTax
        fields = [
            "id", "uuid", "employee", "employee_code", "employee_name",
            "period", "period_code",
            "state_code", "gross_salary", "pt_amount", "ytd_pt",
            "is_excluded",
        ]


class ProfessionalTaxDetailSerializer(serializers.ModelSerializer):
    employee_code = serializers.CharField(source="employee.employee_code", read_only=True)

    class Meta:
        model = ProfessionalTax
        fields = "__all__"
