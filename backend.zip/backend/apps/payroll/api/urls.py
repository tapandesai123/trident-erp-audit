"""Payroll & Compliance API URL configuration."""
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from apps.payroll.api.viewsets import (
    PayrollPeriodViewSet, PayrollRunViewSet, EmployeePayslipViewSet,
    TaxDeclarationViewSet, PFContributionViewSet,
    ESIContributionViewSet, ProfessionalTaxViewSet,
)

router = DefaultRouter()
router.register("periods", PayrollPeriodViewSet, basename="payroll-period")
router.register("runs", PayrollRunViewSet, basename="payroll-run")
router.register("payslips", EmployeePayslipViewSet, basename="employee-payslip")
router.register("tax-declarations", TaxDeclarationViewSet, basename="tax-declaration")
router.register("pf-contributions", PFContributionViewSet, basename="pf-contribution")
router.register("esi-contributions", ESIContributionViewSet, basename="esi-contribution")
router.register("professional-tax", ProfessionalTaxViewSet, basename="professional-tax")

urlpatterns = [
    path("", include(router.urls)),
]
