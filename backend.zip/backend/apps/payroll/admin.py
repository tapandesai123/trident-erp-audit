"""Payroll & Compliance admin registrations."""
from django.contrib import admin
from django.utils.html import format_html
from apps.payroll.models import (
    PayrollPeriod, PayrollRun, EmployeePayslip, PayslipLine,
    TaxDeclaration, TaxDeclarationItem,
    PFContribution, ESIContribution, ProfessionalTax,
)


# ─── Inlines ──────────────────────────────────────────────────────

class PayslipLineInline(admin.TabularInline):
    model = PayslipLine
    extra = 0
    fields = ["component", "component_type", "computed_amount", "override_amount", "is_taxable"]
    readonly_fields = ["component_type"]
    can_delete = False


class TaxDeclarationItemInline(admin.TabularInline):
    model = TaxDeclarationItem
    extra = 0
    fields = ["section", "description", "declared_amount", "proof_document", "is_verified"]


# ─── PayrollPeriod ────────────────────────────────────────────────

@admin.register(PayrollPeriod)
class PayrollPeriodAdmin(admin.ModelAdmin):
    list_display = [
        "period_code", "plant", "month", "year",
        "period_start", "period_end",
        "working_days", "status",
    ]
    list_filter = ["status", "plant", "year"]
    search_fields = ["period_code", "plant__code"]
    readonly_fields = ["uuid", "created_at", "updated_at"]


# ─── PayrollRun ───────────────────────────────────────────────────

@admin.register(PayrollRun)
class PayrollRunAdmin(admin.ModelAdmin):
    list_display = [
        "run_number", "period", "status",
        "employee_count",
        "total_gross", "total_net_payable",
        "total_employer_pf", "total_employer_esi",
        "total_tds", "total_professional_tax",
        "approved_by", "approved_at",
    ]
    list_filter = ["status", "period__plant"]
    search_fields = ["run_number", "period__period_code"]
    readonly_fields = [
        "uuid", "run_number", "created_at", "updated_at",
        "salary_voucher", "pf_voucher", "esi_voucher", "tds_voucher",
        "approved_by", "approved_at", "posted_at",
        "pf_register_generated", "esi_register_generated", "pt_register_generated",
    ]
    fieldsets = [
        ("Run Info", {
            "fields": ["period", "run_number", "status", "notes"]
        }),
        ("Aggregates", {
            "fields": [
                "employee_count", "total_gross", "total_employee_deductions",
                "total_net_payable", "total_employer_pf", "total_employer_esi",
                "total_tds", "total_professional_tax",
            ]
        }),
        ("Vouchers", {
            "fields": ["salary_voucher", "pf_voucher", "esi_voucher", "tds_voucher"],
            "classes": ["collapse"],
        }),
        ("Statutory Flags", {
            "fields": ["pf_register_generated", "esi_register_generated", "pt_register_generated"],
            "classes": ["collapse"],
        }),
        ("Approval", {
            "fields": ["processed_by", "approved_by", "approved_at", "posted_at"],
            "classes": ["collapse"],
        }),
    ]


# ─── EmployeePayslip ──────────────────────────────────────────────

@admin.register(EmployeePayslip)
class EmployeePayslipAdmin(admin.ModelAdmin):
    list_display = [
        "payslip_number", "employee", "period", "status",
        "days_present", "lop_days",
        "gross_earnings", "total_deductions", "net_salary_display",
        "employee_pf", "tds_amount", "professional_tax",
    ]
    list_filter = ["status", "period__plant", "period"]
    search_fields = ["payslip_number", "employee__employee_code", "employee__first_name"]
    readonly_fields = [
        "uuid", "payslip_number", "created_at", "updated_at",
        "approved_by", "approved_at",
    ]
    inlines = [PayslipLineInline]

    @admin.display(description="Net Salary")
    def net_salary_display(self, obj):
        return format_html("<strong>₹{:,.0f}</strong>", obj.net_salary)


# ─── TaxDeclaration ───────────────────────────────────────────────

@admin.register(TaxDeclaration)
class TaxDeclarationAdmin(admin.ModelAdmin):
    list_display = [
        "employee", "financial_year", "tax_regime", "status",
        "projected_annual_salary", "total_taxable_income",
        "projected_annual_tax", "monthly_tds",
    ]
    list_filter = ["status", "tax_regime", "financial_year"]
    search_fields = ["employee__employee_code", "employee__first_name", "financial_year"]
    readonly_fields = [
        "uuid", "created_at", "updated_at",
        "total_taxable_income", "projected_annual_tax", "monthly_tds",
        "approved_by", "approved_at",
    ]
    inlines = [TaxDeclarationItemInline]


# ─── PFContribution ───────────────────────────────────────────────

@admin.register(PFContribution)
class PFContributionAdmin(admin.ModelAdmin):
    list_display = [
        "employee", "period", "uan",
        "pf_wage_capped", "employee_contribution",
        "employer_epf", "employer_eps", "employer_edli",
        "is_excluded",
    ]
    list_filter = ["period", "is_excluded"]
    search_fields = ["employee__employee_code", "uan"]
    readonly_fields = ["uuid", "created_at", "updated_at"]


# ─── ESIContribution ──────────────────────────────────────────────

@admin.register(ESIContribution)
class ESIContributionAdmin(admin.ModelAdmin):
    list_display = [
        "employee", "period", "esic_number",
        "gross_wages", "esi_applicable",
        "employee_contribution", "employer_contribution",
        "is_excluded",
    ]
    list_filter = ["period", "esi_applicable", "is_excluded"]
    search_fields = ["employee__employee_code", "esic_number"]
    readonly_fields = ["uuid", "created_at", "updated_at"]


# ─── ProfessionalTax ──────────────────────────────────────────────

@admin.register(ProfessionalTax)
class ProfessionalTaxAdmin(admin.ModelAdmin):
    list_display = [
        "employee", "period", "state_code",
        "gross_salary", "pt_amount", "ytd_pt",
        "is_excluded",
    ]
    list_filter = ["period", "state_code", "is_excluded"]
    search_fields = ["employee__employee_code"]
    readonly_fields = ["uuid", "created_at", "updated_at"]
