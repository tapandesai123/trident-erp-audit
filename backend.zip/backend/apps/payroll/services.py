"""
Payroll & Compliance Module Services — Section 14

All business logic for payroll processing, payslip generation,
statutory compliance (PF/ESI/PT), and TDS computation.

Services:
  create_payroll_period()   — Define a pay period for a plant/month/year
  process_payroll_run()     — Batch: compute payslips for all active employees
  generate_payslip()        — Individual employee payslip from hr.PayrollLine
  approve_payslip()         — Lock and approve a single payslip
  post_payroll_voucher()    — Post salary + PF + ESI + TDS journals to accounts
  compute_tds()             — Monthly TDS from annual IT declaration (Form 12BB)
  compute_pf_esi()          — PF & ESI contribution records per payslip

Statutory constants (FY 2025-26):
  PF wage ceiling   ₹15,000/month
  PF employee rate  12 % of capped basic
  EPF employer      3.67 % of capped basic
  EPS employer      8.33 % (max ₹1,250/month)
  EDLI              0.50 % (max ₹75/month)
  Admin charges     0.50 %
  ESI wage ceiling  ₹21,000/month gross
  ESI employee      0.75 % of gross
  ESI employer      3.25 % of gross
  PT (default/MH)   slab-based, max ₹2,500/year
  Standard deduction ₹75,000 (FY 2025-26, new regime)
  Basic exemption   ₹4,00,000 (new regime), ₹2,50,000 (old regime)
"""
from __future__ import annotations

import calendar
from datetime import date
from decimal import Decimal, ROUND_HALF_UP
from typing import Optional

from django.db import transaction
from django.utils import timezone

from apps.core.models import AuditLog, DocSequence, Notification

# ─── Statutory constants ──────────────────────────────────────────

PF_WAGE_CEILING = Decimal("15000")
PF_EE_PCT = Decimal("12")
PF_EPF_ER_PCT = Decimal("3.67")
PF_EPS_ER_PCT = Decimal("8.33")
PF_EDLI_PCT = Decimal("0.50")
PF_ADMIN_PCT = Decimal("0.50")
EPS_MAX_MONTHLY = Decimal("1250")
EDLI_MAX_MONTHLY = Decimal("75")

ESI_WAGE_CEILING = Decimal("21000")
ESI_EE_PCT = Decimal("0.75")
ESI_ER_PCT = Decimal("3.25")

PT_ANNUAL_CAP = Decimal("2500")

# Income-tax slabs FY 2025-26 (New Regime — Sec 115BAC)
NEW_REGIME_SLABS = [
    (Decimal("400000"),  Decimal("0")),
    (Decimal("800000"),  Decimal("5")),
    (Decimal("1200000"), Decimal("10")),
    (Decimal("1600000"), Decimal("15")),
    (Decimal("2000000"), Decimal("20")),
    (Decimal("2400000"), Decimal("25")),
    (None,               Decimal("30")),
]
NEW_REGIME_STD_DED = Decimal("75000")

# Old Regime basic slabs (below 60)
OLD_REGIME_SLABS = [
    (Decimal("250000"),  Decimal("0")),
    (Decimal("500000"),  Decimal("5")),
    (Decimal("1000000"), Decimal("20")),
    (None,               Decimal("30")),
]
OLD_REGIME_STD_DED = Decimal("50000")

# PT slabs (default Maharashtra)
PT_SLABS_MH = [
    (Decimal("10000"), Decimal("0")),
    (Decimal("99999999"), Decimal("200")),   # ₹200/month above ₹10,000
]

# ─── Helpers ──────────────────────────────────────────────────────

def _two(val) -> Decimal:
    return Decimal(str(val)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def _log(user, action: str, resource: str, resource_id, details: dict = None):
    AuditLog.objects.create(
        user=user,
        action=action,
        module="payroll",
        resource=resource,
        resource_id=str(resource_id),
        new_values=details or {},
    )


def _notify(user, title: str, message: str, resource: str, resource_id):
    if user:
        Notification.objects.create(
            user=user,
            title=title,
            message=message,
            notification_type="IN_APP",
            module="payroll",
            resource=resource,
            resource_id=resource_id,
        )


def get_next_doc_number(plant, doc_type: str, prefix: str) -> str:
    today = date.today()
    fy_start = today.year if today.month >= 4 else today.year - 1
    fy_label = f"{fy_start}-{str(fy_start + 1)[2:]}"
    with transaction.atomic():
        seq, _ = DocSequence.objects.select_for_update().get_or_create(
            plant=plant,
            doc_type=doc_type,
            defaults={"last_number": 0, "financial_year": fy_label},
        )
        if seq.financial_year != fy_label:
            seq.financial_year = fy_label
            seq.last_number = 0
        seq.last_number += 1
        seq.save(update_fields=["last_number", "financial_year"])
    return f"{prefix}/{fy_label}/{seq.last_number:05d}"


def _financial_year(d: date) -> str:
    fy_start = d.year if d.month >= 4 else d.year - 1
    return f"{fy_start}-{str(fy_start + 1)[2:]}"


# ─── PT computation ───────────────────────────────────────────────

def _compute_pt(gross_monthly: Decimal, ytd_pt: Decimal = Decimal("0"),
                state_code: str = "MH") -> Decimal:
    """
    Compute Professional Tax for a month using Maharashtra-style slabs.
    Caps at ₹2,500/year (ytd_pt = running total before this month).
    """
    remaining_cap = _two(PT_ANNUAL_CAP - ytd_pt)
    if remaining_cap <= 0:
        return Decimal("0.00")

    pt = Decimal("0.00")
    for threshold, monthly_pt in PT_SLABS_MH:
        if gross_monthly > threshold:
            continue
        pt = monthly_pt
        break
    else:
        pt = PT_SLABS_MH[-1][1]

    return min(_two(pt), remaining_cap)


# ─── Tax computation ──────────────────────────────────────────────

def _compute_income_tax_new_regime(taxable_income: Decimal) -> Decimal:
    """Compute income tax under new regime (FY 2025-26 slabs)."""
    tax = Decimal("0.00")
    prev_slab = Decimal("0")
    for upper, rate in NEW_REGIME_SLABS:
        if upper is None:
            slab_income = taxable_income - prev_slab
        else:
            slab_income = min(taxable_income, upper) - prev_slab
        if slab_income <= 0:
            break
        tax += _two(slab_income * rate / 100)
        if upper is not None:
            prev_slab = upper
        if upper is None or taxable_income <= upper:
            break
    # Rebate u/s 87A: full rebate if taxable income ≤ 7,00,000
    if taxable_income <= Decimal("700000"):
        tax = Decimal("0.00")
    # Add 4% health & education cess
    tax = _two(tax * Decimal("1.04"))
    return tax


def _compute_income_tax_old_regime(taxable_income: Decimal) -> Decimal:
    """Compute income tax under old regime."""
    tax = Decimal("0.00")
    prev_slab = Decimal("0")
    for upper, rate in OLD_REGIME_SLABS:
        if upper is None:
            slab_income = taxable_income - prev_slab
        else:
            slab_income = min(taxable_income, upper) - prev_slab
        if slab_income <= 0:
            break
        tax += _two(slab_income * rate / 100)
        if upper is not None:
            prev_slab = upper
        if upper is None or taxable_income <= upper:
            break
    if taxable_income <= Decimal("500000"):
        tax = Decimal("0.00")
    tax = _two(tax * Decimal("1.04"))
    return tax


# ═══════════════════════════════════════════════════════════════════
# CREATE PAYROLL PERIOD
# ═══════════════════════════════════════════════════════════════════

@transaction.atomic
def create_payroll_period(
    plant,
    month: int,
    year: int,
    *,
    working_days: int = None,
    holidays: list = None,
    notes: str = "",
    created_by=None,
) -> "PayrollPeriod":
    """
    Create a PayrollPeriod for a plant/month/year.

    1. Validate: period must not already exist.
    2. Derive period_start, period_end, total_calendar_days.
    3. working_days defaults to calendar days − Sundays − len(holidays).
    4. AuditLog.
    """
    from apps.payroll.models import PayrollPeriod

    if PayrollPeriod.objects.filter(plant=plant, month=month, year=year).exists():
        raise ValueError(
            f"Payroll period {year}-{month:02d} already exists for plant {plant.code}."
        )

    _, last_day = calendar.monthrange(year, month)
    period_start = date(year, month, 1)
    period_end = date(year, month, last_day)
    total_calendar_days = last_day

    if holidays is None:
        holidays = []

    if working_days is None:
        # Count Mondays–Saturdays minus declared holidays
        sundays = sum(
            1 for d in range(1, last_day + 1)
            if date(year, month, d).weekday() == 6
        )
        working_days = total_calendar_days - sundays - len(holidays)

    period_code = f"{year}-{month:02d}"

    period = PayrollPeriod.objects.create(
        plant=plant,
        period_code=period_code,
        month=month,
        year=year,
        period_start=period_start,
        period_end=period_end,
        total_calendar_days=total_calendar_days,
        working_days=working_days,
        holidays=holidays,
        status="OPEN",
        notes=notes,
        created_by=created_by,
    )

    _log(created_by, "CREATE", "PayrollPeriod", period.pk, {
        "period_code": period_code,
        "plant": plant.code,
        "working_days": working_days,
    })
    return period


# ═══════════════════════════════════════════════════════════════════
# PROCESS PAYROLL RUN
# ═══════════════════════════════════════════════════════════════════

@transaction.atomic
def process_payroll_run(
    period,
    *,
    processed_by=None,
    force_reprocess: bool = False,
) -> "PayrollRun":
    """
    Batch-process a payroll run for all ACTIVE employees in the period's plant.

    Steps:
    1. Validate period is OPEN.
    2. Create or reset PayrollRun.
    3. Pull hr.Payroll (via hr.generate_payroll) to get computed PayrollLines.
    4. For each PayrollLine → generate_payslip(), compute_pf_esi(), compute_tds().
    5. Build statutory registers (PF, ESI, PT).
    6. Aggregate totals on PayrollRun.
    7. Set status = REVIEW.
    """
    from apps.payroll.models import PayrollRun, EmployeePayslip

    if period.status not in ("OPEN",) and not force_reprocess:
        raise ValueError(
            f"Period {period.period_code} is '{period.status}'. "
            "Cannot process a non-OPEN period."
        )

    # Get or create PayrollRun
    run, created = PayrollRun.objects.get_or_create(
        period=period,
        defaults={
            "run_number": get_next_doc_number(period.plant, "PRN", "PRN"),
            "status": "DRAFT",
        },
    )

    if not created and run.status == "POSTED":
        raise ValueError(
            f"PayrollRun {run.run_number} is already POSTED. "
            "Cannot reprocess."
        )
    if not created and force_reprocess:
        # Clear existing payslips and registers
        EmployeePayslip.objects.filter(payroll_run=run).delete()
        run.status = "PROCESSING"
        run.save(update_fields=["status"])

    run.status = "PROCESSING"
    run.processed_by = processed_by
    run.save(update_fields=["status", "processed_by"])

    # Pull employees for this plant
    from apps.hr.models import Employee, SalaryStructure
    employees = Employee.objects.filter(
        plant=period.plant,
        status="ACTIVE",
        salary_structure__isnull=False,
    ).select_related("salary_structure", "department", "designation")

    # Use hr.generate_payroll to get computed lines
    from apps.hr.services import generate_payroll
    hr_payroll = generate_payroll(
        plant=period.plant,
        month=period.month,
        year=period.year,
        user=processed_by,
    )

    total_gross = Decimal("0")
    total_deductions = Decimal("0")
    total_net = Decimal("0")
    total_er_pf = Decimal("0")
    total_er_esi = Decimal("0")
    total_tds = Decimal("0")
    total_pt = Decimal("0")
    count = 0

    for hr_line in hr_payroll.lines.select_related("employee").prefetch_related("parts"):
        emp = hr_line.employee

        # Get YTD PT to enforce annual cap
        from apps.payroll.models import ProfessionalTax
        from django.db.models import Sum
        ytd_pt = (
            ProfessionalTax.objects
            .filter(employee=emp, period__year=period.year)
            .exclude(payroll_run=run)
            .aggregate(t=Sum("pt_amount"))["t"] or Decimal("0")
        )

        # Get active TaxDeclaration for this FY
        fy = _financial_year(period.period_start)
        from apps.payroll.models import TaxDeclaration
        try:
            tax_decl = TaxDeclaration.objects.get(
                employee=emp, financial_year=fy, status="APPROVED"
            )
            monthly_tds = tax_decl.monthly_tds
        except TaxDeclaration.DoesNotExist:
            monthly_tds = Decimal("0.00")

        # Build payslip
        payslip = generate_payslip(
            run=run,
            period=period,
            employee=emp,
            hr_line=hr_line,
            monthly_tds=monthly_tds,
            ytd_pt=ytd_pt,
            processed_by=processed_by,
        )

        # Statutory registers
        pf_rec, esi_rec = compute_pf_esi(run, payslip)
        pt_rec = _create_pt_record(run, payslip, ytd_pt)

        total_gross += payslip.gross_earnings
        total_deductions += payslip.total_deductions
        total_net += payslip.net_salary
        # BUG-039 fix: was employer_epf + employer_eps only, missing EDLI (0.5%) and admin (0.5%)
        total_er_pf += pf_rec.total_employer_contribution if pf_rec else Decimal("0")
        total_er_esi += esi_rec.employer_contribution if esi_rec else Decimal("0")
        total_tds += payslip.tds_amount
        total_pt += payslip.professional_tax
        count += 1

    # Update run aggregates
    run.employee_count = count
    run.total_gross = _two(total_gross)
    run.total_employee_deductions = _two(total_deductions)
    run.total_net_payable = _two(total_net)
    run.total_employer_pf = _two(total_er_pf)
    run.total_employer_esi = _two(total_er_esi)
    run.total_tds = _two(total_tds)
    run.total_professional_tax = _two(total_pt)
    run.pf_register_generated = True
    run.esi_register_generated = True
    run.pt_register_generated = True
    run.status = "REVIEW"
    run.save()

    _log(processed_by, "UPDATE", "PayrollRun", run.pk, {
        "run_number": run.run_number,
        "period": period.period_code,
        "employee_count": count,
        "total_net": str(run.total_net_payable),
    })

    return run


# ═══════════════════════════════════════════════════════════════════
# GENERATE PAYSLIP
# ═══════════════════════════════════════════════════════════════════

@transaction.atomic
def generate_payslip(
    run,
    period,
    employee,
    hr_line,
    *,
    monthly_tds: Decimal = Decimal("0"),
    ytd_pt: Decimal = Decimal("0"),
    processed_by=None,
) -> "EmployeePayslip":
    """
    Create an EmployeePayslip from an hr.PayrollLine.

    1. Auto-generate payslip_number (PSL/YYYY-YY/NNNNN).
    2. Map PayrollLineParts → PayslipLines.
    3. Compute PT for this month (with cap).
    4. Compute total_deductions including TDS + PT.
    5. net_salary = gross_earnings − total_deductions.
    """
    from apps.payroll.models import EmployeePayslip, PayslipLine
    from apps.hr.models import SalaryComponent

    payslip_number = get_next_doc_number(period.plant, "PSL", "PSL")

    gross = _two(hr_line.gross_salary)
    # BUG-036 fix: removed dead code (employee_pf = _two(... if False else 0))

    # Re-derive employee PF/ESI from line parts
    emp_pf = Decimal("0")
    emp_esi = Decimal("0")
    for part in hr_line.parts.select_related("component").all():
        if part.component.code in ("EMP_PF", "EMPLOYEE_PF", "PF"):
            emp_pf = _two(part.amount)
        if part.component.code in ("EMP_ESI", "EMPLOYEE_ESI", "ESI"):
            emp_esi = _two(part.amount)

    # PT for this month
    pt_amount = _compute_pt(gross, ytd_pt)

    # Total deductions: all deduction/statutory components + TDS + PT
    base_deductions = _two(hr_line.total_deductions)
    total_deductions = _two(base_deductions + monthly_tds + pt_amount)
    net_salary = _two(gross - total_deductions)

    payslip = EmployeePayslip.objects.create(
        payroll_run=run,
        employee=employee,
        period=period,
        payslip_number=payslip_number,
        status="DRAFT",
        working_days=hr_line.working_days,
        days_present=hr_line.days_present,
        days_absent=hr_line.days_absent,
        days_leave=hr_line.days_leave,
        overtime_hours=hr_line.overtime_hours,
        lop_days=hr_line.days_absent,
        gross_earnings=gross,
        total_deductions=total_deductions,
        net_salary=net_salary,
        employee_pf=emp_pf,
        employee_esi=emp_esi,
        employer_pf=_two(hr_line.employer_pf),
        employer_esi=_two(hr_line.employer_esi),
        tds_amount=_two(monthly_tds),
        professional_tax=pt_amount,
    )

    # Create PayslipLines from hr PayrollLineParts
    for part in hr_line.parts.select_related("component").all():
        PayslipLine.objects.create(
            payslip=payslip,
            component=part.component,
            component_type=part.component.component_type,
            computed_amount=_two(part.computed_amount),
            override_amount=(
                _two(part.override_amount) if part.override_amount is not None else None
            ),
            is_taxable=part.component.is_taxable,
        )

    return payslip


# ═══════════════════════════════════════════════════════════════════
# APPROVE PAYSLIP
# ═══════════════════════════════════════════════════════════════════

@transaction.atomic
def approve_payslip(payslip, approved_by, *, publish: bool = False) -> "EmployeePayslip":
    """
    Approve (lock) a single EmployeePayslip.

    If publish=True → set status=PUBLISHED (employee can see it).
    Notifies the employee's linked user account.
    """
    if payslip.status not in ("DRAFT",):
        raise ValueError(
            f"Payslip {payslip.payslip_number} is in status '{payslip.status}' "
            "and cannot be approved."
        )

    payslip.status = "PUBLISHED" if publish else "APPROVED"
    payslip.approved_by = approved_by
    payslip.approved_at = timezone.now()
    payslip.save(update_fields=["status", "approved_by", "approved_at"])

    _log(approved_by, "UPDATE", "EmployeePayslip", payslip.pk, {
        "payslip_number": payslip.payslip_number,
        "status": payslip.status,
        "net_salary": str(payslip.net_salary),
    })

    # Notify employee
    linked_user = getattr(payslip.employee, "user", None)
    if linked_user and publish:
        _notify(
            linked_user,
            f"Payslip Available: {payslip.period.period_code}",
            f"Your payslip for {payslip.period.period_code} is ready. "
            f"Net pay: ₹{payslip.net_salary:,.2f}.",
            "EmployeePayslip", payslip.pk,
        )

    return payslip


# ═══════════════════════════════════════════════════════════════════
# POST PAYROLL VOUCHER
# ═══════════════════════════════════════════════════════════════════

@transaction.atomic
def post_payroll_voucher(run, posted_by=None) -> "PayrollRun":
    """
    Post accounting vouchers for an approved PayrollRun.

    Vouchers created:
    1. Salary Journal:
         DR  Salary Expense  (total_gross + total_employer_pf + total_employer_esi)
         CR  Employee Payables (total_net_payable)
         CR  Employee PF Payable
         CR  Employee ESI Payable
         CR  TDS Payable
         CR  PT Payable

    2. PF Voucher (employer share):
         DR  PF Expense (employer)
         CR  PF Payable

    3. ESI Voucher (employer share):
         DR  ESI Expense (employer)
         CR  ESI Payable

    4. TDS Voucher:
         DR  TDS Payable
         CR  TDS Payable to Govt   (flag for payment tracking)
    """
    from apps.accounts.models import Voucher, VoucherLine, LedgerAccount

    if run.status != "APPROVED":
        raise ValueError(
            f"PayrollRun {run.run_number} must be APPROVED before posting "
            f"(current status: '{run.status}')."
        )
    if run.salary_voucher:
        raise ValueError(
            f"PayrollRun {run.run_number} has already been posted."
        )

    plant = run.period.plant
    period_code = run.period.period_code

    def _voucher(narration, total, vtype=None):
        # BUG-027 fix: Voucher has no total_amount or created_by fields;
        # use prepared_by= and DRAFT status; post_voucher() called after adding lines
        from apps.accounts.models import Voucher
        vtype = vtype or Voucher.VoucherType.JOURNAL
        return Voucher.objects.create(
            plant=plant,
            voucher_number=get_next_doc_number(plant, "JNL", "JNL"),
            voucher_type=vtype,
            voucher_date=run.period.period_end,
            narration=narration,
            status=Voucher.VoucherStatus.DRAFT,
            prepared_by=posted_by,
        )

    def _line(voucher, ledger, dr, cr, narration=""):
        VoucherLine.objects.create(
            voucher=voucher, ledger=ledger,
            debit_amount=_two(dr), credit_amount=_two(cr),
            narration=narration,
        )

    def _get_ledger(sub_type):
        try:
            return LedgerAccount.objects.get(plant=plant, sub_type=sub_type, is_system=True)
        except LedgerAccount.DoesNotExist:
            return None

    # ── 1. Salary Journal ─────────────────────────────────────────
    total_dr = _two(run.total_gross + run.total_employer_pf + run.total_employer_esi)
    sal_voucher = _voucher(
        f"Salary for {period_code} — {run.employee_count} employees",
        total_dr,
    )

    sal_expense = _get_ledger("SALARY_EXPENSE")
    ee_payable = _get_ledger("EMPLOYEE_PAYABLES")
    pf_payable_ee = _get_ledger("PF_EMPLOYEE_PAYABLE")
    esi_payable_ee = _get_ledger("ESI_EMPLOYEE_PAYABLE")
    tds_payable = _get_ledger("TDS_PAYABLE")
    pt_payable = _get_ledger("PT_PAYABLE")

    if all([sal_expense, ee_payable]):
        _line(sal_voucher, sal_expense, total_dr, 0, f"Salary expense {period_code}")
        _line(sal_voucher, ee_payable, 0, run.total_net_payable, "Net payable to employees")
        if pf_payable_ee:
            # BUG-027 fix: was run.total_employer_pf + run.total_tds (double-counted TDS)
            _line(sal_voucher, pf_payable_ee, 0, run.total_employer_pf, "PF deductions")
        if esi_payable_ee:
            _line(sal_voucher, esi_payable_ee, 0, run.total_employer_esi, "ESI deductions")
        if tds_payable and run.total_tds:
            _line(sal_voucher, tds_payable, 0, run.total_tds, f"TDS {period_code}")
        if pt_payable and run.total_professional_tax:
            _line(sal_voucher, pt_payable, 0, run.total_professional_tax, f"PT {period_code}")
    # BUG-030 fix: call post_voucher() so LedgerAccount.current_balance is updated
    from apps.accounts.services import post_voucher as _post_voucher
    _post_voucher(sal_voucher, posted_by)

    # ── 2. Employer PF Voucher ────────────────────────────────────
    pf_voucher = None
    if run.total_employer_pf > 0:
        pf_voucher = _voucher(
            f"Employer PF contribution — {period_code}",
            run.total_employer_pf,
        )
        pf_expense = _get_ledger("PF_EMPLOYER_EXPENSE")
        pf_payable = _get_ledger("PF_PAYABLE")
        if pf_expense and pf_payable:
            _line(pf_voucher, pf_expense, run.total_employer_pf, 0, f"Employer PF {period_code}")
            _line(pf_voucher, pf_payable, 0, run.total_employer_pf, "PF payable")
        # BUG-030 fix: post voucher to update ledger balances
        _post_voucher(pf_voucher, posted_by)

    # ── 3. Employer ESI Voucher ───────────────────────────────────
    esi_voucher = None
    if run.total_employer_esi > 0:
        esi_voucher = _voucher(
            f"Employer ESI contribution — {period_code}",
            run.total_employer_esi,
        )
        esi_expense = _get_ledger("ESI_EMPLOYER_EXPENSE")
        esi_payable = _get_ledger("ESI_PAYABLE")
        if esi_expense and esi_payable:
            _line(esi_voucher, esi_expense, run.total_employer_esi, 0, f"Employer ESI {period_code}")
            _line(esi_voucher, esi_payable, 0, run.total_employer_esi, "ESI payable")
        # BUG-030 fix: post voucher to update ledger balances
        _post_voucher(esi_voucher, posted_by)

    # ── 4. TDS Voucher ────────────────────────────────────────────
    tds_voucher = None
    if run.total_tds > 0:
        tds_voucher = _voucher(
            f"TDS on salary — {period_code}",
            run.total_tds,
        )
        tds_payable_l = _get_ledger("TDS_PAYABLE")
        tds_govt = _get_ledger("TDS_GOVT_PAYABLE")
        if tds_payable_l and tds_govt:
            _line(tds_voucher, tds_payable_l, run.total_tds, 0, "TDS deducted from employees")
            _line(tds_voucher, tds_govt, 0, run.total_tds, "TDS payable to government")
        # BUG-030 fix: post voucher to update ledger balances
        _post_voucher(tds_voucher, posted_by)

    # ── Update run ────────────────────────────────────────────────
    run.salary_voucher = sal_voucher
    run.pf_voucher = pf_voucher
    run.esi_voucher = esi_voucher
    run.tds_voucher = tds_voucher
    run.status = "POSTED"
    run.posted_at = timezone.now()
    run.save(update_fields=[
        "salary_voucher", "pf_voucher", "esi_voucher", "tds_voucher",
        "status", "posted_at",
    ])

    # Lock the period
    run.period.status = "LOCKED"
    run.period.save(update_fields=["status"])

    _log(posted_by, "UPDATE", "PayrollRun", run.pk, {
        "run_number": run.run_number,
        "status": "POSTED",
        "salary_voucher": sal_voucher.voucher_number,
        "total_net": str(run.total_net_payable),
    })

    return run


# ═══════════════════════════════════════════════════════════════════
# COMPUTE TDS
# ═══════════════════════════════════════════════════════════════════

@transaction.atomic
def compute_tds(
    employee,
    financial_year: str,
    *,
    projected_annual_salary: Decimal = None,
    other_income: Decimal = Decimal("0"),
    tax_regime: str = "NEW",
    section_80c: Decimal = Decimal("0"),
    section_80d: Decimal = Decimal("0"),
    section_80ccd_nps: Decimal = Decimal("0"),
    section_80tta: Decimal = Decimal("0"),
    hra_exemption: Decimal = Decimal("0"),
    home_loan_interest: Decimal = Decimal("0"),
    home_loan_principal: Decimal = Decimal("0"),
    other_deductions: Decimal = Decimal("0"),
    tax_already_deducted: Decimal = Decimal("0"),
    remaining_months: int = 12,
    submitted_by=None,
    auto_approve: bool = False,
) -> "TaxDeclaration":
    """
    Compute monthly TDS from annual income-tax declaration.

    Steps:
    1. Project annual salary from employee CTC if not provided.
    2. Compute total deductions based on regime.
    3. Compute annual tax liability.
    4. monthly_tds = (annual_tax − tax_already_deducted) / remaining_months.
    5. Create or update TaxDeclaration.

    New regime (default): standard deduction ₹75,000; deductions under
    80C/80D/80CCD limited; HRA, home loan deductions not available.
    Old regime: ₹50,000 std deduction + all declared deductions.
    """
    from apps.payroll.models import TaxDeclaration

    # Project annual salary
    if projected_annual_salary is None:
        projected_annual_salary = _two(employee.ctc)

    total_income = _two(projected_annual_salary + other_income)

    if tax_regime == "NEW":
        std_ded = NEW_REGIME_STD_DED
        # New regime: only std deduction + employer NPS contribution
        # (80C, 80D, HRA, home loan not available)
        total_deductions = min(std_ded, total_income)
        taxable_income = _two(max(total_income - total_deductions, Decimal("0")))
        annual_tax = _compute_income_tax_new_regime(taxable_income)
    else:
        std_ded = OLD_REGIME_STD_DED
        ded_80c = min(_two(section_80c + home_loan_principal), Decimal("150000"))
        ded_80d = min(_two(section_80d), Decimal("25000"))
        ded_80ccd = min(_two(section_80ccd_nps), Decimal("50000"))
        ded_80tta = min(_two(section_80tta), Decimal("10000"))
        sec24 = min(_two(home_loan_interest), Decimal("200000"))
        total_deductions = _two(
            std_ded + ded_80c + ded_80d + ded_80ccd
            + ded_80tta + hra_exemption + sec24 + other_deductions
        )
        taxable_income = _two(max(total_income - total_deductions, Decimal("0")))
        annual_tax = _compute_income_tax_old_regime(taxable_income)

    remaining_months = max(remaining_months, 1)
    remaining_tax = _two(max(annual_tax - tax_already_deducted, Decimal("0")))
    monthly_tds = _two(remaining_tax / remaining_months)

    decl, _ = TaxDeclaration.objects.update_or_create(
        employee=employee,
        financial_year=financial_year,
        defaults=dict(
            plant=employee.plant,
            tax_regime=tax_regime,
            projected_annual_salary=projected_annual_salary,
            other_income=other_income,
            section_80c=section_80c,
            section_80d=section_80d,
            section_80ccd_nps=section_80ccd_nps,
            section_80tta=section_80tta,
            hra_exemption=hra_exemption,
            home_loan_interest=home_loan_interest,
            home_loan_principal=home_loan_principal,
            other_deductions=other_deductions,
            total_taxable_income=taxable_income,
            projected_annual_tax=annual_tax,
            monthly_tds=monthly_tds,
            tax_already_deducted=tax_already_deducted,
            status="APPROVED" if auto_approve else "SUBMITTED",
            submitted_at=timezone.now(),
            approved_by=submitted_by if auto_approve else None,
            approved_at=timezone.now() if auto_approve else None,
        ),
    )

    _log(submitted_by, "UPDATE", "TaxDeclaration", decl.pk, {
        "employee": employee.employee_code,
        "financial_year": financial_year,
        "taxable_income": str(taxable_income),
        "annual_tax": str(annual_tax),
        "monthly_tds": str(monthly_tds),
    })

    return decl


# ═══════════════════════════════════════════════════════════════════
# COMPUTE PF & ESI
# ═══════════════════════════════════════════════════════════════════

@transaction.atomic
def compute_pf_esi(run, payslip) -> tuple:
    """
    Create PFContribution and ESIContribution records for a payslip.

    PF:
      - pf_wage = basic from payslip lines (component code BASIC / BASIC_SALARY)
      - pf_wage_capped = min(pf_wage, 15000)
      - EE contribution = 12 % of capped
      - ER EPF = 3.67 % of capped
      - ER EPS = min(8.33 % of capped, 1250)
      - ER EDLI = min(0.50 % of capped, 75)
      - ER Admin = 0.50 % of capped

    ESI:
      - Applicable if gross ≤ 21000
      - EE = 0.75 % of gross
      - ER = 3.25 % of gross
    """
    from apps.payroll.models import PFContribution, ESIContribution

    # Determine basic salary from payslip lines
    basic = Decimal("0")
    for line in payslip.lines.select_related("component").all():
        if line.component.code.upper() in ("BASIC", "BASIC_SALARY", "BASIC_PAY"):
            basic = _two(line.amount)
            break
    if not basic:
        basic = _two(payslip.gross_earnings * Decimal("0.4"))  # fallback: 40% of gross

    pf_wage_capped = min(_two(basic), PF_WAGE_CEILING)

    ee_pf = _two(pf_wage_capped * PF_EE_PCT / 100)
    er_epf = _two(pf_wage_capped * PF_EPF_ER_PCT / 100)
    er_eps = min(_two(pf_wage_capped * PF_EPS_ER_PCT / 100), EPS_MAX_MONTHLY)
    er_edli = min(_two(pf_wage_capped * PF_EDLI_PCT / 100), EDLI_MAX_MONTHLY)
    er_admin = _two(pf_wage_capped * PF_ADMIN_PCT / 100)

    pf_rec, _ = PFContribution.objects.update_or_create(
        payroll_run=run,
        employee=payslip.employee,
        defaults=dict(
            payslip=payslip,
            period=payslip.period,
            uan=payslip.employee.uan,
            pf_wage=_two(basic),
            pf_wage_capped=pf_wage_capped,
            employee_contribution=ee_pf,
            employer_epf=er_epf,
            employer_eps=er_eps,
            employer_edli=er_edli,
            employer_admin=er_admin,
            is_excluded=not bool(payslip.employee.uan),
        ),
    )

    # ESI
    gross = _two(payslip.gross_earnings)
    esi_applicable = gross <= ESI_WAGE_CEILING
    ee_esi = _two(gross * ESI_EE_PCT / 100) if esi_applicable else Decimal("0")
    er_esi = _two(gross * ESI_ER_PCT / 100) if esi_applicable else Decimal("0")

    esi_rec, _ = ESIContribution.objects.update_or_create(
        payroll_run=run,
        employee=payslip.employee,
        defaults=dict(
            payslip=payslip,
            period=payslip.period,
            esic_number=payslip.employee.esic_number,
            gross_wages=gross,
            esi_applicable=esi_applicable,
            employee_contribution=ee_esi,
            employer_contribution=er_esi,
            is_excluded=not esi_applicable,
        ),
    )

    # Sync statutory amounts back to payslip
    payslip.employee_pf = ee_pf
    payslip.employer_pf = _two(er_epf + er_eps)
    payslip.employee_esi = ee_esi
    payslip.employer_esi = er_esi
    payslip.save(update_fields=[
        "employee_pf", "employer_pf", "employee_esi", "employer_esi"
    ])

    return pf_rec, esi_rec


def _create_pt_record(run, payslip, ytd_pt: Decimal):
    """Create ProfessionalTax record for a payslip."""
    from apps.payroll.models import ProfessionalTax

    gross = _two(payslip.gross_earnings)
    pt_amount = _compute_pt(gross, ytd_pt)

    pt_rec, _ = ProfessionalTax.objects.update_or_create(
        payroll_run=run,
        employee=payslip.employee,
        defaults=dict(
            payslip=payslip,
            period=payslip.period,
            state_code=getattr(payslip.employee.plant, "state_code", "MH"),
            gross_salary=gross,
            pt_amount=pt_amount,
            ytd_pt=_two(ytd_pt + pt_amount),
        ),
    )

    payslip.professional_tax = pt_amount
    payslip.save(update_fields=["professional_tax"])

    return pt_rec
