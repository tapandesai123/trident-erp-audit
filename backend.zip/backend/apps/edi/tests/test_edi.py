"""
Tests — Task 21: EDI Integration
Covers:
  - Amazon Excel upload → SalesOrder creation
  - Unknown SKU → error_log entry (not fatal, SO still created)
  - Flipkart column mapping → independent SalesOrders
  - API: upload endpoint creates batch
  - Duplicate-guard: open PR not re-raised (N/A here; covered in task 20)
  - process_edi_batch task runs synchronously in tests
"""
import io
from datetime import date, timedelta
from decimal import Decimal

from django.contrib.auth import get_user_model
from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import TestCase, override_settings
from django.urls import reverse
from rest_framework import status
from rest_framework.test import APITestCase

User = get_user_model()


# ─── Fixtures helpers ─────────────────────────────────────────────────────────

def _make_base_context():
    """Create minimal DB objects needed for EDI processing."""
    from apps.core.models import Company, Plant
    from apps.masters.models import ItemGroup, UOM, Item, CustomerGroup, Customer

    company = Company.objects.create(
        name="EDI Test Co",
        financial_year_start=4,
    )
    plant = Plant.objects.create(
        company=company,
        code="EDI1",
        name="EDI Plant",
        gstin="27AAKFT4708J2ZY",
        is_active=True,
    )

    system_user = User.objects.create_user(
        username="system",
        email="system@edi.test",
        password="x",
        is_superuser=True,
    )

    uom = UOM.objects.create(code="PCS", name="Pieces")
    igroup = ItemGroup.objects.create(code="BOX", name="Boxes")

    item_known = Item.objects.create(
        code="BOX-001", name="Small Box 10x10",
        item_group=igroup, item_type="FINISHED_GOOD",
        uom=uom, is_active=True,
        approval_status="APPROVED",
    )
    item_known2 = Item.objects.create(
        code="BOX-002", name="Medium Box 20x20",
        item_group=igroup, item_type="FINISHED_GOOD",
        uom=uom, is_active=True,
        approval_status="APPROVED",
    )

    return dict(
        company=company, plant=plant,
        system_user=system_user,
        uom=uom, igroup=igroup,
        item_known=item_known,
        item_known2=item_known2,
    )


def _make_amazon_excel(rows: list[dict]) -> bytes:
    """
    Build an in-memory Amazon-format Excel file.
    rows: list of dicts with keys matching Amazon column names.
    Returns raw xlsx bytes.
    """
    import openpyxl
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "orders"

    headers = [
        "Order ID", "Order Date", "Customer Name", "ASIN",
        "SKU", "Qty", "Ship-by Date", "Ship Address",
        "City", "State", "Pincode",
    ]
    ws.append(headers)

    for row in rows:
        ws.append([
            row.get("Order ID", ""),
            row.get("Order Date", ""),
            row.get("Customer Name", ""),
            row.get("ASIN", ""),
            row.get("SKU", ""),
            row.get("Qty", 1),
            row.get("Ship-by Date", ""),
            row.get("Ship Address", ""),
            row.get("City", ""),
            row.get("State", ""),
            row.get("Pincode", ""),
        ])

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return buf.read()


def _make_flipkart_excel(rows: list[dict]) -> bytes:
    """Build an in-memory Flipkart-format Excel file."""
    import openpyxl
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "fk_orders"

    headers = [
        "Order ID", "Order Date", "Product Title", "FSN",
        "Qty", "Customer Name", "Ship To", "City", "State", "Pin",
    ]
    ws.append(headers)

    for row in rows:
        ws.append([
            row.get("Order ID", ""),
            row.get("Order Date", ""),
            row.get("Product Title", ""),
            row.get("FSN", ""),
            row.get("Qty", 1),
            row.get("Customer Name", ""),
            row.get("Ship To", ""),
            row.get("City", ""),
            row.get("State", ""),
            row.get("Pin", ""),
        ])

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return buf.read()


def _create_edi_batch(platform: str, xlsx_bytes: bytes, user=None):
    """Create an EDIUploadBatch directly (bypassing HTTP upload for service-level tests)."""
    from apps.edi.models import EDIUploadBatch
    from django.core.files.base import ContentFile

    batch = EDIUploadBatch(
        platform=platform,
        status=EDIUploadBatch.Status.PENDING,
        uploaded_by=user,
    )
    filename = f"test_{platform.lower()}_orders.xlsx"
    batch.uploaded_file.save(filename, ContentFile(xlsx_bytes), save=False)
    batch.save()
    return batch


# ─── Amazon Processing Tests ──────────────────────────────────────────────────

@override_settings(CELERY_TASK_ALWAYS_EAGER=True, CELERY_TASK_EAGER_PROPAGATES=True)
class AmazonExcelProcessingTest(TestCase):
    """Unit tests for process_amazon_excel service function."""

    def setUp(self):
        self.ctx = _make_base_context()

    def _amazon_rows(self, n=5, include_bad_sku=False):
        rows = []
        today = date.today().strftime("%d-%m-%Y")
        ship_by = (date.today() + timedelta(days=3)).strftime("%d-%m-%Y")
        for i in range(1, n + 1):
            rows.append({
                "Order ID":       f"AMZ-2024-{i:04d}",
                "Order Date":     today,
                "Customer Name":  f"Amazon Customer {i}",
                "ASIN":           f"B00EXAMPLE{i}",
                "SKU":            "BOX-001",  # valid SKU
                "Qty":            i,
                "Ship-by Date":   ship_by,
                "Ship Address":   f"{i} MG Road",
                "City":           "Mumbai",
                "State":          "Maharashtra",
                "Pincode":        "400001",
            })
        if include_bad_sku:
            rows.append({
                "Order ID":       "AMZ-BAD-001",
                "Order Date":     today,
                "Customer Name":  "Bad SKU Customer",
                "ASIN":           "B00BADSKU",
                "SKU":            "NONEXISTENT-SKU",  # unknown SKU
                "Qty":            1,
                "Ship-by Date":   ship_by,
                "City":           "Delhi",
                "State":          "Delhi",
                "Pincode":        "110001",
            })
        return rows

    def test_5_valid_rows_create_5_sales_orders(self):
        """Core acceptance criterion: 5 Amazon rows → 5 SalesOrders."""
        from apps.edi.services import process_amazon_excel
        from apps.sales.models import SalesOrder

        rows = self._amazon_rows(n=5)
        xlsx_bytes = _make_amazon_excel(rows)
        batch = _create_edi_batch("AMAZON", xlsx_bytes, user=self.ctx["system_user"])

        process_amazon_excel(batch.pk)

        batch.refresh_from_db()
        self.assertEqual(batch.status, "COMPLETED")
        self.assertEqual(batch.total_rows, 5)
        self.assertEqual(batch.success_rows, 5)
        self.assertEqual(batch.failed_rows, 0)
        self.assertEqual(batch.created_sales_orders.count(), 5)

        # Verify SalesOrder contents
        so = batch.created_sales_orders.order_by("so_number").first()
        self.assertIsNotNone(so)
        self.assertEqual(so.portal_source, "AMAZON")
        self.assertIn("AMZ-2024", so.customer_po_number)
        self.assertEqual(so.lines.count(), 1)

    def test_unknown_sku_row_logs_error_but_creates_so(self):
        """
        A row with an unknown SKU should:
        - Still create a SalesOrder (linked to no item)
        - Log a warning to error_log
        - NOT be counted as a fatal failure
        """
        from apps.edi.services import process_amazon_excel
        from apps.sales.models import SalesOrder

        rows = self._amazon_rows(n=3, include_bad_sku=True)
        xlsx_bytes = _make_amazon_excel(rows)
        batch = _create_edi_batch("AMAZON", xlsx_bytes, user=self.ctx["system_user"])

        process_amazon_excel(batch.pk)

        batch.refresh_from_db()
        self.assertEqual(batch.status, "COMPLETED")
        self.assertEqual(batch.total_rows, 4)  # 3 valid + 1 bad SKU
        # All 4 SOs are created; bad-SKU SO has item=None
        self.assertEqual(batch.success_rows, 4)

        # Error log should have the unknown-SKU warning
        sku_errors = [e for e in batch.error_log if "NONEXISTENT-SKU" in e.get("error", "")]
        self.assertEqual(len(sku_errors), 1)
        self.assertIn("not found", sku_errors[0]["error"])

        # The bad-SKU SO exists with no item on the line
        all_sos = batch.created_sales_orders.all()
        self.assertEqual(all_sos.count(), 4)

        bad_so = batch.created_sales_orders.filter(customer_po_number="AMZ-BAD-001").first()
        self.assertIsNotNone(bad_so)
        line = bad_so.lines.first()
        self.assertIsNotNone(line)
        self.assertIsNone(line.item)  # no item linked

    def test_customer_auto_created_if_not_found(self):
        """If customer name doesn't exist in masters, it should be auto-created."""
        from apps.edi.services import process_amazon_excel
        from apps.masters.models import Customer

        rows = [{
            "Order ID":       "AMZ-NEW-CUST-001",
            "Order Date":     date.today().strftime("%d-%m-%Y"),
            "Customer Name":  "Brand New Customer",
            "SKU":            "BOX-001",
            "Qty":            10,
            "City":           "Chennai",
            "State":          "Tamil Nadu",
            "Pincode":        "600001",
        }]
        xlsx_bytes = _make_amazon_excel(rows)
        batch = _create_edi_batch("AMAZON", xlsx_bytes)
        process_amazon_excel(batch.pk)

        batch.refresh_from_db()
        self.assertEqual(batch.success_rows, 1)

        new_cust = Customer.objects.filter(name__icontains="Brand New Customer").first()
        self.assertIsNotNone(new_cust)
        self.assertEqual(new_cust.customer_type, "E_COMMERCE")

    def test_batch_status_set_to_completed(self):
        """Batch status must transition PENDING → COMPLETED on success."""
        from apps.edi.services import process_amazon_excel

        rows = self._amazon_rows(n=2)
        xlsx_bytes = _make_amazon_excel(rows)
        batch = _create_edi_batch("AMAZON", xlsx_bytes)
        self.assertEqual(batch.status, "PENDING")

        process_amazon_excel(batch.pk)

        batch.refresh_from_db()
        self.assertEqual(batch.status, "COMPLETED")

    def test_same_customer_reused_on_second_order(self):
        """If the same customer name appears twice, only 1 Customer record is created."""
        from apps.edi.services import process_amazon_excel
        from apps.masters.models import Customer

        rows = [
            {"Order ID": "AMZ-DUP-001", "Customer Name": "Repeated Customer",
             "SKU": "BOX-001", "Qty": 1, "Order Date": date.today().strftime("%d-%m-%Y")},
            {"Order ID": "AMZ-DUP-002", "Customer Name": "Repeated Customer",
             "SKU": "BOX-002", "Qty": 2, "Order Date": date.today().strftime("%d-%m-%Y")},
        ]
        xlsx_bytes = _make_amazon_excel(rows)
        batch = _create_edi_batch("AMAZON", xlsx_bytes)
        process_amazon_excel(batch.pk)

        batch.refresh_from_db()
        self.assertEqual(batch.success_rows, 2)
        count = Customer.objects.filter(name__icontains="Repeated Customer").count()
        self.assertEqual(count, 1)

    def test_qty_is_correctly_mapped(self):
        """SOLine.ordered_qty must match the Excel Qty column."""
        from apps.edi.services import process_amazon_excel

        rows = [{"Order ID": "AMZ-QTY-001", "Customer Name": "Qty Tester",
                 "SKU": "BOX-001", "Qty": 42,
                 "Order Date": date.today().strftime("%d-%m-%Y")}]
        xlsx_bytes = _make_amazon_excel(rows)
        batch = _create_edi_batch("AMAZON", xlsx_bytes)
        process_amazon_excel(batch.pk)

        batch.refresh_from_db()
        so = batch.created_sales_orders.first()
        self.assertIsNotNone(so)
        line = so.lines.first()
        self.assertEqual(line.ordered_qty, Decimal("42"))


# ─── Flipkart Processing Tests ────────────────────────────────────────────────

@override_settings(CELERY_TASK_ALWAYS_EAGER=True, CELERY_TASK_EAGER_PROPAGATES=True)
class FlipkartExcelProcessingTest(TestCase):
    """Unit tests for process_flipkart_excel service function."""

    def setUp(self):
        self.ctx = _make_base_context()

    def test_flipkart_3_rows_create_3_sales_orders(self):
        """Flipkart column mapping works independently from Amazon."""
        from apps.edi.services import process_flipkart_excel
        from apps.sales.models import SalesOrder

        today = date.today().strftime("%d-%m-%Y")
        rows = [
            {
                "Order ID":       f"FK-ORD-{i:04d}",
                "Order Date":     today,
                "Product Title":  "Small Cardboard Box",
                "FSN":            "BOX-001",   # maps to item.code
                "Qty":            i * 5,
                "Customer Name":  f"Flipkart Buyer {i}",
                "Ship To":        f"{i} Park Street",
                "City":           "Kolkata",
                "State":          "West Bengal",
                "Pin":            "700001",
            }
            for i in range(1, 4)
        ]

        xlsx_bytes = _make_flipkart_excel(rows)
        batch = _create_edi_batch("FLIPKART", xlsx_bytes, user=self.ctx["system_user"])

        process_flipkart_excel(batch.pk)

        batch.refresh_from_db()
        self.assertEqual(batch.status, "COMPLETED")
        self.assertEqual(batch.total_rows, 3)
        self.assertEqual(batch.success_rows, 3)
        self.assertEqual(batch.created_sales_orders.count(), 3)

        # portal_source should be FLIPKART
        so = batch.created_sales_orders.first()
        self.assertEqual(so.portal_source, "FLIPKART")

    def test_flipkart_unknown_fsn_logs_warning_not_fatal(self):
        """Unknown FSN in Flipkart → error logged but SO still created."""
        from apps.edi.services import process_flipkart_excel

        today = date.today().strftime("%d-%m-%Y")
        rows = [
            {"Order ID": "FK-GOOD-001", "Order Date": today, "FSN": "BOX-001",
             "Qty": 1, "Customer Name": "Good Buyer", "Product Title": "Good Box"},
            {"Order ID": "FK-BAD-001", "Order Date": today, "FSN": "NO-SUCH-FSN",
             "Qty": 2, "Customer Name": "Bad Buyer", "Product Title": "Bad Box"},
        ]
        xlsx_bytes = _make_flipkart_excel(rows)
        batch = _create_edi_batch("FLIPKART", xlsx_bytes)

        process_flipkart_excel(batch.pk)

        batch.refresh_from_db()
        self.assertEqual(batch.success_rows, 2)  # Both SOs created
        bad_errors = [e for e in batch.error_log if "NO-SUCH-FSN" in e.get("error", "")]
        self.assertEqual(len(bad_errors), 1)

    def test_flipkart_product_title_used_as_line_description(self):
        """When FSN matches an item, Product Title used as line description."""
        from apps.edi.services import process_flipkart_excel

        rows = [{"Order ID": "FK-DESC-001", "Order Date": date.today().strftime("%d-%m-%Y"),
                 "Product Title": "Premium Box Large 30x30cm", "FSN": "BOX-001",
                 "Qty": 5, "Customer Name": "Title Buyer"}]
        xlsx_bytes = _make_flipkart_excel(rows)
        batch = _create_edi_batch("FLIPKART", xlsx_bytes)
        process_flipkart_excel(batch.pk)

        batch.refresh_from_db()
        so = batch.created_sales_orders.first()
        line = so.lines.first()
        self.assertIn("Premium Box Large", line.description)


# ─── Celery Task Tests ────────────────────────────────────────────────────────

@override_settings(CELERY_TASK_ALWAYS_EAGER=True, CELERY_TASK_EAGER_PROPAGATES=True)
class ProcessEDIBatchTaskTest(TestCase):
    """Test the Celery task dispatcher (synchronous execution)."""

    def setUp(self):
        self.ctx = _make_base_context()

    def test_task_dispatches_amazon(self):
        """process_edi_batch task with AMAZON platform calls process_amazon_excel."""
        from apps.edi.tasks import process_edi_batch

        today = date.today().strftime("%d-%m-%Y")
        rows = [{"Order ID": "AMZ-TASK-001", "Order Date": today,
                 "Customer Name": "Task Tester", "SKU": "BOX-001", "Qty": 3}]
        xlsx_bytes = _make_amazon_excel(rows)
        batch = _create_edi_batch("AMAZON", xlsx_bytes, user=self.ctx["system_user"])

        # Run synchronously
        result = process_edi_batch(batch.pk)

        batch.refresh_from_db()
        self.assertEqual(batch.status, "COMPLETED")
        self.assertEqual(batch.success_rows, 1)

    def test_task_dispatches_flipkart(self):
        """process_edi_batch task with FLIPKART platform calls process_flipkart_excel."""
        from apps.edi.tasks import process_edi_batch

        today = date.today().strftime("%d-%m-%Y")
        rows = [{"Order ID": "FK-TASK-001", "Order Date": today,
                 "Customer Name": "FK Task Tester", "FSN": "BOX-002",
                 "Qty": 7, "Product Title": "Box"}]
        xlsx_bytes = _make_flipkart_excel(rows)
        batch = _create_edi_batch("FLIPKART", xlsx_bytes)

        result = process_edi_batch(batch.pk)

        batch.refresh_from_db()
        self.assertEqual(batch.status, "COMPLETED")
        self.assertEqual(batch.success_rows, 1)

    def test_task_handles_missing_batch_gracefully(self):
        """Task should not crash if batch ID doesn't exist."""
        from apps.edi.tasks import process_edi_batch
        result = process_edi_batch(999999)
        self.assertIn("error", result)


# ─── API Upload Tests ─────────────────────────────────────────────────────────

@override_settings(
    CELERY_TASK_ALWAYS_EAGER=True,
    CELERY_TASK_EAGER_PROPAGATES=True,
    MEDIA_ROOT='/tmp/edi_test_media/',
)
class EDIUploadAPITest(APITestCase):
    """Tests for POST /api/v1/edi/upload/ and GET /api/v1/edi/batches/."""

    def setUp(self):
        self.ctx = _make_base_context()
        self.client.force_authenticate(user=self.ctx["system_user"])

    def _xlsx_upload_file(self, rows, platform="AMAZON"):
        if platform == "FLIPKART":
            data = _make_flipkart_excel(rows)
        else:
            data = _make_amazon_excel(rows)
        return SimpleUploadedFile(
            f"test_{platform.lower()}.xlsx",
            data,
            content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )

    def test_upload_creates_batch(self):
        """POST /api/v1/edi/upload/ creates an EDIUploadBatch record."""
        from apps.edi.models import EDIUploadBatch

        today = date.today().strftime("%d-%m-%Y")
        rows = [{"Order ID": "AMZ-API-001", "Order Date": today,
                 "Customer Name": "API Test", "SKU": "BOX-001", "Qty": 1}]
        f = self._xlsx_upload_file(rows)

        response = self.client.post(
            "/api/v1/edi/upload/",
            data={"platform": "AMAZON", "file": f},
            format="multipart",
        )

        self.assertEqual(response.status_code, 202)
        self.assertIn("batch_id", response.data)
        self.assertEqual(response.data["platform"], "AMAZON")

        batch_id = response.data["batch_id"]
        batch = EDIUploadBatch.objects.get(pk=batch_id)
        self.assertIsNotNone(batch)

    def test_upload_with_eager_task_creates_sales_orders(self):
        """With CELERY_TASK_ALWAYS_EAGER, upload triggers processing immediately."""
        today = date.today().strftime("%d-%m-%Y")
        rows = [
            {"Order ID": f"AMZ-EAGER-{i:03d}", "Order Date": today,
             "Customer Name": f"Eager Buyer {i}", "SKU": "BOX-001", "Qty": i}
            for i in range(1, 4)
        ]
        f = self._xlsx_upload_file(rows)

        response = self.client.post(
            "/api/v1/edi/upload/",
            data={"platform": "AMAZON", "file": f},
            format="multipart",
        )
        self.assertEqual(response.status_code, 202)

        # With eager execution, batch should already be COMPLETED
        from apps.edi.models import EDIUploadBatch
        batch = EDIUploadBatch.objects.get(pk=response.data["batch_id"])
        batch.refresh_from_db()
        self.assertEqual(batch.status, "COMPLETED")
        self.assertEqual(batch.success_rows, 3)

    def test_upload_invalid_platform_returns_400(self):
        """Unknown platform must return 400."""
        f = self._xlsx_upload_file([])
        response = self.client.post(
            "/api/v1/edi/upload/",
            data={"platform": "TIKTOK", "file": f},
            format="multipart",
        )
        self.assertEqual(response.status_code, 400)

    def test_upload_no_file_returns_400(self):
        """Missing file must return 400."""
        response = self.client.post(
            "/api/v1/edi/upload/",
            data={"platform": "AMAZON"},
            format="multipart",
        )
        self.assertEqual(response.status_code, 400)

    def test_list_batches_endpoint(self):
        """GET /api/v1/edi/batches/ returns list of batches."""
        today = date.today().strftime("%d-%m-%Y")
        rows = [{"Order ID": "AMZ-LIST-001", "Order Date": today,
                 "Customer Name": "List Test", "SKU": "BOX-001", "Qty": 1}]
        f = self._xlsx_upload_file(rows)
        self.client.post("/api/v1/edi/upload/", data={"platform": "AMAZON", "file": f}, format="multipart")

        response = self.client.get("/api/v1/edi/batches/")
        self.assertEqual(response.status_code, 200)
        self.assertIsInstance(response.data, list)
        self.assertGreaterEqual(len(response.data), 1)

    def test_batch_detail_endpoint_includes_error_log(self):
        """GET /api/v1/edi/batches/{id}/ includes error_log field."""
        today = date.today().strftime("%d-%m-%Y")
        rows = [{"Order ID": "AMZ-DET-001", "Order Date": today,
                 "Customer Name": "Detail Test", "SKU": "UNKNOWN-SKU-XYZ", "Qty": 1}]
        f = self._xlsx_upload_file(rows)
        upload_response = self.client.post(
            "/api/v1/edi/upload/",
            data={"platform": "AMAZON", "file": f},
            format="multipart",
        )
        batch_id = upload_response.data["batch_id"]

        detail_response = self.client.get(f"/api/v1/edi/batches/{batch_id}/")
        self.assertEqual(detail_response.status_code, 200)
        self.assertIn("error_log", detail_response.data)

    def test_error_report_endpoint_returns_xlsx(self):
        """GET /api/v1/edi/batches/{id}/error-report/ returns Excel content-type."""
        today = date.today().strftime("%d-%m-%Y")
        rows = [{"Order ID": "AMZ-ERR-001", "Order Date": today,
                 "Customer Name": "Error Report Test", "SKU": "BAAD-SKU-999", "Qty": 1}]
        f = self._xlsx_upload_file(rows)
        upload_response = self.client.post(
            "/api/v1/edi/upload/",
            data={"platform": "AMAZON", "file": f},
            format="multipart",
        )
        batch_id = upload_response.data["batch_id"]

        report_response = self.client.get(f"/api/v1/edi/batches/{batch_id}/error-report/")
        self.assertEqual(report_response.status_code, 200)
        self.assertIn(
            "spreadsheetml",
            report_response.get("Content-Type", ""),
        )
        self.assertIn(
            "attachment",
            report_response.get("Content-Disposition", ""),
        )


# ─── Error Report Tests ────────────────────────────────────────────────────────

@override_settings(CELERY_TASK_ALWAYS_EAGER=True, CELERY_TASK_EAGER_PROPAGATES=True)
class ErrorReportTest(TestCase):
    """Tests for get_error_report_excel service."""

    def setUp(self):
        self.ctx = _make_base_context()

    def test_error_report_is_valid_xlsx(self):
        """get_error_report_excel returns parseable xlsx with error rows."""
        import openpyxl
        from apps.edi.services import process_amazon_excel, get_error_report_excel

        today = date.today().strftime("%d-%m-%Y")
        rows = [
            {"Order ID": "AMZ-RPT-001", "Order Date": today,
             "Customer Name": "Good Buyer", "SKU": "BOX-001", "Qty": 1},
            {"Order ID": "AMZ-RPT-002", "Order Date": today,
             "Customer Name": "Bad Buyer", "SKU": "NO-SUCH-ITEM-123", "Qty": 2},
        ]
        xlsx_bytes = _make_amazon_excel(rows)
        batch = _create_edi_batch("AMAZON", xlsx_bytes)
        process_amazon_excel(batch.pk)

        report_bytes = get_error_report_excel(batch.pk)
        self.assertIsInstance(report_bytes, bytes)
        self.assertGreater(len(report_bytes), 0)

        # Parse the returned xlsx
        wb = openpyxl.load_workbook(io.BytesIO(report_bytes))
        ws = wb.active
        # Row 1 is header; row 2+ are error entries
        headers = [ws.cell(1, c).value for c in range(1, 3)]
        self.assertIn("Row #", headers)
        self.assertIn("Error Description", headers)

        # Should have at least 1 error row (the unknown SKU)
        data_rows = [ws.cell(r, 2).value for r in range(2, ws.max_row + 1) if ws.cell(r, 2).value]
        self.assertGreater(len(data_rows), 0)
