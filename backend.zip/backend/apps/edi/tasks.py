"""
EDI Celery Tasks — Task 21
"""
from celery import shared_task
import logging

logger = logging.getLogger(__name__)


@shared_task(name="apps.edi.tasks.process_edi_batch", bind=True, max_retries=2)
def process_edi_batch(self, batch_id: int):
    """
    Process an uploaded EDI batch file.
    Reads the uploaded Excel and delegates to the appropriate platform handler.
    """
    from apps.edi.models import EDIUploadBatch
    from apps.edi.services import process_amazon_excel, process_flipkart_excel

    try:
        batch = EDIUploadBatch.objects.get(pk=batch_id)
    except EDIUploadBatch.DoesNotExist:
        logger.error("EDI batch %s not found", batch_id)
        return {"error": "Batch not found"}

    try:
        if batch.platform == EDIUploadBatch.Platform.AMAZON:
            result = process_amazon_excel(batch_id)
        elif batch.platform == EDIUploadBatch.Platform.FLIPKART:
            result = process_flipkart_excel(batch_id)
        else:
            # MANUAL / CSV — treat as Amazon column format for now
            result = process_amazon_excel(batch_id)

        logger.info("EDI batch %s completed: %s", batch_id, result)
        return result

    except Exception as exc:
        logger.exception("EDI batch %s task failed", batch_id)
        # Mark batch as FAILED if not already
        try:
            batch.refresh_from_db()
            if batch.status not in ("COMPLETED", "FAILED"):
                batch.status = "FAILED"
                batch.error_log = [{"row": 0, "error": f"Task error: {exc}"}]
                batch.save(update_fields=["status", "error_log"])
        except Exception:
            pass
        raise self.retry(exc=exc, countdown=30)
