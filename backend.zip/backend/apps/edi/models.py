from django.conf import settings
"""
EDI Integration Models — Task 21
Handles Amazon / Flipkart / Manual CSV order uploads.
"""
from django.db import models
from apps.core.models import UUIDModel, TimeStampedModel


class EDIUploadBatch(UUIDModel, TimeStampedModel):
    """
    One batch per file upload. Tracks processing state,
    row counts, errors, and created SalesOrders.
    """

    class Platform(models.TextChoices):
        AMAZON   = "AMAZON",   "Amazon"
        FLIPKART = "FLIPKART", "Flipkart"
        MANUAL   = "MANUAL",   "Manual CSV"

    class Status(models.TextChoices):
        PENDING    = "PENDING",    "Pending"
        PROCESSING = "PROCESSING", "Processing"
        COMPLETED  = "COMPLETED",  "Completed"
        FAILED     = "FAILED",     "Failed"

    platform      = models.CharField(max_length=20, choices=Platform.choices)
    uploaded_file = models.FileField(upload_to="edi_uploads/")
    status        = models.CharField(
        max_length=20, choices=Status.choices, default=Status.PENDING
    )
    total_rows   = models.PositiveIntegerField(default=0)
    success_rows = models.PositiveIntegerField(default=0)
    failed_rows  = models.PositiveIntegerField(default=0)

    # [{row: N, error: 'message'}]
    error_log = models.JSONField(default=list)

    # SalesOrders created from this batch
    created_sales_orders = models.ManyToManyField(
        "sales.SalesOrder",
        blank=True,
        related_name="edi_batches",
    )

    uploaded_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name="edi_batches",
    )

    class Meta:
        ordering = ["-created_at"]
        verbose_name = "EDI Upload Batch"
        verbose_name_plural = "EDI Upload Batches"

    def __str__(self):
        return f"{self.platform} batch — {self.created_at:%Y-%m-%d} ({self.status})"

    @property
    def success_rate(self):
        if not self.total_rows:
            return 0
        return round((self.success_rows / self.total_rows) * 100, 1)

