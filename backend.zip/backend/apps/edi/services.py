"""
EDI Services — Task 21
process_amazon_excel(batch_id)   — maps Amazon MFN report columns → SalesOrder
process_flipkart_excel(batch_id) — maps Flipkart order dump columns → SalesOrder
get_error_report_excel(batch_id) — generate downloadable error report
"""
from __future__ import annotations

import io
import logging
from datetime import date
from decimal import Decimal, InvalidOperation

from django.db import transaction

logger = logging.getLogger(__name__)


# ─── Helpers ─────────────────────────────────────────────────────────────────

def _get_batch(batch_id):
    from apps.edi.models import EDIUploadBatch
    return EDIUploadBatch.objects.get(pk=batch_id)


def _parse_date(value) -> date | None:
    """Try common date formats: DD-MM-YYYY, YYYY-MM-DD, MM/DD/YYYY."""
    if not value:
        return None
    if isinstance(value, date):
        return value
    s = str(value).strip()
    for fmt in ("%d-%m-%Y", "%Y-%m-%d", "%m/%d/%Y", "%d/%m/%Y", "%Y%m%d"):
        try:
            from datetime import datetime
            return datetime.strptime(s, fmt).date()
        except ValueError:
            continue
    return None


def _find_or_create_customer(name: str, city: str = "", state: str = "",
                              pincode: str = "", source_tag: str = "AMAZON"):
    """
    Look up customer by name (case-insensitive). If not found, create one with
    customer_type=E_COMMERCE and a generated code.
    """
    from apps.masters.models import Customer, CustomerGroup
    from django.utils.text import slugify

    # Try exact or iexact match
    customer = Customer.objects.filter(name__iexact=name.strip()).first()
    if customer:
        return customer

    # Need to create — get/create an E-Commerce customer group
    cgroup, _ = CustomerGroup.objects.get_or_create(
        code="ECOM",
        defaults={"name": "E-Commerce"},
    )

    # Generate a unique code: first 12 chars of slugified name
    base_code = slugify(name)[:12].upper() or "ECOM"
    code = base_code
    suffix = 1
    while Customer.objects.filter(code=code).exists():
        code = f"{base_code[:10]}{suffix:02d}"
        suffix += 1

    # Assign default plant so EDI customers are not orphaned (BUG-032)
    default_plant = _get_default_plant()

    customer = Customer.objects.create(
        code=code,
        name=name.strip(),
        customer_type=Customer.CustomerType.E_COMMERCE,
        customer_group=cgroup,
        city=city,
        state=state,
        pincode=pincode,
        plant=default_plant,
        notes=f"Auto-created from {source_tag} EDI import",
    )
    return customer


def _find_item_by_sku(sku: str):
    """Look up Item by code (exact, case-insensitive)."""
    from apps.masters.models import Item
    if not sku:
        return None
    return Item.objects.filter(code__iexact=sku.strip()).first()


def _get_default_plant():
    """Return first active plant as fallback."""
    from apps.core.models import Plant
    return Plant.objects.filter(is_active=True).order_by("code").first()


def _get_system_user():
    from django.contrib.auth import get_user_model
    User = get_user_model()
    return (
        User.objects.filter(username="system").first()
        or User.objects.filter(is_superuser=True).order_by("pk").first()
    )


def _get_default_uom():
    from apps.masters.models import UOM
    return UOM.objects.filter(code__iexact="PCS").first() or UOM.objects.order_by("pk").first()


def _next_so_number(plant):
    from apps.purchase.services import get_next_doc_number
    return get_next_doc_number(plant, "SO", "SO")


def _create_sales_order(plant, customer, order_ref: str, order_date: date,
                        delivery_date: date | None, remarks: str,
                        system_user, source_tag: str) -> "SalesOrder":
    from apps.sales.models import SalesOrder
    so_number = _next_so_number(plant)
    return SalesOrder.objects.create(
        plant=plant,
        so_number=so_number,
        so_date=order_date or date.today(),
        so_type=SalesOrder.SOType.REGULAR,
        status=SalesOrder.SOStatus.DRAFT,
        customer=customer,
        customer_po_number=order_ref,
        required_delivery_date=delivery_date,
        currency="INR",
        subtotal=Decimal("0"),
        discount_amount=Decimal("0"),
        taxable_amount=Decimal("0"),
        cgst_amount=Decimal("0"),
        sgst_amount=Decimal("0"),
        igst_amount=Decimal("0"),
        total_amount=Decimal("0"),
        portal_source=source_tag,
        remarks=remarks,
        created_by=system_user,
    )


def _create_so_line(so, line_no: int, item, description: str, qty: Decimal, uom):
    from apps.sales.models import SOLine
    return SOLine.objects.create(
        so=so,
        line_no=line_no,
        item=item,
        description=description or (item.name if item else "EDI Import"),
        ordered_qty=qty,
        uom=uom or (item.uom if item else None),
        unit_rate=Decimal("0"),
        discount_pct=Decimal("0"),
        taxable_amt=Decimal("0"),
        gst_pct=Decimal("18"),
        cgst_pct=Decimal("9"),
        sgst_pct=Decimal("9"),
        igst_pct=Decimal("0"),
        gst_amount=Decimal("0"),
        line_total=Decimal("0"),
    )


def _cell(row_dict: dict, *keys) -> str:
    """Try multiple column name variants, return stripped string or ''."""
    for k in keys:
        v = row_dict.get(k)
        if v is not None and str(v).strip() not in ("", "nan", "None"):
            return str(v).strip()
    return ""


# ─── Amazon Processing ────────────────────────────────────────────────────────

AMAZON_COLUMNS = {
    "order_id":      ("Order ID", "order-id", "AmazonOrderId"),
    "order_date":    ("Order Date", "purchase-date"),
    "customer_name": ("Customer Name", "BuyerName", "recipient-name"),
    "sku":           ("SKU", "sku", "seller-sku"),
    "asin":          ("ASIN", "asin"),
    "qty":           ("Qty", "quantity", "quantity-purchased"),
    "ship_by":       ("Ship-by Date", "latest-ship-date"),
    "address":       ("Ship Address", "ship-address-1"),
    "city":          ("City", "ship-city"),
    "state":         ("State", "ship-state"),
    "pincode":       ("Pincode", "ship-postal-code"),
}


def process_amazon_excel(batch_id: int) -> dict:
    """
    Process an Amazon MFN / FBM order report Excel file.
    Expects columns (flexible mapping):
      Order ID | Order Date | Customer Name | ASIN | SKU | Qty |
      Ship-by Date | Ship Address | City | State | Pincode
    """
    import openpyxl

    batch = _get_batch(batch_id)
    batch.status = "PROCESSING"
    batch.save(update_fields=["status"])

    plant      = _get_default_plant()
    system_user = _get_system_user()
    default_uom = _get_default_uom()

    errors: list[dict] = []
    created_sos: list = []
    total_rows = 0

    try:
        wb = openpyxl.load_workbook(batch.uploaded_file, read_only=True, data_only=True)
        ws = wb.active

        rows = list(ws.iter_rows(values_only=True))
        if not rows:
            batch.status = "FAILED"
            batch.error_log = [{"row": 0, "error": "Empty file"}]
            batch.save()
            return {"prs_created": 0}

        # First row = headers
        headers = [str(h).strip() if h is not None else "" for h in rows[0]]

        def col(row_vals, *keys):
            row_dict = dict(zip(headers, row_vals))
            return _cell(row_dict, *keys)

        data_rows = rows[1:]
        total_rows = len(data_rows)

        for idx, row_vals in enumerate(data_rows, start=2):  # 2 = Excel row (1=header)
            row_dict = dict(zip(headers, row_vals))
            try:
                order_id  = _cell(row_dict, *AMAZON_COLUMNS["order_id"])
                order_date = _parse_date(_cell(row_dict, *AMAZON_COLUMNS["order_date"]))
                cust_name  = _cell(row_dict, *AMAZON_COLUMNS["customer_name"]) or f"Amazon Customer {order_id}"
                sku        = _cell(row_dict, *AMAZON_COLUMNS["sku"])
                qty_raw    = _cell(row_dict, *AMAZON_COLUMNS["qty"])
                ship_by    = _parse_date(_cell(row_dict, *AMAZON_COLUMNS["ship_by"]))
                city       = _cell(row_dict, *AMAZON_COLUMNS["city"])
                state      = _cell(row_dict, *AMAZON_COLUMNS["state"])
                pincode    = _cell(row_dict, *AMAZON_COLUMNS["pincode"])

                if not order_id:
                    errors.append({"row": idx, "error": "Missing Order ID — row skipped"})
                    continue

                try:
                    qty = Decimal(str(qty_raw)) if qty_raw else Decimal("1")
                except InvalidOperation:
                    qty = Decimal("1")

                item = _find_item_by_sku(sku)
                if not item and sku:
                    errors.append({
                        "row": idx,
                        "error": f"SKU '{sku}' not found in Item master — order created without item link",
                    })

                with transaction.atomic():
                    customer = _find_or_create_customer(
                        cust_name, city=city, state=state,
                        pincode=pincode, source_tag="AMAZON"
                    )
                    so = _create_sales_order(
                        plant=plant,
                        customer=customer,
                        order_ref=order_id,
                        order_date=order_date or date.today(),
                        delivery_date=ship_by,
                        remarks=f"Amazon EDI import — Order {order_id}",
                        system_user=system_user,
                        source_tag="AMAZON",
                    )
                    _create_so_line(
                        so=so,
                        line_no=1,
                        item=item,
                        description=sku or "Amazon Order Item",
                        qty=qty,
                        uom=default_uom,
                    )
                    created_sos.append(so)

            except Exception as exc:
                logger.exception("Amazon EDI row %s error", idx)
                errors.append({"row": idx, "error": str(exc)})

        # Attach created SOs to batch
        batch.created_sales_orders.set(created_sos)

    except Exception as exc:
        logger.exception("Amazon EDI batch %s fatal error", batch_id)
        batch.status = "FAILED"
        batch.error_log = [{"row": 0, "error": f"Fatal: {exc}"}]
        batch.total_rows = total_rows
        batch.success_rows = 0
        batch.failed_rows = total_rows
        batch.save()
        return {"error": str(exc)}

    success = len(created_sos)
    failed  = errors.__len__() - sum(1 for e in errors if "not found in Item master" in e["error"])
    # Rows with unknown SKU are still successes (SO created); purely fatal rows count as failures
    actual_failed = total_rows - success

    batch.total_rows   = total_rows
    batch.success_rows = success
    batch.failed_rows  = actual_failed
    batch.error_log    = errors
    batch.status       = "COMPLETED"
    batch.save()

    return {"success_rows": success, "failed_rows": actual_failed, "total_rows": total_rows}


# ─── Flipkart Processing ──────────────────────────────────────────────────────

FLIPKART_COLUMNS = {
    "order_id":      ("Order ID", "order_id", "fsn_order_id"),
    "order_date":    ("Order Date", "order_date"),
    "product_title": ("Product Title", "product_title", "product_name"),
    "fsn":           ("FSN", "fsn", "flipkart_serial_number"),
    "qty":           ("Qty", "quantity", "qty"),
    "customer_name": ("Customer Name", "customer_name", "buyer_name"),
    "address":       ("Ship To", "ship_to", "shipping_address"),
    "city":          ("City", "city"),
    "state":         ("State", "state"),
    "pincode":       ("Pin", "pin", "pincode", "pin_code"),
}


def process_flipkart_excel(batch_id: int) -> dict:
    """
    Process a Flipkart order dump Excel file.
    Expects columns (flexible mapping):
      Order ID | Order Date | Product Title | FSN | Qty |
      Customer Name | Ship To | City | State | Pin
    """
    import openpyxl

    batch = _get_batch(batch_id)
    batch.status = "PROCESSING"
    batch.save(update_fields=["status"])

    plant       = _get_default_plant()
    system_user = _get_system_user()
    default_uom = _get_default_uom()

    errors: list[dict] = []
    created_sos: list = []
    total_rows = 0

    try:
        wb = openpyxl.load_workbook(batch.uploaded_file, read_only=True, data_only=True)
        ws = wb.active

        rows = list(ws.iter_rows(values_only=True))
        if not rows:
            batch.status = "FAILED"
            batch.error_log = [{"row": 0, "error": "Empty file"}]
            batch.save()
            return {"error": "Empty file"}

        headers = [str(h).strip() if h is not None else "" for h in rows[0]]
        data_rows = rows[1:]
        total_rows = len(data_rows)

        for idx, row_vals in enumerate(data_rows, start=2):
            row_dict = dict(zip(headers, row_vals))
            try:
                order_id      = _cell(row_dict, *FLIPKART_COLUMNS["order_id"])
                order_date    = _parse_date(_cell(row_dict, *FLIPKART_COLUMNS["order_date"]))
                product_title = _cell(row_dict, *FLIPKART_COLUMNS["product_title"])
                fsn           = _cell(row_dict, *FLIPKART_COLUMNS["fsn"])
                qty_raw       = _cell(row_dict, *FLIPKART_COLUMNS["qty"])
                cust_name     = _cell(row_dict, *FLIPKART_COLUMNS["customer_name"]) or f"Flipkart Customer {order_id}"
                city          = _cell(row_dict, *FLIPKART_COLUMNS["city"])
                state         = _cell(row_dict, *FLIPKART_COLUMNS["state"])
                pincode       = _cell(row_dict, *FLIPKART_COLUMNS["pincode"])

                if not order_id:
                    errors.append({"row": idx, "error": "Missing Order ID — row skipped"})
                    continue

                try:
                    qty = Decimal(str(qty_raw)) if qty_raw else Decimal("1")
                except InvalidOperation:
                    qty = Decimal("1")

                # FSN maps to Item.code
                item = _find_item_by_sku(fsn)
                if not item and fsn:
                    errors.append({
                        "row": idx,
                        "error": f"FSN '{fsn}' not found in Item master — order created without item link",
                    })

                with transaction.atomic():
                    customer = _find_or_create_customer(
                        cust_name, city=city, state=state,
                        pincode=pincode, source_tag="FLIPKART"
                    )
                    so = _create_sales_order(
                        plant=plant,
                        customer=customer,
                        order_ref=order_id,
                        order_date=order_date or date.today(),
                        delivery_date=None,
                        remarks=f"Flipkart EDI import — Order {order_id}",
                        system_user=system_user,
                        source_tag="FLIPKART",
                    )
                    _create_so_line(
                        so=so,
                        line_no=1,
                        item=item,
                        description=product_title or fsn or "Flipkart Order Item",
                        qty=qty,
                        uom=default_uom,
                    )
                    created_sos.append(so)

            except Exception as exc:
                logger.exception("Flipkart EDI row %s error", idx)
                errors.append({"row": idx, "error": str(exc)})

        batch.created_sales_orders.set(created_sos)

    except Exception as exc:
        logger.exception("Flipkart EDI batch %s fatal error", batch_id)
        batch.status = "FAILED"
        batch.error_log = [{"row": 0, "error": f"Fatal: {exc}"}]
        batch.total_rows = total_rows
        batch.success_rows = 0
        batch.failed_rows = total_rows
        batch.save()
        return {"error": str(exc)}

    success      = len(created_sos)
    actual_failed = total_rows - success

    batch.total_rows   = total_rows
    batch.success_rows = success
    batch.failed_rows  = actual_failed
    batch.error_log    = errors
    batch.status       = "COMPLETED"
    batch.save()

    return {"success_rows": success, "failed_rows": actual_failed, "total_rows": total_rows}


# ─── Error Report Excel ────────────────────────────────────────────────────────

def get_error_report_excel(batch_id: int) -> bytes:
    """
    Generate an in-memory Excel file listing all errors from an EDI batch.
    Returns raw bytes (xlsx).
    """
    import openpyxl
    from openpyxl.styles import Font, PatternFill, Alignment

    batch = _get_batch(batch_id)
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Error Report"

    # Header
    header_font = Font(bold=True, color="FFFFFF")
    header_fill = PatternFill("solid", fgColor="C0392B")

    headers = ["Row #", "Error Description"]
    for col_idx, h in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col_idx, value=h)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal="center")

    ws.column_dimensions["A"].width = 10
    ws.column_dimensions["B"].width = 80

    for row_idx, entry in enumerate(batch.error_log, start=2):
        ws.cell(row=row_idx, column=1, value=entry.get("row", ""))
        ws.cell(row=row_idx, column=2, value=entry.get("error", ""))

    # Summary row
    last_row = len(batch.error_log) + 3
    ws.cell(row=last_row, column=1, value="Summary")
    ws.cell(row=last_row, column=1).font = Font(bold=True)
    ws.cell(row=last_row, column=2,
            value=f"Total: {batch.total_rows} | Success: {batch.success_rows} | Failed: {batch.failed_rows}")

    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()
