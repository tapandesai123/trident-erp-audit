"""
EDI API Views — Task 21
POST /api/v1/edi/upload/        Upload Excel file for Amazon/Flipkart/Manual
GET  /api/v1/edi/batches/       List all upload batches
GET  /api/v1/edi/batches/{id}/  Batch detail with error_log
GET  /api/v1/edi/batches/{id}/error-report/  Download error report as Excel
"""
from django.http import HttpResponse
from rest_framework import generics, status
from rest_framework.decorators import api_view, permission_classes, parser_classes
from rest_framework.parsers import MultiPartParser, FormParser
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.edi.models import EDIUploadBatch


# ─── Serializers (inline, simple) ────────────────────────────────────────────

from rest_framework import serializers


class EDIBatchListSerializer(serializers.ModelSerializer):
    success_rate = serializers.ReadOnlyField()
    uploaded_by_username = serializers.CharField(
        source="uploaded_by.username", read_only=True, default=""
    )

    class Meta:
        model = EDIUploadBatch
        fields = [
            "id", "uuid", "platform", "status",
            "total_rows", "success_rows", "failed_rows", "success_rate",
            "uploaded_by_username", "created_at", "updated_at",
        ]


class EDIBatchDetailSerializer(serializers.ModelSerializer):
    success_rate = serializers.ReadOnlyField()
    created_so_count = serializers.SerializerMethodField()
    uploaded_by_username = serializers.CharField(
        source="uploaded_by.username", read_only=True, default=""
    )

    class Meta:
        model = EDIUploadBatch
        fields = [
            "id", "uuid", "platform", "status",
            "total_rows", "success_rows", "failed_rows", "success_rate",
            "error_log", "created_so_count",
            "uploaded_by_username", "created_at", "updated_at",
        ]

    def get_created_so_count(self, obj):
        return obj.created_sales_orders.count()


# ─── Views ────────────────────────────────────────────────────────────────────

class EDIUploadView(APIView):
    """
    POST /api/v1/edi/upload/
    Multipart: {platform: AMAZON|FLIPKART|MANUAL, file: <xlsx>}
    """
    permission_classes = [IsAuthenticated]
    parser_classes = [MultiPartParser, FormParser]

    def post(self, request):
        platform = request.data.get("platform", "").upper()
        if platform not in [c[0] for c in EDIUploadBatch.Platform.choices]:
            return Response(
                {"error": f"Invalid platform. Choose from: {[c[0] for c in EDIUploadBatch.Platform.choices]}"},
                status=status.HTTP_400_BAD_REQUEST,
            )

        uploaded_file = request.FILES.get("file")
        if not uploaded_file:
            return Response({"error": "No file uploaded"}, status=status.HTTP_400_BAD_REQUEST)

        # Validate file type
        fname = uploaded_file.name.lower()
        if not (fname.endswith(".xlsx") or fname.endswith(".xls") or fname.endswith(".csv")):
            return Response(
                {"error": "Only .xlsx, .xls or .csv files are accepted"},
                status=status.HTTP_400_BAD_REQUEST,
            )

        batch = EDIUploadBatch.objects.create(
            platform=platform,
            uploaded_file=uploaded_file,
            status=EDIUploadBatch.Status.PENDING,
            uploaded_by=request.user,
        )

        # Fire async task
        from apps.edi.tasks import process_edi_batch
        process_edi_batch.delay(batch.pk)

        return Response(
            {
                "batch_id": batch.pk,
                "uuid": str(batch.uuid),
                "status": "PROCESSING",
                "platform": platform,
            },
            status=status.HTTP_202_ACCEPTED,
        )


class EDIBatchListView(generics.ListAPIView):
    """GET /api/v1/edi/batches/"""
    permission_classes = [IsAuthenticated]
    serializer_class = EDIBatchListSerializer
    queryset = EDIUploadBatch.objects.select_related("uploaded_by").order_by("-created_at")


class EDIBatchDetailView(generics.RetrieveAPIView):
    """GET /api/v1/edi/batches/{id}/"""
    permission_classes = [IsAuthenticated]
    serializer_class = EDIBatchDetailSerializer
    queryset = EDIUploadBatch.objects.select_related("uploaded_by")
    lookup_field = "pk"


class EDIErrorReportView(APIView):
    """GET /api/v1/edi/batches/{id}/error-report/ — download Excel error report"""
    permission_classes = [IsAuthenticated]

    def get(self, request, pk):
        try:
            batch = EDIUploadBatch.objects.get(pk=pk)
        except EDIUploadBatch.DoesNotExist:
            return Response({"error": "Batch not found"}, status=status.HTTP_404_NOT_FOUND)

        from apps.edi.services import get_error_report_excel
        xlsx_bytes = get_error_report_excel(batch.pk)

        response = HttpResponse(
            xlsx_bytes,
            content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )
        response["Content-Disposition"] = (
            f'attachment; filename="edi_errors_{batch.platform}_{batch.pk}.xlsx"'
        )
        return response
