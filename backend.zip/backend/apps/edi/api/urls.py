"""EDI API URL configuration."""
from django.urls import path
from apps.edi.api.views import (
    EDIUploadView,
    EDIBatchListView,
    EDIBatchDetailView,
    EDIErrorReportView,
)

urlpatterns = [
    path("upload/",              EDIUploadView.as_view(),      name="edi-upload"),
    path("batches/",             EDIBatchListView.as_view(),   name="edi-batch-list"),
    path("batches/<int:pk>/",    EDIBatchDetailView.as_view(), name="edi-batch-detail"),
    path("batches/<int:pk>/error-report/", EDIErrorReportView.as_view(), name="edi-error-report"),
]
