"""Project & Job Costing admin registrations."""
from django.contrib import admin
from django.utils.html import format_html
from apps.projects.models import (
    Project, ProjectPhase, ProjectTask, ProjectResource,
    ProjectCostEntry, ProjectBudget, ProjectBudgetLine,
    ProjectInvoice, ProjectClosure,
)


# ─── Inlines ──────────────────────────────────────────────────────

class ProjectPhaseInline(admin.TabularInline):
    model = ProjectPhase
    extra = 0
    fields = [
        "phase_number", "name", "status",
        "planned_start", "planned_end", "completion_pct",
        "budget_amount", "cost_incurred",
    ]
    readonly_fields = ["cost_incurred"]
    ordering = ["phase_number"]


class ProjectResourceInline(admin.TabularInline):
    model = ProjectResource
    extra = 0
    fields = [
        "employee", "role", "allocation_pct",
        "start_date", "end_date", "hourly_cost_rate",
        "planned_hours", "actual_hours", "is_active",
    ]
    readonly_fields = ["actual_hours"]


class ProjectBudgetLineInline(admin.TabularInline):
    model = ProjectBudgetLine
    extra = 0
    fields = ["phase", "cost_type", "description", "quantity", "unit_cost", "amount"]


# ─── Project ──────────────────────────────────────────────────────

@admin.register(Project)
class ProjectAdmin(admin.ModelAdmin):
    list_display = [
        "project_number", "name", "project_type", "status",
        "plant", "customer",
        "approved_budget", "total_cost_incurred", "total_invoiced",
        "gross_margin_display", "planned_end",
    ]
    list_filter = ["status", "project_type", "plant"]
    search_fields = ["project_number", "name", "contract_number"]
    readonly_fields = [
        "uuid", "project_number", "created_at", "updated_at",
        "total_cost_incurred", "total_invoiced",
        "gross_margin", "gross_margin_pct", "budget_utilisation_pct",
    ]
    fieldsets = [
        ("Project Info", {
            "fields": [
                "plant", "project_number", "name", "description",
                "project_type", "status", "project_manager",
            ]
        }),
        ("Contract", {
            "fields": ["customer", "contract_number", "contract_value"]
        }),
        ("Timeline", {
            "fields": [
                "planned_start", "planned_end",
                "actual_start", "actual_end",
            ]
        }),
        ("Financials", {
            "fields": [
                "approved_budget", "total_cost_incurred", "total_invoiced",
                "gross_margin", "gross_margin_pct", "budget_utilisation_pct",
            ]
        }),
        ("Meta", {
            "fields": ["uuid", "notes", "created_by", "created_at", "updated_at"],
            "classes": ["collapse"],
        }),
    ]
    inlines = [ProjectPhaseInline, ProjectResourceInline]

    @admin.display(description="Gross Margin")
    def gross_margin_display(self, obj):
        gm = obj.gross_margin
        color = "green" if gm >= 0 else "red"
        return format_html('<span style="color:{}">₹{:,.0f}</span>', color, gm)


# ─── ProjectPhase ─────────────────────────────────────────────────

@admin.register(ProjectPhase)
class ProjectPhaseAdmin(admin.ModelAdmin):
    list_display = [
        "project", "phase_number", "name", "status",
        "planned_start", "planned_end", "completion_pct",
        "budget_amount", "cost_incurred",
    ]
    list_filter = ["status", "project__plant"]
    search_fields = ["project__project_number", "name"]
    readonly_fields = ["uuid", "created_at", "updated_at"]


# ─── ProjectTask ──────────────────────────────────────────────────

@admin.register(ProjectTask)
class ProjectTaskAdmin(admin.ModelAdmin):
    list_display = [
        "project", "phase", "title", "status", "priority",
        "assigned_to", "planned_end", "completion_pct",
        "estimated_hours", "actual_hours",
    ]
    list_filter = ["status", "priority", "project__plant"]
    search_fields = ["title", "project__project_number"]
    readonly_fields = ["uuid", "created_at", "updated_at"]


# ─── ProjectResource ──────────────────────────────────────────────

@admin.register(ProjectResource)
class ProjectResourceAdmin(admin.ModelAdmin):
    list_display = [
        "project", "employee", "role", "allocation_pct",
        "start_date", "end_date",
        "planned_hours", "actual_hours", "is_active",
    ]
    list_filter = ["role", "is_active", "project__plant"]
    search_fields = ["project__project_number", "employee__first_name", "employee__last_name"]
    readonly_fields = ["uuid", "created_at", "updated_at"]


# ─── ProjectCostEntry ─────────────────────────────────────────────

@admin.register(ProjectCostEntry)
class ProjectCostEntryAdmin(admin.ModelAdmin):
    list_display = [
        "entry_number", "project", "phase",
        "cost_type", "cost_date", "description",
        "amount", "status",
    ]
    list_filter = ["status", "cost_type", "project__plant"]
    search_fields = ["entry_number", "project__project_number", "description"]
    readonly_fields = [
        "uuid", "entry_number", "created_at", "updated_at",
        "approved_by", "approved_at", "posted_by",
    ]


# ─── ProjectBudget ────────────────────────────────────────────────

@admin.register(ProjectBudget)
class ProjectBudgetAdmin(admin.ModelAdmin):
    list_display = [
        "budget_number", "project", "version",
        "title", "status", "total_amount",
        "approved_by", "approved_at",
    ]
    list_filter = ["status", "project__plant"]
    search_fields = ["budget_number", "project__project_number", "title"]
    readonly_fields = [
        "uuid", "budget_number", "created_at", "updated_at",
        "approved_by", "approved_at",
    ]
    inlines = [ProjectBudgetLineInline]


# ─── ProjectInvoice ───────────────────────────────────────────────

@admin.register(ProjectInvoice)
class ProjectInvoiceAdmin(admin.ModelAdmin):
    list_display = [
        "invoice_number", "project", "invoice_type",
        "invoice_date", "total_amount", "amount_received",
        "amount_outstanding_display", "status",
    ]
    list_filter = ["status", "invoice_type", "project__plant"]
    search_fields = ["invoice_number", "project__project_number"]
    readonly_fields = [
        "uuid", "invoice_number", "created_at", "updated_at",
        "approved_by", "approved_at", "amount_outstanding",
    ]

    @admin.display(description="Outstanding")
    def amount_outstanding_display(self, obj):
        outstanding = obj.amount_outstanding
        color = "red" if outstanding > 0 else "green"
        return format_html('<span style="color:{}">₹{:,.0f}</span>', color, outstanding)


# ─── ProjectClosure ───────────────────────────────────────────────

@admin.register(ProjectClosure)
class ProjectClosureAdmin(admin.ModelAdmin):
    list_display = [
        "project", "closure_date", "closure_reason",
        "total_revenue", "total_cost", "gross_profit",
        "gross_margin_pct", "budget_variance",
        "client_sign_off",
    ]
    list_filter = ["closure_reason", "client_sign_off"]
    search_fields = ["project__project_number"]
    readonly_fields = ["uuid", "created_at", "updated_at"]
