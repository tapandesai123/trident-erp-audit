"""Project & Job Costing API Viewsets."""
from decimal import Decimal
from datetime import date as date_type

from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated

from apps.projects.models import (
    Project, ProjectPhase, ProjectTask, ProjectResource,
    ProjectCostEntry, ProjectBudget, ProjectBudgetLine,
    ProjectInvoice, ProjectClosure,
)
from apps.projects.api.serializers import (
    ProjectListSerializer, ProjectDetailSerializer, ProjectCreateSerializer,
    ProjectPhaseListSerializer, ProjectPhaseDetailSerializer, ProjectPhaseCreateSerializer,
    ProjectTaskListSerializer, ProjectTaskDetailSerializer, ProjectTaskCreateSerializer,
    ProjectResourceListSerializer, ProjectResourceDetailSerializer, ProjectResourceCreateSerializer,
    ProjectCostEntryListSerializer, ProjectCostEntryDetailSerializer, ProjectCostEntryCreateSerializer,
    ProjectBudgetListSerializer, ProjectBudgetDetailSerializer, ProjectBudgetCreateSerializer,
    ProjectInvoiceListSerializer, ProjectInvoiceDetailSerializer, ProjectInvoiceCreateSerializer,
    ProjectClosureListSerializer, ProjectClosureDetailSerializer, ProjectClosureCreateSerializer,
)
from apps.projects import services


# ─── Project ──────────────────────────────────────────────────────

class ProjectViewSet(viewsets.ModelViewSet):
    queryset = Project.objects.select_related(
        "plant", "customer", "project_manager"
    ).prefetch_related("phases")
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return ProjectListSerializer
        if self.action in ("create", "update", "partial_update"):
            return ProjectCreateSerializer
        return ProjectDetailSerializer

    def get_queryset(self):
        qs = super().get_queryset()
        plant = self.request.query_params.get("plant")
        proj_status = self.request.query_params.get("status")
        customer = self.request.query_params.get("customer")
        project_type = self.request.query_params.get("project_type")
        if plant:
            qs = qs.filter(plant=plant)
        if proj_status:
            qs = qs.filter(status=proj_status)
        if customer:
            qs = qs.filter(customer=customer)
        if project_type:
            qs = qs.filter(project_type=project_type)
        return qs

    def create(self, request, *args, **kwargs):
        from apps.core.models import Plant
        try:
            plant = Plant.objects.get(pk=request.data["plant"])
            project_manager = None
            if request.data.get("project_manager"):
                from django.contrib.auth import get_user_model
                project_manager = get_user_model().objects.filter(
                    pk=request.data["project_manager"]
                ).first()

            customer = None
            if request.data.get("customer"):
                from apps.masters.models import Customer
                customer = Customer.objects.filter(pk=request.data["customer"]).first()

            project = services.create_project(
                plant=plant,
                name=request.data["name"],
                project_type=request.data.get("project_type", "EXTERNAL"),
                description=request.data.get("description", ""),
                customer=customer,
                contract_number=request.data.get("contract_number", ""),
                contract_value=Decimal(str(request.data.get("contract_value", "0"))),
                planned_start=(
                    date_type.fromisoformat(request.data["planned_start"])
                    if request.data.get("planned_start") else None
                ),
                planned_end=(
                    date_type.fromisoformat(request.data["planned_end"])
                    if request.data.get("planned_end") else None
                ),
                project_manager=project_manager,
                notes=request.data.get("notes", ""),
                created_by=request.user,
            )
            return Response(
                ProjectDetailSerializer(project).data,
                status=status.HTTP_201_CREATED
            )
        except Exception as e:
            return Response({"detail": str(e)}, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=True, methods=["post"], url_path="activate")
    def activate(self, request, pk=None):
        """Set project status to ACTIVE."""
        project = self.get_object()
        if project.status not in ("DRAFT", "ON_HOLD"):
            return Response(
                {"detail": f"Cannot activate project in status '{project.status}'."},
                status=status.HTTP_400_BAD_REQUEST,
            )
        project.status = "ACTIVE"
        if not project.actual_start:
            project.actual_start = date_type.today()
        project.save(update_fields=["status", "actual_start"])
        return Response(ProjectDetailSerializer(project).data)

    @action(detail=True, methods=["post"], url_path="close")
    def close(self, request, pk=None):
        """Formally close a project."""
        project = self.get_object()
        try:
            closure = services.close_project(
                project=project,
                closure_date=date_type.fromisoformat(
                    request.data.get("closure_date", str(date_type.today()))
                ),
                closure_reason=request.data.get("closure_reason", "COMPLETED"),
                signed_off_by=request.user,
                client_sign_off=request.data.get("client_sign_off", False),
                client_sign_off_date=(
                    date_type.fromisoformat(request.data["client_sign_off_date"])
                    if request.data.get("client_sign_off_date") else None
                ),
                lessons_learned=request.data.get("lessons_learned", ""),
                notes=request.data.get("notes", ""),
            )
            return Response(ProjectClosureDetailSerializer(closure).data)
        except Exception as e:
            return Response({"detail": str(e)}, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=True, methods=["get"], url_path="profitability")
    def profitability(self, request, pk=None):
        """Return project profitability report."""
        project = self.get_object()
        data = services.get_project_profitability(project)
        return Response(data)


# ─── ProjectPhase ─────────────────────────────────────────────────

class ProjectPhaseViewSet(viewsets.ModelViewSet):
    queryset = ProjectPhase.objects.select_related("project")
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return ProjectPhaseListSerializer
        if self.action in ("create", "update", "partial_update"):
            return ProjectPhaseCreateSerializer
        return ProjectPhaseDetailSerializer

    def get_queryset(self):
        qs = super().get_queryset()
        project = self.request.query_params.get("project")
        if project:
            qs = qs.filter(project=project)
        return qs


# ─── ProjectTask ──────────────────────────────────────────────────

class ProjectTaskViewSet(viewsets.ModelViewSet):
    queryset = ProjectTask.objects.select_related("project", "phase", "assigned_to")
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return ProjectTaskListSerializer
        if self.action in ("create", "update", "partial_update"):
            return ProjectTaskCreateSerializer
        return ProjectTaskDetailSerializer

    def get_queryset(self):
        qs = super().get_queryset()
        project = self.request.query_params.get("project")
        phase = self.request.query_params.get("phase")
        task_status = self.request.query_params.get("status")
        assigned_to = self.request.query_params.get("assigned_to")
        if project:
            qs = qs.filter(project=project)
        if phase:
            qs = qs.filter(phase=phase)
        if task_status:
            qs = qs.filter(status=task_status)
        if assigned_to:
            qs = qs.filter(assigned_to=assigned_to)
        return qs


# ─── ProjectResource ──────────────────────────────────────────────

class ProjectResourceViewSet(viewsets.ModelViewSet):
    queryset = ProjectResource.objects.select_related("project", "employee", "phase")
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return ProjectResourceListSerializer
        if self.action in ("create", "update", "partial_update"):
            return ProjectResourceCreateSerializer
        return ProjectResourceDetailSerializer

    def get_queryset(self):
        qs = super().get_queryset()
        project = self.request.query_params.get("project")
        is_active = self.request.query_params.get("is_active")
        if project:
            qs = qs.filter(project=project)
        if is_active is not None:
            qs = qs.filter(is_active=is_active.lower() == "true")
        return qs

    def create(self, request, *args, **kwargs):
        try:
            project = Project.objects.get(pk=request.data["project"])
            from apps.hr.models import Employee
            employee = Employee.objects.get(pk=request.data["employee"])

            phase = None
            if request.data.get("phase"):
                phase = ProjectPhase.objects.filter(pk=request.data["phase"]).first()

            resource = services.assign_resource(
                project=project,
                employee=employee,
                start_date=date_type.fromisoformat(request.data["start_date"]),
                role=request.data.get("role", "ENGINEER"),
                phase=phase,
                allocation_pct=Decimal(str(request.data.get("allocation_pct", "100"))),
                end_date=(
                    date_type.fromisoformat(request.data["end_date"])
                    if request.data.get("end_date") else None
                ),
                hourly_cost_rate=Decimal(str(request.data.get("hourly_cost_rate", "0"))),
                planned_hours=Decimal(str(request.data.get("planned_hours", "0"))),
                notes=request.data.get("notes", ""),
                assigned_by=request.user,
            )
            return Response(
                ProjectResourceDetailSerializer(resource).data,
                status=status.HTTP_201_CREATED,
            )
        except Exception as e:
            return Response({"detail": str(e)}, status=status.HTTP_400_BAD_REQUEST)


# ─── ProjectCostEntry ─────────────────────────────────────────────

class ProjectCostEntryViewSet(viewsets.ModelViewSet):
    queryset = ProjectCostEntry.objects.select_related(
        "project", "phase", "task", "resource", "voucher", "created_by"
    )
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return ProjectCostEntryListSerializer
        if self.action in ("create", "update", "partial_update"):
            return ProjectCostEntryCreateSerializer
        return ProjectCostEntryDetailSerializer

    def get_queryset(self):
        qs = super().get_queryset()
        project = self.request.query_params.get("project")
        cost_type = self.request.query_params.get("cost_type")
        entry_status = self.request.query_params.get("status")
        if project:
            qs = qs.filter(project=project)
        if cost_type:
            qs = qs.filter(cost_type=cost_type)
        if entry_status:
            qs = qs.filter(status=entry_status)
        return qs

    def create(self, request, *args, **kwargs):
        try:
            project = Project.objects.get(pk=request.data["project"])
            phase = None
            if request.data.get("phase"):
                phase = ProjectPhase.objects.filter(pk=request.data["phase"]).first()
            task = None
            if request.data.get("task"):
                task = ProjectTask.objects.filter(pk=request.data["task"]).first()
            resource = None
            if request.data.get("resource"):
                resource = ProjectResource.objects.filter(pk=request.data["resource"]).first()
            material_issue = None
            if request.data.get("material_issue"):
                from apps.stores.models import MaterialIssue
                material_issue = MaterialIssue.objects.filter(pk=request.data["material_issue"]).first()

            entry = services.log_cost_entry(
                project=project,
                cost_type=request.data["cost_type"],
                cost_date=date_type.fromisoformat(request.data["cost_date"]),
                description=request.data["description"],
                amount=Decimal(str(request.data["amount"])),
                phase=phase,
                task=task,
                quantity=Decimal(str(request.data.get("quantity", "1"))),
                unit_cost=(
                    Decimal(str(request.data["unit_cost"]))
                    if request.data.get("unit_cost") else None
                ),
                resource=resource,
                material_issue=material_issue,
                notes=request.data.get("notes", ""),
                created_by=request.user,
                auto_approve=request.data.get("auto_approve", False),
                post_voucher=request.data.get("post_voucher", False),
            )
            return Response(
                ProjectCostEntryDetailSerializer(entry).data,
                status=status.HTTP_201_CREATED,
            )
        except Exception as e:
            return Response({"detail": str(e)}, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=True, methods=["post"], url_path="approve")
    def approve(self, request, pk=None):
        """Approve a cost entry and optionally post its voucher."""
        entry = self.get_object()
        if entry.status != "DRAFT":
            return Response(
                {"detail": f"Entry in status '{entry.status}' cannot be approved."},
                status=status.HTTP_400_BAD_REQUEST,
            )
        from django.utils import timezone as tz
        entry.status = "APPROVED"
        entry.approved_by = request.user
        entry.approved_at = tz.now()
        entry.save(update_fields=["status", "approved_by", "approved_at"])

        # Update project cost totals
        services._update_cost_totals(entry.project, entry.phase, entry.amount)

        if request.data.get("post_voucher", False):
            voucher = services._post_cost_voucher(entry, request.user)
            entry.voucher = voucher
            entry.status = "POSTED"
            entry.posted_by = request.user
            entry.save(update_fields=["voucher", "status", "posted_by"])

        return Response(ProjectCostEntryDetailSerializer(entry).data)


# ─── ProjectBudget ────────────────────────────────────────────────

class ProjectBudgetViewSet(viewsets.ModelViewSet):
    queryset = ProjectBudget.objects.select_related(
        "project", "approved_by"
    ).prefetch_related("lines")
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return ProjectBudgetListSerializer
        if self.action in ("create", "update", "partial_update"):
            return ProjectBudgetCreateSerializer
        return ProjectBudgetDetailSerializer

    def get_queryset(self):
        qs = super().get_queryset()
        project = self.request.query_params.get("project")
        bgt_status = self.request.query_params.get("status")
        if project:
            qs = qs.filter(project=project)
        if bgt_status:
            qs = qs.filter(status=bgt_status)
        return qs

    @action(detail=True, methods=["post"], url_path="approve")
    def approve(self, request, pk=None):
        """Approve a project budget."""
        budget = self.get_object()
        try:
            budget = services.approve_budget(
                budget=budget,
                approved_by=request.user,
                notes=request.data.get("notes", ""),
            )
            return Response(ProjectBudgetDetailSerializer(budget).data)
        except Exception as e:
            return Response({"detail": str(e)}, status=status.HTTP_400_BAD_REQUEST)


# ─── ProjectInvoice ───────────────────────────────────────────────

class ProjectInvoiceViewSet(viewsets.ModelViewSet):
    queryset = ProjectInvoice.objects.select_related(
        "project", "phase", "voucher", "sales_invoice"
    )
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return ProjectInvoiceListSerializer
        if self.action in ("create", "update", "partial_update"):
            return ProjectInvoiceCreateSerializer
        return ProjectInvoiceDetailSerializer

    def get_queryset(self):
        qs = super().get_queryset()
        project = self.request.query_params.get("project")
        inv_status = self.request.query_params.get("status")
        if project:
            qs = qs.filter(project=project)
        if inv_status:
            qs = qs.filter(status=inv_status)
        return qs

    def create(self, request, *args, **kwargs):
        try:
            project = Project.objects.get(pk=request.data["project"])
            phase = None
            if request.data.get("phase"):
                phase = ProjectPhase.objects.filter(pk=request.data["phase"]).first()

            invoice = services.generate_project_invoice(
                project=project,
                invoice_type=request.data.get("invoice_type", "PROGRESS"),
                invoice_date=date_type.fromisoformat(request.data["invoice_date"]),
                subtotal=Decimal(str(request.data["subtotal"])),
                phase=phase,
                tax_amount=Decimal(str(request.data.get("tax_amount", "0"))),
                due_date=(
                    date_type.fromisoformat(request.data["due_date"])
                    if request.data.get("due_date") else None
                ),
                milestone_description=request.data.get("milestone_description", ""),
                billing_period_from=(
                    date_type.fromisoformat(request.data["billing_period_from"])
                    if request.data.get("billing_period_from") else None
                ),
                billing_period_to=(
                    date_type.fromisoformat(request.data["billing_period_to"])
                    if request.data.get("billing_period_to") else None
                ),
                notes=request.data.get("notes", ""),
                created_by=request.user,
                auto_approve=request.data.get("auto_approve", False),
                post_to_sales=request.data.get("post_to_sales", False),
            )
            return Response(
                ProjectInvoiceDetailSerializer(invoice).data,
                status=status.HTTP_201_CREATED,
            )
        except Exception as e:
            return Response({"detail": str(e)}, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=True, methods=["post"], url_path="record-payment")
    def record_payment(self, request, pk=None):
        """Record payment received against a project invoice."""
        invoice = self.get_object()
        amount = Decimal(str(request.data.get("amount", "0")))
        if amount <= 0:
            return Response(
                {"detail": "Payment amount must be positive."},
                status=status.HTTP_400_BAD_REQUEST,
            )
        from django.db.models import F
        ProjectInvoice.objects.filter(pk=invoice.pk).update(
            amount_received=F("amount_received") + amount
        )
        invoice.refresh_from_db()
        if invoice.amount_received >= invoice.total_amount:
            invoice.status = "PAID"
            invoice.save(update_fields=["status"])
        return Response(ProjectInvoiceDetailSerializer(invoice).data)


# ─── ProjectClosure ───────────────────────────────────────────────

class ProjectClosureViewSet(viewsets.ReadOnlyModelViewSet):
    """
    Project closures are created via POST /projects/{id}/close/.
    This viewset provides read-only access.
    """
    queryset = ProjectClosure.objects.select_related("project", "signed_off_by")
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return ProjectClosureListSerializer
        return ProjectClosureDetailSerializer
