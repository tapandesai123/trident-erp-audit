"""Project & Job Costing API URL configuration."""
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from apps.projects.api.viewsets import (
    ProjectViewSet, ProjectPhaseViewSet, ProjectTaskViewSet,
    ProjectResourceViewSet, ProjectCostEntryViewSet,
    ProjectBudgetViewSet, ProjectInvoiceViewSet, ProjectClosureViewSet,
)

router = DefaultRouter()
router.register("projects", ProjectViewSet, basename="project")
router.register("phases", ProjectPhaseViewSet, basename="project-phase")
router.register("tasks", ProjectTaskViewSet, basename="project-task")
router.register("resources", ProjectResourceViewSet, basename="project-resource")
router.register("cost-entries", ProjectCostEntryViewSet, basename="project-cost-entry")
router.register("budgets", ProjectBudgetViewSet, basename="project-budget")
router.register("invoices", ProjectInvoiceViewSet, basename="project-invoice")
router.register("closures", ProjectClosureViewSet, basename="project-closure")

urlpatterns = [
    path("", include(router.urls)),
]
