"""Project & Job Costing API Serializers — 3 variants per major model."""
from rest_framework import serializers
from apps.projects.models import (
    Project, ProjectPhase, ProjectTask, ProjectResource,
    ProjectCostEntry, ProjectBudget, ProjectBudgetLine,
    ProjectInvoice, ProjectClosure,
)


# ─── ProjectPhase (inline) ────────────────────────────────────────

class ProjectPhaseListSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProjectPhase
        fields = [
            "id", "uuid", "phase_number", "name", "status",
            "planned_start", "planned_end", "completion_pct",
            "budget_amount", "cost_incurred",
        ]


class ProjectPhaseDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProjectPhase
        fields = "__all__"


class ProjectPhaseCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProjectPhase
        fields = [
            "project", "phase_number", "name", "description",
            "planned_start", "planned_end", "budget_amount",
        ]


# ─── Project ──────────────────────────────────────────────────────

class ProjectListSerializer(serializers.ModelSerializer):
    customer_name = serializers.CharField(source="customer.name", read_only=True)
    plant_code = serializers.CharField(source="plant.code", read_only=True)
    project_manager_name = serializers.SerializerMethodField()
    gross_margin = serializers.DecimalField(max_digits=18, decimal_places=2, read_only=True)
    gross_margin_pct = serializers.DecimalField(max_digits=6, decimal_places=2, read_only=True)
    budget_utilisation_pct = serializers.DecimalField(max_digits=6, decimal_places=2, read_only=True)

    class Meta:
        model = Project
        fields = [
            "id", "uuid", "project_number", "name", "project_type",
            "status", "plant", "plant_code",
            "customer", "customer_name",
            "contract_value", "approved_budget",
            "total_cost_incurred", "total_invoiced",
            "gross_margin", "gross_margin_pct", "budget_utilisation_pct",
            "planned_start", "planned_end",
            "project_manager_name",
        ]

    def get_project_manager_name(self, obj):
        return obj.project_manager.get_full_name() if obj.project_manager else None


class ProjectDetailSerializer(serializers.ModelSerializer):
    customer_name = serializers.CharField(source="customer.name", read_only=True)
    plant_code = serializers.CharField(source="plant.code", read_only=True)
    project_manager_name = serializers.SerializerMethodField()
    gross_margin = serializers.DecimalField(max_digits=18, decimal_places=2, read_only=True)
    gross_margin_pct = serializers.DecimalField(max_digits=6, decimal_places=2, read_only=True)
    budget_utilisation_pct = serializers.DecimalField(max_digits=6, decimal_places=2, read_only=True)
    phases = ProjectPhaseListSerializer(many=True, read_only=True)

    class Meta:
        model = Project
        fields = "__all__"

    def get_project_manager_name(self, obj):
        return obj.project_manager.get_full_name() if obj.project_manager else None


class ProjectCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Project
        fields = [
            "plant", "name", "description", "project_type",
            "customer", "contract_number", "contract_value",
            "planned_start", "planned_end",
            "project_manager", "notes",
        ]


# ─── ProjectTask ──────────────────────────────────────────────────

class ProjectTaskListSerializer(serializers.ModelSerializer):
    project_number = serializers.CharField(source="project.project_number", read_only=True)
    phase_name = serializers.CharField(source="phase.name", read_only=True)
    assigned_to_name = serializers.SerializerMethodField()

    class Meta:
        model = ProjectTask
        fields = [
            "id", "uuid", "project", "project_number",
            "phase", "phase_name",
            "title", "status", "priority",
            "assigned_to", "assigned_to_name",
            "planned_end", "completion_pct",
            "estimated_hours", "actual_hours",
        ]

    def get_assigned_to_name(self, obj):
        return obj.assigned_to.get_full_name() if obj.assigned_to else None


class ProjectTaskDetailSerializer(serializers.ModelSerializer):
    project_number = serializers.CharField(source="project.project_number", read_only=True)

    class Meta:
        model = ProjectTask
        fields = "__all__"


class ProjectTaskCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProjectTask
        fields = [
            "project", "phase", "title", "description",
            "priority", "assigned_to",
            "planned_start", "planned_end",
            "estimated_hours",
        ]


# ─── ProjectResource ──────────────────────────────────────────────

class ProjectResourceListSerializer(serializers.ModelSerializer):
    project_number = serializers.CharField(source="project.project_number", read_only=True)
    employee_name = serializers.CharField(source="employee.__str__", read_only=True)
    phase_name = serializers.CharField(source="phase.name", read_only=True)

    class Meta:
        model = ProjectResource
        fields = [
            "id", "uuid", "project", "project_number",
            "employee", "employee_name",
            "phase", "phase_name",
            "role", "allocation_pct",
            "start_date", "end_date",
            "hourly_cost_rate",
            "planned_hours", "actual_hours",
            "is_active",
        ]


class ProjectResourceDetailSerializer(serializers.ModelSerializer):
    project_number = serializers.CharField(source="project.project_number", read_only=True)
    employee_name = serializers.CharField(source="employee.__str__", read_only=True)

    class Meta:
        model = ProjectResource
        fields = "__all__"


class ProjectResourceCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProjectResource
        fields = [
            "project", "employee", "phase", "role",
            "allocation_pct", "start_date", "end_date",
            "hourly_cost_rate", "planned_hours", "notes",
        ]


# ─── ProjectCostEntry ─────────────────────────────────────────────

class ProjectCostEntryListSerializer(serializers.ModelSerializer):
    project_number = serializers.CharField(source="project.project_number", read_only=True)
    phase_name = serializers.CharField(source="phase.name", read_only=True)
    voucher_number = serializers.CharField(source="voucher.voucher_number", read_only=True)

    class Meta:
        model = ProjectCostEntry
        fields = [
            "id", "uuid", "entry_number",
            "project", "project_number",
            "phase", "phase_name",
            "cost_type", "cost_date",
            "description", "amount", "status",
            "voucher_number",
        ]


class ProjectCostEntryDetailSerializer(serializers.ModelSerializer):
    project_number = serializers.CharField(source="project.project_number", read_only=True)
    voucher_number = serializers.CharField(source="voucher.voucher_number", read_only=True)

    class Meta:
        model = ProjectCostEntry
        fields = "__all__"


class ProjectCostEntryCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProjectCostEntry
        fields = [
            "project", "phase", "task",
            "cost_type", "cost_date", "description",
            "quantity", "unit_cost", "amount",
            "resource", "material_issue", "notes",
        ]


# ─── ProjectBudgetLine ────────────────────────────────────────────

class ProjectBudgetLineSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProjectBudgetLine
        fields = [
            "id", "phase", "cost_type", "description",
            "quantity", "unit_cost", "amount", "notes",
        ]


# ─── ProjectBudget ────────────────────────────────────────────────

class ProjectBudgetListSerializer(serializers.ModelSerializer):
    project_number = serializers.CharField(source="project.project_number", read_only=True)
    approved_by_name = serializers.SerializerMethodField()

    class Meta:
        model = ProjectBudget
        fields = [
            "id", "uuid", "budget_number", "project", "project_number",
            "version", "title", "status", "total_amount",
            "approved_by_name", "approved_at",
        ]

    def get_approved_by_name(self, obj):
        return obj.approved_by.get_full_name() if obj.approved_by else None


class ProjectBudgetDetailSerializer(serializers.ModelSerializer):
    project_number = serializers.CharField(source="project.project_number", read_only=True)
    lines = ProjectBudgetLineSerializer(many=True, read_only=True)

    class Meta:
        model = ProjectBudget
        fields = "__all__"


class ProjectBudgetCreateSerializer(serializers.ModelSerializer):
    lines = ProjectBudgetLineSerializer(many=True, required=False)

    class Meta:
        model = ProjectBudget
        fields = ["project", "title", "version", "notes", "lines"]

    def create(self, validated_data):
        lines_data = validated_data.pop("lines", [])
        budget = ProjectBudget.objects.create(**validated_data)
        for line in lines_data:
            ProjectBudgetLine.objects.create(budget=budget, **line)
        return budget


# ─── ProjectInvoice ───────────────────────────────────────────────

class ProjectInvoiceListSerializer(serializers.ModelSerializer):
    project_number = serializers.CharField(source="project.project_number", read_only=True)
    phase_name = serializers.CharField(source="phase.name", read_only=True)
    voucher_number = serializers.CharField(source="voucher.voucher_number", read_only=True)
    amount_outstanding = serializers.DecimalField(max_digits=16, decimal_places=2, read_only=True)

    class Meta:
        model = ProjectInvoice
        fields = [
            "id", "uuid", "invoice_number",
            "project", "project_number",
            "phase", "phase_name",
            "invoice_type", "invoice_date",
            "total_amount", "amount_received", "amount_outstanding",
            "status", "voucher_number",
        ]


class ProjectInvoiceDetailSerializer(serializers.ModelSerializer):
    project_number = serializers.CharField(source="project.project_number", read_only=True)
    amount_outstanding = serializers.DecimalField(max_digits=16, decimal_places=2, read_only=True)
    voucher_number = serializers.CharField(source="voucher.voucher_number", read_only=True)

    class Meta:
        model = ProjectInvoice
        fields = "__all__"


class ProjectInvoiceCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProjectInvoice
        fields = [
            "project", "phase", "invoice_type", "invoice_date",
            "due_date", "subtotal", "tax_amount",
            "billing_period_from", "billing_period_to",
            "milestone_description", "notes",
        ]


# ─── ProjectClosure ───────────────────────────────────────────────

class ProjectClosureListSerializer(serializers.ModelSerializer):
    project_number = serializers.CharField(source="project.project_number", read_only=True)
    project_name = serializers.CharField(source="project.name", read_only=True)

    class Meta:
        model = ProjectClosure
        fields = [
            "id", "uuid", "project", "project_number", "project_name",
            "closure_date", "closure_reason",
            "total_revenue", "total_cost", "gross_profit", "gross_margin_pct",
            "budget_variance", "client_sign_off",
        ]


class ProjectClosureDetailSerializer(serializers.ModelSerializer):
    project_number = serializers.CharField(source="project.project_number", read_only=True)

    class Meta:
        model = ProjectClosure
        fields = "__all__"


class ProjectClosureCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProjectClosure
        fields = [
            "project", "closure_date", "closure_reason",
            "client_sign_off", "client_sign_off_date",
            "lessons_learned", "notes",
        ]
