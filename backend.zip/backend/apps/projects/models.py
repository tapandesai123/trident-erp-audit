"""
Project & Job Costing Module Models — Section 13

Models:
  Project             — Master project record with budget, timeline, customer link
  ProjectPhase        — Phases / milestones within a project
  ProjectTask         — Granular tasks under a phase
  ProjectResource     — Human resources assigned to a project (linked to hr.Employee)
  ProjectCostEntry    — Actual cost postings (labour / material / overhead)
  ProjectBudget       — Approved budget header for a project
  ProjectBudgetLine   — Line-level breakdown of a budget (by cost type / phase)
  ProjectInvoice      — Client invoices raised against a project
  ProjectClosure      — Formal closure record with sign-off and profitability snapshot
"""
import uuid
from decimal import Decimal
from django.db import models
from django.conf import settings
from apps.core.models import UUIDModel, TimeStampedModel, Plant


# ═══════════════════════════════════════════════════════════════════
# PROJECT
# ═══════════════════════════════════════════════════════════════════

class Project(UUIDModel, TimeStampedModel):
    STATUS_CHOICES = [
        ("DRAFT", "Draft"),
        ("ACTIVE", "Active"),
        ("ON_HOLD", "On Hold"),
        ("COMPLETED", "Completed"),
        ("CLOSED", "Closed"),
        ("CANCELLED", "Cancelled"),
    ]
    TYPE_CHOICES = [
        ("INTERNAL", "Internal"),
        ("EXTERNAL", "External — Fixed Price"),
        ("EXTERNAL_TM", "External — Time & Material"),
        ("CAPEX", "Capital Expenditure"),
    ]

    plant = models.ForeignKey(Plant, on_delete=models.PROTECT, related_name="projects")
    project_number = models.CharField(max_length=50, unique=True)
    name = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    project_type = models.CharField(max_length=20, choices=TYPE_CHOICES, default="EXTERNAL")
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="DRAFT")

    # Customer / contract link
    customer = models.ForeignKey(
        "masters.Customer", on_delete=models.SET_NULL,
        null=True, blank=True, related_name="projects",
    )
    contract_number = models.CharField(max_length=100, blank=True)
    contract_value = models.DecimalField(max_digits=18, decimal_places=2, default=0)

    # Timeline
    planned_start = models.DateField(null=True, blank=True)
    planned_end = models.DateField(null=True, blank=True)
    actual_start = models.DateField(null=True, blank=True)
    actual_end = models.DateField(null=True, blank=True)

    # Budget summary (denormalized for quick reads — maintained by services)
    approved_budget = models.DecimalField(max_digits=18, decimal_places=2, default=0)
    total_cost_incurred = models.DecimalField(max_digits=18, decimal_places=2, default=0)
    total_invoiced = models.DecimalField(max_digits=18, decimal_places=2, default=0)

    # Personnel
    project_manager = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="managed_projects",
    )

    notes = models.TextField(blank=True)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="projects_created",
    )

    @property
    def gross_margin(self) -> Decimal:
        """Revenue - Cost; positive = profit."""
        return Decimal(str(self.total_invoiced)) - Decimal(str(self.total_cost_incurred))

    @property
    def gross_margin_pct(self) -> Decimal:
        if self.total_invoiced:
            return (self.gross_margin / Decimal(str(self.total_invoiced)) * 100).quantize(
                Decimal("0.01")
            )
        return Decimal("0.00")

    @property
    def budget_utilisation_pct(self) -> Decimal:
        if self.approved_budget:
            return (
                Decimal(str(self.total_cost_incurred))
                / Decimal(str(self.approved_budget))
                * 100
            ).quantize(Decimal("0.01"))
        return Decimal("0.00")

    class Meta:
        ordering = ["-created_at"]
        indexes = [
            models.Index(fields=["plant", "status"]),
            models.Index(fields=["customer"]),
            models.Index(fields=["project_type"]),
        ]

    def __str__(self):
        return f"{self.project_number} — {self.name} [{self.status}]"


# ═══════════════════════════════════════════════════════════════════
# PROJECT PHASE
# ═══════════════════════════════════════════════════════════════════

class ProjectPhase(UUIDModel, TimeStampedModel):
    STATUS_CHOICES = [
        ("PENDING", "Pending"),
        ("IN_PROGRESS", "In Progress"),
        ("COMPLETED", "Completed"),
        ("ON_HOLD", "On Hold"),
        ("CANCELLED", "Cancelled"),
    ]

    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name="phases")
    phase_number = models.PositiveSmallIntegerField(help_text="Order within project (1, 2, 3…)")
    name = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="PENDING")
    planned_start = models.DateField(null=True, blank=True)
    planned_end = models.DateField(null=True, blank=True)
    actual_start = models.DateField(null=True, blank=True)
    actual_end = models.DateField(null=True, blank=True)
    completion_pct = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    budget_amount = models.DecimalField(max_digits=16, decimal_places=2, default=0)
    cost_incurred = models.DecimalField(max_digits=16, decimal_places=2, default=0)

    class Meta:
        unique_together = [["project", "phase_number"]]
        ordering = ["project", "phase_number"]

    def __str__(self):
        return f"{self.project.project_number} | Phase {self.phase_number}: {self.name}"


# ═══════════════════════════════════════════════════════════════════
# PROJECT TASK
# ═══════════════════════════════════════════════════════════════════

class ProjectTask(UUIDModel, TimeStampedModel):
    PRIORITY_CHOICES = [
        ("LOW", "Low"),
        ("MEDIUM", "Medium"),
        ("HIGH", "High"),
        ("CRITICAL", "Critical"),
    ]
    STATUS_CHOICES = [
        ("OPEN", "Open"),
        ("IN_PROGRESS", "In Progress"),
        ("REVIEW", "Review"),
        ("DONE", "Done"),
        ("CANCELLED", "Cancelled"),
    ]

    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name="tasks")
    phase = models.ForeignKey(
        ProjectPhase, on_delete=models.SET_NULL, null=True, blank=True, related_name="tasks"
    )
    title = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="OPEN")
    priority = models.CharField(max_length=10, choices=PRIORITY_CHOICES, default="MEDIUM")
    assigned_to = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="project_tasks",
    )
    planned_start = models.DateField(null=True, blank=True)
    planned_end = models.DateField(null=True, blank=True)
    actual_start = models.DateField(null=True, blank=True)
    actual_end = models.DateField(null=True, blank=True)
    estimated_hours = models.DecimalField(max_digits=8, decimal_places=2, default=0)
    actual_hours = models.DecimalField(max_digits=8, decimal_places=2, default=0)
    completion_pct = models.DecimalField(max_digits=5, decimal_places=2, default=0)

    class Meta:
        ordering = ["project", "phase", "priority"]
        indexes = [
            models.Index(fields=["project", "status"]),
            models.Index(fields=["assigned_to"]),
        ]

    def __str__(self):
        return f"{self.project.project_number} | {self.title} [{self.status}]"


# ═══════════════════════════════════════════════════════════════════
# PROJECT RESOURCE
# ═══════════════════════════════════════════════════════════════════

class ProjectResource(UUIDModel, TimeStampedModel):
    ROLE_CHOICES = [
        ("PROJECT_MANAGER", "Project Manager"),
        ("ENGINEER", "Engineer"),
        ("TECHNICIAN", "Technician"),
        ("DESIGNER", "Designer"),
        ("ANALYST", "Analyst"),
        ("CONSULTANT", "Consultant"),
        ("SUPPORT", "Support"),
        ("OTHER", "Other"),
    ]

    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name="resources")
    employee = models.ForeignKey(
        "hr.Employee", on_delete=models.PROTECT, related_name="project_assignments",
    )
    phase = models.ForeignKey(
        ProjectPhase, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="resources",
    )
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default="ENGINEER")
    allocation_pct = models.DecimalField(
        max_digits=5, decimal_places=2, default=100,
        help_text="% of employee time allocated to this project",
    )
    start_date = models.DateField()
    end_date = models.DateField(null=True, blank=True)
    hourly_cost_rate = models.DecimalField(
        max_digits=10, decimal_places=2, default=0,
        help_text="Cost per hour billed to project",
    )
    planned_hours = models.DecimalField(max_digits=8, decimal_places=2, default=0)
    actual_hours = models.DecimalField(max_digits=8, decimal_places=2, default=0)
    is_active = models.BooleanField(default=True)
    notes = models.TextField(blank=True)
    assigned_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="resource_assignments",
    )

    class Meta:
        unique_together = [["project", "employee", "phase"]]
        ordering = ["project", "role"]
        indexes = [
            models.Index(fields=["project", "is_active"]),
            models.Index(fields=["employee"]),
        ]

    def __str__(self):
        return (
            f"{self.project.project_number} | {self.employee} "
            f"| {self.get_role_display()} | {self.allocation_pct}%"
        )


# ═══════════════════════════════════════════════════════════════════
# PROJECT COST ENTRY
# ═══════════════════════════════════════════════════════════════════

class ProjectCostEntry(UUIDModel, TimeStampedModel):
    COST_TYPE = [
        ("LABOUR", "Labour"),
        ("MATERIAL", "Material"),
        ("SUBCONTRACT", "Subcontract"),
        ("OVERHEAD", "Overhead"),
        ("TRAVEL", "Travel & Expenses"),
        ("EQUIPMENT", "Equipment Hire"),
        ("OTHER", "Other"),
    ]
    STATUS_CHOICES = [
        ("DRAFT", "Draft"),
        ("APPROVED", "Approved"),
        ("REJECTED", "Rejected"),
        ("POSTED", "Posted"),
    ]

    entry_number = models.CharField(max_length=50, unique=True)
    project = models.ForeignKey(Project, on_delete=models.PROTECT, related_name="cost_entries")
    phase = models.ForeignKey(
        ProjectPhase, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="cost_entries",
    )
    task = models.ForeignKey(
        ProjectTask, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="cost_entries",
    )
    cost_type = models.CharField(max_length=15, choices=COST_TYPE, default="LABOUR")
    cost_date = models.DateField()
    description = models.CharField(max_length=300)
    quantity = models.DecimalField(max_digits=12, decimal_places=4, default=1)
    unit_cost = models.DecimalField(max_digits=14, decimal_places=4, default=0)
    amount = models.DecimalField(max_digits=16, decimal_places=2, default=0)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default="DRAFT")

    # Integration links
    resource = models.ForeignKey(
        ProjectResource, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="cost_entries",
        help_text="Linked resource (for LABOUR entries)",
    )
    material_issue = models.ForeignKey(
        "stores.StockIssue", on_delete=models.SET_NULL, null=True, blank=True,
        related_name="project_cost_entries",
        help_text="Linked material issue (for MATERIAL entries)",
    )
    voucher = models.ForeignKey(
        "accounts.Voucher", on_delete=models.SET_NULL, null=True, blank=True,
        related_name="project_cost_entries",
    )

    approved_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="cost_entries_approved",
    )
    approved_at = models.DateTimeField(null=True, blank=True)
    posted_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="cost_entries_posted",
    )
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="cost_entries_created",
    )
    notes = models.TextField(blank=True)

    class Meta:
        ordering = ["-cost_date", "project"]
        indexes = [
            models.Index(fields=["project", "cost_type"]),
            models.Index(fields=["project", "status"]),
            models.Index(fields=["cost_date"]),
        ]

    def __str__(self):
        return (
            f"{self.entry_number} | {self.project.project_number} "
            f"| {self.get_cost_type_display()} | ₹{self.amount}"
        )


# ═══════════════════════════════════════════════════════════════════
# PROJECT BUDGET
# ═══════════════════════════════════════════════════════════════════

class ProjectBudget(UUIDModel, TimeStampedModel):
    STATUS_CHOICES = [
        ("DRAFT", "Draft"),
        ("SUBMITTED", "Submitted"),
        ("APPROVED", "Approved"),
        ("REVISED", "Revised"),
        ("REJECTED", "Rejected"),
    ]

    project = models.ForeignKey(Project, on_delete=models.PROTECT, related_name="budgets")
    budget_number = models.CharField(max_length=50, unique=True)
    version = models.PositiveSmallIntegerField(default=1)
    title = models.CharField(max_length=200)
    status = models.CharField(max_length=15, choices=STATUS_CHOICES, default="DRAFT")
    total_amount = models.DecimalField(max_digits=18, decimal_places=2, default=0)

    submitted_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="budgets_submitted",
    )
    submitted_at = models.DateTimeField(null=True, blank=True)
    approved_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="budgets_approved",
    )
    approved_at = models.DateTimeField(null=True, blank=True)
    notes = models.TextField(blank=True)

    class Meta:
        ordering = ["-version"]
        indexes = [models.Index(fields=["project", "status"])]

    def __str__(self):
        return f"{self.budget_number} | {self.project.project_number} v{self.version} [{self.status}]"


class ProjectBudgetLine(models.Model):
    budget = models.ForeignKey(ProjectBudget, on_delete=models.CASCADE, related_name="lines")
    phase = models.ForeignKey(
        ProjectPhase, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="budget_lines",
    )
    cost_type = models.CharField(
        max_length=15, choices=ProjectCostEntry.COST_TYPE, default="LABOUR"
    )
    description = models.CharField(max_length=300)
    quantity = models.DecimalField(max_digits=12, decimal_places=4, default=1)
    unit_cost = models.DecimalField(max_digits=14, decimal_places=4, default=0)
    amount = models.DecimalField(max_digits=16, decimal_places=2, default=0)
    notes = models.CharField(max_length=300, blank=True)

    class Meta:
        ordering = ["budget", "cost_type"]

    def __str__(self):
        return (
            f"{self.budget.budget_number} | {self.get_cost_type_display()} "
            f"| ₹{self.amount}"
        )

    def get_cost_type_display(self):
        return dict(ProjectCostEntry.COST_TYPE).get(self.cost_type, self.cost_type)


# ═══════════════════════════════════════════════════════════════════
# PROJECT INVOICE
# ═══════════════════════════════════════════════════════════════════

class ProjectInvoice(UUIDModel, TimeStampedModel):
    STATUS_CHOICES = [
        ("DRAFT", "Draft"),
        ("SUBMITTED", "Submitted"),
        ("APPROVED", "Approved"),
        ("POSTED", "Posted"),
        ("PAID", "Paid"),
        ("CANCELLED", "Cancelled"),
    ]
    INVOICE_TYPE = [
        ("MILESTONE", "Milestone"),
        ("PROGRESS", "Progress Billing"),
        ("FINAL", "Final Invoice"),
        ("ADVANCE", "Advance"),
        ("RETENTION", "Retention Release"),
    ]

    invoice_number = models.CharField(max_length=50, unique=True)
    project = models.ForeignKey(Project, on_delete=models.PROTECT, related_name="invoices")
    phase = models.ForeignKey(
        ProjectPhase, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="invoices",
    )
    invoice_type = models.CharField(max_length=15, choices=INVOICE_TYPE, default="PROGRESS")
    invoice_date = models.DateField()
    due_date = models.DateField(null=True, blank=True)
    status = models.CharField(max_length=15, choices=STATUS_CHOICES, default="DRAFT")

    billing_period_from = models.DateField(null=True, blank=True)
    billing_period_to = models.DateField(null=True, blank=True)
    milestone_description = models.CharField(max_length=300, blank=True)

    subtotal = models.DecimalField(max_digits=16, decimal_places=2, default=0)
    tax_amount = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    total_amount = models.DecimalField(max_digits=16, decimal_places=2, default=0)
    amount_received = models.DecimalField(max_digits=16, decimal_places=2, default=0)

    # Integration
    sales_invoice = models.ForeignKey(
        "sales.Invoice", on_delete=models.SET_NULL, null=True, blank=True,
        related_name="project_invoices",
    )
    voucher = models.ForeignKey(
        "accounts.Voucher", on_delete=models.SET_NULL, null=True, blank=True,
        related_name="project_invoices",
    )

    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="project_invoices_created",
    )
    approved_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="project_invoices_approved",
    )
    approved_at = models.DateTimeField(null=True, blank=True)
    notes = models.TextField(blank=True)

    @property
    def amount_outstanding(self) -> Decimal:
        return Decimal(str(self.total_amount)) - Decimal(str(self.amount_received))

    class Meta:
        ordering = ["-invoice_date"]
        indexes = [
            models.Index(fields=["project", "status"]),
            models.Index(fields=["invoice_date"]),
        ]

    def __str__(self):
        return (
            f"{self.invoice_number} | {self.project.project_number} "
            f"| ₹{self.total_amount} | {self.status}"
        )


# ═══════════════════════════════════════════════════════════════════
# PROJECT CLOSURE
# ═══════════════════════════════════════════════════════════════════

class ProjectClosure(UUIDModel, TimeStampedModel):
    CLOSURE_REASON = [
        ("COMPLETED", "Successfully Completed"),
        ("CANCELLED", "Cancelled"),
        ("MERGED", "Merged into Another Project"),
        ("SCOPE_CHANGE", "Scope Change / Restructured"),
    ]

    project = models.OneToOneField(Project, on_delete=models.PROTECT, related_name="closure")
    closure_date = models.DateField()
    closure_reason = models.CharField(max_length=20, choices=CLOSURE_REASON, default="COMPLETED")

    # Profitability snapshot at closure
    total_revenue = models.DecimalField(max_digits=18, decimal_places=2, default=0)
    total_cost = models.DecimalField(max_digits=18, decimal_places=2, default=0)
    gross_profit = models.DecimalField(max_digits=18, decimal_places=2, default=0)
    gross_margin_pct = models.DecimalField(max_digits=6, decimal_places=2, default=0)
    approved_budget = models.DecimalField(max_digits=18, decimal_places=2, default=0)
    budget_variance = models.DecimalField(
        max_digits=18, decimal_places=2, default=0,
        help_text="Positive = under budget, Negative = over budget",
    )

    # Sign-off
    signed_off_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="projects_signed_off",
    )
    signed_off_at = models.DateTimeField(null=True, blank=True)
    client_sign_off = models.BooleanField(default=False)
    client_sign_off_date = models.DateField(null=True, blank=True)
    lessons_learned = models.TextField(blank=True)
    notes = models.TextField(blank=True)

    class Meta:
        ordering = ["-closure_date"]

    def __str__(self):
        return (
            f"Closure: {self.project.project_number} | {self.closure_date} "
            f"| GP: ₹{self.gross_profit} ({self.gross_margin_pct}%)"
        )
