"""Project & Job Costing Celery tasks."""
from celery import shared_task
from django.utils import timezone


@shared_task(bind=True, max_retries=3, default_retry_delay=60)
def recalculate_project_costs_task(self, project_id):
    """
    Async: recompute total_cost_incurred and total_invoiced for a project
    from source records. Used to fix any denormalization drift.
    """
    try:
        from apps.projects.models import Project, ProjectCostEntry, ProjectInvoice
        from django.db.models import Sum

        project = Project.objects.get(pk=project_id)

        total_cost = (
            ProjectCostEntry.objects
            .filter(project=project, status__in=("APPROVED", "POSTED"))
            .aggregate(t=Sum("amount"))["t"] or 0
        )
        total_invoiced = (
            ProjectInvoice.objects
            .filter(project=project, status__in=("APPROVED", "POSTED", "PAID"))
            .aggregate(t=Sum("total_amount"))["t"] or 0
        )

        project.total_cost_incurred = total_cost
        project.total_invoiced = total_invoiced
        project.save(update_fields=["total_cost_incurred", "total_invoiced"])

        return {
            "project": project.project_number,
            "total_cost": str(total_cost),
            "total_invoiced": str(total_invoiced),
        }
    except Exception as exc:
        raise self.retry(exc=exc)


@shared_task
def send_project_overdue_alerts():
    """
    Periodic: notify project managers of projects past their planned_end date
    that are still ACTIVE.
    Schedule: daily.
    """
    from datetime import date
    from apps.projects.models import Project
    from apps.core.models import Notification

    today = date.today()
    overdue = Project.objects.filter(
        status="ACTIVE",
        planned_end__lt=today,
        project_manager__isnull=False,
    ).select_related("project_manager")

    notified = 0
    for project in overdue:
        days_overdue = (today - project.planned_end).days
        Notification.objects.get_or_create(
            user=project.project_manager,
            module="projects",
            resource="Project",
            resource_id=project.pk,
            title=f"Project Overdue: {project.project_number}",
            defaults={
                "message": (
                    f"Project '{project.name}' ({project.project_number}) is "
                    f"{days_overdue} day(s) overdue. Planned end: {project.planned_end}."
                ),
                "notification_type": "IN_APP",
            },
        )
        notified += 1

    return {"overdue_alerts_sent": notified, "checked_date": str(today)}


@shared_task
def send_budget_overrun_alerts():
    """
    Periodic: alert project managers when cost incurred exceeds 90% of approved budget.
    Schedule: daily.
    """
    from apps.projects.models import Project
    from apps.core.models import Notification
    from decimal import Decimal

    threshold = Decimal("90")
    at_risk = Project.objects.filter(
        status="ACTIVE",
        approved_budget__gt=0,
        project_manager__isnull=False,
    ).select_related("project_manager")

    notified = 0
    for project in at_risk:
        utilisation = project.budget_utilisation_pct
        if utilisation >= threshold:
            Notification.objects.get_or_create(
                user=project.project_manager,
                module="projects",
                resource="Project",
                resource_id=project.pk,
                title=f"Budget {'Overrun' if utilisation > 100 else 'Warning'}: {project.project_number}",
                defaults={
                    "message": (
                        f"Project '{project.name}' has consumed "
                        f"{utilisation}% of its approved budget "
                        f"(₹{project.total_cost_incurred:,.0f} of "
                        f"₹{project.approved_budget:,.0f})."
                    ),
                    "notification_type": "IN_APP",
                },
            )
            notified += 1

    return {"budget_alerts_sent": notified}


@shared_task
def send_invoice_due_alerts():
    """
    Periodic: alert project managers of outstanding project invoices past due date.
    Schedule: daily.
    """
    from datetime import date
    from apps.projects.models import ProjectInvoice
    from apps.core.models import Notification

    today = date.today()
    overdue_invoices = ProjectInvoice.objects.filter(
        status__in=("APPROVED", "POSTED"),
        due_date__lt=today,
    ).select_related("project__project_manager", "project")

    notified = 0
    for invoice in overdue_invoices:
        pm = invoice.project.project_manager
        if pm and invoice.amount_outstanding > 0:
            days_overdue = (today - invoice.due_date).days
            Notification.objects.get_or_create(
                user=pm,
                module="projects",
                resource="ProjectInvoice",
                resource_id=invoice.pk,
                title=f"Invoice Overdue: {invoice.invoice_number}",
                defaults={
                    "message": (
                        f"Invoice {invoice.invoice_number} for project "
                        f"'{invoice.project.project_number}' is {days_overdue} "
                        f"day(s) overdue. Outstanding: ₹{invoice.amount_outstanding:,.2f}."
                    ),
                    "notification_type": "IN_APP",
                },
            )
            notified += 1

    return {"invoice_overdue_alerts": notified, "checked_date": str(today)}


@shared_task(bind=True, max_retries=3, default_retry_delay=120)
def generate_profitability_report_task(self, project_id, user_id=None):
    """
    Async: compute and return profitability report for a project.
    Useful for large projects where the report takes significant time.
    """
    try:
        from apps.projects.models import Project
        from apps.projects.services import get_project_profitability

        project = Project.objects.get(pk=project_id)
        report = get_project_profitability(project)
        return report
    except Exception as exc:
        raise self.retry(exc=exc)
