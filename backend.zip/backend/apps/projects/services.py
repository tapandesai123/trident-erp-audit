"""
Project & Job Costing Module Services — Section 13

Services:
  create_project()              — Create project with auto-number; AuditLog + Notification
  assign_resource()             — Assign hr.Employee to a project/phase
  log_cost_entry()              — Record actual cost; post accounts.Voucher on approval
  approve_budget()              — Approve a project budget; update project.approved_budget
  generate_project_invoice()    — Raise a ProjectInvoice; link sales.Invoice + Voucher
  close_project()               — Formal closure with profitability snapshot
  get_project_profitability()   — Return profitability report dict for a project
"""
from __future__ import annotations

from datetime import date
from decimal import Decimal, ROUND_HALF_UP
from typing import Optional

from django.db import transaction
from django.utils import timezone

from apps.core.models import AuditLog, DocSequence, Notification


# ─── Helpers ──────────────────────────────────────────────────────

def _two(val) -> Decimal:
    return Decimal(str(val)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def _log(user, action: str, resource: str, resource_id, details: dict = None):
    AuditLog.objects.create(
        user=user,
        action=action,
        module="projects",
        resource=resource,
        resource_id=str(resource_id),
        new_values=details or {},
    )


def _notify(user, title: str, message: str, resource: str, resource_id):
    if user:
        Notification.objects.create(
            user=user,
            title=title,
            message=message,
            notification_type="IN_APP",
            module="projects",
            resource=resource,
            resource_id=resource_id,
        )


def get_next_doc_number(plant, doc_type: str, prefix: str) -> str:
    """Thread-safe sequential document numbering. Format: PREFIX/YYYY-YY/00001"""
    today = date.today()
    fy_start = today.year if today.month >= 4 else today.year - 1
    fy_label = f"{fy_start}-{str(fy_start + 1)[2:]}"

    with transaction.atomic():
        seq, _ = DocSequence.objects.select_for_update().get_or_create(
            plant=plant,
            doc_type=doc_type,
            defaults={"last_number": 0, "financial_year": fy_label},
        )
        if seq.financial_year != fy_label:
            seq.financial_year = fy_label
            seq.last_number = 0

        seq.last_number += 1
        seq.save(update_fields=["last_number", "financial_year"])
        return f"{prefix}/{fy_label}/{seq.last_number:05d}"


# ═══════════════════════════════════════════════════════════════════
# CREATE PROJECT
# ═══════════════════════════════════════════════════════════════════

@transaction.atomic
def create_project(
    plant,
    name: str,
    project_type: str = "EXTERNAL",
    *,
    description: str = "",
    customer=None,
    contract_number: str = "",
    contract_value: Decimal = Decimal("0"),
    planned_start: date = None,
    planned_end: date = None,
    project_manager=None,
    notes: str = "",
    created_by=None,
) -> "Project":
    """
    Create a new project.

    1. Auto-generate project_number (PRJ/YYYY-YY/00001).
    2. Create Project record in DRAFT status.
    3. AuditLog + Notification to project_manager.
    """
    from apps.projects.models import Project

    project_number = get_next_doc_number(plant, "PRJ", "PRJ")

    project = Project.objects.create(
        plant=plant,
        project_number=project_number,
        name=name,
        description=description,
        project_type=project_type,
        status="DRAFT",
        customer=customer,
        contract_number=contract_number,
        contract_value=_two(contract_value),
        planned_start=planned_start,
        planned_end=planned_end,
        project_manager=project_manager,
        notes=notes,
        created_by=created_by,
    )

    _log(created_by, "CREATE", "Project", project.pk, {
        "project_number": project_number,
        "name": name,
        "type": project_type,
        "plant": plant.code,
    })

    if project_manager:
        _notify(
            project_manager,
            f"Project Created: {project_number}",
            f"You have been assigned as Project Manager for '{name}' ({project_number}).",
            "Project", project.pk,
        )

    return project


# ═══════════════════════════════════════════════════════════════════
# ASSIGN RESOURCE
# ═══════════════════════════════════════════════════════════════════

@transaction.atomic
def assign_resource(
    project,
    employee,
    start_date: date,
    role: str = "ENGINEER",
    *,
    phase=None,
    allocation_pct: Decimal = Decimal("100"),
    end_date: date = None,
    hourly_cost_rate: Decimal = Decimal("0"),
    planned_hours: Decimal = Decimal("0"),
    notes: str = "",
    assigned_by=None,
) -> "ProjectResource":
    """
    Assign an hr.Employee to a project (optionally to a specific phase).

    - Upserts: if the employee is already assigned to the same project+phase,
      updates the existing record instead of creating a duplicate.
    - Notifies the employee's linked user account if available.
    """
    from apps.projects.models import ProjectResource

    resource, created = ProjectResource.objects.update_or_create(
        project=project,
        employee=employee,
        phase=phase,
        defaults=dict(
            role=role,
            allocation_pct=_two(allocation_pct),
            start_date=start_date,
            end_date=end_date,
            hourly_cost_rate=_two(hourly_cost_rate),
            planned_hours=_two(planned_hours),
            notes=notes,
            is_active=True,
            assigned_by=assigned_by,
        ),
    )

    action = "CREATE" if created else "UPDATE"
    _log(assigned_by, action, "ProjectResource", resource.pk, {
        "project": project.project_number,
        "employee": str(employee),
        "role": role,
        "allocation_pct": str(allocation_pct),
    })

    # Notify employee's linked user if available
    linked_user = getattr(employee, "user", None)
    if linked_user:
        _notify(
            linked_user,
            f"Assigned to Project: {project.project_number}",
            f"You have been assigned as {role} on project '{project.name}' "
            f"({allocation_pct}% allocation from {start_date}).",
            "ProjectResource", resource.pk,
        )

    return resource


# ═══════════════════════════════════════════════════════════════════
# LOG COST ENTRY
# ═══════════════════════════════════════════════════════════════════

@transaction.atomic
def log_cost_entry(
    project,
    cost_type: str,
    cost_date: date,
    description: str,
    amount: Decimal,
    *,
    phase=None,
    task=None,
    quantity: Decimal = Decimal("1"),
    unit_cost: Decimal = None,
    resource=None,
    material_issue=None,
    notes: str = "",
    created_by=None,
    auto_approve: bool = False,
    post_voucher: bool = False,
) -> "ProjectCostEntry":
    """
    Record an actual cost against a project.

    Steps:
    1. Validate project status is ACTIVE.
    2. Generate entry_number (PCE/YYYY-YY/00001).
    3. Create ProjectCostEntry.
    4. If auto_approve=True → set status=APPROVED.
    5. If post_voucher=True (and approved) → post accounts.Voucher (JOURNAL):
         DR  Project WIP / Cost Account
         CR  Payables / Labour Accrual
    6. Update project.total_cost_incurred and phase.cost_incurred.
    """
    from apps.projects.models import ProjectCostEntry

    if project.status not in ("ACTIVE", "DRAFT"):
        raise ValueError(
            f"Cannot log cost for project '{project.project_number}' "
            f"in status '{project.status}'."
        )

    if unit_cost is None:
        unit_cost = _two(amount / quantity) if quantity else _two(amount)
    unit_cost = _two(unit_cost)
    amount = _two(amount)

    entry_number = get_next_doc_number(project.plant, "PCE", "PCE")
    status = "APPROVED" if auto_approve else "DRAFT"

    entry = ProjectCostEntry.objects.create(
        entry_number=entry_number,
        project=project,
        phase=phase,
        task=task,
        cost_type=cost_type,
        cost_date=cost_date,
        description=description,
        quantity=quantity,
        unit_cost=unit_cost,
        amount=amount,
        status=status,
        resource=resource,
        material_issue=material_issue,
        notes=notes,
        created_by=created_by,
        approved_by=created_by if auto_approve else None,
        approved_at=timezone.now() if auto_approve else None,
    )

    # Post voucher if approved
    voucher = None
    if post_voucher and status == "APPROVED":
        voucher = _post_cost_voucher(entry, created_by)
        entry.voucher = voucher
        entry.status = "POSTED"
        entry.posted_by = created_by
        entry.save(update_fields=["voucher", "status", "posted_by"])

    # Update project and phase cost totals
    if status in ("APPROVED", "POSTED"):
        _update_cost_totals(project, phase, amount)

    _log(created_by, "CREATE", "ProjectCostEntry", entry.pk, {
        "entry_number": entry_number,
        "project": project.project_number,
        "cost_type": cost_type,
        "amount": str(amount),
        "status": entry.status,
    })

    return entry


def _post_cost_voucher(entry, user):
    """Create a JOURNAL voucher for a posted cost entry."""
    from apps.accounts.models import Voucher, VoucherLine, LedgerAccount

    plant = entry.project.plant
    voucher_number = get_next_doc_number(plant, "JNL", "JNL")

    voucher = Voucher.objects.create(
        plant=plant,
        voucher_number=voucher_number,
        voucher_type=Voucher.VoucherType.JOURNAL,
        voucher_date=entry.cost_date,
        narration=(
            f"Project cost: {entry.project.project_number} — "
            f"{entry.get_cost_type_display()} — {entry.description}"
        ),
        total_amount=entry.amount,
        status=Voucher.VoucherStatus.POSTED,
        created_by=user,
    )

    try:
        wip_ledger = LedgerAccount.objects.get(
            plant=plant, sub_type="PROJECT_WIP", is_system=True
        )
        payable_ledger = LedgerAccount.objects.get(
            plant=plant, sub_type="ACCOUNTS_PAYABLE", is_system=True
        )
        VoucherLine.objects.create(
            voucher=voucher,
            ledger=wip_ledger,
            debit_amount=entry.amount,
            credit_amount=Decimal("0.00"),
            narration=f"Project WIP: {entry.project.project_number} | {entry.entry_number}",
        )
        VoucherLine.objects.create(
            voucher=voucher,
            ledger=payable_ledger,
            debit_amount=Decimal("0.00"),
            credit_amount=entry.amount,
            narration=f"Cost accrual: {entry.entry_number}",
        )
    except LedgerAccount.DoesNotExist:
        pass  # System ledgers not configured yet

    return voucher


def _update_cost_totals(project, phase, amount: Decimal):
    """Update denormalized cost totals on project and phase."""
    from apps.projects.models import Project, ProjectPhase

    Project.objects.filter(pk=project.pk).update(
        total_cost_incurred=models_f_add("total_cost_incurred", amount)
    )
    project.refresh_from_db(fields=["total_cost_incurred"])

    if phase:
        ProjectPhase.objects.filter(pk=phase.pk).update(
            cost_incurred=models_f_add("cost_incurred", amount)
        )


def models_f_add(field: str, amount: Decimal):
    """Return a Django F expression for safe concurrent addition."""
    from django.db.models import F
    return F(field) + amount


# ═══════════════════════════════════════════════════════════════════
# APPROVE BUDGET
# ═══════════════════════════════════════════════════════════════════

@transaction.atomic
def approve_budget(
    budget,
    approved_by,
    *,
    notes: str = "",
) -> "ProjectBudget":
    """
    Approve a ProjectBudget.

    Steps:
    1. Validate budget is in DRAFT or SUBMITTED status.
    2. Recompute total_amount from budget lines.
    3. Set budget.status = APPROVED.
    4. Update project.approved_budget to this budget's total_amount.
    5. AuditLog + Notification to project manager.
    """
    from apps.projects.models import ProjectBudget
    from django.db.models import Sum

    if budget.status not in ("DRAFT", "SUBMITTED"):
        raise ValueError(
            f"Budget '{budget.budget_number}' is in status '{budget.status}' "
            "and cannot be approved."
        )

    # Recompute total from lines
    total = budget.lines.aggregate(t=Sum("amount"))["t"] or Decimal("0.00")
    budget.total_amount = _two(total)
    budget.status = "APPROVED"
    budget.approved_by = approved_by
    budget.approved_at = timezone.now()
    if notes:
        budget.notes = notes
    budget.save(update_fields=[
        "total_amount", "status", "approved_by", "approved_at", "notes"
    ])

    # Update project approved_budget
    project = budget.project
    project.approved_budget = budget.total_amount
    project.save(update_fields=["approved_budget"])

    _log(approved_by, "UPDATE", "ProjectBudget", budget.pk, {
        "budget_number": budget.budget_number,
        "status": "APPROVED",
        "total_amount": str(budget.total_amount),
        "project": project.project_number,
    })

    if project.project_manager:
        _notify(
            project.project_manager,
            f"Budget Approved: {budget.budget_number}",
            f"Budget '{budget.title}' (₹{budget.total_amount:,.2f}) for project "
            f"'{project.name}' has been approved.",
            "ProjectBudget", budget.pk,
        )

    return budget


# ═══════════════════════════════════════════════════════════════════
# GENERATE PROJECT INVOICE
# ═══════════════════════════════════════════════════════════════════

@transaction.atomic
def generate_project_invoice(
    project,
    invoice_type: str,
    invoice_date: date,
    subtotal: Decimal,
    *,
    phase=None,
    tax_amount: Decimal = Decimal("0"),
    due_date: date = None,
    milestone_description: str = "",
    billing_period_from: date = None,
    billing_period_to: date = None,
    notes: str = "",
    created_by=None,
    auto_approve: bool = False,
    post_to_sales: bool = False,
) -> "ProjectInvoice":
    """
    Raise a project invoice.

    Steps:
    1. Validate project is ACTIVE.
    2. Generate invoice_number (PIN/YYYY-YY/00001).
    3. Compute total_amount = subtotal + tax_amount.
    4. Create ProjectInvoice.
    5. If post_to_sales=True → create sales.Invoice + accounts.Voucher.
    6. Update project.total_invoiced.
    """
    from apps.projects.models import ProjectInvoice

    if project.status not in ("ACTIVE", "DRAFT"):
        raise ValueError(
            f"Cannot invoice project '{project.project_number}' "
            f"in status '{project.status}'."
        )

    subtotal = _two(subtotal)
    tax_amount = _two(tax_amount)
    total_amount = _two(subtotal + tax_amount)

    invoice_number = get_next_doc_number(project.plant, "PIN", "PIN")
    status = "APPROVED" if auto_approve else "DRAFT"

    invoice = ProjectInvoice.objects.create(
        invoice_number=invoice_number,
        project=project,
        phase=phase,
        invoice_type=invoice_type,
        invoice_date=invoice_date,
        due_date=due_date,
        status=status,
        billing_period_from=billing_period_from,
        billing_period_to=billing_period_to,
        milestone_description=milestone_description,
        subtotal=subtotal,
        tax_amount=tax_amount,
        total_amount=total_amount,
        notes=notes,
        created_by=created_by,
        approved_by=created_by if auto_approve else None,
        approved_at=timezone.now() if auto_approve else None,
    )

    # Post to sales/accounts if requested and approved
    if post_to_sales and status == "APPROVED":
        sales_inv, voucher = _post_invoice_to_sales(invoice, created_by)
        invoice.sales_invoice = sales_inv
        invoice.voucher = voucher
        invoice.status = "POSTED"
        invoice.save(update_fields=["sales_invoice", "voucher", "status"])

    # Update project totals
    from apps.projects.models import Project as Proj
    Proj.objects.filter(pk=project.pk).update(
        total_invoiced=models_f_add("total_invoiced", total_amount)
    )
    project.refresh_from_db(fields=["total_invoiced"])

    _log(created_by, "CREATE", "ProjectInvoice", invoice.pk, {
        "invoice_number": invoice_number,
        "project": project.project_number,
        "invoice_type": invoice_type,
        "total_amount": str(total_amount),
        "status": invoice.status,
    })

    if project.project_manager:
        _notify(
            project.project_manager,
            f"Invoice Raised: {invoice_number}",
            f"Invoice {invoice_number} (₹{total_amount:,.2f}) raised for "
            f"project '{project.name}'.",
            "ProjectInvoice", invoice.pk,
        )

    return invoice


def _post_invoice_to_sales(invoice, user):
    """Attempt to create a linked sales.Invoice and accounts.Voucher."""
    from apps.accounts.models import Voucher, VoucherLine, LedgerAccount

    plant = invoice.project.plant
    voucher_number = get_next_doc_number(plant, "JNL", "JNL")

    voucher = Voucher.objects.create(
        plant=plant,
        voucher_number=voucher_number,
        voucher_type=Voucher.VoucherType.JOURNAL,
        voucher_date=invoice.invoice_date,
        narration=(
            f"Project invoice: {invoice.project.project_number} — "
            f"{invoice.invoice_number}"
        ),
        total_amount=invoice.total_amount,
        status=Voucher.VoucherStatus.POSTED,
        created_by=user,
    )

    try:
        ar_ledger = LedgerAccount.objects.get(
            plant=plant, sub_type="ACCOUNTS_RECEIVABLE", is_system=True
        )
        revenue_ledger = LedgerAccount.objects.get(
            plant=plant, sub_type="PROJECT_REVENUE", is_system=True
        )
        VoucherLine.objects.create(
            voucher=voucher,
            ledger=ar_ledger,
            debit_amount=invoice.total_amount,
            credit_amount=Decimal("0.00"),
            narration=f"AR: {invoice.invoice_number}",
        )
        VoucherLine.objects.create(
            voucher=voucher,
            ledger=revenue_ledger,
            debit_amount=Decimal("0.00"),
            credit_amount=invoice.subtotal,
            narration=f"Revenue: {invoice.project.project_number}",
        )
        if invoice.tax_amount:
            try:
                tax_ledger = LedgerAccount.objects.get(
                    plant=plant, sub_type="OUTPUT_TAX", is_system=True
                )
                VoucherLine.objects.create(
                    voucher=voucher,
                    ledger=tax_ledger,
                    debit_amount=Decimal("0.00"),
                    credit_amount=invoice.tax_amount,
                    narration=f"Tax on {invoice.invoice_number}",
                )
            except LedgerAccount.DoesNotExist:
                pass
    except LedgerAccount.DoesNotExist:
        pass

    # Attempt to create a sales.Invoice stub
    sales_invoice = None
    try:
        from apps.sales.models import Invoice as SalesInvoice
        customer = invoice.project.customer
        if customer:
            from apps.core.models import DocSequence
            si_number = get_next_doc_number(plant, "SI", "SI")
            sales_invoice = SalesInvoice.objects.create(
                plant=plant,
                invoice_number=si_number,
                customer=customer,
                invoice_date=invoice.invoice_date,
                due_date=invoice.due_date,
                total_amount=invoice.total_amount,
                status="POSTED",
                created_by=user,
                notes=f"Auto-generated from project invoice {invoice.invoice_number}",
            )
    except Exception:
        pass  # Sales integration optional

    return sales_invoice, voucher


# ═══════════════════════════════════════════════════════════════════
# CLOSE PROJECT
# ═══════════════════════════════════════════════════════════════════

@transaction.atomic
def close_project(
    project,
    closure_date: date,
    closure_reason: str = "COMPLETED",
    *,
    signed_off_by=None,
    client_sign_off: bool = False,
    client_sign_off_date: date = None,
    lessons_learned: str = "",
    notes: str = "",
) -> "ProjectClosure":
    """
    Formally close a project.

    Steps:
    1. Validate project is ACTIVE or ON_HOLD.
    2. Compute profitability snapshot.
    3. Create ProjectClosure record.
    4. Set project.status = CLOSED; record actual_end.
    5. AuditLog + Notification.
    """
    from apps.projects.models import ProjectClosure

    if project.status not in ("ACTIVE", "ON_HOLD", "COMPLETED"):
        raise ValueError(
            f"Cannot close project '{project.project_number}' "
            f"in status '{project.status}'."
        )

    if ProjectClosure.objects.filter(project=project).exists():
        raise ValueError(
            f"Project '{project.project_number}' is already closed."
        )

    # Profitability snapshot
    total_revenue = _two(project.total_invoiced)
    total_cost = _two(project.total_cost_incurred)
    gross_profit = _two(total_revenue - total_cost)
    gross_margin_pct = (
        _two(gross_profit / total_revenue * 100) if total_revenue else Decimal("0.00")
    )
    budget_variance = _two(project.approved_budget - total_cost)

    closure = ProjectClosure.objects.create(
        project=project,
        closure_date=closure_date,
        closure_reason=closure_reason,
        total_revenue=total_revenue,
        total_cost=total_cost,
        gross_profit=gross_profit,
        gross_margin_pct=gross_margin_pct,
        approved_budget=project.approved_budget,
        budget_variance=budget_variance,
        signed_off_by=signed_off_by,
        signed_off_at=timezone.now() if signed_off_by else None,
        client_sign_off=client_sign_off,
        client_sign_off_date=client_sign_off_date,
        lessons_learned=lessons_learned,
        notes=notes,
    )

    # Update project status
    project.status = "CLOSED"
    project.actual_end = closure_date
    project.save(update_fields=["status", "actual_end"])

    _log(signed_off_by, "UPDATE", "ProjectClosure", closure.pk, {
        "project": project.project_number,
        "closure_reason": closure_reason,
        "gross_profit": str(gross_profit),
        "gross_margin_pct": str(gross_margin_pct),
        "budget_variance": str(budget_variance),
    })

    if project.project_manager:
        _notify(
            project.project_manager,
            f"Project Closed: {project.project_number}",
            f"Project '{project.name}' has been closed. "
            f"GP: ₹{gross_profit:,.2f} ({gross_margin_pct}%), "
            f"Budget variance: ₹{budget_variance:,.2f}.",
            "ProjectClosure", closure.pk,
        )

    return closure


# ═══════════════════════════════════════════════════════════════════
# GET PROJECT PROFITABILITY
# ═══════════════════════════════════════════════════════════════════

def get_project_profitability(project) -> dict:
    """
    Return a comprehensive profitability report for a project.

    Includes:
    - Budget vs. actual cost breakdown by cost_type
    - Revenue vs. cost
    - Phase-wise cost breakdown
    - Resource cost summary
    - Invoice summary
    """
    from apps.projects.models import ProjectCostEntry, ProjectBudgetLine
    from django.db.models import Sum, Count

    # Cost by type
    cost_by_type = (
        ProjectCostEntry.objects
        .filter(project=project, status__in=("APPROVED", "POSTED"))
        .values("cost_type")
        .annotate(total=Sum("amount"), count=Count("id"))
        .order_by("cost_type")
    )

    # Budget by type
    approved_budgets = project.budgets.filter(status="APPROVED")
    budget_by_type = {}
    for bgt in approved_budgets:
        for line in bgt.lines.values("cost_type").annotate(total=Sum("amount")):
            ct = line["cost_type"]
            budget_by_type[ct] = budget_by_type.get(ct, Decimal("0")) + _two(line["total"])

    # Build comparison rows
    all_types = {r["cost_type"] for r in cost_by_type} | set(budget_by_type.keys())
    cost_map = {r["cost_type"]: _two(r["total"]) for r in cost_by_type}

    type_breakdown = []
    for ct in sorted(all_types):
        actual = cost_map.get(ct, Decimal("0"))
        budgeted = budget_by_type.get(ct, Decimal("0"))
        variance = _two(budgeted - actual)
        type_breakdown.append({
            "cost_type": ct,
            "budgeted": budgeted,
            "actual": actual,
            "variance": variance,
            "variance_pct": (
                _two(variance / budgeted * 100) if budgeted else Decimal("0.00")
            ),
        })

    # Phase-wise costs
    phase_costs = (
        ProjectCostEntry.objects
        .filter(project=project, status__in=("APPROVED", "POSTED"))
        .values("phase__name", "phase__phase_number")
        .annotate(total=Sum("amount"))
        .order_by("phase__phase_number")
    )

    # Resource costs (labour)
    resource_costs = (
        ProjectCostEntry.objects
        .filter(
            project=project,
            cost_type="LABOUR",
            status__in=("APPROVED", "POSTED"),
        )
        .values("resource__employee__id")
        .annotate(total=Sum("amount"), hours=Sum("quantity"))
        .order_by("-total")
    )

    # Invoice summary
    from apps.projects.models import ProjectInvoice
    invoice_summary = (
        ProjectInvoice.objects
        .filter(project=project)
        .values("status")
        .annotate(count=Count("id"), total=Sum("total_amount"))
    )
    total_invoiced = _two(
        ProjectInvoice.objects
        .filter(project=project, status__in=("APPROVED", "POSTED", "PAID"))
        .aggregate(t=Sum("total_amount"))["t"] or 0
    )
    total_received = _two(
        ProjectInvoice.objects
        .filter(project=project)
        .aggregate(t=Sum("amount_received"))["t"] or 0
    )

    total_cost = _two(project.total_cost_incurred)
    total_revenue = total_invoiced
    gross_profit = _two(total_revenue - total_cost)
    gross_margin_pct = (
        _two(gross_profit / total_revenue * 100) if total_revenue else Decimal("0.00")
    )

    return {
        "project_number": project.project_number,
        "project_name": project.name,
        "status": project.status,
        "contract_value": project.contract_value,
        "approved_budget": project.approved_budget,
        "total_cost_incurred": total_cost,
        "budget_utilisation_pct": project.budget_utilisation_pct,
        "total_invoiced": total_invoiced,
        "total_received": total_received,
        "outstanding_receivable": _two(total_invoiced - total_received),
        "gross_profit": gross_profit,
        "gross_margin_pct": gross_margin_pct,
        "budget_variance": _two(project.approved_budget - total_cost),
        "cost_by_type": type_breakdown,
        "phase_costs": [
            {
                "phase": r["phase__name"] or "Unassigned",
                "phase_number": r["phase__phase_number"],
                "total": _two(r["total"]),
            }
            for r in phase_costs
        ],
        "invoice_summary": list(invoice_summary),
    }
