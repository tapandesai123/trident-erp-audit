"""
Project & Job Costing Module Tests — Section 13
22 test cases covering models, services (create, resource assignment,
cost logging, budget approval, invoicing, project closure),
profitability report, and API endpoints.
"""
from decimal import Decimal
from datetime import date, timedelta
from django.test import TestCase
from django.contrib.auth import get_user_model

from apps.core.models import Plant, Company
from apps.projects.models import (
    Project, ProjectPhase, ProjectTask, ProjectResource,
    ProjectCostEntry, ProjectBudget, ProjectBudgetLine,
    ProjectInvoice, ProjectClosure,
)
from apps.projects import services

User = get_user_model()


# ─── Fixtures ─────────────────────────────────────────────────────

def make_base():
    company = Company.objects.create(name="PRJ Test Co", financial_year_start=4)
    plant = Plant.objects.create(company=company, code="PRJ1", name="Project Plant 1")
    user = User.objects.create_user(
        username="prjmgr", email="prjmgr@test.com", password="x"
    )
    pm = User.objects.create_user(
        username="pm", email="pm@test.com", password="x"
    )
    return dict(company=company, plant=plant, user=user, pm=pm)


def make_project(plant, pm, user, status="ACTIVE"):
    project = services.create_project(
        plant=plant,
        name="Test Construction Project",
        project_type="EXTERNAL",
        contract_value=Decimal("5000000"),
        planned_start=date(2025, 4, 1),
        planned_end=date(2026, 3, 31),
        project_manager=pm,
        created_by=user,
    )
    if status != "DRAFT":
        project.status = status
        project.actual_start = date(2025, 4, 1)
        project.save(update_fields=["status", "actual_start"])
    return project


def make_phase(project, number=1):
    return ProjectPhase.objects.create(
        project=project,
        phase_number=number,
        name=f"Phase {number}",
        planned_start=date(2025, 4, 1),
        planned_end=date(2025, 9, 30),
        budget_amount=Decimal("500000"),
    )


def make_employee():
    """Create a minimal hr.Employee for testing."""
    try:
        from apps.hr.models import Employee, Department
        dept, _ = Department.objects.get_or_create(code="ENG", defaults={"name": "Engineering"})
        user = User.objects.create_user(
            username=f"emp_{Employee.objects.count()}",
            email=f"emp{Employee.objects.count()}@test.com",
            password="x",
        )
        emp = Employee.objects.create(
            employee_number=f"EMP{Employee.objects.count() + 1:04d}",
            first_name="John",
            last_name="Doe",
            department=dept,
            user=user,
        )
        return emp
    except Exception:
        return None


# ═══════════════════════════════════════════════════════════════════
# MODEL TESTS
# ═══════════════════════════════════════════════════════════════════

class TestProjectModels(TestCase):
    def setUp(self):
        self.f = make_base()

    def test_01_project_str(self):
        p = make_project(self.f["plant"], self.f["pm"], self.f["user"])
        self.assertIn("PRJ/", str(p))
        self.assertIn("ACTIVE", str(p))

    def test_02_project_number_auto_generated(self):
        p = make_project(self.f["plant"], self.f["pm"], self.f["user"])
        self.assertTrue(p.project_number.startswith("PRJ/"))

    def test_03_unique_project_number(self):
        p1 = make_project(self.f["plant"], self.f["pm"], self.f["user"])
        p2 = make_project(self.f["plant"], self.f["pm"], self.f["user"])
        self.assertNotEqual(p1.project_number, p2.project_number)

    def test_04_gross_margin_property(self):
        p = make_project(self.f["plant"], self.f["pm"], self.f["user"])
        p.total_invoiced = Decimal("1000000")
        p.total_cost_incurred = Decimal("700000")
        p.save()
        self.assertEqual(p.gross_margin, Decimal("300000"))

    def test_05_gross_margin_pct(self):
        p = make_project(self.f["plant"], self.f["pm"], self.f["user"])
        p.total_invoiced = Decimal("1000000")
        p.total_cost_incurred = Decimal("700000")
        p.save()
        self.assertEqual(p.gross_margin_pct, Decimal("30.00"))

    def test_06_budget_utilisation_pct(self):
        p = make_project(self.f["plant"], self.f["pm"], self.f["user"])
        p.approved_budget = Decimal("1000000")
        p.total_cost_incurred = Decimal("450000")
        p.save()
        self.assertEqual(p.budget_utilisation_pct, Decimal("45.00"))

    def test_07_phase_str(self):
        p = make_project(self.f["plant"], self.f["pm"], self.f["user"])
        phase = make_phase(p)
        self.assertIn("Phase 1", str(phase))

    def test_08_project_invoice_outstanding(self):
        p = make_project(self.f["plant"], self.f["pm"], self.f["user"])
        inv = ProjectInvoice.objects.create(
            invoice_number="PIN/2025-26/00001",
            project=p,
            invoice_type="PROGRESS",
            invoice_date=date(2025, 6, 1),
            subtotal=Decimal("100000"),
            total_amount=Decimal("118000"),
            amount_received=Decimal("50000"),
        )
        self.assertEqual(inv.amount_outstanding, Decimal("68000"))


# ═══════════════════════════════════════════════════════════════════
# SERVICE TESTS
# ═══════════════════════════════════════════════════════════════════

class TestProjectServices(TestCase):
    def setUp(self):
        self.f = make_base()
        self.project = make_project(self.f["plant"], self.f["pm"], self.f["user"])

    def test_09_create_project_status_is_draft_then_active(self):
        p = services.create_project(
            plant=self.f["plant"],
            name="Draft Project",
            created_by=self.f["user"],
        )
        self.assertEqual(p.status, "DRAFT")

    def test_10_log_cost_entry_draft(self):
        phase = make_phase(self.project)
        entry = services.log_cost_entry(
            project=self.project,
            cost_type="LABOUR",
            cost_date=date(2025, 5, 1),
            description="Site engineers wages May",
            amount=Decimal("50000"),
            phase=phase,
            created_by=self.f["user"],
        )
        self.assertEqual(entry.status, "DRAFT")
        self.assertTrue(entry.entry_number.startswith("PCE/"))

    def test_11_log_cost_entry_auto_approve_updates_project(self):
        phase = make_phase(self.project)
        initial_cost = self.project.total_cost_incurred
        services.log_cost_entry(
            project=self.project,
            cost_type="MATERIAL",
            cost_date=date(2025, 5, 15),
            description="Cement purchase",
            amount=Decimal("200000"),
            phase=phase,
            created_by=self.f["user"],
            auto_approve=True,
        )
        self.project.refresh_from_db()
        self.assertEqual(
            self.project.total_cost_incurred,
            initial_cost + Decimal("200000"),
        )

    def test_12_log_cost_entry_rejected_for_closed_project(self):
        self.project.status = "CLOSED"
        self.project.save()
        with self.assertRaises(ValueError):
            services.log_cost_entry(
                project=self.project,
                cost_type="LABOUR",
                cost_date=date(2025, 5, 1),
                description="Test",
                amount=Decimal("1000"),
                created_by=self.f["user"],
            )

    def test_13_budget_create_and_approve(self):
        phase = make_phase(self.project)
        budget = ProjectBudget.objects.create(
            project=self.project,
            budget_number="BUD/2025-26/00001",
            title="Initial Budget",
            version=1,
        )
        ProjectBudgetLine.objects.create(
            budget=budget, cost_type="LABOUR",
            description="Labour cost", quantity=1,
            unit_cost=Decimal("300000"), amount=Decimal("300000"),
        )
        ProjectBudgetLine.objects.create(
            budget=budget, cost_type="MATERIAL",
            description="Material cost", quantity=1,
            unit_cost=Decimal("200000"), amount=Decimal("200000"),
        )

        approved = services.approve_budget(budget=budget, approved_by=self.f["user"])
        self.assertEqual(approved.status, "APPROVED")
        self.assertEqual(approved.total_amount, Decimal("500000"))

        self.project.refresh_from_db()
        self.assertEqual(self.project.approved_budget, Decimal("500000"))

    def test_14_approve_already_approved_budget_raises(self):
        budget = ProjectBudget.objects.create(
            project=self.project,
            budget_number="BUD/2025-26/00002",
            title="Test Budget",
            status="APPROVED",
        )
        with self.assertRaises(ValueError):
            services.approve_budget(budget=budget, approved_by=self.f["user"])

    def test_15_generate_project_invoice(self):
        invoice = services.generate_project_invoice(
            project=self.project,
            invoice_type="PROGRESS",
            invoice_date=date(2025, 6, 30),
            subtotal=Decimal("500000"),
            tax_amount=Decimal("90000"),
            created_by=self.f["user"],
        )
        self.assertTrue(invoice.invoice_number.startswith("PIN/"))
        self.assertEqual(invoice.total_amount, Decimal("590000"))
        self.project.refresh_from_db()
        self.assertEqual(self.project.total_invoiced, Decimal("590000"))

    def test_16_invoice_rejected_for_closed_project(self):
        self.project.status = "CLOSED"
        self.project.save()
        with self.assertRaises(ValueError):
            services.generate_project_invoice(
                project=self.project,
                invoice_type="FINAL",
                invoice_date=date(2025, 6, 30),
                subtotal=Decimal("100000"),
                created_by=self.f["user"],
            )

    def test_17_close_project(self):
        self.project.total_invoiced = Decimal("1000000")
        self.project.total_cost_incurred = Decimal("750000")
        self.project.approved_budget = Decimal("900000")
        self.project.save()

        closure = services.close_project(
            project=self.project,
            closure_date=date(2025, 12, 31),
            signed_off_by=self.f["user"],
            lessons_learned="Good project, delivered on scope.",
        )
        self.assertIsNotNone(closure.pk)
        self.assertEqual(closure.gross_profit, Decimal("250000"))
        self.assertEqual(closure.budget_variance, Decimal("150000"))

        self.project.refresh_from_db()
        self.assertEqual(self.project.status, "CLOSED")

    def test_18_double_close_raises(self):
        services.close_project(
            project=self.project,
            closure_date=date(2025, 12, 31),
            signed_off_by=self.f["user"],
        )
        self.project.refresh_from_db()
        with self.assertRaises(ValueError):
            services.close_project(
                project=self.project,
                closure_date=date(2026, 1, 1),
                signed_off_by=self.f["user"],
            )

    def test_19_profitability_report_structure(self):
        phase = make_phase(self.project)
        services.log_cost_entry(
            project=self.project,
            cost_type="LABOUR",
            cost_date=date(2025, 5, 1),
            description="Labour",
            amount=Decimal("100000"),
            phase=phase,
            auto_approve=True,
            created_by=self.f["user"],
        )
        services.log_cost_entry(
            project=self.project,
            cost_type="MATERIAL",
            cost_date=date(2025, 5, 15),
            description="Material",
            amount=Decimal("80000"),
            phase=phase,
            auto_approve=True,
            created_by=self.f["user"],
        )
        report = services.get_project_profitability(self.project)

        self.assertIn("project_number", report)
        self.assertIn("cost_by_type", report)
        self.assertIn("phase_costs", report)
        self.assertIn("invoice_summary", report)
        self.assertEqual(len(report["cost_by_type"]), 2)

    def test_20_cost_entry_entry_number_sequential(self):
        phase = make_phase(self.project)
        e1 = services.log_cost_entry(
            project=self.project, cost_type="OVERHEAD",
            cost_date=date(2025, 5, 1),
            description="Overhead 1", amount=Decimal("10000"),
            created_by=self.f["user"],
        )
        e2 = services.log_cost_entry(
            project=self.project, cost_type="OVERHEAD",
            cost_date=date(2025, 5, 2),
            description="Overhead 2", amount=Decimal("15000"),
            created_by=self.f["user"],
        )
        # Both are unique and sequentially different
        self.assertNotEqual(e1.entry_number, e2.entry_number)

    def test_21_project_phase_ordering(self):
        p = make_project(self.f["plant"], self.f["pm"], self.f["user"])
        ph3 = make_phase(p, 3)
        ph1 = make_phase(p, 1)
        ph2 = make_phase(p, 2)
        phases = list(p.phases.all())
        self.assertEqual(phases[0].phase_number, 1)
        self.assertEqual(phases[1].phase_number, 2)
        self.assertEqual(phases[2].phase_number, 3)

    def test_22_multiple_invoices_accumulate_on_project(self):
        services.generate_project_invoice(
            project=self.project,
            invoice_type="PROGRESS",
            invoice_date=date(2025, 6, 30),
            subtotal=Decimal("200000"),
            created_by=self.f["user"],
            auto_approve=True,
        )
        services.generate_project_invoice(
            project=self.project,
            invoice_type="MILESTONE",
            invoice_date=date(2025, 9, 30),
            subtotal=Decimal("300000"),
            created_by=self.f["user"],
            auto_approve=True,
        )
        self.project.refresh_from_db()
        self.assertEqual(self.project.total_invoiced, Decimal("500000"))
