from django.apps import AppConfig


class WebtelConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.webtel"
    verbose_name = "Webtel GST Integration"

    def ready(self):
        pass
