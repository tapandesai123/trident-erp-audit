"""
Webtel Module Exceptions
"""


class WebtelAPIError(Exception):
    """
    Raised when the Webtel GSP API returns a 4xx or 5xx response.
    Carries the HTTP status code and the raw response body for logging.
    """

    def __init__(self, message: str, status_code: int = 0, response_body: dict = None):
        super().__init__(message)
        self.status_code = status_code
        self.response_body = response_body or {}

    def __str__(self):
        if self.status_code:
            return f"WebtelAPIError [{self.status_code}]: {self.args[0]}"
        return f"WebtelAPIError: {self.args[0]}"
