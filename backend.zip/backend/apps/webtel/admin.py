"""Webtel Module Admin — Section 7"""
from django.contrib import admin
from apps.webtel.models import (
    WebtelConfig,
    IRNRequest,
    EwayBillRequest,
    GSTR2BData,
    GSTR2BLine,
    GSTR2BReconciliation,
    VendorGSTMismatch,
    GSTRFilingLog,
)


@admin.register(WebtelConfig)
class WebtelConfigAdmin(admin.ModelAdmin):
    list_display  = ["plant", "environment", "gstin", "is_active",
                     "auto_generate_irn", "auto_generate_eway",
                     "last_tested_at", "last_test_result"]
    list_filter   = ["environment", "is_active"]
    readonly_fields = ["last_tested_at", "last_test_result", "access_token_expiry"]
    fieldsets = (
        ("Plant & Environment", {
            "fields": ("plant", "environment", "gstin", "is_active")
        }),
        ("API Credentials", {
            "fields": ("username", "client_id"),
            "classes": ("collapse",),
        }),
        ("API URLs", {
            "fields": ("irn_base_url", "eway_base_url", "gstr_base_url"),
            "classes": ("collapse",),
        }),
        ("Settings", {
            "fields": ("eway_bill_threshold", "auto_generate_irn", "auto_generate_eway")
        }),
        ("Token Status", {
            "fields": ("access_token_expiry", "last_tested_at", "last_test_result"),
            "classes": ("collapse",),
        }),
    )


@admin.register(IRNRequest)
class IRNRequestAdmin(admin.ModelAdmin):
    list_display  = ["invoice", "action", "status", "irn", "ack_number",
                     "api_call_duration_ms", "created_at", "plant"]
    list_filter   = ["action", "status", "plant"]
    search_fields = ["invoice__invoice_number", "irn", "ack_number", "error_code"]
    readonly_fields = ["request_payload", "response_data", "signed_invoice", "signed_qr_code"]

    def has_change_permission(self, request, obj=None):
        return False  # IRN logs are immutable


@admin.register(EwayBillRequest)
class EwayBillRequestAdmin(admin.ModelAdmin):
    list_display  = ["invoice", "action", "status", "eway_bill_number",
                     "api_call_duration_ms", "created_at", "plant"]
    list_filter   = ["action", "status", "plant"]
    search_fields = ["invoice__invoice_number", "eway_bill_number", "error_code"]
    readonly_fields = ["request_payload", "response_data"]


class GSTR2BLineInline(admin.TabularInline):
    model  = GSTR2BLine
    extra  = 0
    fields = ["supplier_gstin", "doc_number", "doc_date", "taxable_value",
              "cgst", "sgst", "igst", "itc_availability"]
    readonly_fields = fields


@admin.register(GSTR2BData)
class GSTR2BDataAdmin(admin.ModelAdmin):
    list_display  = ["plant", "return_period", "fetch_status", "total_records",
                     "matched_count", "mismatched_count", "missing_in_2b_count",
                     "fetched_at", "reconciled_at"]
    list_filter   = ["fetch_status", "plant"]
    readonly_fields = ["total_records", "total_igst", "total_cgst", "total_sgst",
                       "matched_count", "mismatched_count", "missing_in_2b_count",
                       "extra_in_2b_count", "fetched_at", "reconciled_at"]
    inlines = [GSTR2BLineInline]


@admin.register(GSTR2BReconciliation)
class GSTR2BReconciliationAdmin(admin.ModelAdmin):
    list_display  = ["gstr2b", "match_status", "our_doc_number", "our_supplier_gstin",
                     "our_taxable_value", "diff_cgst", "diff_sgst", "diff_igst"]
    list_filter   = ["match_status", "gstr2b__plant"]
    search_fields = ["our_doc_number", "our_supplier_gstin"]


@admin.register(VendorGSTMismatch)
class VendorGSTMismatchAdmin(admin.ModelAdmin):
    list_display  = ["vendor", "mismatch_type", "status", "our_amount", "their_amount",
                     "difference", "invoice_ref", "email_sent_at", "resolved_at"]
    list_filter   = ["mismatch_type", "status", "plant"]
    search_fields = ["vendor__name", "invoice_ref"]


@admin.register(GSTRFilingLog)
class GSTRFilingLogAdmin(admin.ModelAdmin):
    list_display  = ["plant", "return_type", "return_period", "status", "arn",
                     "total_tax_paid", "filed_at", "filed_by"]
    list_filter   = ["return_type", "status", "plant"]
    readonly_fields = ["summary_data", "filed_at"]
