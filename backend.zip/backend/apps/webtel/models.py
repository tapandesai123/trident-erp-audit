"""
Webtel Module Models — Section 7
GST Integration: IRN generation, e-Way Bill, GSTR-2B reconciliation

Models:
  WebtelConfig       — API credentials per plant (encrypted at rest via env)
  IRNRequest         — Full log of every e-invoice API call + response (immutable audit)
  EwayBillRequest    — e-Way Bill generation/extension/cancellation log
  GSTR2BData         — Raw 2B data pulled from Webtel for a return period
  GSTR2BLine         — Per-document line from 2B (one row per vendor invoice)
  GSTR2BReconciliation — Match 2B line against purchase MRR/VendorBill
  VendorGSTMismatch  — Vendors whose 2B data doesn't match our purchase register
  GSTRFilingLog      — Record of GSTR-1 / GSTR-3B filing submissions
"""
import uuid
from django.conf import settings
from django.db import models
from django.utils import timezone
from apps.core.models import TimeStampedModel, UUIDModel, Plant


# ══════════════════════════════════════════════════════════════════
# WEBTEL CONFIGURATION
# ══════════════════════════════════════════════════════════════════

class WebtelConfig(UUIDModel, TimeStampedModel):
    """
    Webtel API credentials per plant. Only one active config per plant.
    Credentials stored as env vars in production — these fields store
    the env var KEY NAMES (not the actual secrets) for security.
    """
    class APIEnvironment(models.TextChoices):
        SANDBOX    = "SANDBOX",    "Sandbox / Testing"
        PRODUCTION = "PRODUCTION", "Production"

    plant           = models.OneToOneField(Plant, on_delete=models.CASCADE, related_name="webtel_config")
    environment     = models.CharField(
        max_length=15, choices=APIEnvironment.choices, default=APIEnvironment.SANDBOX
    )

    # API endpoint base URLs
    irn_base_url    = models.URLField(
        max_length=300,
        default="https://gsp.webtel.in/einvoice/",
        help_text="Webtel e-Invoice API base URL"
    )
    eway_base_url   = models.URLField(
        max_length=300,
        default="https://gsp.webtel.in/ewaybill/",
        help_text="Webtel e-Way Bill API base URL"
    )
    gstr_base_url   = models.URLField(
        max_length=300,
        default="https://gsp.webtel.in/gst/",
        help_text="Webtel GSTR API base URL"
    )

    # Credentials (env var key names — actual values from environment)
    username        = models.CharField(max_length=100, help_text="Webtel portal username")
    # Password stored as env var: WEBTEL_PASSWORD_{PLANT_CODE}
    client_id       = models.CharField(max_length=100, blank=True, help_text="OAuth client_id")
    gstin           = models.CharField(max_length=15, help_text="GSTIN for API auth — must match plant")

    # GSP token (refreshed via Celery)
    access_token        = models.TextField(blank=True, help_text="Current OAuth access token")
    access_token_expiry = models.DateTimeField(null=True, blank=True)
    refresh_token       = models.TextField(blank=True)

    # Limits & options
    eway_bill_threshold = models.DecimalField(
        max_digits=12, decimal_places=2, default=50000,
        help_text="Invoice value above which e-Way Bill is mandatory (₹)"
    )
    auto_generate_irn   = models.BooleanField(
        default=True,
        help_text="Auto-generate IRN when invoice is confirmed"
    )
    is_irn_mandatory    = models.BooleanField(
        default=True,
        help_text=(
            "Set to True only if aggregate turnover > ₹5Cr (e-invoicing mandate). "
            "When False, IRN will NOT be auto-generated for any invoice. (BUG-029)"
        )
    )
    auto_generate_eway  = models.BooleanField(
        default=True,
        help_text="Auto-generate e-Way Bill when DC gate-out happens"
    )

    is_active       = models.BooleanField(default=True)
    last_tested_at  = models.DateTimeField(null=True, blank=True)
    last_test_result = models.CharField(max_length=20, blank=True)  # SUCCESS / FAILED

    configured_by   = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, related_name="webtel_configs"
    )

    class Meta:
        verbose_name = "Webtel Configuration"

    def __str__(self):
        return f"Webtel Config — {self.plant.code} ({self.environment})"

    @property
    def token_is_valid(self):
        if not self.access_token or not self.access_token_expiry:
            return False
        return timezone.now() < self.access_token_expiry


# ══════════════════════════════════════════════════════════════════
# IRN REQUEST LOG
# ══════════════════════════════════════════════════════════════════

class IRNRequest(UUIDModel, TimeStampedModel):
    """
    Immutable log of every e-Invoice API call.
    Records full request payload and response for audit trail.
    IRN once generated cannot be modified (immutable by GST law).
    """
    class IRNAction(models.TextChoices):
        GENERATE   = "GENERATE",   "Generate IRN"
        CANCEL     = "CANCEL",     "Cancel IRN"
        GET_DETAILS = "GET_DETAILS", "Get IRN Details"
        GET_QR     = "GET_QR",     "Get QR Code"

    class IRNStatus(models.TextChoices):
        PENDING  = "PENDING",  "API Call Pending"
        SUCCESS  = "SUCCESS",  "Success"
        FAILED   = "FAILED",   "Failed"
        DUPLICATE = "DUPLICATE","Duplicate (IRN Already Exists)"

    plant           = models.ForeignKey(Plant, on_delete=models.CASCADE, related_name="irn_requests")
    invoice         = models.ForeignKey(
        "sales.Invoice", on_delete=models.PROTECT, related_name="irn_requests"
    )
    action          = models.CharField(max_length=15, choices=IRNAction.choices)
    status          = models.CharField(max_length=15, choices=IRNStatus.choices, default=IRNStatus.PENDING)

    # API payload snapshot (JSON stored as text for full audit)
    request_payload = models.JSONField(default=dict, help_text="Full JSON sent to Webtel API")
    response_data   = models.JSONField(default=dict, help_text="Full JSON response from Webtel")

    # Result fields (extracted from response on success)
    irn             = models.CharField(max_length=100, blank=True, help_text="64-char IRN hash")
    ack_number      = models.CharField(max_length=20, blank=True)
    ack_date        = models.CharField(max_length=30, blank=True)
    signed_invoice  = models.TextField(blank=True, help_text="Signed JSON from IRP")
    signed_qr_code  = models.TextField(blank=True, help_text="Signed QR string from IRP")

    # Error details
    error_code      = models.CharField(max_length=20, blank=True)
    error_message   = models.TextField(blank=True)

    # Cancel-specific
    cancel_reason   = models.CharField(max_length=300, blank=True)
    cancelled_at    = models.DateTimeField(null=True, blank=True)

    # Timing
    api_call_duration_ms = models.IntegerField(
        default=0, help_text="API response time in milliseconds"
    )
    requested_by    = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True,
        related_name="irn_requests_made"
    )

    class Meta:
        ordering = ["-created_at"]
        verbose_name = "IRN Request Log"

    def __str__(self):
        return f"IRN {self.action} — {self.invoice.invoice_number} ({self.status})"


# ══════════════════════════════════════════════════════════════════
# E-WAY BILL REQUEST LOG
# ══════════════════════════════════════════════════════════════════

class EwayBillRequest(UUIDModel, TimeStampedModel):
    """
    Log of every e-Way Bill API call (generate / extend / cancel / update).
    """
    class EwayAction(models.TextChoices):
        GENERATE   = "GENERATE",   "Generate e-Way Bill"
        EXTEND     = "EXTEND",     "Extend Validity"
        CANCEL     = "CANCEL",     "Cancel e-Way Bill"
        UPDATE_PART_B = "UPDATE_PART_B", "Update Part-B (Vehicle)"
        GET_DETAILS = "GET_DETAILS", "Get e-Way Bill Details"
        REJECT      = "REJECT",    "Reject e-Way Bill"

    class EwayStatus(models.TextChoices):
        PENDING  = "PENDING",  "Pending"
        SUCCESS  = "SUCCESS",  "Success"
        FAILED   = "FAILED",   "Failed"

    plant           = models.ForeignKey(Plant, on_delete=models.CASCADE, related_name="eway_requests")
    invoice         = models.ForeignKey(
        "sales.Invoice", on_delete=models.PROTECT, related_name="eway_requests"
    )
    action          = models.CharField(max_length=20, choices=EwayAction.choices)
    status          = models.CharField(max_length=10, choices=EwayStatus.choices, default=EwayStatus.PENDING)

    # API call data
    request_payload = models.JSONField(default=dict)
    response_data   = models.JSONField(default=dict)

    # Result fields
    eway_bill_number   = models.CharField(max_length=20, blank=True)
    eway_bill_date     = models.CharField(max_length=30, blank=True)
    eway_bill_valid_until = models.CharField(max_length=30, blank=True)
    alert_message      = models.TextField(blank=True)

    # Extension-specific
    extended_from      = models.CharField(max_length=30, blank=True)
    extended_to        = models.CharField(max_length=30, blank=True)
    extension_reason   = models.CharField(max_length=300, blank=True)

    # Cancel-specific
    cancel_reason      = models.CharField(max_length=300, blank=True)

    # Error
    error_code         = models.CharField(max_length=20, blank=True)
    error_message      = models.TextField(blank=True)

    api_call_duration_ms = models.IntegerField(default=0)
    requested_by       = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True,
        related_name="eway_requests_made"
    )

    class Meta:
        ordering = ["-created_at"]
        verbose_name = "e-Way Bill Request Log"

    def __str__(self):
        return f"EWB {self.action} — {self.invoice.invoice_number} ({self.status})"


# ══════════════════════════════════════════════════════════════════
# GSTR-2B DATA
# ══════════════════════════════════════════════════════════════════

class GSTR2BData(UUIDModel, TimeStampedModel):
    """
    Raw GSTR-2B data fetched from GST portal via Webtel for a return period.
    One record per plant per month.
    """
    class FetchStatus(models.TextChoices):
        PENDING     = "PENDING",     "Pending Fetch"
        FETCHED     = "FETCHED",     "Fetched Successfully"
        FETCH_FAILED = "FETCH_FAILED","Fetch Failed"
        RECONCILED  = "RECONCILED",  "Reconciliation Complete"

    plant           = models.ForeignKey(Plant, on_delete=models.CASCADE, related_name="gstr2b_data")
    return_period   = models.CharField(max_length=7, help_text="MMYYYY e.g. 012026")
    fetch_status    = models.CharField(
        max_length=15, choices=FetchStatus.choices, default=FetchStatus.PENDING
    )

    # Summary from 2B
    total_records   = models.IntegerField(default=0)
    total_igst      = models.DecimalField(max_digits=18, decimal_places=2, default=0)
    total_cgst      = models.DecimalField(max_digits=18, decimal_places=2, default=0)
    total_sgst      = models.DecimalField(max_digits=18, decimal_places=2, default=0)
    total_cess      = models.DecimalField(max_digits=18, decimal_places=2, default=0)

    # Reconciliation summary
    matched_count   = models.IntegerField(default=0)
    mismatched_count = models.IntegerField(default=0)
    missing_in_2b_count = models.IntegerField(default=0, help_text="In our books but not in 2B")
    extra_in_2b_count   = models.IntegerField(default=0, help_text="In 2B but not in our books")

    fetched_at      = models.DateTimeField(null=True, blank=True)
    reconciled_at   = models.DateTimeField(null=True, blank=True)
    fetched_by      = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True,
        related_name="gstr2b_fetches"
    )
    raw_response    = models.JSONField(
        default=dict, help_text="Raw API response stored for re-processing"
    )
    error_message   = models.TextField(blank=True)

    class Meta:
        unique_together = [("plant", "return_period")]
        ordering = ["-return_period"]
        verbose_name = "GSTR-2B Data"

    def __str__(self):
        return f"GSTR-2B {self.plant.code} — {self.return_period} ({self.fetch_status})"


class GSTR2BLine(models.Model):
    """
    Per-document line from GSTR-2B (one row per vendor invoice reported by vendor).
    Section B2B: invoices from registered suppliers.
    """
    class DocType(models.TextChoices):
        INVOICE     = "INV",  "Invoice"
        CREDIT_NOTE = "CR",   "Credit Note"
        DEBIT_NOTE  = "DR",   "Debit Note"
        ISD         = "ISD",  "Input Service Distributor"

    gstr2b          = models.ForeignKey(GSTR2BData, on_delete=models.CASCADE, related_name="lines")

    # Supplier details (from 2B)
    supplier_gstin  = models.CharField(max_length=15)
    supplier_name   = models.CharField(max_length=200, blank=True)
    doc_type        = models.CharField(max_length=5, choices=DocType.choices)
    doc_number      = models.CharField(max_length=50, help_text="Vendor's invoice number")
    doc_date        = models.DateField()

    # Tax amounts from 2B
    taxable_value   = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    igst            = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    cgst            = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    sgst            = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    cess            = models.DecimalField(max_digits=15, decimal_places=2, default=0)

    # ITC eligibility
    itc_availability = models.CharField(
        max_length=50, blank=True,
        help_text="Full / Ineligible / Proportionate etc. (as per 2B)"
    )
    reason_for_ineligibility = models.CharField(max_length=200, blank=True)

    place_of_supply = models.CharField(max_length=5, blank=True)
    reverse_charge  = models.BooleanField(default=False)
    source          = models.CharField(max_length=20, blank=True, help_text="EINV / ECOM / MANUAL")

    class Meta:
        ordering = ["supplier_gstin", "doc_date"]
        indexes = [
            models.Index(fields=["supplier_gstin", "doc_number"]),
            models.Index(fields=["gstr2b", "supplier_gstin"]),
        ]

    def __str__(self):
        return f"2B: {self.supplier_gstin} / {self.doc_number} / ₹{self.taxable_value}"


# ══════════════════════════════════════════════════════════════════
# GSTR-2B RECONCILIATION
# ══════════════════════════════════════════════════════════════════

class GSTR2BReconciliation(UUIDModel, TimeStampedModel):
    """
    Reconciliation result: each 2B line matched against our purchase register.
    One record per 2B line after reconciliation run.
    """
    class MatchStatus(models.TextChoices):
        MATCHED        = "MATCHED",        "Matched — Amount & GSTIN OK"
        AMT_MISMATCH   = "AMT_MISMATCH",   "Amount Mismatch"
        GSTIN_MISMATCH = "GSTIN_MISMATCH", "GSTIN Mismatch"
        DATE_MISMATCH  = "DATE_MISMATCH",  "Date Mismatch"
        MISSING_IN_BOOKS = "MISSING_IN_BOOKS", "In 2B but NOT in our books"
        MISSING_IN_2B  = "MISSING_IN_2B",  "In our books but NOT in 2B"
        ACCEPTED       = "ACCEPTED",       "Accepted (manual override)"
        IGNORED        = "IGNORED",        "Ignored (not claimable)"

    gstr2b          = models.ForeignKey(GSTR2BData, on_delete=models.CASCADE, related_name="reconciliations")
    gstr2b_line     = models.OneToOneField(
        GSTR2BLine, on_delete=models.CASCADE, null=True, blank=True,
        related_name="reconciliation"
    )

    # Our corresponding purchase record
    vendor_bill     = models.ForeignKey(
        "accounts.VendorBill", on_delete=models.SET_NULL,
        null=True, blank=True, related_name="gstr2b_recon"
    )
    mrr             = models.ForeignKey(
        "purchase.MRR", on_delete=models.SET_NULL,
        null=True, blank=True, related_name="gstr2b_recon"
    )

    match_status    = models.CharField(
        max_length=20, choices=MatchStatus.choices, default=MatchStatus.MISSING_IN_BOOKS
    )

    # Our books values
    our_supplier_gstin = models.CharField(max_length=15, blank=True)
    our_doc_number     = models.CharField(max_length=50, blank=True)
    our_doc_date       = models.DateField(null=True, blank=True)
    our_taxable_value  = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    our_igst           = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    our_cgst           = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    our_sgst           = models.DecimalField(max_digits=15, decimal_places=2, default=0)

    # Difference
    diff_taxable    = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    diff_igst       = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    diff_cgst       = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    diff_sgst       = models.DecimalField(max_digits=15, decimal_places=2, default=0)

    # Resolution
    resolution_notes = models.TextField(blank=True)
    resolved_by      = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="gstr2b_resolutions"
    )
    resolved_at      = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["match_status", "-created_at"]
        verbose_name = "GSTR-2B Reconciliation"

    def __str__(self):
        return f"Recon: {self.gstr2b_line.doc_number if self.gstr2b_line else 'N/A'} — {self.match_status}"


# ══════════════════════════════════════════════════════════════════
# VENDOR GST MISMATCH
# ══════════════════════════════════════════════════════════════════

class VendorGSTMismatch(UUIDModel, TimeStampedModel):
    """
    Vendors whose GSTR-2B data doesn't match our purchase register.
    Auto-email sent to vendor with discrepancy details.
    """
    class MismatchType(models.TextChoices):
        INVOICE_NOT_FILED   = "NOT_FILED",     "Vendor Did Not File Invoice in 2B"
        AMOUNT_MISMATCH     = "AMT_MISMATCH",  "Amount Mismatch in 2B vs Our Books"
        GSTIN_WRONG         = "GSTIN_WRONG",   "Wrong GSTIN on Invoice"
        DATE_MISMATCH       = "DATE_MISMATCH", "Invoice Date Mismatch"
        EXTRA_IN_2B         = "EXTRA_IN_2B",   "Extra Invoice in 2B Not in Our Books"

    class ResolutionStatus(models.TextChoices):
        OPEN        = "OPEN",       "Open"
        EMAIL_SENT  = "EMAIL_SENT", "Reminder Email Sent"
        VENDOR_REPLIED = "VENDOR_REPLIED", "Vendor Replied"
        RESOLVED    = "RESOLVED",   "Resolved"
        DISPUTED    = "DISPUTED",   "Disputed"

    plant           = models.ForeignKey(Plant, on_delete=models.CASCADE, related_name="vendor_gst_mismatches")
    gstr2b          = models.ForeignKey(GSTR2BData, on_delete=models.CASCADE, related_name="mismatches")
    vendor          = models.ForeignKey(
        "masters.Vendor", on_delete=models.PROTECT, related_name="gst_mismatches"
    )
    vendor_bill     = models.ForeignKey(
        "accounts.VendorBill", on_delete=models.SET_NULL,
        null=True, blank=True, related_name="gst_mismatches"
    )
    gstr2b_recon    = models.ForeignKey(
        GSTR2BReconciliation, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="mismatches"
    )

    mismatch_type   = models.CharField(max_length=20, choices=MismatchType.choices)
    status          = models.CharField(
        max_length=20, choices=ResolutionStatus.choices, default=ResolutionStatus.OPEN
    )

    # Mismatch details
    our_amount      = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    their_amount    = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    difference      = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    invoice_ref     = models.CharField(max_length=100, blank=True)
    description     = models.TextField(blank=True)

    # Email tracking
    email_sent_at   = models.DateTimeField(null=True, blank=True)
    email_sent_to   = models.CharField(max_length=200, blank=True)
    vendor_reply    = models.TextField(blank=True)
    vendor_replied_at = models.DateTimeField(null=True, blank=True)

    resolution_notes = models.TextField(blank=True)
    resolved_at      = models.DateTimeField(null=True, blank=True)
    resolved_by      = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="gst_mismatch_resolutions"
    )

    class Meta:
        ordering = ["-created_at"]
        verbose_name = "Vendor GST Mismatch"

    def __str__(self):
        return f"Mismatch: {self.vendor.name} — {self.mismatch_type} ({self.status})"


# ══════════════════════════════════════════════════════════════════
# GSTR FILING LOG
# ══════════════════════════════════════════════════════════════════

class GSTRFilingLog(UUIDModel, TimeStampedModel):
    """
    Record of GSTR-1 / GSTR-3B filing submissions via Webtel.
    One record per return type per period.
    """
    class ReturnType(models.TextChoices):
        GSTR1  = "GSTR1",  "GSTR-1 (Outward Supplies)"
        GSTR3B = "GSTR3B", "GSTR-3B (Monthly Summary)"
        GSTR2B = "GSTR2B", "GSTR-2B (ITC Auto-Draft)"

    class FilingStatus(models.TextChoices):
        PREPARED  = "PREPARED",  "Prepared"
        SUBMITTED = "SUBMITTED", "Submitted (Not Filed)"
        FILED     = "FILED",     "Filed"
        FAILED    = "FAILED",    "Filing Failed"

    plant           = models.ForeignKey(Plant, on_delete=models.CASCADE, related_name="gstr_filings")
    return_type     = models.CharField(max_length=10, choices=ReturnType.choices)
    return_period   = models.CharField(max_length=7, help_text="MMYYYY")
    status          = models.CharField(
        max_length=15, choices=FilingStatus.choices, default=FilingStatus.PREPARED
    )

    # Summary data (snapshot at time of filing)
    summary_data    = models.JSONField(default=dict)

    # Webtel response
    reference_id    = models.CharField(max_length=100, blank=True, help_text="ARN / Reference from GST portal")
    arn             = models.CharField(max_length=50, blank=True, help_text="Acknowledgement Reference Number")
    filed_at        = models.DateTimeField(null=True, blank=True)
    error_message   = models.TextField(blank=True)

    # Tax payment (for 3B)
    total_tax_paid  = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    challan_number  = models.CharField(max_length=50, blank=True)

    filed_by        = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True,
        related_name="gstr_filings"
    )

    class Meta:
        unique_together = [("plant", "return_type", "return_period")]
        ordering = ["-return_period", "return_type"]
        verbose_name = "GSTR Filing Log"

    def __str__(self):
        return f"{self.return_type} {self.return_period} — {self.plant.code} ({self.status})"
