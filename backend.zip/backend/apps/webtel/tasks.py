"""
Webtel Module Celery Tasks — Section 7
"""
from celery import shared_task
from django.utils import timezone
import logging

logger = logging.getLogger(__name__)


@shared_task(bind=True, name="webtel.refresh_all_tokens", max_retries=3, default_retry_delay=60)
def refresh_all_tokens(self):
    """
    Every 5 hours: Refresh Webtel OAuth tokens for all active plants.
    Tokens typically valid 6 hours — refresh proactively at 5 hours.
    """
    try:
        from apps.webtel.models import WebtelConfig
        from apps.webtel.services import refresh_access_token

        configs = WebtelConfig.objects.filter(is_active=True)
        results = []
        for config in configs:
            success = refresh_access_token(config)
            results.append({"plant": config.plant.code, "success": success})
            if success:
                logger.info(f"[WEBTEL] Token refreshed for {config.plant.code}")
            else:
                logger.error(f"[WEBTEL] Token refresh FAILED for {config.plant.code}")

        return {"refreshed": len(results), "results": results}
    except Exception as exc:
        raise self.retry(exc=exc, countdown=2 ** self.request.retries * 60)


@shared_task(bind=True, name="webtel.auto_generate_irn_for_confirmed_invoices", max_retries=3, default_retry_delay=60)
def auto_generate_irn_for_confirmed_invoices(self):
    """
    Every 30 minutes: Auto-generate IRN for confirmed Tax Invoices
    where IRN is missing and auto_generate_irn is True in config.
    Handles cases where IRN wasn't generated immediately due to API issues.
    """
    try:
        from apps.sales.models import Invoice
        from apps.webtel.models import WebtelConfig
        from apps.webtel.services import generate_irn
        from django.contrib.auth import get_user_model

        User = get_user_model()
        system_user = User.objects.filter(is_superuser=True).first()

        generated = failed = 0
        for config in WebtelConfig.objects.filter(is_active=True, auto_generate_irn=True, is_irn_mandatory=True):
            plant = config.plant
            pending = Invoice.objects.filter(
                plant=plant,
                invoice_type="TAX_INVOICE",
                status__in=["CONFIRMED", "IRN_PENDING"],
                irn="",
                total_amount__gte=1,
            ).select_related("customer", "plant")[:50]  # Process max 50 at a time

            for invoice in pending:
                try:
                    generate_irn(invoice, system_user, plant)
                    generated += 1
                    logger.info(f"[WEBTEL] IRN auto-generated for {invoice.invoice_number}")
                except Exception as e:
                    failed += 1
                    logger.warning(f"[WEBTEL] IRN auto-gen failed for {invoice.invoice_number}: {e}")

        return {"irn_generated": generated, "irn_failed": failed, "run_at": str(timezone.now())}
    except Exception as exc:
        raise self.retry(exc=exc, countdown=2 ** self.request.retries * 60)


@shared_task(bind=True, name="webtel.check_expiring_eway_bills", max_retries=3, default_retry_delay=60)
def check_expiring_eway_bills(self):
    """
    Daily 7:00 AM: Check for e-Way Bills expiring in the next 4 hours.
    Sends alerts to logistics team.
    """
    try:
        from datetime import date, timedelta
        from apps.sales.models import Invoice
        from apps.core.models import Notification

        tomorrow = date.today() + timedelta(days=1)
        expiring = Invoice.objects.filter(
            eway_bill_valid_until__lte=tomorrow,
            eway_bill_valid_until__gte=date.today(),
            eway_bill_number__gt="",
            status__in=["CONFIRMED", "IRN_DONE"],
        ).select_related("customer", "plant")

        count = 0
        for inv in expiring:
            Notification.objects.create(
                user_id=None,
                title=f"e-Way Bill Expiring: {inv.invoice_number}",
                message=(
                    f"e-Way Bill {inv.eway_bill_number} for invoice {inv.invoice_number} "
                    f"({inv.customer.name}) expires on {inv.eway_bill_valid_until}. "
                    f"Extend if goods are still in transit."
                ),
                module="webtel",
                object_id=str(inv.pk),
            )
            count += 1

        logger.info(f"[WEBTEL] {count} e-Way Bills flagged as expiring soon")
        return {"expiring_eway_bills": count}
    except Exception as exc:
        raise self.retry(exc=exc, countdown=2 ** self.request.retries * 60)


@shared_task(bind=True, name="webtel.monthly_gstr2b_fetch", max_retries=3, default_retry_delay=60)
def monthly_gstr2b_fetch(self):
    """
    Runs on 14th of each month: Auto-fetch GSTR-2B for previous month.
    (2B is typically available from 12th-14th of the following month)
    """
    try:
        from datetime import date
        from apps.webtel.models import WebtelConfig
        from apps.webtel.services import fetch_gstr2b, reconcile_2b_with_purchase
        from django.contrib.auth import get_user_model

        User = get_user_model()
        system_user = User.objects.filter(is_superuser=True).first()

        today = date.today()
        if today.month == 1:
            prev_month, prev_year = 12, today.year - 1
        else:
            prev_month, prev_year = today.month - 1, today.year

        return_period = f"{prev_month:02d}{prev_year}"
        results = []

        for config in WebtelConfig.objects.filter(is_active=True):
            plant = config.plant
            try:
                gstr2b = fetch_gstr2b(plant, return_period, system_user)
                recon = reconcile_2b_with_purchase(gstr2b, system_user)
                results.append({
                    "plant": plant.code,
                    "period": return_period,
                    "lines": gstr2b.total_records,
                    "matched": recon["matched"],
                    "mismatched": recon["mismatched"],
                })
                logger.info(f"[WEBTEL] GSTR-2B fetched and reconciled for {plant.code} — {return_period}")
            except Exception as e:
                results.append({"plant": plant.code, "error": str(e)})
                logger.error(f"[WEBTEL] GSTR-2B fetch failed for {plant.code}: {e}")

        return {"period": return_period, "results": results}
    except Exception as exc:
        raise self.retry(exc=exc, countdown=2 ** self.request.retries * 60)


@shared_task(bind=True, name="webtel.send_monthly_mismatch_emails", max_retries=3, default_retry_delay=60)
def send_monthly_mismatch_emails(self):
    """
    Runs on 16th of each month: Send mismatch notification emails to vendors.
    Gives vendors time to correct before their next filing.
    """
    try:
        from datetime import date
        from apps.webtel.models import WebtelConfig, GSTR2BData
        from apps.webtel.services import send_vendor_mismatch_emails

        today = date.today()
        if today.month == 1:
            prev_month, prev_year = 12, today.year - 1
        else:
            prev_month, prev_year = today.month - 1, today.year

        return_period = f"{prev_month:02d}{prev_year}"
        total_emails = 0

        for config in WebtelConfig.objects.filter(is_active=True):
            plant = config.plant
            try:
                count = send_vendor_mismatch_emails(plant, return_period)
                total_emails += count
                logger.info(f"[WEBTEL] Sent {count} mismatch emails for {plant.code} — {return_period}")
            except Exception as e:
                logger.error(f"[WEBTEL] Mismatch email failed for {plant.code}: {e}")

        return {"period": return_period, "emails_sent": total_emails}
    except Exception as exc:
        raise self.retry(exc=exc, countdown=2 ** self.request.retries * 60)
