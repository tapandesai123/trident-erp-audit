"""
Webtel Module Tests — Section 7
Covers: config setup, IRN generation (mock), e-Way Bill, GSTR-2B fetch/reconcile,
        vendor mismatch detection, email sending, filing log.
"""
from decimal import Decimal
from datetime import date
from unittest.mock import patch, MagicMock

from django.test import TestCase
from django.contrib.auth import get_user_model

User = get_user_model()


class BaseWebtelTest(TestCase):

    def setUp(self):
        from apps.core.models import Company, Plant
        from apps.masters.models import VendorGroup, Vendor, CustomerGroup, Customer

        self.company = Company.objects.create(name="Trident Paper Box", gstin="24AAKFT4708J2ZY")
        self.plant = Plant.objects.create(
            company=self.company, code="PARDI", name="Pardi Plant",
            gstin="24AAKFT4708J2ZY", state_code="24", is_active=True,
        )
        self.user = User.objects.create_user(username="webtel_user", password="pass123")
        if hasattr(self.user, "plant"):
            self.user.plant = self.plant
            self.user.save()

        vg = VendorGroup.objects.create(name="Suppliers")
        self.vendor = Vendor.objects.create(
            plant=self.plant, vendor_group=vg,
            name="GST Supplier", gstin="27AAAAA1234A1Z5",
            tds_rate=Decimal("2"), tds_section="194C",
        )

        cg = CustomerGroup.objects.create(name="Regular")
        self.customer = Customer.objects.create(
            plant=self.plant, customer_group=cg,
            name="Registered Customer", gstin="27BBBBB5678B1Z2",
        )

        # WebtelConfig in SANDBOX mode
        from apps.webtel.models import WebtelConfig
        self.config = WebtelConfig.objects.create(
            plant=self.plant,
            environment=WebtelConfig.APIEnvironment.SANDBOX,
            username="test_user",
            client_id="test_client",
            gstin="24AAKFT4708J2ZY",
            is_active=True,
            configured_by=self.user,
        )

        # Minimal Invoice for IRN tests
        self._create_invoice()

    def _create_invoice(self):
        from apps.sales.models import Invoice, InvoiceLine
        from apps.masters.models import UOM, Item, ItemGroup

        ig = ItemGroup.objects.create(code="FG", name="Finished Goods")
        uom = UOM.objects.create(code="NOS", name="Numbers")
        item = Item.objects.create(
            plant=self.plant, item_group=ig,
            code="BOX001", name="Corrugated Box 400x300x200",
            uom=uom, hsn_code="4819",
        )

        self.invoice = Invoice.objects.create(
            plant=self.plant,
            invoice_number="INV/2025-26/00001",
            invoice_date=date.today(),
            invoice_type="TAX_INVOICE",
            status="CONFIRMED",
            customer=self.customer,
            customer_gstin=self.customer.gstin,
            is_interstate=False,
            place_of_supply="24",
            taxable_amount=Decimal("50000"),
            cgst_amount=Decimal("4500"),
            sgst_amount=Decimal("4500"),
            igst_amount=Decimal("0"),
            total_amount=Decimal("59000"),
            discount_amount=Decimal("0"),
            round_off=Decimal("0"),
            prepared_by=self.user,
        )
        InvoiceLine.objects.create(
            invoice=self.invoice, line_no=1,
            item=item, description="Corrugated Box 400x300x200",
            hsn_code="4819", qty=Decimal("1000"), uom=uom,
            unit_rate=Decimal("50"), taxable_amt=Decimal("50000"),
            gst_pct=Decimal("18"), cgst_pct=Decimal("9"), sgst_pct=Decimal("9"),
            igst_pct=Decimal("0"), cgst_amount=Decimal("4500"),
            sgst_amount=Decimal("4500"), igst_amount=Decimal("0"),
            line_total=Decimal("59000"),
        )


# ── TEST GROUP 1: Config & Connection ────────────────────────────

class TestWebtelConfig(BaseWebtelTest):

    def test_01_config_created(self):
        """WebtelConfig created in SANDBOX mode."""
        from apps.webtel.models import WebtelConfig
        config = WebtelConfig.objects.get(plant=self.plant)
        self.assertEqual(config.environment, "SANDBOX")
        self.assertTrue(config.is_active)

    def test_02_token_invalid_initially(self):
        """Token is invalid initially (not yet refreshed)."""
        self.assertFalse(self.config.token_is_valid)

    def test_03_refresh_token_sandbox(self):
        """Token refresh in sandbox mode sets mock token."""
        from apps.webtel.services import refresh_access_token
        result = refresh_access_token(self.config)
        self.assertTrue(result)
        self.config.refresh_from_db()
        self.assertTrue(self.config.token_is_valid)
        self.assertIn("MOCK_TOKEN", self.config.access_token)

    def test_04_test_connection(self):
        """test_connection returns success=True in sandbox."""
        from apps.webtel.services import test_connection
        result = test_connection(self.config, self.user)
        self.assertTrue(result["success"])

    def test_05_get_config_raises_if_not_configured(self):
        """_get_config raises ValueError for unconfigured plant."""
        from apps.core.models import Plant, Company
        from apps.webtel.services import _get_config
        company2 = Company.objects.create(name="Other Co", gstin="29XXXXX1234X1ZX")
        other_plant = Plant.objects.create(
            company=company2, code="OTHER", name="Other", gstin="29XXXXX1234X1ZX",
            state_code="29", is_active=True,
        )
        with self.assertRaises(ValueError):
            _get_config(other_plant)


# ── TEST GROUP 2: IRN Generation ─────────────────────────────────

class TestIRNGeneration(BaseWebtelTest):

    def test_06_generate_irn_sandbox(self):
        """IRN generation in sandbox returns mock IRN and updates invoice."""
        from apps.webtel.services import generate_irn
        from apps.webtel.models import IRNRequest
        from apps.sales.models import Invoice

        irn_req = generate_irn(self.invoice, self.user, self.plant)

        self.assertEqual(irn_req.status, IRNRequest.IRNStatus.SUCCESS)
        self.assertNotEqual(irn_req.irn, "")
        self.assertEqual(len(irn_req.irn), 64)

        self.invoice.refresh_from_db()
        self.assertEqual(self.invoice.irn, irn_req.irn)
        self.assertEqual(self.invoice.status, Invoice.InvoiceStatus.IRN_DONE)

    def test_07_duplicate_irn_generation_raises(self):
        """Generating IRN on invoice that already has IRN raises ValueError."""
        from apps.webtel.services import generate_irn

        generate_irn(self.invoice, self.user, self.plant)
        self.invoice.refresh_from_db()

        with self.assertRaises(ValueError) as ctx:
            generate_irn(self.invoice, self.user, self.plant)
        self.assertIn("already generated", str(ctx.exception).lower())

    def test_08_irn_payload_built_correctly(self):
        """IRN payload has required NIC schema fields."""
        from apps.webtel.services import _build_irn_payload
        payload = _build_irn_payload(self.invoice)
        self.assertIn("Version", payload)
        self.assertIn("TranDtls", payload)
        self.assertIn("DocDtls", payload)
        self.assertIn("SellerDtls", payload)
        self.assertIn("BuyerDtls", payload)
        self.assertIn("ItemList", payload)
        self.assertIn("ValDtls", payload)
        self.assertEqual(payload["DocDtls"]["No"], "INV/2025-26/00001")
        self.assertEqual(payload["SellerDtls"]["Gstin"], "24AAKFT4708J2ZY")

    def test_09_cancel_irn(self):
        """Cancel IRN clears invoice.irn and marks invoice CANCELLED."""
        from apps.webtel.services import generate_irn, cancel_irn
        from apps.sales.models import Invoice

        generate_irn(self.invoice, self.user, self.plant)
        self.invoice.refresh_from_db()

        irn_req = cancel_irn(self.invoice, "ORDER_CANCELLED", self.user, self.plant)
        self.invoice.refresh_from_db()
        self.assertEqual(self.invoice.irn, "")
        self.assertEqual(self.invoice.status, Invoice.InvoiceStatus.CANCELLED)

    def test_10_irn_request_log_created(self):
        """IRNRequest log entries created for each API call."""
        from apps.webtel.services import generate_irn
        from apps.webtel.models import IRNRequest

        generate_irn(self.invoice, self.user, self.plant)
        count = IRNRequest.objects.filter(
            invoice=self.invoice, action=IRNRequest.IRNAction.GENERATE
        ).count()
        self.assertEqual(count, 1)


# ── TEST GROUP 3: e-Way Bill ─────────────────────────────────────

class TestEwayBill(BaseWebtelTest):

    def test_11_eway_below_threshold_raises(self):
        """e-Way Bill generation raises for invoice below threshold."""
        from apps.webtel.services import generate_eway_bill

        # Default threshold ₹50,000 — our invoice is ₹59,000 so should work.
        # Create small invoice to test threshold:
        self.invoice.total_amount = Decimal("30000")
        self.invoice.save(update_fields=["total_amount"])

        with self.assertRaises(ValueError) as ctx:
            generate_eway_bill(self.invoice, self.user, self.plant)
        self.assertIn("not required", str(ctx.exception).lower())

    def test_12_generate_eway_bill(self):
        """e-Way Bill generated successfully in sandbox."""
        from apps.webtel.services import generate_eway_bill
        from apps.webtel.models import EwayBillRequest

        req = generate_eway_bill(self.invoice, self.user, self.plant)
        self.assertEqual(req.status, EwayBillRequest.EwayStatus.SUCCESS)
        self.assertNotEqual(req.eway_bill_number, "")

        self.invoice.refresh_from_db()
        self.assertEqual(self.invoice.eway_bill_number, req.eway_bill_number)

    def test_13_duplicate_eway_raises(self):
        """Generating e-Way Bill when one already exists raises ValueError."""
        from apps.webtel.services import generate_eway_bill
        generate_eway_bill(self.invoice, self.user, self.plant)
        self.invoice.refresh_from_db()
        with self.assertRaises(ValueError):
            generate_eway_bill(self.invoice, self.user, self.plant)

    def test_14_cancel_eway_bill(self):
        """Cancel e-Way Bill clears invoice.eway_bill_number."""
        from apps.webtel.services import generate_eway_bill, cancel_eway_bill
        generate_eway_bill(self.invoice, self.user, self.plant)
        self.invoice.refresh_from_db()

        cancel_eway_bill(self.invoice, "ORDER_CANCELLED", self.user, self.plant)
        self.invoice.refresh_from_db()
        self.assertEqual(self.invoice.eway_bill_number, "")

    def test_15_eway_payload_structure(self):
        """e-Way Bill payload has required fields."""
        from apps.webtel.services import _build_eway_payload
        payload = _build_eway_payload(self.invoice)
        self.assertIn("supplyType", payload)
        self.assertIn("docNo", payload)
        self.assertIn("fromGstin", payload)
        self.assertIn("toGstin", payload)
        self.assertIn("itemList", payload)
        self.assertGreater(len(payload["itemList"]), 0)


# ── TEST GROUP 4: GSTR-2B Fetch & Reconciliation ─────────────────

class TestGSTR2BReconciliation(BaseWebtelTest):

    def test_16_fetch_gstr2b_sandbox(self):
        """Fetch GSTR-2B in sandbox returns FETCHED status."""
        from apps.webtel.services import fetch_gstr2b
        from apps.webtel.models import GSTR2BData

        period = date.today().strftime("%m%Y")
        gstr2b = fetch_gstr2b(self.plant, period, self.user)
        self.assertEqual(gstr2b.fetch_status, GSTR2BData.FetchStatus.FETCHED)
        self.assertEqual(gstr2b.return_period, period)

    def test_17_reconcile_missing_in_2b(self):
        """Bills in our books but absent from 2B are flagged as MISSING_IN_2B."""
        from apps.webtel.services import fetch_gstr2b, reconcile_2b_with_purchase
        from apps.webtel.models import GSTR2BData, GSTR2BReconciliation
        from apps.accounts.models import VendorBill

        # Create a passed vendor bill
        bill = VendorBill.objects.create(
            plant=self.plant,
            bill_number="VBILL/2025-26/00001",
            vendor_bill_ref="SUP-INV-001",
            vendor_bill_date=date.today(),
            received_date=date.today(),
            vendor=self.vendor,
            taxable_amount=Decimal("10000"),
            cgst_amount=Decimal("900"),
            sgst_amount=Decimal("900"),
            total_amount=Decimal("11800"),
            net_payable=Decimal("11800"),
            outstanding=Decimal("11800"),
            status="PASSED",
            chk_pr_authorised=True, chk_po_approved=True,
            chk_gate_entry_done=True, chk_mrr_qty_match=True,
            chk_qc_passed=True, chk_gst_copy_received=True,
            chk_accounts_paper_ok=True, chk_calculation_verified=True,
            received_by=self.user,
        )

        period = date.today().strftime("%m%Y")
        gstr2b = fetch_gstr2b(self.plant, period, self.user)
        # sandbox returns empty b2b, so our bill is MISSING_IN_2B
        result = reconcile_2b_with_purchase(gstr2b, self.user)

        self.assertGreaterEqual(result["missing_in_2b"], 1)

        # Check GSTR2BReconciliation record
        recon = GSTR2BReconciliation.objects.filter(
            vendor_bill=bill,
            match_status=GSTR2BReconciliation.MatchStatus.MISSING_IN_2B,
        ).first()
        self.assertIsNotNone(recon)

    def test_18_vendor_mismatch_created(self):
        """VendorGSTMismatch created for missing-in-2B bills."""
        from apps.webtel.services import fetch_gstr2b, reconcile_2b_with_purchase
        from apps.webtel.models import VendorGSTMismatch
        from apps.accounts.models import VendorBill

        VendorBill.objects.create(
            plant=self.plant,
            bill_number="VBILL/2025-26/00002",
            vendor_bill_ref="SUP-INV-002",
            vendor_bill_date=date.today(),
            received_date=date.today(),
            vendor=self.vendor,
            taxable_amount=Decimal("20000"),
            cgst_amount=Decimal("1800"),
            sgst_amount=Decimal("1800"),
            total_amount=Decimal("23600"),
            net_payable=Decimal("23600"),
            outstanding=Decimal("23600"),
            status="PASSED",
            chk_pr_authorised=True, chk_po_approved=True,
            chk_gate_entry_done=True, chk_mrr_qty_match=True,
            chk_qc_passed=True, chk_gst_copy_received=True,
            chk_accounts_paper_ok=True, chk_calculation_verified=True,
            received_by=self.user,
        )

        period = date.today().strftime("%m%Y")
        gstr2b = fetch_gstr2b(self.plant, period, self.user)
        reconcile_2b_with_purchase(gstr2b, self.user)

        mismatches = VendorGSTMismatch.objects.filter(
            plant=self.plant, gstr2b=gstr2b,
            mismatch_type=VendorGSTMismatch.MismatchType.INVOICE_NOT_FILED,
        )
        self.assertGreater(mismatches.count(), 0)

    def test_19_gstr2b_reconciliation_status_updated(self):
        """After reconcile, GSTR2BData status = RECONCILED."""
        from apps.webtel.services import fetch_gstr2b, reconcile_2b_with_purchase
        from apps.webtel.models import GSTR2BData

        period = date.today().strftime("%m%Y")
        gstr2b = fetch_gstr2b(self.plant, period, self.user)
        reconcile_2b_with_purchase(gstr2b, self.user)
        gstr2b.refresh_from_db()
        self.assertEqual(gstr2b.fetch_status, GSTR2BData.FetchStatus.RECONCILED)

    def test_20_duplicate_fetch_replaces_lines(self):
        """Re-fetching 2B for same period deletes old lines and re-imports."""
        from apps.webtel.services import fetch_gstr2b
        from apps.webtel.models import GSTR2BLine

        period = date.today().strftime("%m%Y")
        gstr2b1 = fetch_gstr2b(self.plant, period, self.user)
        count1 = GSTR2BLine.objects.filter(gstr2b=gstr2b1).count()
        # Re-fetch
        gstr2b2 = fetch_gstr2b(self.plant, period, self.user)
        self.assertEqual(gstr2b1.pk, gstr2b2.pk)  # Same record
        count2 = GSTR2BLine.objects.filter(gstr2b=gstr2b2).count()
        self.assertEqual(count1, count2)  # Same count (sandbox returns same empty response)


# ── TEST GROUP 5: Filing & Dashboard ─────────────────────────────

class TestGSTRFiling(BaseWebtelTest):

    def test_21_gstr1_submission(self):
        """GSTR-1 submission creates filing log in SUBMITTED status."""
        from apps.webtel.services import submit_gstr1
        from apps.webtel.models import GSTRFilingLog

        period = date.today().strftime("%m%Y")
        filing = submit_gstr1(self.plant, period, self.user)
        self.assertEqual(filing.return_type, "GSTR1")
        self.assertEqual(filing.return_period, period)
        self.assertEqual(filing.status, GSTRFilingLog.FilingStatus.SUBMITTED)

    def test_22_duplicate_filed_gstr1_raises(self):
        """Re-submitting already-FILED GSTR-1 raises ValueError."""
        from apps.webtel.services import submit_gstr1
        from apps.webtel.models import GSTRFilingLog

        period = date.today().strftime("%m%Y")
        filing = submit_gstr1(self.plant, period, self.user)
        filing.status = GSTRFilingLog.FilingStatus.FILED
        filing.arn = "AA242426021234567"
        filing.save()

        with self.assertRaises(ValueError) as ctx:
            submit_gstr1(self.plant, period, self.user)
        self.assertIn("already filed", str(ctx.exception).lower())

    def test_23_webtel_dashboard(self):
        """Dashboard returns all required tiles."""
        from apps.webtel.services import get_webtel_dashboard
        result = get_webtel_dashboard(self.plant)
        expected = [
            "irn_generated_this_month", "irn_failed_today",
            "eway_bills_this_month", "invoices_pending_irn",
            "invoices_irn_in_progress", "open_gst_mismatches",
        ]
        for key in expected:
            self.assertIn(key, result, f"Dashboard missing key: {key}")


# ── TEST GROUP 6: Task 12 — Live API Tests (responses mock) ──────

class TestLiveAPIWithResponsesMock(BaseWebtelTest):
    """
    Test live (SANDBOX=False) API calls using the `responses` library
    to mock HTTP at the requests level.
    """

    def _make_live_config(self):
        """Switch config to PRODUCTION mode for live API testing."""
        from apps.webtel.models import WebtelConfig
        self.config.environment = WebtelConfig.APIEnvironment.PRODUCTION
        self.config.access_token = "LIVE_TOKEN_TEST"
        self.config.access_token_expiry = __import__('django.utils.timezone', fromlist=['timezone']).timezone.now() + __import__('datetime').timedelta(hours=6)
        self.config.save()

    def test_24_irn_generation_live_stores_irn(self):
        """
        SANDBOX=False: successful IRN generation stores irn on Invoice.
        Uses responses library to mock the HTTP call.
        """
        try:
            import responses as responses_lib
        except ImportError:
            self.skipTest("responses library not installed")

        from apps.webtel.models import WebtelConfig
        import django.utils.timezone as tz
        import datetime

        # Switch to PRODUCTION environment
        self.config.environment = WebtelConfig.APIEnvironment.PRODUCTION
        self.config.access_token = "LIVE_TOKEN_TEST"
        self.config.access_token_expiry = tz.now() + datetime.timedelta(hours=6)
        self.config.save()

        fake_irn = "a" * 64
        mock_response = {
            "Status": "1",
            "Data": {
                "Irn": fake_irn,
                "AckNo": "123456789012345678",
                "AckDt": "2026-01-01 10:00:00",
                "SignedInvoice": "SIGNED_INV",
                "SignedQRCode": "QR_CODE_DATA",
            },
        }

        with responses_lib.RequestsMock() as rsps:
            # Mock token check endpoint
            rsps.add(responses_lib.POST, __import__('re').compile(r'.*/einvoice/generate'), json=mock_response, status=200)

            from apps.webtel.services import generate_irn
            from apps.webtel.models import IRNRequest
            from apps.sales.models import Invoice

            with self.settings(WEBTEL_CONFIG={
                "BASE_URL": "https://api.webtel.in/gsp/v3",
                "CLIENT_ID": "test_client",
                "CLIENT_SECRET": "test_secret",
                "GSP_USERNAME": "test_user",
                "GSP_PASSWORD": "test_pass",
                "SANDBOX": False,
            }):
                irn_req = generate_irn(self.invoice, self.user, self.plant)

            self.assertEqual(irn_req.status, IRNRequest.IRNStatus.SUCCESS)
            self.invoice.refresh_from_db()
            self.assertEqual(self.invoice.irn, fake_irn)
            self.assertEqual(self.invoice.ack_number, "123456789012345678")

    def test_25_live_401_triggers_token_refresh_and_retry(self):
        """
        SANDBOX=False: a 401 response triggers token refresh and the request retries.
        """
        try:
            import responses as responses_lib
        except ImportError:
            self.skipTest("responses library not installed")

        from apps.webtel.models import WebtelConfig
        import django.utils.timezone as tz
        import datetime

        self.config.environment = WebtelConfig.APIEnvironment.PRODUCTION
        self.config.access_token = "EXPIRED_TOKEN"
        self.config.access_token_expiry = tz.now() + datetime.timedelta(hours=6)
        self.config.save()

        fake_irn = "b" * 64
        mock_irn_response = {
            "Status": "1",
            "Data": {
                "Irn": fake_irn,
                "AckNo": "987654321012345678",
                "AckDt": "2026-01-02 10:00:00",
                "SignedInvoice": "SIGNED_INV_2",
                "SignedQRCode": "QR_CODE_DATA_2",
            },
        }
        mock_token_response = {
            "Status": "1",
            "Data": {"AuthToken": "NEW_LIVE_TOKEN"},
        }

        with responses_lib.RequestsMock() as rsps:
            import re
            # First call returns 401
            rsps.add(responses_lib.POST, re.compile(r'.*/einvoice/generate'), status=401, json={"error": "Unauthorized"})
            # Token refresh
            rsps.add(responses_lib.POST, re.compile(r'.*/auth/token'), json=mock_token_response, status=200)
            # Retry call succeeds
            rsps.add(responses_lib.POST, re.compile(r'.*/einvoice/generate'), json=mock_irn_response, status=200)

            with self.settings(WEBTEL_CONFIG={
                "BASE_URL": "https://api.webtel.in/gsp/v3",
                "CLIENT_ID": "test_client",
                "CLIENT_SECRET": "test_secret",
                "GSP_USERNAME": "test_user",
                "GSP_PASSWORD": "test_pass",
                "SANDBOX": False,
            }):
                from apps.webtel.services import generate_irn
                from apps.webtel.models import IRNRequest

                irn_req = generate_irn(self.invoice, self.user, self.plant)

            self.assertEqual(irn_req.status, IRNRequest.IRNStatus.SUCCESS)

    def test_26_gstr2b_fetch_creates_line_records(self):
        """
        SANDBOX=False: GSTR-2B fetch creates GSTR2BLine records from API response.
        """
        try:
            import responses as responses_lib
        except ImportError:
            self.skipTest("responses library not installed")

        from apps.webtel.models import WebtelConfig, GSTR2BLine
        import django.utils.timezone as tz
        import datetime

        self.config.environment = WebtelConfig.APIEnvironment.PRODUCTION
        self.config.access_token = "LIVE_TOKEN"
        self.config.access_token_expiry = tz.now() + datetime.timedelta(hours=6)
        self.config.save()

        period = "012026"
        mock_gstr2b_response = {
            "Status": "1",
            "Data": {
                "rtnprd": period,
                "b2b": [
                    {
                        "ctin": "27AAAAA1234A1Z5",
                        "tradeName": "Test Supplier",
                        "inv": [
                            {
                                "inum": "INV-001",
                                "idt": "01-01-2026",
                                "val": 10000,
                                "pos": "27",
                                "rchrg": "N",
                                "itcAvl": "Y",
                                "typ": "INV",
                                "srctyp": "GSTR1",
                                "items": [
                                    {"rt": 18, "igst": 0, "cgst": 900, "sgst": 900, "cess": 0}
                                ],
                            }
                        ],
                    }
                ],
            },
        }

        with responses_lib.RequestsMock() as rsps:
            import re
            rsps.add(responses_lib.GET, re.compile(r'.*/gstr2b/.*'), json=mock_gstr2b_response, status=200)

            with self.settings(WEBTEL_CONFIG={
                "BASE_URL": "https://api.webtel.in/gsp/v3",
                "CLIENT_ID": "test_client",
                "CLIENT_SECRET": "test_secret",
                "GSP_USERNAME": "test_user",
                "GSP_PASSWORD": "test_pass",
                "SANDBOX": False,
            }):
                from apps.webtel.services import fetch_gstr2b
                gstr2b = fetch_gstr2b(self.plant, period, self.user)

        lines = GSTR2BLine.objects.filter(gstr2b=gstr2b)
        self.assertEqual(lines.count(), 1)
        self.assertEqual(lines.first().supplier_gstin, "27AAAAA1234A1Z5")
        self.assertEqual(lines.first().doc_number, "INV-001")

    def test_27_mismatched_vendor_creates_vendor_gst_mismatch(self):
        """
        After GSTR-2B fetch with unmatched data, VendorGSTMismatch records are created.
        """
        from apps.webtel.services import fetch_gstr2b, reconcile_2b_with_purchase
        from apps.webtel.models import GSTR2BData, VendorGSTMismatch
        from apps.accounts.models import VendorBill

        # Create a vendor bill that won't match any 2B line (sandbox returns empty b2b)
        VendorBill.objects.create(
            plant=self.plant,
            bill_number="VBILL/2025-26/00099",
            vendor_bill_ref="MISMATCH-INV-099",
            vendor_bill_date=__import__('datetime').date.today(),
            received_date=__import__('datetime').date.today(),
            vendor=self.vendor,
            taxable_amount=Decimal("15000"),
            cgst_amount=Decimal("1350"),
            sgst_amount=Decimal("1350"),
            total_amount=Decimal("17700"),
            net_payable=Decimal("17700"),
            outstanding=Decimal("17700"),
            status="PASSED",
            chk_pr_authorised=True, chk_po_approved=True,
            chk_gate_entry_done=True, chk_mrr_qty_match=True,
            chk_qc_passed=True, chk_gst_copy_received=True,
            chk_accounts_paper_ok=True, chk_calculation_verified=True,
            received_by=self.user,
        )

        period = __import__('datetime').date.today().strftime("%m%Y")
        # sandbox returns empty b2b — so our bill will be MISSING_IN_2B → VendorGSTMismatch
        gstr2b = fetch_gstr2b(self.plant, period, self.user)
        reconcile_2b_with_purchase(gstr2b, self.user)

        mismatches = VendorGSTMismatch.objects.filter(
            plant=self.plant,
            gstr2b=gstr2b,
            mismatch_type=VendorGSTMismatch.MismatchType.INVOICE_NOT_FILED,
        )
        self.assertGreater(mismatches.count(), 0)

    def test_28_webtel_api_error_raised_on_5xx(self):
        """
        SANDBOX=False: HTTP 5xx raises WebtelAPIError.
        """
        try:
            import responses as responses_lib
        except ImportError:
            self.skipTest("responses library not installed")

        from apps.webtel.models import WebtelConfig
        from apps.webtel.exceptions import WebtelAPIError
        from apps.webtel.services import WebtelAPIClient
        import django.utils.timezone as tz
        import datetime

        self.config.environment = WebtelConfig.APIEnvironment.PRODUCTION
        self.config.access_token = "LIVE_TOKEN"
        self.config.access_token_expiry = tz.now() + datetime.timedelta(hours=6)
        self.config.save()

        with responses_lib.RequestsMock() as rsps:
            import re
            rsps.add(responses_lib.POST, re.compile(r'.*/einvoice/generate'), status=500, json={"message": "Internal Server Error"})

            with self.settings(WEBTEL_CONFIG={
                "BASE_URL": "https://api.webtel.in/gsp/v3",
                "CLIENT_ID": "test_client",
                "CLIENT_SECRET": "test_secret",
                "GSP_USERNAME": "test_user",
                "GSP_PASSWORD": "test_pass",
                "SANDBOX": False,
            }):
                client = WebtelAPIClient(self.config, plant=self.plant)
                with self.assertRaises(WebtelAPIError) as ctx:
                    client.post("einvoice/generate", {"test": True})
            self.assertEqual(ctx.exception.status_code, 500)

    def test_29_sandbox_true_still_returns_mock(self):
        """
        WEBTEL_SANDBOX=True (via settings): mock responses returned regardless of DB environment.
        """
        from apps.webtel.models import WebtelConfig, IRNRequest
        from apps.webtel.services import generate_irn

        # Even if DB env is PRODUCTION, settings SANDBOX=True should mock
        self.config.environment = WebtelConfig.APIEnvironment.PRODUCTION
        self.config.save()

        with self.settings(WEBTEL_CONFIG={
            "BASE_URL": "https://api.webtel.in/gsp/v3",
            "CLIENT_ID": "test_client",
            "CLIENT_SECRET": "test_secret",
            "GSP_USERNAME": "test_user",
            "GSP_PASSWORD": "test_pass",
            "SANDBOX": True,
        }):
            irn_req = generate_irn(self.invoice, self.user, self.plant)

        self.assertEqual(irn_req.status, IRNRequest.IRNStatus.SUCCESS)
        # Mock IRN is 64 char hex
        self.assertEqual(len(irn_req.irn), 64)
