"""
Webtel Module Services — Section 7
All API calls to Webtel GSP (GST Suvidha Provider) go through this module.

Architecture:
  - WebtelAPIClient: low-level HTTP client (token refresh, retries, logging)
  - IRN services: generate_irn(), cancel_irn(), get_irn_details()
  - e-Way Bill services: generate_eway_bill(), extend_eway_bill(), cancel_eway_bill(),
                         update_vehicle_number()
  - GSTR-2B services: fetch_gstr2b(), reconcile_2b_with_purchase()
  - Vendor mismatch: send_vendor_mismatch_emails()
  - GSTR filing: submit_gstr1(), submit_gstr3b()
  - Token management: refresh_access_token()

Note: This module makes real HTTP calls to Webtel's API.
      In test/sandbox mode, mock responses are returned.
      All API calls are logged to IRNRequest / EwayBillRequest models.
"""
import json
import time
import logging
from decimal import Decimal
from datetime import date, timedelta
from typing import Optional

from django.conf import settings as django_settings
from django.core.mail import send_mail
from django.db import transaction
from django.utils import timezone

from apps.webtel.exceptions import WebtelAPIError

try:
    import requests
    HAS_REQUESTS = True
except ImportError:
    HAS_REQUESTS = False

from apps.core.models import AuditLog, Notification
from apps.webtel.models import (
    WebtelConfig,
    IRNRequest,
    EwayBillRequest,
    GSTR2BData,
    GSTR2BLine,
    GSTR2BReconciliation,
    VendorGSTMismatch,
    GSTRFilingLog,
)

logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════════
# HELPERS
# ═══════════════════════════════════════════════════════════════════

def _log(user, action, resource, resource_id, details=None):
    AuditLog.objects.create(
        user=user, action=action, module="webtel",
        resource=resource, resource_id=str(resource_id),
        details=details or {},
    )


def _two(val):
    return Decimal(str(val)).quantize(Decimal("0.01"))


def _get_config(plant) -> WebtelConfig:
    """Fetch active Webtel config for plant. Raises ValueError if not configured."""
    try:
        return WebtelConfig.objects.get(plant=plant, is_active=True)
    except WebtelConfig.DoesNotExist:
        raise ValueError(
            f"Webtel not configured for plant {plant.code}. "
            "Go to Settings → Webtel Configuration to set up API credentials."
        )


# ═══════════════════════════════════════════════════════════════════
# WEBTEL API CLIENT
# ═══════════════════════════════════════════════════════════════════

class WebtelAPIClient:
    """
    Low-level HTTP client for Webtel GSP API.
    Handles token refresh, request signing, retry logic, and logging.
    """

    def __init__(self, config: WebtelConfig, plant=None):
        self.config = config
        self.plant = plant  # used to set gstin header
        self.session = None
        if HAS_REQUESTS:
            self.session = requests.Session()

    def _get_headers(self) -> dict:
        webtel_cfg = django_settings.WEBTEL_CONFIG
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "Authorization": f"Bearer {self.config.access_token}",
            "gstin": self.plant.gstin if self.plant else self.config.gstin,
            "user_name": webtel_cfg.get("GSP_USERNAME", self.config.username),
            "client_id": webtel_cfg.get("CLIENT_ID", self.config.client_id),
        }
        return headers

    def _is_sandbox(self) -> bool:
        """Check sandbox mode via settings (env var takes precedence)."""
        cfg = django_settings.WEBTEL_CONFIG
        if "SANDBOX" in cfg:
            return bool(cfg["SANDBOX"])
        return self.config.environment == WebtelConfig.APIEnvironment.SANDBOX

    def _ensure_token_valid(self):
        """Refresh token if expired or about to expire (within 5 minutes)."""
        if not self.config.token_is_valid:
            refresh_access_token(self.config)
            self.config.refresh_from_db()

    def _call(self, method: str, url: str, payload: dict = None, params: dict = None) -> tuple:
        """
        Make a raw HTTP call. Returns (response_dict, duration_ms).
        On 401: refresh token and retry once.
        On 4xx/5xx: raise WebtelAPIError.
        """
        start = time.time()
        try:
            if method == "POST":
                resp = self.session.post(url, json=payload, headers=self._get_headers(), timeout=30)
            else:
                resp = self.session.get(url, params=params, headers=self._get_headers(), timeout=30)

            duration_ms = int((time.time() - start) * 1000)

            if resp.status_code == 401:
                # Token expired — refresh once and retry
                logger.info(f"[WEBTEL] 401 received, refreshing token for {self.config.plant.code}")
                refresh_access_token(self.config)
                self.config.refresh_from_db()

                start = time.time()
                if method == "POST":
                    resp = self.session.post(url, json=payload, headers=self._get_headers(), timeout=30)
                else:
                    resp = self.session.get(url, params=params, headers=self._get_headers(), timeout=30)
                duration_ms = int((time.time() - start) * 1000)

            if resp.status_code >= 400:
                body = {}
                try:
                    body = resp.json()
                except Exception:
                    body = {"raw": resp.text}
                msg = body.get("message") or body.get("error") or resp.text[:200]
                raise WebtelAPIError(
                    f"HTTP {resp.status_code}: {msg}",
                    status_code=resp.status_code,
                    response_body=body,
                )

            return resp.json(), duration_ms

        except requests.exceptions.Timeout:
            raise WebtelAPIError("Request timeout — Webtel API did not respond within 30 seconds.")
        except requests.exceptions.ConnectionError as e:
            raise WebtelAPIError(f"Connection error: {e}")

    def post(self, endpoint: str, payload: dict, base_url_key: str = "irn") -> dict:
        """
        Make authenticated POST call to Webtel API.
        Returns parsed JSON response dict.
        Raises WebtelAPIError on non-2xx response.
        """
        self._ensure_token_valid()

        if base_url_key == "eway":
            base_url = self.config.eway_base_url
        elif base_url_key == "gstr":
            base_url = self.config.gstr_base_url
        else:
            base_url = self.config.irn_base_url

        url = f"{base_url.rstrip('/')}/{endpoint}"

        if not HAS_REQUESTS or self._is_sandbox():
            # Sandbox mode: return mock response
            return _mock_response(endpoint, payload)

        data, duration_ms = self._call("POST", url, payload=payload)
        return {"_duration_ms": duration_ms, **data}

    def get(self, endpoint: str, params: dict = None, base_url_key: str = "irn") -> dict:
        self._ensure_token_valid()

        if base_url_key == "eway":
            base_url = self.config.eway_base_url
        elif base_url_key == "gstr":
            base_url = self.config.gstr_base_url
        else:
            base_url = self.config.irn_base_url

        url = f"{base_url.rstrip('/')}/{endpoint}"

        if not HAS_REQUESTS or self._is_sandbox():
            return _mock_response(endpoint, params or {})

        data, duration_ms = self._call("GET", url, params=params)
        return {"_duration_ms": duration_ms, **data}


def _mock_response(endpoint: str, payload: dict) -> dict:
    """
    Return realistic mock responses for sandbox / testing mode.
    """
    import hashlib, random
    if "einvoice" in endpoint or "irn" in endpoint.lower():
        fake_irn = hashlib.sha256(json.dumps(payload).encode()).hexdigest()[:64]
        return {
            "Status": "1",
            "Data": {
                "Irn": fake_irn,
                "AckNo": str(random.randint(10**18, 10**19)),
                "AckDt": date.today().strftime("%Y-%m-%d %H:%M:%S"),
                "SignedInvoice": "MOCK_SIGNED_INVOICE",
                "SignedQRCode": f"MOCK_QR_{fake_irn[:16]}",
            },
            "_duration_ms": 120,
            "_mock": True,
        }
    if "ewaybill" in endpoint or "eway" in endpoint.lower():
        ewb_num = str(random.randint(10**11, 10**12))
        valid_until = (date.today() + timedelta(days=1)).strftime("%d/%m/%Y %H:%M:%S")
        return {
            "Status": "1",
            "Data": {
                "EwbNo": ewb_num,
                "EwbDt": date.today().strftime("%d/%m/%Y %H:%M:%S"),
                "EwbValidTill": valid_until,
                "Alert": "",
            },
            "_duration_ms": 95,
            "_mock": True,
        }
    if "gstr2b" in endpoint.lower():
        return {
            "Status": "1",
            "Data": {
                "rtnprd": payload.get("ret_period", ""),
                "b2b": [],
            },
            "_duration_ms": 200,
            "_mock": True,
        }
    return {"Status": "1", "Data": {}, "_duration_ms": 50, "_mock": True}


# ═══════════════════════════════════════════════════════════════════
# TOKEN MANAGEMENT
# ═══════════════════════════════════════════════════════════════════

@transaction.atomic
def refresh_access_token(config: WebtelConfig) -> bool:
    """
    Refresh Webtel OAuth access token using client_credentials grant.
    Uses select_for_update() to prevent race conditions.
    Returns True on success.
    """
    webtel_cfg = django_settings.WEBTEL_CONFIG

    # Re-fetch with lock to prevent race condition
    config = WebtelConfig.objects.select_for_update().get(pk=config.pk)

    # Check if another process already refreshed while we waited for the lock
    if config.token_is_valid:
        return True

    sandbox = webtel_cfg.get("SANDBOX", True) if webtel_cfg else True
    if not HAS_REQUESTS or sandbox or config.environment == WebtelConfig.APIEnvironment.SANDBOX:
        # Mock token for sandbox
        config.access_token = "MOCK_TOKEN_" + config.plant.code
        config.access_token_expiry = timezone.now() + timedelta(hours=6)
        config.save(update_fields=["access_token", "access_token_expiry"])
        return True

    base_url = webtel_cfg.get("BASE_URL", "").rstrip("/")
    client_id = webtel_cfg.get("CLIENT_ID", config.client_id)
    client_secret = webtel_cfg.get("CLIENT_SECRET", "")
    gsp_username = webtel_cfg.get("GSP_USERNAME", config.username)
    gsp_password = webtel_cfg.get("GSP_PASSWORD", "")

    try:
        resp = requests.post(
            f"{base_url}/auth/token",
            json={
                "client_id": client_id,
                "client_secret": client_secret,
                "grant_type": "client_credentials",
                "username": gsp_username,
                "password": gsp_password,
                "gstin": config.gstin,
            },
            timeout=30,
        )
        resp.raise_for_status()
        data = resp.json()

        if data.get("Status") != "1":
            raise WebtelAPIError(
                f"Token refresh failed: {data.get('ErrorDetails', 'Unknown error')}",
                status_code=resp.status_code,
                response_body=data,
            )

        token_data = data.get("Data", {})
        config.access_token = token_data.get("AuthToken") or token_data.get("access_token", "")
        config.access_token_expiry = timezone.now() + timedelta(hours=6)
        config.save(update_fields=["access_token", "access_token_expiry"])
        logger.info(f"[WEBTEL] Token refreshed for plant {config.plant.code}")
        return True
    except WebtelAPIError:
        raise
    except Exception as e:
        logger.error(f"[WEBTEL] Token refresh failed for {config.plant.code}: {e}")
        return False


def test_connection(config: WebtelConfig, user) -> dict:
    """Test Webtel API connectivity and return result."""
    try:
        refresh_access_token(config)
        config.last_tested_at = timezone.now()
        config.last_test_result = "SUCCESS"
        config.save(update_fields=["last_tested_at", "last_test_result"])
        _log(user, "TESTED", "WebtelConfig", config.pk, {"result": "SUCCESS"})
        return {"success": True, "message": "Connection successful"}
    except Exception as e:
        config.last_tested_at = timezone.now()
        config.last_test_result = "FAILED"
        config.save(update_fields=["last_tested_at", "last_test_result"])
        return {"success": False, "message": str(e)}


# ═══════════════════════════════════════════════════════════════════
# IRN — E-INVOICE
# ═══════════════════════════════════════════════════════════════════

def _build_irn_payload(invoice) -> dict:
    """
    Build the JSON payload for IRN generation per GST e-invoice schema.
    Schema version: 1.1 (as per NIC/IRP specification).
    """
    from apps.sales.models import InvoiceLine

    plant = invoice.plant
    customer = invoice.customer

    # Document type mapping
    doc_type_map = {
        "TAX_INVOICE": "INV",
        "CREDIT_NOTE": "CRN",
        "DEBIT_NOTE": "DBN",
    }
    doc_type = doc_type_map.get(invoice.invoice_type, "INV")

    # Seller details
    seller = {
        "Gstin": plant.gstin,
        "LglNm": plant.company.name if hasattr(plant, "company") else "Trident Paper Box Industries",
        "TrdNm": plant.name,
        "Addr1": plant.address_line1 if hasattr(plant, "address_line1") else plant.name,
        "Loc": plant.city if hasattr(plant, "city") else "Pardi",
        "Pin": int(plant.pincode) if hasattr(plant, "pincode") and plant.pincode else 396105,
        "Stcd": plant.state_code or "24",
        "Ph": plant.phone if hasattr(plant, "phone") else "",
        "Em": plant.email if hasattr(plant, "email") else "",
    }

    # Buyer details
    buyer = {
        "Gstin": customer.gstin or "URP",  # URP = Unregistered Person
        "LglNm": customer.name,
        "TrdNm": customer.name,
        "Pos": invoice.place_of_supply or plant.state_code or "24",
        "Addr1": customer.address_line1 if hasattr(customer, "address_line1") else customer.name,
        "Loc": customer.city if hasattr(customer, "city") else "",
        "Pin": int(customer.pincode) if hasattr(customer, "pincode") and customer.pincode else 999999,
        "Stcd": customer.state_code if hasattr(customer, "state_code") else "24",
    }

    # Line items
    item_list = []
    for i, line in enumerate(invoice.lines.all().select_related("item", "uom"), start=1):
        gst_type = "IGST" if invoice.is_interstate else "GST"
        item_entry = {
            "SlNo": str(i),
            "PrdDesc": line.description[:300],
            "IsServc": "N",
            "HsnCd": line.hsn_code or "4819",
            "Qty": float(line.qty),
            "Unit": line.uom.code if line.uom else "NOS",
            "UnitPrice": float(line.unit_rate),
            "TotAmt": float(line.taxable_amt),
            "Discount": 0,
            "PreTaxVal": float(line.taxable_amt),
            "AssAmt": float(line.taxable_amt),
            "GstRt": float(line.gst_pct),
        }
        if invoice.is_interstate:
            item_entry["IgstAmt"] = float(line.igst_amount)
            item_entry["CgstAmt"] = 0
            item_entry["SgstAmt"] = 0
        else:
            item_entry["IgstAmt"] = 0
            item_entry["CgstAmt"] = float(line.cgst_amount)
            item_entry["SgstAmt"] = float(line.sgst_amount)
        item_entry["TotItemVal"] = float(line.line_total)
        item_list.append(item_entry)

    payload = {
        "Version": "1.1",
        "TranDtls": {
            "TaxSch": "GST",
            "SupTyp": "B2B" if customer.gstin else "B2C",
            "RegRev": "Y" if invoice.reverse_charge else "N",
            "EcmGstin": None,
            "IgstOnIntra": "N",
        },
        "DocDtls": {
            "Typ": doc_type,
            "No": invoice.invoice_number,
            "Dt": invoice.invoice_date.strftime("%d/%m/%Y"),
        },
        "SellerDtls": seller,
        "BuyerDtls": buyer,
        "ItemList": item_list,
        "ValDtls": {
            "AssVal": float(invoice.taxable_amount),
            "CgstVal": float(invoice.cgst_amount),
            "SgstVal": float(invoice.sgst_amount),
            "IgstVal": float(invoice.igst_amount),
            "CesVal": 0,
            "StCesVal": 0,
            "Discount": float(invoice.discount_amount),
            "RndOffAmt": float(invoice.round_off),
            "TotInvVal": float(invoice.total_amount),
        },
    }

    # Dispatch details (from despatch)
    if invoice.despatch:
        d = invoice.despatch
        payload["DispDtls"] = {
            "Nm": plant.name,
            "Addr1": seller["Addr1"],
            "Loc": seller["Loc"],
            "Pin": seller["Pin"],
            "Stcd": seller["Stcd"],
        }
        payload["ShipDtls"] = {
            "Gstin": buyer["Gstin"],
            "LglNm": buyer["LglNm"],
            "TrdNm": buyer["TrdNm"],
            "Addr1": buyer["Addr1"],
            "Loc": buyer["Loc"],
            "Pin": buyer["Pin"],
            "Stcd": buyer["Stcd"],
        }
        if d.transporter_name:
            payload["EwbDtls"] = {
                "TransId": "",
                "TransName": d.transporter_name,
                "Distance": 0,
                "TransDocNo": d.lr_number,
                "TransDocDt": d.lr_date.strftime("%d/%m/%Y") if d.lr_date else "",
                "VehNo": d.vehicle_number,
                "VehType": "R",
                "TransMode": "1",
            }

    return payload


@transaction.atomic
def generate_irn(invoice, user, plant) -> IRNRequest:
    """
    Generate IRN for a confirmed Tax Invoice.
    - Validates invoice is in correct state
    - Builds NIC-compliant JSON payload
    - Calls Webtel API
    - Saves IRN + QR code back to Invoice model
    - Creates IRNRequest log entry
    """
    from apps.sales.models import Invoice

    if invoice.invoice_type not in ("TAX_INVOICE", "CREDIT_NOTE", "DEBIT_NOTE"):
        raise ValueError("IRN can only be generated for Tax Invoice, Credit Note, or Debit Note.")
    if invoice.irn:
        raise ValueError(f"IRN already generated: {invoice.irn}")
    if invoice.status not in (Invoice.InvoiceStatus.CONFIRMED, Invoice.InvoiceStatus.IRN_PENDING):
        raise ValueError(f"Invoice must be CONFIRMED or IRN_PENDING. Current: {invoice.status}")

    config = _get_config(plant)
    client = WebtelAPIClient(config, plant=plant)
    payload = _build_irn_payload(invoice)

    # Create pending log entry
    irn_req = IRNRequest.objects.create(
        plant=plant,
        invoice=invoice,
        action=IRNRequest.IRNAction.GENERATE,
        status=IRNRequest.IRNStatus.PENDING,
        request_payload=payload,
        requested_by=user,
    )

    invoice.status = Invoice.InvoiceStatus.IRN_PENDING
    invoice.save(update_fields=["status"])

    try:
        start = time.time()
        response = client.post("einvoice/generate", payload)
        duration_ms = response.pop("_duration_ms", int((time.time() - start) * 1000))

        if response.get("Status") == "1":
            data = response.get("Data", {})
            irn = data.get("Irn", "")
            ack_no = str(data.get("AckNo", ""))
            ack_dt = str(data.get("AckDt", ""))
            signed_inv = data.get("SignedInvoice", "")
            signed_qr = data.get("SignedQRCode", "")

            # Update IRNRequest
            irn_req.status = IRNRequest.IRNStatus.SUCCESS
            irn_req.irn = irn
            irn_req.ack_number = ack_no
            irn_req.ack_date = ack_dt
            irn_req.signed_invoice = signed_inv
            irn_req.signed_qr_code = signed_qr
            irn_req.response_data = response
            irn_req.api_call_duration_ms = duration_ms
            irn_req.save()

            # Update Invoice
            invoice.irn = irn
            invoice.ack_number = ack_no
            invoice.irn_generated_at = timezone.now()
            invoice.qr_code_irn = signed_qr
            invoice.status = Invoice.InvoiceStatus.IRN_DONE
            invoice.save(update_fields=[
                "irn", "ack_number", "irn_generated_at", "qr_code_irn", "status"
            ])

            _log(user, "IRN_GENERATED", "Invoice", invoice.pk, {
                "irn": irn, "ack_no": ack_no,
                "invoice_number": invoice.invoice_number,
            })

            Notification.objects.create(
                user=user,
                title=f"IRN Generated: {invoice.invoice_number}",
                message=f"IRN {irn[:16]}... generated successfully for {invoice.invoice_number}.",
                module="webtel",
                object_id=str(invoice.pk),
            )

        else:
            # Check for duplicate
            error_details = response.get("ErrorDetails", [])
            error_code = error_details[0].get("ErrorCode", "") if error_details else ""
            error_msg = error_details[0].get("ErrorMessage", "") if error_details else str(response)

            if error_code == "2150":  # Duplicate IRN
                irn_req.status = IRNRequest.IRNStatus.DUPLICATE
            else:
                irn_req.status = IRNRequest.IRNStatus.FAILED

            irn_req.error_code = error_code
            irn_req.error_message = error_msg
            irn_req.response_data = response
            irn_req.api_call_duration_ms = duration_ms
            irn_req.save()

            invoice.status = Invoice.InvoiceStatus.CONFIRMED
            invoice.save(update_fields=["status"])

            raise ValueError(f"IRN generation failed [{error_code}]: {error_msg}")

    except ValueError:
        raise
    except Exception as e:
        irn_req.status = IRNRequest.IRNStatus.FAILED
        irn_req.error_message = str(e)
        irn_req.save()
        invoice.status = Invoice.InvoiceStatus.CONFIRMED
        invoice.save(update_fields=["status"])
        raise ValueError(f"IRN generation error: {e}")

    return irn_req


@transaction.atomic
def cancel_irn(invoice, cancel_reason: str, user, plant) -> IRNRequest:
    """
    Cancel an IRN. Only possible within 24 hours of generation.
    IRN cancellation is irreversible — invoice must be re-issued with new number.
    """
    from apps.sales.models import Invoice

    if not invoice.irn:
        raise ValueError("No IRN to cancel on this invoice.")

    config = _get_config(plant)
    client = WebtelAPIClient(config, plant=plant)

    cancel_codes = {
        "DUPLICATE": "1",
        "DATA_ENTRY_MISTAKE": "2",
        "ORDER_CANCELLED": "3",
        "OTHER": "4",
    }

    payload = {
        "Irn": invoice.irn,
        "CnlRsn": cancel_codes.get(cancel_reason, "4"),
        "CnlRem": cancel_reason[:100],
    }

    irn_req = IRNRequest.objects.create(
        plant=plant, invoice=invoice,
        action=IRNRequest.IRNAction.CANCEL,
        status=IRNRequest.IRNStatus.PENDING,
        request_payload=payload,
        cancel_reason=cancel_reason,
        requested_by=user,
    )

    try:
        response = client.post("einvoice/cancel", payload)
        if response.get("Status") == "1":
            irn_req.status = IRNRequest.IRNStatus.SUCCESS
            irn_req.response_data = response
            irn_req.cancelled_at = timezone.now()
            irn_req.save()

            invoice.irn = ""
            invoice.status = Invoice.InvoiceStatus.CANCELLED
            invoice.save(update_fields=["irn", "status"])

            _log(user, "IRN_CANCELLED", "Invoice", invoice.pk, {
                "reason": cancel_reason,
                "invoice_number": invoice.invoice_number,
            })
        else:
            error_details = response.get("ErrorDetails", [{}])
            irn_req.status = IRNRequest.IRNStatus.FAILED
            irn_req.error_message = error_details[0].get("ErrorMessage", str(response))
            irn_req.response_data = response
            irn_req.save()
            raise ValueError(f"IRN cancellation failed: {irn_req.error_message}")
    except ValueError:
        raise
    except Exception as e:
        irn_req.status = IRNRequest.IRNStatus.FAILED
        irn_req.error_message = str(e)
        irn_req.save()
        raise ValueError(f"IRN cancellation error: {e}")

    return irn_req


# ═══════════════════════════════════════════════════════════════════
# E-WAY BILL
# ═══════════════════════════════════════════════════════════════════

def _build_eway_payload(invoice) -> dict:
    """Build e-Way Bill generation payload."""
    plant = invoice.plant
    customer = invoice.customer
    despatch = invoice.despatch

    supply_type = "O" if not invoice.is_interstate else "O"  # O = Outward
    sub_supply_type = "1"  # 1 = Supply

    payload = {
        "supplyType": supply_type,
        "subSupplyType": sub_supply_type,
        "docType": "INV",
        "docNo": invoice.invoice_number,
        "docDate": invoice.invoice_date.strftime("%d/%m/%Y"),
        "fromGstin": plant.gstin,
        "fromTrdName": plant.name,
        "fromAddr1": plant.address_line1 if hasattr(plant, "address_line1") else plant.name,
        "fromPlace": plant.city if hasattr(plant, "city") else "Pardi",
        "fromPincode": int(plant.pincode) if hasattr(plant, "pincode") and plant.pincode else 396105,
        "fromStateCode": int(plant.state_code or 24),
        "toGstin": customer.gstin or "URP",
        "toTrdName": customer.name,
        "toAddr1": customer.address_line1 if hasattr(customer, "address_line1") else customer.name,
        "toPlace": customer.city if hasattr(customer, "city") else "",
        "toPincode": int(customer.pincode) if hasattr(customer, "pincode") and customer.pincode else 999999,
        "toStateCode": int(customer.state_code if hasattr(customer, "state_code") else 24),
        "totalValue": float(invoice.taxable_amount),
        "cgstValue": float(invoice.cgst_amount),
        "sgstValue": float(invoice.sgst_amount),
        "igstValue": float(invoice.igst_amount),
        "cessValue": 0,
        "totInvValue": float(invoice.total_amount),
        "itemList": [],
    }

    for line in invoice.lines.all():
        payload["itemList"].append({
            "productName": line.description[:300],
            "hsnCode": line.hsn_code or "4819",
            "quantity": float(line.qty),
            "qtyUnit": line.uom.code if line.uom else "NOS",
            "taxableAmount": float(line.taxable_amt),
            "cgstRate": float(line.cgst_pct),
            "sgstRate": float(line.sgst_pct),
            "igstRate": float(line.igst_pct),
        })

    # Part-B (transport details) — optional on generation, required within distance
    if despatch:
        payload["transMode"] = "1"  # 1=Road, 2=Rail, 3=Air, 4=Ship
        payload["transDistance"] = 0  # Will be auto-calculated by GST portal
        if despatch.vehicle_number:
            payload["vehicleNo"] = despatch.vehicle_number
            payload["vehicleType"] = "R"  # R=Regular
        if despatch.transporter_name:
            payload["transporterName"] = despatch.transporter_name
        if despatch.lr_number:
            payload["transDocNo"] = despatch.lr_number
            payload["transDocDate"] = (
                despatch.lr_date.strftime("%d/%m/%Y") if despatch.lr_date else ""
            )

    return payload


@transaction.atomic
def generate_eway_bill(invoice, user, plant) -> EwayBillRequest:
    """
    Generate e-Way Bill for an invoice.
    - Required when invoice value > WebtelConfig.eway_bill_threshold (default ₹50,000)
    - Typically called after IRN is generated
    - Updates Invoice.eway_bill_number
    """
    from apps.sales.models import Invoice

    config = _get_config(plant)

    if invoice.total_amount < config.eway_bill_threshold:
        raise ValueError(
            f"e-Way Bill not required: Invoice value ₹{invoice.total_amount} "
            f"< threshold ₹{config.eway_bill_threshold}"
        )

    if invoice.eway_bill_number:
        raise ValueError(f"e-Way Bill already generated: {invoice.eway_bill_number}")

    client = WebtelAPIClient(config, plant=plant)
    payload = _build_eway_payload(invoice)

    eway_req = EwayBillRequest.objects.create(
        plant=plant, invoice=invoice,
        action=EwayBillRequest.EwayAction.GENERATE,
        status=EwayBillRequest.EwayStatus.PENDING,
        request_payload=payload,
        requested_by=user,
    )

    try:
        response = client.post("ewaybill/generate", payload, base_url_key="eway")
        duration_ms = response.get("_duration_ms", 0)

        if response.get("Status") == "1":
            data = response.get("Data", {})
            ewb_no = str(data.get("EwbNo", ""))
            ewb_dt = str(data.get("EwbDt", ""))
            ewb_valid = str(data.get("EwbValidTill", ""))

            eway_req.status = EwayBillRequest.EwayStatus.SUCCESS
            eway_req.eway_bill_number = ewb_no
            eway_req.eway_bill_date = ewb_dt
            eway_req.eway_bill_valid_until = ewb_valid
            eway_req.alert_message = data.get("Alert", "")
            eway_req.response_data = response
            eway_req.api_call_duration_ms = duration_ms
            eway_req.save()

            invoice.eway_bill_number = ewb_no
            invoice.eway_bill_date = date.today()
            invoice.save(update_fields=["eway_bill_number", "eway_bill_date"])

            _log(user, "EWAY_GENERATED", "Invoice", invoice.pk, {
                "eway_bill_number": ewb_no,
                "invoice_number": invoice.invoice_number,
            })

        else:
            error_details = response.get("ErrorDetails", [{}])
            eway_req.status = EwayBillRequest.EwayStatus.FAILED
            eway_req.error_message = error_details[0].get("ErrorMessage", str(response))
            eway_req.error_code = error_details[0].get("ErrorCode", "")
            eway_req.response_data = response
            eway_req.api_call_duration_ms = duration_ms
            eway_req.save()
            raise ValueError(f"e-Way Bill generation failed: {eway_req.error_message}")

    except ValueError:
        raise
    except Exception as e:
        eway_req.status = EwayBillRequest.EwayStatus.FAILED
        eway_req.error_message = str(e)
        eway_req.save()
        raise ValueError(f"e-Way Bill error: {e}")

    return eway_req


@transaction.atomic
def extend_eway_bill(invoice, extension_reason: str, user, plant) -> EwayBillRequest:
    """Extend e-Way Bill validity (goods in transit past expiry)."""
    if not invoice.eway_bill_number:
        raise ValueError("No e-Way Bill to extend.")

    config = _get_config(plant)
    client = WebtelAPIClient(config, plant=plant)

    payload = {
        "ewbNo": invoice.eway_bill_number,
        "vehicleNo": invoice.vehicle_number or "",
        "fromPlace": plant.city if hasattr(plant, "city") else "Pardi",
        "fromState": int(plant.state_code or 24),
        "remainingDistance": 0,
        "transDocNo": "",
        "transDocDate": "",
        "transMode": "1",
        "extnRsnCode": "1",
        "extnRemarks": extension_reason[:100],
    }

    eway_req = EwayBillRequest.objects.create(
        plant=plant, invoice=invoice,
        action=EwayBillRequest.EwayAction.EXTEND,
        status=EwayBillRequest.EwayStatus.PENDING,
        request_payload=payload,
        extension_reason=extension_reason,
        requested_by=user,
    )

    try:
        response = client.post("ewaybill/extend", payload, base_url_key="eway")
        if response.get("Status") == "1":
            data = response.get("Data", {})
            new_valid_until = str(data.get("EwbValidTill", ""))
            eway_req.status = EwayBillRequest.EwayStatus.SUCCESS
            eway_req.extended_from = str(invoice.eway_bill_date or "")
            eway_req.extended_to = new_valid_until
            eway_req.eway_bill_valid_until = new_valid_until
            eway_req.response_data = response
            eway_req.save()
            invoice.eway_bill_valid_until = date.today() + timedelta(days=1)
            invoice.save(update_fields=["eway_bill_valid_until"])
            _log(user, "EWAY_EXTENDED", "Invoice", invoice.pk, {"new_valid": new_valid_until})
        else:
            error_details = response.get("ErrorDetails", [{}])
            eway_req.status = EwayBillRequest.EwayStatus.FAILED
            eway_req.error_message = error_details[0].get("ErrorMessage", str(response))
            eway_req.response_data = response
            eway_req.save()
            raise ValueError(f"e-Way Bill extension failed: {eway_req.error_message}")
    except ValueError:
        raise
    except Exception as e:
        eway_req.status = EwayBillRequest.EwayStatus.FAILED
        eway_req.error_message = str(e)
        eway_req.save()
        raise ValueError(f"e-Way Bill extension error: {e}")

    return eway_req


@transaction.atomic
def cancel_eway_bill(invoice, cancel_reason: str, user, plant) -> EwayBillRequest:
    """Cancel an e-Way Bill (within 24 hours of generation)."""
    if not invoice.eway_bill_number:
        raise ValueError("No e-Way Bill to cancel.")

    config = _get_config(plant)
    client = WebtelAPIClient(config, plant=plant)

    cancel_codes = {
        "DUPLICATE": "1",
        "ORDER_CANCELLED": "2",
        "DATA_ENTRY_MISTAKE": "3",
        "OTHER": "4",
    }

    payload = {
        "ewbNo": invoice.eway_bill_number,
        "cancelRsnCode": cancel_codes.get(cancel_reason, "4"),
        "cancelRmrk": cancel_reason[:100],
    }

    eway_req = EwayBillRequest.objects.create(
        plant=plant, invoice=invoice,
        action=EwayBillRequest.EwayAction.CANCEL,
        status=EwayBillRequest.EwayStatus.PENDING,
        request_payload=payload,
        cancel_reason=cancel_reason,
        requested_by=user,
    )

    try:
        response = client.post("ewaybill/cancel", payload, base_url_key="eway")
        if response.get("Status") == "1":
            eway_req.status = EwayBillRequest.EwayStatus.SUCCESS
            eway_req.response_data = response
            eway_req.save()
            invoice.eway_bill_number = ""
            invoice.save(update_fields=["eway_bill_number"])
            _log(user, "EWAY_CANCELLED", "Invoice", invoice.pk, {"reason": cancel_reason})
        else:
            error_details = response.get("ErrorDetails", [{}])
            eway_req.status = EwayBillRequest.EwayStatus.FAILED
            eway_req.error_message = error_details[0].get("ErrorMessage", str(response))
            eway_req.response_data = response
            eway_req.save()
            raise ValueError(f"e-Way Bill cancellation failed: {eway_req.error_message}")
    except ValueError:
        raise
    except Exception as e:
        eway_req.status = EwayBillRequest.EwayStatus.FAILED
        eway_req.error_message = str(e)
        eway_req.save()
        raise ValueError(f"e-Way Bill cancel error: {e}")

    return eway_req


@transaction.atomic
def update_vehicle_number(invoice, vehicle_number: str, from_place: str, user, plant) -> EwayBillRequest:
    """Update Part-B (vehicle number) on an existing e-Way Bill."""
    if not invoice.eway_bill_number:
        raise ValueError("No e-Way Bill to update.")

    config = _get_config(plant)
    client = WebtelAPIClient(config, plant=plant)

    payload = {
        "ewbNo": invoice.eway_bill_number,
        "vehicleNo": vehicle_number,
        "fromPlace": from_place,
        "fromState": int(plant.state_code or 24),
        "vehicleType": "R",
        "transMode": "1",
        "reasonCode": "1",
        "reasonRem": "Vehicle changed",
    }

    eway_req = EwayBillRequest.objects.create(
        plant=plant, invoice=invoice,
        action=EwayBillRequest.EwayAction.UPDATE_PART_B,
        status=EwayBillRequest.EwayStatus.PENDING,
        request_payload=payload,
        requested_by=user,
    )

    try:
        response = client.post("ewaybill/update_partb", payload, base_url_key="eway")
        if response.get("Status") == "1":
            eway_req.status = EwayBillRequest.EwayStatus.SUCCESS
            eway_req.response_data = response
            eway_req.save()
            invoice.vehicle_number = vehicle_number
            invoice.save(update_fields=["vehicle_number"])
            _log(user, "EWAY_VEHICLE_UPDATED", "Invoice", invoice.pk, {"vehicle": vehicle_number})
        else:
            error_details = response.get("ErrorDetails", [{}])
            eway_req.status = EwayBillRequest.EwayStatus.FAILED
            eway_req.error_message = error_details[0].get("ErrorMessage", str(response))
            eway_req.response_data = response
            eway_req.save()
            raise ValueError(f"Vehicle update failed: {eway_req.error_message}")
    except ValueError:
        raise
    except Exception as e:
        eway_req.status = EwayBillRequest.EwayStatus.FAILED
        eway_req.error_message = str(e)
        eway_req.save()
        raise ValueError(f"Vehicle update error: {e}")

    return eway_req


# ═══════════════════════════════════════════════════════════════════
# GSTR-2B FETCH & RECONCILIATION
# ═══════════════════════════════════════════════════════════════════

@transaction.atomic
def fetch_gstr2b(plant, return_period: str, user) -> GSTR2BData:
    """
    Fetch GSTR-2B data from GST portal via Webtel for a given return period.
    return_period: MMYYYY e.g. "012026"
    Saves all lines to GSTR2BLine table.
    """
    config = _get_config(plant)
    client = WebtelAPIClient(config, plant=plant)

    gstr2b_obj, created = GSTR2BData.objects.get_or_create(
        plant=plant, return_period=return_period,
        defaults={"fetch_status": GSTR2BData.FetchStatus.PENDING, "fetched_by": user}
    )

    if not created and gstr2b_obj.fetch_status == GSTR2BData.FetchStatus.FETCHED:
        # Delete old lines before re-fetch
        gstr2b_obj.lines.all().delete()
        gstr2b_obj.reconciliations.all().delete()

    payload = {"ret_period": return_period, "gstin": plant.gstin}

    try:
        response = client.get(f"gst/gstr2b/{return_period}", base_url_key="gstr")

        if response.get("Status") == "1":
            data = response.get("Data", {})
            b2b_entries = data.get("b2b", [])

            lines_created = 0
            total_igst = total_cgst = total_sgst = Decimal("0")

            for supplier in b2b_entries:
                sup_gstin = supplier.get("ctin", "")
                sup_name = supplier.get("tradeName", "")
                for inv in supplier.get("inv", []):
                    for item in inv.get("items", [{"rt": 18}]):
                        line = GSTR2BLine.objects.create(
                            gstr2b=gstr2b_obj,
                            supplier_gstin=sup_gstin,
                            supplier_name=sup_name,
                            doc_type=inv.get("typ", "INV"),
                            doc_number=inv.get("inum", ""),
                            doc_date=_parse_gst_date(inv.get("idt", "")),
                            taxable_value=_two(inv.get("val", 0)),
                            igst=_two(item.get("igst", 0)),
                            cgst=_two(item.get("cgst", 0)),
                            sgst=_two(item.get("sgst", 0)),
                            cess=_two(item.get("cess", 0)),
                            itc_availability=inv.get("itcAvl", ""),
                            place_of_supply=inv.get("pos", ""),
                            reverse_charge=inv.get("rchrg", "N") == "Y",
                            source=inv.get("srctyp", ""),
                        )
                        lines_created += 1
                        total_igst += line.igst
                        total_cgst += line.cgst
                        total_sgst += line.sgst

            gstr2b_obj.fetch_status = GSTR2BData.FetchStatus.FETCHED
            gstr2b_obj.total_records = lines_created
            gstr2b_obj.total_igst = total_igst
            gstr2b_obj.total_cgst = total_cgst
            gstr2b_obj.total_sgst = total_sgst
            gstr2b_obj.fetched_at = timezone.now()
            gstr2b_obj.fetched_by = user
            gstr2b_obj.raw_response = response
            gstr2b_obj.save()

            _log(user, "FETCHED", "GSTR2BData", gstr2b_obj.pk, {
                "period": return_period, "lines": lines_created
            })

        else:
            error = response.get("ErrorDetails", [{}])
            gstr2b_obj.fetch_status = GSTR2BData.FetchStatus.FETCH_FAILED
            gstr2b_obj.error_message = error[0].get("ErrorMessage", str(response)) if error else str(response)
            gstr2b_obj.save()
            raise ValueError(f"GSTR-2B fetch failed: {gstr2b_obj.error_message}")

    except ValueError:
        raise
    except Exception as e:
        gstr2b_obj.fetch_status = GSTR2BData.FetchStatus.FETCH_FAILED
        gstr2b_obj.error_message = str(e)
        gstr2b_obj.save()
        raise ValueError(f"GSTR-2B fetch error: {e}")

    return gstr2b_obj


def _parse_gst_date(date_str: str) -> date:
    """Parse GST date formats: DD-MM-YYYY or DD/MM/YYYY."""
    if not date_str:
        return date.today()
    for fmt in ("%d-%m-%Y", "%d/%m/%Y", "%Y-%m-%d"):
        try:
            return date(*[int(x) for x in date_str.replace("/", "-").split("-")][::-1]) if "-" in date_str else date.today()
        except Exception:
            pass
    return date.today()


@transaction.atomic
def reconcile_2b_with_purchase(gstr2b_obj: GSTR2BData, user) -> dict:
    """
    Match GSTR-2B lines against our purchase register (VendorBill).

    Matching logic:
    1. For each 2B line: look for VendorBill with same supplier_gstin + doc_number
    2. If found: compare amounts — MATCHED or AMT/DATE/GSTIN mismatch
    3. If not found in 2B: mark MISSING_IN_2B
    4. If not found in books: mark MISSING_IN_BOOKS

    Creates VendorGSTMismatch for any non-MATCHED result.
    """
    from apps.accounts.models import VendorBill
    from apps.masters.models import Vendor

    plant = gstr2b_obj.plant
    period = gstr2b_obj.return_period

    # Get all vendor bills for this period
    year = int(period[2:])
    month = int(period[:2])
    vendor_bills = VendorBill.objects.filter(
        plant=plant,
        vendor_bill_date__year=year,
        vendor_bill_date__month=month,
    ).select_related("vendor")

    # Index by: (vendor_gstin, vendor_bill_ref.lower())
    bills_index: dict = {}
    for bill in vendor_bills:
        key = (bill.vendor.gstin or "", bill.vendor_bill_ref.strip().lower())
        bills_index[key] = bill

    matched = mismatched = missing_in_books = missing_in_2b = 0
    processed_bill_pks = set()

    # Process each 2B line
    for line in gstr2b_obj.lines.all():
        key = (line.supplier_gstin, line.doc_number.strip().lower())
        bill = bills_index.get(key)

        if bill:
            processed_bill_pks.add(bill.pk)
            # Compare amounts (allow ₹1 tolerance for rounding)
            our_igst = bill.igst_amount if hasattr(bill, "igst_amount") else Decimal("0")
            our_cgst = bill.cgst_amount
            our_sgst = bill.sgst_amount
            diff_cgst = abs(our_cgst - line.cgst)
            diff_sgst = abs(our_sgst - line.sgst)
            diff_igst = abs(our_igst - line.igst)

            tolerance = Decimal("1.00")
            if diff_cgst <= tolerance and diff_sgst <= tolerance and diff_igst <= tolerance:
                status = GSTR2BReconciliation.MatchStatus.MATCHED
                matched += 1
            else:
                status = GSTR2BReconciliation.MatchStatus.AMT_MISMATCH
                mismatched += 1

            recon = GSTR2BReconciliation.objects.create(
                gstr2b=gstr2b_obj,
                gstr2b_line=line,
                vendor_bill=bill,
                match_status=status,
                our_supplier_gstin=bill.vendor.gstin or "",
                our_doc_number=bill.vendor_bill_ref,
                our_doc_date=bill.vendor_bill_date,
                our_taxable_value=bill.taxable_amount,
                our_cgst=our_cgst,
                our_sgst=our_sgst,
                our_igst=our_igst,
                diff_cgst=diff_cgst,
                diff_sgst=diff_sgst,
                diff_igst=diff_igst,
                diff_taxable=abs(bill.taxable_amount - line.taxable_value),
            )

            if status != GSTR2BReconciliation.MatchStatus.MATCHED:
                _create_vendor_mismatch(plant, gstr2b_obj, bill, recon, status, line)
        else:
            # 2B has this invoice but we don't
            missing_in_books += 1
            recon = GSTR2BReconciliation.objects.create(
                gstr2b=gstr2b_obj,
                gstr2b_line=line,
                match_status=GSTR2BReconciliation.MatchStatus.MISSING_IN_BOOKS,
                our_supplier_gstin="",
                our_doc_number="",
                our_taxable_value=Decimal("0"),
                diff_taxable=line.taxable_value,
                diff_cgst=line.cgst,
                diff_sgst=line.sgst,
                diff_igst=line.igst,
            )
            # Try to find vendor by GSTIN
            vendor = None
            try:
                vendor = Vendor.objects.get(plant=plant, gstin=line.supplier_gstin)
            except (Vendor.DoesNotExist, Vendor.MultipleObjectsReturned):
                pass

            if vendor:
                VendorGSTMismatch.objects.create(
                    plant=plant,
                    gstr2b=gstr2b_obj,
                    vendor=vendor,
                    gstr2b_recon=recon,
                    mismatch_type=VendorGSTMismatch.MismatchType.EXTRA_IN_2B,
                    their_amount=line.taxable_value,
                    our_amount=Decimal("0"),
                    difference=line.taxable_value,
                    invoice_ref=line.doc_number,
                    description=f"Invoice {line.doc_number} found in 2B but not in our purchase register.",
                )

    # Bills in our books but missing from 2B
    for pk, bill in [(b.pk, b) for b in vendor_bills if b.pk not in processed_bill_pks]:
        missing_in_2b += 1
        recon = GSTR2BReconciliation.objects.create(
            gstr2b=gstr2b_obj,
            vendor_bill=bill,
            match_status=GSTR2BReconciliation.MatchStatus.MISSING_IN_2B,
            our_supplier_gstin=bill.vendor.gstin or "",
            our_doc_number=bill.vendor_bill_ref,
            our_doc_date=bill.vendor_bill_date,
            our_taxable_value=bill.taxable_amount,
            our_cgst=bill.cgst_amount,
            our_sgst=bill.sgst_amount,
            diff_taxable=bill.taxable_amount,
            diff_cgst=bill.cgst_amount,
            diff_sgst=bill.sgst_amount,
        )
        VendorGSTMismatch.objects.create(
            plant=plant,
            gstr2b=gstr2b_obj,
            vendor=bill.vendor,
            vendor_bill=bill,
            gstr2b_recon=recon,
            mismatch_type=VendorGSTMismatch.MismatchType.INVOICE_NOT_FILED,
            our_amount=bill.taxable_amount,
            their_amount=Decimal("0"),
            difference=bill.taxable_amount,
            invoice_ref=bill.vendor_bill_ref,
            description=(
                f"Vendor bill {bill.vendor_bill_ref} in our books but vendor did not file in GSTR-1. "
                f"ITC of CGST ₹{bill.cgst_amount} + SGST ₹{bill.sgst_amount} at risk."
            ),
        )

    # Update GSTR2B summary
    gstr2b_obj.matched_count = matched
    gstr2b_obj.mismatched_count = mismatched
    gstr2b_obj.missing_in_2b_count = missing_in_2b
    gstr2b_obj.extra_in_2b_count = missing_in_books
    gstr2b_obj.fetch_status = GSTR2BData.FetchStatus.RECONCILED
    gstr2b_obj.reconciled_at = timezone.now()
    gstr2b_obj.save()

    _log(user, "RECONCILED", "GSTR2BData", gstr2b_obj.pk, {
        "matched": matched, "mismatched": mismatched,
        "missing_in_2b": missing_in_2b, "extra_in_2b": missing_in_books,
    })

    return {
        "matched": matched,
        "mismatched": mismatched,
        "missing_in_2b": missing_in_2b,
        "extra_in_2b": missing_in_books,
        "total_2b_lines": gstr2b_obj.total_records,
        "total_our_bills": vendor_bills.count(),
    }


def _create_vendor_mismatch(plant, gstr2b_obj, bill, recon, status, line):
    VendorGSTMismatch.objects.create(
        plant=plant,
        gstr2b=gstr2b_obj,
        vendor=bill.vendor,
        vendor_bill=bill,
        gstr2b_recon=recon,
        mismatch_type=VendorGSTMismatch.MismatchType.AMOUNT_MISMATCH,
        our_amount=bill.taxable_amount,
        their_amount=line.taxable_value,
        difference=abs(bill.taxable_amount - line.taxable_value),
        invoice_ref=bill.vendor_bill_ref,
        description=(
            f"Amount mismatch for {bill.vendor_bill_ref}: "
            f"Our books ₹{bill.taxable_amount} vs 2B ₹{line.taxable_value}"
        ),
    )


# ═══════════════════════════════════════════════════════════════════
# VENDOR MISMATCH EMAILS
# ═══════════════════════════════════════════════════════════════════

def send_vendor_mismatch_emails(plant, return_period: str, user=None) -> int:
    """
    Send automated email to vendors with GSTR-2B discrepancies.
    Groups mismatches by vendor and sends one consolidated email per vendor.
    Returns count of emails sent.
    """
    try:
        gstr2b_obj = GSTR2BData.objects.get(plant=plant, return_period=return_period)
    except GSTR2BData.DoesNotExist:
        raise ValueError(f"No GSTR-2B data found for period {return_period}. Fetch it first.")

    mismatches = VendorGSTMismatch.objects.filter(
        gstr2b=gstr2b_obj,
        status=VendorGSTMismatch.ResolutionStatus.OPEN,
    ).select_related("vendor", "vendor_bill")

    # Group by vendor
    by_vendor: dict = {}
    for m in mismatches:
        v = m.vendor
        if v.pk not in by_vendor:
            by_vendor[v.pk] = {"vendor": v, "items": []}
        by_vendor[v.pk]["items"].append(m)

    month_name = _month_name(return_period)
    sent = 0

    for vendor_pk, group in by_vendor.items():
        vendor = group["vendor"]
        email = vendor.email
        if not email:
            logger.warning(f"[WEBTEL] Vendor {vendor.name} has no email — skipping mismatch notification")
            continue

        items_text = "\n".join([
            f"  - Invoice {m.invoice_ref}: {m.get_mismatch_type_display()} "
            f"(Our books: ₹{m.our_amount}, 2B: ₹{m.their_amount})"
            for m in group["items"]
        ])

        message = (
            f"Dear {vendor.name},\n\n"
            f"We have identified discrepancies in your GST return (GSTR-1) for {month_name} "
            f"vs our purchase register.\n\n"
            f"Discrepancy Details:\n{items_text}\n\n"
            f"As per GST rules, ITC can only be claimed if the invoice appears in GSTR-2B. "
            f"Unresolved discrepancies will result in ITC being blocked.\n\n"
            f"Please rectify in your next GSTR-1 filing or contact us with your explanation.\n\n"
            f"Trident Paper Box Industries | Pardi, Valsad\n"
            f"GSTIN: {plant.gstin}\n"
            f"For queries: accounts@tridentpaper.in"
        )

        try:
            send_mail(
                subject=f"GST Mismatch Notice — {month_name} — Vendor: {vendor.name}",
                message=message,
                from_email=django_settings.DEFAULT_FROM_EMAIL,
                recipient_list=[email],
                fail_silently=True,
            )
            # Update status
            for m in group["items"]:
                m.status = VendorGSTMismatch.ResolutionStatus.EMAIL_SENT
                m.email_sent_at = timezone.now()
                m.email_sent_to = email
                m.save(update_fields=["status", "email_sent_at", "email_sent_to"])
            sent += 1
            logger.info(f"[WEBTEL] Mismatch email sent to {vendor.name} <{email}>")
        except Exception as e:
            logger.error(f"[WEBTEL] Failed to send mismatch email to {vendor.name}: {e}")

    if user:
        _log(user, "EMAILS_SENT", "VendorGSTMismatch", 0, {
            "period": return_period, "emails_sent": sent
        })

    return sent


def _month_name(return_period: str) -> str:
    months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
              "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    try:
        m = int(return_period[:2]) - 1
        y = return_period[2:]
        return f"{months[m]} {y}"
    except Exception:
        return return_period


# ═══════════════════════════════════════════════════════════════════
# GSTR FILING
# ═══════════════════════════════════════════════════════════════════

@transaction.atomic
def submit_gstr1(plant, return_period: str, user) -> GSTRFilingLog:
    """
    Submit GSTR-1 data to GST portal via Webtel.
    Pulls data from accounts.services.get_gst_data_for_gstr1() and submits.
    """
    from apps.accounts.services import get_gst_data_for_gstr1

    filing, created = GSTRFilingLog.objects.get_or_create(
        plant=plant, return_type="GSTR1", return_period=return_period,
        defaults={"status": GSTRFilingLog.FilingStatus.PREPARED, "filed_by": user}
    )

    if not created and filing.status == GSTRFilingLog.FilingStatus.FILED:
        raise ValueError(f"GSTR-1 for {return_period} already filed. ARN: {filing.arn}")

    gstr1_data = get_gst_data_for_gstr1(plant, return_period)
    config = _get_config(plant)
    client = WebtelAPIClient(config, plant=plant)

    # Build Webtel submission payload
    payload = {
        "gstin": plant.gstin,
        "ret_period": return_period,
        "b2b": gstr1_data["b2b"],
        "b2cs": gstr1_data["b2c"],
        "cdnr": gstr1_data["cdnr"],
    }

    filing.summary_data = gstr1_data["summary"]
    filing.save(update_fields=["summary_data"])

    try:
        response = client.post("gst/gstr1/submit", payload, base_url_key="gstr")
        if response.get("Status") == "1":
            data = response.get("Data", {})
            filing.status = GSTRFilingLog.FilingStatus.SUBMITTED
            filing.reference_id = data.get("referenceId", "")
            filing.filed_at = timezone.now()
            filing.filed_by = user
            filing.save()
            _log(user, "GSTR1_SUBMITTED", "GSTRFilingLog", filing.pk, {"period": return_period})
        else:
            error = response.get("ErrorDetails", [{}])
            filing.status = GSTRFilingLog.FilingStatus.FAILED
            filing.error_message = error[0].get("ErrorMessage", str(response))
            filing.save()
            raise ValueError(f"GSTR-1 submission failed: {filing.error_message}")
    except ValueError:
        raise
    except Exception as e:
        filing.status = GSTRFilingLog.FilingStatus.FAILED
        filing.error_message = str(e)
        filing.save()
        raise ValueError(f"GSTR-1 submission error: {e}")

    return filing


@transaction.atomic
def submit_gstr3b(plant, return_period: str, tax_paid_challan: str, user) -> GSTRFilingLog:
    """
    Submit GSTR-3B to GST portal via Webtel.
    tax_paid_challan: BSR code of challan used to pay the GST.
    """
    from apps.accounts.services import get_gst_data_for_gstr3b

    filing, created = GSTRFilingLog.objects.get_or_create(
        plant=plant, return_type="GSTR3B", return_period=return_period,
        defaults={"status": GSTRFilingLog.FilingStatus.PREPARED, "filed_by": user}
    )

    if not created and filing.status == GSTRFilingLog.FilingStatus.FILED:
        raise ValueError(f"GSTR-3B for {return_period} already filed. ARN: {filing.arn}")

    gstr3b_data = get_gst_data_for_gstr3b(plant, return_period)
    config = _get_config(plant)
    client = WebtelAPIClient(config, plant=plant)

    payload = {
        "gstin": plant.gstin,
        "ret_period": return_period,
        "inward_supplies": gstr3b_data["table_4_itc"],
        "outward_supplies": gstr3b_data["table_3_1_outward"],
        "payment_of_tax": {
            **gstr3b_data["table_6_payment"],
            "challan_no": tax_paid_challan,
        },
    }

    filing.summary_data = gstr3b_data
    filing.challan_number = tax_paid_challan
    filing.total_tax_paid = gstr3b_data["table_6_payment"]["total_payable"]
    filing.save(update_fields=["summary_data", "challan_number", "total_tax_paid"])

    try:
        response = client.post("gst/gstr3b/submit", payload, base_url_key="gstr")
        if response.get("Status") == "1":
            data = response.get("Data", {})
            filing.status = GSTRFilingLog.FilingStatus.FILED
            filing.arn = data.get("arn", "")
            filing.reference_id = data.get("referenceId", "")
            filing.filed_at = timezone.now()
            filing.filed_by = user
            filing.save()
            _log(user, "GSTR3B_FILED", "GSTRFilingLog", filing.pk, {
                "period": return_period, "arn": filing.arn
            })
        else:
            error = response.get("ErrorDetails", [{}])
            filing.status = GSTRFilingLog.FilingStatus.FAILED
            filing.error_message = error[0].get("ErrorMessage", str(response))
            filing.save()
            raise ValueError(f"GSTR-3B submission failed: {filing.error_message}")
    except ValueError:
        raise
    except Exception as e:
        filing.status = GSTRFilingLog.FilingStatus.FAILED
        filing.error_message = str(e)
        filing.save()
        raise ValueError(f"GSTR-3B submission error: {e}")

    return filing


# ═══════════════════════════════════════════════════════════════════
# WEBTEL DASHBOARD
# ═══════════════════════════════════════════════════════════════════

def get_webtel_dashboard(plant) -> dict:
    """Webtel module dashboard tiles."""
    from apps.sales.models import Invoice

    today = date.today()
    month_start = today.replace(day=1)

    irn_this_month = IRNRequest.objects.filter(
        plant=plant, action="GENERATE", status="SUCCESS",
        created_at__gte=month_start,
    ).count()

    irn_failed_today = IRNRequest.objects.filter(
        plant=plant, action="GENERATE", status="FAILED",
        created_at__date=today,
    ).count()

    eway_this_month = EwayBillRequest.objects.filter(
        plant=plant, action="GENERATE", status="SUCCESS",
        created_at__gte=month_start,
    ).count()

    pending_irn = Invoice.objects.filter(
        plant=plant, status="IRN_PENDING",
    ).count()

    pending_irn_confirmed = Invoice.objects.filter(
        plant=plant,
        invoice_type="TAX_INVOICE",
        status="CONFIRMED",
        irn="",
    ).count()

    open_mismatches = VendorGSTMismatch.objects.filter(
        plant=plant,
        status__in=["OPEN", "EMAIL_SENT"],
    ).count()

    return {
        "irn_generated_this_month": irn_this_month,
        "irn_failed_today": irn_failed_today,
        "eway_bills_this_month": eway_this_month,
        "invoices_pending_irn": pending_irn_confirmed,
        "invoices_irn_in_progress": pending_irn,
        "open_gst_mismatches": open_mismatches,
    }
