"""Webtel Module ViewSets — Section 7"""
from rest_framework import viewsets, filters, status
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from django_filters.rest_framework import DjangoFilterBackend

from apps.webtel.models import (
    WebtelConfig, IRNRequest, EwayBillRequest,
    GSTR2BData, GSTR2BLine, GSTR2BReconciliation,
    VendorGSTMismatch, GSTRFilingLog,
)
from apps.webtel.api.serializers import (
    WebtelConfigSerializer, WebtelConfigCreateSerializer,
    IRNRequestListSerializer, IRNRequestDetailSerializer,
    GenerateIRNSerializer, CancelIRNSerializer,
    EwayBillRequestListSerializer, EwayBillRequestDetailSerializer,
    GenerateEwaySerializer, ExtendEwaySerializer,
    CancelEwaySerializer, UpdateVehicleSerializer,
    GSTR2BDataListSerializer, GSTR2BDataDetailSerializer, FetchGSTR2BSerializer,
    GSTR2BReconListSerializer, GSTR2BReconDetailSerializer, ReconResolveSerializer,
    VendorGSTMismatchListSerializer, VendorGSTMismatchDetailSerializer,
    SendMismatchEmailsSerializer,
    GSTRFilingLogListSerializer, GSTRFilingLogDetailSerializer,
    SubmitGSTR1Serializer, SubmitGSTR3BSerializer,
)
import apps.webtel.services as services


def _plant(request):
    return request.user.plant


# ── Webtel Config ─────────────────────────────────────────────────

class WebtelConfigViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return WebtelConfig.objects.filter(plant=_plant(self.request))

    def get_serializer_class(self):
        if self.action in ("create", "update", "partial_update"):
            return WebtelConfigCreateSerializer
        return WebtelConfigSerializer

    def create(self, request):
        ser = WebtelConfigCreateSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        d = ser.validated_data
        plant = _plant(request)
        config, created = WebtelConfig.objects.update_or_create(
            plant=plant,
            defaults={
                "environment": d["environment"],
                "username": d["username"],
                "client_id": d.get("client_id", ""),
                "gstin": d["gstin"],
                "irn_base_url": d.get("irn_base_url", "https://gsp.webtel.in/einvoice/"),
                "eway_base_url": d.get("eway_base_url", "https://gsp.webtel.in/ewaybill/"),
                "gstr_base_url": d.get("gstr_base_url", "https://gsp.webtel.in/gst/"),
                "eway_bill_threshold": d.get("eway_bill_threshold", 50000),
                "auto_generate_irn": d.get("auto_generate_irn", True),
                "auto_generate_eway": d.get("auto_generate_eway", True),
                "configured_by": request.user,
            }
        )
        return Response(WebtelConfigSerializer(config).data, status=201 if created else 200)

    @action(detail=True, methods=["post"])
    def test_connection(self, request, pk=None):
        """Test Webtel API connectivity."""
        config = self.get_object()
        result = services.test_connection(config, request.user)
        return Response(result)

    @action(detail=True, methods=["post"])
    def refresh_token(self, request, pk=None):
        """Manually refresh the access token."""
        config = self.get_object()
        success = services.refresh_access_token(config)
        if success:
            return Response({"success": True, "message": "Token refreshed successfully."})
        return Response({"success": False, "message": "Token refresh failed."}, status=400)

    @action(detail=False, methods=["get"])
    def dashboard(self, request):
        """Webtel dashboard tiles."""
        return Response(services.get_webtel_dashboard(_plant(request)))


# ── IRN Management ────────────────────────────────────────────────

class IRNRequestViewSet(viewsets.ReadOnlyModelViewSet):
    """IRN requests are auto-created by services — read-only here."""
    permission_classes = [IsAuthenticated]
    filter_backends    = [filters.SearchFilter, DjangoFilterBackend]
    search_fields      = ["invoice__invoice_number", "irn", "ack_number", "error_code"]
    filterset_fields   = ["action", "status"]

    def get_queryset(self):
        return IRNRequest.objects.filter(
            plant=_plant(self.request)
        ).select_related("invoice", "requested_by")

    def get_serializer_class(self):
        if self.action == "retrieve":
            return IRNRequestDetailSerializer
        return IRNRequestListSerializer

    @action(detail=False, methods=["post"])
    def generate(self, request):
        """Generate IRN for an invoice."""
        from apps.sales.models import Invoice
        ser = GenerateIRNSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        try:
            invoice = Invoice.objects.get(uuid=ser.validated_data["invoice_id"], plant=_plant(request))
            irn_req = services.generate_irn(invoice, request.user, _plant(request))
            return Response(IRNRequestDetailSerializer(irn_req).data, status=201)
        except Invoice.DoesNotExist:
            return Response({"error": "Invoice not found."}, status=404)
        except ValueError as e:
            return Response({"error": str(e)}, status=400)

    @action(detail=False, methods=["post"])
    def cancel(self, request):
        """Cancel an IRN."""
        from apps.sales.models import Invoice
        ser = CancelIRNSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        try:
            invoice = Invoice.objects.get(uuid=ser.validated_data["invoice_id"], plant=_plant(request))
            irn_req = services.cancel_irn(
                invoice, ser.validated_data["cancel_reason"], request.user, _plant(request)
            )
            return Response(IRNRequestDetailSerializer(irn_req).data)
        except Invoice.DoesNotExist:
            return Response({"error": "Invoice not found."}, status=404)
        except ValueError as e:
            return Response({"error": str(e)}, status=400)

    @action(detail=False, methods=["get"])
    def pending_invoices(self, request):
        """Confirmed invoices without IRN (pending IRN generation)."""
        from apps.sales.models import Invoice
        from apps.sales.api.serializers import InvoiceListSerializer
        invoices = Invoice.objects.filter(
            plant=_plant(request),
            invoice_type="TAX_INVOICE",
            status="CONFIRMED",
            irn="",
        ).select_related("customer")
        return Response(InvoiceListSerializer(invoices, many=True).data)


# ── e-Way Bill Management ─────────────────────────────────────────

class EwayBillRequestViewSet(viewsets.ReadOnlyModelViewSet):
    permission_classes = [IsAuthenticated]
    filter_backends    = [filters.SearchFilter, DjangoFilterBackend]
    search_fields      = ["invoice__invoice_number", "eway_bill_number"]
    filterset_fields   = ["action", "status"]

    def get_queryset(self):
        return EwayBillRequest.objects.filter(
            plant=_plant(self.request)
        ).select_related("invoice", "requested_by")

    def get_serializer_class(self):
        if self.action == "retrieve":
            return EwayBillRequestDetailSerializer
        return EwayBillRequestListSerializer

    @action(detail=False, methods=["post"])
    def generate(self, request):
        """Generate e-Way Bill for an invoice."""
        from apps.sales.models import Invoice
        ser = GenerateEwaySerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        try:
            invoice = Invoice.objects.get(uuid=ser.validated_data["invoice_id"], plant=_plant(request))
            eway_req = services.generate_eway_bill(invoice, request.user, _plant(request))
            return Response(EwayBillRequestDetailSerializer(eway_req).data, status=201)
        except Invoice.DoesNotExist:
            return Response({"error": "Invoice not found."}, status=404)
        except ValueError as e:
            return Response({"error": str(e)}, status=400)

    @action(detail=False, methods=["post"])
    def extend(self, request):
        """Extend e-Way Bill validity."""
        from apps.sales.models import Invoice
        ser = ExtendEwaySerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        try:
            invoice = Invoice.objects.get(uuid=ser.validated_data["invoice_id"], plant=_plant(request))
            eway_req = services.extend_eway_bill(
                invoice, ser.validated_data["extension_reason"], request.user, _plant(request)
            )
            return Response(EwayBillRequestDetailSerializer(eway_req).data)
        except Invoice.DoesNotExist:
            return Response({"error": "Invoice not found."}, status=404)
        except ValueError as e:
            return Response({"error": str(e)}, status=400)

    @action(detail=False, methods=["post"])
    def cancel(self, request):
        """Cancel e-Way Bill."""
        from apps.sales.models import Invoice
        ser = CancelEwaySerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        try:
            invoice = Invoice.objects.get(uuid=ser.validated_data["invoice_id"], plant=_plant(request))
            eway_req = services.cancel_eway_bill(
                invoice, ser.validated_data["cancel_reason"], request.user, _plant(request)
            )
            return Response(EwayBillRequestDetailSerializer(eway_req).data)
        except Invoice.DoesNotExist:
            return Response({"error": "Invoice not found."}, status=404)
        except ValueError as e:
            return Response({"error": str(e)}, status=400)

    @action(detail=False, methods=["post"])
    def update_vehicle(self, request):
        """Update Part-B (vehicle number) on existing e-Way Bill."""
        from apps.sales.models import Invoice
        ser = UpdateVehicleSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        try:
            invoice = Invoice.objects.get(uuid=ser.validated_data["invoice_id"], plant=_plant(request))
            eway_req = services.update_vehicle_number(
                invoice,
                ser.validated_data["vehicle_number"],
                ser.validated_data["from_place"],
                request.user,
                _plant(request),
            )
            return Response(EwayBillRequestDetailSerializer(eway_req).data)
        except Invoice.DoesNotExist:
            return Response({"error": "Invoice not found."}, status=404)
        except ValueError as e:
            return Response({"error": str(e)}, status=400)

    @action(detail=False, methods=["get"])
    def expiring_soon(self, request):
        """Invoices with e-Way Bills expiring in next 24 hours."""
        from datetime import date, timedelta
        from apps.sales.models import Invoice
        from apps.sales.api.serializers import InvoiceListSerializer
        tomorrow = date.today() + timedelta(days=1)
        qs = Invoice.objects.filter(
            plant=_plant(request),
            eway_bill_valid_until__lte=tomorrow,
            eway_bill_number__gt="",
        )
        return Response(InvoiceListSerializer(qs, many=True).data)


# ── GSTR-2B ───────────────────────────────────────────────────────

class GSTR2BViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    filter_backends    = [DjangoFilterBackend]
    filterset_fields   = ["fetch_status", "return_period"]

    def get_queryset(self):
        return GSTR2BData.objects.filter(plant=_plant(self.request))

    def get_serializer_class(self):
        if self.action == "retrieve":
            return GSTR2BDataDetailSerializer
        return GSTR2BDataListSerializer

    def create(self, request):
        ser = FetchGSTR2BSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        try:
            gstr2b = services.fetch_gstr2b(
                _plant(request), ser.validated_data["return_period"], request.user
            )
            return Response(GSTR2BDataDetailSerializer(gstr2b).data, status=201)
        except ValueError as e:
            return Response({"error": str(e)}, status=400)

    @action(detail=True, methods=["post"])
    def reconcile(self, request, pk=None):
        """Run reconciliation of 2B data against purchase register."""
        gstr2b = self.get_object()
        try:
            result = services.reconcile_2b_with_purchase(gstr2b, request.user)
            return Response(result)
        except ValueError as e:
            return Response({"error": str(e)}, status=400)

    @action(detail=True, methods=["post"])
    def send_mismatch_emails(self, request, pk=None):
        """Send mismatch notification emails to vendors."""
        gstr2b = self.get_object()
        try:
            count = services.send_vendor_mismatch_emails(
                _plant(request), gstr2b.return_period, request.user
            )
            return Response({"emails_sent": count})
        except ValueError as e:
            return Response({"error": str(e)}, status=400)

    @action(detail=True, methods=["get"])
    def reconciliation_summary(self, request, pk=None):
        """Summary of reconciliation results for this 2B period."""
        gstr2b = self.get_object()
        recons = GSTR2BReconciliation.objects.filter(gstr2b=gstr2b)
        by_status = {}
        for recon in recons:
            s = recon.match_status
            by_status[s] = by_status.get(s, 0) + 1
        return Response({
            "return_period": gstr2b.return_period,
            "total_2b_lines": gstr2b.total_records,
            "by_status": by_status,
            "total_igst_2b": float(gstr2b.total_igst),
            "total_cgst_2b": float(gstr2b.total_cgst),
            "total_sgst_2b": float(gstr2b.total_sgst),
        })


# ── GSTR-2B Reconciliation ────────────────────────────────────────

class GSTR2BReconViewSet(viewsets.ReadOnlyModelViewSet):
    permission_classes = [IsAuthenticated]
    filter_backends    = [DjangoFilterBackend]
    filterset_fields   = ["match_status", "gstr2b"]

    def get_queryset(self):
        return GSTR2BReconciliation.objects.filter(
            gstr2b__plant=_plant(self.request)
        ).select_related("gstr2b_line", "vendor_bill")

    def get_serializer_class(self):
        if self.action == "retrieve":
            return GSTR2BReconDetailSerializer
        return GSTR2BReconListSerializer

    @action(detail=True, methods=["post"])
    def resolve(self, request, pk=None):
        """Manually resolve a reconciliation mismatch."""
        from django.utils import timezone
        recon = self.get_object()
        ser = ReconResolveSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        recon.match_status = ser.validated_data["new_status"]
        recon.resolution_notes = ser.validated_data["resolution_notes"]
        recon.resolved_by = request.user
        recon.resolved_at = timezone.now()
        recon.save(update_fields=["match_status", "resolution_notes", "resolved_by", "resolved_at"])
        return Response(GSTR2BReconDetailSerializer(recon).data)


# ── Vendor GST Mismatch ───────────────────────────────────────────

class VendorGSTMismatchViewSet(viewsets.ReadOnlyModelViewSet):
    permission_classes = [IsAuthenticated]
    filter_backends    = [filters.SearchFilter, DjangoFilterBackend]
    search_fields      = ["vendor__name", "invoice_ref"]
    filterset_fields   = ["mismatch_type", "status"]

    def get_queryset(self):
        return VendorGSTMismatch.objects.filter(
            plant=_plant(self.request)
        ).select_related("vendor", "vendor_bill", "gstr2b")

    def get_serializer_class(self):
        if self.action == "retrieve":
            return VendorGSTMismatchDetailSerializer
        return VendorGSTMismatchListSerializer

    @action(detail=True, methods=["post"])
    def mark_resolved(self, request, pk=None):
        """Mark a mismatch as resolved with notes."""
        from django.utils import timezone
        mismatch = self.get_object()
        notes = request.data.get("resolution_notes", "")
        mismatch.status = VendorGSTMismatch.ResolutionStatus.RESOLVED
        mismatch.resolution_notes = notes
        mismatch.resolved_at = timezone.now()
        mismatch.resolved_by = request.user
        mismatch.save(update_fields=["status", "resolution_notes", "resolved_at", "resolved_by"])
        return Response(VendorGSTMismatchDetailSerializer(mismatch).data)

    @action(detail=True, methods=["post"])
    def log_vendor_reply(self, request, pk=None):
        """Log vendor's response to mismatch email."""
        from django.utils import timezone
        mismatch = self.get_object()
        mismatch.vendor_reply = request.data.get("reply", "")
        mismatch.vendor_replied_at = timezone.now()
        mismatch.status = VendorGSTMismatch.ResolutionStatus.VENDOR_REPLIED
        mismatch.save(update_fields=["vendor_reply", "vendor_replied_at", "status"])
        return Response(VendorGSTMismatchDetailSerializer(mismatch).data)


# ── GSTR Filing Log ───────────────────────────────────────────────

class GSTRFilingLogViewSet(viewsets.ReadOnlyModelViewSet):
    permission_classes = [IsAuthenticated]
    filter_backends    = [DjangoFilterBackend]
    filterset_fields   = ["return_type", "status", "return_period"]

    def get_queryset(self):
        return GSTRFilingLog.objects.filter(plant=_plant(self.request))

    def get_serializer_class(self):
        if self.action == "retrieve":
            return GSTRFilingLogDetailSerializer
        return GSTRFilingLogListSerializer

    @action(detail=False, methods=["post"])
    def submit_gstr1(self, request):
        """Submit GSTR-1 for a return period."""
        ser = SubmitGSTR1Serializer(data=request.data)
        ser.is_valid(raise_exception=True)
        try:
            filing = services.submit_gstr1(
                _plant(request), ser.validated_data["return_period"], request.user
            )
            return Response(GSTRFilingLogDetailSerializer(filing).data, status=201)
        except ValueError as e:
            return Response({"error": str(e)}, status=400)

    @action(detail=False, methods=["post"])
    def submit_gstr3b(self, request):
        """Submit GSTR-3B for a return period."""
        ser = SubmitGSTR3BSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        try:
            filing = services.submit_gstr3b(
                _plant(request),
                ser.validated_data["return_period"],
                ser.validated_data["tax_paid_challan"],
                request.user,
            )
            return Response(GSTRFilingLogDetailSerializer(filing).data, status=201)
        except ValueError as e:
            return Response({"error": str(e)}, status=400)
