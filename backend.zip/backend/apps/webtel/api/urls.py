"""Webtel Module URL Router — Section 7"""
from rest_framework.routers import DefaultRouter
from django.urls import path, include
from apps.webtel.api.viewsets import (
    WebtelConfigViewSet,
    IRNRequestViewSet,
    EwayBillRequestViewSet,
    GSTR2BViewSet,
    GSTR2BReconViewSet,
    VendorGSTMismatchViewSet,
    GSTRFilingLogViewSet,
)

router = DefaultRouter()
router.register("config",           WebtelConfigViewSet,        basename="webtel-config")
router.register("irn",              IRNRequestViewSet,          basename="irn")
router.register("eway-bill",        EwayBillRequestViewSet,     basename="eway-bill")
router.register("gstr2b",           GSTR2BViewSet,              basename="gstr2b")
router.register("gstr2b-recon",     GSTR2BReconViewSet,         basename="gstr2b-recon")
router.register("vendor-mismatches",VendorGSTMismatchViewSet,   basename="vendor-mismatch")
router.register("filings",          GSTRFilingLogViewSet,       basename="gstr-filing")

app_name = "webtel"
urlpatterns = [path("", include(router.urls))]
