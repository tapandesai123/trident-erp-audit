"""Webtel Module Serializers — Section 7"""
from rest_framework import serializers
from apps.webtel.models import (
    WebtelConfig,
    IRNRequest,
    EwayBillRequest,
    GSTR2BData,
    GSTR2BLine,
    GSTR2BReconciliation,
    VendorGSTMismatch,
    GSTRFilingLog,
)


# ── WebtelConfig ──────────────────────────────────────────────────

class WebtelConfigSerializer(serializers.ModelSerializer):
    plant_name        = serializers.CharField(source="plant.name", read_only=True)
    token_valid       = serializers.BooleanField(source="token_is_valid", read_only=True)
    class Meta:
        model   = WebtelConfig
        exclude = ["access_token", "refresh_token"]  # Never expose tokens in API


class WebtelConfigCreateSerializer(serializers.Serializer):
    environment         = serializers.ChoiceField(choices=WebtelConfig.APIEnvironment.choices)
    irn_base_url        = serializers.URLField(required=False)
    eway_base_url       = serializers.URLField(required=False)
    gstr_base_url       = serializers.URLField(required=False)
    username            = serializers.CharField(max_length=100)
    client_id           = serializers.CharField(max_length=100, required=False, allow_blank=True)
    gstin               = serializers.CharField(max_length=15)
    eway_bill_threshold = serializers.DecimalField(max_digits=12, decimal_places=2, default=50000)
    auto_generate_irn   = serializers.BooleanField(default=True)
    auto_generate_eway  = serializers.BooleanField(default=True)


# ── IRN Request ───────────────────────────────────────────────────

class IRNRequestListSerializer(serializers.ModelSerializer):
    invoice_number = serializers.CharField(source="invoice.invoice_number", read_only=True)
    class Meta:
        model  = IRNRequest
        fields = ["id", "uuid", "invoice", "invoice_number", "action", "status",
                  "irn", "ack_number", "ack_date", "error_code", "error_message",
                  "api_call_duration_ms", "created_at"]


class IRNRequestDetailSerializer(serializers.ModelSerializer):
    invoice_number = serializers.CharField(source="invoice.invoice_number", read_only=True)
    class Meta:
        model  = IRNRequest
        exclude = ["request_payload", "signed_invoice"]  # Exclude large fields from list
        # Expose for detail view:
    def to_representation(self, instance):
        rep = super().to_representation(instance)
        rep["request_payload"] = instance.request_payload
        return rep


class GenerateIRNSerializer(serializers.Serializer):
    invoice_id = serializers.UUIDField()


class CancelIRNSerializer(serializers.Serializer):
    invoice_id     = serializers.UUIDField()
    cancel_reason  = serializers.ChoiceField(choices=[
        ("DUPLICATE", "Duplicate"),
        ("DATA_ENTRY_MISTAKE", "Data Entry Mistake"),
        ("ORDER_CANCELLED", "Order Cancelled"),
        ("OTHER", "Other"),
    ])


# ── e-Way Bill Request ────────────────────────────────────────────

class EwayBillRequestListSerializer(serializers.ModelSerializer):
    invoice_number = serializers.CharField(source="invoice.invoice_number", read_only=True)
    class Meta:
        model  = EwayBillRequest
        fields = ["id", "uuid", "invoice", "invoice_number", "action", "status",
                  "eway_bill_number", "eway_bill_date", "eway_bill_valid_until",
                  "error_code", "error_message", "api_call_duration_ms", "created_at"]


class EwayBillRequestDetailSerializer(serializers.ModelSerializer):
    invoice_number = serializers.CharField(source="invoice.invoice_number", read_only=True)
    class Meta:
        model  = EwayBillRequest
        fields = "__all__"


class GenerateEwaySerializer(serializers.Serializer):
    invoice_id = serializers.UUIDField()


class ExtendEwaySerializer(serializers.Serializer):
    invoice_id       = serializers.UUIDField()
    extension_reason = serializers.CharField(max_length=300)


class CancelEwaySerializer(serializers.Serializer):
    invoice_id    = serializers.UUIDField()
    cancel_reason = serializers.ChoiceField(choices=[
        ("DUPLICATE", "Duplicate"),
        ("ORDER_CANCELLED", "Order Cancelled"),
        ("DATA_ENTRY_MISTAKE", "Data Entry Mistake"),
        ("OTHER", "Other"),
    ])


class UpdateVehicleSerializer(serializers.Serializer):
    invoice_id     = serializers.UUIDField()
    vehicle_number = serializers.CharField(max_length=20)
    from_place     = serializers.CharField(max_length=100)


# ── GSTR-2B ───────────────────────────────────────────────────────

class GSTR2BLineSerializer(serializers.ModelSerializer):
    class Meta:
        model  = GSTR2BLine
        fields = ["id", "supplier_gstin", "supplier_name", "doc_type", "doc_number",
                  "doc_date", "taxable_value", "igst", "cgst", "sgst",
                  "itc_availability", "place_of_supply", "reverse_charge"]


class GSTR2BDataListSerializer(serializers.ModelSerializer):
    class Meta:
        model  = GSTR2BData
        fields = ["id", "uuid", "plant", "return_period", "fetch_status",
                  "total_records", "total_igst", "total_cgst", "total_sgst",
                  "matched_count", "mismatched_count", "missing_in_2b_count",
                  "extra_in_2b_count", "fetched_at", "reconciled_at"]


class GSTR2BDataDetailSerializer(serializers.ModelSerializer):
    lines = GSTR2BLineSerializer(many=True, read_only=True)
    class Meta:
        model  = GSTR2BData
        exclude = ["raw_response"]


class FetchGSTR2BSerializer(serializers.Serializer):
    return_period = serializers.CharField(max_length=7, help_text="MMYYYY e.g. 012026")


# ── GSTR-2B Reconciliation ────────────────────────────────────────

class GSTR2BReconListSerializer(serializers.ModelSerializer):
    doc_number   = serializers.CharField(source="gstr2b_line.doc_number", read_only=True, default="")
    supplier     = serializers.CharField(source="gstr2b_line.supplier_gstin", read_only=True, default="")
    class Meta:
        model  = GSTR2BReconciliation
        fields = ["id", "uuid", "match_status", "doc_number", "supplier",
                  "our_doc_number", "our_supplier_gstin",
                  "our_taxable_value", "diff_cgst", "diff_sgst", "diff_igst",
                  "resolution_notes", "resolved_at"]


class GSTR2BReconDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model  = GSTR2BReconciliation
        fields = "__all__"


class ReconResolveSerializer(serializers.Serializer):
    resolution_notes = serializers.CharField()
    new_status       = serializers.ChoiceField(choices=[
        ("ACCEPTED", "Accept as correct"),
        ("IGNORED", "Ignore — not claimable"),
    ])


# ── Vendor GST Mismatch ───────────────────────────────────────────

class VendorGSTMismatchListSerializer(serializers.ModelSerializer):
    vendor_name = serializers.CharField(source="vendor.name", read_only=True)
    class Meta:
        model  = VendorGSTMismatch
        fields = ["id", "uuid", "vendor", "vendor_name", "mismatch_type", "status",
                  "our_amount", "their_amount", "difference", "invoice_ref",
                  "email_sent_at", "resolved_at"]


class VendorGSTMismatchDetailSerializer(serializers.ModelSerializer):
    vendor_name = serializers.CharField(source="vendor.name", read_only=True)
    class Meta:
        model  = VendorGSTMismatch
        fields = "__all__"


class SendMismatchEmailsSerializer(serializers.Serializer):
    return_period = serializers.CharField(max_length=7)


# ── GSTR Filing Log ───────────────────────────────────────────────

class GSTRFilingLogListSerializer(serializers.ModelSerializer):
    class Meta:
        model  = GSTRFilingLog
        fields = ["id", "uuid", "return_type", "return_period", "status", "arn",
                  "total_tax_paid", "filed_at", "filed_by"]


class GSTRFilingLogDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model  = GSTRFilingLog
        fields = "__all__"


class SubmitGSTR1Serializer(serializers.Serializer):
    return_period = serializers.CharField(max_length=7)


class SubmitGSTR3BSerializer(serializers.Serializer):
    return_period       = serializers.CharField(max_length=7)
    tax_paid_challan    = serializers.CharField(max_length=50, help_text="BSR challan number")
