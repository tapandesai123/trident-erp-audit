from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('webtel', '0001_initial'),
    ]

    operations = [
        migrations.AddField(
            model_name='webtelconfig',
            name='is_irn_mandatory',
            field=models.BooleanField(
                default=True,
                help_text=(
                    'Set to True only if aggregate turnover > ₹5Cr (e-invoicing mandate). '
                    'When False, IRN will NOT be auto-generated for any invoice. (BUG-029)'
                ),
            ),
        ),
    ]
