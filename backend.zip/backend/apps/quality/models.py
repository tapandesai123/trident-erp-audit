"""
Quality Control Module Models — Section 9
Models: SamplingScheme, InspectionPlan, InspectionPlanCharacteristic,
        InspectionLot, InspectionResult, NCR, NCRLine, CAPA
"""
from decimal import Decimal
from django.db import models
from django.conf import settings
from apps.core.models import UUIDModel, TimeStampedModel, Plant
from apps.masters.models import Item, UOM, Vendor


# ═══════════════════════════════════════════════════════════════════
# AQL / SAMPLING SCHEME  (ISO 2859-1 lookup table)
# ═══════════════════════════════════════════════════════════════════

class SamplingScheme(TimeStampedModel):
    """
    AQL sampling table entry.
    Stores sample size and accept/reject numbers for a given lot size range and AQL level.
    """
    AQL_LEVELS = [
        ("0.065", "0.065"), ("0.10", "0.10"), ("0.15", "0.15"),
        ("0.25", "0.25"), ("0.40", "0.40"), ("0.65", "0.65"),
        ("1.0", "1.0"), ("1.5", "1.5"), ("2.5", "2.5"),
        ("4.0", "4.0"), ("6.5", "6.5"), ("10.0", "10.0"),
    ]
    INSPECTION_LEVEL = [
        ("I", "Level I (Reduced)"),
        ("II", "Level II (Normal)"),
        ("III", "Level III (Tightened)"),
    ]

    name = models.CharField(max_length=100)
    inspection_level = models.CharField(max_length=5, choices=INSPECTION_LEVEL, default="II")
    aql_level = models.CharField(max_length=10, choices=AQL_LEVELS, default="1.0")
    lot_size_min = models.PositiveIntegerField()
    lot_size_max = models.PositiveIntegerField(null=True, blank=True, help_text="Null = no upper limit")
    sample_size = models.PositiveIntegerField()
    accept_number = models.PositiveIntegerField(help_text="Max defectives to accept")
    reject_number = models.PositiveIntegerField(help_text="Min defectives to reject")
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ["aql_level", "lot_size_min"]

    def __str__(self):
        return f"AQL {self.aql_level} | Lot {self.lot_size_min}–{self.lot_size_max or '∞'} | n={self.sample_size}"


# ═══════════════════════════════════════════════════════════════════
# INSPECTION PLAN
# ═══════════════════════════════════════════════════════════════════

class InspectionPlan(UUIDModel, TimeStampedModel):
    TRIGGER_CHOICES = [
        ("INCOMING", "Incoming (GRN/MRR)"),
        ("IN_PROCESS", "In-Process (JobCard)"),
        ("FG", "Finished Goods (WO Completion)"),
        ("OUTGOING", "Outgoing (Despatch)"),
        ("PERIODIC", "Periodic / Audit"),
    ]

    plant = models.ForeignKey(Plant, on_delete=models.PROTECT, related_name="inspection_plans")
    item = models.ForeignKey(Item, on_delete=models.PROTECT, related_name="inspection_plans",
                             null=True, blank=True)
    item_group = models.ForeignKey("masters.ItemGroup", on_delete=models.SET_NULL,
                                   null=True, blank=True, related_name="inspection_plans")
    trigger = models.CharField(max_length=20, choices=TRIGGER_CHOICES)
    plan_name = models.CharField(max_length=200)
    sampling_scheme = models.ForeignKey(SamplingScheme, on_delete=models.SET_NULL,
                                        null=True, blank=True)
    is_mandatory = models.BooleanField(default=True)
    is_active = models.BooleanField(default=True)
    rejection_threshold = models.DecimalField(
        max_digits=5, decimal_places=2, default=5,
        help_text="% rejection above which HOD notification is triggered",
    )
    effective_from = models.DateField()
    effective_to = models.DateField(null=True, blank=True)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
                                   null=True, related_name="inspection_plans_created")

    class Meta:
        ordering = ["trigger", "plan_name"]

    def __str__(self):
        return f"{self.plan_name} ({self.trigger})"


class InspectionPlanCharacteristic(UUIDModel, TimeStampedModel):
    """Individual quality characteristic / parameter to inspect."""
    TEST_TYPE = [
        ("VARIABLE", "Variable (Measurable)"),
        ("ATTRIBUTE", "Attribute (Pass/Fail)"),
    ]

    plan = models.ForeignKey(InspectionPlan, on_delete=models.CASCADE, related_name="characteristics")
    seq_no = models.PositiveSmallIntegerField(default=10)
    characteristic_name = models.CharField(max_length=200)
    test_type = models.CharField(max_length=20, choices=TEST_TYPE, default="ATTRIBUTE")
    uom = models.ForeignKey(UOM, on_delete=models.SET_NULL, null=True, blank=True)
    min_value = models.DecimalField(max_digits=14, decimal_places=4, null=True, blank=True)
    max_value = models.DecimalField(max_digits=14, decimal_places=4, null=True, blank=True)
    target_value = models.DecimalField(max_digits=14, decimal_places=4, null=True, blank=True)
    is_critical = models.BooleanField(default=False, help_text="Failure blocks lot disposition")
    method = models.CharField(max_length=300, blank=True, help_text="Test method / instrument")

    class Meta:
        unique_together = [["plan", "seq_no"]]
        ordering = ["seq_no"]

    def __str__(self):
        return f"{self.plan.plan_name} / {self.characteristic_name}"


# ═══════════════════════════════════════════════════════════════════
# INSPECTION LOT
# ═══════════════════════════════════════════════════════════════════

class InspectionLot(UUIDModel, TimeStampedModel):
    LOT_STATUS = [
        ("OPEN", "Open"),
        ("IN_PROGRESS", "In Progress"),
        ("COMPLETED", "Completed"),
        ("ACCEPTED", "Accepted"),
        ("REJECTED", "Rejected"),
        ("CONDITIONALLY_ACCEPTED", "Conditionally Accepted"),
        ("CANCELLED", "Cancelled"),
    ]
    ORIGIN_DOC = [
        ("MRR", "Material Receipt Record"),
        ("WO", "Work Order"),
        ("JOBCARD", "Job Card"),
        ("DESPATCH", "Despatch Note"),
        ("MANUAL", "Manual"),
    ]

    plant = models.ForeignKey(Plant, on_delete=models.PROTECT, related_name="inspection_lots")
    lot_number = models.CharField(max_length=30, unique=True)
    inspection_plan = models.ForeignKey(InspectionPlan, on_delete=models.PROTECT,
                                        related_name="lots")
    item = models.ForeignKey(Item, on_delete=models.PROTECT, related_name="inspection_lots")
    vendor = models.ForeignKey(Vendor, on_delete=models.SET_NULL, null=True, blank=True,
                               related_name="inspection_lots")

    # In-process QC linkage
    job_card = models.ForeignKey(
        'production.JobCard', on_delete=models.SET_NULL,
        null=True, blank=True, related_name='inspection_lots',
    )
    work_order = models.ForeignKey(
        'production.WorkOrder', on_delete=models.SET_NULL,
        null=True, blank=True, related_name='inspection_lots',
    )
    qty_produced = models.PositiveIntegerField(null=True, blank=True)
    qty_rejected = models.PositiveIntegerField(null=True, blank=True)
    rejection_reason = models.TextField(blank=True)
    stage = models.CharField(max_length=100, blank=True)

    # Source traceability
    origin_doc = models.CharField(max_length=20, choices=ORIGIN_DOC, default="MANUAL")
    origin_doc_id = models.IntegerField(null=True, blank=True, db_index=True)
    origin_doc_number = models.CharField(max_length=50, blank=True)

    lot_qty = models.DecimalField(max_digits=14, decimal_places=4)
    sample_qty = models.DecimalField(max_digits=14, decimal_places=4, default=0)
    uom = models.ForeignKey(UOM, on_delete=models.PROTECT)

    status = models.CharField(max_length=30, choices=LOT_STATUS, default="OPEN")
    inspection_date = models.DateField()
    due_date = models.DateField(null=True, blank=True)
    completed_date = models.DateField(null=True, blank=True)

    inspector = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
                                  null=True, blank=True, related_name="inspection_lots_inspected")
    defects_found = models.PositiveIntegerField(default=0)
    remarks = models.TextField(blank=True)

    # Disposition
    disposition_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
                                       null=True, blank=True, related_name="lots_dispositioned")
    disposition_remarks = models.TextField(blank=True)

    class Meta:
        ordering = ["-inspection_date", "-created_at"]
        indexes = [
            models.Index(fields=["plant", "status"]),
            models.Index(fields=["origin_doc", "origin_doc_id"]),
        ]

    def __str__(self):
        return f"{self.lot_number} — {self.item.item_code} ({self.status})"


# ═══════════════════════════════════════════════════════════════════
# INSPECTION RESULT
# ═══════════════════════════════════════════════════════════════════

class InspectionResult(UUIDModel, TimeStampedModel):
    RESULT_CHOICES = [
        ("PASS", "Pass"),
        ("FAIL", "Fail"),
        ("CONDITIONAL", "Conditional"),
    ]

    lot = models.ForeignKey(InspectionLot, on_delete=models.CASCADE, related_name="results")
    characteristic = models.ForeignKey(InspectionPlanCharacteristic, on_delete=models.PROTECT,
                                       related_name="results")
    measured_value = models.DecimalField(max_digits=14, decimal_places=4, null=True, blank=True)
    result = models.CharField(max_length=20, choices=RESULT_CHOICES)
    defect_count = models.PositiveIntegerField(default=0, help_text="For attribute inspection")
    remarks = models.CharField(max_length=500, blank=True)
    inspected_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
                                     null=True, related_name="inspection_results")
    inspected_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = [["lot", "characteristic"]]
        ordering = ["characteristic__seq_no"]

    def __str__(self):
        return f"{self.lot.lot_number} / {self.characteristic.characteristic_name}: {self.result}"

    @property
    def is_within_spec(self):
        """True if measured_value is within [min_value, max_value]."""
        char = self.characteristic
        if self.measured_value is None:
            return self.result == "PASS"
        if char.min_value is not None and self.measured_value < char.min_value:
            return False
        if char.max_value is not None and self.measured_value > char.max_value:
            return False
        return True


# ═══════════════════════════════════════════════════════════════════
# NCR — Non-Conformance Report
# ═══════════════════════════════════════════════════════════════════

class NCR(UUIDModel, TimeStampedModel):
    NCR_STATUS = [
        ("OPEN", "Open"),
        ("UNDER_REVIEW", "Under Review"),
        ("DISPOSITION", "Pending Disposition"),
        ("CLOSED", "Closed"),
        ("CANCELLED", "Cancelled"),
    ]
    SEVERITY = [
        ("CRITICAL", "Critical"),
        ("MAJOR", "Major"),
        ("MINOR", "Minor"),
    ]
    DISPOSITION_CHOICES = [
        ("USE_AS_IS", "Use As-Is"),
        ("REWORK", "Rework"),
        ("RETURN_TO_VENDOR", "Return to Vendor"),
        ("SCRAP", "Scrap"),
        ("CONCESSION", "Customer Concession"),
    ]

    plant = models.ForeignKey(Plant, on_delete=models.PROTECT, related_name="ncrs")
    ncr_number = models.CharField(max_length=30, unique=True)
    inspection_lot = models.ForeignKey(InspectionLot, on_delete=models.SET_NULL,
                                       null=True, blank=True, related_name="ncrs")
    item = models.ForeignKey(Item, on_delete=models.PROTECT, related_name="ncrs")
    vendor = models.ForeignKey(Vendor, on_delete=models.SET_NULL, null=True, blank=True,
                               related_name="ncrs")
    ncr_date = models.DateField()
    severity = models.CharField(max_length=20, choices=SEVERITY, default="MAJOR")
    status = models.CharField(max_length=20, choices=NCR_STATUS, default="OPEN")
    description = models.TextField(help_text="Description of non-conformance")
    quantity_affected = models.DecimalField(max_digits=14, decimal_places=4)
    uom = models.ForeignKey(UOM, on_delete=models.PROTECT)
    disposition = models.CharField(max_length=30, choices=DISPOSITION_CHOICES, blank=True)
    disposition_remarks = models.TextField(blank=True)
    rework_cost = models.DecimalField(max_digits=14, decimal_places=2, default=0)

    # Block flags
    block_vendor_po = models.BooleanField(default=False)
    quarantine_stock = models.BooleanField(default=False)

    raised_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
                                  null=True, related_name="ncrs_raised")
    closed_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
                                  null=True, blank=True, related_name="ncrs_closed")
    closed_date = models.DateField(null=True, blank=True)
    root_cause = models.TextField(blank=True)

    class Meta:
        ordering = ["-ncr_date", "-created_at"]
        indexes = [models.Index(fields=["plant", "status", "severity"])]

    def __str__(self):
        return f"{self.ncr_number} — {self.item.item_code} ({self.severity})"


class NCRLine(UUIDModel, TimeStampedModel):
    """Defect detail lines under an NCR."""
    DEFECT_CATEGORY = [
        ("DIMENSIONAL", "Dimensional"),
        ("VISUAL", "Visual / Surface"),
        ("FUNCTIONAL", "Functional"),
        ("DOCUMENTATION", "Documentation"),
        ("LABELING", "Labeling / Marking"),
        ("OTHER", "Other"),
    ]

    ncr = models.ForeignKey(NCR, on_delete=models.CASCADE, related_name="lines")
    line_no = models.PositiveSmallIntegerField()
    defect_category = models.CharField(max_length=30, choices=DEFECT_CATEGORY)
    defect_description = models.CharField(max_length=500)
    qty_defective = models.DecimalField(max_digits=14, decimal_places=4)
    characteristic = models.ForeignKey(InspectionPlanCharacteristic, on_delete=models.SET_NULL,
                                       null=True, blank=True)

    class Meta:
        unique_together = [["ncr", "line_no"]]
        ordering = ["line_no"]

    def __str__(self):
        return f"{self.ncr.ncr_number}/{self.line_no} {self.defect_category}"


# ═══════════════════════════════════════════════════════════════════
# CAPA — Corrective & Preventive Action
# ═══════════════════════════════════════════════════════════════════

class CAPA(UUIDModel, TimeStampedModel):
    CAPA_TYPE = [
        ("CORRECTIVE", "Corrective Action"),
        ("PREVENTIVE", "Preventive Action"),
    ]
    CAPA_STATUS = [
        ("OPEN", "Open"),
        ("IN_PROGRESS", "In Progress"),
        ("PENDING_VERIFICATION", "Pending Verification"),
        ("CLOSED", "Closed"),
        ("CANCELLED", "Cancelled"),
    ]

    plant = models.ForeignKey(Plant, on_delete=models.PROTECT, related_name="capas")
    capa_number = models.CharField(max_length=30, unique=True)
    ncr = models.ForeignKey(NCR, on_delete=models.SET_NULL, null=True, blank=True,
                            related_name="capas")
    capa_type = models.CharField(max_length=20, choices=CAPA_TYPE)
    status = models.CharField(max_length=30, choices=CAPA_STATUS, default="OPEN")
    description = models.TextField()
    root_cause_analysis = models.TextField(blank=True)
    action_planned = models.TextField()
    action_taken = models.TextField(blank=True)
    target_date = models.DateField()
    actual_close_date = models.DateField(null=True, blank=True)

    owner = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
                              null=True, related_name="capas_owned")
    verified_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
                                    null=True, blank=True, related_name="capas_verified")
    verification_remarks = models.TextField(blank=True)
    effectiveness_rating = models.PositiveSmallIntegerField(
        null=True, blank=True, help_text="1-5 rating of action effectiveness"
    )

    class Meta:
        ordering = ["-created_at"]
        indexes = [models.Index(fields=["plant", "status", "capa_type"])]

    def __str__(self):
        return f"{self.capa_number} ({self.capa_type}) — {self.status}"
