"""Quality Control API URLs."""
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from apps.quality.api.viewsets import (
    SamplingSchemeViewSet, InspectionPlanViewSet,
    InspectionLotViewSet, NCRViewSet, CAPAViewSet,
)

router = DefaultRouter()
router.register("sampling-schemes", SamplingSchemeViewSet, basename="sampling-scheme")
router.register("inspection-plans", InspectionPlanViewSet, basename="inspection-plan")
router.register("inspection-lots", InspectionLotViewSet, basename="inspection-lot")
router.register("ncrs", NCRViewSet, basename="ncr")
router.register("capas", CAPAViewSet, basename="capa")

urlpatterns = [
    path("", include(router.urls)),
]
