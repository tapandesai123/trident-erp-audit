"""Quality Control API Serializers — 3 variants per major model."""
from rest_framework import serializers
from apps.quality.models import (
    SamplingScheme, InspectionPlan, InspectionPlanCharacteristic,
    InspectionLot, InspectionResult,
    NCR, NCRLine, CAPA,
)


# ─── SamplingScheme ───────────────────────────────────────────────

class SamplingSchemeSerializer(serializers.ModelSerializer):
    class Meta:
        model = SamplingScheme
        fields = "__all__"


# ─── InspectionPlan ───────────────────────────────────────────────

class InspectionPlanCharacteristicSerializer(serializers.ModelSerializer):
    uom_code = serializers.CharField(source="uom.uom_code", read_only=True)

    class Meta:
        model = InspectionPlanCharacteristic
        fields = [
            "id", "uuid", "seq_no", "characteristic_name", "test_type",
            "uom", "uom_code", "min_value", "max_value", "target_value",
            "is_critical", "method",
        ]


class InspectionPlanListSerializer(serializers.ModelSerializer):
    item_code = serializers.CharField(source="item.item_code", read_only=True)
    char_count = serializers.IntegerField(source="characteristics.count", read_only=True)

    class Meta:
        model = InspectionPlan
        fields = [
            "id", "uuid", "plan_name", "trigger", "item", "item_code",
            "is_mandatory", "is_active", "effective_from", "char_count",
        ]


class InspectionPlanDetailSerializer(serializers.ModelSerializer):
    characteristics = InspectionPlanCharacteristicSerializer(many=True, read_only=True)

    class Meta:
        model = InspectionPlan
        fields = "__all__"


class InspectionPlanCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = InspectionPlan
        fields = [
            "plant", "item", "item_group", "trigger", "plan_name",
            "sampling_scheme", "is_mandatory", "effective_from", "effective_to",
        ]


# ─── InspectionLot ────────────────────────────────────────────────

class InspectionResultSerializer(serializers.ModelSerializer):
    characteristic_name = serializers.CharField(
        source="characteristic.characteristic_name", read_only=True
    )
    is_within_spec = serializers.BooleanField(read_only=True)

    class Meta:
        model = InspectionResult
        fields = [
            "id", "uuid", "characteristic", "characteristic_name",
            "measured_value", "result", "defect_count", "remarks",
            "is_within_spec", "inspected_at",
        ]


class InspectionLotListSerializer(serializers.ModelSerializer):
    item_code = serializers.CharField(source="item.item_code", read_only=True)
    plan_name = serializers.CharField(source="inspection_plan.plan_name", read_only=True)

    class Meta:
        model = InspectionLot
        fields = [
            "id", "uuid", "lot_number", "status", "item", "item_code",
            "plan_name", "lot_qty", "sample_qty", "defects_found",
            "inspection_date", "due_date",
        ]


class InspectionLotDetailSerializer(serializers.ModelSerializer):
    item_code = serializers.CharField(source="item.item_code", read_only=True)
    results = InspectionResultSerializer(many=True, read_only=True)

    class Meta:
        model = InspectionLot
        fields = "__all__"


class InspectionLotCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = InspectionLot
        fields = [
            "plant", "inspection_plan", "item", "vendor", "lot_qty", "uom",
            "origin_doc", "origin_doc_id", "origin_doc_number",
            "inspector", "inspection_date",
        ]


# ─── NCR ──────────────────────────────────────────────────────────

class NCRLineSerializer(serializers.ModelSerializer):
    class Meta:
        model = NCRLine
        fields = [
            "id", "uuid", "line_no", "defect_category", "defect_description",
            "qty_defective", "characteristic",
        ]


class NCRListSerializer(serializers.ModelSerializer):
    item_code = serializers.CharField(source="item.item_code", read_only=True)

    class Meta:
        model = NCR
        fields = [
            "id", "uuid", "ncr_number", "severity", "status",
            "item", "item_code", "ncr_date", "quantity_affected",
            "disposition", "block_vendor_po",
        ]


class NCRDetailSerializer(serializers.ModelSerializer):
    item_code = serializers.CharField(source="item.item_code", read_only=True)
    lines = NCRLineSerializer(many=True, read_only=True)

    class Meta:
        model = NCR
        fields = "__all__"


class NCRCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = NCR
        fields = [
            "plant", "item", "vendor", "inspection_lot", "ncr_date",
            "severity", "description", "quantity_affected", "uom",
            "block_vendor_po", "quarantine_stock",
        ]


# ─── CAPA ─────────────────────────────────────────────────────────

class CAPAListSerializer(serializers.ModelSerializer):
    owner_name = serializers.CharField(source="owner.get_full_name", read_only=True)

    class Meta:
        model = CAPA
        fields = [
            "id", "uuid", "capa_number", "capa_type", "status",
            "description", "target_date", "actual_close_date",
            "owner", "owner_name", "effectiveness_rating",
        ]


class CAPADetailSerializer(serializers.ModelSerializer):
    ncr_number = serializers.CharField(source="ncr.ncr_number", read_only=True)

    class Meta:
        model = CAPA
        fields = "__all__"


class CAPACreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = CAPA
        fields = [
            "plant", "ncr", "capa_type", "description",
            "root_cause_analysis", "action_planned", "target_date", "owner",
        ]
