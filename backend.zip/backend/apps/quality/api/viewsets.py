"""Quality Control API Viewsets."""
from decimal import Decimal
from datetime import date
from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated

from apps.quality.models import (
    SamplingScheme, InspectionPlan, InspectionPlanCharacteristic,
    InspectionLot, InspectionResult,
    NCR, NCRLine, CAPA,
)
from apps.quality.api.serializers import (
    SamplingSchemeSerializer,
    InspectionPlanListSerializer, InspectionPlanDetailSerializer, InspectionPlanCreateSerializer,
    InspectionLotListSerializer, InspectionLotDetailSerializer, InspectionLotCreateSerializer,
    InspectionResultSerializer,
    NCRListSerializer, NCRDetailSerializer, NCRCreateSerializer,
    CAPAListSerializer, CAPADetailSerializer, CAPACreateSerializer,
)
from apps.quality import services


class SamplingSchemeViewSet(viewsets.ModelViewSet):
    queryset = SamplingScheme.objects.all()
    permission_classes = [IsAuthenticated]
    serializer_class = SamplingSchemeSerializer

    @action(detail=False, methods=["get"])
    def lookup(self, request):
        """GET /api/v1/quality/sampling-schemes/lookup/?lot_qty=500&aql=1.0&level=II"""
        lot_qty = int(request.query_params.get("lot_qty", 100))
        aql = request.query_params.get("aql", "1.0")
        level = request.query_params.get("level", "II")
        result = services.aql_sampling_size(lot_qty, aql, level)
        return Response(result)


class InspectionPlanViewSet(viewsets.ModelViewSet):
    queryset = InspectionPlan.objects.select_related(
        "plant", "item", "sampling_scheme"
    ).prefetch_related("characteristics")
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return InspectionPlanListSerializer
        if self.action in ("create", "update", "partial_update"):
            return InspectionPlanCreateSerializer
        return InspectionPlanDetailSerializer

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)


class InspectionLotViewSet(viewsets.ModelViewSet):
    queryset = InspectionLot.objects.select_related(
        "plant", "item", "vendor", "inspection_plan", "inspector"
    ).prefetch_related("results", "ncrs")
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return InspectionLotListSerializer
        if self.action in ("create", "update", "partial_update"):
            return InspectionLotCreateSerializer
        return InspectionLotDetailSerializer

    def get_queryset(self):
        qs = super().get_queryset()
        work_order = self.request.query_params.get("work_order")
        if work_order:
            qs = qs.filter(work_order_id=work_order)
        return qs

    def create(self, request, *args, **kwargs):
        from apps.masters.models import Item, UOM
        from apps.masters.models import Vendor
        d = request.data
        try:
            item = Item.objects.get(pk=d["item"])
            uom = UOM.objects.get(pk=d["uom"])
            vendor = Vendor.objects.filter(pk=d.get("vendor")).first() if d.get("vendor") else None
            plan = InspectionPlan.objects.filter(pk=d.get("inspection_plan")).first()
            lot = services.create_inspection_lot(
                plant=item.plant if hasattr(item, "plant") else None,
                item=item, lot_qty=Decimal(str(d["lot_qty"])), uom=uom,
                trigger=d.get("trigger", "MANUAL"),
                origin_doc=d.get("origin_doc", "MANUAL"),
                origin_doc_id=d.get("origin_doc_id"),
                origin_doc_number=d.get("origin_doc_number", ""),
                vendor=vendor,
                inspection_plan=plan,
                user=request.user,
            )
            return Response(InspectionLotDetailSerializer(lot).data, status=status.HTTP_201_CREATED)
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=True, methods=["post"])
    def record_result(self, request, pk=None):
        """POST result for one characteristic."""
        lot = self.get_object()
        char_id = request.data.get("characteristic")
        try:
            char = InspectionPlanCharacteristic.objects.get(pk=char_id)
        except InspectionPlanCharacteristic.DoesNotExist:
            return Response({"error": "Characteristic not found"}, status=status.HTTP_404_NOT_FOUND)
        try:
            ir = services.record_inspection_result(
                lot=lot,
                characteristic=char,
                result=request.data.get("result", "PASS"),
                measured_value=Decimal(str(request.data["measured_value"]))
                    if request.data.get("measured_value") is not None else None,
                defect_count=int(request.data.get("defect_count", 0)),
                remarks=request.data.get("remarks", ""),
                user=request.user,
            )
            return Response(InspectionResultSerializer(ir).data)
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=True, methods=["post"])
    def disposition(self, request, pk=None):
        """POST: accept / reject / conditionally accept a lot."""
        lot = self.get_object()
        disp = request.data.get("disposition", "ACCEPTED")
        try:
            lot = services.disposition_lot(
                lot=lot,
                disposition=disp,
                remarks=request.data.get("remarks", ""),
                user=request.user,
            )
            return Response(InspectionLotDetailSerializer(lot).data)
        except ValueError as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=False, methods=["get"])
    def dashboard(self, request):
        """Quality dashboard summary."""
        from apps.core.models import Plant
        plant_id = request.query_params.get("plant")
        try:
            plant = Plant.objects.get(pk=plant_id)
            return Response(services.get_quality_dashboard(plant))
        except Plant.DoesNotExist:
            return Response({"error": "Plant not found"}, status=status.HTTP_404_NOT_FOUND)

    @action(detail=False, methods=["post"], url_path="from-scan")
    def from_scan(self, request):
        """
        POST /api/v1/quality/inspection-lots/from-scan/
        Body: {job_card_qr, stage, qty_produced, qty_rejected, rejection_reason}
        """
        from apps.production.models import JobCard, WorkOrder
        from apps.quality.models import InspectionPlan
        from apps.core.models import Notification
        from django.contrib.auth import get_user_model
        import json
        from decimal import Decimal
        from datetime import date

        d = request.data

        # --- Parse QR ---
        qr_raw = d.get("job_card_qr", "")
        job_card_id = None
        try:
            parsed = json.loads(qr_raw)
            job_card_id = parsed.get("job_card_id") or parsed.get("id")
        except (json.JSONDecodeError, TypeError):
            # Try plain UUID / int string
            job_card_id = qr_raw.strip()

        try:
            jc = JobCard.objects.select_related(
                "work_order", "work_order__finished_good",
                "work_order__plant", "work_order__uom"
            ).get(pk=job_card_id)
        except (JobCard.DoesNotExist, ValueError):
            return Response({"error": "Job card not found for QR"}, status=status.HTTP_404_NOT_FOUND)

        wo = jc.work_order
        stage = d.get("stage", jc.operation_name)
        qty_produced = int(d.get("qty_produced", 0))
        qty_rejected = int(d.get("qty_rejected", 0))
        rejection_reason = d.get("rejection_reason", "")

        # --- Find InspectionPlan ---
        plan = (
            InspectionPlan.objects.filter(
                plant=wo.plant, trigger="IN_PROCESS", item=wo.finished_good, is_active=True
            ).order_by("-effective_from").first()
            or InspectionPlan.objects.filter(
                plant=wo.plant, trigger="IN_PROCESS",
                item__isnull=True, is_active=True
            ).order_by("-effective_from").first()
        )

        # --- Create InspectionLot ---
        lot_number = services.get_next_doc_number(wo.plant, "IL", "IL")
        lot = InspectionLot.objects.create(
            plant=wo.plant,
            lot_number=lot_number,
            inspection_plan=plan,
            item=wo.finished_good,
            origin_doc="JOBCARD",
            origin_doc_id=jc.pk,
            origin_doc_number=jc.jc_number,
            lot_qty=Decimal(qty_produced),
            sample_qty=Decimal(qty_produced),
            uom=wo.uom,
            status="OPEN",
            inspection_date=date.today(),
            defects_found=qty_rejected,
            job_card=jc,
            work_order=wo,
            qty_produced=qty_produced,
            qty_rejected=qty_rejected,
            rejection_reason=rejection_reason,
            stage=stage,
        )

        # --- NCR if rejected ---
        ncr = None
        if qty_rejected > 0:
            ncr = services.raise_ncr(
                plant=wo.plant,
                item=wo.finished_good,
                uom=wo.uom,
                quantity_affected=Decimal(qty_rejected),
                description=rejection_reason or f"In-process rejection on Job Card {jc.jc_number}",
                severity="MAJOR",
                inspection_lot=lot,
                vendor=None,
                defect_lines=[],
                block_vendor_po=False,
                quarantine_stock=False,
                user=request.user,
            )

        # --- Notification if rejection rate > threshold ---
        if plan and qty_produced > 0:
            rejection_pct = (qty_rejected / qty_produced) * 100
            threshold = float(plan.rejection_threshold)
            if rejection_pct > threshold:
                User = get_user_model()
                # Notify users with quality HOD role / is_staff
                hod_users = User.objects.filter(is_staff=True)
                for u in hod_users:
                    Notification.objects.create(
                        user=u,
                        title="High Rejection Rate Alert",
                        message=(
                            f"Job Card {jc.jc_number} ({stage}): "
                            f"{rejection_pct:.1f}% rejection exceeds threshold {threshold}%. "
                            f"Qty Produced: {qty_produced}, Rejected: {qty_rejected}."
                        ),
                        notification_type="IN_APP",
                        module="quality",
                        resource="InspectionLot",
                    )

        result = {
            "lot_id": str(lot.pk),
            "inspection_lot_number": lot.lot_number,
            "ncr_id": str(ncr.pk) if ncr else None,
            "status": lot.status,
        }
        return Response(result, status=status.HTTP_201_CREATED)


class NCRViewSet(viewsets.ModelViewSet):
    queryset = NCR.objects.select_related(
        "plant", "item", "vendor", "inspection_lot", "raised_by"
    ).prefetch_related("lines", "capas")
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return NCRListSerializer
        if self.action in ("create", "update", "partial_update"):
            return NCRCreateSerializer
        return NCRDetailSerializer

    def create(self, request, *args, **kwargs):
        from apps.masters.models import Item, UOM
        d = request.data
        try:
            item = Item.objects.get(pk=d["item"])
            uom = UOM.objects.get(pk=d["uom"])
            lot = InspectionLot.objects.filter(pk=d.get("inspection_lot")).first()
            from apps.masters.models import Vendor
            vendor = Vendor.objects.filter(pk=d.get("vendor")).first() if d.get("vendor") else None
            from apps.core.models import Plant
            plant = Plant.objects.get(pk=d["plant"])
            ncr = services.raise_ncr(
                plant=plant, item=item, uom=uom,
                quantity_affected=Decimal(str(d["quantity_affected"])),
                description=d.get("description", ""),
                severity=d.get("severity", "MAJOR"),
                inspection_lot=lot,
                vendor=vendor,
                defect_lines=d.get("defect_lines", []),
                block_vendor_po=d.get("block_vendor_po", False),
                quarantine_stock=d.get("quarantine_stock", True),
                user=request.user,
            )
            return Response(NCRDetailSerializer(ncr).data, status=status.HTTP_201_CREATED)
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=True, methods=["post"])
    def close(self, request, pk=None):
        ncr = self.get_object()
        try:
            ncr = services.close_ncr(
                ncr=ncr,
                disposition=request.data.get("disposition", "USE_AS_IS"),
                disposition_remarks=request.data.get("disposition_remarks", ""),
                root_cause=request.data.get("root_cause", ""),
                rework_cost=Decimal(str(request.data.get("rework_cost", "0"))),
                user=request.user,
            )
            return Response(NCRDetailSerializer(ncr).data)
        except ValueError as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=True, methods=["get"])
    def vendor_open_ncrs(self, request, pk=None):
        ncr = self.get_object()
        if not ncr.vendor:
            return Response([])
        return Response(services.get_open_ncrs_for_vendor(ncr.vendor))


class CAPAViewSet(viewsets.ModelViewSet):
    queryset = CAPA.objects.select_related("plant", "ncr", "owner", "verified_by")
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return CAPAListSerializer
        if self.action in ("create", "update", "partial_update"):
            return CAPACreateSerializer
        return CAPADetailSerializer

    def create(self, request, *args, **kwargs):
        from apps.core.models import Plant
        d = request.data
        try:
            plant = Plant.objects.get(pk=d["plant"])
            ncr = NCR.objects.filter(pk=d.get("ncr")).first() if d.get("ncr") else None
            from django.contrib.auth import get_user_model
            User = get_user_model()
            owner = User.objects.filter(pk=d.get("owner")).first() if d.get("owner") else None
            capa = services.create_capa(
                plant=plant,
                capa_type=d.get("capa_type", "CORRECTIVE"),
                description=d.get("description", ""),
                action_planned=d.get("action_planned", ""),
                target_date=date.fromisoformat(d["target_date"]),
                owner=owner,
                ncr=ncr,
                user=request.user,
            )
            return Response(CAPADetailSerializer(capa).data, status=status.HTTP_201_CREATED)
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=True, methods=["post"])
    def close(self, request, pk=None):
        capa = self.get_object()
        from django.contrib.auth import get_user_model
        User = get_user_model()
        verified_by = User.objects.filter(pk=request.data.get("verified_by")).first()
        try:
            capa = services.close_capa(
                capa=capa,
                action_taken=request.data.get("action_taken", ""),
                effectiveness_rating=int(request.data.get("effectiveness_rating", 3)),
                verified_by=verified_by,
                verification_remarks=request.data.get("verification_remarks", ""),
                user=request.user,
            )
            return Response(CAPADetailSerializer(capa).data)
        except (ValueError, Exception) as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)
