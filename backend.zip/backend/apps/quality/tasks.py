"""Quality Control Celery tasks."""
from celery import shared_task
from datetime import date, timedelta


@shared_task
def auto_trigger_incoming_inspection(mrr_id: int):
    """
    Triggered after MRR is approved.
    Creates InspectionLot for each MRR line that has a mandatory incoming InspectionPlan.
    """
    try:
        from apps.purchase.models import MRR, MRRLine
        from apps.quality.services import create_inspection_lot
        from apps.masters.models import Item

        mrr = MRR.objects.get(pk=mrr_id)
        for line in mrr.lines.select_related("item", "uom"):
            try:
                create_inspection_lot(
                    plant=mrr.plant,
                    item=line.item,
                    lot_qty=line.received_qty,
                    uom=line.uom,
                    trigger="INCOMING",
                    origin_doc="MRR",
                    origin_doc_id=mrr.pk,
                    origin_doc_number=mrr.mrr_number,
                )
            except ValueError:
                pass  # No inspection plan — skip
        return {"mrr": mrr.mrr_number, "triggered": mrr.lines.count()}
    except Exception as e:
        return {"error": str(e)}


@shared_task
def auto_trigger_fg_inspection(wo_id: int):
    """
    Triggered on WorkOrder COMPLETED.
    Creates FG InspectionLot.
    """
    try:
        from apps.production.models import WorkOrder
        from apps.quality.services import create_inspection_lot
        wo = WorkOrder.objects.get(pk=wo_id)
        try:
            create_inspection_lot(
                plant=wo.plant,
                item=wo.finished_good,
                lot_qty=wo.produced_qty,
                uom=wo.uom,
                trigger="FG",
                origin_doc="WO",
                origin_doc_id=wo.pk,
                origin_doc_number=wo.wo_number,
            )
        except ValueError:
            pass
        return {"wo": wo.wo_number}
    except Exception as e:
        return {"error": str(e)}


@shared_task
def send_overdue_inspection_alerts():
    """Daily: alert inspectors about overdue lots."""
    from apps.quality.models import InspectionLot
    from apps.core.models import Notification

    today = date.today()
    overdue = InspectionLot.objects.filter(
        status__in=("OPEN", "IN_PROGRESS"),
        due_date__lt=today,
    ).select_related("inspector", "item")

    for lot in overdue:
        if lot.inspector:
            Notification.objects.get_or_create(
                user=lot.inspector,
                module="quality",
                resource="InspectionLot",
                resource_id=lot.pk,
                title=f"Overdue Inspection: {lot.lot_number}",
                defaults={
                    "message": f"Lot {lot.lot_number} for {lot.item.item_code} was due {lot.due_date}.",
                    "notification_type": "IN_APP",
                },
            )
    return {"overdue_count": overdue.count()}


@shared_task
def send_overdue_capa_alerts():
    """Daily: alert CAPA owners about overdue actions."""
    from apps.quality.models import CAPA
    from apps.core.models import Notification

    today = date.today()
    overdue = CAPA.objects.filter(
        status__in=("OPEN", "IN_PROGRESS"),
        target_date__lt=today,
    ).select_related("owner")

    for capa in overdue:
        if capa.owner:
            Notification.objects.get_or_create(
                user=capa.owner,
                module="quality",
                resource="CAPA",
                resource_id=capa.pk,
                title=f"Overdue CAPA: {capa.capa_number}",
                defaults={
                    "message": f"CAPA {capa.capa_number} was due {capa.target_date}. Please update.",
                    "notification_type": "IN_APP",
                },
            )
    return {"overdue_count": overdue.count()}


@shared_task
def generate_quality_summary_report(plant_id: int):
    """Weekly: compile quality KPI summary and email QA head."""
    try:
        from apps.core.models import Plant
        from apps.quality.services import get_quality_dashboard
        plant = Plant.objects.get(pk=plant_id)
        summary = get_quality_dashboard(plant)
        # Email would be sent here via django.core.mail
        return {"plant": plant.code, "summary": summary}
    except Exception as e:
        return {"error": str(e)}
