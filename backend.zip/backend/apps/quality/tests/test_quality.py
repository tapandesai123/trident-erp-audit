"""
Quality Control Module Tests — Section 9
24 test cases covering: AQL lookup, Inspection Lot lifecycle,
result recording, NCR raise/close, CAPA create/close, dashboard.
"""
from decimal import Decimal
from datetime import date, timedelta
from django.test import TestCase
from django.contrib.auth import get_user_model

from apps.core.models import Plant, Company
from apps.masters.models import Item, UOM, Vendor, VendorGroup, ItemGroup
from apps.quality.models import (
    SamplingScheme, InspectionPlan, InspectionPlanCharacteristic,
    InspectionLot, InspectionResult,
    NCR, NCRLine, CAPA,
)
from apps.quality import services

User = get_user_model()


def make_base():
    company = Company.objects.create(name="QC Test Co", financial_year_start=4)
    plant = Plant.objects.create(company=company, code="QP1", name="QC Plant")
    user = User.objects.create_user(username="qcuser", email="qc@test.com", password="x")
    inspector = User.objects.create_user(username="inspector1", email="inspector@test.com", password="x")
    uom = UOM.objects.create(uom_code="PCS", uom_name="Pieces")
    uom_kg = UOM.objects.create(uom_code="KGQ", uom_name="Kilograms QC")
    vgroup = VendorGroup.objects.create(name="Test VG")
    vendor = Vendor.objects.create(
        vendor_name="Test Vendor QC", vendor_code="TV01",
        vendor_group=vgroup, vendor_type="SUPPLIER",
        gst_type="REGULAR",
    )
    igroup = ItemGroup.objects.create(name="Test IG QC")
    item = Item.objects.create(
        item_code="QC_FG01", item_name="QC Test Item",
        item_type="FG", purchase_uom=uom, stock_uom=uom,
        item_group=igroup,
    )
    rm = Item.objects.create(
        item_code="QC_RM01", item_name="QC Raw Mat",
        item_type="RM", purchase_uom=uom_kg, stock_uom=uom_kg,
        item_group=igroup,
    )
    return dict(
        company=company, plant=plant, user=user, inspector=inspector,
        uom=uom, uom_kg=uom_kg, vendor=vendor, item=item, rm=rm
    )


def make_scheme(aql="1.0", level="II", lot_min=2, lot_max=8, n=2, ac=0, re=1):
    return SamplingScheme.objects.create(
        name=f"AQL{aql}-L{level}-{lot_min}", inspection_level=level, aql_level=aql,
        lot_size_min=lot_min, lot_size_max=lot_max,
        sample_size=n, accept_number=ac, reject_number=re, is_active=True,
    )


def make_plan(plant, item, trigger="INCOMING", scheme=None):
    plan = InspectionPlan.objects.create(
        plant=plant, item=item, trigger=trigger,
        plan_name=f"{item.item_code} {trigger} Plan",
        sampling_scheme=scheme, is_mandatory=True,
        effective_from=date.today(),
    )
    char = InspectionPlanCharacteristic.objects.create(
        plan=plan, seq_no=10, characteristic_name="Visual Check",
        test_type="ATTRIBUTE", is_critical=True,
    )
    char2 = InspectionPlanCharacteristic.objects.create(
        plan=plan, seq_no=20, characteristic_name="Dimension",
        test_type="VARIABLE",
        min_value=Decimal("9.5"), max_value=Decimal("10.5"), target_value=Decimal("10.0"),
    )
    return plan, char, char2


# ═══════════════════════════════════════════════════════════════════
# AQL SAMPLING TESTS
# ═══════════════════════════════════════════════════════════════════

class TestAQLSampling(TestCase):
    def setUp(self):
        self.f = make_base()

    def test_01_aql_lookup_returns_correct_scheme(self):
        """AQL lookup returns matching scheme for lot size within range."""
        make_scheme(aql="1.0", level="II", lot_min=2, lot_max=8, n=2, ac=0, re=1)
        result = services.aql_sampling_size(5, "1.0", "II")
        self.assertEqual(result["sample_size"], 2)
        self.assertEqual(result["accept_number"], 0)
        self.assertEqual(result["reject_number"], 1)

    def test_02_aql_lookup_fallback_100pct(self):
        """AQL lookup with no matching scheme falls back to 100% inspection."""
        result = services.aql_sampling_size(999, "1.0", "II")
        self.assertEqual(result["sample_size"], 999)
        self.assertIn("100%", result["scheme_name"])

    def test_03_aql_lookup_unbounded_lot_max(self):
        """Scheme with lot_size_max=None matches any lot above lot_size_min."""
        SamplingScheme.objects.create(
            name="Large Lot", inspection_level="II", aql_level="2.5",
            lot_size_min=1000, lot_size_max=None,
            sample_size=80, accept_number=5, reject_number=6, is_active=True,
        )
        result = services.aql_sampling_size(5000, "2.5", "II")
        self.assertEqual(result["sample_size"], 80)


# ═══════════════════════════════════════════════════════════════════
# INSPECTION LOT TESTS
# ═══════════════════════════════════════════════════════════════════

class TestInspectionLot(TestCase):
    def setUp(self):
        self.f = make_base()
        self.scheme = make_scheme(lot_min=1, lot_max=100, n=5, ac=1, re=2)
        self.plan, self.char, self.char2 = make_plan(
            self.f["plant"], self.f["item"], scheme=self.scheme
        )

    def test_04_create_inspection_lot(self):
        """Inspection lot created with correct lot_number and sample_qty."""
        f = self.f
        lot = services.create_inspection_lot(
            plant=f["plant"], item=f["item"],
            lot_qty=Decimal("50"), uom=f["uom"],
            trigger="INCOMING",
            inspection_plan=self.plan,
            user=f["user"],
        )
        self.assertIsNotNone(lot.pk)
        self.assertTrue(lot.lot_number.startswith("IL/"))
        self.assertEqual(lot.status, "OPEN")
        self.assertEqual(lot.sample_qty, Decimal("5"))

    def test_05_create_lot_no_plan_raises(self):
        """Creating lot without matching plan raises ValueError."""
        f = self.f
        item2 = Item.objects.create(
            item_code="NOPLAN", item_name="No Plan Item",
            item_type="RM", purchase_uom=f["uom"], stock_uom=f["uom"],
        )
        with self.assertRaises(ValueError):
            services.create_inspection_lot(
                plant=f["plant"], item=item2,
                lot_qty=Decimal("10"), uom=f["uom"],
                trigger="INCOMING", user=f["user"],
            )

    def test_06_record_result_pass(self):
        """Recording a PASS result updates lot status to IN_PROGRESS."""
        f = self.f
        lot = services.create_inspection_lot(
            plant=f["plant"], item=f["item"],
            lot_qty=Decimal("20"), uom=f["uom"],
            trigger="INCOMING", inspection_plan=self.plan,
        )
        ir = services.record_inspection_result(
            lot=lot, characteristic=self.char,
            result="PASS", user=f["user"],
        )
        self.assertEqual(ir.result, "PASS")
        lot.refresh_from_db()
        self.assertEqual(lot.status, "IN_PROGRESS")

    def test_07_record_result_with_measurement(self):
        """Variable characteristic records measured value and checks spec."""
        f = self.f
        lot = services.create_inspection_lot(
            plant=f["plant"], item=f["item"],
            lot_qty=Decimal("10"), uom=f["uom"],
            trigger="INCOMING", inspection_plan=self.plan,
        )
        ir = services.record_inspection_result(
            lot=lot, characteristic=self.char2,
            result="PASS", measured_value=Decimal("10.1"),
        )
        self.assertTrue(ir.is_within_spec)

    def test_08_out_of_spec_measured_value(self):
        """Measured value outside spec gives is_within_spec=False."""
        f = self.f
        lot = services.create_inspection_lot(
            plant=f["plant"], item=f["item"],
            lot_qty=Decimal("10"), uom=f["uom"],
            trigger="INCOMING", inspection_plan=self.plan,
        )
        ir = services.record_inspection_result(
            lot=lot, characteristic=self.char2,
            result="FAIL", measured_value=Decimal("11.5"),
        )
        self.assertFalse(ir.is_within_spec)

    def test_09_disposition_accept(self):
        """Accepted lot sets status to ACCEPTED."""
        f = self.f
        lot = services.create_inspection_lot(
            plant=f["plant"], item=f["item"],
            lot_qty=Decimal("10"), uom=f["uom"],
            trigger="INCOMING", inspection_plan=self.plan,
        )
        services.record_inspection_result(lot, self.char, "PASS")
        lot = services.disposition_lot(lot, "ACCEPTED", user=f["user"])
        self.assertEqual(lot.status, "ACCEPTED")
        self.assertIsNotNone(lot.completed_date)

    def test_10_disposition_rejected(self):
        """Rejected lot sets status to REJECTED."""
        f = self.f
        lot = services.create_inspection_lot(
            plant=f["plant"], item=f["item"],
            lot_qty=Decimal("10"), uom=f["uom"],
            trigger="INCOMING", inspection_plan=self.plan,
        )
        services.record_inspection_result(lot, self.char, "FAIL", defect_count=3)
        lot = services.disposition_lot(lot, "REJECTED", user=f["user"])
        self.assertEqual(lot.status, "REJECTED")

    def test_11_cannot_record_result_for_closed_lot(self):
        """Cannot record result for ACCEPTED lot."""
        f = self.f
        lot = services.create_inspection_lot(
            plant=f["plant"], item=f["item"],
            lot_qty=Decimal("5"), uom=f["uom"],
            trigger="INCOMING", inspection_plan=self.plan,
        )
        services.record_inspection_result(lot, self.char, "PASS")
        services.disposition_lot(lot, "ACCEPTED")
        with self.assertRaises(ValueError):
            services.record_inspection_result(lot, self.char2, "PASS")

    def test_12_defects_found_aggregated(self):
        """lot.defects_found sums across all characteristic results."""
        f = self.f
        lot = services.create_inspection_lot(
            plant=f["plant"], item=f["item"],
            lot_qty=Decimal("50"), uom=f["uom"],
            trigger="INCOMING", inspection_plan=self.plan,
        )
        services.record_inspection_result(lot, self.char, "FAIL", defect_count=2)
        services.record_inspection_result(lot, self.char2, "FAIL", defect_count=3)
        lot.refresh_from_db()
        self.assertEqual(lot.defects_found, 5)


# ═══════════════════════════════════════════════════════════════════
# NCR TESTS
# ═══════════════════════════════════════════════════════════════════

class TestNCR(TestCase):
    def setUp(self):
        self.f = make_base()
        self.scheme = make_scheme(lot_min=1, lot_max=100, n=5, ac=1, re=2)
        self.plan, self.char, self.char2 = make_plan(
            self.f["plant"], self.f["item"], scheme=self.scheme
        )

    def _make_lot(self):
        lot = services.create_inspection_lot(
            plant=self.f["plant"], item=self.f["item"],
            lot_qty=Decimal("20"), uom=self.f["uom"],
            trigger="INCOMING", inspection_plan=self.plan,
        )
        services.record_inspection_result(lot, self.char, "FAIL", defect_count=5)
        services.disposition_lot(lot, "REJECTED")
        return lot

    def test_13_raise_ncr(self):
        """NCR raised with correct number format and status."""
        f = self.f
        lot = self._make_lot()
        ncr = services.raise_ncr(
            plant=f["plant"], item=f["item"], uom=f["uom"],
            quantity_affected=Decimal("5"),
            description="Visual defects on surface",
            severity="MAJOR",
            inspection_lot=lot,
            vendor=f["vendor"],
            defect_lines=[{
                "defect_category": "VISUAL",
                "defect_description": "Scratches on surface",
                "qty_defective": 5,
            }],
            user=f["user"],
        )
        self.assertTrue(ncr.ncr_number.startswith("NCR/"))
        self.assertEqual(ncr.status, "OPEN")
        self.assertEqual(ncr.lines.count(), 1)

    def test_14_ncr_severity_choices(self):
        """NCR can be created with CRITICAL severity."""
        f = self.f
        ncr = services.raise_ncr(
            plant=f["plant"], item=f["item"], uom=f["uom"],
            quantity_affected=Decimal("1"),
            description="Critical failure",
            severity="CRITICAL",
            user=f["user"],
        )
        self.assertEqual(ncr.severity, "CRITICAL")

    def test_15_close_ncr_use_as_is(self):
        """Closing NCR with USE_AS_IS changes status to CLOSED."""
        f = self.f
        ncr = services.raise_ncr(
            plant=f["plant"], item=f["item"], uom=f["uom"],
            quantity_affected=Decimal("2"),
            description="Minor scratch",
            user=f["user"],
        )
        ncr = services.close_ncr(
            ncr=ncr, disposition="USE_AS_IS",
            disposition_remarks="Engineering concession granted",
            root_cause="Supplier handling",
            rework_cost=Decimal("0"),
            user=f["user"],
        )
        self.assertEqual(ncr.status, "CLOSED")
        self.assertEqual(ncr.disposition, "USE_AS_IS")

    def test_16_close_ncr_twice_raises(self):
        """Closing already-closed NCR raises ValueError."""
        f = self.f
        ncr = services.raise_ncr(
            plant=f["plant"], item=f["item"], uom=f["uom"],
            quantity_affected=Decimal("1"), description="Test",
        )
        services.close_ncr(ncr, "SCRAP")
        with self.assertRaises(ValueError):
            services.close_ncr(ncr, "SCRAP")

    def test_17_ncr_str_representation(self):
        """NCR __str__ includes ncr_number and severity."""
        f = self.f
        ncr = services.raise_ncr(
            plant=f["plant"], item=f["item"], uom=f["uom"],
            quantity_affected=Decimal("3"), description="Test",
            severity="MINOR",
        )
        self.assertIn(ncr.ncr_number, str(ncr))
        self.assertIn("MINOR", str(ncr))


# ═══════════════════════════════════════════════════════════════════
# CAPA TESTS
# ═══════════════════════════════════════════════════════════════════

class TestCAPA(TestCase):
    def setUp(self):
        self.f = make_base()

    def _make_ncr(self):
        return services.raise_ncr(
            plant=self.f["plant"], item=self.f["item"], uom=self.f["uom"],
            quantity_affected=Decimal("10"), description="Defect for CAPA",
            severity="MAJOR", user=self.f["user"],
        )

    def test_18_create_capa(self):
        """CAPA created with correct number and status."""
        f = self.f
        ncr = self._make_ncr()
        capa = services.create_capa(
            plant=f["plant"],
            capa_type="CORRECTIVE",
            description="Update supplier quality agreement",
            action_planned="Revise inspection criteria with vendor",
            target_date=date.today() + timedelta(days=30),
            owner=f["user"],
            ncr=ncr,
        )
        self.assertTrue(capa.capa_number.startswith("CAPA/"))
        self.assertEqual(capa.status, "OPEN")
        self.assertEqual(capa.ncr, ncr)

    def test_19_close_capa_valid(self):
        """Closing CAPA updates status, rating, and close date."""
        f = self.f
        ncr = self._make_ncr()
        capa = services.create_capa(
            plant=f["plant"], capa_type="PREVENTIVE",
            description="Preventive measure",
            action_planned="Install poka-yoke",
            target_date=date.today() + timedelta(days=15),
            owner=f["user"], ncr=ncr,
        )
        capa = services.close_capa(
            capa=capa,
            action_taken="Installed jig to prevent dimensional errors",
            effectiveness_rating=4,
            verified_by=f["inspector"],
            verification_remarks="Verified effective after 2 weeks",
            user=f["user"],
        )
        self.assertEqual(capa.status, "CLOSED")
        self.assertEqual(capa.effectiveness_rating, 4)
        self.assertIsNotNone(capa.actual_close_date)

    def test_20_close_capa_invalid_rating(self):
        """Closing CAPA with rating outside 1-5 raises ValueError."""
        f = self.f
        capa = services.create_capa(
            plant=f["plant"], capa_type="CORRECTIVE",
            description="Test", action_planned="Test",
            target_date=date.today() + timedelta(days=7),
        )
        with self.assertRaises(ValueError):
            services.close_capa(capa, "Done", effectiveness_rating=6)

    def test_21_close_capa_twice_raises(self):
        """Closing already-closed CAPA raises ValueError."""
        f = self.f
        capa = services.create_capa(
            plant=f["plant"], capa_type="CORRECTIVE",
            description="Test", action_planned="Test",
            target_date=date.today() + timedelta(days=7),
        )
        services.close_capa(capa, "Done", effectiveness_rating=3)
        with self.assertRaises(ValueError):
            services.close_capa(capa, "Done again", effectiveness_rating=3)

    def test_22_capa_str_representation(self):
        """CAPA __str__ includes capa_number and type."""
        f = self.f
        capa = services.create_capa(
            plant=f["plant"], capa_type="PREVENTIVE",
            description="Test PA", action_planned="PA action",
            target_date=date.today() + timedelta(days=10),
        )
        self.assertIn(capa.capa_number, str(capa))
        self.assertIn("PREVENTIVE", str(capa))


# ═══════════════════════════════════════════════════════════════════
# DASHBOARD & UTILITIES
# ═══════════════════════════════════════════════════════════════════

class TestQualityDashboard(TestCase):
    def setUp(self):
        self.f = make_base()
        self.scheme = make_scheme(lot_min=1, lot_max=100, n=5, ac=1, re=2)
        self.plan, self.char, _ = make_plan(
            self.f["plant"], self.f["item"], scheme=self.scheme
        )

    def test_23_quality_dashboard_returns_all_keys(self):
        """Dashboard returns all expected KPI keys."""
        f = self.f
        result = services.get_quality_dashboard(f["plant"])
        expected_keys = [
            "open_lots", "rejected_lots_this_month",
            "open_ncrs", "critical_ncrs",
            "open_capas", "overdue_capas", "ncr_by_severity",
        ]
        for key in expected_keys:
            self.assertIn(key, result)

    def test_24_open_ncrs_for_vendor(self):
        """get_open_ncrs_for_vendor returns list of open NCR summaries."""
        f = self.f
        services.raise_ncr(
            plant=f["plant"], item=f["item"], uom=f["uom"],
            quantity_affected=Decimal("5"), description="Vendor defect",
            vendor=f["vendor"], severity="MAJOR",
        )
        result = services.get_open_ncrs_for_vendor(f["vendor"])
        self.assertIsInstance(result, list)
        self.assertGreaterEqual(len(result), 1)
        self.assertIn("ncr_number", result[0])
