"""
Test Task 19: In-Process QC — Barcode Scan Wiring
Tests for from-scan endpoint, InspectionLot job_card FK, NCR creation, notification.
"""
import json
from datetime import date
from decimal import Decimal

from django.test import TestCase
from django.contrib.auth import get_user_model
from rest_framework.test import APIClient
from rest_framework import status as http_status

from apps.core.models import Plant, Company, Notification
from apps.masters.models import Item, UOM, ItemGroup
from apps.quality.models import (
    InspectionPlan, InspectionLot, NCR,
)
from apps.production.models import WorkCenter, WorkOrder, JobCard

User = get_user_model()


def _make_base():
    company = Company.objects.create(name="IP Test Co", financial_year_start=4)
    plant = Plant.objects.create(company=company, code="IP1", name="IP Plant")
    user = User.objects.create_user(username="ip_user", email="ip@test.com", password="x")
    hod = User.objects.create_user(
        username="qc_hod", email="hod@test.com", password="x", is_staff=True
    )
    uom = UOM.objects.create(uom_code="IPCS", uom_name="IP Pieces")
    igroup = ItemGroup.objects.create(name="IP Items")
    item = Item.objects.create(
        item_code="IP_FG01", item_name="IP Finished Good",
        item_type="FG", purchase_uom=uom, stock_uom=uom, item_group=igroup,
    )
    wc = WorkCenter.objects.create(
        plant=plant, code="WC01", name="Assembly", capacity_per_day=8, cost_per_hour=100,
    )
    wo = WorkOrder.objects.create(
        plant=plant, wo_number="WO-IP-001",
        finished_good=item, uom=uom,
        planned_qty=Decimal("100"), produced_qty=Decimal("0"), rejected_qty=Decimal("0"),
        planned_start=date.today(), planned_end=date.today(),
        status="IN_PROGRESS",
    )
    jc = JobCard.objects.create(
        work_order=wo, jc_number="JC-IP-001",
        operation_name="Assembly",
        sequence_no=10,
        work_center=wc,
        planned_qty=Decimal("100"),
        completed_qty=Decimal("0"),
        rejected_qty=Decimal("0"),
        status="IN_PROGRESS",
    )
    plan = InspectionPlan.objects.create(
        plant=plant, item=item, trigger="IN_PROCESS",
        plan_name="Assembly IP Plan",
        is_mandatory=True,
        rejection_threshold=Decimal("10"),  # 10% threshold
        effective_from=date.today(),
    )
    return dict(
        company=company, plant=plant, user=user, hod=hod,
        uom=uom, item=item, wc=wc, wo=wo, jc=jc, plan=plan,
    )


class InspectionLotJobCardFKTest(TestCase):
    """Step 1: InspectionLot has job_card FK."""

    def test_job_card_fk_exists(self):
        ctx = _make_base()
        lot = InspectionLot.objects.create(
            plant=ctx["plant"],
            lot_number="IL-TEST-001",
            inspection_plan=ctx["plan"],
            item=ctx["item"],
            lot_qty=Decimal("50"),
            sample_qty=Decimal("50"),
            uom=ctx["uom"],
            status="OPEN",
            inspection_date=date.today(),
            job_card=ctx["jc"],
            work_order=ctx["wo"],
            qty_produced=50,
            qty_rejected=0,
        )
        lot.refresh_from_db()
        self.assertEqual(lot.job_card_id, ctx["jc"].pk)
        self.assertEqual(lot.work_order_id, ctx["wo"].pk)


class FromScanEndpointTest(TestCase):
    """Step 2: POST /api/v1/quality/inspection-lots/from-scan/"""

    def setUp(self):
        self.ctx = _make_base()
        self.client = APIClient()
        self.client.force_authenticate(user=self.ctx["user"])

    def _qr(self, jc):
        """Build a QR string that the endpoint can parse."""
        return str(jc.pk)

    def test_from_scan_creates_inspection_lot(self):
        jc = self.ctx["jc"]
        resp = self.client.post("/api/v1/quality/inspection-lots/from-scan/", {
            "job_card_qr": self._qr(jc),
            "stage": "Assembly",
            "qty_produced": 50,
            "qty_rejected": 0,
            "rejection_reason": "",
        }, format="json")
        self.assertEqual(resp.status_code, http_status.HTTP_201_CREATED)
        data = resp.json()
        self.assertIn("lot_id", data)
        self.assertIn("inspection_lot_number", data)
        self.assertIsNone(data["ncr_id"])

        lot = InspectionLot.objects.get(pk=data["lot_id"])
        self.assertEqual(lot.job_card_id, jc.pk)
        self.assertEqual(lot.work_order_id, self.ctx["wo"].pk)
        self.assertEqual(lot.qty_produced, 50)
        self.assertEqual(lot.qty_rejected, 0)

    def test_from_scan_with_json_qr(self):
        """QR can also be a JSON string with job_card_id key."""
        jc = self.ctx["jc"]
        qr_json = json.dumps({"job_card_id": str(jc.pk), "type": "job_card"})
        resp = self.client.post("/api/v1/quality/inspection-lots/from-scan/", {
            "job_card_qr": qr_json,
            "stage": "Welding",
            "qty_produced": 20,
            "qty_rejected": 0,
        }, format="json")
        self.assertEqual(resp.status_code, http_status.HTTP_201_CREATED)
        data = resp.json()
        lot = InspectionLot.objects.get(pk=data["lot_id"])
        self.assertEqual(lot.job_card_id, jc.pk)

    def test_from_scan_invalid_qr_returns_404(self):
        resp = self.client.post("/api/v1/quality/inspection-lots/from-scan/", {
            "job_card_qr": "nonexistent-uuid-9999",
            "stage": "Test",
            "qty_produced": 10,
            "qty_rejected": 0,
        }, format="json")
        self.assertEqual(resp.status_code, http_status.HTTP_404_NOT_FOUND)


class FromScanNCRCreationTest(TestCase):
    """qty_rejected > 0 automatically raises an NCR."""

    def setUp(self):
        self.ctx = _make_base()
        self.client = APIClient()
        self.client.force_authenticate(user=self.ctx["user"])

    def test_rejection_creates_ncr(self):
        jc = self.ctx["jc"]
        resp = self.client.post("/api/v1/quality/inspection-lots/from-scan/", {
            "job_card_qr": str(jc.pk),
            "stage": "Assembly",
            "qty_produced": 100,
            "qty_rejected": 15,
            "rejection_reason": "Surface defect observed",
        }, format="json")
        self.assertEqual(resp.status_code, http_status.HTTP_201_CREATED)
        data = resp.json()
        self.assertIsNotNone(data["ncr_id"])

        lot = InspectionLot.objects.get(pk=data["lot_id"])
        ncr = NCR.objects.get(pk=data["ncr_id"])
        self.assertEqual(ncr.inspection_lot_id, lot.pk)
        self.assertEqual(ncr.item_id, self.ctx["item"].pk)
        self.assertEqual(ncr.quantity_affected, Decimal("15"))

    def test_no_rejection_no_ncr(self):
        jc = self.ctx["jc"]
        resp = self.client.post("/api/v1/quality/inspection-lots/from-scan/", {
            "job_card_qr": str(jc.pk),
            "stage": "Assembly",
            "qty_produced": 50,
            "qty_rejected": 0,
        }, format="json")
        self.assertEqual(resp.status_code, http_status.HTTP_201_CREATED)
        data = resp.json()
        self.assertIsNone(data["ncr_id"])
        self.assertEqual(NCR.objects.count(), 0)


class FromScanHighRejectionNotificationTest(TestCase):
    """Rejection % > plan.rejection_threshold sends notification to QC HOD."""

    def setUp(self):
        self.ctx = _make_base()
        self.client = APIClient()
        self.client.force_authenticate(user=self.ctx["user"])

    def test_high_rejection_sends_notification(self):
        jc = self.ctx["jc"]
        # 25% rejection > 10% threshold
        resp = self.client.post("/api/v1/quality/inspection-lots/from-scan/", {
            "job_card_qr": str(jc.pk),
            "stage": "Assembly",
            "qty_produced": 100,
            "qty_rejected": 25,
            "rejection_reason": "Major dimensional defects",
        }, format="json")
        self.assertEqual(resp.status_code, http_status.HTTP_201_CREATED)

        # HOD (is_staff=True) should have received a notification
        hod_notifications = Notification.objects.filter(user=self.ctx["hod"])
        self.assertGreater(hod_notifications.count(), 0)
        notif = hod_notifications.first()
        self.assertIn("rejection", notif.message.lower())
        self.assertIn("threshold", notif.message.lower())

    def test_low_rejection_no_notification(self):
        jc = self.ctx["jc"]
        # 5% rejection < 10% threshold
        resp = self.client.post("/api/v1/quality/inspection-lots/from-scan/", {
            "job_card_qr": str(jc.pk),
            "stage": "Assembly",
            "qty_produced": 100,
            "qty_rejected": 5,
            "rejection_reason": "Minor cosmetic",
        }, format="json")
        self.assertEqual(resp.status_code, http_status.HTTP_201_CREATED)
        hod_notifications = Notification.objects.filter(user=self.ctx["hod"])
        self.assertEqual(hod_notifications.count(), 0)


class JobCardScanEndpointTest(TestCase):
    """Step 3: GET /api/v1/production/job-cards/scan/?qr={code}"""

    def setUp(self):
        self.ctx = _make_base()
        self.client = APIClient()
        self.client.force_authenticate(user=self.ctx["user"])

    def test_scan_returns_job_card_detail(self):
        jc = self.ctx["jc"]
        resp = self.client.get(
            "/api/v1/production/job-cards/scan/",
            {"qr": str(jc.pk)},
        )
        self.assertEqual(resp.status_code, http_status.HTTP_200_OK)
        data = resp.json()
        self.assertEqual(data["jc_number"], jc.jc_number)
        self.assertEqual(data["current_stage"], jc.operation_name)
        self.assertIn("work_order", data)
        self.assertEqual(data["work_order"]["wo_number"], self.ctx["wo"].wo_number)

    def test_scan_with_json_qr(self):
        jc = self.ctx["jc"]
        qr_json = json.dumps({"job_card_id": str(jc.pk)})
        resp = self.client.get("/api/v1/production/job-cards/scan/", {"qr": qr_json})
        self.assertEqual(resp.status_code, http_status.HTTP_200_OK)
        self.assertEqual(resp.json()["jc_number"], jc.jc_number)

    def test_scan_invalid_returns_404(self):
        resp = self.client.get("/api/v1/production/job-cards/scan/", {"qr": "invalid-id"})
        self.assertEqual(resp.status_code, http_status.HTTP_404_NOT_FOUND)


class InspectionLotWorkOrderFilterTest(TestCase):
    """Step 5: GET /api/v1/quality/inspection-lots/?work_order={id} filter."""

    def setUp(self):
        self.ctx = _make_base()
        self.client = APIClient()
        self.client.force_authenticate(user=self.ctx["user"])

    def test_work_order_filter(self):
        wo = self.ctx["wo"]
        jc = self.ctx["jc"]
        # Create two lots — one linked to work order, one not
        lot1 = InspectionLot.objects.create(
            plant=self.ctx["plant"],
            lot_number="IL-WO-FILTER-001",
            inspection_plan=self.ctx["plan"],
            item=self.ctx["item"],
            lot_qty=Decimal("10"),
            sample_qty=Decimal("10"),
            uom=self.ctx["uom"],
            status="OPEN",
            inspection_date=date.today(),
            work_order=wo,
            job_card=jc,
        )

        resp = self.client.get(
            "/api/v1/quality/inspection-lots/",
            {"work_order": str(wo.pk)},
        )
        self.assertEqual(resp.status_code, http_status.HTTP_200_OK)
        results = resp.json() if isinstance(resp.json(), list) else resp.json().get("results", [])
        lot_ids = [r["id"] for r in results]
        self.assertIn(str(lot1.pk), lot_ids)
