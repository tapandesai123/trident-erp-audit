"""Quality Control admin registrations."""
from django.contrib import admin
from apps.quality.models import (
    SamplingScheme, InspectionPlan, InspectionPlanCharacteristic,
    InspectionLot, InspectionResult,
    NCR, NCRLine, CAPA,
)


@admin.register(SamplingScheme)
class SamplingSchemeAdmin(admin.ModelAdmin):
    list_display = ["name", "aql_level", "inspection_level", "lot_size_min",
                    "lot_size_max", "sample_size", "accept_number", "reject_number", "is_active"]
    list_filter = ["aql_level", "inspection_level", "is_active"]
    search_fields = ["name"]


class InspectionPlanCharacteristicInline(admin.TabularInline):
    model = InspectionPlanCharacteristic
    extra = 0
    fields = ["seq_no", "characteristic_name", "test_type", "uom",
              "min_value", "max_value", "target_value", "is_critical"]


@admin.register(InspectionPlan)
class InspectionPlanAdmin(admin.ModelAdmin):
    list_display = ["plan_name", "trigger", "plant", "item", "is_mandatory", "is_active", "effective_from"]
    list_filter = ["trigger", "plant", "is_active", "is_mandatory"]
    search_fields = ["plan_name", "item__item_code"]
    inlines = [InspectionPlanCharacteristicInline]
    readonly_fields = ["uuid", "created_at", "updated_at"]


class InspectionResultInline(admin.TabularInline):
    model = InspectionResult
    extra = 0
    fields = ["characteristic", "result", "measured_value", "defect_count", "remarks"]
    readonly_fields = ["inspected_at"]


@admin.register(InspectionLot)
class InspectionLotAdmin(admin.ModelAdmin):
    list_display = ["lot_number", "item", "lot_qty", "sample_qty", "defects_found",
                    "status", "inspection_date", "inspector"]
    list_filter = ["status", "plant", "origin_doc"]
    search_fields = ["lot_number", "item__item_code", "origin_doc_number"]
    readonly_fields = ["uuid", "lot_number", "created_at", "updated_at"]
    inlines = [InspectionResultInline]
    date_hierarchy = "inspection_date"


class NCRLineInline(admin.TabularInline):
    model = NCRLine
    extra = 0
    fields = ["line_no", "defect_category", "defect_description", "qty_defective"]


@admin.register(NCR)
class NCRAdmin(admin.ModelAdmin):
    list_display = ["ncr_number", "severity", "item", "vendor", "ncr_date",
                    "status", "disposition", "block_vendor_po", "rework_cost"]
    list_filter = ["status", "severity", "plant", "block_vendor_po"]
    search_fields = ["ncr_number", "item__item_code", "vendor__vendor_name"]
    readonly_fields = ["uuid", "ncr_number", "raised_by", "closed_by", "closed_date"]
    inlines = [NCRLineInline]
    date_hierarchy = "ncr_date"


@admin.register(CAPA)
class CAPAAdmin(admin.ModelAdmin):
    list_display = ["capa_number", "capa_type", "status", "target_date",
                    "actual_close_date", "owner", "effectiveness_rating"]
    list_filter = ["capa_type", "status", "plant"]
    search_fields = ["capa_number", "description"]
    readonly_fields = ["uuid", "capa_number", "actual_close_date"]
    date_hierarchy = "target_date"
