"""
Quality Control Module Services — Section 9

Services:
  - aql_sampling_size()         — ISO 2859-1 lookup: given lot qty + AQL → sample size, Ac, Re
  - create_inspection_lot()     — Create IL triggered from MRR / WO / JobCard / Despatch
  - record_inspection_result()  — Record characteristic result, auto-detect fail
  - disposition_lot()           — Accept / Reject / Conditional accept
  - raise_ncr()                 — Raise NCR from rejected lot with vendor/stock block
  - close_ncr()                 — Close NCR with disposition, post rework cost to accounts
  - create_capa()               — Create CAPA linked to NCR
  - close_capa()                — Close CAPA with effectiveness rating, notify stakeholders
"""
from decimal import Decimal, ROUND_HALF_UP
from datetime import date, timedelta
from django.db import transaction
from django.db.models import Sum, Q
from django.utils import timezone

from apps.core.models import AuditLog, Notification
from apps.quality.models import (
    SamplingScheme, InspectionPlan, InspectionPlanCharacteristic,
    InspectionLot, InspectionResult,
    NCR, NCRLine, CAPA,
)


# ═══════════════════════════════════════════════════════════════════
# HELPERS
# ═══════════════════════════════════════════════════════════════════

def _log(user, action, resource, resource_id, details=None):
    AuditLog.objects.create(
        user=user, action=action, module="quality",
        resource=resource, resource_id=str(resource_id),
        new_values=details or {},
    )


def _notify(user, title, message, resource=None, resource_id=None):
    if not user:
        return
    Notification.objects.create(
        user=user, title=title, message=message,
        notification_type="IN_APP", module="quality",
        resource=resource or "", resource_id=resource_id,
    )


def _notify_all(users, title, message, resource=None, resource_id=None):
    """Notify a list/queryset of users."""
    for u in users:
        _notify(u, title, message, resource, resource_id)


def _two(val):
    return Decimal(val).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def get_next_doc_number(plant, doc_type: str, prefix: str) -> str:
    """Thread-safe document numbering: PREFIX/YYYY-YY/00001"""
    from django.db import transaction as dbt
    from apps.core.models import DocSequence
    today = date.today()
    fy_start = today.year if today.month >= 4 else today.year - 1
    fy = f"{fy_start}-{str(fy_start + 1)[-2:]}"
    with dbt.atomic():
        seq, _ = DocSequence.objects.select_for_update().get_or_create(
            plant=plant, doc_type=doc_type, financial_year=fy,
            defaults={"prefix": prefix, "last_number": 0,
                      "format_pattern": "{prefix}/{fy}/{num:05d}"},
        )
        seq.last_number += 1
        seq.save(update_fields=["last_number"])
        return seq.format_pattern.format(prefix=prefix, fy=fy, num=seq.last_number)


# ═══════════════════════════════════════════════════════════════════
# AQL SAMPLING
# ═══════════════════════════════════════════════════════════════════

def aql_sampling_size(lot_qty: int, aql_level: str = "1.0",
                      inspection_level: str = "II") -> dict:
    """
    ISO 2859-1 AQL lookup.
    Returns: {sample_size, accept_number, reject_number, scheme_name}
    Falls back to 100% inspection if no matching scheme found.
    """
    scheme = SamplingScheme.objects.filter(
        aql_level=aql_level,
        inspection_level=inspection_level,
        lot_size_min__lte=lot_qty,
        is_active=True,
    ).filter(
        Q(lot_size_max__gte=lot_qty) | Q(lot_size_max__isnull=True)
    ).order_by("lot_size_min").first()

    if scheme:
        return {
            "sample_size": scheme.sample_size,
            "accept_number": scheme.accept_number,
            "reject_number": scheme.reject_number,
            "scheme_name": scheme.name,
            "aql_level": aql_level,
        }
    # Fallback: 100% inspection
    return {
        "sample_size": lot_qty,
        "accept_number": 0,
        "reject_number": 1,
        "scheme_name": "100% Inspection (No scheme found)",
        "aql_level": aql_level,
    }


# ═══════════════════════════════════════════════════════════════════
# INSPECTION LOT
# ═══════════════════════════════════════════════════════════════════

@transaction.atomic
def create_inspection_lot(
    plant,
    item,
    lot_qty: Decimal,
    uom,
    trigger: str,  # "INCOMING", "IN_PROCESS", "FG", "OUTGOING", "PERIODIC"
    origin_doc: str = "MANUAL",
    origin_doc_id: int = None,
    origin_doc_number: str = "",
    vendor=None,
    inspector=None,
    user=None,
    inspection_plan: InspectionPlan = None,
) -> InspectionLot:
    """
    Create an InspectionLot.
    - Auto-selects InspectionPlan by trigger + item/item_group
    - Calculates sample_qty via AQL lookup
    - Status = OPEN
    """
    if inspection_plan is None:
        # Find plan: item-specific first, then item-group
        inspection_plan = (
            InspectionPlan.objects.filter(
                plant=plant, trigger=trigger, item=item, is_active=True
            ).order_by("-effective_from").first()
            or InspectionPlan.objects.filter(
                plant=plant, trigger=trigger,
                item__isnull=True,
                item_group=item.item_group if hasattr(item, "item_group") else None,
                is_active=True,
            ).order_by("-effective_from").first()
        )

    if inspection_plan is None:
        raise ValueError(
            f"No active InspectionPlan found for item {item.item_code} trigger={trigger}."
        )

    # AQL sample size
    aql_info = {"sample_size": lot_qty}
    if inspection_plan.sampling_scheme:
        s = inspection_plan.sampling_scheme
        aql_info = aql_sampling_size(int(lot_qty), s.aql_level, s.inspection_level)

    lot_number = get_next_doc_number(plant, "IL", "IL")

    lot = InspectionLot.objects.create(
        plant=plant,
        lot_number=lot_number,
        inspection_plan=inspection_plan,
        item=item,
        vendor=vendor,
        origin_doc=origin_doc,
        origin_doc_id=origin_doc_id,
        origin_doc_number=origin_doc_number,
        lot_qty=lot_qty,
        sample_qty=Decimal(str(aql_info["sample_size"])),
        uom=uom,
        status="OPEN",
        inspection_date=date.today(),
        due_date=date.today() + timedelta(days=2),
        inspector=inspector,
    )

    _log(user, "CREATE", "InspectionLot", lot.pk, {
        "lot_number": lot_number, "lot_qty": str(lot_qty),
        "sample_qty": str(lot.sample_qty),
    })
    if inspector:
        _notify(inspector, f"Inspection Lot {lot_number} Assigned",
                f"You have a new inspection lot for {item.item_code} × {lot_qty}.",
                resource="InspectionLot", resource_id=lot.pk)
    return lot


@transaction.atomic
def record_inspection_result(
    lot: InspectionLot,
    characteristic: InspectionPlanCharacteristic,
    result: str,  # PASS / FAIL / CONDITIONAL
    measured_value: Decimal = None,
    defect_count: int = 0,
    remarks: str = "",
    user=None,
) -> InspectionResult:
    """
    Record a single characteristic result for an inspection lot.
    - Creates or updates InspectionResult
    - Updates lot.defects_found
    - Changes lot status to IN_PROGRESS
    """
    if lot.status not in ("OPEN", "IN_PROGRESS"):
        raise ValueError(f"Cannot record results for lot in status '{lot.status}'.")

    ir, created = InspectionResult.objects.update_or_create(
        lot=lot,
        characteristic=characteristic,
        defaults={
            "measured_value": measured_value,
            "result": result,
            "defect_count": defect_count,
            "remarks": remarks,
            "inspected_by": user,
        },
    )

    # Update lot defects_found
    total_defects = lot.results.aggregate(total=Sum("defect_count"))["total"] or 0
    lot.defects_found = total_defects
    if lot.status == "OPEN":
        lot.status = "IN_PROGRESS"
    lot.save(update_fields=["defects_found", "status", "updated_at"])

    _log(user, "UPDATE", "InspectionResult", ir.pk, {
        "lot": lot.lot_number,
        "characteristic": characteristic.characteristic_name,
        "result": result,
    })
    return ir


@transaction.atomic
def disposition_lot(
    lot: InspectionLot,
    disposition: str,  # "ACCEPTED" / "REJECTED" / "CONDITIONALLY_ACCEPTED"
    remarks: str = "",
    user=None,
) -> InspectionLot:
    """
    Finalize disposition of an Inspection Lot.
    - Status → ACCEPTED / REJECTED / CONDITIONALLY_ACCEPTED
    - If REJECTED and origin_doc=MRR → quarantine inventory lot
    - If REJECTED → auto-raise NCR
    """
    if lot.status not in ("IN_PROGRESS", "COMPLETED"):
        raise ValueError(f"Cannot disposition lot in status '{lot.status}'.")

    lot.status = disposition
    lot.completed_date = date.today()
    lot.disposition_by = user
    lot.disposition_remarks = remarks
    lot.save(update_fields=["status", "completed_date", "disposition_by",
                             "disposition_remarks", "updated_at"])

    # Quarantine inventory if rejected from incoming inspection
    if disposition == "REJECTED" and lot.origin_doc == "MRR":
        _quarantine_inventory_lot(lot)

    _log(user, "APPROVE", "InspectionLot", lot.pk, {"disposition": disposition})
    if user:
        _notify(user, f"Lot {lot.lot_number} {disposition}",
                f"Inspection lot for {lot.item.item_code} dispositioned: {disposition}.",
                resource="InspectionLot", resource_id=lot.pk)
    return lot


def _quarantine_inventory_lot(lot: InspectionLot):
    """Move stores InventoryLots to QUARANTINE status."""
    try:
        from apps.stores.models import InventoryLot as StoresLot
        StoresLot.objects.filter(
            item=lot.item,
            plant=lot.plant,
        ).filter(
            # Match by MRR reference if available
            **{"receipt_id": lot.origin_doc_id} if lot.origin_doc_id else {}
        ).update(status="QUARANTINE", qc_status="REJECTED")
    except Exception:
        pass


# ═══════════════════════════════════════════════════════════════════
# NCR
# ═══════════════════════════════════════════════════════════════════

@transaction.atomic
def raise_ncr(
    plant,
    item,
    uom,
    quantity_affected: Decimal,
    description: str,
    severity: str = "MAJOR",
    inspection_lot: InspectionLot = None,
    vendor=None,
    defect_lines: list = None,  # [{defect_category, defect_description, qty_defective}]
    block_vendor_po: bool = False,
    quarantine_stock: bool = True,
    user=None,
) -> NCR:
    """
    Raise a Non-Conformance Report.
    - Creates NCR with lines
    - Optionally blocks vendor from new POs
    - Optionally marks stock as quarantine
    """
    ncr_number = get_next_doc_number(plant, "NCR", "NCR")

    ncr = NCR.objects.create(
        plant=plant,
        ncr_number=ncr_number,
        inspection_lot=inspection_lot,
        item=item,
        vendor=vendor,
        ncr_date=date.today(),
        severity=severity,
        status="OPEN",
        description=description,
        quantity_affected=quantity_affected,
        uom=uom,
        block_vendor_po=block_vendor_po,
        quarantine_stock=quarantine_stock,
        raised_by=user,
    )

    # Create defect lines
    for i, line_data in enumerate(defect_lines or [], start=1):
        NCRLine.objects.create(
            ncr=ncr,
            line_no=i,
            defect_category=line_data.get("defect_category", "OTHER"),
            defect_description=line_data.get("defect_description", ""),
            qty_defective=Decimal(str(line_data.get("qty_defective", quantity_affected))),
            characteristic_id=line_data.get("characteristic_id"),
        )

    # Block vendor if flagged
    if block_vendor_po and vendor:
        _block_vendor(vendor, ncr)

    # Quarantine stock
    if quarantine_stock and inspection_lot:
        _quarantine_inventory_lot(inspection_lot)

    _log(user, "CREATE", "NCR", ncr.pk, {
        "ncr_number": ncr_number, "severity": severity,
        "item": item.item_code, "qty": str(quantity_affected),
    })
    if user:
        _notify(user, f"NCR {ncr_number} Raised",
                f"NCR for {item.item_code} — {severity}. Qty: {quantity_affected}.",
                resource="NCR", resource_id=ncr.pk)
    return ncr


def _block_vendor(vendor, ncr: NCR):
    """Flag vendor as blocked due to NCR (stores flag on Vendor model if field exists)."""
    try:
        if hasattr(vendor, "is_blocked"):
            vendor.is_blocked = True
            vendor.save(update_fields=["is_blocked"])
    except Exception:
        pass


@transaction.atomic
def close_ncr(
    ncr: NCR,
    disposition: str,
    disposition_remarks: str = "",
    root_cause: str = "",
    rework_cost: Decimal = Decimal("0"),
    user=None,
) -> NCR:
    """
    Close an NCR with disposition decision.
    - Posts rework cost as accounts journal voucher if rework_cost > 0
    - Unblocks vendor if disposition is not SCRAP/RETURN
    - Status → CLOSED
    """
    if ncr.status in ("CLOSED", "CANCELLED"):
        raise ValueError(f"NCR {ncr.ncr_number} is already {ncr.status}.")

    ncr.disposition = disposition
    ncr.disposition_remarks = disposition_remarks
    ncr.root_cause = root_cause
    ncr.rework_cost = _two(rework_cost)
    ncr.status = "CLOSED"
    ncr.closed_by = user
    ncr.closed_date = date.today()
    ncr.save(update_fields=[
        "disposition", "disposition_remarks", "root_cause", "rework_cost",
        "status", "closed_by", "closed_date", "updated_at",
    ])

    # Post rework cost to accounts if > 0
    if rework_cost > Decimal("0"):
        _post_rework_cost_voucher(ncr, rework_cost, user)

    # Unblock vendor if appropriate
    if disposition in ("USE_AS_IS", "REWORK", "CONCESSION") and ncr.vendor and ncr.block_vendor_po:
        try:
            if hasattr(ncr.vendor, "is_blocked"):
                ncr.vendor.is_blocked = False
                ncr.vendor.save(update_fields=["is_blocked"])
        except Exception:
            pass

    _log(user, "UPDATE", "NCR", ncr.pk, {
        "status": "CLOSED", "disposition": disposition, "rework_cost": str(rework_cost),
    })
    if user:
        _notify(user, f"NCR {ncr.ncr_number} Closed",
                f"Disposition: {disposition}. Rework cost: ₹{rework_cost:,.2f}",
                resource="NCR", resource_id=ncr.pk)
    return ncr


def _post_rework_cost_voucher(ncr: NCR, rework_cost: Decimal, user=None):
    """Post rework cost as a journal entry to accounts."""
    try:
        from apps.accounts.services import get_next_doc_number as acc_num
        from apps.accounts.models import Voucher, VoucherLine
        voucher = Voucher.objects.create(
            plant=ncr.plant,
            voucher_number=acc_num(ncr.plant, "JV", "JV"),
            voucher_type="JOURNAL",
            voucher_date=date.today(),
            narration=f"Rework cost for NCR {ncr.ncr_number} — {ncr.item.item_code}",
            created_by=user,
            status="DRAFT",
        )
        VoucherLine.objects.create(
            voucher=voucher, line_no=1,
            narration=f"NCR {ncr.ncr_number} rework cost",
            debit_amount=rework_cost,
            credit_amount=Decimal("0"),
        )
        from apps.accounts.services import post_voucher
        post_voucher(voucher, user=user)
    except Exception:
        pass  # Accounts integration — graceful fail in isolation


# ═══════════════════════════════════════════════════════════════════
# CAPA
# ═══════════════════════════════════════════════════════════════════

@transaction.atomic
def create_capa(
    plant,
    capa_type: str,  # "CORRECTIVE" / "PREVENTIVE"
    description: str,
    action_planned: str,
    target_date: date,
    owner=None,
    ncr: NCR = None,
    user=None,
) -> CAPA:
    """Create a CAPA record linked to an NCR."""
    capa_number = get_next_doc_number(plant, "CAPA", "CAPA")

    capa = CAPA.objects.create(
        plant=plant,
        capa_number=capa_number,
        ncr=ncr,
        capa_type=capa_type,
        status="OPEN",
        description=description,
        action_planned=action_planned,
        target_date=target_date,
        owner=owner,
    )

    _log(user, "CREATE", "CAPA", capa.pk, {
        "capa_number": capa_number, "capa_type": capa_type,
        "ncr": ncr.ncr_number if ncr else None,
    })
    if owner:
        _notify(owner, f"CAPA {capa_number} Assigned to You",
                f"New {capa_type} action: {description[:100]}. Due: {target_date}.",
                resource="CAPA", resource_id=capa.pk)
    return capa


@transaction.atomic
def close_capa(
    capa: CAPA,
    action_taken: str,
    effectiveness_rating: int,  # 1–5
    verified_by=None,
    verification_remarks: str = "",
    user=None,
) -> CAPA:
    """
    Close a CAPA after verification.
    - Status → CLOSED
    - Notifies all stakeholders: owner, verifier, NCR raised_by
    """
    if capa.status in ("CLOSED", "CANCELLED"):
        raise ValueError(f"CAPA {capa.capa_number} is already {capa.status}.")

    if not 1 <= effectiveness_rating <= 5:
        raise ValueError("effectiveness_rating must be between 1 and 5.")

    capa.action_taken = action_taken
    capa.effectiveness_rating = effectiveness_rating
    capa.verified_by = verified_by
    capa.verification_remarks = verification_remarks
    capa.status = "CLOSED"
    capa.actual_close_date = date.today()
    capa.save(update_fields=[
        "action_taken", "effectiveness_rating", "verified_by",
        "verification_remarks", "status", "actual_close_date", "updated_at",
    ])

    # Notify stakeholders
    stakeholders = set()
    if capa.owner:
        stakeholders.add(capa.owner)
    if verified_by:
        stakeholders.add(verified_by)
    if capa.ncr and capa.ncr.raised_by:
        stakeholders.add(capa.ncr.raised_by)

    for stakeholder in stakeholders:
        _notify(
            stakeholder,
            f"CAPA {capa.capa_number} Closed",
            f"{capa.capa_type} action closed. Effectiveness: {effectiveness_rating}/5. "
            f"Verified by: {verified_by.get_full_name() if verified_by else 'N/A'}.",
            resource="CAPA",
            resource_id=capa.pk,
        )

    _log(user, "UPDATE", "CAPA", capa.pk, {
        "status": "CLOSED", "effectiveness_rating": effectiveness_rating,
    })
    return capa


# ═══════════════════════════════════════════════════════════════════
# UTILITY QUERIES
# ═══════════════════════════════════════════════════════════════════

def get_open_ncrs_for_vendor(vendor) -> list:
    """Return summary of open NCRs for a vendor (used in PO block check)."""
    ncrs = NCR.objects.filter(vendor=vendor, status__in=("OPEN", "UNDER_REVIEW", "DISPOSITION"))
    return list(ncrs.values("ncr_number", "severity", "ncr_date", "item__item_code"))


def get_quality_dashboard(plant) -> dict:
    """Summary stats for quality dashboard."""
    from django.db.models import Count
    return {
        "open_lots": InspectionLot.objects.filter(plant=plant, status__in=("OPEN", "IN_PROGRESS")).count(),
        "rejected_lots_this_month": InspectionLot.objects.filter(
            plant=plant, status="REJECTED",
            completed_date__month=date.today().month,
            completed_date__year=date.today().year,
        ).count(),
        "open_ncrs": NCR.objects.filter(plant=plant, status__in=("OPEN", "UNDER_REVIEW")).count(),
        "critical_ncrs": NCR.objects.filter(plant=plant, status="OPEN", severity="CRITICAL").count(),
        "open_capas": CAPA.objects.filter(plant=plant, status__in=("OPEN", "IN_PROGRESS")).count(),
        "overdue_capas": CAPA.objects.filter(
            plant=plant, status__in=("OPEN", "IN_PROGRESS"),
            target_date__lt=date.today(),
        ).count(),
        "ncr_by_severity": dict(
            NCR.objects.filter(plant=plant, status="OPEN")
            .values("severity")
            .annotate(count=Count("id"))
            .values_list("severity", "count")
        ),
    }
