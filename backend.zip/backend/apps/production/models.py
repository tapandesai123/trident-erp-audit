"""
Production & WIP Module Models — Section 8
Models: ProductionBOMHeader, ProductionBOMLine, WorkOrder, JobCard,
        WOMaterialIssue, WOMaterialIssueLine, WorkCenter,
        MachineLoadingPlan, MRPRun, MRPSuggestion
"""
import uuid
from decimal import Decimal
from django.db import models
from django.conf import settings
from apps.core.models import UUIDModel, TimeStampedModel, Plant
from apps.masters.models import Item, UOM


# ═══════════════════════════════════════════════════════════════════
# BOM (Production copy — tracks revisions per plant)
# ═══════════════════════════════════════════════════════════════════

class ProductionBOMHeader(UUIDModel, TimeStampedModel):
    STATUS_CHOICES = [
        ("DRAFT", "Draft"),
        ("ACTIVE", "Active"),
        ("OBSOLETE", "Obsolete"),
    ]

    plant = models.ForeignKey(Plant, on_delete=models.PROTECT, related_name="prod_boms")
    finished_good = models.ForeignKey(
        Item, on_delete=models.PROTECT, related_name="prod_boms",
    )
    bom_number = models.CharField(max_length=50)
    revision = models.CharField(max_length=10, default="A")
    base_qty = models.DecimalField(max_digits=14, decimal_places=4, default=1)
    base_uom = models.ForeignKey(UOM, on_delete=models.PROTECT, related_name="prod_bom_headers")
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="DRAFT")
    effective_from = models.DateField()
    effective_to = models.DateField(null=True, blank=True)
    routing_notes = models.TextField(blank=True)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True,
        related_name="prod_boms_created",
    )

    class Meta:
        unique_together = [["plant", "finished_good", "revision"]]
        ordering = ["bom_number", "-revision"]

    def __str__(self):
        return f"{self.bom_number} Rev:{self.revision} — {self.finished_good.item_code}"


class ProductionBOMLine(UUIDModel, TimeStampedModel):
    COMPONENT_TYPE = [
        ("RAW", "Raw Material"),
        ("SFG", "Semi-Finished Good"),
        ("CONSUMABLE", "Consumable"),
        ("PACKING", "Packing Material"),
    ]

    bom = models.ForeignKey(ProductionBOMHeader, on_delete=models.CASCADE, related_name="lines")
    line_no = models.PositiveSmallIntegerField()
    component = models.ForeignKey(Item, on_delete=models.PROTECT, related_name="prod_bom_lines")
    component_type = models.CharField(max_length=20, choices=COMPONENT_TYPE, default="RAW")
    qty_per_base = models.DecimalField(max_digits=14, decimal_places=6)
    uom = models.ForeignKey(UOM, on_delete=models.PROTECT)
    scrap_pct = models.DecimalField(max_digits=6, decimal_places=2, default=0)
    is_critical = models.BooleanField(default=False)
    notes = models.CharField(max_length=300, blank=True)

    class Meta:
        unique_together = [["bom", "line_no"]]
        ordering = ["line_no"]

    def __str__(self):
        return f"{self.bom.bom_number}/{self.line_no} {self.component.item_code}"

    @property
    def effective_qty(self):
        """qty_per_base adjusted for scrap %."""
        return self.qty_per_base * (1 + self.scrap_pct / Decimal("100"))


# ═══════════════════════════════════════════════════════════════════
# WORK CENTER
# ═══════════════════════════════════════════════════════════════════

class WorkCenter(UUIDModel, TimeStampedModel):
    plant = models.ForeignKey(Plant, on_delete=models.PROTECT, related_name="work_centers")
    code = models.CharField(max_length=20)
    name = models.CharField(max_length=100)
    capacity_per_day = models.DecimalField(
        max_digits=10, decimal_places=2, default=8,
        help_text="Hours available per day",
    )
    cost_per_hour = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    min_deckle_mm   = models.DecimalField(
        max_digits=10, decimal_places=2, null=True, blank=True,
        help_text="Minimum paper/box width this machine can handle (mm)",
    )
    max_deckle_mm   = models.DecimalField(
        max_digits=10, decimal_places=2, null=True, blank=True,
        help_text="Maximum paper/box width this machine can handle (mm)",
    )
    machine_type    = models.CharField(
        max_length=30, blank=True,
        choices=[
            ("CORRUGATOR",  "Corrugator"),
            ("SLITTER",     "Slitter / Sheeter"),
            ("PRINTING",    "Printing Machine"),
            ("DIE_CUTTING", "Die Cutting"),
            ("FOLDING",     "Folding / Gluing"),
            ("PACKING",     "Packing Line"),
            ("GENERAL",     "General Purpose"),
        ],
        help_text="Type of operation this machine performs",
    )
    is_active = models.BooleanField(default=True)

    class Meta:
        unique_together = [["plant", "code"]]
        ordering = ["code"]

    def __str__(self):
        return f"{self.code} — {self.name}"

    def clean(self):
        from django.core.exceptions import ValidationError
        if (self.min_deckle_mm is not None and self.max_deckle_mm is not None
                and self.min_deckle_mm > self.max_deckle_mm):
            raise ValidationError(
                {'min_deckle_mm': 'min_deckle_mm must be <= max_deckle_mm'}
            )


# ═══════════════════════════════════════════════════════════════════
# WORK ORDER
# ═══════════════════════════════════════════════════════════════════

class WorkOrder(UUIDModel, TimeStampedModel):
    STATUS_CHOICES = [
        ("DRAFT", "Draft"),
        ("RELEASED", "Released"),
        ("IN_PROGRESS", "In Progress"),
        ("COMPLETED", "Completed"),
        ("CLOSED", "Closed"),
        ("CANCELLED", "Cancelled"),
    ]

    plant = models.ForeignKey(Plant, on_delete=models.PROTECT, related_name="work_orders")
    wo_number = models.CharField(max_length=30, unique=True)
    finished_good = models.ForeignKey(Item, on_delete=models.PROTECT, related_name="work_orders")
    bom = models.ForeignKey(
        ProductionBOMHeader, on_delete=models.PROTECT,
        related_name="work_orders", null=True, blank=True,
    )
    planned_qty = models.DecimalField(max_digits=14, decimal_places=4)
    produced_qty = models.DecimalField(max_digits=14, decimal_places=4, default=0)
    rejected_qty = models.DecimalField(max_digits=14, decimal_places=4, default=0)
    uom = models.ForeignKey(UOM, on_delete=models.PROTECT)
    planned_start = models.DateField()
    planned_end = models.DateField()
    actual_start = models.DateField(null=True, blank=True)
    actual_end = models.DateField(null=True, blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="DRAFT")

    # Source traceability — lazy FK to avoid circular import
    sales_order_line_id = models.IntegerField(null=True, blank=True, db_index=True)
    mrp_suggestion = models.ForeignKey(
        "production.MRPSuggestion", on_delete=models.SET_NULL, null=True, blank=True,
        related_name="work_orders",
    )

    # Cost tracking
    std_material_cost = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    std_labour_cost = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    std_overhead_cost = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    actual_material_cost = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    actual_labour_cost = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    actual_overhead_cost = models.DecimalField(max_digits=14, decimal_places=2, default=0)

    priority = models.PositiveSmallIntegerField(default=5, help_text="1=Highest, 10=Lowest")
    suggested_work_centers = models.JSONField(
        default=list, blank=True,
        help_text="Auto-suggested work centres based on box dimensions",
    )
    notes = models.TextField(blank=True)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True,
        related_name="work_orders_created",
    )

    class Meta:
        ordering = ["-created_at"]
        indexes = [
            models.Index(fields=["plant", "status"]),
            models.Index(fields=["planned_start", "planned_end"]),
        ]

    def __str__(self):
        return f"{self.wo_number} — {self.finished_good.item_code} × {self.planned_qty}"

    @property
    def material_variance(self):
        return self.actual_material_cost - self.std_material_cost

    @property
    def total_variance(self):
        return (
            (self.actual_material_cost - self.std_material_cost)
            + (self.actual_labour_cost - self.std_labour_cost)
            + (self.actual_overhead_cost - self.std_overhead_cost)
        )


# ═══════════════════════════════════════════════════════════════════
# JOB CARD
# ═══════════════════════════════════════════════════════════════════

class JobCard(UUIDModel, TimeStampedModel):
    STATUS_CHOICES = [
        ("OPEN", "Open"),
        ("IN_PROGRESS", "In Progress"),
        ("COMPLETED", "Completed"),
        ("ON_HOLD", "On Hold"),
    ]

    work_order = models.ForeignKey(WorkOrder, on_delete=models.CASCADE, related_name="job_cards")
    jc_number = models.CharField(max_length=30, unique=True)
    operation_name = models.CharField(max_length=100)
    sequence_no = models.PositiveSmallIntegerField(default=10)
    work_center = models.ForeignKey(WorkCenter, on_delete=models.PROTECT, related_name="job_cards")
    assigned_to = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="job_cards_assigned",
    )
    planned_hours = models.DecimalField(max_digits=8, decimal_places=2, default=0)
    actual_hours = models.DecimalField(max_digits=8, decimal_places=2, default=0)
    planned_qty = models.DecimalField(max_digits=14, decimal_places=4)
    completed_qty = models.DecimalField(max_digits=14, decimal_places=4, default=0)
    rejected_qty = models.DecimalField(max_digits=14, decimal_places=4, default=0)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="OPEN")
    started_at = models.DateTimeField(null=True, blank=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    remarks = models.TextField(blank=True)

    # Delay tracking (F4)
    is_delayed = models.BooleanField(default=False, help_text="True if actual_hours > planned_hours * 1.2")
    delay_notified = models.BooleanField(default=False, help_text="True if delay notification has been sent")

    class Meta:
        ordering = ["work_order", "sequence_no"]
        indexes = [models.Index(fields=["work_order", "status"])]

    def __str__(self):
        return f"{self.jc_number} — {self.operation_name}"


# ═══════════════════════════════════════════════════════════════════
# MATERIAL ISSUE TO PRODUCTION
# ═══════════════════════════════════════════════════════════════════

class WOMaterialIssue(UUIDModel, TimeStampedModel):
    STATUS_CHOICES = [
        ("DRAFT", "Draft"),
        ("ISSUED", "Issued"),
        ("CANCELLED", "Cancelled"),
    ]

    work_order = models.ForeignKey(WorkOrder, on_delete=models.PROTECT, related_name="material_issues")
    issue_number = models.CharField(max_length=30, unique=True)
    issue_date = models.DateField()
    store_location = models.ForeignKey(
        "stores.Warehouse", on_delete=models.PROTECT, null=True, blank=True,
        related_name="wo_issues",
    )
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="DRAFT")
    issued_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True,
        related_name="wo_issues_created",
    )
    notes = models.TextField(blank=True)

    class Meta:
        ordering = ["-issue_date", "-created_at"]

    def __str__(self):
        return f"{self.issue_number} → WO:{self.work_order.wo_number}"


class WOMaterialIssueLine(UUIDModel, TimeStampedModel):
    issue = models.ForeignKey(WOMaterialIssue, on_delete=models.CASCADE, related_name="lines")
    line_no = models.PositiveSmallIntegerField()
    bom_line = models.ForeignKey(
        ProductionBOMLine, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="issue_lines",
    )
    item = models.ForeignKey(Item, on_delete=models.PROTECT, related_name="wo_issue_lines")
    planned_qty = models.DecimalField(max_digits=14, decimal_places=4)
    issued_qty = models.DecimalField(max_digits=14, decimal_places=4)
    uom = models.ForeignKey(UOM, on_delete=models.PROTECT)
    stock_ledger_entry_id = models.IntegerField(null=True, blank=True, db_index=True)
    unit_cost = models.DecimalField(max_digits=14, decimal_places=4, default=0)

    class Meta:
        unique_together = [["issue", "line_no"]]
        ordering = ["line_no"]

    def __str__(self):
        return f"{self.issue.issue_number}/{self.line_no} {self.item.item_code}"

    @property
    def line_cost(self):
        return self.issued_qty * self.unit_cost


# ═══════════════════════════════════════════════════════════════════
# MACHINE LOADING PLAN
# ═══════════════════════════════════════════════════════════════════

class MachineLoadingPlan(UUIDModel, TimeStampedModel):
    SHIFT_CHOICES = [('A', 'Shift A'), ('B', 'Shift B'), ('C', 'Shift C'), ('G', 'General')]

    plant = models.ForeignKey(Plant, on_delete=models.PROTECT, related_name="loading_plans")
    work_center = models.ForeignKey(WorkCenter, on_delete=models.PROTECT, related_name="loading_plans")
    job_card = models.ForeignKey(JobCard, on_delete=models.CASCADE, related_name="loading_plans")
    scheduled_date = models.DateField()
    start_time = models.TimeField()
    end_time = models.TimeField()
    planned_hours = models.DecimalField(max_digits=6, decimal_places=2)
    shift = models.CharField(max_length=5, choices=SHIFT_CHOICES, default='A')
    is_confirmed = models.BooleanField(default=False)
    notes = models.TextField(blank=True)

    class Meta:
        unique_together = [['work_center', 'scheduled_date', 'shift']]
        ordering = ["scheduled_date", "start_time"]
        indexes = [models.Index(fields=["work_center", "scheduled_date", "shift"])]

    def __str__(self):
        return f"{self.work_center.code} {self.scheduled_date} {self.start_time}–{self.end_time}"


# ═══════════════════════════════════════════════════════════════════
# MRP
# ═══════════════════════════════════════════════════════════════════

class MRPRun(UUIDModel, TimeStampedModel):
    STATUS_CHOICES = [
        ("RUNNING", "Running"),
        ("COMPLETED", "Completed"),
        ("FAILED", "Failed"),
    ]

    plant = models.ForeignKey(Plant, on_delete=models.PROTECT, related_name="mrp_runs")
    run_number = models.CharField(max_length=30, unique=True)
    run_date = models.DateField()
    horizon_days = models.PositiveSmallIntegerField(default=30)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="RUNNING")
    initiated_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True,
        related_name="mrp_runs",
    )
    completed_at = models.DateTimeField(null=True, blank=True)
    error_message = models.TextField(blank=True)
    summary = models.JSONField(default=dict, blank=True)

    class Meta:
        ordering = ["-run_date", "-created_at"]

    def __str__(self):
        return f"{self.run_number} — {self.run_date}"


class MRPSuggestion(UUIDModel, TimeStampedModel):
    SUGGESTION_TYPE = [
        ("PRODUCE", "Produce (New WO)"),
        ("PURCHASE", "Purchase (New PR)"),
        ("RESCHEDULE", "Reschedule Existing"),
        ("CANCEL", "Cancel Excess"),
    ]
    STATUS_CHOICES = [
        ("OPEN", "Open"),
        ("ACCEPTED", "Accepted"),
        ("REJECTED", "Rejected"),
        ("CONVERTED", "Converted"),
    ]

    mrp_run = models.ForeignKey(MRPRun, on_delete=models.CASCADE, related_name="suggestions")
    item = models.ForeignKey(Item, on_delete=models.PROTECT, related_name="mrp_suggestions")
    suggestion_type = models.CharField(max_length=20, choices=SUGGESTION_TYPE)
    required_qty = models.DecimalField(max_digits=14, decimal_places=4)
    available_qty = models.DecimalField(max_digits=14, decimal_places=4, default=0)
    shortage_qty = models.DecimalField(max_digits=14, decimal_places=4)
    uom = models.ForeignKey(UOM, on_delete=models.PROTECT)
    required_by = models.DateField()
    suggested_qty = models.DecimalField(max_digits=14, decimal_places=4)
    source_demand = models.JSONField(default=list)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="OPEN")
    remarks = models.TextField(blank=True)

    class Meta:
        ordering = ["required_by", "item__code"]
        indexes = [models.Index(fields=["mrp_run", "status", "suggestion_type"])]

    def __str__(self):
        return (
            f"{self.mrp_run.run_number} | {self.item.item_code} "
            f"| {self.suggestion_type} × {self.suggested_qty}"
        )


# ═══════════════════════════════════════════════════════════════════
# PRODUCTION DOWNTIME TRACKING
# ═══════════════════════════════════════════════════════════════════

class ProductionDowntime(UUIDModel, TimeStampedModel):
    """Machine downtime recorded per shift for PPC reporting."""
    class DowntimeCategory(models.TextChoices):
        BREAKDOWN     = "BREAKDOWN",     "Machine Breakdown"
        PLANNED_MAINT = "PLANNED_MAINT", "Planned Maintenance"
        POWER_CUT     = "POWER_CUT",     "Power Failure"
        NO_MATERIAL   = "NO_MATERIAL",   "No Raw Material"
        NO_OPERATOR   = "NO_OPERATOR",   "No Operator"
        CHANGEOVER    = "CHANGEOVER",    "Product Changeover"
        QC_HOLD       = "QC_HOLD",       "QC Hold"
        OTHER         = "OTHER",         "Other"

    plant            = models.ForeignKey("core.Plant", on_delete=models.CASCADE, related_name="downtimes")
    work_center      = models.ForeignKey(WorkCenter, on_delete=models.CASCADE, related_name="downtimes")
    work_order       = models.ForeignKey(WorkOrder, on_delete=models.SET_NULL, null=True, blank=True,
                                          related_name="downtimes")
    job_card         = models.ForeignKey(JobCard, on_delete=models.SET_NULL, null=True, blank=True,
                                          related_name="downtimes")
    shift            = models.CharField(max_length=20,
                                         choices=[("A","A"),("B","B"),("C","C"),("G","General")])
    downtime_start   = models.DateTimeField()
    downtime_end     = models.DateTimeField(null=True, blank=True)
    category         = models.CharField(max_length=30, choices=DowntimeCategory.choices)
    reason_detail    = models.TextField()
    responsible_dept = models.CharField(max_length=100, blank=True,
                                         help_text="Man / Machine / Material / Method")
    capa_required    = models.BooleanField(default=False)
    capa             = models.ForeignKey("quality.CAPA", on_delete=models.SET_NULL,
                                          null=True, blank=True, related_name="downtime_triggers")
    recorded_by      = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True)

    class Meta:
        ordering = ["-downtime_start"]
        verbose_name = "Production Downtime"
        verbose_name_plural = "Production Downtimes"

    def __str__(self):
        return f"{self.work_center} – {self.category} @ {self.downtime_start:%Y-%m-%d %H:%M}"

    @property
    def duration_minutes(self):
        if self.downtime_start and self.downtime_end:
            return int((self.downtime_end - self.downtime_start).total_seconds() / 60)
        return None
