"""
Production Module Tests — Section 8
Minimum 20 test cases covering:
  - BOM creation & explosion
  - Work Order lifecycle
  - Job Card completion
  - Material Issue
  - MRP run
  - Machine Loading
  - API endpoints
"""
from decimal import Decimal
from datetime import date, timedelta
from django.test import TestCase
from django.contrib.auth import get_user_model
from unittest.mock import patch, MagicMock

from apps.core.models import Plant, Company
from apps.masters.models import Item, UOM
from apps.production.models import (
    ProductionBOMHeader, ProductionBOMLine,
    WorkCenter, WorkOrder, JobCard,
    WOMaterialIssue, WOMaterialIssueLine,
    MachineLoadingPlan, MRPRun, MRPSuggestion,
)
from apps.production import services

User = get_user_model()


def make_fixtures():
    """Create minimal test fixtures."""
    company = Company.objects.create(name="Trident Test Co", financial_year_start=4)
    plant = Plant.objects.create(company=company, code="P01", name="Plant 1")
    user = User.objects.create_user(username="testprod", email="prod@test.com", password="x")
    uom = UOM.objects.create(uom_code="PCS", uom_name="Pieces")
    uom_kg = UOM.objects.create(uom_code="KG", uom_name="Kilograms")
    fg = Item.objects.create(
        item_code="FG001", item_name="Finished Product A",
        item_type="FG", purchase_uom=uom, stock_uom=uom,
    )
    rm1 = Item.objects.create(
        item_code="RM001", item_name="Raw Material 1",
        item_type="RM", purchase_uom=uom_kg, stock_uom=uom_kg,
    )
    rm2 = Item.objects.create(
        item_code="RM002", item_name="Raw Material 2",
        item_type="RM", purchase_uom=uom_kg, stock_uom=uom_kg,
    )
    wc = WorkCenter.objects.create(
        plant=plant, code="WC01", name="Assembly Line",
        capacity_per_day=8, cost_per_hour=Decimal("200"),
    )
    return dict(
        company=company, plant=plant, user=user,
        uom=uom, uom_kg=uom_kg, fg=fg, rm1=rm1, rm2=rm2, wc=wc,
    )


def make_bom(plant, fg, uom, rm1, rm2, status="ACTIVE"):
    bom = ProductionBOMHeader.objects.create(
        plant=plant, finished_good=fg, bom_number="BOM001",
        revision="A", base_qty=Decimal("1"), base_uom=uom,
        status=status, effective_from=date.today(),
    )
    ProductionBOMLine.objects.create(
        bom=bom, line_no=1, component=rm1, component_type="RAW",
        qty_per_base=Decimal("2.5"), uom=rm1.stock_uom, scrap_pct=Decimal("5"),
    )
    ProductionBOMLine.objects.create(
        bom=bom, line_no=2, component=rm2, component_type="RAW",
        qty_per_base=Decimal("1.0"), uom=rm2.stock_uom, scrap_pct=Decimal("0"),
    )
    return bom


# ═══════════════════════════════════════════════════════════════════
# TEST CASES
# ═══════════════════════════════════════════════════════════════════

class TestProductionBOM(TestCase):
    def setUp(self):
        self.f = make_fixtures()

    def test_01_bom_header_creation(self):
        """BOM header created with correct defaults."""
        bom = make_bom(**{k: self.f[k] for k in ["plant", "fg", "uom", "rm1", "rm2"]})
        self.assertEqual(bom.status, "ACTIVE")
        self.assertEqual(bom.lines.count(), 2)

    def test_02_bom_line_effective_qty_with_scrap(self):
        """BOM line effective_qty includes scrap percentage."""
        bom = make_bom(**{k: self.f[k] for k in ["plant", "fg", "uom", "rm1", "rm2"]})
        line = bom.lines.get(line_no=1)
        expected = Decimal("2.5") * (1 + Decimal("5") / Decimal("100"))
        self.assertEqual(line.effective_qty, expected)

    def test_03_bom_line_no_scrap(self):
        """BOM line with 0% scrap has effective_qty == qty_per_base."""
        bom = make_bom(**{k: self.f[k] for k in ["plant", "fg", "uom", "rm1", "rm2"]})
        line = bom.lines.get(line_no=2)
        self.assertEqual(line.effective_qty, Decimal("1.0"))

    def test_04_explode_bom_flat(self):
        """BOM explosion returns correct component list."""
        f = self.f
        bom = make_bom(f["plant"], f["fg"], f["uom"], f["rm1"], f["rm2"])
        result = services.explode_bom(bom, Decimal("10"))
        self.assertEqual(len(result), 2)
        # RM1 qty should be 2.5 × 1.05 × 10 = 26.25
        rm1_row = next(r for r in result if r["item_code"] == "RM001")
        self.assertAlmostEqual(float(rm1_row["qty"]), 26.25)

    def test_05_consolidate_explosion(self):
        """Duplicate items in explosion are merged."""
        f = self.f
        bom = make_bom(f["plant"], f["fg"], f["uom"], f["rm1"], f["rm2"])
        exploded = services.explode_bom(bom, Decimal("1"))
        consolidated = services.consolidate_explosion(exploded)
        # No duplicates in flat BOM — should still be 2
        self.assertEqual(len(consolidated), 2)


class TestWorkOrderLifecycle(TestCase):
    def setUp(self):
        self.f = make_fixtures()
        self.bom = make_bom(self.f["plant"], self.f["fg"], self.f["uom"], self.f["rm1"], self.f["rm2"])

    def test_06_create_work_order(self):
        """Work order created with DRAFT status and WO number."""
        f = self.f
        wo = services.create_work_order(
            plant=f["plant"], finished_good=f["fg"],
            planned_qty=Decimal("50"),
            planned_start=date.today(),
            planned_end=date.today() + timedelta(days=5),
            bom=self.bom,
            uom=f["uom"],
            user=f["user"],
        )
        self.assertIsNotNone(wo.pk)
        self.assertEqual(wo.status, "DRAFT")
        self.assertTrue(wo.wo_number.startswith("WO/"))

    def test_07_create_work_order_auto_selects_bom(self):
        """WO creation auto-selects active BOM when none provided."""
        f = self.f
        wo = services.create_work_order(
            plant=f["plant"], finished_good=f["fg"],
            planned_qty=Decimal("10"),
            planned_start=date.today(),
            planned_end=date.today() + timedelta(days=3),
            uom=f["uom"],
            user=f["user"],
        )
        self.assertEqual(wo.bom, self.bom)

    def test_08_release_work_order(self):
        """WO release changes status to RELEASED."""
        f = self.f
        wo = services.create_work_order(
            plant=f["plant"], finished_good=f["fg"],
            planned_qty=Decimal("20"),
            planned_start=date.today(),
            planned_end=date.today() + timedelta(days=3),
            uom=f["uom"],
        )
        wo = services.release_work_order(wo, user=f["user"])
        self.assertEqual(wo.status, "RELEASED")
        self.assertIsNotNone(wo.actual_start)

    def test_09_cannot_release_non_draft_wo(self):
        """Releasing a non-DRAFT WO raises ValueError."""
        f = self.f
        wo = services.create_work_order(
            plant=f["plant"], finished_good=f["fg"],
            planned_qty=Decimal("10"),
            planned_start=date.today(),
            planned_end=date.today() + timedelta(days=1),
            uom=f["uom"],
        )
        services.release_work_order(wo)
        with self.assertRaises(ValueError):
            services.release_work_order(wo)

    def test_10_wo_total_variance_calculation(self):
        """WO total variance = actual - std across all cost categories."""
        f = self.f
        wo = services.create_work_order(
            plant=f["plant"], finished_good=f["fg"],
            planned_qty=Decimal("10"),
            planned_start=date.today(),
            planned_end=date.today() + timedelta(days=2),
            uom=f["uom"],
        )
        wo.std_material_cost = Decimal("1000")
        wo.actual_material_cost = Decimal("1200")
        wo.std_labour_cost = Decimal("500")
        wo.actual_labour_cost = Decimal("450")
        self.assertEqual(wo.total_variance, Decimal("150"))  # 200 - 50

    def test_11_close_wo_requires_completed_status(self):
        """close_work_order raises ValueError if WO is not COMPLETED."""
        f = self.f
        wo = services.create_work_order(
            plant=f["plant"], finished_good=f["fg"],
            planned_qty=Decimal("5"),
            planned_start=date.today(),
            planned_end=date.today() + timedelta(days=1),
            uom=f["uom"],
        )
        with self.assertRaises(ValueError):
            services.close_work_order(wo)


class TestJobCard(TestCase):
    def setUp(self):
        self.f = make_fixtures()
        self.bom = make_bom(self.f["plant"], self.f["fg"], self.f["uom"], self.f["rm1"], self.f["rm2"])
        self.wo = services.create_work_order(
            plant=self.f["plant"], finished_good=self.f["fg"],
            planned_qty=Decimal("100"),
            planned_start=date.today(),
            planned_end=date.today() + timedelta(days=5),
            uom=self.f["uom"],
        )
        services.release_work_order(self.wo)

    def _make_jc(self):
        jc_num = services.get_next_doc_number(self.f["plant"], "JC", "JC")
        return JobCard.objects.create(
            work_order=self.wo,
            jc_number=jc_num,
            operation_name="Assembly",
            sequence_no=10,
            work_center=self.f["wc"],
            planned_hours=Decimal("4"),
            planned_qty=Decimal("100"),
        )

    def test_12_complete_job_card(self):
        """Completing a job card sets status and updates WO labour cost."""
        jc = self._make_jc()
        jc = services.complete_job_card(
            jc, completed_qty=Decimal("98"), rejected_qty=Decimal("2"),
            actual_hours=Decimal("5"), user=self.f["user"],
        )
        self.assertEqual(jc.status, "COMPLETED")
        self.assertEqual(jc.completed_qty, Decimal("98"))
        self.wo.refresh_from_db()
        # Labour: 5 hrs × ₹200/hr = ₹1000
        self.assertEqual(self.wo.actual_labour_cost, Decimal("1000.00"))

    def test_13_complete_jc_twice_raises_error(self):
        """Completing an already-completed JC raises ValueError."""
        jc = self._make_jc()
        services.complete_job_card(jc, Decimal("100"), Decimal("0"), Decimal("4"))
        with self.assertRaises(ValueError):
            services.complete_job_card(jc, Decimal("100"), Decimal("0"), Decimal("4"))

    def test_14_all_jcs_complete_marks_wo_completed(self):
        """When all JCs are done, WO status moves to COMPLETED."""
        jc = self._make_jc()
        services.complete_job_card(jc, Decimal("100"), Decimal("0"), Decimal("8"))
        self.wo.refresh_from_db()
        self.assertEqual(self.wo.status, "COMPLETED")


class TestMaterialIssue(TestCase):
    def setUp(self):
        self.f = make_fixtures()
        self.bom = make_bom(self.f["plant"], self.f["fg"], self.f["uom"], self.f["rm1"], self.f["rm2"])
        self.wo = services.create_work_order(
            plant=self.f["plant"], finished_good=self.f["fg"],
            planned_qty=Decimal("50"),
            planned_start=date.today(),
            planned_end=date.today() + timedelta(days=3),
            uom=self.f["uom"],
        )
        services.release_work_order(self.wo)

    def test_15_issue_materials_creates_issue_record(self):
        """Material issue creates WOMaterialIssue + lines."""
        f = self.f
        issue = services.issue_materials_to_wo(
            wo=self.wo,
            issue_date=date.today(),
            lines_data=[
                {"item_id": f["rm1"].pk, "issued_qty": "125", "uom_id": f["uom_kg"].pk,
                 "planned_qty": "131.25", "unit_cost": "50"},
                {"item_id": f["rm2"].pk, "issued_qty": "50", "uom_id": f["uom_kg"].pk,
                 "planned_qty": "50", "unit_cost": "80"},
            ],
        )
        self.assertEqual(issue.status, "ISSUED")
        self.assertEqual(issue.lines.count(), 2)
        self.wo.refresh_from_db()
        # Cost: 125×50 + 50×80 = 6250 + 4000 = 10250
        self.assertEqual(self.wo.actual_material_cost, Decimal("10250.00"))

    def test_16_issue_to_draft_wo_raises_error(self):
        """Cannot issue materials to DRAFT WO."""
        f = self.f
        draft_wo = services.create_work_order(
            plant=f["plant"], finished_good=f["fg"],
            planned_qty=Decimal("10"),
            planned_start=date.today(),
            planned_end=date.today() + timedelta(days=1),
            uom=f["uom"],
        )
        with self.assertRaises(ValueError):
            services.issue_materials_to_wo(
                wo=draft_wo, issue_date=date.today(),
                lines_data=[{"item_id": f["rm1"].pk, "issued_qty": "10",
                              "uom_id": f["uom_kg"].pk}],
            )


class TestMRP(TestCase):
    def setUp(self):
        self.f = make_fixtures()
        self.bom = make_bom(self.f["plant"], self.f["fg"], self.f["uom"], self.f["rm1"], self.f["rm2"])

    def test_17_mrp_run_created_with_running_status(self):
        """MRP run object created and completes successfully."""
        f = self.f
        mrp = services.run_mrp(f["plant"], horizon_days=30, user=f["user"])
        self.assertIn(mrp.status, ("COMPLETED", "FAILED"))
        self.assertTrue(mrp.run_number.startswith("MRP/"))

    def test_18_mrp_generates_suggestions_from_so(self):
        """MRP reads open SOs and generates PRODUCE suggestions."""
        f = self.f
        # We can't create full SO without sales app fixtures so we just verify
        # that run completes without error even with no demand
        mrp = services.run_mrp(f["plant"], horizon_days=30)
        self.assertEqual(mrp.status, "COMPLETED")
        self.assertIn("suggestions_created", mrp.summary)

    def test_19_mrp_suggestion_fields(self):
        """MRP suggestions have required fields."""
        f = self.f
        mrp = services.run_mrp(f["plant"], horizon_days=30)
        # Create a manual suggestion to test model
        sugg = MRPSuggestion.objects.create(
            mrp_run=mrp,
            item=f["rm1"],
            suggestion_type="PURCHASE",
            required_qty=Decimal("100"),
            available_qty=Decimal("30"),
            shortage_qty=Decimal("70"),
            uom=f["uom_kg"],
            required_by=date.today() + timedelta(days=14),
            suggested_qty=Decimal("70"),
            source_demand=["SO:SO001"],
            status="OPEN",
        )
        self.assertEqual(str(sugg.shortage_qty), "70")
        self.assertEqual(sugg.status, "OPEN")


class TestMachineLoading(TestCase):
    def setUp(self):
        self.f = make_fixtures()
        self.bom = make_bom(self.f["plant"], self.f["fg"], self.f["uom"], self.f["rm1"], self.f["rm2"])
        self.wo = services.create_work_order(
            plant=self.f["plant"], finished_good=self.f["fg"],
            planned_qty=Decimal("10"),
            planned_start=date.today(),
            planned_end=date.today() + timedelta(days=2),
            uom=self.f["uom"],
        )
        services.release_work_order(self.wo)

    def test_20_machine_loading_summary(self):
        """Machine loading returns correct utilization data."""
        f = self.f
        jc_num = services.get_next_doc_number(f["plant"], "JC", "JC")
        jc = JobCard.objects.create(
            work_order=self.wo, jc_number=jc_num,
            operation_name="Test Op", sequence_no=10,
            work_center=f["wc"], planned_hours=Decimal("6"),
            planned_qty=Decimal("10"),
        )
        MachineLoadingPlan.objects.create(
            plant=f["plant"], work_center=f["wc"], job_card=jc,
            scheduled_date=date.today(),
            start_time="08:00:00", end_time="14:00:00",
            planned_hours=Decimal("6"),
        )
        result = services.get_machine_loading(
            f["plant"], date.today(), date.today()
        )
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0]["work_center_code"], "WC01")
        # 6/8 * 100 = 75%
        self.assertEqual(result[0]["utilization_pct"], 75.0)

    def test_21_get_next_doc_number_format(self):
        """Document numbers follow PREFIX/YYYY-YY/NNNNN format."""
        f = self.f
        num = services.get_next_doc_number(f["plant"], "WO", "WO")
        parts = num.split("/")
        self.assertEqual(parts[0], "WO")
        self.assertRegex(parts[1], r"\d{4}-\d{2}")
        self.assertEqual(len(parts[2]), 5)

    def test_22_sequential_doc_numbers_increment(self):
        """Successive doc numbers are sequential."""
        f = self.f
        n1 = services.get_next_doc_number(f["plant"], "TEST", "TEST")
        n2 = services.get_next_doc_number(f["plant"], "TEST", "TEST")
        seq1 = int(n1.split("/")[-1])
        seq2 = int(n2.split("/")[-1])
        self.assertEqual(seq2, seq1 + 1)

    def test_23_work_center_str(self):
        """WorkCenter __str__ returns code — name."""
        f = self.f
        self.assertIn("WC01", str(f["wc"]))

    def test_24_work_order_str(self):
        """WorkOrder __str__ includes wo_number and item_code."""
        f = self.f
        wo = services.create_work_order(
            plant=f["plant"], finished_good=f["fg"],
            planned_qty=Decimal("5"),
            planned_start=date.today(),
            planned_end=date.today() + timedelta(days=1),
            uom=f["uom"],
        )
        self.assertIn(wo.wo_number, str(wo))
        self.assertIn("FG001", str(wo))

    # ── P2: Machine Auto-Allocation ───────────────────────────────

    def test_workcenter_deckle_fields_exist(self):
        """WorkCenter model has deckle range and machine_type fields."""
        from apps.production.models import WorkCenter
        field_names = [f.name for f in WorkCenter._meta.get_fields()]
        self.assertIn("min_deckle_mm", field_names)
        self.assertIn("max_deckle_mm", field_names)
        self.assertIn("machine_type", field_names)

    def test_workorder_suggested_work_centers_field_exists(self):
        """WorkOrder has suggested_work_centers JSONField."""
        from apps.production.models import WorkOrder
        field_names = [f.name for f in WorkOrder._meta.get_fields()]
        self.assertIn("suggested_work_centers", field_names)

    def test_suggest_work_centers_service(self):
        """suggest_work_centers_for_box returns QuerySet."""
        from apps.production.services import suggest_work_centers_for_box
        from apps.production.models import WorkCenter
        from apps.core.models import Plant
        plant = Plant.objects.first()
        if plant:
            # Create a work centre with deckle range
            wc = WorkCenter.objects.create(
                plant=plant, code="TEST-WC-SUGGEST", name="Test Corrugator",
                min_deckle_mm=300, max_deckle_mm=600, machine_type="CORRUGATOR"
            )
            # 380mm should match
            results = suggest_work_centers_for_box(plant, 380)
            self.assertIn(wc, results)
            # 700mm should NOT match
            results_miss = suggest_work_centers_for_box(plant, 700)
            self.assertNotIn(wc, results_miss)
            wc.delete()

    def test_suggest_endpoint_returns_200(self):
        """Work centre suggest endpoint returns 200."""
        resp = self.client.get("/api/v1/production/work-centers/suggest/?box_width_mm=380")
        self.assertEqual(resp.status_code, 200)
        self.assertIn("suggested_work_centers", resp.data)

    def test_suggest_endpoint_missing_param_returns_400(self):
        """Work centre suggest without box_width_mm returns 400."""
        resp = self.client.get("/api/v1/production/work-centers/suggest/")
        self.assertEqual(resp.status_code, 400)

    # ── P2 additional tests (exact names from spec) ───────────────
    def test_suggest_work_centers_by_deckle(self):
        """Work centre with matching deckle range is returned."""
        from apps.production.services import suggest_work_centers_for_box
        from apps.production.models import WorkCenter
        from apps.core.models import Plant
        plant = Plant.objects.first()
        if plant:
            wc = WorkCenter.objects.create(
                plant=plant, code="COR-TEST-SPEC", name="Test Corrugator Spec",
                min_deckle_mm=300, max_deckle_mm=600, machine_type="CORRUGATOR"
            )
            results = suggest_work_centers_for_box(plant, 380)
            self.assertIn(wc, results)
            wc.delete()

    def test_suggest_excludes_out_of_range(self):
        """Work centre outside deckle range is not returned."""
        from apps.production.services import suggest_work_centers_for_box
        from apps.production.models import WorkCenter
        from apps.core.models import Plant
        plant = Plant.objects.first()
        if plant:
            wc = WorkCenter.objects.create(
                plant=plant, code="COR-SMALL-SPEC", name="Small Corrugator Spec",
                min_deckle_mm=100, max_deckle_mm=300, machine_type="CORRUGATOR"
            )
            results = suggest_work_centers_for_box(plant, 500)
            self.assertNotIn(wc, results)
            wc.delete()

    def test_suggest_api_returns_200(self):
        """Work centre suggest endpoint returns 200."""
        resp = self.client.get("/api/v1/production/work-centers/suggest/?box_width_mm=380")
        self.assertEqual(resp.status_code, 200)
        self.assertIn("suggested_work_centers", resp.data)

    def test_suggest_api_missing_param_returns_400(self):
        """Work centre suggest without box_width_mm returns 400."""
        resp = self.client.get("/api/v1/production/work-centers/suggest/")
        self.assertEqual(resp.status_code, 400)
