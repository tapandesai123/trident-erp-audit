"""Production API Viewsets."""
from decimal import Decimal
from datetime import date
from rest_framework import viewsets, status, filters
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django_filters.rest_framework import DjangoFilterBackend

from apps.production.models import (
    ProductionBOMHeader, ProductionBOMLine,
    WorkCenter, WorkOrder, JobCard,
    WOMaterialIssue, MachineLoadingPlan,
    MRPRun, MRPSuggestion,
)
from apps.production.api.serializers import (
    ProductionBOMListSerializer, ProductionBOMDetailSerializer, ProductionBOMCreateSerializer,
    WorkCenterListSerializer, WorkCenterDetailSerializer, WorkCenterCreateSerializer,
    WorkOrderListSerializer, WorkOrderDetailSerializer, WorkOrderCreateSerializer,
    JobCardListSerializer, JobCardDetailSerializer, JobCardCreateSerializer,
    WOMaterialIssueListSerializer, WOMaterialIssueDetailSerializer, WOMaterialIssueCreateSerializer,
    MachineLoadingPlanListSerializer, MachineLoadingPlanDetailSerializer, MachineLoadingPlanCreateSerializer,
    MRPRunListSerializer, MRPRunDetailSerializer,
    MRPSuggestionListSerializer, MRPSuggestionDetailSerializer,
)
from apps.production import services


class ProductionBOMViewSet(viewsets.ModelViewSet):
    queryset = ProductionBOMHeader.objects.select_related("plant", "finished_good", "base_uom").prefetch_related("lines")
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return ProductionBOMListSerializer
        if self.action in ("create", "update", "partial_update"):
            return ProductionBOMCreateSerializer
        return ProductionBOMDetailSerializer

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)

    @action(detail=True, methods=["post"])
    def activate(self, request, pk=None):
        bom = self.get_object()
        bom.status = "ACTIVE"
        bom.save(update_fields=["status"])
        return Response({"status": "activated"})

    @action(detail=True, methods=["post"])
    def explode(self, request, pk=None):
        """Explode BOM for a given quantity."""
        bom = self.get_object()
        qty = Decimal(str(request.data.get("qty", bom.base_qty)))
        try:
            result = services.consolidate_explosion(services.explode_bom(bom, qty))
            data = [
                {
                    "item_code": r["item_code"],
                    "item_name": r["item_name"],
                    "qty": str(r["qty"]),
                    "uom": r["uom"].uom_code,
                    "component_type": r["component_type"],
                    "depth": r["depth"],
                    "is_critical": r["is_critical"],
                }
                for r in result
            ]
            return Response({"bom": bom.bom_number, "qty": str(qty), "components": data})
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)


class WorkCenterViewSet(viewsets.ModelViewSet):
    queryset = WorkCenter.objects.select_related("plant")
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return WorkCenterListSerializer
        if self.action in ("create", "update", "partial_update"):
            return WorkCenterCreateSerializer
        return WorkCenterDetailSerializer

    @action(detail=False, methods=["get"], url_path="suggest")
    def suggest(self, request):
        """
        GET /api/v1/production/work-centers/suggest/?box_width_mm=380&machine_type=CORRUGATOR
        Returns list of work centres that can handle the given box width.
        """
        box_width = request.query_params.get("box_width_mm")
        if not box_width:
            return Response({"error": "box_width_mm is required"}, status=400)
        try:
            box_width = float(box_width)
        except ValueError:
            return Response({"error": "box_width_mm must be a number"}, status=400)

        machine_type = request.query_params.get("machine_type")
        plant = request.user.plant

        from apps.production.services import suggest_work_centers_for_box
        qs = suggest_work_centers_for_box(plant, box_width, machine_type)
        serializer = self.get_serializer(qs, many=True)
        return Response({
            "box_width_mm": box_width,
            "machine_type_filter": machine_type,
            "suggested_work_centers": serializer.data,
            "count": qs.count(),
        })


class WorkOrderViewSet(viewsets.ModelViewSet):
    queryset = WorkOrder.objects.select_related(
        "plant", "finished_good", "finished_good__item_group",
        "bom", "uom", "created_by"
    ).prefetch_related(
        "job_cards__work_center",
        "job_cards__assigned_to",
        "material_issues__lines__item",
        "bom__lines__item",
    )
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return WorkOrderListSerializer
        if self.action in ("create", "update", "partial_update"):
            return WorkOrderCreateSerializer
        return WorkOrderDetailSerializer

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        d = serializer.validated_data
        try:
            wo = services.create_work_order(
                plant=d["plant"],
                finished_good=d["finished_good"],
                planned_qty=d["planned_qty"],
                planned_start=d["planned_start"],
                planned_end=d["planned_end"],
                bom=d.get("bom"),
                uom=d.get("uom"),
                priority=d.get("priority", 5),
                notes=d.get("notes", ""),
                user=request.user,
            )
            return Response(WorkOrderDetailSerializer(wo).data, status=status.HTTP_201_CREATED)
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=True, methods=["post"])
    def release(self, request, pk=None):
        wo = self.get_object()
        try:
            wo = services.release_work_order(wo, user=request.user)
            return Response(WorkOrderDetailSerializer(wo).data)
        except ValueError as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=True, methods=["post"])
    def close(self, request, pk=None):
        wo = self.get_object()
        try:
            wo = services.close_work_order(wo, user=request.user)
            return Response(WorkOrderDetailSerializer(wo).data)
        except ValueError as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=False, methods=["get"], url_path="daily-tonnage")
    def daily_tonnage(self, request):
        """
        GET /api/v1/production/work-orders/daily-tonnage/?date=YYYY-MM-DD
        Returns production qty and dispatch weight for the given date.
        """
        from datetime import datetime
        from django.db.models import Sum
        from apps.dispatch.models import DispatchPlan

        date_str = request.query_params.get("date")
        if date_str:
            try:
                report_date = datetime.strptime(date_str, "%Y-%m-%d").date()
            except ValueError:
                return Response({"error": "Invalid date format. Use YYYY-MM-DD."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            from datetime import date as today_date
            report_date = today_date.today()

        # Production: sum completed_qty from JobCards completed on report_date
        production_qs = JobCard.objects.filter(
            status="COMPLETED",
            completed_at__date=report_date,
        ).values("work_order__finished_good__code", "work_order__finished_good__name").annotate(
            qty=Sum("completed_qty")
        )
        production_qty_total = sum(row["qty"] or 0 for row in production_qs)

        # Dispatch: sum total_weight_kg from DispatchPlans completed on report_date
        dispatch_agg = DispatchPlan.objects.filter(
            status="COMPLETED",
            plan_date=report_date,
        ).aggregate(total=Sum("total_weight_kg"))
        dispatch_weight_kg = dispatch_agg["total"] or 0

        return Response({
            "date": str(report_date),
            "production_qty_total": production_qty_total,
            "dispatch_weight_kg_total": float(dispatch_weight_kg),
            "dispatch_weight_mt": round(float(dispatch_weight_kg) / 1000, 3),
            "production_by_item": [
                {
                    "item_code": row["work_order__finished_good__code"],
                    "item_name": row["work_order__finished_good__name"],
                    "qty": float(row["qty"] or 0),
                }
                for row in production_qs
            ],
        })


class JobCardViewSet(viewsets.ModelViewSet):
    queryset = JobCard.objects.select_related("work_order", "work_center", "assigned_to")
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return JobCardListSerializer
        if self.action in ("create", "update", "partial_update"):
            return JobCardCreateSerializer
        return JobCardDetailSerializer

    def perform_create(self, serializer):
        jc_number = services.get_next_doc_number(
            serializer.validated_data["work_order"].plant, "JC", "JC"
        )
        serializer.save(jc_number=jc_number)

    @action(detail=True, methods=["post"])
    def complete(self, request, pk=None):
        jc = self.get_object()
        completed_qty = Decimal(str(request.data.get("completed_qty", 0)))
        rejected_qty = Decimal(str(request.data.get("rejected_qty", 0)))
        actual_hours = Decimal(str(request.data.get("actual_hours", 0)))
        remarks = request.data.get("remarks", "")
        try:
            jc = services.complete_job_card(
                jc, completed_qty, rejected_qty, actual_hours, remarks, user=request.user
            )
            return Response(JobCardDetailSerializer(jc).data)
        except ValueError as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=False, methods=["get"])
    def scan(self, request):
        """
        GET /api/v1/production/job-cards/scan/?qr={code}
        Parse QR and return full job card detail with work order context.
        """
        import json
        qr = request.query_params.get("qr", "")
        job_card_id = None
        try:
            parsed = json.loads(qr)
            job_card_id = parsed.get("job_card_id") or parsed.get("id")
        except (json.JSONDecodeError, TypeError):
            job_card_id = qr.strip()

        try:
            jc = JobCard.objects.select_related(
                "work_order", "work_order__finished_good", "work_center", "assigned_to"
            ).get(pk=job_card_id)
        except (JobCard.DoesNotExist, ValueError):
            return Response({"error": "Job card not found"}, status=status.HTTP_404_NOT_FOUND)

        wo = jc.work_order
        data = {
            "id": str(jc.pk),
            "jc_number": jc.jc_number,
            "qr_code": qr,
            "operation_name": jc.operation_name,
            "sequence_no": jc.sequence_no,
            "status": jc.status,
            "current_stage": jc.operation_name,
            "work_center": jc.work_center.name if jc.work_center else None,
            "planned_qty": str(jc.planned_qty),
            "completed_qty": str(jc.completed_qty),
            "rejected_qty": str(jc.rejected_qty),
            "planned_hours": str(jc.planned_hours),
            "actual_hours": str(jc.actual_hours),
            "work_order": {
                "id": str(wo.pk),
                "wo_number": wo.wo_number,
                "item_code": wo.finished_good.code,
                "item_name": wo.finished_good.name,
                "planned_qty": str(wo.planned_qty),
                "produced_qty": str(wo.produced_qty),
                "status": wo.status,
            },
        }
        return Response(data)


    @action(detail=False, methods=["get"], url_path="delayed")
    def delayed(self, request):
        """
        GET /api/v1/production/job-cards/delayed/
        Returns all IN_PROGRESS job cards flagged as delayed.
        """
        qs = JobCard.objects.filter(
            status="IN_PROGRESS", is_delayed=True
        ).select_related("work_order__finished_good", "work_center", "assigned_to")
        serializer = JobCardDetailSerializer(qs, many=True)
        return Response(serializer.data)


class WOMaterialIssueViewSet(viewsets.ModelViewSet):
    queryset = WOMaterialIssue.objects.select_related("work_order", "issued_by").prefetch_related("lines")
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return WOMaterialIssueListSerializer
        if self.action in ("create", "update", "partial_update"):
            return WOMaterialIssueCreateSerializer
        return WOMaterialIssueDetailSerializer

    @action(detail=True, methods=["post"])
    def issue(self, request, pk=None):
        """Issue materials: pass lines_data in request body."""
        mi = self.get_object()
        lines_data = request.data.get("lines_data", [])
        try:
            issue = services.issue_materials_to_wo(
                wo=mi.work_order,
                issue_date=date.today(),
                lines_data=lines_data,
                warehouse=mi.store_location,
                user=request.user,
            )
            return Response(WOMaterialIssueDetailSerializer(issue).data)
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)


class MachineLoadingPlanViewSet(viewsets.ModelViewSet):
    queryset = MachineLoadingPlan.objects.select_related("work_center", "job_card", "plant")
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return MachineLoadingPlanListSerializer
        if self.action in ("create", "update", "partial_update"):
            return MachineLoadingPlanCreateSerializer
        return MachineLoadingPlanDetailSerializer

    @action(detail=False, methods=["get"])
    def loading_summary(self, request):
        """GET /api/v1/production/loading-plans/loading_summary/?plant=1&from=YYYY-MM-DD&to=YYYY-MM-DD"""
        from apps.core.models import Plant
        plant_id = request.query_params.get("plant")
        from_date = request.query_params.get("from", str(date.today()))
        to_date = request.query_params.get("to", str(date.today()))
        try:
            plant = Plant.objects.get(pk=plant_id)
            result = services.get_machine_loading(
                plant,
                date.fromisoformat(from_date),
                date.fromisoformat(to_date),
            )
            return Response(result)
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)


class MRPRunViewSet(viewsets.ModelViewSet):
    queryset = MRPRun.objects.select_related("plant", "initiated_by")
    permission_classes = [IsAuthenticated]
    http_method_names = ["get", "post"]

    def get_serializer_class(self):
        if self.action == "list":
            return MRPRunListSerializer
        return MRPRunDetailSerializer

    @action(detail=False, methods=["post"])
    def trigger(self, request):
        """POST /api/v1/production/mrp-runs/trigger/ {plant, horizon_days}"""
        from apps.core.models import Plant
        from apps.production.tasks import run_mrp_task
        plant_id = request.data.get("plant")
        horizon_days = int(request.data.get("horizon_days", 30))
        try:
            plant = Plant.objects.get(pk=plant_id)
        except Plant.DoesNotExist:
            return Response({"error": "Plant not found"}, status=status.HTTP_404_NOT_FOUND)
        # Trigger async
        run_mrp_task.delay(plant.pk, horizon_days, request.user.pk)
        return Response({"message": f"MRP run triggered for plant {plant.code}, horizon {horizon_days} days."})


class MRPSuggestionViewSet(viewsets.ModelViewSet):
    queryset = MRPSuggestion.objects.select_related("mrp_run", "item", "uom")
    permission_classes = [IsAuthenticated]
    http_method_names = ["get", "patch"]

    def get_serializer_class(self):
        if self.action == "list":
            return MRPSuggestionListSerializer
        return MRPSuggestionDetailSerializer

    @action(detail=True, methods=["patch"])
    def accept(self, request, pk=None):
        sugg = self.get_object()
        sugg.status = "ACCEPTED"
        sugg.save(update_fields=["status"])
        return Response({"status": "ACCEPTED"})

    @action(detail=True, methods=["patch"])
    def reject(self, request, pk=None):
        sugg = self.get_object()
        sugg.status = "REJECTED"
        sugg.remarks = request.data.get("remarks", "")
        sugg.save(update_fields=["status", "remarks"])
        return Response({"status": "REJECTED"})


# ═══════════════════════════════════════════════════════════════════
# PRODUCTION DOWNTIME VIEWSET
# ═══════════════════════════════════════════════════════════════════

class ProductionDowntimeViewSet(viewsets.ModelViewSet):
    """Machine downtime recording and reporting for PPC dashboards."""
    permission_classes = [IsAuthenticated]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ["work_center", "category", "shift"]
    search_fields = ["reason_detail", "work_center__name"]
    ordering = ["-downtime_start"]

    def get_queryset(self):
        from apps.production.models import ProductionDowntime
        qs = ProductionDowntime.objects.select_related(
            "work_center", "work_order", "job_card", "recorded_by"
        )
        if hasattr(self.request, "plant"):
            qs = qs.filter(plant=self.request.plant)
        # Date range filter
        date_from = self.request.query_params.get("date_from")
        date_to = self.request.query_params.get("date_to")
        if date_from:
            qs = qs.filter(downtime_start__date__gte=date_from)
        if date_to:
            qs = qs.filter(downtime_start__date__lte=date_to)
        return qs

    def get_serializer_class(self):
        from apps.production.api.serializers import ProductionDowntimeSerializer
        return ProductionDowntimeSerializer

    def perform_create(self, serializer):
        plant = getattr(self.request, "plant", None)
        serializer.save(recorded_by=self.request.user, plant=plant)

    @action(detail=False, methods=["get"])
    def summary(self, request):
        """Group by work_center + category + date range — total minutes per category."""
        from apps.production.models import ProductionDowntime
        from django.db.models import Sum, F, ExpressionWrapper, DurationField, Count
        from django.utils import timezone
        import datetime

        qs = self.get_queryset().filter(downtime_end__isnull=False)

        results = {}
        for dt in qs:
            key = dt.category
            if key not in results:
                results[key] = {"category": key, "total_minutes": 0, "count": 0}
            if dt.duration_minutes:
                results[key]["total_minutes"] += dt.duration_minutes
                results[key]["count"] += 1

        # Per work center summary
        wc_summary = {}
        for dt in qs:
            wc = str(dt.work_center)
            if wc not in wc_summary:
                wc_summary[wc] = {"work_center": wc, "total_minutes": 0}
            if dt.duration_minutes:
                wc_summary[wc]["total_minutes"] += dt.duration_minutes

        return Response({
            "by_category": list(results.values()),
            "by_work_center": sorted(wc_summary.values(),
                                     key=lambda x: -x["total_minutes"])[:10],
        })
