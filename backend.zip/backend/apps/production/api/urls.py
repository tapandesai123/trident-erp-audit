"""Production API URL configuration."""
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from apps.production.api.viewsets import (
    ProductionBOMViewSet, WorkCenterViewSet, WorkOrderViewSet,
    JobCardViewSet, WOMaterialIssueViewSet, MachineLoadingPlanViewSet,
    MRPRunViewSet, MRPSuggestionViewSet, ProductionDowntimeViewSet,
)

router = DefaultRouter()
router.register("boms", ProductionBOMViewSet, basename="production-bom")
router.register("work-centers", WorkCenterViewSet, basename="work-center")
router.register("work-orders", WorkOrderViewSet, basename="work-order")
router.register("job-cards", JobCardViewSet, basename="job-card")
router.register("material-issues", WOMaterialIssueViewSet, basename="wo-material-issue")
router.register("loading-plans", MachineLoadingPlanViewSet, basename="machine-loading-plan")
router.register("mrp-runs", MRPRunViewSet, basename="mrp-run")
router.register("mrp-suggestions", MRPSuggestionViewSet, basename="mrp-suggestion")
router.register("downtime", ProductionDowntimeViewSet, basename="production-downtime")

urlpatterns = [
    path("", include(router.urls)),
]
