"""Production API Serializers — 3 variants per major model."""
from rest_framework import serializers
from apps.production.models import (
    ProductionBOMHeader, ProductionBOMLine,
    WorkCenter, WorkOrder, JobCard,
    WOMaterialIssue, WOMaterialIssueLine,
    MachineLoadingPlan, MRPRun, MRPSuggestion,
)


# ─── ProductionBOM ────────────────────────────────────────────────

class ProductionBOMLineSerializer(serializers.ModelSerializer):
    component_code = serializers.CharField(source="component.item_code", read_only=True)
    component_name = serializers.CharField(source="component.item_name", read_only=True)
    uom_code = serializers.CharField(source="uom.uom_code", read_only=True)
    effective_qty = serializers.DecimalField(max_digits=14, decimal_places=6, read_only=True)

    class Meta:
        model = ProductionBOMLine
        fields = [
            "id", "uuid", "line_no", "component", "component_code", "component_name",
            "component_type", "qty_per_base", "effective_qty", "uom", "uom_code",
            "scrap_pct", "is_critical", "notes",
        ]


class ProductionBOMListSerializer(serializers.ModelSerializer):
    finished_good_code = serializers.CharField(source="finished_good.item_code", read_only=True)
    line_count = serializers.IntegerField(source="lines.count", read_only=True)

    class Meta:
        model = ProductionBOMHeader
        fields = [
            "id", "uuid", "bom_number", "revision", "status",
            "finished_good", "finished_good_code", "base_qty",
            "effective_from", "effective_to", "line_count",
        ]


class ProductionBOMDetailSerializer(serializers.ModelSerializer):
    finished_good_code = serializers.CharField(source="finished_good.item_code", read_only=True)
    base_uom_code = serializers.CharField(source="base_uom.uom_code", read_only=True)
    lines = ProductionBOMLineSerializer(many=True, read_only=True)

    class Meta:
        model = ProductionBOMHeader
        fields = "__all__"


class ProductionBOMCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProductionBOMHeader
        fields = [
            "plant", "finished_good", "bom_number", "revision", "base_qty",
            "base_uom", "effective_from", "effective_to", "routing_notes",
        ]


# ─── WorkCenter ───────────────────────────────────────────────────

class WorkCenterListSerializer(serializers.ModelSerializer):
    class Meta:
        model = WorkCenter
        fields = ["id", "uuid", "code", "name", "capacity_per_day", "cost_per_hour", "is_active"]


class WorkCenterDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = WorkCenter
        fields = "__all__"


class WorkCenterCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = WorkCenter
        fields = ["plant", "code", "name", "capacity_per_day", "cost_per_hour",
                  "min_deckle_mm", "max_deckle_mm", "machine_type", "is_active"]

    def validate(self, attrs):
        mn = attrs.get('min_deckle_mm')
        mx = attrs.get('max_deckle_mm')
        if mn is not None and mx is not None and mn > mx:
            raise serializers.ValidationError(
                {'min_deckle_mm': 'min_deckle_mm must be <= max_deckle_mm'}
            )
        return attrs


# ─── WorkOrder ────────────────────────────────────────────────────

class WorkOrderListSerializer(serializers.ModelSerializer):
    finished_good_code = serializers.CharField(source="finished_good.item_code", read_only=True)
    plant_code = serializers.CharField(source="plant.code", read_only=True)

    class Meta:
        model = WorkOrder
        fields = [
            "id", "uuid", "wo_number", "status", "priority",
            "finished_good", "finished_good_code", "plant_code",
            "planned_qty", "produced_qty", "rejected_qty",
            "planned_start", "planned_end", "actual_start", "actual_end",
        ]


class WorkOrderDetailSerializer(serializers.ModelSerializer):
    finished_good_code = serializers.CharField(source="finished_good.item_code", read_only=True)
    material_variance = serializers.DecimalField(max_digits=14, decimal_places=2, read_only=True)
    total_variance = serializers.DecimalField(max_digits=14, decimal_places=2, read_only=True)

    class Meta:
        model = WorkOrder
        fields = "__all__"


class WorkOrderCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = WorkOrder
        fields = [
            "plant", "finished_good", "bom", "planned_qty", "uom",
            "planned_start", "planned_end", "priority", "notes",
            "sales_order_line_id",
        ]


# ─── JobCard ──────────────────────────────────────────────────────

class JobCardListSerializer(serializers.ModelSerializer):
    work_order_number = serializers.CharField(source="work_order.wo_number", read_only=True)
    work_center_code = serializers.CharField(source="work_center.code", read_only=True)

    class Meta:
        model = JobCard
        fields = [
            "id", "uuid", "jc_number", "operation_name", "sequence_no",
            "work_order", "work_order_number", "work_center_code",
            "status", "planned_qty", "completed_qty", "rejected_qty",
            "planned_hours", "actual_hours",
        ]


class JobCardDetailSerializer(serializers.ModelSerializer):
    work_order_number = serializers.CharField(source="work_order.wo_number", read_only=True)
    work_center_name = serializers.CharField(source="work_center.name", read_only=True)

    class Meta:
        model = JobCard
        fields = "__all__"


class JobCardCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = JobCard
        fields = [
            "work_order", "operation_name", "sequence_no", "work_center",
            "assigned_to", "planned_hours", "planned_qty",
        ]


# ─── WOMaterialIssue ──────────────────────────────────────────────

class WOMaterialIssueLineSerializer(serializers.ModelSerializer):
    item_code = serializers.CharField(source="item.item_code", read_only=True)
    uom_code = serializers.CharField(source="uom.uom_code", read_only=True)
    line_cost = serializers.DecimalField(max_digits=14, decimal_places=2, read_only=True)

    class Meta:
        model = WOMaterialIssueLine
        fields = [
            "id", "uuid", "line_no", "item", "item_code",
            "planned_qty", "issued_qty", "uom", "uom_code",
            "unit_cost", "line_cost",
        ]


class WOMaterialIssueListSerializer(serializers.ModelSerializer):
    wo_number = serializers.CharField(source="work_order.wo_number", read_only=True)

    class Meta:
        model = WOMaterialIssue
        fields = ["id", "uuid", "issue_number", "issue_date", "wo_number", "status"]


class WOMaterialIssueDetailSerializer(serializers.ModelSerializer):
    wo_number = serializers.CharField(source="work_order.wo_number", read_only=True)
    lines = WOMaterialIssueLineSerializer(many=True, read_only=True)

    class Meta:
        model = WOMaterialIssue
        fields = "__all__"


class WOMaterialIssueCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = WOMaterialIssue
        fields = ["work_order", "issue_date", "store_location", "notes"]


# ─── MachineLoadingPlan ───────────────────────────────────────────

class MachineLoadingPlanListSerializer(serializers.ModelSerializer):
    work_center_code = serializers.CharField(source="work_center.code", read_only=True)
    jc_number = serializers.CharField(source="job_card.jc_number", read_only=True)

    class Meta:
        model = MachineLoadingPlan
        fields = [
            "id", "uuid", "work_center_code", "jc_number",
            "scheduled_date", "start_time", "end_time", "planned_hours", "is_confirmed",
        ]


class MachineLoadingPlanDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = MachineLoadingPlan
        fields = "__all__"


class MachineLoadingPlanCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = MachineLoadingPlan
        fields = ["plant", "work_center", "job_card", "scheduled_date", "start_time", "end_time", "planned_hours"]


# ─── MRPRun ───────────────────────────────────────────────────────

class MRPRunListSerializer(serializers.ModelSerializer):
    class Meta:
        model = MRPRun
        fields = ["id", "uuid", "run_number", "run_date", "status", "horizon_days", "summary", "completed_at"]


class MRPRunDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = MRPRun
        fields = "__all__"


# ─── MRPSuggestion ────────────────────────────────────────────────

class MRPSuggestionListSerializer(serializers.ModelSerializer):
    item_code = serializers.CharField(source="item.item_code", read_only=True)
    item_name = serializers.CharField(source="item.item_name", read_only=True)
    uom_code = serializers.CharField(source="uom.uom_code", read_only=True)

    class Meta:
        model = MRPSuggestion
        fields = [
            "id", "uuid", "item", "item_code", "item_name",
            "suggestion_type", "required_qty", "available_qty",
            "shortage_qty", "suggested_qty", "uom_code",
            "required_by", "status",
        ]


class MRPSuggestionDetailSerializer(serializers.ModelSerializer):
    item_code = serializers.CharField(source="item.item_code", read_only=True)

    class Meta:
        model = MRPSuggestion
        fields = "__all__"


# ── Production Downtime Serializer ────────────────────────────────

class ProductionDowntimeSerializer(serializers.ModelSerializer):
    work_center_name   = serializers.CharField(source="work_center.name", read_only=True)
    category_display   = serializers.CharField(source="get_category_display", read_only=True)
    shift_display      = serializers.CharField(source="get_shift_display", read_only=True)
    duration_minutes   = serializers.IntegerField(read_only=True)
    recorded_by_name   = serializers.CharField(source="recorded_by.get_full_name", read_only=True, default="")

    class Meta:
        from apps.production.models import ProductionDowntime
        model = ProductionDowntime
        fields = [
            "id", "uuid", "plant", "work_center", "work_center_name",
            "work_order", "job_card", "shift", "shift_display",
            "downtime_start", "downtime_end", "duration_minutes",
            "category", "category_display", "reason_detail",
            "responsible_dept", "capa_required", "capa",
            "recorded_by", "recorded_by_name", "created_at",
        ]
        read_only_fields = ["uuid", "created_at", "recorded_by"]
