"""
Migration: Add shift field and unique_together constraint to MachineLoadingPlan.
Fixes BUG-003: prevents overbooking of machine time per shift.
"""
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('production', '0004_workcenter_deckle_workorder_suggested'),
    ]

    operations = [
        migrations.AddField(
            model_name='machineloadingplan',
            name='shift',
            field=models.CharField(
                choices=[('A', 'Shift A'), ('B', 'Shift B'), ('C', 'Shift C'), ('G', 'General')],
                default='A',
                max_length=5,
            ),
        ),
        migrations.AlterUniqueTogether(
            name='machineloadingplan',
            unique_together={('work_center', 'scheduled_date', 'shift')},
        ),
        migrations.AlterIndexTogether(
            name='machineloadingplan',
            index_together=set(),
        ),
        migrations.AddIndex(
            model_name='machineloadingplan',
            index=models.Index(fields=['work_center', 'scheduled_date', 'shift'], name='production_machload_wc_date_shift_idx'),
        ),
    ]
