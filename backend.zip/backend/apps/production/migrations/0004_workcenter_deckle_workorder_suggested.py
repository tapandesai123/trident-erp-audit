"""
Migration: P2
  - Add min_deckle_mm, max_deckle_mm, machine_type to WorkCenter
  - Add suggested_work_centers JSONField to WorkOrder
"""
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('production', '0003_jobcard_delay_fields'),
    ]

    operations = [
        # WorkCenter deckle range + machine type
        migrations.AddField(
            model_name='workcenter',
            name='min_deckle_mm',
            field=models.DecimalField(blank=True, decimal_places=2, help_text='Minimum paper/box width this machine can handle (mm)', max_digits=10, null=True),
        ),
        migrations.AddField(
            model_name='workcenter',
            name='max_deckle_mm',
            field=models.DecimalField(blank=True, decimal_places=2, help_text='Maximum paper/box width this machine can handle (mm)', max_digits=10, null=True),
        ),
        migrations.AddField(
            model_name='workcenter',
            name='machine_type',
            field=models.CharField(
                blank=True,
                choices=[
                    ('CORRUGATOR', 'Corrugator'),
                    ('SLITTER', 'Slitter / Sheeter'),
                    ('PRINTING', 'Printing Machine'),
                    ('DIE_CUTTING', 'Die Cutting'),
                    ('FOLDING', 'Folding / Gluing'),
                    ('PACKING', 'Packing Line'),
                    ('GENERAL', 'General Purpose'),
                ],
                help_text='Type of operation this machine performs',
                max_length=30,
            ),
        ),
        # WorkOrder suggested work centres
        migrations.AddField(
            model_name='workorder',
            name='suggested_work_centers',
            field=models.JSONField(blank=True, default=list, help_text='Auto-suggested work centres based on box dimensions'),
        ),
    ]
