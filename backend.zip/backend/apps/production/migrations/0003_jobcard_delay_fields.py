from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('production', '0002_initial'),
    ]

    operations = [
        migrations.AddField(
            model_name='jobcard',
            name='is_delayed',
            field=models.BooleanField(default=False, help_text='True if actual_hours > planned_hours * 1.2'),
        ),
        migrations.AddField(
            model_name='jobcard',
            name='delay_notified',
            field=models.BooleanField(default=False, help_text='True if delay notification has been sent'),
        ),
    ]
