"""Production admin registrations."""
from django.contrib import admin
from apps.production.models import (
    ProductionBOMHeader, ProductionBOMLine,
    WorkCenter, WorkOrder, JobCard,
    WOMaterialIssue, WOMaterialIssueLine,
    MachineLoadingPlan, MRPRun, MRPSuggestion,
)


class ProductionBOMLineInline(admin.TabularInline):
    model = ProductionBOMLine
    extra = 0
    fields = ["line_no", "component", "component_type", "qty_per_base", "uom", "scrap_pct", "is_critical"]
    readonly_fields = ["effective_qty"] if False else []


@admin.register(ProductionBOMHeader)
class ProductionBOMHeaderAdmin(admin.ModelAdmin):
    list_display = ["bom_number", "revision", "finished_good", "plant", "status", "effective_from"]
    list_filter = ["status", "plant"]
    search_fields = ["bom_number", "finished_good__item_code"]
    inlines = [ProductionBOMLineInline]
    readonly_fields = ["uuid", "created_at", "updated_at"]


@admin.register(WorkCenter)
class WorkCenterAdmin(admin.ModelAdmin):
    list_display = ["code", "name", "plant", "capacity_per_day", "cost_per_hour", "is_active"]
    list_filter = ["plant", "is_active"]
    search_fields = ["code", "name"]


class JobCardInline(admin.TabularInline):
    model = JobCard
    extra = 0
    fields = ["jc_number", "operation_name", "sequence_no", "work_center", "status", "planned_hours"]
    readonly_fields = ["jc_number"]


@admin.register(WorkOrder)
class WorkOrderAdmin(admin.ModelAdmin):
    list_display = ["wo_number", "finished_good", "plant", "planned_qty", "produced_qty",
                    "status", "planned_start", "planned_end", "priority"]
    list_filter = ["status", "plant", "priority"]
    search_fields = ["wo_number", "finished_good__item_code"]
    readonly_fields = ["uuid", "wo_number", "actual_material_cost", "actual_labour_cost",
                       "actual_overhead_cost", "total_variance", "created_at", "updated_at"]
    inlines = [JobCardInline]

    def total_variance(self, obj):
        return obj.total_variance
    total_variance.short_description = "Total Variance (₹)"


@admin.register(JobCard)
class JobCardAdmin(admin.ModelAdmin):
    list_display = ["jc_number", "operation_name", "work_order", "work_center",
                    "status", "planned_qty", "completed_qty", "actual_hours"]
    list_filter = ["status", "work_center"]
    search_fields = ["jc_number", "work_order__wo_number"]
    readonly_fields = ["uuid", "jc_number", "started_at", "completed_at"]


class WOMaterialIssueLineInline(admin.TabularInline):
    model = WOMaterialIssueLine
    extra = 0
    fields = ["line_no", "item", "planned_qty", "issued_qty", "uom", "unit_cost"]


@admin.register(WOMaterialIssue)
class WOMaterialIssueAdmin(admin.ModelAdmin):
    list_display = ["issue_number", "work_order", "issue_date", "status", "issued_by"]
    list_filter = ["status"]
    search_fields = ["issue_number", "work_order__wo_number"]
    readonly_fields = ["uuid", "issue_number"]
    inlines = [WOMaterialIssueLineInline]


@admin.register(MachineLoadingPlan)
class MachineLoadingPlanAdmin(admin.ModelAdmin):
    list_display = ["work_center", "job_card", "scheduled_date", "start_time", "end_time",
                    "planned_hours", "is_confirmed"]
    list_filter = ["work_center", "scheduled_date", "is_confirmed"]
    date_hierarchy = "scheduled_date"


class MRPSuggestionInline(admin.TabularInline):
    model = MRPSuggestion
    extra = 0
    fields = ["item", "suggestion_type", "required_qty", "shortage_qty", "suggested_qty",
              "required_by", "status"]
    readonly_fields = ["item", "suggestion_type", "required_qty", "shortage_qty"]


@admin.register(MRPRun)
class MRPRunAdmin(admin.ModelAdmin):
    list_display = ["run_number", "run_date", "plant", "status", "horizon_days", "completed_at"]
    list_filter = ["status", "plant"]
    search_fields = ["run_number"]
    readonly_fields = ["uuid", "run_number", "status", "completed_at", "summary", "error_message"]
    inlines = [MRPSuggestionInline]


@admin.register(MRPSuggestion)
class MRPSuggestionAdmin(admin.ModelAdmin):
    list_display = ["mrp_run", "item", "suggestion_type", "shortage_qty", "suggested_qty",
                    "required_by", "status"]
    list_filter = ["suggestion_type", "status"]
    search_fields = ["item__item_code", "mrp_run__run_number"]
    readonly_fields = ["uuid"]
