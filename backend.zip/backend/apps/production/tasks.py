"""Production Celery tasks."""
from celery import shared_task
from django.utils import timezone


@shared_task(bind=True, max_retries=3, default_retry_delay=60)
def run_mrp_task(self, plant_id: int, horizon_days: int = 30, user_id: int = None):
    """Async MRP execution for a plant."""
    try:
        from apps.core.models import Plant
        from apps.production.services import run_mrp
        plant = Plant.objects.get(pk=plant_id)
        user = None
        if user_id:
            from django.contrib.auth import get_user_model
            User = get_user_model()
            user = User.objects.filter(pk=user_id).first()
        mrp_run = run_mrp(plant, horizon_days, user)
        return {"mrp_run_id": mrp_run.pk, "run_number": mrp_run.run_number, "status": mrp_run.status}
    except Exception as exc:
        raise self.retry(exc=exc)


@shared_task
def auto_close_completed_work_orders():
    """
    Periodic task: auto-close WOs that have been in COMPLETED status for > 2 days.
    Schedule: daily via Celery Beat.
    """
    from datetime import date, timedelta
    from apps.production.models import WorkOrder
    from apps.production.services import close_work_order

    cutoff = date.today() - timedelta(days=2)
    wos = WorkOrder.objects.filter(status="COMPLETED", actual_end__lte=cutoff)
    closed_count = 0
    for wo in wos:
        try:
            close_work_order(wo, user=None)
            closed_count += 1
        except Exception:
            pass
    return {"auto_closed": closed_count}


@shared_task
def send_overdue_wo_alerts():
    """Notify planners of overdue work orders (planned_end < today, not closed)."""
    from datetime import date
    from apps.production.models import WorkOrder
    from apps.core.models import Notification

    today = date.today()
    overdue = WorkOrder.objects.filter(
        planned_end__lt=today,
        status__in=("RELEASED", "IN_PROGRESS"),
    ).select_related("created_by", "finished_good")

    for wo in overdue:
        if wo.created_by:
            Notification.objects.get_or_create(
                user=wo.created_by,
                module="production",
                resource="WorkOrder",
                resource_id=wo.pk,
                title=f"Overdue WO: {wo.wo_number}",
                defaults={
                    "message": f"WO {wo.wo_number} for {wo.finished_good.item_code} "
                               f"was due {wo.planned_end}.",
                    "notification_type": "IN_APP",
                },
            )
    return {"overdue_count": overdue.count()}


@shared_task
def recalculate_std_costs(plant_id: int):
    """Recalculate standard material cost for all DRAFT WOs in a plant."""
    from apps.core.models import Plant
    from apps.production.models import WorkOrder
    from apps.production.services import explode_bom, consolidate_explosion
    from decimal import Decimal

    plant = Plant.objects.get(pk=plant_id)
    updated = 0
    for wo in WorkOrder.objects.filter(plant=plant, status="DRAFT", bom__isnull=False):
        try:
            exploded = consolidate_explosion(explode_bom(wo.bom, wo.planned_qty))
            cost = sum(
                row["qty"] * (getattr(row["item"], "std_cost", Decimal("0")) or Decimal("0"))
                for row in exploded
            )
            wo.std_material_cost = round(cost, 2)
            wo.save(update_fields=["std_material_cost"])
            updated += 1
        except Exception:
            pass
    return {"updated_wos": updated}


@shared_task
def check_production_delays():
    """
    Periodic task (F4): Flag JobCards where actual_hours > planned_hours * 1.2
    and send notifications to work order creators.
    Schedule: every hour via Celery Beat.
    """
    from apps.production.models import JobCard
    from apps.core.models import Notification

    delayed_cards = JobCard.objects.filter(
        status="IN_PROGRESS",
        delay_notified=False,
    ).select_related("work_order__created_by", "work_order__finished_good")

    from decimal import Decimal
    notified_count = 0
    for jc in delayed_cards:
        if jc.planned_hours and jc.actual_hours > jc.planned_hours * Decimal('1.2'):
            jc.is_delayed = True
            jc.delay_notified = True
            jc.save(update_fields=["is_delayed", "delay_notified"])

            if jc.work_order.created_by:
                Notification.objects.get_or_create(
                    user=jc.work_order.created_by,
                    module="production",
                    resource="JobCard",
                    resource_id=jc.pk,
                    title=f"Delay Alert: {jc.jc_number}",
                    defaults={
                        "message": (
                            f"Job Card {jc.jc_number} ({jc.operation_name}) is delayed. "
                            f"Actual hours: {jc.actual_hours}, Planned: {jc.planned_hours}."
                        ),
                        "notification_type": "IN_APP",
                    },
                )
            notified_count += 1

    return {"delayed_cards_flagged": notified_count}


@shared_task(bind=True, max_retries=3)
def check_material_availability_for_so(self):
    """
    Runs daily at 7:30 AM.
    For each CONFIRMED SalesOrder that hasn't been notified yet:
      1. Get finished good Items from SOLines
      2. Explode BOM to get all required RM components and quantities
      3. Check available QC-passed stock in stores
      4. If all materials available, mark SO as material_ready and notify staff
    """
    from django.utils import timezone
    from django.db.models import Sum
    from decimal import Decimal
    from apps.sales.models import SalesOrder
    from apps.stores.models import InventoryLot
    from apps.core.models import Notification
    from django.contrib.auth import get_user_model
    User = get_user_model()

    pending_sos = SalesOrder.objects.filter(
        status="CONFIRMED",
        material_ready=False,
        material_ready_notified=False,
    ).prefetch_related("lines__item", "lines__item__prod_bom_lines__component")

    notified_count = 0

    for so in pending_sos:
        all_materials_available = True
        has_bom = False

        for so_line in so.lines.all():
            item = so_line.item
            if not item:
                continue

            try:
                from apps.production.models import ProductionBOMHeader
                bom = ProductionBOMHeader.objects.filter(
                    finished_good=item,
                    plant=so.plant,
                    status="ACTIVE",
                ).prefetch_related("lines__component").first()
            except Exception:
                continue

            if not bom:
                continue

            has_bom = True

            for bom_line in bom.lines.all():
                required_qty = bom_line.qty_per_base * so_line.quantity
                available = InventoryLot.objects.filter(
                    item=bom_line.component,
                    plant=so.plant,
                    qc_status="PASSED",
                    status__in=("AVAILABLE", "RESERVED"),
                    current_qty__gt=0,
                ).aggregate(total=Sum("current_qty"))["total"] or Decimal("0")

                if available < required_qty:
                    all_materials_available = False
                    break

            if not all_materials_available:
                break

        if all_materials_available and has_bom:
            so.material_ready = True
            so.material_ready_notified = True
            so.material_ready_at = timezone.now()
            so.save(update_fields=["material_ready", "material_ready_notified", "material_ready_at"])

            # Notify all staff users at this plant
            try:
                staff_users = User.objects.filter(is_staff=True)
                for user in staff_users:
                    try:
                        Notification.objects.create(
                            user=user,
                            title=f"Material Ready: {so.so_number}",
                            message=(
                                f"All raw materials are now available for Sales Order "
                                f"{so.so_number} ({so.customer.name}). "
                                f"Work Order and Job Cards can now be created."
                            ),
                            notification_type="IN_APP",
                            module="production",
                            resource="sales_order",
                        )
                    except Exception:
                        pass
            except Exception:
                pass

            notified_count += 1

    return f"Checked {pending_sos.count()} SOs. Notified production for {notified_count} orders."
