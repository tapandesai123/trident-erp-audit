from django.apps import AppConfig


class ProductionConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.production"
    verbose_name = "Production & WIP"

    def ready(self):
        pass  # Signal handlers can be imported here if needed
