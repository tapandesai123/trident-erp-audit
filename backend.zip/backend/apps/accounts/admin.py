"""Accounts Module Admin — Section 6"""
from django.contrib import admin
from apps.accounts.models import (
    AccountGroup, LedgerAccount, CostCenter,
    Voucher, VoucherLine,
    VendorBill, BillPayment,
    BillReceipt, ReceiptAllocation,
    TDSEntry, GSTLedger,
    BankStatement, BankReconciliation,
    OutstandingFollowup,
)


@admin.register(AccountGroup)
class AccountGroupAdmin(admin.ModelAdmin):
    list_display = ["code", "name", "group_type", "parent", "plant", "is_system"]
    list_filter  = ["group_type", "plant", "is_system"]
    search_fields = ["code", "name"]


@admin.register(LedgerAccount)
class LedgerAccountAdmin(admin.ModelAdmin):
    list_display  = ["code", "name", "sub_type", "group", "current_balance", "balance_type", "is_active"]
    list_filter   = ["sub_type", "is_active", "plant", "group__group_type"]
    search_fields = ["code", "name", "account_number"]


@admin.register(CostCenter)
class CostCenterAdmin(admin.ModelAdmin):
    list_display = ["code", "name", "head", "is_active", "plant"]
    list_filter  = ["is_active", "plant"]


class VoucherLineInline(admin.TabularInline):
    model  = VoucherLine
    extra  = 0
    fields = ["line_no", "ledger", "cost_center", "debit_amount", "credit_amount", "narration"]


@admin.register(Voucher)
class VoucherAdmin(admin.ModelAdmin):
    list_display  = ["voucher_number", "voucher_date", "voucher_type", "status", "total_debit", "narration", "plant"]
    list_filter   = ["voucher_type", "status", "plant"]
    search_fields = ["voucher_number", "narration", "reference_number"]
    inlines       = [VoucherLineInline]
    readonly_fields = ["voucher_number", "posted_at"]


@admin.register(VendorBill)
class VendorBillAdmin(admin.ModelAdmin):
    list_display  = [
        "bill_number", "vendor_bill_ref", "vendor", "status",
        "total_amount", "net_payable", "outstanding", "checklist_score", "plant"
    ]
    list_filter   = ["status", "plant"]
    search_fields = ["bill_number", "vendor_bill_ref", "vendor__name"]
    readonly_fields = ["bill_number", "passed_at", "checklist_score"]

    fieldsets = (
        ("Bill Details", {
            "fields": ("plant", "bill_number", "vendor_bill_ref", "vendor_bill_date",
                       "received_date", "vendor", "mrr", "status", "due_date")
        }),
        ("Amounts", {
            "fields": ("taxable_amount", "cgst_amount", "sgst_amount", "igst_amount",
                       "tds_rate", "tds_section", "tds_amount", "total_amount", "net_payable",
                       "amount_paid", "outstanding")
        }),
        ("8-Point Checklist", {
            "fields": (
                "chk_pr_authorised", "chk_po_approved", "chk_gate_entry_done",
                "chk_mrr_qty_match", "chk_qc_passed", "chk_gst_copy_received",
                "chk_accounts_paper_ok", "chk_calculation_verified",
                "checklist_remarks", "hold_reason"
            )
        }),
        ("Approval", {
            "fields": ("voucher", "passed_by", "passed_at", "received_by")
        }),
    )


@admin.register(BillPayment)
class BillPaymentAdmin(admin.ModelAdmin):
    list_display  = ["payment_number", "vendor", "payment_date", "payment_mode", "gross_amount",
                     "tds_amount", "net_amount", "status"]
    list_filter   = ["status", "payment_mode", "plant"]
    search_fields = ["payment_number", "vendor__name", "utr_number", "cheque_number"]
    readonly_fields = ["payment_number"]


class ReceiptAllocationInline(admin.TabularInline):
    model  = ReceiptAllocation
    extra  = 0
    fields = ["invoice", "allocated_amount"]


@admin.register(BillReceipt)
class BillReceiptAdmin(admin.ModelAdmin):
    list_display  = ["receipt_number", "customer", "receipt_date", "receipt_mode",
                     "gross_amount", "net_amount", "status"]
    list_filter   = ["status", "receipt_mode", "plant"]
    search_fields = ["receipt_number", "customer__name", "utr_number", "cheque_number"]
    inlines       = [ReceiptAllocationInline]
    readonly_fields = ["receipt_number"]


@admin.register(TDSEntry)
class TDSEntryAdmin(admin.ModelAdmin):
    list_display  = ["vendor_name", "tds_section", "tds_rate", "gross_payment", "tds_amount",
                     "payment_date", "is_deposited", "quarter", "financial_year"]
    list_filter   = ["tds_section", "is_deposited", "quarter", "financial_year", "plant"]
    search_fields = ["vendor_name", "vendor_pan", "challan_number"]


@admin.register(GSTLedger)
class GSTLedgerAdmin(admin.ModelAdmin):
    list_display  = ["entry_type", "gst_type", "amount", "taxable_amount", "entry_date",
                     "return_period", "is_filed", "plant"]
    list_filter   = ["entry_type", "gst_type", "is_filed", "plant"]
    search_fields = ["party_gstin", "hsn_code"]


class BankReconciliationInline(admin.TabularInline):
    model  = BankReconciliation
    extra  = 0
    fields = ["transaction_date", "description", "debit_amount", "credit_amount",
              "balance", "match_status", "matched_voucher"]


@admin.register(BankStatement)
class BankStatementAdmin(admin.ModelAdmin):
    list_display  = ["bank_account", "statement_month", "opening_balance", "closing_balance",
                     "is_reconciled", "uploaded_by"]
    list_filter   = ["is_reconciled", "plant"]
    inlines       = [BankReconciliationInline]


@admin.register(OutstandingFollowup)
class OutstandingFollowupAdmin(admin.ModelAdmin):
    list_display  = ["customer", "invoice", "outstanding_amount", "bucket", "action",
                     "action_date", "done_by", "promised_date", "is_resolved"]
    list_filter   = ["action", "bucket", "is_resolved", "plant"]
    search_fields = ["customer__name"]
