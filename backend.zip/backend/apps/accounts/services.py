"""
Accounts Module Services — Section 6
All business logic lives here — no logic in viewsets.

Services:
  - pass_vendor_bill()          — 8-point checklist validation + voucher creation
  - pay_vendor()                — payment with auto TDS deduction
  - receive_customer_payment()  — receipt with invoice knock-off + TCS
  - calculate_tds()             — TDS amount from section + threshold
  - post_voucher()              — double-entry posting + ledger balance update
  - get_gst_data_for_gstr1()   — sales data formatted for GSTR-1
  - get_gst_data_for_gstr3b()  — summary data for GSTR-3B
  - get_outstanding_debtors()   — ageing with followup status
  - get_creditor_outstanding()  — vendor payables ageing
  - send_overdue_reminders()    — Celery: auto-email overdue debtors
  - reconcile_bank_line()       — match bank statement line to voucher
"""
from decimal import Decimal, ROUND_HALF_UP
from datetime import date, timedelta
from django.db import transaction
from django.db.models import Sum, Q, F
from django.utils import timezone
from django.core.mail import send_mail
from django.conf import settings as django_settings

from apps.core.models import AuditLog, DocSequence, Notification
from apps.accounts.models import (
    AccountGroup, LedgerAccount, CostCenter,
    Voucher, VoucherLine,
    VendorBill, BillPayment,
    BillReceipt, ReceiptAllocation,
    TDSEntry, GSTLedger,
    BankStatement, BankReconciliation,
    OutstandingFollowup,
)


# ═══════════════════════════════════════════════════════════════════
# HELPERS
# ═══════════════════════════════════════════════════════════════════

def _log(user, action, resource, resource_id, details=None):
    # BUG-021 fix: resource_id must be int (IntegerField); use new_values= not details=
    AuditLog.objects.create(
        user=user, action=action, module="accounts",
        resource=resource, resource_id=int(resource_id),
        new_values=details or {},
    )


def _two(val):
    """Round to 2 decimal places."""
    return Decimal(val).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def get_next_doc_number(plant, doc_type: str, prefix: str) -> str:
    """
    Thread-safe sequential document numbering.
    Format: PREFIX/YYYY-YY/00001  (financial year = April start)
    """
    today = date.today()
    fy_start = today.year if today.month >= 4 else today.year - 1
    fy_label = f"{fy_start}-{str(fy_start + 1)[2:]}"  # "2025-26"

    seq, _ = DocSequence.objects.select_for_update().get_or_create(
        plant=plant, doc_type=doc_type,
        defaults={"last_number": 0, "financial_year": fy_label},
    )
    # Reset if new financial year
    if seq.financial_year != fy_label:
        seq.financial_year = fy_label
        seq.last_number = 0

    seq.last_number += 1
    seq.save(update_fields=["last_number", "financial_year"])
    return f"{prefix}/{fy_label}/{seq.last_number:05d}"


def _get_system_ledger(plant, sub_type: str) -> LedgerAccount:
    """Fetch a system ledger by sub_type. Raises ValueError if not found."""
    try:
        return LedgerAccount.objects.get(plant=plant, sub_type=sub_type, is_system=True)
    except LedgerAccount.DoesNotExist:
        raise ValueError(
            f"System ledger '{sub_type}' not configured for plant {plant.code}. "
            "Please run the seed data command."
        )
    except LedgerAccount.MultipleObjectsReturned:
        return LedgerAccount.objects.filter(plant=plant, sub_type=sub_type, is_system=True).first()


def _get_vendor_ledger(plant, vendor) -> LedgerAccount:
    """Get or create a sundry creditor ledger for this vendor."""
    name = f"Sundry Creditor — {vendor.name}"
    try:
        group = AccountGroup.objects.get(plant=plant, code="SC")
    except AccountGroup.DoesNotExist:
        # Fallback: use any LIABILITIES group
        group = AccountGroup.objects.filter(plant=plant, group_type="LIABILITIES").first()
        if not group:
            raise ValueError("No LIABILITIES account group found. Run seed data.")

    ledger, _ = LedgerAccount.objects.get_or_create(
        plant=plant,
        code=f"SC-{vendor.pk}",
        defaults={
            "group": group,
            "name": name,
            "sub_type": LedgerAccount.AccountSubType.CREDITOR,
        },
    )
    return ledger


def _get_customer_ledger(plant, customer) -> LedgerAccount:
    """Get or create a sundry debtor ledger for this customer."""
    name = f"Sundry Debtor — {customer.name}"
    try:
        group = AccountGroup.objects.get(plant=plant, code="SD")
    except AccountGroup.DoesNotExist:
        group = AccountGroup.objects.filter(plant=plant, group_type="ASSETS").first()
        if not group:
            raise ValueError("No ASSETS account group found. Run seed data.")

    ledger, _ = LedgerAccount.objects.get_or_create(
        plant=plant,
        code=f"SD-{customer.pk}",
        defaults={
            "group": group,
            "name": name,
            "sub_type": LedgerAccount.AccountSubType.DEBTOR,
        },
    )
    return ledger


def _determine_quarter(d: date) -> str:
    """Return Q1/Q2/Q3/Q4 for 26Q filing (Apr-Jun=Q1, Jul-Sep=Q2, Oct-Dec=Q3, Jan-Mar=Q4)."""
    m = d.month
    if m in (4, 5, 6):
        return "Q1"
    if m in (7, 8, 9):
        return "Q2"
    if m in (10, 11, 12):
        return "Q3"
    return "Q4"


def _financial_year(d: date) -> str:
    if d.month >= 4:
        return f"{d.year}-{str(d.year + 1)[2:]}"
    return f"{d.year - 1}-{str(d.year)[2:]}"


def _return_period(d: date) -> str:
    """MMYYYY format for GST return period."""
    return d.strftime("%m%Y")


# ═══════════════════════════════════════════════════════════════════
# VOUCHER POSTING
# ═══════════════════════════════════════════════════════════════════

@transaction.atomic
def post_voucher(voucher: Voucher, user) -> Voucher:
    """
    Post a voucher:
    1. Validate debit = credit
    2. Update LedgerAccount.current_balance for each line
    3. Mark voucher as POSTED
    """
    if voucher.status == Voucher.VoucherStatus.POSTED:
        raise ValueError("Voucher is already posted.")
    if voucher.status == Voucher.VoucherStatus.CANCELLED:
        raise ValueError("Cannot post a cancelled voucher.")

    lines = list(voucher.lines.all())
    if not lines:
        raise ValueError("Voucher has no lines.")

    total_dr = sum(l.debit_amount for l in lines)
    total_cr = sum(l.credit_amount for l in lines)

    if _two(total_dr) != _two(total_cr):
        raise ValueError(
            f"Voucher not balanced: Debit ₹{total_dr} ≠ Credit ₹{total_cr}."
        )

    # Update ledger balances
    for line in lines:
        ledger = LedgerAccount.objects.select_for_update().get(pk=line.ledger_id)
        # Assets/Expenses: Dr increases, Cr decreases
        # Liabilities/Income/Equity: Cr increases, Dr decreases
        debit_increases = ledger.group.group_type in ("ASSETS", "EXPENSE")
        if debit_increases:
            delta = line.debit_amount - line.credit_amount
        else:
            delta = line.credit_amount - line.debit_amount
        ledger.current_balance = _two(ledger.current_balance + delta)
        ledger.save(update_fields=["current_balance"])

    voucher.total_debit = _two(total_dr)
    voucher.total_credit = _two(total_cr)
    voucher.status = Voucher.VoucherStatus.POSTED
    voucher.posted_at = timezone.now()
    voucher.save(update_fields=["total_debit", "total_credit", "status", "posted_at"])

    _log(user, "APPROVE", "Voucher", voucher.pk, {"number": voucher.voucher_number})
    return voucher


@transaction.atomic
def cancel_voucher(voucher: Voucher, reason: str, user) -> Voucher:
    """Cancel a voucher and reverse ledger balances if already posted."""
    if voucher.status == Voucher.VoucherStatus.CANCELLED:
        raise ValueError("Voucher already cancelled.")

    if voucher.status == Voucher.VoucherStatus.POSTED:
        # Reverse ledger balances
        for line in voucher.lines.all():
            ledger = LedgerAccount.objects.select_for_update().get(pk=line.ledger_id)
            debit_increases = ledger.group.group_type in ("ASSETS", "EXPENSE")
            if debit_increases:
                delta = line.debit_amount - line.credit_amount
            else:
                delta = line.credit_amount - line.debit_amount
            ledger.current_balance = _two(ledger.current_balance - delta)
            ledger.save(update_fields=["current_balance"])

    voucher.status = Voucher.VoucherStatus.CANCELLED
    voucher.cancellation_reason = reason
    voucher.save(update_fields=["status", "cancellation_reason"])
    _log(user, "DELETE", "Voucher", voucher.pk, {"reason": reason})
    return voucher


# ═══════════════════════════════════════════════════════════════════
# TDS CALCULATION
# ═══════════════════════════════════════════════════════════════════

def calculate_tds(gross_amount: Decimal, tds_rate: Decimal, tds_section: str) -> dict:
    """
    Calculate TDS.
    Thresholds:
      194C: ₹30,000 single / ₹1,00,000 aggregate
      194J: ₹30,000 per year
      194I: ₹2,40,000 per year
    This function calculates based on rate — threshold check must be done in caller.
    Returns dict: {tds_amount, net_amount}
    """
    gross_amount = Decimal(gross_amount)
    tds_rate = Decimal(tds_rate)
    if tds_rate <= 0:
        return {"tds_amount": Decimal("0"), "net_amount": gross_amount}
    tds = _two(gross_amount * tds_rate / 100)
    net = _two(gross_amount - tds)
    return {"tds_amount": tds, "net_amount": net, "section": tds_section, "rate": tds_rate}


# ═══════════════════════════════════════════════════════════════════
# VENDOR BILL PASSING
# ═══════════════════════════════════════════════════════════════════

@transaction.atomic
def receive_vendor_bill(data: dict, user, plant) -> VendorBill:
    """
    Record receipt of a vendor invoice. Initial status = RECEIVED.
    Auto-populates checklist from MRR status.
    """
    from apps.purchase.models import MRR

    bill_number = get_next_doc_number(plant, "VBILL", "VBILL")

    mrr = None
    if data.get("mrr_id"):
        mrr = MRR.objects.get(pk=data["mrr_id"])

    # Auto-check checklist based on MRR/PO status
    chk_pr  = False
    chk_po  = False
    chk_ge  = False
    chk_mrr = False
    chk_qc  = False

    if mrr:
        po = mrr.po
        chk_po = po.status in ("APPROVED", "CLOSED")
        chk_ge = mrr.gate_entry is not None if hasattr(mrr, "gate_entry") else False
        chk_mrr = True  # MRR exists means goods received
        # QC: check no rejected lots from this MRR
        from apps.stores.models import InventoryLot
        rejected = InventoryLot.objects.filter(
            mrr=mrr, qc_status="REJECTED"
        ).exists()
        chk_qc = not rejected
        # PR check
        if hasattr(po, "pr") and po.pr:
            chk_pr = po.pr.status in ("DIRECTOR_APPROVED", "PO_CREATED")

    bill = VendorBill.objects.create(
        plant=plant,
        bill_number=bill_number,
        vendor_bill_ref=data["vendor_bill_ref"],
        vendor_bill_date=data["vendor_bill_date"],
        received_date=data.get("received_date", date.today()),
        vendor_id=data["vendor_id"],
        mrr=mrr,
        taxable_amount=data.get("taxable_amount", 0),
        cgst_amount=data.get("cgst_amount", 0),
        sgst_amount=data.get("sgst_amount", 0),
        igst_amount=data.get("igst_amount", 0),
        total_amount=data["total_amount"],
        due_date=data.get("due_date"),
        chk_pr_authorised=chk_pr,
        chk_po_approved=chk_po,
        chk_gate_entry_done=chk_ge,
        chk_mrr_qty_match=chk_mrr,
        chk_qc_passed=chk_qc,
        received_by=user,
    )
    _log(user, "CREATE", "VendorBill", bill.pk, {"number": bill_number})
    return bill


@transaction.atomic
def update_bill_checklist(bill: VendorBill, checklist_data: dict, user) -> VendorBill:
    """
    Update checklist items and auto-calculate TDS.
    Called by accounts clerk as they verify each point.
    """
    checklist_fields = [
        "chk_pr_authorised", "chk_po_approved", "chk_gate_entry_done",
        "chk_mrr_qty_match", "chk_qc_passed", "chk_gst_copy_received",
        "chk_accounts_paper_ok", "chk_calculation_verified",
    ]
    for field in checklist_fields:
        if field in checklist_data:
            setattr(bill, field, checklist_data[field])

    if "checklist_remarks" in checklist_data:
        bill.checklist_remarks = checklist_data["checklist_remarks"]

    bill.status = VendorBill.BillStatus.UNDER_CHECK
    bill.save()
    _log(user, "UPDATED", "VendorBill", bill.pk, {"checklist": checklist_data})
    return bill


@transaction.atomic
def pass_vendor_bill(bill: VendorBill, user, plant) -> VendorBill:
    """
    Pass a vendor bill after 8-point checklist complete.
    Creates Purchase Voucher (double-entry):
      Dr: Purchase/Expense account (taxable)
      Dr: CGST Receivable (if applicable)
      Dr: SGST Receivable (if applicable)
      Dr: IGST Receivable (if applicable)
      Cr: Sundry Creditor (vendor ledger)  = net_payable
      Cr: TDS Payable (if TDS applicable)
    """
    if bill.status == VendorBill.BillStatus.PASSED:
        raise ValueError("Bill already passed.")
    if bill.status == VendorBill.BillStatus.PAID:
        raise ValueError("Bill already paid.")
    if not bill.checklist_complete:
        missing = []
        if not bill.chk_pr_authorised:      missing.append("PR authorised")
        if not bill.chk_po_approved:        missing.append("PO approved")
        if not bill.chk_gate_entry_done:    missing.append("Gate entry done")
        if not bill.chk_mrr_qty_match:      missing.append("MRR qty match")
        if not bill.chk_qc_passed:          missing.append("QC passed")
        if not bill.chk_gst_copy_received:  missing.append("GST transporter copy received")
        if not bill.chk_accounts_paper_ok:  missing.append("Accounts paper seen OK")
        if not bill.chk_calculation_verified: missing.append("Calculation verified")
        raise ValueError(f"Bill checklist incomplete. Missing: {', '.join(missing)}")

    vendor = bill.vendor

    # Calculate TDS if applicable
    tds_rate = vendor.tds_rate if hasattr(vendor, "tds_rate") else Decimal("0")
    tds_section = vendor.tds_section if hasattr(vendor, "tds_section") else ""
    tds_calc = calculate_tds(bill.taxable_amount, tds_rate, tds_section)
    tds_amount = tds_calc["tds_amount"]
    net_payable = _two(bill.total_amount - tds_amount)

    bill.tds_rate = tds_rate
    bill.tds_section = tds_section
    bill.tds_amount = tds_amount
    bill.net_payable = net_payable
    bill.outstanding = net_payable
    bill.save(update_fields=["tds_rate", "tds_section", "tds_amount", "net_payable", "outstanding"])

    # Create Purchase Voucher
    voucher_number = get_next_doc_number(plant, "PV", "PV")
    voucher = Voucher.objects.create(
        plant=plant,
        voucher_number=voucher_number,
        voucher_date=date.today(),
        voucher_type=Voucher.VoucherType.PURCHASE,
        status=Voucher.VoucherStatus.APPROVED,
        narration=f"Purchase bill {bill.vendor_bill_ref} — {vendor.name}",
        reference_number=bill.vendor_bill_ref,
        reference_date=bill.vendor_bill_date,
        vendor=vendor,
        mrr=bill.mrr,
        is_gst_entry=True,
        gst_return_period=_return_period(date.today()),
        prepared_by=user,
        approved_by=user,
        approved_at=timezone.now(),
    )

    lines = []
    line_no = 1

    # Dr: Purchase Account
    purchase_ledger = LedgerAccount.objects.filter(
        plant=plant, name__icontains="purchase"
    ).first()
    if not purchase_ledger:
        purchase_ledger = LedgerAccount.objects.filter(
            plant=plant, group__group_type="EXPENSE"
        ).first()
    if not purchase_ledger:
        raise ValueError("No Purchase/Expense ledger found. Please configure chart of accounts.")

    VoucherLine.objects.create(
        voucher=voucher, line_no=line_no, ledger=purchase_ledger,
        debit_amount=bill.taxable_amount, credit_amount=0,
        narration=f"Purchase — {vendor.name}",
    )
    line_no += 1

    # Dr: GST Input Tax Credit
    # BUG-037 fix: raise ValueError if GST ledgers not found — silent skip loses ITC permanently
    if bill.cgst_amount > 0:
        cgst_itc = LedgerAccount.objects.filter(
            plant=plant, name__icontains="CGST", sub_type="GST_RECEIVABLE"
        ).first()
        if not cgst_itc:
            raise ValueError(
                f"CGST Input Tax Credit ledger not configured for plant {plant.code}. "
                "Please set up a GST_RECEIVABLE ledger with 'CGST' in its name before passing bills."
            )
        VoucherLine.objects.create(
            voucher=voucher, line_no=line_no, ledger=cgst_itc,
            debit_amount=bill.cgst_amount, credit_amount=0,
            cgst_amount=bill.cgst_amount,
            narration="CGST Input",
        )
        line_no += 1

    if bill.sgst_amount > 0:
        sgst_itc = LedgerAccount.objects.filter(
            plant=plant, name__icontains="SGST", sub_type="GST_RECEIVABLE"
        ).first()
        if not sgst_itc:
            raise ValueError(
                f"SGST Input Tax Credit ledger not configured for plant {plant.code}. "
                "Please set up a GST_RECEIVABLE ledger with 'SGST' in its name before passing bills."
            )
        VoucherLine.objects.create(
            voucher=voucher, line_no=line_no, ledger=sgst_itc,
            debit_amount=bill.sgst_amount, credit_amount=0,
            sgst_amount=bill.sgst_amount,
            narration="SGST Input",
        )
        line_no += 1

    if bill.igst_amount > 0:
        igst_itc = LedgerAccount.objects.filter(
            plant=plant, name__icontains="IGST", sub_type="GST_RECEIVABLE"
        ).first()
        if not igst_itc:
            raise ValueError(
                f"IGST Input Tax Credit ledger not configured for plant {plant.code}. "
                "Please set up a GST_RECEIVABLE ledger with 'IGST' in its name before passing bills."
            )
        VoucherLine.objects.create(
            voucher=voucher, line_no=line_no, ledger=igst_itc,
            debit_amount=bill.igst_amount, credit_amount=0,
            igst_amount=bill.igst_amount,
            narration="IGST Input",
        )
        line_no += 1

    # Cr: TDS Payable (if applicable)
    if tds_amount > 0:
        tds_ledger = LedgerAccount.objects.filter(
            plant=plant, sub_type="TDS_PAYABLE"
        ).first()
        if tds_ledger:
            VoucherLine.objects.create(
                voucher=voucher, line_no=line_no, ledger=tds_ledger,
                debit_amount=0, credit_amount=tds_amount,
                narration=f"TDS u/s {tds_section} @ {tds_rate}%",
            )
            line_no += 1

    # Cr: Sundry Creditor (vendor)
    vendor_ledger = _get_vendor_ledger(plant, vendor)
    VoucherLine.objects.create(
        voucher=voucher, line_no=line_no, ledger=vendor_ledger,
        debit_amount=0, credit_amount=net_payable,
        narration=f"Payable to {vendor.name}",
    )

    # Post voucher
    post_voucher(voucher, user)

    # Create GST Ledger entries
    if bill.cgst_amount > 0:
        GSTLedger.objects.create(
            plant=plant, voucher=voucher, entry_type="INPUT", gst_type="CGST",
            amount=bill.cgst_amount, entry_date=date.today(),
            taxable_amount=bill.taxable_amount, return_period=_return_period(date.today()),
            vendor=vendor, party_gstin=vendor.gstin,
        )
    if bill.sgst_amount > 0:
        GSTLedger.objects.create(
            plant=plant, voucher=voucher, entry_type="INPUT", gst_type="SGST",
            amount=bill.sgst_amount, entry_date=date.today(),
            taxable_amount=bill.taxable_amount, return_period=_return_period(date.today()),
            vendor=vendor, party_gstin=vendor.gstin,
        )
    if bill.igst_amount > 0:
        GSTLedger.objects.create(
            plant=plant, voucher=voucher, entry_type="INPUT", gst_type="IGST",
            amount=bill.igst_amount, entry_date=date.today(),
            taxable_amount=bill.taxable_amount, return_period=_return_period(date.today()),
            vendor=vendor, party_gstin=vendor.gstin,
        )

    # Update bill status
    bill.voucher = voucher
    bill.status = VendorBill.BillStatus.PASSED
    bill.passed_by = user
    bill.passed_at = timezone.now()
    bill.save(update_fields=["voucher", "status", "passed_by", "passed_at"])

    _log(user, "APPROVE", "VendorBill", bill.pk, {
        "voucher": voucher_number,
        "tds_amount": str(tds_amount),
        "net_payable": str(net_payable),
    })

    # Notify vendor's accounts contact
    Notification.objects.create(
        user=user,
        title=f"Bill Passed: {bill.vendor_bill_ref}",
        message=f"Vendor bill {bill.vendor_bill_ref} from {vendor.name} has been passed. Net payable: ₹{net_payable}",
        module="accounts",
        object_id=str(bill.pk),
    )

    return bill


# ═══════════════════════════════════════════════════════════════════
# VENDOR PAYMENT
# ═══════════════════════════════════════════════════════════════════

@transaction.atomic
def pay_vendor(data: dict, user, plant) -> BillPayment:
    """
    Create vendor payment.
    - Bill must be in PASSED status
    - Auto-deducts TDS from vendor master
    - Creates Bank Payment voucher
    - Creates TDSEntry record
    """
    bill = VendorBill.objects.get(pk=data["vendor_bill_id"])

    if bill.status not in (VendorBill.BillStatus.PASSED, VendorBill.BillStatus.PARTIALLY_PAID):
        raise ValueError(f"Bill must be in PASSED status. Current status: {bill.status}")

    if bill.outstanding <= 0:
        raise ValueError("No outstanding amount on this bill.")

    gross_amount = _two(data["gross_amount"])

    if gross_amount > bill.outstanding + Decimal("0.01"):
        raise ValueError(
            f"Payment ₹{gross_amount} exceeds outstanding ₹{bill.outstanding}."
        )

    vendor = bill.vendor
    tds_rate = bill.tds_rate or Decimal("0")
    tds_section = bill.tds_section or ""
    tds_calc = calculate_tds(gross_amount, tds_rate, tds_section)
    tds_amount = tds_calc["tds_amount"]
    net_amount = tds_calc["net_amount"]

    payment_number = get_next_doc_number(plant, "VP", "VP")
    bank_account_id = data["bank_account_id"]
    bank_account = LedgerAccount.objects.get(pk=bank_account_id)

    payment = BillPayment.objects.create(
        plant=plant,
        payment_number=payment_number,
        payment_date=data.get("payment_date", date.today()),
        status=BillPayment.PaymentStatus.APPROVED,
        payment_mode=data["payment_mode"],
        vendor=vendor,
        vendor_bill=bill,
        bank_account=bank_account,
        cheque_number=data.get("cheque_number", ""),
        cheque_date=data.get("cheque_date"),
        utr_number=data.get("utr_number", ""),
        gross_amount=gross_amount,
        tds_section=tds_section,
        tds_rate=tds_rate,
        tds_amount=tds_amount,
        net_amount=net_amount,
        prepared_by=user,
        approved_by=user,
        approved_at=timezone.now(),
        remarks=data.get("remarks", ""),
    )

    # Create Bank Payment Voucher
    voucher_type = (
        Voucher.VoucherType.CASH_PAYMENT
        if data["payment_mode"] == "CASH"
        else Voucher.VoucherType.BANK_PAYMENT
    )
    voucher_number = get_next_doc_number(plant, "BP", "BP")
    voucher = Voucher.objects.create(
        plant=plant,
        voucher_number=voucher_number,
        voucher_date=payment.payment_date,
        voucher_type=voucher_type,
        status=Voucher.VoucherStatus.APPROVED,
        narration=f"Payment to {vendor.name} — Bill {bill.vendor_bill_ref}",
        reference_number=data.get("utr_number") or data.get("cheque_number", ""),
        vendor=vendor,
        prepared_by=user,
        approved_by=user,
        approved_at=timezone.now(),
    )

    vendor_ledger = _get_vendor_ledger(plant, vendor)
    line_no = 1

    # Dr: Sundry Creditor (clears liability)
    VoucherLine.objects.create(
        voucher=voucher, line_no=line_no, ledger=vendor_ledger,
        debit_amount=gross_amount, credit_amount=0,
        narration=f"Payment — {vendor.name}",
    )
    line_no += 1

    # BUG-038 fix: TDS Payable was already credited when the bill was passed.
    # On payment we just Dr Vendor (net_payable) and Cr Bank (net_payable).
    # No TDS line needed here — removed the create-then-delete anti-pattern.

    # Cr: Bank Account
    VoucherLine.objects.create(
        voucher=voucher, line_no=line_no, ledger=bank_account,
        debit_amount=0, credit_amount=net_amount,
        narration=f"Paid to {vendor.name}",
    )

    # Vendor Dr = net_payable (not gross — TDS was already handled on bill pass)
    VoucherLine.objects.filter(voucher=voucher, line_no=1).update(debit_amount=net_amount)

    post_voucher(voucher, user)

    payment.voucher = voucher
    payment.status = BillPayment.PaymentStatus.PROCESSED
    payment.save(update_fields=["voucher", "status"])

    # Update bill outstanding
    bill.amount_paid = _two(bill.amount_paid + net_amount)
    bill.outstanding = _two(bill.net_payable - bill.amount_paid)
    if bill.outstanding <= 0:
        bill.status = VendorBill.BillStatus.PAID
    else:
        bill.status = VendorBill.BillStatus.PARTIALLY_PAID
    bill.save(update_fields=["amount_paid", "outstanding", "status"])

    # Create TDS Entry record
    if tds_amount > 0:
        TDSEntry.objects.create(
            plant=plant,
            payment=payment,
            vendor=vendor,
            tds_section=tds_section,
            tds_rate=tds_rate,
            gross_payment=gross_amount,
            tds_amount=tds_amount,
            payment_date=payment.payment_date,
            deduction_date=payment.payment_date,
            vendor_pan=getattr(vendor, "pan_number", ""),
            vendor_name=vendor.name,
            quarter=_determine_quarter(payment.payment_date),
            financial_year=_financial_year(payment.payment_date),
        )

    _log(user, "CREATED", "BillPayment", payment.pk, {
        "number": payment_number,
        "vendor": vendor.name,
        "gross": str(gross_amount),
        "tds": str(tds_amount),
        "net": str(net_amount),
    })
    return payment


# ═══════════════════════════════════════════════════════════════════
# CUSTOMER RECEIPT
# ═══════════════════════════════════════════════════════════════════

@transaction.atomic
def receive_customer_payment(data: dict, user, plant) -> BillReceipt:
    """
    Record customer payment receipt.
    - Knock-off against specified invoices
    - Auto-deduct TCS from customer master
    - Creates Bank Receipt voucher
    - Updates invoice outstanding amounts
    """
    from apps.sales.models import Invoice
    from apps.masters.models import Customer

    customer = Customer.objects.get(pk=data["customer_id"])
    receipt_number = get_next_doc_number(plant, "REC", "REC")
    bank_account = LedgerAccount.objects.get(pk=data["bank_account_id"])

    gross_amount = _two(data["gross_amount"])
    tcs_rate = _two(getattr(customer, "tcs_rate", 0) or 0)
    tcs_amount = _two(gross_amount * tcs_rate / 100) if tcs_rate > 0 else Decimal("0")
    tds_by_customer = _two(data.get("tds_by_customer", 0) or 0)
    net_amount = _two(gross_amount - tds_by_customer)

    receipt = BillReceipt.objects.create(
        plant=plant,
        receipt_number=receipt_number,
        receipt_date=data.get("receipt_date", date.today()),
        status=BillReceipt.ReceiptStatus.CONFIRMED,
        receipt_mode=data["receipt_mode"],
        customer=customer,
        bank_account=bank_account,
        cheque_number=data.get("cheque_number", ""),
        cheque_date=data.get("cheque_date"),
        utr_number=data.get("utr_number", ""),
        gross_amount=gross_amount,
        tcs_rate=tcs_rate,
        tcs_amount=tcs_amount,
        tds_by_customer=tds_by_customer,
        net_amount=net_amount,
        received_by=user,
        remarks=data.get("remarks", ""),
    )

    # Allocate to invoices
    allocations = data.get("allocations", [])
    total_allocated = Decimal("0")
    for alloc in allocations:
        inv = Invoice.objects.get(pk=alloc["invoice_id"])
        alloc_amount = _two(alloc["amount"])
        if alloc_amount > inv.outstanding_amount + Decimal("0.01"):
            raise ValueError(
                f"Allocation ₹{alloc_amount} > invoice {inv.invoice_number} outstanding ₹{inv.outstanding_amount}"
            )
        ReceiptAllocation.objects.create(
            receipt=receipt, invoice=inv, allocated_amount=alloc_amount
        )
        inv.amount_paid = _two(inv.amount_paid + alloc_amount)
        inv.outstanding_amount = _two(inv.outstanding_amount - alloc_amount)
        if inv.outstanding_amount <= 0:
            inv.status = Invoice.InvoiceStatus.PAID
        elif inv.amount_paid > 0:
            inv.status = Invoice.InvoiceStatus.PARTIALLY_PAID
        inv.save(update_fields=["amount_paid", "outstanding_amount", "status"])
        total_allocated += alloc_amount

    # Create Bank Receipt Voucher
    voucher_type = (
        Voucher.VoucherType.CASH_RECEIPT
        if data["receipt_mode"] == "CASH"
        else Voucher.VoucherType.BANK_RECEIPT
    )
    voucher_number = get_next_doc_number(plant, "BR", "BR")
    voucher = Voucher.objects.create(
        plant=plant,
        voucher_number=voucher_number,
        voucher_date=receipt.receipt_date,
        voucher_type=voucher_type,
        status=Voucher.VoucherStatus.APPROVED,
        narration=f"Receipt from {customer.name}",
        reference_number=data.get("utr_number") or data.get("cheque_number", ""),
        customer=customer,
        prepared_by=user,
        approved_by=user,
        approved_at=timezone.now(),
    )

    customer_ledger = _get_customer_ledger(plant, customer)
    line_no = 1

    # Dr: Bank Account = gross_amount + tcs_amount (customer pays principal + TCS we collect)
    # BUG-029 fix: was net_amount which caused Cr > Dr by tcs_amount when tcs_amount > 0
    bank_debit = _two(gross_amount + tcs_amount)
    VoucherLine.objects.create(
        voucher=voucher, line_no=line_no, ledger=bank_account,
        debit_amount=bank_debit, credit_amount=0,
        narration=f"Received from {customer.name}",
    )
    line_no += 1

    # Dr: TDS Recoverable (if customer deducted TDS)
    if tds_by_customer > 0:
        tds_recv = LedgerAccount.objects.filter(
            plant=plant, name__icontains="TDS Recoverable"
        ).first()
        if tds_recv:
            VoucherLine.objects.create(
                voucher=voucher, line_no=line_no, ledger=tds_recv,
                debit_amount=tds_by_customer, credit_amount=0,
                narration="TDS deducted by customer",
            )
            line_no += 1

    # Cr: TCS Payable (if TCS collected)
    if tcs_amount > 0:
        tcs_ledger = LedgerAccount.objects.filter(plant=plant, sub_type="TCS_PAYABLE").first()
        if tcs_ledger:
            VoucherLine.objects.create(
                voucher=voucher, line_no=line_no, ledger=tcs_ledger,
                debit_amount=0, credit_amount=tcs_amount,
                narration=f"TCS @ {tcs_rate}%",
            )
            line_no += 1

    # Cr: Sundry Debtor (customer ledger) = gross
    VoucherLine.objects.create(
        voucher=voucher, line_no=line_no, ledger=customer_ledger,
        debit_amount=0, credit_amount=gross_amount,
        narration=f"Receipt — {customer.name}",
    )

    post_voucher(voucher, user)

    receipt.voucher = voucher
    receipt.save(update_fields=["voucher"])

    _log(user, "CREATED", "BillReceipt", receipt.pk, {
        "number": receipt_number,
        "customer": customer.name,
        "gross": str(gross_amount),
        "net": str(net_amount),
        "allocated_to": len(allocations),
    })
    return receipt


# ═══════════════════════════════════════════════════════════════════
# GST DATA EXTRACTION
# ═══════════════════════════════════════════════════════════════════

def get_gst_data_for_gstr1(plant, return_period: str) -> dict:
    """
    GSTR-1: Outward supply return.
    return_period = "MMYYYY" e.g. "012026"
    Returns B2B, B2C, CDNR data.
    """
    from apps.sales.models import Invoice

    invoices = Invoice.objects.filter(
        plant=plant,
        invoice_date__year=int(return_period[2:]),
        invoice_date__month=int(return_period[:2]),
        status__in=["CONFIRMED", "IRN_DONE", "PAYMENT_PENDING", "PARTIALLY_PAID", "PAID"],
        invoice_type="TAX_INVOICE",
    ).select_related("customer")

    b2b = []  # Registered customers (have GSTIN)
    b2c = []  # Unregistered customers

    for inv in invoices:
        entry = {
            "invoice_number": inv.invoice_number,
            "invoice_date": str(inv.invoice_date),
            "invoice_value": float(inv.total_amount),
            "place_of_supply": inv.place_of_supply,
            "reverse_charge": "Y" if inv.reverse_charge else "N",
            "taxable_value": float(inv.taxable_amount),
            "cgst": float(inv.cgst_amount),
            "sgst": float(inv.sgst_amount),
            "igst": float(inv.igst_amount),
            "cess": 0,
            "customer_name": inv.customer.name,
            "customer_gstin": inv.customer_gstin,
            "irn": inv.irn,
        }
        if inv.customer_gstin:
            b2b.append(entry)
        else:
            b2c.append(entry)

    # CDNR: Credit/Debit notes for registered
    credit_debit = Invoice.objects.filter(
        plant=plant,
        invoice_date__year=int(return_period[2:]),
        invoice_date__month=int(return_period[:2]),
        invoice_type__in=["DEBIT_NOTE", "CREDIT_NOTE"],
    ).select_related("customer")

    cdnr = []
    for inv in credit_debit:
        cdnr.append({
            "note_number": inv.invoice_number,
            "note_date": str(inv.invoice_date),
            "note_type": "C" if inv.invoice_type == "CREDIT_NOTE" else "D",
            "original_invoice": inv.original_invoice.invoice_number if inv.original_invoice else "",
            "taxable_value": float(inv.taxable_amount),
            "cgst": float(inv.cgst_amount),
            "sgst": float(inv.sgst_amount),
            "igst": float(inv.igst_amount),
            "customer_gstin": inv.customer_gstin,
        })

    summary = {
        "total_invoices": invoices.count(),
        "total_taxable": float(invoices.aggregate(t=Sum("taxable_amount"))["t"] or 0),
        "total_cgst": float(invoices.aggregate(t=Sum("cgst_amount"))["t"] or 0),
        "total_sgst": float(invoices.aggregate(t=Sum("sgst_amount"))["t"] or 0),
        "total_igst": float(invoices.aggregate(t=Sum("igst_amount"))["t"] or 0),
    }

    return {
        "return_period": return_period,
        "gstin": plant.gstin,
        "plant": plant.code,
        "b2b": b2b,
        "b2c": b2c,
        "cdnr": cdnr,
        "summary": summary,
    }


def get_gst_data_for_gstr3b(plant, return_period: str) -> dict:
    """
    GSTR-3B summary return.
    Returns Table 3.1 (outward), Table 4 (ITC) data.
    """
    # Outward supplies (from GSTLedger OUTPUT entries)
    output_cgst = GSTLedger.objects.filter(
        plant=plant, entry_type="OUTPUT", gst_type="CGST", return_period=return_period
    ).aggregate(t=Sum("amount"))["t"] or 0

    output_sgst = GSTLedger.objects.filter(
        plant=plant, entry_type="OUTPUT", gst_type="SGST", return_period=return_period
    ).aggregate(t=Sum("amount"))["t"] or 0

    output_igst = GSTLedger.objects.filter(
        plant=plant, entry_type="OUTPUT", gst_type="IGST", return_period=return_period
    ).aggregate(t=Sum("amount"))["t"] or 0

    output_taxable = GSTLedger.objects.filter(
        plant=plant, entry_type="OUTPUT", gst_type="CGST", return_period=return_period
    ).aggregate(t=Sum("taxable_amount"))["t"] or 0

    # Input tax credit (from GSTLedger INPUT entries)
    input_cgst = GSTLedger.objects.filter(
        plant=plant, entry_type="INPUT", gst_type="CGST", return_period=return_period
    ).aggregate(t=Sum("amount"))["t"] or 0

    input_sgst = GSTLedger.objects.filter(
        plant=plant, entry_type="INPUT", gst_type="SGST", return_period=return_period
    ).aggregate(t=Sum("amount"))["t"] or 0

    input_igst = GSTLedger.objects.filter(
        plant=plant, entry_type="INPUT", gst_type="IGST", return_period=return_period
    ).aggregate(t=Sum("amount"))["t"] or 0

    # Net GST payable
    net_cgst = float(output_cgst) - float(input_cgst)
    net_sgst = float(output_sgst) - float(input_sgst)
    net_igst = float(output_igst) - float(input_igst)

    return {
        "return_period": return_period,
        "gstin": plant.gstin,
        "table_3_1_outward": {
            "taxable_value": float(output_taxable),
            "igst": float(output_igst),
            "cgst": float(output_cgst),
            "sgst": float(output_sgst),
        },
        "table_4_itc": {
            "igst": float(input_igst),
            "cgst": float(input_cgst),
            "sgst": float(input_sgst),
        },
        "table_6_payment": {
            "igst_payable": round(net_igst, 2),
            "cgst_payable": round(net_cgst, 2),
            "sgst_payable": round(net_sgst, 2),
            "total_payable": round(net_igst + net_cgst + net_sgst, 2),
        },
    }


# ═══════════════════════════════════════════════════════════════════
# OUTSTANDING / AGEING REPORTS
# ═══════════════════════════════════════════════════════════════════

def get_outstanding_debtors(plant, as_of_date: date = None) -> list:
    """
    AR ageing report. 0-30 / 30-60 / 60-90 / 90+ days.
    Returns list of dicts per invoice.
    """
    from apps.sales.models import Invoice

    if as_of_date is None:
        as_of_date = date.today()

    invoices = Invoice.objects.filter(
        plant=plant,
        outstanding_amount__gt=0,
        status__in=["PAYMENT_PENDING", "PARTIALLY_PAID"],
    ).select_related("customer").order_by("customer__name", "invoice_date")

    result = []
    for inv in invoices:
        overdue_days = (as_of_date - inv.invoice_date).days
        if overdue_days <= 30:
            bucket = "CURRENT"
        elif overdue_days <= 60:
            bucket = "30_60"
        elif overdue_days <= 90:
            bucket = "60_90"
        else:
            bucket = "OVER_90"

        # Last followup
        last_followup = OutstandingFollowup.objects.filter(
            invoice=inv
        ).order_by("-action_date").first()

        result.append({
            "customer_id": inv.customer_id,
            "customer_name": inv.customer.name,
            "customer_gstin": inv.customer.gstin,
            "invoice_id": str(inv.pk),
            "invoice_number": inv.invoice_number,
            "invoice_date": str(inv.invoice_date),
            "due_date": str(inv.due_date) if inv.due_date else None,
            "invoice_amount": float(inv.total_amount),
            "amount_paid": float(inv.amount_paid),
            "outstanding": float(inv.outstanding_amount),
            "overdue_days": overdue_days,
            "bucket": bucket,
            "last_followup_date": str(last_followup.action_date) if last_followup else None,
            "last_followup_action": last_followup.action if last_followup else None,
            "promised_date": str(last_followup.promised_date) if last_followup and last_followup.promised_date else None,
        })

    return result


def get_outstanding_creditors(plant, as_of_date: date = None) -> list:
    """
    AP ageing report. Bills passed but not fully paid.
    """
    if as_of_date is None:
        as_of_date = date.today()

    bills = VendorBill.objects.filter(
        plant=plant,
        outstanding__gt=0,
        status__in=[VendorBill.BillStatus.PASSED, VendorBill.BillStatus.PARTIALLY_PAID],
    ).select_related("vendor").order_by("vendor__name", "vendor_bill_date")

    result = []
    for bill in bills:
        overdue_days = (as_of_date - bill.vendor_bill_date).days if bill.vendor_bill_date else 0
        if overdue_days <= 30:
            bucket = "CURRENT"
        elif overdue_days <= 60:
            bucket = "30_60"
        elif overdue_days <= 90:
            bucket = "60_90"
        else:
            bucket = "OVER_90"

        result.append({
            "vendor_id": bill.vendor_id,
            "vendor_name": bill.vendor.name,
            "vendor_gstin": bill.vendor.gstin,
            "bill_id": str(bill.pk),
            "bill_number": bill.bill_number,
            "vendor_bill_ref": bill.vendor_bill_ref,
            "bill_date": str(bill.vendor_bill_date),
            "due_date": str(bill.due_date) if bill.due_date else None,
            "bill_amount": float(bill.total_amount),
            "net_payable": float(bill.net_payable),
            "amount_paid": float(bill.amount_paid),
            "outstanding": float(bill.outstanding),
            "overdue_days": overdue_days,
            "bucket": bucket,
        })

    return result


def get_cash_position(plant) -> dict:
    """
    Current cash and bank balances.
    """
    bank_accounts = LedgerAccount.objects.filter(
        plant=plant, sub_type__in=["BANK", "CASH"], is_active=True
    )
    position = []
    total_cash = Decimal("0")
    for acc in bank_accounts:
        balance = acc.current_balance
        position.append({
            "account_id": acc.pk,
            "account_code": acc.code,
            "account_name": acc.name,
            "sub_type": acc.sub_type,
            "bank_name": acc.bank_name,
            "balance": float(balance),
        })
        total_cash += balance

    return {
        "accounts": position,
        "total_balance": float(total_cash),
        "as_of": str(date.today()),
    }


def log_ar_followup(data: dict, user, plant) -> OutstandingFollowup:
    """Log an AR followup action on an outstanding invoice."""
    from apps.sales.models import Invoice

    invoice = Invoice.objects.get(pk=data["invoice_id"])
    overdue_days = (date.today() - invoice.invoice_date).days
    if overdue_days <= 30:
        bucket = "CURRENT"
    elif overdue_days <= 60:
        bucket = "30_60"
    elif overdue_days <= 90:
        bucket = "60_90"
    else:
        bucket = "OVER_90"

    followup = OutstandingFollowup.objects.create(
        plant=plant,
        customer=invoice.customer,
        invoice=invoice,
        outstanding_amount=invoice.outstanding_amount,
        overdue_days=overdue_days,
        bucket=bucket,
        action=data["action"],
        action_date=data.get("action_date", date.today()),
        done_by=user,
        contact_person=data.get("contact_person", ""),
        summary=data["summary"],
        promised_date=data.get("promised_date"),
        promised_amount=data.get("promised_amount"),
        next_followup_date=data.get("next_followup_date"),
    )
    _log(user, "CREATED", "OutstandingFollowup", followup.pk, {
        "invoice": invoice.invoice_number,
        "action": data["action"],
    })
    return followup


# ═══════════════════════════════════════════════════════════════════
# BANK RECONCILIATION
# ═══════════════════════════════════════════════════════════════════

@transaction.atomic
def upload_bank_statement(data: dict, user, plant) -> BankStatement:
    """Create or update a bank statement for reconciliation."""
    bank_account = LedgerAccount.objects.get(pk=data["bank_account_id"])
    statement, created = BankStatement.objects.get_or_create(
        bank_account=bank_account,
        statement_month=data["statement_month"],
        defaults={
            "plant": plant,
            "opening_balance": data["opening_balance"],
            "closing_balance": data["closing_balance"],
            "uploaded_by": user,
        }
    )
    if not created:
        statement.opening_balance = data["opening_balance"]
        statement.closing_balance = data["closing_balance"]
        statement.uploaded_by = user
        statement.save(update_fields=["opening_balance", "closing_balance", "uploaded_by"])

    _log(user, "CREATED" if created else "UPDATED", "BankStatement", statement.pk, {
        "month": data["statement_month"],
        "bank": bank_account.name,
    })
    return statement


@transaction.atomic
def reconcile_bank_line(recon_line: BankReconciliation, voucher: Voucher, user) -> BankReconciliation:
    """Match a bank statement line to a voucher."""
    if recon_line.match_status == BankReconciliation.MatchStatus.MATCHED:
        raise ValueError("Bank statement line is already matched.")

    recon_line.match_status = BankReconciliation.MatchStatus.MATCHED
    recon_line.matched_voucher = voucher
    recon_line.matched_by = user
    recon_line.matched_at = timezone.now()
    recon_line.save(update_fields=["match_status", "matched_voucher", "matched_by", "matched_at"])

    _log(user, "MATCHED", "BankReconciliation", recon_line.pk, {
        "voucher": voucher.voucher_number,
    })
    return recon_line


# ═══════════════════════════════════════════════════════════════════
# ACCOUNTS DASHBOARD
# ═══════════════════════════════════════════════════════════════════

def get_accounts_dashboard(plant) -> dict:
    """
    Dashboard tiles for Accounts module.
    """
    from apps.sales.models import Invoice

    today = date.today()
    month_start = today.replace(day=1)

    # AR summary
    total_outstanding_ar = Invoice.objects.filter(
        plant=plant, outstanding_amount__gt=0
    ).aggregate(t=Sum("outstanding_amount"))["t"] or 0

    overdue_ar = Invoice.objects.filter(
        plant=plant, outstanding_amount__gt=0,
        invoice_date__lt=today - timedelta(days=30),
    ).aggregate(t=Sum("outstanding_amount"))["t"] or 0

    # AP summary
    total_outstanding_ap = VendorBill.objects.filter(
        plant=plant, outstanding__gt=0
    ).aggregate(t=Sum("outstanding"))["t"] or 0

    overdue_ap = VendorBill.objects.filter(
        plant=plant, outstanding__gt=0,
        vendor_bill_date__lt=today - timedelta(days=30),
    ).aggregate(t=Sum("outstanding"))["t"] or 0

    # Bills pending passing
    bills_pending = VendorBill.objects.filter(
        plant=plant, status__in=["RECEIVED", "UNDER_CHECK"]
    ).count()

    # Receipts this month
    receipts_this_month = BillReceipt.objects.filter(
        plant=plant, receipt_date__gte=month_start,
        status__in=["CONFIRMED", "CLEARED"]
    ).aggregate(t=Sum("net_amount"))["t"] or 0

    # Payments this month
    payments_this_month = BillPayment.objects.filter(
        plant=plant, payment_date__gte=month_start,
        status__in=["PROCESSED", "CLEARED"]
    ).aggregate(t=Sum("net_amount"))["t"] or 0

    return {
        "total_outstanding_receivable": float(total_outstanding_ar),
        "overdue_receivable_30plus": float(overdue_ar),
        "total_outstanding_payable": float(total_outstanding_ap),
        "overdue_payable_30plus": float(overdue_ap),
        "bills_pending_passing": bills_pending,
        "receipts_this_month": float(receipts_this_month),
        "payments_this_month": float(payments_this_month),
        "net_cash_flow": float(receipts_this_month) - float(payments_this_month),
    }


# ═══════════════════════════════════════════════════════════════════
# AUTO-EMAIL OVERDUE DEBTORS (Celery task helper)
# ═══════════════════════════════════════════════════════════════════

def send_overdue_reminder_emails(plant) -> int:
    """
    Send auto-email reminders to customers with invoices overdue 30+ days.
    Returns count of emails sent.
    """
    from apps.sales.models import Invoice

    overdue_invoices = Invoice.objects.filter(
        plant=plant,
        outstanding_amount__gt=0,
        invoice_date__lt=date.today() - timedelta(days=30),
        status__in=["PAYMENT_PENDING", "PARTIALLY_PAID"],
    ).select_related("customer")

    sent = 0
    for inv in overdue_invoices:
        customer_email = inv.customer.email if hasattr(inv.customer, "email") else ""
        if not customer_email:
            continue
        overdue_days = (date.today() - inv.invoice_date).days
        try:
            send_mail(
                subject=f"Payment Reminder — Invoice {inv.invoice_number} — ₹{inv.outstanding_amount}",
                message=(
                    f"Dear {inv.customer.name},\n\n"
                    f"This is a gentle reminder that Invoice {inv.invoice_number} "
                    f"dated {inv.invoice_date} for ₹{inv.total_amount} has an "
                    f"outstanding balance of ₹{inv.outstanding_amount}.\n\n"
                    f"The invoice is {overdue_days} days overdue. "
                    f"Please arrange payment at the earliest.\n\n"
                    f"For queries, please contact our accounts team.\n\n"
                    f"Trident Paper Box Industries\nPardi, Valsad"
                ),
                from_email=django_settings.DEFAULT_FROM_EMAIL,
                recipient_list=[customer_email],
                fail_silently=True,
            )
            sent += 1
        except Exception:
            pass

    return sent


# ═══════════════════════════════════════════════════════════════════
# MSME COMPLIANCE REPORT
# ═══════════════════════════════════════════════════════════════════

def get_msme_overdue_report(plant, as_of_date):
    """
    Return MSME overdue report as of a given date.
    Flags bills where days_overdue > 45 per MSMED Act.
    Interest at 3× bank rate ≈ 3% p.a. per annum on delayed payments.
    """
    from datetime import date as date_type
    from apps.accounts.models import VendorBill

    EXCLUDED_STATUSES = [VendorBill.BillStatus.PAID, "CANCELLED"]

    qs = VendorBill.objects.filter(
        plant=plant,
        vendor__msme_registered=True,
        due_date__isnull=False,
    ).exclude(
        status__in=EXCLUDED_STATUSES,
    ).select_related("vendor")

    bills = []
    total_overdue_amount = Decimal("0.00")
    total_interest = Decimal("0.00")
    vendor_ids = set()

    for bill in qs:
        days_overdue = (as_of_date - bill.due_date).days
        if days_overdue <= 45:
            continue  # not flagged — under 45-day threshold

        vendor_ids.add(bill.vendor_id)
        amount = bill.outstanding if bill.outstanding else bill.net_payable
        # Interest = Amount × 3% × days_overdue / 365
        interest = _two(amount * Decimal("0.03") * Decimal(days_overdue) / Decimal("365"))

        total_overdue_amount += amount
        total_interest += interest

        bills.append({
            "vendor_name": bill.vendor.name,
            "msme_type": bill.vendor.msme_type,
            "msme_number": bill.vendor.msme_number,
            "bill_number": bill.bill_number,
            "bill_date": bill.vendor_bill_date.isoformat(),
            "due_date": bill.due_date.isoformat(),
            "amount": float(amount),
            "days_overdue": days_overdue,
            "interest_liability": float(interest),
        })

    summary = {
        "total_msme_vendors": len(vendor_ids),
        "total_overdue_bills": len(bills),
        "total_overdue_amount": float(total_overdue_amount),
        "total_interest": float(total_interest),
    }

    return {"summary": summary, "bills": bills}
