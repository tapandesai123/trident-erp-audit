"""
MSME Compliance Report Tests — Task 13
Tests for get_msme_overdue_report() service and API endpoint.
"""
from decimal import Decimal
from datetime import date, timedelta

from django.test import TestCase
from django.contrib.auth import get_user_model
from rest_framework.test import APIClient

User = get_user_model()


class BaseMSMETest(TestCase):
    """Shared setup for MSME tests."""

    def setUp(self):
        from apps.core.models import Company, Plant
        from apps.masters.models import VendorGroup, Vendor
        from apps.accounts.models import LedgerAccount, AccountGroup

        self.company = Company.objects.create(
            name="Trident Paper Box", gstin="24AAKFT4708J2ZY"
        )
        self.plant = Plant.objects.create(
            company=self.company,
            code="PARDI",
            name="Pardi Plant",
            gstin="24AAKFT4708J2ZY",
            state_code="24",
            is_active=True,
        )
        self.user = User.objects.create_user(
            username="msme_user",
            password="pass123",
            email="msme@trident.com",
            is_superadmin=True,
        )
        if hasattr(self.user, "plant"):
            self.user.plant = self.plant
            self.user.save()

        vg = VendorGroup.objects.create(name="MSME Suppliers")

        # MSME-registered vendor
        self.msme_vendor = Vendor.objects.create(
            plant=self.plant,
            vendor_group=vg,
            name="MSME Supplies Pvt Ltd",
            gstin="27MSME0001X1Z5",
            msme_registered=True,
            msme_type="MICRO",
            msme_number="UDYAM-GJ-01-0012345",
        )

        # Non-MSME vendor
        self.non_msme_vendor = Vendor.objects.create(
            plant=self.plant,
            vendor_group=vg,
            name="Large Corp Ltd",
            gstin="27LARGE001X1Z5",
            msme_registered=False,
        )

        # Create required account group and ledger for BillPayment (if needed)
        ag = AccountGroup.objects.create(
            plant=self.plant,
            code="LIAB01",
            name="Liabilities",
            group_type="LIABILITIES",
        )

        self.as_of_date = date.today()

    def _make_bill(self, vendor, days_overdue, status="PASSED"):
        """Helper to create a VendorBill overdue by given days."""
        from apps.accounts.models import VendorBill

        due_date = self.as_of_date - timedelta(days=days_overdue)
        bill_date = due_date - timedelta(days=30)

        return VendorBill.objects.create(
            plant=self.plant,
            bill_number=f"BILL-{vendor.id}-{days_overdue}",
            vendor_bill_ref=f"VEN-INV-{days_overdue}",
            vendor_bill_date=bill_date,
            received_date=bill_date,
            status=status,
            vendor=vendor,
            taxable_amount=Decimal("100000.00"),
            total_amount=Decimal("118000.00"),
            net_payable=Decimal("118000.00"),
            outstanding=Decimal("118000.00"),
            due_date=due_date,
            received_by=self.user,
        )


class TestGetMSMEOverdueReport(BaseMSMETest):
    """Unit tests for get_msme_overdue_report() service function."""

    def test_overdue_msme_bill_appears(self):
        """A 50-day overdue MSME bill should appear in the report."""
        from apps.accounts.services import get_msme_overdue_report

        self._make_bill(self.msme_vendor, days_overdue=50)
        result = get_msme_overdue_report(self.plant, self.as_of_date)

        self.assertEqual(result["summary"]["total_overdue_bills"], 1)
        self.assertEqual(len(result["bills"]), 1)

    def test_days_overdue_correct(self):
        """days_overdue should be exactly 50."""
        from apps.accounts.services import get_msme_overdue_report

        self._make_bill(self.msme_vendor, days_overdue=50)
        result = get_msme_overdue_report(self.plant, self.as_of_date)

        bill = result["bills"][0]
        self.assertEqual(bill["days_overdue"], 50)

    def test_interest_liability_formula(self):
        """Interest = amount × 3% × days / 365."""
        from apps.accounts.services import get_msme_overdue_report

        self._make_bill(self.msme_vendor, days_overdue=50)
        result = get_msme_overdue_report(self.plant, self.as_of_date)

        bill = result["bills"][0]
        amount = Decimal(str(bill["amount"]))
        expected_interest = float(
            amount * Decimal("0.03") * Decimal("50") / Decimal("365")
        )
        self.assertAlmostEqual(bill["interest_liability"], expected_interest, places=2)

    def test_bill_exactly_45_days_not_flagged(self):
        """A bill exactly 45 days overdue should NOT appear (must be > 45)."""
        from apps.accounts.services import get_msme_overdue_report

        self._make_bill(self.msme_vendor, days_overdue=45)
        result = get_msme_overdue_report(self.plant, self.as_of_date)

        self.assertEqual(result["summary"]["total_overdue_bills"], 0)
        self.assertEqual(len(result["bills"]), 0)

    def test_bill_under_45_days_not_flagged(self):
        """A bill 30 days overdue should NOT appear."""
        from apps.accounts.services import get_msme_overdue_report

        self._make_bill(self.msme_vendor, days_overdue=30)
        result = get_msme_overdue_report(self.plant, self.as_of_date)

        self.assertEqual(len(result["bills"]), 0)

    def test_non_msme_vendor_bill_excluded(self):
        """Bills from non-MSME vendors must NOT appear."""
        from apps.accounts.services import get_msme_overdue_report

        self._make_bill(self.non_msme_vendor, days_overdue=60)
        result = get_msme_overdue_report(self.plant, self.as_of_date)

        self.assertEqual(result["summary"]["total_overdue_bills"], 0)
        self.assertEqual(len(result["bills"]), 0)

    def test_paid_bill_excluded(self):
        """PAID bills should not appear even if MSME and overdue."""
        from apps.accounts.services import get_msme_overdue_report

        self._make_bill(self.msme_vendor, days_overdue=60, status="PAID")
        result = get_msme_overdue_report(self.plant, self.as_of_date)

        self.assertEqual(len(result["bills"]), 0)

    def test_summary_vendor_count(self):
        """Summary should count unique MSME vendors, not bills."""
        from apps.accounts.services import get_msme_overdue_report

        self._make_bill(self.msme_vendor, days_overdue=50)
        self._make_bill(self.msme_vendor, days_overdue=60)
        result = get_msme_overdue_report(self.plant, self.as_of_date)

        self.assertEqual(result["summary"]["total_msme_vendors"], 1)
        self.assertEqual(result["summary"]["total_overdue_bills"], 2)

    def test_summary_totals(self):
        """Summary totals should sum amounts and interest across all flagged bills."""
        from apps.accounts.services import get_msme_overdue_report

        self._make_bill(self.msme_vendor, days_overdue=50)
        result = get_msme_overdue_report(self.plant, self.as_of_date)

        bill = result["bills"][0]
        summary = result["summary"]
        self.assertAlmostEqual(summary["total_overdue_amount"], bill["amount"], places=2)
        self.assertAlmostEqual(summary["total_interest"], bill["interest_liability"], places=2)

    def test_bill_fields_present(self):
        """Each bill dict should have all required fields."""
        from apps.accounts.services import get_msme_overdue_report

        self._make_bill(self.msme_vendor, days_overdue=50)
        result = get_msme_overdue_report(self.plant, self.as_of_date)

        bill = result["bills"][0]
        required_keys = [
            "vendor_name", "msme_type", "msme_number",
            "bill_number", "bill_date", "due_date",
            "amount", "days_overdue", "interest_liability",
        ]
        for key in required_keys:
            self.assertIn(key, bill, f"Missing key: {key}")

    def test_bill_vendor_details(self):
        """Vendor details should match the MSME vendor record."""
        from apps.accounts.services import get_msme_overdue_report

        self._make_bill(self.msme_vendor, days_overdue=50)
        result = get_msme_overdue_report(self.plant, self.as_of_date)

        bill = result["bills"][0]
        self.assertEqual(bill["vendor_name"], self.msme_vendor.name)
        self.assertEqual(bill["msme_type"], "MICRO")
        self.assertEqual(bill["msme_number"], "UDYAM-GJ-01-0012345")

    def test_empty_report_when_no_overdue(self):
        """Report should return empty lists when nothing qualifies."""
        from apps.accounts.services import get_msme_overdue_report

        result = get_msme_overdue_report(self.plant, self.as_of_date)
        self.assertEqual(result["summary"]["total_overdue_bills"], 0)
        self.assertEqual(result["bills"], [])


class TestMSMEReportAPI(BaseMSMETest):
    """API endpoint tests for /api/accounts/msme-report/."""

    def setUp(self):
        super().setUp()
        self.client = APIClient()
        self.client.force_authenticate(user=self.user)

    def test_api_returns_200(self):
        """GET /api/accounts/msme-report/ should return HTTP 200."""
        response = self.client.get(
            "/api/accounts/msme-report/",
            {"as_of_date": self.as_of_date.isoformat()},
        )
        self.assertEqual(response.status_code, 200)

    def test_api_response_structure(self):
        """Response should have 'summary' and 'bills' keys."""
        response = self.client.get("/api/accounts/msme-report/")
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertIn("summary", data)
        self.assertIn("bills", data)

    def test_api_summary_keys(self):
        """Summary should have all required keys."""
        response = self.client.get("/api/accounts/msme-report/")
        data = response.json()
        summary = data["summary"]
        for key in ["total_msme_vendors", "total_overdue_bills", "total_overdue_amount", "total_interest"]:
            self.assertIn(key, summary)

    def test_api_overdue_bill_in_response(self):
        """Overdue MSME bill should appear in API response."""
        self._make_bill(self.msme_vendor, days_overdue=50)
        response = self.client.get(
            "/api/accounts/msme-report/",
            {"as_of_date": self.as_of_date.isoformat()},
        )
        data = response.json()
        self.assertEqual(data["summary"]["total_overdue_bills"], 1)
        self.assertEqual(len(data["bills"]), 1)

    def test_api_invalid_date_returns_400(self):
        """Invalid date format should return 400."""
        response = self.client.get("/api/accounts/msme-report/", {"as_of_date": "not-a-date"})
        self.assertEqual(response.status_code, 400)

    def test_api_unauthenticated_returns_401(self):
        """Unauthenticated request should return 401."""
        anon_client = APIClient()
        response = anon_client.get("/api/accounts/msme-report/")
        self.assertEqual(response.status_code, 401)

    def test_api_export_returns_excel(self):
        """Export endpoint should return Excel file."""
        self._make_bill(self.msme_vendor, days_overdue=50)
        response = self.client.get("/api/accounts/msme-report/export/")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(
            response["Content-Type"],
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )
        self.assertIn("attachment", response.get("Content-Disposition", ""))

    def test_api_export_filename_contains_date(self):
        """Export filename should contain as_of_date."""
        response = self.client.get(
            "/api/accounts/msme-report/export/",
            {"as_of_date": "2026-03-31"},
        )
        self.assertEqual(response.status_code, 200)
        disposition = response.get("Content-Disposition", "")
        self.assertIn("2026-03-31", disposition)
