"""
Accounts Module Tests — Section 6
Minimum 20 test cases covering:
  - Account group & ledger CRUD
  - Voucher creation, posting, cancellation
  - Vendor bill 8-point checklist
  - Bill passing with TDS
  - Vendor payment with TDS deduction
  - Customer receipt with knock-off
  - GST data extraction (GSTR-1, GSTR-3B)
  - Outstanding AR/AP ageing
  - TDS calculations
  - Bank reconciliation
"""
from decimal import Decimal
from datetime import date
from unittest.mock import patch, MagicMock

from django.test import TestCase
from django.contrib.auth import get_user_model

User = get_user_model()


class BaseAccountsTest(TestCase):
    """Shared setup for all accounts tests."""

    def setUp(self):
        from apps.core.models import Company, Plant
        from apps.masters.models import VendorGroup, Vendor, CustomerGroup, Customer

        self.company = Company.objects.create(name="Trident Paper Box", gstin="24AAKFT4708J2ZY")
        self.plant = Plant.objects.create(
            company=self.company, code="PARDI", name="Pardi Plant",
            gstin="24AAKFT4708J2ZY", state_code="24", is_active=True,
        )
        self.user = User.objects.create_user(
            username="accounts_user", password="pass123",
            email="accounts@trident.com",
        )
        if hasattr(self.user, "plant"):
            self.user.plant = self.plant
            self.user.save()

        vg = VendorGroup.objects.create(name="RM Suppliers")
        self.vendor = Vendor.objects.create(
            plant=self.plant, vendor_group=vg,
            name="Test Supplier Pvt Ltd",
            gstin="27XXXXX1234X1Z5",
            tds_rate=Decimal("2.00"),
            tds_section="194C",
        )

        cg = CustomerGroup.objects.create(name="Regular")
        self.customer = Customer.objects.create(
            plant=self.plant, customer_group=cg,
            name="Test Customer Ltd",
            gstin="24YYYY5678Y1Z3",
        )

        # Create basic chart of accounts
        self._setup_chart_of_accounts()

    def _setup_chart_of_accounts(self):
        from apps.accounts.models import AccountGroup, LedgerAccount, CostCenter

        self.assets_group = AccountGroup.objects.create(
            plant=self.plant, code="A", name="Assets", group_type="ASSETS", is_system=True
        )
        self.liab_group = AccountGroup.objects.create(
            plant=self.plant, code="L", name="Liabilities", group_type="LIABILITIES", is_system=True
        )
        self.exp_group = AccountGroup.objects.create(
            plant=self.plant, code="E", name="Expense", group_type="EXPENSE", is_system=True
        )
        self.sc_group = AccountGroup.objects.create(
            plant=self.plant, code="SC", name="Sundry Creditors",
            group_type="LIABILITIES", parent=self.liab_group
        )
        self.sd_group = AccountGroup.objects.create(
            plant=self.plant, code="SD", name="Sundry Debtors",
            group_type="ASSETS", parent=self.assets_group
        )

        self.bank_ledger = LedgerAccount.objects.create(
            plant=self.plant, group=self.assets_group,
            code="BANK001", name="HDFC Bank", sub_type="BANK",
            current_balance=Decimal("500000"), balance_type="Dr", is_system=True,
        )
        self.purchase_ledger = LedgerAccount.objects.create(
            plant=self.plant, group=self.exp_group,
            code="PUR001", name="Raw Material Purchase", sub_type="EXPENSE",
            current_balance=Decimal("0"),
        )
        self.cgst_itc = LedgerAccount.objects.create(
            plant=self.plant, group=self.assets_group,
            code="CGST-ITC", name="CGST Input Tax Credit",
            sub_type="GST_RECEIVABLE", current_balance=Decimal("0"),
        )
        self.sgst_itc = LedgerAccount.objects.create(
            plant=self.plant, group=self.assets_group,
            code="SGST-ITC", name="SGST Input Tax Credit",
            sub_type="GST_RECEIVABLE", current_balance=Decimal("0"),
        )
        self.tds_payable = LedgerAccount.objects.create(
            plant=self.plant, group=self.liab_group,
            code="TDS-PAY", name="TDS Payable",
            sub_type="TDS_PAYABLE", current_balance=Decimal("0"),
        )
        self.tcs_payable = LedgerAccount.objects.create(
            plant=self.plant, group=self.liab_group,
            code="TCS-PAY", name="TCS Payable",
            sub_type="TCS_PAYABLE", current_balance=Decimal("0"),
        )

        self.cost_center = CostCenter.objects.create(
            plant=self.plant, code="PROD", name="Production",
        )


# ── TEST GROUP 1: Account Groups & Ledgers ────────────────────────

class TestChartOfAccounts(BaseAccountsTest):

    def test_01_account_group_created(self):
        """AccountGroup created successfully with correct group_type."""
        from apps.accounts.models import AccountGroup
        group = AccountGroup.objects.get(plant=self.plant, code="A")
        self.assertEqual(group.group_type, "ASSETS")
        self.assertTrue(group.is_system)

    def test_02_ledger_account_created(self):
        """LedgerAccount created with correct sub_type."""
        self.assertEqual(self.bank_ledger.sub_type, "BANK")
        self.assertEqual(self.bank_ledger.current_balance, Decimal("500000"))

    def test_03_nested_account_groups(self):
        """Account groups can be nested (parent-child)."""
        from apps.accounts.models import AccountGroup
        child = AccountGroup.objects.create(
            plant=self.plant, code="SC-RM", name="RM Creditors",
            group_type="LIABILITIES", parent=self.sc_group,
        )
        self.assertEqual(child.parent, self.sc_group)
        self.assertEqual(self.sc_group.children.count(), 1)

    def test_04_cash_position(self):
        """Cash position returns bank account balance."""
        from apps.accounts.services import get_cash_position
        result = get_cash_position(self.plant)
        self.assertIn("total_balance", result)
        self.assertGreater(result["total_balance"], 0)


# ── TEST GROUP 2: Voucher ─────────────────────────────────────────

class TestVoucher(BaseAccountsTest):

    def _create_test_voucher(self):
        from apps.accounts.models import Voucher, VoucherLine
        from apps.accounts.services import get_next_doc_number

        voucher_number = get_next_doc_number(self.plant, "JV", "JV")
        voucher = Voucher.objects.create(
            plant=self.plant,
            voucher_number=voucher_number,
            voucher_date=date.today(),
            voucher_type="JOURNAL",
            narration="Test journal entry",
            prepared_by=self.user,
        )
        # Dr: Purchase, Cr: Bank
        VoucherLine.objects.create(
            voucher=voucher, line_no=1,
            ledger=self.purchase_ledger,
            debit_amount=Decimal("10000"), credit_amount=Decimal("0"),
        )
        VoucherLine.objects.create(
            voucher=voucher, line_no=2,
            ledger=self.bank_ledger,
            debit_amount=Decimal("0"), credit_amount=Decimal("10000"),
        )
        return voucher

    def test_05_voucher_creation(self):
        """Voucher created in DRAFT status."""
        from apps.accounts.models import Voucher
        voucher = self._create_test_voucher()
        self.assertEqual(voucher.status, Voucher.VoucherStatus.DRAFT)
        self.assertEqual(voucher.lines.count(), 2)

    def test_06_voucher_posting(self):
        """Post voucher updates ledger balances."""
        from apps.accounts.services import post_voucher
        from apps.accounts.models import Voucher
        voucher = self._create_test_voucher()
        initial_bank_balance = self.bank_ledger.current_balance

        result = post_voucher(voucher, self.user)
        self.assertEqual(result.status, Voucher.VoucherStatus.POSTED)

        # Bank (asset) credited — balance should decrease
        self.bank_ledger.refresh_from_db()
        self.assertEqual(
            self.bank_ledger.current_balance,
            initial_bank_balance - Decimal("10000"),
        )

    def test_07_voucher_unbalanced_raises_error(self):
        """Posting unbalanced voucher raises ValueError."""
        from apps.accounts.models import Voucher, VoucherLine
        from apps.accounts.services import post_voucher, get_next_doc_number

        voucher = Voucher.objects.create(
            plant=self.plant,
            voucher_number=get_next_doc_number(self.plant, "JV", "JV"),
            voucher_date=date.today(), voucher_type="JOURNAL",
            narration="Unbalanced", prepared_by=self.user,
        )
        VoucherLine.objects.create(
            voucher=voucher, line_no=1, ledger=self.purchase_ledger,
            debit_amount=Decimal("5000"), credit_amount=Decimal("0"),
        )
        VoucherLine.objects.create(
            voucher=voucher, line_no=2, ledger=self.bank_ledger,
            debit_amount=Decimal("0"), credit_amount=Decimal("3000"),  # intentionally wrong
        )
        with self.assertRaises(ValueError):
            post_voucher(voucher, self.user)

    def test_08_voucher_cancellation(self):
        """Voucher cancellation reverses ledger balances."""
        from apps.accounts.services import post_voucher, cancel_voucher
        from apps.accounts.models import Voucher

        voucher = self._create_test_voucher()
        post_voucher(voucher, self.user)

        bank_after_post = self.bank_ledger.current_balance
        self.bank_ledger.refresh_from_db()
        original_bank = Decimal("500000")

        cancel_voucher(voucher, "Test cancellation", self.user)
        voucher.refresh_from_db()
        self.assertEqual(voucher.status, Voucher.VoucherStatus.CANCELLED)

        # Balance should be restored
        self.bank_ledger.refresh_from_db()
        self.assertEqual(self.bank_ledger.current_balance, original_bank)


# ── TEST GROUP 3: Vendor Bill & Checklist ─────────────────────────

class TestVendorBill(BaseAccountsTest):

    def _create_bill(self):
        from apps.accounts.services import receive_vendor_bill
        data = {
            "vendor_id": self.vendor.pk,
            "vendor_bill_ref": "INV/2026/001",
            "vendor_bill_date": date.today(),
            "taxable_amount": Decimal("50000"),
            "cgst_amount": Decimal("4500"),
            "sgst_amount": Decimal("4500"),
            "igst_amount": Decimal("0"),
            "total_amount": Decimal("59000"),
        }
        return receive_vendor_bill(data, self.user, self.plant)

    def test_09_vendor_bill_creation(self):
        """Vendor bill created in RECEIVED status."""
        from apps.accounts.models import VendorBill
        bill = self._create_bill()
        self.assertEqual(bill.status, VendorBill.BillStatus.RECEIVED)
        self.assertEqual(bill.vendor, self.vendor)
        self.assertEqual(bill.total_amount, Decimal("59000"))

    def test_10_checklist_completion(self):
        """Checklist score increments as points are ticked."""
        bill = self._create_bill()
        self.assertEqual(bill.checklist_score, 0)
        from apps.accounts.services import update_bill_checklist
        update_bill_checklist(bill, {
            "chk_pr_authorised": True,
            "chk_po_approved": True,
        }, self.user)
        bill.refresh_from_db()
        self.assertEqual(bill.checklist_score, 2)
        self.assertFalse(bill.checklist_complete)

    def test_11_pass_bill_incomplete_checklist_fails(self):
        """Passing a bill with incomplete checklist raises ValueError."""
        from apps.accounts.services import pass_vendor_bill
        bill = self._create_bill()
        with self.assertRaises(ValueError) as ctx:
            pass_vendor_bill(bill, self.user, self.plant)
        self.assertIn("checklist incomplete", str(ctx.exception).lower())

    def test_12_pass_bill_complete_checklist_succeeds(self):
        """Passing a bill with complete checklist creates Purchase Voucher."""
        from apps.accounts.services import update_bill_checklist, pass_vendor_bill
        from apps.accounts.models import VendorBill

        bill = self._create_bill()
        update_bill_checklist(bill, {
            "chk_pr_authorised": True, "chk_po_approved": True,
            "chk_gate_entry_done": True, "chk_mrr_qty_match": True,
            "chk_qc_passed": True, "chk_gst_copy_received": True,
            "chk_accounts_paper_ok": True, "chk_calculation_verified": True,
        }, self.user)

        result = pass_vendor_bill(bill, self.user, self.plant)
        self.assertEqual(result.status, VendorBill.BillStatus.PASSED)
        self.assertIsNotNone(result.voucher)
        # TDS 2% of 50000 taxable = 1000
        self.assertEqual(result.tds_amount, Decimal("1000.00"))
        self.assertEqual(result.net_payable, Decimal("58000.00"))

    def test_13_pass_bill_already_passed_raises(self):
        """Passing already-passed bill raises ValueError."""
        from apps.accounts.services import update_bill_checklist, pass_vendor_bill

        bill = self._create_bill()
        update_bill_checklist(bill, {
            "chk_pr_authorised": True, "chk_po_approved": True,
            "chk_gate_entry_done": True, "chk_mrr_qty_match": True,
            "chk_qc_passed": True, "chk_gst_copy_received": True,
            "chk_accounts_paper_ok": True, "chk_calculation_verified": True,
        }, self.user)
        pass_vendor_bill(bill, self.user, self.plant)

        with self.assertRaises(ValueError):
            pass_vendor_bill(bill, self.user, self.plant)


# ── TEST GROUP 4: TDS Calculation ────────────────────────────────

class TestTDSCalculation(BaseAccountsTest):

    def test_14_tds_194c_calculation(self):
        """TDS 194C @ 2% on 50000 = 1000."""
        from apps.accounts.services import calculate_tds
        result = calculate_tds(Decimal("50000"), Decimal("2.00"), "194C")
        self.assertEqual(result["tds_amount"], Decimal("1000.00"))
        self.assertEqual(result["net_amount"], Decimal("49000.00"))

    def test_15_tds_zero_rate(self):
        """Zero TDS rate returns full amount."""
        from apps.accounts.services import calculate_tds
        result = calculate_tds(Decimal("100000"), Decimal("0"), "")
        self.assertEqual(result["tds_amount"], Decimal("0"))
        self.assertEqual(result["net_amount"], Decimal("100000"))


# ── TEST GROUP 5: Vendor Payment ──────────────────────────────────

class TestVendorPayment(BaseAccountsTest):

    def _create_passed_bill(self):
        from apps.accounts.services import receive_vendor_bill, update_bill_checklist, pass_vendor_bill
        bill = receive_vendor_bill({
            "vendor_id": self.vendor.pk,
            "vendor_bill_ref": "INV/2026/002",
            "vendor_bill_date": date.today(),
            "taxable_amount": Decimal("100000"),
            "cgst_amount": Decimal("9000"),
            "sgst_amount": Decimal("9000"),
            "igst_amount": Decimal("0"),
            "total_amount": Decimal("118000"),
        }, self.user, self.plant)
        update_bill_checklist(bill, {
            "chk_pr_authorised": True, "chk_po_approved": True,
            "chk_gate_entry_done": True, "chk_mrr_qty_match": True,
            "chk_qc_passed": True, "chk_gst_copy_received": True,
            "chk_accounts_paper_ok": True, "chk_calculation_verified": True,
        }, self.user)
        return pass_vendor_bill(bill, self.user, self.plant)

    def test_16_vendor_payment_created(self):
        """Vendor payment creates BillPayment and Bank Payment Voucher."""
        from apps.accounts.services import pay_vendor
        from apps.accounts.models import BillPayment
        bill = self._create_passed_bill()
        payment = pay_vendor({
            "vendor_bill_id": str(bill.uuid),
            "bank_account_id": self.bank_ledger.pk,
            "payment_mode": "NEFT",
            "gross_amount": bill.net_payable,
            "utr_number": "UTR123456",
        }, self.user, self.plant)
        self.assertEqual(payment.status, BillPayment.PaymentStatus.PROCESSED)

    def test_17_vendor_payment_bill_fully_paid(self):
        """After full payment bill status = PAID."""
        from apps.accounts.services import pay_vendor
        from apps.accounts.models import VendorBill
        bill = self._create_passed_bill()
        pay_vendor({
            "vendor_bill_id": str(bill.uuid),
            "bank_account_id": self.bank_ledger.pk,
            "payment_mode": "NEFT",
            "gross_amount": bill.net_payable,
        }, self.user, self.plant)
        bill.refresh_from_db()
        self.assertEqual(bill.status, VendorBill.BillStatus.PAID)
        self.assertEqual(bill.outstanding, Decimal("0"))

    def test_18_vendor_payment_overpayment_rejected(self):
        """Payment exceeding outstanding raises ValueError."""
        from apps.accounts.services import pay_vendor
        bill = self._create_passed_bill()
        with self.assertRaises(ValueError):
            pay_vendor({
                "vendor_bill_id": str(bill.uuid),
                "bank_account_id": self.bank_ledger.pk,
                "payment_mode": "NEFT",
                "gross_amount": bill.net_payable + Decimal("100000"),  # overpayment
            }, self.user, self.plant)


# ── TEST GROUP 6: GST Data ────────────────────────────────────────

class TestGSTData(BaseAccountsTest):

    def test_19_gstr1_structure(self):
        """GSTR-1 data returns b2b, b2c, cdnr, summary keys."""
        from apps.accounts.services import get_gst_data_for_gstr1
        period = date.today().strftime("%m%Y")
        result = get_gst_data_for_gstr1(self.plant, period)
        self.assertIn("b2b", result)
        self.assertIn("b2c", result)
        self.assertIn("cdnr", result)
        self.assertIn("summary", result)
        self.assertEqual(result["gstin"], self.plant.gstin)

    def test_20_gstr3b_structure(self):
        """GSTR-3B data returns table_3_1_outward, table_4_itc, table_6_payment."""
        from apps.accounts.services import get_gst_data_for_gstr3b
        period = date.today().strftime("%m%Y")
        result = get_gst_data_for_gstr3b(self.plant, period)
        self.assertIn("table_3_1_outward", result)
        self.assertIn("table_4_itc", result)
        self.assertIn("table_6_payment", result)

    def test_21_accounts_dashboard(self):
        """Accounts dashboard returns all expected tiles."""
        from apps.accounts.services import get_accounts_dashboard
        result = get_accounts_dashboard(self.plant)
        expected_keys = [
            "total_outstanding_receivable", "overdue_receivable_30plus",
            "total_outstanding_payable", "overdue_payable_30plus",
            "bills_pending_passing", "receipts_this_month",
            "payments_this_month", "net_cash_flow",
        ]
        for key in expected_keys:
            self.assertIn(key, result, f"Missing key: {key}")

    def test_22_ar_ageing_empty(self):
        """Outstanding debtors returns empty list when no outstanding invoices."""
        from apps.accounts.services import get_outstanding_debtors
        result = get_outstanding_debtors(self.plant)
        self.assertIsInstance(result, list)

    def test_23_ap_ageing_empty(self):
        """Outstanding creditors returns empty list when no outstanding bills."""
        from apps.accounts.services import get_outstanding_creditors
        result = get_outstanding_creditors(self.plant)
        self.assertIsInstance(result, list)
