"""
Accounts Module Models — Section 6
Full double-entry accounting for Trident Paper Box Industries:

  Chart of Accounts: AccountGroup → LedgerAccount → CostCenter
  Vouchers: Purchase / Sales / Cash / Bank / Journal / Debit Note / Credit Note
  VoucherLine: double-entry debit/credit lines
  Vendor Bill Passing: 8-point checklist before payment released
  BillPayment: vendor payment with auto TDS deduction
  BillReceipt: customer receipts with TCS
  TDSEntry: per-section TDS tracking for 26Q filing
  GSTLedger: running CGST/SGST/IGST payable/receivable ledger
  BankReconciliation: bank statement upload + matching
  OutstandingFollowup: AR ageing + followup log
"""
import uuid
from decimal import Decimal
from django.conf import settings
from django.db import models
from django.utils import timezone
from apps.core.models import TimeStampedModel, UUIDModel, Plant


# ══════════════════════════════════════════════════════════════════
# CHART OF ACCOUNTS
# ══════════════════════════════════════════════════════════════════

class AccountGroup(UUIDModel, TimeStampedModel):
    """
    Hierarchy: Assets / Liabilities / Income / Expense / Equity.
    Can be nested (parent → child groups).
    """
    class GroupType(models.TextChoices):
        ASSETS      = "ASSETS",      "Assets"
        LIABILITIES = "LIABILITIES", "Liabilities"
        INCOME      = "INCOME",      "Income"
        EXPENSE     = "EXPENSE",     "Expense"
        EQUITY      = "EQUITY",      "Equity"

    plant        = models.ForeignKey(Plant, on_delete=models.CASCADE, related_name="account_groups")
    code         = models.CharField(max_length=20)
    name         = models.CharField(max_length=200)
    group_type   = models.CharField(max_length=15, choices=GroupType.choices)
    parent       = models.ForeignKey(
        "self", on_delete=models.SET_NULL, null=True, blank=True, related_name="children"
    )
    is_system    = models.BooleanField(
        default=False, help_text="System groups cannot be deleted"
    )
    description  = models.TextField(blank=True)

    class Meta:
        unique_together = [("plant", "code")]
        ordering = ["group_type", "code"]

    def __str__(self):
        return f"{self.code} — {self.name}"


class LedgerAccount(UUIDModel, TimeStampedModel):
    """
    Individual ledger account (GL account).
    Examples: Sundry Creditors, Sundry Debtors, Cash, HDFC Bank,
              CGST Payable, SGST Payable, IGST Payable, TDS Payable.
    """
    class AccountSubType(models.TextChoices):
        BANK           = "BANK",           "Bank Account"
        CASH           = "CASH",           "Cash Account"
        DEBTOR         = "DEBTOR",         "Sundry Debtor"
        CREDITOR       = "CREDITOR",       "Sundry Creditor"
        GST_PAYABLE    = "GST_PAYABLE",    "GST Payable"
        GST_RECEIVABLE = "GST_RECEIVABLE", "GST Receivable"
        TDS_PAYABLE    = "TDS_PAYABLE",    "TDS Payable"
        TCS_PAYABLE    = "TCS_PAYABLE",    "TCS Payable"
        INCOME         = "INCOME",         "Income"
        EXPENSE        = "EXPENSE",        "Expense"
        FIXED_ASSET    = "FIXED_ASSET",    "Fixed Asset"
        CAPITAL        = "CAPITAL",        "Capital / Equity"
        LOAN           = "LOAN",           "Loan"
        OTHER          = "OTHER",          "Other"

    plant         = models.ForeignKey(Plant, on_delete=models.CASCADE, related_name="ledger_accounts")
    group         = models.ForeignKey(AccountGroup, on_delete=models.PROTECT, related_name="ledgers")
    code          = models.CharField(max_length=20)
    name          = models.CharField(max_length=200)
    sub_type      = models.CharField(max_length=20, choices=AccountSubType.choices, default=AccountSubType.OTHER)

    # Bank-specific
    bank_name     = models.CharField(max_length=100, blank=True)
    account_number = models.CharField(max_length=50, blank=True)
    ifsc_code     = models.CharField(max_length=20, blank=True)
    branch        = models.CharField(max_length=100, blank=True)

    # Balances (updated by voucher posting)
    opening_balance = models.DecimalField(max_digits=18, decimal_places=2, default=0)
    opening_balance_type = models.CharField(
        max_length=2, choices=[("Dr", "Debit"), ("Cr", "Credit")], default="Dr"
    )
    current_balance = models.DecimalField(max_digits=18, decimal_places=2, default=0)
    balance_type    = models.CharField(
        max_length=2, choices=[("Dr", "Debit"), ("Cr", "Credit")], default="Dr"
    )

    is_active     = models.BooleanField(default=True)
    is_system     = models.BooleanField(default=False, help_text="System accounts cannot be deleted")
    notes         = models.TextField(blank=True)

    class Meta:
        unique_together = [("plant", "code")]
        ordering = ["code"]

    def __str__(self):
        return f"{self.code} — {self.name}"


class CostCenter(TimeStampedModel):
    """Department-wise cost tracking (e.g. Production, Sales, Admin, Quality)."""
    plant       = models.ForeignKey(Plant, on_delete=models.CASCADE, related_name="cost_centers")
    code        = models.CharField(max_length=20)
    name        = models.CharField(max_length=100)
    head        = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="cost_center_head"
    )
    is_active   = models.BooleanField(default=True)

    class Meta:
        unique_together = [("plant", "code")]
        ordering = ["code"]

    def __str__(self):
        return f"{self.code} — {self.name}"


# ══════════════════════════════════════════════════════════════════
# VOUCHER (HEADER)
# ══════════════════════════════════════════════════════════════════

class Voucher(UUIDModel, TimeStampedModel):
    """
    Voucher header. Supports all accounting entry types.
    Every financial transaction passes through a voucher.
    """
    class VoucherType(models.TextChoices):
        PURCHASE      = "PURCHASE",      "Purchase Voucher (PV)"
        SALES         = "SALES",         "Sales Voucher (SV)"
        CASH_PAYMENT  = "CASH_PAYMENT",  "Cash Payment (CP)"
        CASH_RECEIPT  = "CASH_RECEIPT",  "Cash Receipt (CR)"
        BANK_PAYMENT  = "BANK_PAYMENT",  "Bank Payment (BP)"
        BANK_RECEIPT  = "BANK_RECEIPT",  "Bank Receipt (BR)"
        JOURNAL       = "JOURNAL",       "Journal Entry (JV)"
        DEBIT_NOTE    = "DEBIT_NOTE",    "Debit Note (DN)"
        CREDIT_NOTE   = "CREDIT_NOTE",   "Credit Note (CN)"
        CONTRA        = "CONTRA",        "Contra Entry"
        OPENING       = "OPENING",       "Opening Balance Entry"

    class VoucherStatus(models.TextChoices):
        DRAFT     = "DRAFT",     "Draft"
        PENDING   = "PENDING",   "Pending Approval"
        APPROVED  = "APPROVED",  "Approved"
        POSTED    = "POSTED",    "Posted"
        CANCELLED = "CANCELLED", "Cancelled"

    plant            = models.ForeignKey(Plant, on_delete=models.CASCADE, related_name="vouchers")
    voucher_number   = models.CharField(max_length=50, unique=True)
    voucher_date     = models.DateField()
    voucher_type     = models.CharField(max_length=20, choices=VoucherType.choices)
    status           = models.CharField(
        max_length=15, choices=VoucherStatus.choices, default=VoucherStatus.DRAFT
    )

    # Narration / description
    narration        = models.TextField(help_text="Description of this transaction")
    reference_number = models.CharField(max_length=100, blank=True, help_text="Cheque no / UTR / invoice ref")
    reference_date   = models.DateField(null=True, blank=True)

    # Source document links
    vendor           = models.ForeignKey(
        "masters.Vendor", on_delete=models.SET_NULL, null=True, blank=True, related_name="vouchers"
    )
    customer         = models.ForeignKey(
        "masters.Customer", on_delete=models.SET_NULL, null=True, blank=True, related_name="vouchers"
    )
    mrr              = models.ForeignKey(
        "purchase.MRR", on_delete=models.SET_NULL, null=True, blank=True, related_name="vouchers"
    )
    invoice          = models.ForeignKey(
        "sales.Invoice", on_delete=models.SET_NULL, null=True, blank=True, related_name="vouchers"
    )

    # Financial totals
    total_debit      = models.DecimalField(max_digits=18, decimal_places=2, default=0)
    total_credit     = models.DecimalField(max_digits=18, decimal_places=2, default=0)

    # Approval
    prepared_by      = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, related_name="vouchers_prepared"
    )
    approved_by      = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="vouchers_approved"
    )
    approved_at      = models.DateTimeField(null=True, blank=True)
    posted_at        = models.DateTimeField(null=True, blank=True)
    cancellation_reason = models.TextField(blank=True)

    # GST data (for GSTR-1 / GSTR-3B)
    is_gst_entry     = models.BooleanField(default=False)
    gst_return_period = models.CharField(
        max_length=7, blank=True, help_text="MMYYYY e.g. 012026 — month this entry belongs to"
    )

    cost_center      = models.ForeignKey(
        CostCenter, on_delete=models.SET_NULL, null=True, blank=True, related_name="vouchers"
    )

    class Meta:
        ordering = ["-voucher_date", "-created_at"]

    def __str__(self):
        return f"{self.voucher_number} ({self.get_voucher_type_display()}) ₹{self.total_debit}"


class VoucherLine(models.Model):
    """
    Double-entry line. Debit XOR Credit must be non-zero on each line.
    Sum of all debits must equal sum of all credits at voucher level.
    """
    voucher     = models.ForeignKey(Voucher, on_delete=models.CASCADE, related_name="lines")
    line_no     = models.PositiveIntegerField(default=1)
    ledger      = models.ForeignKey(LedgerAccount, on_delete=models.PROTECT, related_name="voucher_lines")
    cost_center = models.ForeignKey(
        CostCenter, on_delete=models.SET_NULL, null=True, blank=True
    )
    debit_amount  = models.DecimalField(max_digits=18, decimal_places=2, default=0)
    credit_amount = models.DecimalField(max_digits=18, decimal_places=2, default=0)
    narration     = models.CharField(max_length=500, blank=True)

    # GST breakdown (populated for Purchase/Sales vouchers)
    cgst_amount   = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    sgst_amount   = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    igst_amount   = models.DecimalField(max_digits=15, decimal_places=2, default=0)

    class Meta:
        ordering = ["line_no"]

    def __str__(self):
        side = f"Dr {self.debit_amount}" if self.debit_amount else f"Cr {self.credit_amount}"
        return f"{self.voucher.voucher_number} L{self.line_no} — {self.ledger.name} {side}"


# ══════════════════════════════════════════════════════════════════
# VENDOR BILL PASSING
# ══════════════════════════════════════════════════════════════════

class VendorBill(UUIDModel, TimeStampedModel):
    """
    Vendor bill (purchase invoice) passing with mandatory 8-point checklist.
    Only after all checkpoints pass can a BillPayment be created.

    8-point checklist:
      1. PR authorised
      2. PO approved
      3. Gate entry done
      4. MRR quantity matches PO
      5. QC passed (no rejected lots)
      6. GST transporter copy received
      7. Accounts — paper seen OK
      8. Calculation verified (rate × qty + GST = bill amount)
    """
    class BillStatus(models.TextChoices):
        RECEIVED    = "RECEIVED",    "Bill Received"
        UNDER_CHECK = "UNDER_CHECK", "Under Verification"
        PASSED      = "PASSED",      "Bill Passed"
        ON_HOLD     = "ON_HOLD",     "On Hold"
        REJECTED    = "REJECTED",    "Rejected"
        PAID        = "PAID",        "Paid"
        PARTIALLY_PAID = "PARTIALLY_PAID", "Partially Paid"

    plant           = models.ForeignKey(Plant, on_delete=models.CASCADE, related_name="vendor_bills")
    bill_number     = models.CharField(max_length=50, unique=True, help_text="Internal bill reference")
    vendor_bill_ref = models.CharField(max_length=100, help_text="Vendor's own invoice number")
    vendor_bill_date = models.DateField()
    received_date   = models.DateField()
    status          = models.CharField(max_length=20, choices=BillStatus.choices, default=BillStatus.RECEIVED)

    # Source documents
    vendor          = models.ForeignKey("masters.Vendor", on_delete=models.PROTECT, related_name="bills")
    mrr             = models.ForeignKey(
        "purchase.MRR", on_delete=models.SET_NULL, null=True, blank=True, related_name="vendor_bills"
    )

    # Bill amounts (as per vendor's invoice)
    taxable_amount  = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    cgst_amount     = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    sgst_amount     = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    igst_amount     = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    tds_amount      = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    total_amount    = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    net_payable     = models.DecimalField(
        max_digits=15, decimal_places=2, default=0,
        help_text="total_amount - tds_amount"
    )
    amount_paid     = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    outstanding     = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    due_date        = models.DateField(null=True, blank=True)

    # TDS details
    tds_section     = models.CharField(max_length=20, blank=True, help_text="194C / 194J etc.")
    tds_rate        = models.DecimalField(max_digits=5, decimal_places=2, default=0)

    # 8-Point Checklist (booleans)
    chk_pr_authorised       = models.BooleanField(default=False, verbose_name="1. PR Authorised")
    chk_po_approved         = models.BooleanField(default=False, verbose_name="2. PO Approved")
    chk_gate_entry_done     = models.BooleanField(default=False, verbose_name="3. Gate Entry Done")
    chk_mrr_qty_match       = models.BooleanField(default=False, verbose_name="4. MRR Qty Matches PO")
    chk_qc_passed           = models.BooleanField(default=False, verbose_name="5. QC Passed")
    chk_gst_copy_received   = models.BooleanField(default=False, verbose_name="6. GST Transporter Copy Received")
    chk_accounts_paper_ok   = models.BooleanField(default=False, verbose_name="7. Accounts Paper Seen OK")
    chk_calculation_verified = models.BooleanField(default=False, verbose_name="8. Calculation Verified")

    # Checklist notes
    checklist_remarks = models.TextField(blank=True)
    hold_reason       = models.TextField(blank=True)

    # Voucher generated on bill passing
    voucher         = models.OneToOneField(
        Voucher, on_delete=models.SET_NULL, null=True, blank=True, related_name="vendor_bill"
    )

    passed_by       = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="bills_passed"
    )
    passed_at       = models.DateTimeField(null=True, blank=True)
    received_by     = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, related_name="bills_received"
    )

    class Meta:
        ordering = ["-received_date", "-created_at"]

    def __str__(self):
        return f"{self.bill_number} — {self.vendor.name} ₹{self.total_amount} ({self.status})"

    @property
    def checklist_complete(self):
        return all([
            self.chk_pr_authorised, self.chk_po_approved, self.chk_gate_entry_done,
            self.chk_mrr_qty_match, self.chk_qc_passed, self.chk_gst_copy_received,
            self.chk_accounts_paper_ok, self.chk_calculation_verified,
        ])

    @property
    def checklist_score(self):
        checks = [
            self.chk_pr_authorised, self.chk_po_approved, self.chk_gate_entry_done,
            self.chk_mrr_qty_match, self.chk_qc_passed, self.chk_gst_copy_received,
            self.chk_accounts_paper_ok, self.chk_calculation_verified,
        ]
        return sum(1 for c in checks if c)


# ══════════════════════════════════════════════════════════════════
# BILL PAYMENT (VENDOR)
# ══════════════════════════════════════════════════════════════════

class BillPayment(UUIDModel, TimeStampedModel):
    """
    Vendor payment entry. Requires bill to be in PASSED status.
    Auto-calculates TDS from vendor master.
    """
    class PaymentMode(models.TextChoices):
        NEFT    = "NEFT",   "NEFT"
        RTGS    = "RTGS",   "RTGS"
        IMPS    = "IMPS",   "IMPS"
        CHEQUE  = "CHEQUE", "Cheque"
        CASH    = "CASH",   "Cash"
        UPI     = "UPI",    "UPI"
        DD      = "DD",     "Demand Draft"

    class PaymentStatus(models.TextChoices):
        DRAFT       = "DRAFT",      "Draft"
        APPROVED    = "APPROVED",   "Approved"
        PROCESSED   = "PROCESSED",  "Processed"
        CLEARED     = "CLEARED",    "Bank Cleared"
        BOUNCED     = "BOUNCED",    "Bounced / Failed"
        CANCELLED   = "CANCELLED",  "Cancelled"

    plant           = models.ForeignKey(Plant, on_delete=models.CASCADE, related_name="bill_payments")
    payment_number  = models.CharField(max_length=50, unique=True)
    payment_date    = models.DateField()
    status          = models.CharField(
        max_length=15, choices=PaymentStatus.choices, default=PaymentStatus.DRAFT
    )
    payment_mode    = models.CharField(max_length=10, choices=PaymentMode.choices)

    vendor          = models.ForeignKey("masters.Vendor", on_delete=models.PROTECT, related_name="payments")
    vendor_bill     = models.ForeignKey(VendorBill, on_delete=models.PROTECT, related_name="payments")

    # Bank details
    bank_account    = models.ForeignKey(
        LedgerAccount, on_delete=models.PROTECT, related_name="payments_made",
        limit_choices_to={"sub_type__in": ["BANK", "CASH"]}
    )
    cheque_number   = models.CharField(max_length=20, blank=True)
    cheque_date     = models.DateField(null=True, blank=True)
    utr_number      = models.CharField(max_length=50, blank=True, help_text="UTR / transaction ID")

    # Amounts
    gross_amount    = models.DecimalField(max_digits=15, decimal_places=2)
    tds_section     = models.CharField(max_length=20, blank=True)
    tds_rate        = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    tds_amount      = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    net_amount      = models.DecimalField(
        max_digits=15, decimal_places=2, help_text="Actual cash out = gross - TDS"
    )

    # Clearance
    bank_cleared_date = models.DateField(null=True, blank=True)
    bank_statement_ref = models.CharField(max_length=100, blank=True)

    # Voucher
    voucher         = models.OneToOneField(
        Voucher, on_delete=models.SET_NULL, null=True, blank=True, related_name="bill_payment"
    )
    approved_by     = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="payments_approved"
    )
    approved_at     = models.DateTimeField(null=True, blank=True)
    prepared_by     = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, related_name="payments_prepared"
    )
    remarks         = models.TextField(blank=True)

    class Meta:
        ordering = ["-payment_date", "-created_at"]

    def __str__(self):
        return f"{self.payment_number} — {self.vendor.name} ₹{self.net_amount}"


# ══════════════════════════════════════════════════════════════════
# BILL RECEIPT (CUSTOMER)
# ══════════════════════════════════════════════════════════════════

class BillReceipt(UUIDModel, TimeStampedModel):
    """
    Customer payment receipt. Knock-off against outstanding invoices.
    TCS deducted at source (from customer master rate).
    """
    class ReceiptMode(models.TextChoices):
        NEFT    = "NEFT",   "NEFT"
        RTGS    = "RTGS",   "RTGS"
        IMPS    = "IMPS",   "IMPS"
        CHEQUE  = "CHEQUE", "Cheque"
        CASH    = "CASH",   "Cash"
        UPI     = "UPI",    "UPI"
        DD      = "DD",     "Demand Draft"

    class ReceiptStatus(models.TextChoices):
        DRAFT     = "DRAFT",     "Draft"
        CONFIRMED = "CONFIRMED", "Confirmed"
        CLEARED   = "CLEARED",   "Bank Cleared"
        BOUNCED   = "BOUNCED",   "Cheque Bounced"
        CANCELLED = "CANCELLED", "Cancelled"

    plant           = models.ForeignKey(Plant, on_delete=models.CASCADE, related_name="bill_receipts")
    receipt_number  = models.CharField(max_length=50, unique=True)
    receipt_date    = models.DateField()
    status          = models.CharField(
        max_length=15, choices=ReceiptStatus.choices, default=ReceiptStatus.DRAFT
    )
    receipt_mode    = models.CharField(max_length=10, choices=ReceiptMode.choices)

    customer        = models.ForeignKey("masters.Customer", on_delete=models.PROTECT, related_name="receipts")

    # Bank account credited
    bank_account    = models.ForeignKey(
        LedgerAccount, on_delete=models.PROTECT, related_name="receipts_received",
        limit_choices_to={"sub_type__in": ["BANK", "CASH"]}
    )
    cheque_number   = models.CharField(max_length=20, blank=True)
    cheque_date     = models.DateField(null=True, blank=True)
    utr_number      = models.CharField(max_length=50, blank=True)

    # Amounts
    gross_amount    = models.DecimalField(max_digits=15, decimal_places=2)
    tcs_rate        = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    tcs_amount      = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    tds_by_customer = models.DecimalField(
        max_digits=15, decimal_places=2, default=0,
        help_text="TDS deducted by customer (they send net, we book TDS as receivable)"
    )
    net_amount      = models.DecimalField(max_digits=15, decimal_places=2)

    bank_cleared_date   = models.DateField(null=True, blank=True)
    bank_statement_ref  = models.CharField(max_length=100, blank=True)
    bounce_reason       = models.CharField(max_length=300, blank=True)

    voucher         = models.OneToOneField(
        Voucher, on_delete=models.SET_NULL, null=True, blank=True, related_name="bill_receipt"
    )
    received_by     = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, related_name="receipts_recorded"
    )
    remarks         = models.TextField(blank=True)

    class Meta:
        ordering = ["-receipt_date", "-created_at"]

    def __str__(self):
        return f"{self.receipt_number} — {self.customer.name} ₹{self.net_amount}"


class ReceiptAllocation(models.Model):
    """
    Allocation of a receipt against one or more invoices (knock-off).
    """
    receipt     = models.ForeignKey(BillReceipt, on_delete=models.CASCADE, related_name="allocations")
    invoice     = models.ForeignKey("sales.Invoice", on_delete=models.PROTECT, related_name="receipt_allocations")
    allocated_amount = models.DecimalField(max_digits=15, decimal_places=2)

    class Meta:
        unique_together = [("receipt", "invoice")]

    def __str__(self):
        return f"{self.receipt.receipt_number} → {self.invoice.invoice_number} ₹{self.allocated_amount}"


# ══════════════════════════════════════════════════════════════════
# TDS ENTRY
# ══════════════════════════════════════════════════════════════════

class TDSEntry(UUIDModel, TimeStampedModel):
    """
    Per-deduction TDS record for 26Q filing.
    Created automatically when a BillPayment is processed.
    """
    class TDSSection(models.TextChoices):
        SEC_194C = "194C", "Section 194C — Contractors"
        SEC_194J = "194J", "Section 194J — Professional/Technical Fees"
        SEC_194I = "194I", "Section 194I — Rent"
        SEC_194H = "194H", "Section 194H — Commission"
        SEC_194A = "194A", "Section 194A — Interest"
        SEC_194D = "194D", "Section 194D — Insurance Commission"
        OTHER    = "OTHER", "Other Section"

    plant           = models.ForeignKey(Plant, on_delete=models.CASCADE, related_name="tds_entries")
    payment         = models.ForeignKey(BillPayment, on_delete=models.CASCADE, related_name="tds_entries")
    vendor          = models.ForeignKey("masters.Vendor", on_delete=models.PROTECT, related_name="tds_entries")

    tds_section     = models.CharField(max_length=10, choices=TDSSection.choices)
    tds_rate        = models.DecimalField(max_digits=5, decimal_places=2)
    gross_payment   = models.DecimalField(max_digits=15, decimal_places=2)
    tds_amount      = models.DecimalField(max_digits=15, decimal_places=2)
    payment_date    = models.DateField()
    deduction_date  = models.DateField()

    # For 26Q: vendor PAN mandatory
    vendor_pan      = models.CharField(max_length=10, blank=True)
    vendor_name     = models.CharField(max_length=200)  # snapshot at time of payment

    # Deposit to govt
    challan_number  = models.CharField(max_length=50, blank=True)
    challan_date    = models.DateField(null=True, blank=True)
    deposit_bank    = models.CharField(max_length=100, blank=True)
    is_deposited    = models.BooleanField(default=False)
    quarter         = models.CharField(
        max_length=2, blank=True,
        help_text="Q1/Q2/Q3/Q4 for 26Q filing"
    )
    financial_year  = models.CharField(max_length=9, blank=True, help_text="e.g. 2025-26")

    class Meta:
        ordering = ["-payment_date"]

    def __str__(self):
        return f"TDS u/s {self.tds_section} — {self.vendor_name} ₹{self.tds_amount}"


# ══════════════════════════════════════════════════════════════════
# GST LEDGER
# ══════════════════════════════════════════════════════════════════

class GSTLedger(UUIDModel, TimeStampedModel):
    """
    Running GST payable/receivable ledger.
    Each voucher posting creates a GSTLedger entry.
    Used for GSTR-1, GSTR-3B, GSTR-2B reconciliation.
    """
    class GSTType(models.TextChoices):
        CGST       = "CGST",       "CGST"
        SGST       = "SGST",       "SGST"
        IGST       = "IGST",       "IGST"
        CESS       = "CESS",       "GST Cess"

    class EntryType(models.TextChoices):
        OUTPUT     = "OUTPUT",     "Output (Sales — Payable)"
        INPUT      = "INPUT",      "Input (Purchase — Receivable/ITC)"
        REVERSAL   = "REVERSAL",   "Reversal"
        PAYMENT    = "PAYMENT",    "GST Payment to Govt"

    plant           = models.ForeignKey(Plant, on_delete=models.CASCADE, related_name="gst_ledger_entries")
    voucher         = models.ForeignKey(Voucher, on_delete=models.CASCADE, related_name="gst_entries")
    entry_type      = models.CharField(max_length=15, choices=EntryType.choices)
    gst_type        = models.CharField(max_length=5, choices=GSTType.choices)
    amount          = models.DecimalField(max_digits=15, decimal_places=2)
    entry_date      = models.DateField()

    # Source details
    taxable_amount  = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    gst_rate        = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    hsn_code        = models.CharField(max_length=10, blank=True)

    # Party
    vendor          = models.ForeignKey(
        "masters.Vendor", on_delete=models.SET_NULL, null=True, blank=True
    )
    customer        = models.ForeignKey(
        "masters.Customer", on_delete=models.SET_NULL, null=True, blank=True
    )
    party_gstin     = models.CharField(max_length=15, blank=True)

    # Return period
    return_period   = models.CharField(max_length=7, blank=True, help_text="MMYYYY")
    is_filed        = models.BooleanField(default=False)

    class Meta:
        ordering = ["-entry_date"]

    def __str__(self):
        return f"{self.gst_type} {self.entry_type} ₹{self.amount} — {self.entry_date}"


# ══════════════════════════════════════════════════════════════════
# BANK RECONCILIATION
# ══════════════════════════════════════════════════════════════════

class BankStatement(UUIDModel, TimeStampedModel):
    """
    Uploaded bank statement for reconciliation.
    """
    plant           = models.ForeignKey(Plant, on_delete=models.CASCADE, related_name="bank_statements")
    bank_account    = models.ForeignKey(
        LedgerAccount, on_delete=models.PROTECT, related_name="bank_statements",
        limit_choices_to={"sub_type": "BANK"}
    )
    statement_month = models.CharField(max_length=7, help_text="MMYYYY e.g. 012026")
    opening_balance = models.DecimalField(max_digits=15, decimal_places=2)
    closing_balance = models.DecimalField(max_digits=15, decimal_places=2)
    statement_file  = models.FileField(upload_to="bank_statements/", null=True, blank=True)
    uploaded_by     = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True
    )
    is_reconciled   = models.BooleanField(default=False)

    class Meta:
        unique_together = [("bank_account", "statement_month")]
        ordering = ["-statement_month"]

    def __str__(self):
        return f"{self.bank_account.name} — {self.statement_month}"


class BankReconciliation(TimeStampedModel):
    """
    Line-by-line bank statement entry matched against voucher.
    """
    class MatchStatus(models.TextChoices):
        UNMATCHED  = "UNMATCHED",  "Unmatched"
        MATCHED    = "MATCHED",    "Matched"
        IGNORED    = "IGNORED",    "Ignored (bank charges etc.)"

    statement       = models.ForeignKey(BankStatement, on_delete=models.CASCADE, related_name="lines")
    transaction_date = models.DateField()
    description     = models.CharField(max_length=500)
    debit_amount    = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    credit_amount   = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    balance         = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    bank_reference  = models.CharField(max_length=100, blank=True)

    # Match
    match_status    = models.CharField(
        max_length=15, choices=MatchStatus.choices, default=MatchStatus.UNMATCHED
    )
    matched_voucher = models.ForeignKey(
        Voucher, on_delete=models.SET_NULL, null=True, blank=True, related_name="bank_recon_lines"
    )
    matched_by      = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True
    )
    matched_at      = models.DateTimeField(null=True, blank=True)
    notes           = models.CharField(max_length=300, blank=True)

    class Meta:
        ordering = ["transaction_date"]

    def __str__(self):
        return f"{self.statement.bank_account.name} {self.transaction_date} {self.description[:50]}"


# ══════════════════════════════════════════════════════════════════
# OUTSTANDING FOLLOWUP (AR AGEING)
# ══════════════════════════════════════════════════════════════════

class OutstandingFollowup(UUIDModel, TimeStampedModel):
    """
    AR followup log for outstanding invoices.
    Auto-created by Celery for 30/60/90+ day buckets.
    Accounts team logs each call/email action here.
    """
    class FollowupAction(models.TextChoices):
        CALL    = "CALL",    "Phone Call"
        EMAIL   = "EMAIL",   "Email Sent"
        VISIT   = "VISIT",   "Physical Visit"
        WHATSAPP = "WHATSAPP", "WhatsApp"
        LEGAL   = "LEGAL",   "Legal Notice"
        ESCALATED = "ESCALATED", "Escalated to Management"

    class OutstandingBucket(models.TextChoices):
        CURRENT    = "CURRENT",   "Current (0-30 days)"
        DAYS_30_60 = "30_60",     "30-60 Days"
        DAYS_60_90 = "60_90",     "60-90 Days"
        OVER_90    = "OVER_90",   "Over 90 Days"

    plant           = models.ForeignKey(Plant, on_delete=models.CASCADE, related_name="ar_followups")
    customer        = models.ForeignKey("masters.Customer", on_delete=models.PROTECT, related_name="ar_followups")
    invoice         = models.ForeignKey("sales.Invoice", on_delete=models.PROTECT, related_name="ar_followups")

    # Ageing at time of followup
    outstanding_amount = models.DecimalField(max_digits=15, decimal_places=2)
    overdue_days    = models.IntegerField(default=0)
    bucket          = models.CharField(max_length=10, choices=OutstandingBucket.choices)

    # Action taken
    action          = models.CharField(max_length=15, choices=FollowupAction.choices)
    action_date     = models.DateField()
    done_by         = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, related_name="ar_followups"
    )
    contact_person  = models.CharField(max_length=100, blank=True)
    summary         = models.TextField()
    promised_date   = models.DateField(null=True, blank=True, help_text="Customer promised payment by this date")
    promised_amount = models.DecimalField(max_digits=15, decimal_places=2, null=True, blank=True)
    next_followup_date = models.DateField(null=True, blank=True)
    is_resolved     = models.BooleanField(default=False)

    class Meta:
        ordering = ["-action_date", "-created_at"]

    def __str__(self):
        return (
            f"{self.customer.name} — INV {self.invoice.invoice_number} "
            f"₹{self.outstanding_amount} ({self.bucket})"
        )
