"""
Accounts Module Celery Tasks — Section 6
"""
from celery import shared_task
from django.utils import timezone
import logging

logger = logging.getLogger(__name__)


@shared_task(name="accounts.send_overdue_reminders")
def send_overdue_reminders():
    """
    Daily Celery task: Send email reminders to customers with invoices
    overdue 30+ days. Runs at 9:00 AM.
    """
    from apps.core.models import Plant
    from apps.accounts.services import send_overdue_reminder_emails

    total_sent = 0
    for plant in Plant.objects.filter(is_active=True):
        try:
            count = send_overdue_reminder_emails(plant)
            total_sent += count
            logger.info(f"[ACCOUNTS] Sent {count} overdue reminders for plant {plant.code}")
        except Exception as e:
            logger.error(f"[ACCOUNTS] Error sending reminders for {plant.code}: {e}")

    return {"emails_sent": total_sent, "run_at": str(timezone.now())}


@shared_task(name="accounts.auto_flag_overdue_bills")
def auto_flag_overdue_bills():
    """
    Daily task: Flag vendor bills whose due date has passed but are still unpaid.
    Creates notifications for accounts team.
    """
    from datetime import date
    from apps.accounts.models import VendorBill
    from apps.core.models import Notification

    today = date.today()
    overdue_bills = VendorBill.objects.filter(
        due_date__lt=today,
        status__in=["PASSED", "PARTIALLY_PAID"],
    ).select_related("vendor", "plant")

    flagged = 0
    for bill in overdue_bills:
        # Create notification for accounts staff (no FK to specific user — broadcast)
        Notification.objects.get_or_create(
            title=f"Overdue AP: {bill.bill_number}",
            object_id=str(bill.pk),
            defaults={
                "user_id": None,  # System notification — accounts team picks up
                "message": (
                    f"Vendor bill {bill.bill_number} ({bill.vendor.name}) "
                    f"₹{bill.outstanding} is overdue since {bill.due_date}."
                ),
                "module": "accounts",
            }
        )
        flagged += 1

    logger.info(f"[ACCOUNTS] Flagged {flagged} overdue AP bills")
    return {"overdue_bills_flagged": flagged, "run_at": str(timezone.now())}


@shared_task(name="accounts.generate_monthly_gst_summary")
def generate_monthly_gst_summary():
    """
    Monthly task (run on 2nd of each month): Generate GSTR-1 / GSTR-3B
    summary for the previous month and notify the accounts team.
    """
    from datetime import date
    from apps.core.models import Plant, Notification
    from apps.accounts.services import get_gst_data_for_gstr1, get_gst_data_for_gstr3b

    today = date.today()
    # Previous month
    if today.month == 1:
        prev_month = 12
        prev_year = today.year - 1
    else:
        prev_month = today.month - 1
        prev_year = today.year

    return_period = f"{prev_month:02d}{prev_year}"

    results = []
    for plant in Plant.objects.filter(is_active=True):
        try:
            gstr1 = get_gst_data_for_gstr1(plant, return_period)
            gstr3b = get_gst_data_for_gstr3b(plant, return_period)
            results.append({
                "plant": plant.code,
                "return_period": return_period,
                "gstr1_invoices": gstr1["summary"]["total_invoices"],
                "gstr3b_payable": gstr3b["table_6_payment"]["total_payable"],
            })
            logger.info(
                f"[ACCOUNTS] GST summary for {plant.code} period {return_period}: "
                f"GSTR-1 invoices={gstr1['summary']['total_invoices']}, "
                f"GSTR-3B payable=₹{gstr3b['table_6_payment']['total_payable']}"
            )
        except Exception as e:
            logger.error(f"[ACCOUNTS] GST summary error for {plant.code}: {e}")

    return {"period": return_period, "plants_processed": results}


@shared_task(name="accounts.tds_deposit_reminder")
def tds_deposit_reminder():
    """
    Runs on 5th of every month: Remind accounts team to deposit TDS by 7th.
    """
    from datetime import date
    from apps.accounts.models import TDSEntry
    from apps.core.models import Notification

    today = date.today()
    if today.month == 1:
        prev_month, prev_year = 12, today.year - 1
    else:
        prev_month, prev_year = today.month - 1, today.year

    quarter = _quarter_for_month(prev_month)
    fy_start = prev_year if prev_month >= 4 else prev_year - 1
    financial_year = f"{fy_start}-{str(fy_start + 1)[2:]}"

    undeposited = TDSEntry.objects.filter(
        is_deposited=False,
        payment_date__month=prev_month,
        payment_date__year=prev_year,
    )
    total_tds = sum(e.tds_amount for e in undeposited)
    count = undeposited.count()

    if count > 0:
        logger.warning(
            f"[ACCOUNTS] TDS deposit reminder: {count} entries, total ₹{total_tds} pending deposit"
        )

    return {
        "undeposited_count": count,
        "total_tds": float(total_tds),
        "month": f"{prev_month:02d}/{prev_year}",
    }


def _quarter_for_month(month):
    if month in (4, 5, 6):
        return "Q1"
    if month in (7, 8, 9):
        return "Q2"
    if month in (10, 11, 12):
        return "Q3"
    return "Q4"


@shared_task(name="accounts.send_overdue_payment_sms")
def send_overdue_payment_sms():
    """
    Daily Celery task (9:10 AM): SMS customers with overdue invoices.

    For each active plant, finds invoices with outstanding_amount > 0
    whose due_date is in the past. Sends one SMS per invoice to the
    customer's registered mobile number.

    Runs AFTER send_overdue_reminders (email) to avoid double-alerting
    on the same schedule tick.
    """
    from datetime import date
    from apps.sales.models import Invoice
    from apps.core.sms import SMSService
    from apps.core.models import Plant

    today = date.today()
    sms_sent = 0
    sms_failed = 0

    overdue_invoices = (
        Invoice.objects.select_related("customer", "plant")
        .filter(
            outstanding_amount__gt=0,
            due_date__lt=today,
            status__in=["PAYMENT_PENDING", "PARTIALLY_PAID", "CONFIRMED", "IRN_DONE"],
        )
        .order_by("customer", "due_date")
    )

    if not overdue_invoices.exists():
        logger.info("[SMS-OVERDUE] No overdue invoices found.")
        return {"sms_sent": 0, "sms_failed": 0, "run_at": str(timezone.now())}

    for invoice in overdue_invoices:
        customer = invoice.customer
        mobile   = customer.mobile or customer.phone

        if not mobile:
            logger.debug(
                "[SMS-OVERDUE] Skipping invoice %s — customer %s has no mobile",
                invoice.invoice_number, customer.code,
            )
            continue

        overdue_days = (today - invoice.due_date).days
        amount_str   = f"Rs {int(invoice.outstanding_amount):,}"

        # Contact number to call — use plant's phone if available
        plant_phone = invoice.plant.company.phone if hasattr(invoice.plant, "company") else ""
        contact_str = f"Contact: {plant_phone}" if plant_phone else "Please contact us"

        message = (
            f"Reminder: Invoice {invoice.invoice_number} of {amount_str} "
            f"is overdue by {overdue_days} day{'s' if overdue_days != 1 else ''}. "
            f"{contact_str}. - Trident ERP"
        )

        try:
            result = SMSService.send(mobile, message)
            if result["success"]:
                sms_sent += 1
                logger.info(
                    "[SMS-OVERDUE] SMS sent for invoice %s to customer %s",
                    invoice.invoice_number, customer.code,
                )
            else:
                sms_failed += 1
                logger.warning(
                    "[SMS-OVERDUE] SMS failed for invoice %s to customer %s",
                    invoice.invoice_number, customer.code,
                )
        except Exception as exc:
            sms_failed += 1
            logger.error(
                "[SMS-OVERDUE] Exception sending SMS for invoice %s: %s",
                invoice.invoice_number, exc,
            )

    logger.info(
        "[SMS-OVERDUE] Done: %d sent, %d failed", sms_sent, sms_failed
    )
    return {
        "sms_sent":  sms_sent,
        "sms_failed": sms_failed,
        "run_at":    str(timezone.now()),
    }
