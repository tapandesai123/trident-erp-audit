"""Accounts Module ViewSets — Section 6"""
from rest_framework import viewsets, filters, status
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from django_filters.rest_framework import DjangoFilterBackend

from apps.accounts.models import (
    AccountGroup, LedgerAccount, CostCenter,
    Voucher, VoucherLine,
    VendorBill, BillPayment,
    BillReceipt, ReceiptAllocation,
    TDSEntry, GSTLedger,
    BankStatement, BankReconciliation,
    OutstandingFollowup,
)
from apps.accounts.api.serializers import (
    AccountGroupListSerializer, AccountGroupDetailSerializer, AccountGroupCreateSerializer,
    LedgerAccountListSerializer, LedgerAccountDetailSerializer, LedgerAccountCreateSerializer,
    CostCenterSerializer, CostCenterCreateSerializer,
    VoucherListSerializer, VoucherDetailSerializer, VoucherCreateSerializer,
    VoucherLineSerializer,
    VendorBillListSerializer, VendorBillDetailSerializer, VendorBillCreateSerializer,
    BillChecklistSerializer,
    BillPaymentListSerializer, BillPaymentDetailSerializer, BillPaymentCreateSerializer,
    BillReceiptListSerializer, BillReceiptDetailSerializer, BillReceiptCreateSerializer,
    TDSEntryListSerializer, TDSEntryDetailSerializer,
    GSTLedgerListSerializer, GSTLedgerDetailSerializer,
    BankStatementListSerializer, BankStatementDetailSerializer,
    BankStatementCreateSerializer, BankReconLineCreateSerializer, BankReconMatchSerializer,
    OutstandingFollowupListSerializer, OutstandingFollowupDetailSerializer,
    OutstandingFollowupCreateSerializer,
)
import apps.accounts.services as services


def _plant(request):
    """Get plant from request.user.plant."""
    return request.user.plant


# ── Account Group ─────────────────────────────────────────────────

class AccountGroupViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    filter_backends    = [filters.SearchFilter, DjangoFilterBackend]
    search_fields      = ["code", "name"]
    filterset_fields   = ["group_type", "plant"]

    def get_queryset(self):
        return AccountGroup.objects.filter(plant=_plant(self.request)).select_related("parent")

    def get_serializer_class(self):
        if self.action == "retrieve":
            return AccountGroupDetailSerializer
        if self.action in ("create", "update", "partial_update"):
            return AccountGroupCreateSerializer
        return AccountGroupListSerializer

    def create(self, request):
        ser = AccountGroupCreateSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        d = ser.validated_data
        plant = _plant(request)
        obj = AccountGroup.objects.create(
            plant=plant,
            code=d["code"], name=d["name"], group_type=d["group_type"],
            parent_id=d.get("parent_id"), description=d.get("description", ""),
        )
        return Response(AccountGroupDetailSerializer(obj).data, status=201)


# ── Ledger Account ────────────────────────────────────────────────

class LedgerAccountViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    filter_backends    = [filters.SearchFilter, DjangoFilterBackend]
    search_fields      = ["code", "name", "account_number"]
    filterset_fields   = ["sub_type", "is_active", "group"]

    def get_queryset(self):
        return LedgerAccount.objects.filter(
            plant=_plant(self.request)
        ).select_related("group")

    def get_serializer_class(self):
        if self.action == "retrieve":
            return LedgerAccountDetailSerializer
        if self.action in ("create", "update", "partial_update"):
            return LedgerAccountCreateSerializer
        return LedgerAccountListSerializer

    def create(self, request):
        ser = LedgerAccountCreateSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        d = ser.validated_data
        plant = _plant(request)
        obj = LedgerAccount.objects.create(
            plant=plant,
            group_id=d["group_id"],
            code=d["code"], name=d["name"], sub_type=d.get("sub_type", "OTHER"),
            bank_name=d.get("bank_name", ""),
            account_number=d.get("account_number", ""),
            ifsc_code=d.get("ifsc_code", ""),
            branch=d.get("branch", ""),
            opening_balance=d.get("opening_balance", 0),
            opening_balance_type=d.get("opening_balance_type", "Dr"),
            current_balance=d.get("opening_balance", 0),
            notes=d.get("notes", ""),
        )
        return Response(LedgerAccountDetailSerializer(obj).data, status=201)

    @action(detail=False, methods=["get"])
    def bank_cash(self, request):
        """List only bank and cash accounts."""
        qs = self.get_queryset().filter(sub_type__in=["BANK", "CASH"], is_active=True)
        return Response(LedgerAccountListSerializer(qs, many=True).data)

    @action(detail=False, methods=["get"])
    def cash_position(self, request):
        """Current cash and bank balances."""
        return Response(services.get_cash_position(_plant(request)))


# ── Cost Center ───────────────────────────────────────────────────

class CostCenterViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    filter_backends    = [filters.SearchFilter]
    search_fields      = ["code", "name"]

    def get_queryset(self):
        return CostCenter.objects.filter(plant=_plant(self.request))

    def get_serializer_class(self):
        if self.action in ("create", "update", "partial_update"):
            return CostCenterCreateSerializer
        return CostCenterSerializer

    def create(self, request):
        ser = CostCenterCreateSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        d = ser.validated_data
        obj = CostCenter.objects.create(
            plant=_plant(request),
            code=d["code"], name=d["name"], head_id=d.get("head_id"),
        )
        return Response(CostCenterSerializer(obj).data, status=201)


# ── Voucher ───────────────────────────────────────────────────────

class VoucherViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    filter_backends    = [filters.SearchFilter, DjangoFilterBackend]
    search_fields      = ["voucher_number", "narration", "reference_number"]
    filterset_fields   = ["voucher_type", "status", "voucher_date"]

    def get_queryset(self):
        return Voucher.objects.filter(
            plant=_plant(self.request)
        ).select_related("vendor", "customer", "prepared_by")

    def get_serializer_class(self):
        if self.action == "retrieve":
            return VoucherDetailSerializer
        if self.action == "create":
            return VoucherCreateSerializer
        return VoucherListSerializer

    def create(self, request):
        ser = VoucherCreateSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        d = ser.validated_data
        plant = _plant(request)

        voucher_number = services.get_next_doc_number(plant, d["voucher_type"], d["voucher_type"])
        voucher = Voucher.objects.create(
            plant=plant,
            voucher_number=voucher_number,
            voucher_date=d["voucher_date"],
            voucher_type=d["voucher_type"],
            narration=d["narration"],
            reference_number=d.get("reference_number", ""),
            reference_date=d.get("reference_date"),
            vendor_id=d.get("vendor_id"),
            customer_id=d.get("customer_id"),
            cost_center_id=d.get("cost_center_id"),
            gst_return_period=d.get("gst_return_period", ""),
            prepared_by=request.user,
        )

        for i, line in enumerate(d["lines"], start=1):
            VoucherLine.objects.create(
                voucher=voucher, line_no=i,
                ledger_id=line["ledger_id"],
                cost_center_id=line.get("cost_center_id"),
                debit_amount=line.get("debit_amount", 0),
                credit_amount=line.get("credit_amount", 0),
                narration=line.get("narration", ""),
            )

        return Response(VoucherDetailSerializer(voucher).data, status=201)

    @action(detail=True, methods=["post"])
    def post_voucher(self, request, pk=None):
        """Post a voucher (update ledger balances)."""
        voucher = self.get_object()
        try:
            result = services.post_voucher(voucher, request.user)
            return Response(VoucherDetailSerializer(result).data)
        except ValueError as e:
            return Response({"error": str(e)}, status=400)

    @action(detail=True, methods=["post"])
    def cancel(self, request, pk=None):
        """Cancel a voucher."""
        voucher = self.get_object()
        reason = request.data.get("reason", "")
        if not reason:
            return Response({"error": "Cancellation reason required."}, status=400)
        try:
            result = services.cancel_voucher(voucher, reason, request.user)
            return Response(VoucherDetailSerializer(result).data)
        except ValueError as e:
            return Response({"error": str(e)}, status=400)


# ── Vendor Bill ───────────────────────────────────────────────────

class VendorBillViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    filter_backends    = [filters.SearchFilter, DjangoFilterBackend]
    search_fields      = ["bill_number", "vendor_bill_ref", "vendor__name"]
    filterset_fields   = ["status", "vendor"]

    def get_queryset(self):
        return VendorBill.objects.filter(
            plant=_plant(self.request)
        ).select_related("vendor", "mrr", "voucher")

    def get_serializer_class(self):
        if self.action == "retrieve":
            return VendorBillDetailSerializer
        if self.action == "create":
            return VendorBillCreateSerializer
        return VendorBillListSerializer

    def create(self, request):
        ser = VendorBillCreateSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        try:
            bill = services.receive_vendor_bill(ser.validated_data, request.user, _plant(request))
            return Response(VendorBillDetailSerializer(bill).data, status=201)
        except Exception as e:
            return Response({"error": str(e)}, status=400)

    @action(detail=True, methods=["patch"])
    def update_checklist(self, request, pk=None):
        """Update 8-point checklist for a bill."""
        bill = self.get_object()
        ser = BillChecklistSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        try:
            result = services.update_bill_checklist(bill, ser.validated_data, request.user)
            return Response(VendorBillDetailSerializer(result).data)
        except ValueError as e:
            return Response({"error": str(e)}, status=400)

    @action(detail=True, methods=["post"])
    def pass_bill(self, request, pk=None):
        """Pass the vendor bill after 8-point checklist complete. Creates Purchase Voucher."""
        bill = self.get_object()
        try:
            result = services.pass_vendor_bill(bill, request.user, _plant(request))
            return Response(VendorBillDetailSerializer(result).data)
        except ValueError as e:
            return Response({"error": str(e)}, status=400)

    @action(detail=False, methods=["get"])
    def pending_passing(self, request):
        """Bills received but not yet passed."""
        qs = self.get_queryset().filter(status__in=["RECEIVED", "UNDER_CHECK"])
        return Response(VendorBillListSerializer(qs, many=True).data)

    @action(detail=False, methods=["get"])
    def outstanding_ap(self, request):
        """AP ageing report."""
        return Response(services.get_outstanding_creditors(_plant(request)))


# ── Bill Payment ──────────────────────────────────────────────────

class BillPaymentViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    filter_backends    = [filters.SearchFilter, DjangoFilterBackend]
    search_fields      = ["payment_number", "vendor__name", "utr_number", "cheque_number"]
    filterset_fields   = ["status", "payment_mode", "vendor"]

    def get_queryset(self):
        return BillPayment.objects.filter(
            plant=_plant(self.request)
        ).select_related("vendor", "vendor_bill", "bank_account")

    def get_serializer_class(self):
        if self.action == "retrieve":
            return BillPaymentDetailSerializer
        if self.action == "create":
            return BillPaymentCreateSerializer
        return BillPaymentListSerializer

    def create(self, request):
        ser = BillPaymentCreateSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        try:
            payment = services.pay_vendor(ser.validated_data, request.user, _plant(request))
            return Response(BillPaymentDetailSerializer(payment).data, status=201)
        except ValueError as e:
            return Response({"error": str(e)}, status=400)

    @action(detail=True, methods=["post"])
    def mark_cleared(self, request, pk=None):
        """Mark payment as bank-cleared."""
        payment = self.get_object()
        if payment.status == BillPayment.PaymentStatus.CLEARED:
            return Response({"error": "Already cleared."}, status=400)
        payment.status = BillPayment.PaymentStatus.CLEARED
        payment.bank_cleared_date = request.data.get("cleared_date")
        payment.bank_statement_ref = request.data.get("statement_ref", "")
        payment.save(update_fields=["status", "bank_cleared_date", "bank_statement_ref"])
        return Response(BillPaymentDetailSerializer(payment).data)


# ── Bill Receipt ──────────────────────────────────────────────────

class BillReceiptViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    filter_backends    = [filters.SearchFilter, DjangoFilterBackend]
    search_fields      = ["receipt_number", "customer__name", "utr_number", "cheque_number"]
    filterset_fields   = ["status", "receipt_mode", "customer"]

    def get_queryset(self):
        return BillReceipt.objects.filter(
            plant=_plant(self.request)
        ).select_related("customer", "bank_account")

    def get_serializer_class(self):
        if self.action == "retrieve":
            return BillReceiptDetailSerializer
        if self.action == "create":
            return BillReceiptCreateSerializer
        return BillReceiptListSerializer

    def create(self, request):
        ser = BillReceiptCreateSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        try:
            receipt = services.receive_customer_payment(
                ser.validated_data, request.user, _plant(request)
            )
            return Response(BillReceiptDetailSerializer(receipt).data, status=201)
        except ValueError as e:
            return Response({"error": str(e)}, status=400)

    @action(detail=True, methods=["post"])
    def mark_cleared(self, request, pk=None):
        """Mark receipt/cheque as cleared by bank."""
        receipt = self.get_object()
        receipt.status = BillReceipt.ReceiptStatus.CLEARED
        receipt.bank_cleared_date = request.data.get("cleared_date")
        receipt.bank_statement_ref = request.data.get("statement_ref", "")
        receipt.save(update_fields=["status", "bank_cleared_date", "bank_statement_ref"])
        return Response(BillReceiptDetailSerializer(receipt).data)

    @action(detail=True, methods=["post"])
    def mark_bounced(self, request, pk=None):
        """Mark a cheque as bounced."""
        receipt = self.get_object()
        bounce_reason = request.data.get("bounce_reason", "")
        if not bounce_reason:
            return Response({"error": "bounce_reason is required."}, status=400)
        receipt.status = BillReceipt.ReceiptStatus.BOUNCED
        receipt.bounce_reason = bounce_reason
        receipt.save(update_fields=["status", "bounce_reason"])
        return Response(BillReceiptDetailSerializer(receipt).data)


# ── TDS Entry ─────────────────────────────────────────────────────

class TDSEntryViewSet(viewsets.ReadOnlyModelViewSet):
    """TDS entries are created automatically by pay_vendor. Read-only here."""
    permission_classes = [IsAuthenticated]
    filter_backends    = [filters.SearchFilter, DjangoFilterBackend]
    search_fields      = ["vendor_name", "vendor_pan", "challan_number"]
    filterset_fields   = ["tds_section", "is_deposited", "quarter", "financial_year"]

    def get_queryset(self):
        return TDSEntry.objects.filter(plant=_plant(self.request)).select_related("vendor", "payment")

    def get_serializer_class(self):
        if self.action == "retrieve":
            return TDSEntryDetailSerializer
        return TDSEntryListSerializer

    @action(detail=True, methods=["post"])
    def mark_deposited(self, request, pk=None):
        """Mark TDS as deposited to govt with challan details."""
        entry = self.get_object()
        entry.is_deposited = True
        entry.challan_number = request.data.get("challan_number", "")
        entry.challan_date = request.data.get("challan_date")
        entry.deposit_bank = request.data.get("deposit_bank", "")
        entry.save(update_fields=["is_deposited", "challan_number", "challan_date", "deposit_bank"])
        return Response(TDSEntryDetailSerializer(entry).data)

    @action(detail=False, methods=["get"])
    def pending_deposit(self, request):
        """TDS entries not yet deposited to govt."""
        qs = self.get_queryset().filter(is_deposited=False)
        return Response(TDSEntryListSerializer(qs, many=True).data)

    @action(detail=False, methods=["get"])
    def quarterly_summary(self, request):
        """26Q summary by quarter and section."""
        from django.db.models import Sum
        quarter = request.query_params.get("quarter")
        fy = request.query_params.get("financial_year")
        qs = self.get_queryset()
        if quarter:
            qs = qs.filter(quarter=quarter)
        if fy:
            qs = qs.filter(financial_year=fy)
        summary = qs.values("tds_section", "quarter", "financial_year").annotate(
            total_gross=Sum("gross_payment"),
            total_tds=Sum("tds_amount"),
        ).order_by("financial_year", "quarter", "tds_section")
        return Response(list(summary))


# ── GST Ledger ────────────────────────────────────────────────────

class GSTLedgerViewSet(viewsets.ReadOnlyModelViewSet):
    """GST ledger is auto-populated by voucher posting."""
    permission_classes = [IsAuthenticated]
    filter_backends    = [DjangoFilterBackend]
    filterset_fields   = ["entry_type", "gst_type", "is_filed", "return_period"]

    def get_queryset(self):
        return GSTLedger.objects.filter(plant=_plant(self.request))

    def get_serializer_class(self):
        if self.action == "retrieve":
            return GSTLedgerDetailSerializer
        return GSTLedgerListSerializer

    @action(detail=False, methods=["get"])
    def gstr1(self, request):
        """GSTR-1 data for a return period."""
        period = request.query_params.get("period")
        if not period:
            return Response({"error": "period query param required (MMYYYY)."}, status=400)
        return Response(services.get_gst_data_for_gstr1(_plant(request), period))

    @action(detail=False, methods=["get"])
    def gstr3b(self, request):
        """GSTR-3B summary data."""
        period = request.query_params.get("period")
        if not period:
            return Response({"error": "period query param required (MMYYYY)."}, status=400)
        return Response(services.get_gst_data_for_gstr3b(_plant(request), period))


# ── Bank Statement & Reconciliation ──────────────────────────────

class BankStatementViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    filter_backends    = [DjangoFilterBackend]
    filterset_fields   = ["bank_account", "is_reconciled"]

    def get_queryset(self):
        return BankStatement.objects.filter(
            plant=_plant(self.request)
        ).select_related("bank_account", "uploaded_by")

    def get_serializer_class(self):
        if self.action == "retrieve":
            return BankStatementDetailSerializer
        if self.action == "create":
            return BankStatementCreateSerializer
        return BankStatementListSerializer

    def create(self, request):
        ser = BankStatementCreateSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        try:
            statement = services.upload_bank_statement(
                ser.validated_data, request.user, _plant(request)
            )
            return Response(BankStatementDetailSerializer(statement).data, status=201)
        except Exception as e:
            return Response({"error": str(e)}, status=400)

    @action(detail=True, methods=["post"])
    def import_lines(self, request, pk=None):
        """Bulk-import bank statement lines."""
        statement = self.get_object()
        ser = BankReconLineCreateSerializer(data=request.data.get("lines", []), many=True)
        ser.is_valid(raise_exception=True)
        created = []
        for line in ser.validated_data:
            obj = BankReconciliation.objects.create(statement=statement, **line)
            created.append(obj.pk)
        return Response({"created": len(created)}, status=201)

    @action(detail=True, methods=["post"])
    def match_line(self, request, pk=None):
        """Match a bank reconciliation line to a voucher."""
        statement = self.get_object()
        line_id = request.data.get("line_id")
        ser = BankReconMatchSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        try:
            recon_line = BankReconciliation.objects.get(pk=line_id, statement=statement)
            voucher = Voucher.objects.get(uuid=ser.validated_data["voucher_id"], plant=_plant(request))
            result = services.reconcile_bank_line(recon_line, voucher, request.user)
            from apps.accounts.api.serializers import BankReconciliationSerializer
            return Response(BankReconciliationSerializer(result).data)
        except BankReconciliation.DoesNotExist:
            return Response({"error": "Line not found."}, status=404)
        except Voucher.DoesNotExist:
            return Response({"error": "Voucher not found."}, status=404)
        except ValueError as e:
            return Response({"error": str(e)}, status=400)

    @action(detail=True, methods=["get"])
    def unmatched_lines(self, request, pk=None):
        """Return all unmatched bank statement lines."""
        statement = self.get_object()
        qs = statement.lines.filter(match_status="UNMATCHED")
        from apps.accounts.api.serializers import BankReconciliationSerializer
        return Response(BankReconciliationSerializer(qs, many=True).data)


# ── Outstanding Followup ──────────────────────────────────────────

class OutstandingFollowupViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    filter_backends    = [filters.SearchFilter, DjangoFilterBackend]
    search_fields      = ["customer__name"]
    filterset_fields   = ["action", "bucket", "is_resolved", "customer"]

    def get_queryset(self):
        return OutstandingFollowup.objects.filter(
            plant=_plant(self.request)
        ).select_related("customer", "invoice", "done_by")

    def get_serializer_class(self):
        if self.action == "retrieve":
            return OutstandingFollowupDetailSerializer
        if self.action == "create":
            return OutstandingFollowupCreateSerializer
        return OutstandingFollowupListSerializer

    def create(self, request):
        ser = OutstandingFollowupCreateSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        try:
            followup = services.log_ar_followup(
                ser.validated_data, request.user, _plant(request)
            )
            return Response(OutstandingFollowupDetailSerializer(followup).data, status=201)
        except Exception as e:
            return Response({"error": str(e)}, status=400)

    @action(detail=True, methods=["post"])
    def resolve(self, request, pk=None):
        followup = self.get_object()
        followup.is_resolved = True
        followup.save(update_fields=["is_resolved"])
        return Response(OutstandingFollowupDetailSerializer(followup).data)

    @action(detail=False, methods=["get"])
    def outstanding_ar(self, request):
        """Full AR ageing report."""
        return Response(services.get_outstanding_debtors(_plant(request)))

    @action(detail=False, methods=["get"])
    def dashboard(self, request):
        """Accounts dashboard tiles."""
        return Response(services.get_accounts_dashboard(_plant(request)))


# ── MSME Compliance Report ────────────────────────────────────────

class MSMEReportViewSet(viewsets.ViewSet):
    """
    GET /api/accounts/msme-report/?as_of_date=YYYY-MM-DD&plant=<uuid>
    GET /api/accounts/msme-report/export/
    """
    permission_classes = [IsAuthenticated]

    def _check_permission(self, request):
        user = request.user
        if user.is_superadmin:
            return True
        from apps.core.models import Permission
        return Permission.objects.filter(
            module="accounts",
            action="view",
            resource="msme_report",
            rolepermission__role__userrole__user=user,
            rolepermission__role__is_active=True,
        ).exists()

    def list(self, request):
        if not self._check_permission(request):
            return Response({"detail": "Permission denied."}, status=403)

        from datetime import date
        plant = _plant(request)

        as_of_str = request.query_params.get("as_of_date")
        if as_of_str:
            try:
                as_of_date = date.fromisoformat(as_of_str)
            except ValueError:
                return Response({"detail": "Invalid as_of_date format. Use YYYY-MM-DD."}, status=400)
        else:
            as_of_date = date.today()

        result = services.get_msme_overdue_report(plant, as_of_date)
        return Response(result)

    @action(detail=False, methods=["get"], url_path="export")
    def export(self, request):
        if not self._check_permission(request):
            return Response({"detail": "Permission denied."}, status=403)

        from datetime import date
        import io
        from django.http import HttpResponse

        try:
            import openpyxl
            from openpyxl.styles import PatternFill, Font, Alignment
        except ImportError:
            return Response({"detail": "openpyxl not installed."}, status=500)

        plant = _plant(request)
        as_of_str = request.query_params.get("as_of_date")
        if as_of_str:
            try:
                as_of_date = date.fromisoformat(as_of_str)
            except ValueError:
                return Response({"detail": "Invalid as_of_date."}, status=400)
        else:
            as_of_date = date.today()

        result = services.get_msme_overdue_report(plant, as_of_date)
        summary = result["summary"]
        bills = result["bills"]

        wb = openpyxl.Workbook()

        # ── Sheet 1: Summary ──────────────────────────────────────
        ws1 = wb.active
        ws1.title = "Summary"
        header_fill = PatternFill(start_color="1F4E79", end_color="1F4E79", fill_type="solid")
        header_font = Font(color="FFFFFF", bold=True)

        ws1.append(["MSME Compliance Report"])
        ws1.append([f"As of Date: {as_of_date.isoformat()}"])
        ws1.append([])
        ws1.append(["Metric", "Value"])
        for cell in ws1[4]:
            cell.fill = header_fill
            cell.font = header_font
        ws1.append(["Total MSME Vendors", summary["total_msme_vendors"]])
        ws1.append(["Total Overdue Bills (>45 days)", summary["total_overdue_bills"]])
        ws1.append(["Total Overdue Amount (₹)", summary["total_overdue_amount"]])
        ws1.append(["Total Interest Liability (₹)", summary["total_interest"]])
        ws1.column_dimensions["A"].width = 35
        ws1.column_dimensions["B"].width = 20

        # ── Sheet 2: Bill-wise Detail ─────────────────────────────
        ws2 = wb.create_sheet("Bill-wise Detail")
        red_fill = PatternFill(start_color="FFCCCC", end_color="FFCCCC", fill_type="solid")

        cols = [
            "Vendor", "MSME Type", "MSME Number", "Bill #",
            "Bill Date", "Due Date", "Amount (₹)", "Days Overdue", "Interest Liability (₹)"
        ]
        ws2.append(cols)
        for cell in ws2[1]:
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = Alignment(horizontal="center")

        for bill in bills:
            row = [
                bill["vendor_name"], bill["msme_type"], bill["msme_number"],
                bill["bill_number"], bill["bill_date"], bill["due_date"],
                bill["amount"], bill["days_overdue"], bill["interest_liability"],
            ]
            ws2.append(row)
            if bill["days_overdue"] > 45:
                row_idx = ws2.max_row
                for col_idx in range(1, len(cols) + 1):
                    ws2.cell(row=row_idx, column=col_idx).fill = red_fill

        for col in ws2.columns:
            ws2.column_dimensions[col[0].column_letter].width = 18

        buf = io.BytesIO()
        wb.save(buf)
        buf.seek(0)

        response = HttpResponse(
            buf.getvalue(),
            content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )
        response["Content-Disposition"] = (
            f'attachment; filename="MSME_Compliance_Report_{as_of_date.isoformat()}.xlsx"'
        )
        return response
