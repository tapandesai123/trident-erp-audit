"""Accounts Module URL Router — Section 6"""
from rest_framework.routers import DefaultRouter
from django.urls import path, include
from apps.accounts.api.viewsets import (
    AccountGroupViewSet,
    LedgerAccountViewSet,
    CostCenterViewSet,
    VoucherViewSet,
    VendorBillViewSet,
    BillPaymentViewSet,
    BillReceiptViewSet,
    TDSEntryViewSet,
    GSTLedgerViewSet,
    BankStatementViewSet,
    OutstandingFollowupViewSet,
    MSMEReportViewSet,
)

router = DefaultRouter()
router.register("account-groups",       AccountGroupViewSet,       basename="account-group")
router.register("ledger-accounts",      LedgerAccountViewSet,      basename="ledger-account")
router.register("cost-centers",         CostCenterViewSet,         basename="cost-center")
router.register("vouchers",             VoucherViewSet,            basename="voucher")
router.register("vendor-bills",         VendorBillViewSet,         basename="vendor-bill")
router.register("bill-payments",        BillPaymentViewSet,        basename="bill-payment")
router.register("bill-receipts",        BillReceiptViewSet,        basename="bill-receipt")
router.register("tds-entries",          TDSEntryViewSet,           basename="tds-entry")
router.register("gst-ledger",           GSTLedgerViewSet,          basename="gst-ledger")
router.register("bank-statements",      BankStatementViewSet,      basename="bank-statement")
router.register("ar-followups",         OutstandingFollowupViewSet, basename="ar-followup")
router.register("msme-report",          MSMEReportViewSet,          basename="msme-report")

app_name = "accounts"
urlpatterns = [path("", include(router.urls))]
