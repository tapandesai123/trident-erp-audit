"""Accounts Module Serializers — Section 6
Three serializer variants per model: List, Detail, Create.
"""
from rest_framework import serializers
from apps.accounts.models import (
    AccountGroup, LedgerAccount, CostCenter,
    Voucher, VoucherLine,
    VendorBill, BillPayment,
    BillReceipt, ReceiptAllocation,
    TDSEntry, GSTLedger,
    BankStatement, BankReconciliation,
    OutstandingFollowup,
)


# ── Account Group ─────────────────────────────────────────────────

class AccountGroupListSerializer(serializers.ModelSerializer):
    parent_name = serializers.CharField(source="parent.name", read_only=True, default="")
    class Meta:
        model  = AccountGroup
        fields = ["id", "uuid", "code", "name", "group_type", "parent", "parent_name", "is_system"]


class AccountGroupDetailSerializer(serializers.ModelSerializer):
    parent_name  = serializers.CharField(source="parent.name", read_only=True, default="")
    class Meta:
        model  = AccountGroup
        fields = "__all__"


class AccountGroupCreateSerializer(serializers.Serializer):
    code        = serializers.CharField(max_length=20)
    name        = serializers.CharField(max_length=200)
    group_type  = serializers.ChoiceField(choices=AccountGroup.GroupType.choices)
    parent_id   = serializers.IntegerField(required=False, allow_null=True)
    description = serializers.CharField(required=False, allow_blank=True)


# ── Ledger Account ────────────────────────────────────────────────

class LedgerAccountListSerializer(serializers.ModelSerializer):
    group_name = serializers.CharField(source="group.name", read_only=True)
    class Meta:
        model  = LedgerAccount
        fields = ["id", "uuid", "code", "name", "sub_type", "group", "group_name",
                  "current_balance", "balance_type", "is_active"]


class LedgerAccountDetailSerializer(serializers.ModelSerializer):
    group_name = serializers.CharField(source="group.name", read_only=True)
    class Meta:
        model  = LedgerAccount
        fields = "__all__"


class LedgerAccountCreateSerializer(serializers.Serializer):
    group_id     = serializers.IntegerField()
    code         = serializers.CharField(max_length=20)
    name         = serializers.CharField(max_length=200)
    sub_type     = serializers.ChoiceField(choices=LedgerAccount.AccountSubType.choices,
                                           default="OTHER")
    bank_name    = serializers.CharField(required=False, allow_blank=True)
    account_number = serializers.CharField(required=False, allow_blank=True)
    ifsc_code    = serializers.CharField(required=False, allow_blank=True)
    branch       = serializers.CharField(required=False, allow_blank=True)
    opening_balance = serializers.DecimalField(max_digits=18, decimal_places=2, default=0)
    opening_balance_type = serializers.ChoiceField(choices=[("Dr", "Debit"), ("Cr", "Credit")],
                                                    default="Dr")
    notes        = serializers.CharField(required=False, allow_blank=True)


# ── Cost Center ───────────────────────────────────────────────────

class CostCenterSerializer(serializers.ModelSerializer):
    head_name = serializers.CharField(source="head.get_full_name", read_only=True, default="")
    class Meta:
        model  = CostCenter
        fields = ["id", "code", "name", "head", "head_name", "is_active"]


class CostCenterCreateSerializer(serializers.Serializer):
    code    = serializers.CharField(max_length=20)
    name    = serializers.CharField(max_length=100)
    head_id = serializers.IntegerField(required=False, allow_null=True)


# ── Voucher ───────────────────────────────────────────────────────

class VoucherLineSerializer(serializers.ModelSerializer):
    ledger_name  = serializers.CharField(source="ledger.name", read_only=True)
    ledger_code  = serializers.CharField(source="ledger.code", read_only=True)
    cc_name      = serializers.CharField(source="cost_center.name", read_only=True, default="")
    class Meta:
        model  = VoucherLine
        fields = ["id", "line_no", "ledger", "ledger_code", "ledger_name",
                  "cost_center", "cc_name", "debit_amount", "credit_amount",
                  "cgst_amount", "sgst_amount", "igst_amount", "narration"]


class VoucherListSerializer(serializers.ModelSerializer):
    vendor_name   = serializers.CharField(source="vendor.name", read_only=True, default="")
    customer_name = serializers.CharField(source="customer.name", read_only=True, default="")
    class Meta:
        model  = Voucher
        fields = ["id", "uuid", "voucher_number", "voucher_date", "voucher_type",
                  "status", "total_debit", "narration", "vendor", "vendor_name",
                  "customer", "customer_name", "reference_number", "plant"]


class VoucherDetailSerializer(serializers.ModelSerializer):
    lines         = VoucherLineSerializer(many=True, read_only=True)
    vendor_name   = serializers.CharField(source="vendor.name", read_only=True, default="")
    customer_name = serializers.CharField(source="customer.name", read_only=True, default="")
    prepared_by_name = serializers.CharField(source="prepared_by.get_full_name", read_only=True, default="")
    class Meta:
        model  = Voucher
        fields = "__all__"


class VoucherLineCreateSerializer(serializers.Serializer):
    ledger_id      = serializers.IntegerField()
    cost_center_id = serializers.IntegerField(required=False, allow_null=True)
    debit_amount   = serializers.DecimalField(max_digits=18, decimal_places=2, default=0)
    credit_amount  = serializers.DecimalField(max_digits=18, decimal_places=2, default=0)
    narration      = serializers.CharField(required=False, allow_blank=True)


class VoucherCreateSerializer(serializers.Serializer):
    voucher_date     = serializers.DateField()
    voucher_type     = serializers.ChoiceField(choices=Voucher.VoucherType.choices)
    narration        = serializers.CharField()
    reference_number = serializers.CharField(required=False, allow_blank=True)
    reference_date   = serializers.DateField(required=False, allow_null=True)
    vendor_id        = serializers.IntegerField(required=False, allow_null=True)
    customer_id      = serializers.IntegerField(required=False, allow_null=True)
    cost_center_id   = serializers.IntegerField(required=False, allow_null=True)
    gst_return_period = serializers.CharField(required=False, allow_blank=True)
    lines            = VoucherLineCreateSerializer(many=True)

    def validate_lines(self, v):
        if len(v) < 2:
            raise serializers.ValidationError("Voucher must have at least 2 lines.")
        total_dr = sum(l.get("debit_amount", 0) or 0 for l in v)
        total_cr = sum(l.get("credit_amount", 0) or 0 for l in v)
        if round(float(total_dr), 2) != round(float(total_cr), 2):
            raise serializers.ValidationError(
                f"Debit ₹{total_dr} does not equal Credit ₹{total_cr}."
            )
        return v


# ── Vendor Bill ───────────────────────────────────────────────────

class VendorBillListSerializer(serializers.ModelSerializer):
    vendor_name    = serializers.CharField(source="vendor.name", read_only=True)
    checklist_done = serializers.BooleanField(source="checklist_complete", read_only=True)
    class Meta:
        model  = VendorBill
        fields = ["id", "uuid", "bill_number", "vendor_bill_ref", "vendor_bill_date",
                  "received_date", "status", "vendor", "vendor_name",
                  "total_amount", "net_payable", "outstanding",
                  "checklist_score", "checklist_done", "due_date"]


class VendorBillDetailSerializer(serializers.ModelSerializer):
    vendor_name   = serializers.CharField(source="vendor.name", read_only=True)
    checklist_done = serializers.BooleanField(source="checklist_complete", read_only=True)
    passed_by_name = serializers.CharField(source="passed_by.get_full_name", read_only=True, default="")
    class Meta:
        model  = VendorBill
        fields = "__all__"


class VendorBillCreateSerializer(serializers.Serializer):
    vendor_id       = serializers.IntegerField()
    vendor_bill_ref = serializers.CharField(max_length=100)
    vendor_bill_date = serializers.DateField()
    received_date   = serializers.DateField(required=False)
    mrr_id          = serializers.UUIDField(required=False, allow_null=True)
    taxable_amount  = serializers.DecimalField(max_digits=15, decimal_places=2, default=0)
    cgst_amount     = serializers.DecimalField(max_digits=15, decimal_places=2, default=0)
    sgst_amount     = serializers.DecimalField(max_digits=15, decimal_places=2, default=0)
    igst_amount     = serializers.DecimalField(max_digits=15, decimal_places=2, default=0)
    total_amount    = serializers.DecimalField(max_digits=15, decimal_places=2)
    due_date        = serializers.DateField(required=False, allow_null=True)


class BillChecklistSerializer(serializers.Serializer):
    chk_pr_authorised       = serializers.BooleanField(required=False)
    chk_po_approved         = serializers.BooleanField(required=False)
    chk_gate_entry_done     = serializers.BooleanField(required=False)
    chk_mrr_qty_match       = serializers.BooleanField(required=False)
    chk_qc_passed           = serializers.BooleanField(required=False)
    chk_gst_copy_received   = serializers.BooleanField(required=False)
    chk_accounts_paper_ok   = serializers.BooleanField(required=False)
    chk_calculation_verified = serializers.BooleanField(required=False)
    checklist_remarks        = serializers.CharField(required=False, allow_blank=True)


# ── Bill Payment ──────────────────────────────────────────────────

class BillPaymentListSerializer(serializers.ModelSerializer):
    vendor_name = serializers.CharField(source="vendor.name", read_only=True)
    class Meta:
        model  = BillPayment
        fields = ["id", "uuid", "payment_number", "payment_date", "payment_mode",
                  "vendor", "vendor_name", "gross_amount", "tds_amount", "net_amount",
                  "status", "utr_number"]


class BillPaymentDetailSerializer(serializers.ModelSerializer):
    vendor_name  = serializers.CharField(source="vendor.name", read_only=True)
    bank_account_name = serializers.CharField(source="bank_account.name", read_only=True)
    class Meta:
        model  = BillPayment
        fields = "__all__"


class BillPaymentCreateSerializer(serializers.Serializer):
    vendor_bill_id  = serializers.UUIDField()
    bank_account_id = serializers.IntegerField()
    payment_date    = serializers.DateField(required=False)
    payment_mode    = serializers.ChoiceField(choices=BillPayment.PaymentMode.choices)
    gross_amount    = serializers.DecimalField(max_digits=15, decimal_places=2)
    cheque_number   = serializers.CharField(required=False, allow_blank=True)
    cheque_date     = serializers.DateField(required=False, allow_null=True)
    utr_number      = serializers.CharField(required=False, allow_blank=True)
    remarks         = serializers.CharField(required=False, allow_blank=True)


# ── Bill Receipt ──────────────────────────────────────────────────

class ReceiptAllocationSerializer(serializers.ModelSerializer):
    invoice_number = serializers.CharField(source="invoice.invoice_number", read_only=True)
    class Meta:
        model  = ReceiptAllocation
        fields = ["id", "invoice", "invoice_number", "allocated_amount"]


class BillReceiptListSerializer(serializers.ModelSerializer):
    customer_name = serializers.CharField(source="customer.name", read_only=True)
    class Meta:
        model  = BillReceipt
        fields = ["id", "uuid", "receipt_number", "receipt_date", "receipt_mode",
                  "customer", "customer_name", "gross_amount", "net_amount", "status"]


class BillReceiptDetailSerializer(serializers.ModelSerializer):
    customer_name    = serializers.CharField(source="customer.name", read_only=True)
    bank_account_name = serializers.CharField(source="bank_account.name", read_only=True)
    allocations      = ReceiptAllocationSerializer(many=True, read_only=True)
    class Meta:
        model  = BillReceipt
        fields = "__all__"


class ReceiptAllocationCreateSerializer(serializers.Serializer):
    invoice_id = serializers.UUIDField()
    amount     = serializers.DecimalField(max_digits=15, decimal_places=2)


class BillReceiptCreateSerializer(serializers.Serializer):
    customer_id    = serializers.IntegerField()
    bank_account_id = serializers.IntegerField()
    receipt_date   = serializers.DateField(required=False)
    receipt_mode   = serializers.ChoiceField(choices=BillReceipt.ReceiptMode.choices)
    gross_amount   = serializers.DecimalField(max_digits=15, decimal_places=2)
    cheque_number  = serializers.CharField(required=False, allow_blank=True)
    cheque_date    = serializers.DateField(required=False, allow_null=True)
    utr_number     = serializers.CharField(required=False, allow_blank=True)
    tds_by_customer = serializers.DecimalField(max_digits=15, decimal_places=2, default=0)
    remarks        = serializers.CharField(required=False, allow_blank=True)
    allocations    = ReceiptAllocationCreateSerializer(many=True, required=False, default=[])


# ── TDS Entry ─────────────────────────────────────────────────────

class TDSEntryListSerializer(serializers.ModelSerializer):
    vendor_name_str = serializers.CharField(source="vendor_name", read_only=True)
    class Meta:
        model  = TDSEntry
        fields = ["id", "uuid", "tds_section", "tds_rate", "gross_payment",
                  "tds_amount", "payment_date", "vendor_name_str", "vendor_pan",
                  "is_deposited", "quarter", "financial_year"]


class TDSEntryDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model  = TDSEntry
        fields = "__all__"


# ── GST Ledger ────────────────────────────────────────────────────

class GSTLedgerListSerializer(serializers.ModelSerializer):
    class Meta:
        model  = GSTLedger
        fields = ["id", "uuid", "entry_type", "gst_type", "amount", "taxable_amount",
                  "entry_date", "return_period", "is_filed", "party_gstin"]


class GSTLedgerDetailSerializer(serializers.ModelSerializer):
    vendor_name   = serializers.CharField(source="vendor.name", read_only=True, default="")
    customer_name = serializers.CharField(source="customer.name", read_only=True, default="")
    class Meta:
        model  = GSTLedger
        fields = "__all__"


# ── Bank Statement ────────────────────────────────────────────────

class BankReconciliationSerializer(serializers.ModelSerializer):
    matched_voucher_number = serializers.CharField(
        source="matched_voucher.voucher_number", read_only=True, default=""
    )
    class Meta:
        model  = BankReconciliation
        fields = ["id", "transaction_date", "description", "debit_amount", "credit_amount",
                  "balance", "bank_reference", "match_status", "matched_voucher",
                  "matched_voucher_number", "notes"]


class BankStatementListSerializer(serializers.ModelSerializer):
    bank_account_name = serializers.CharField(source="bank_account.name", read_only=True)
    class Meta:
        model  = BankStatement
        fields = ["id", "uuid", "bank_account", "bank_account_name", "statement_month",
                  "opening_balance", "closing_balance", "is_reconciled", "uploaded_by"]


class BankStatementDetailSerializer(serializers.ModelSerializer):
    bank_account_name = serializers.CharField(source="bank_account.name", read_only=True)
    lines = BankReconciliationSerializer(many=True, read_only=True)
    class Meta:
        model  = BankStatement
        fields = "__all__"


class BankStatementCreateSerializer(serializers.Serializer):
    bank_account_id  = serializers.IntegerField()
    statement_month  = serializers.CharField(max_length=7)
    opening_balance  = serializers.DecimalField(max_digits=15, decimal_places=2)
    closing_balance  = serializers.DecimalField(max_digits=15, decimal_places=2)


class BankReconLineCreateSerializer(serializers.Serializer):
    """Bulk-import lines from bank statement CSV."""
    transaction_date = serializers.DateField()
    description      = serializers.CharField(max_length=500)
    debit_amount     = serializers.DecimalField(max_digits=15, decimal_places=2, default=0)
    credit_amount    = serializers.DecimalField(max_digits=15, decimal_places=2, default=0)
    balance          = serializers.DecimalField(max_digits=15, decimal_places=2, default=0)
    bank_reference   = serializers.CharField(required=False, allow_blank=True)


class BankReconMatchSerializer(serializers.Serializer):
    voucher_id = serializers.UUIDField()


# ── Outstanding Followup ──────────────────────────────────────────

class OutstandingFollowupListSerializer(serializers.ModelSerializer):
    customer_name   = serializers.CharField(source="customer.name", read_only=True)
    invoice_number  = serializers.CharField(source="invoice.invoice_number", read_only=True)
    done_by_name    = serializers.CharField(source="done_by.get_full_name", read_only=True, default="")
    class Meta:
        model  = OutstandingFollowup
        fields = ["id", "uuid", "customer", "customer_name", "invoice", "invoice_number",
                  "outstanding_amount", "overdue_days", "bucket", "action",
                  "action_date", "done_by_name", "promised_date", "is_resolved"]


class OutstandingFollowupDetailSerializer(serializers.ModelSerializer):
    customer_name  = serializers.CharField(source="customer.name", read_only=True)
    invoice_number = serializers.CharField(source="invoice.invoice_number", read_only=True)
    done_by_name   = serializers.CharField(source="done_by.get_full_name", read_only=True, default="")
    class Meta:
        model  = OutstandingFollowup
        fields = "__all__"


class OutstandingFollowupCreateSerializer(serializers.Serializer):
    invoice_id      = serializers.UUIDField()
    action          = serializers.ChoiceField(choices=OutstandingFollowup.FollowupAction.choices)
    action_date     = serializers.DateField(required=False)
    contact_person  = serializers.CharField(required=False, allow_blank=True)
    summary         = serializers.CharField()
    promised_date   = serializers.DateField(required=False, allow_null=True)
    promised_amount = serializers.DecimalField(max_digits=15, decimal_places=2,
                                               required=False, allow_null=True)
    next_followup_date = serializers.DateField(required=False, allow_null=True)
