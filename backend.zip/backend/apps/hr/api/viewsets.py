"""HR & Payroll API Viewsets."""
from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated

from apps.hr.models import (
    Department, Designation, Employee,
    Attendance, LeaveType, LeaveRequest,
    SalaryComponent, SalaryStructure, SalaryStructureLine,
    Payroll, PayrollLine,
)
from apps.hr.api.serializers import (
    DepartmentListSerializer, DepartmentDetailSerializer, DepartmentCreateSerializer,
    DesignationListSerializer, DesignationDetailSerializer, DesignationCreateSerializer,
    EmployeeListSerializer, EmployeeDetailSerializer, EmployeeCreateSerializer,
    AttendanceListSerializer, AttendanceDetailSerializer, AttendanceCreateSerializer,
    LeaveTypeSerializer,
    LeaveRequestListSerializer, LeaveRequestDetailSerializer, LeaveRequestCreateSerializer,
    SalaryComponentListSerializer, SalaryComponentDetailSerializer, SalaryComponentCreateSerializer,
    SalaryStructureListSerializer, SalaryStructureDetailSerializer, SalaryStructureCreateSerializer,
    PayrollListSerializer, PayrollDetailSerializer, PayrollCreateSerializer,
    PayrollLineListSerializer, PayrollLineDetailSerializer,
)
from apps.hr import services


class DepartmentViewSet(viewsets.ModelViewSet):
    queryset = Department.objects.select_related("plant", "head")
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return DepartmentListSerializer
        if self.action in ("create", "update", "partial_update"):
            return DepartmentCreateSerializer
        return DepartmentDetailSerializer

    def get_queryset(self):
        # BUG-032 fix: filter by user's plant to prevent cross-plant HR data exposure
        plant = getattr(self.request.user, 'plant', None)
        return Department.objects.filter(plant=plant).select_related("plant", "head")


class DesignationViewSet(viewsets.ModelViewSet):
    queryset = Designation.objects.select_related("plant")
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return DesignationListSerializer
        if self.action in ("create", "update", "partial_update"):
            return DesignationCreateSerializer
        return DesignationDetailSerializer

    def get_queryset(self):
        # BUG-032 fix: filter by user's plant
        plant = getattr(self.request.user, 'plant', None)
        return Designation.objects.filter(plant=plant).select_related("plant")


class EmployeeViewSet(viewsets.ModelViewSet):
    queryset = Employee.objects.select_related(
        "plant", "department", "designation",
        "reporting_manager", "salary_structure", "user",
    )
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return EmployeeListSerializer
        if self.action in ("create", "update", "partial_update"):
            return EmployeeCreateSerializer
        return EmployeeDetailSerializer

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)

    def get_queryset(self):
        # BUG-032 fix: always filter by user's plant; param can only narrow further
        user_plant = getattr(self.request.user, 'plant', None)
        qs = super().get_queryset().filter(plant=user_plant)
        status_filter = self.request.query_params.get("status")
        dept = self.request.query_params.get("department")
        if status_filter:
            qs = qs.filter(status=status_filter)
        if dept:
            qs = qs.filter(department=dept)
        return qs

    @action(detail=True, methods=["post"])
    def deactivate(self, request, pk=None):
        """Mark employee as RESIGNED with date_of_leaving."""
        from datetime import date
        emp = self.get_object()
        emp.status = "RESIGNED"
        emp.date_of_leaving = request.data.get("date_of_leaving", date.today().isoformat())
        emp.save(update_fields=["status", "date_of_leaving"])
        return Response({"status": "resigned", "employee_code": emp.employee_code})

    @action(detail=True, methods=["get"])
    def payslips(self, request, pk=None):
        """Return list of PayrollLines for this employee."""
        emp = self.get_object()
        lines = PayrollLine.objects.filter(employee=emp).select_related("payroll")
        serializer = PayrollLineListSerializer(lines, many=True)
        return Response(serializer.data)


class AttendanceViewSet(viewsets.ModelViewSet):
    queryset = Attendance.objects.select_related("employee", "marked_by")
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return AttendanceListSerializer
        if self.action in ("create", "update", "partial_update"):
            return AttendanceCreateSerializer
        return AttendanceDetailSerializer

    def get_queryset(self):
        qs = super().get_queryset()
        employee = self.request.query_params.get("employee")
        att_date = self.request.query_params.get("date")
        from_date = self.request.query_params.get("from_date")
        to_date = self.request.query_params.get("to_date")
        if employee:
            qs = qs.filter(employee=employee)
        if att_date:
            qs = qs.filter(date=att_date)
        if from_date:
            qs = qs.filter(date__gte=from_date)
        if to_date:
            qs = qs.filter(date__lte=to_date)
        return qs

    @action(detail=False, methods=["post"])
    def bulk_mark(self, request):
        """
        Bulk mark attendance for multiple employees on a single date.
        Payload: { "plant": <int>, "date": "YYYY-MM-DD", "records": [...] }
        """
        from datetime import date as date_type
        from apps.core.models import Plant

        plant_id = request.data.get("plant")
        att_date_str = request.data.get("date")
        records = request.data.get("records", [])

        if not plant_id or not att_date_str or not records:
            return Response(
                {"error": "plant, date, and records are required."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        try:
            plant = Plant.objects.get(pk=plant_id)
            att_date = date_type.fromisoformat(att_date_str)
            attendances = services.mark_attendance(plant, att_date, records, request.user)
            serializer = AttendanceListSerializer(attendances, many=True)
            return Response({"marked": len(attendances), "records": serializer.data})
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)


class LeaveTypeViewSet(viewsets.ModelViewSet):
    queryset = LeaveType.objects.all()
    serializer_class = LeaveTypeSerializer
    permission_classes = [IsAuthenticated]


class LeaveRequestViewSet(viewsets.ModelViewSet):
    queryset = LeaveRequest.objects.select_related(
        "employee", "leave_type", "approved_by"
    )
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return LeaveRequestListSerializer
        if self.action in ("create", "update", "partial_update"):
            return LeaveRequestCreateSerializer
        return LeaveRequestDetailSerializer

    def get_queryset(self):
        qs = super().get_queryset()
        emp = self.request.query_params.get("employee")
        lv_status = self.request.query_params.get("status")
        if emp:
            qs = qs.filter(employee=emp)
        if lv_status:
            qs = qs.filter(status=lv_status)
        return qs

    def create(self, request, *args, **kwargs):
        """Use service for validation."""
        from apps.hr.models import Employee, LeaveType as LT

        try:
            emp = Employee.objects.get(pk=request.data["employee"])
            lt = LT.objects.get(pk=request.data["leave_type"])
            from datetime import date
            from_date = date.fromisoformat(request.data["from_date"])
            to_date = date.fromisoformat(request.data["to_date"])
            lr = services.apply_leave(
                emp, lt, from_date, to_date,
                request.data.get("reason", ""),
                user=request.user,
            )
            serializer = LeaveRequestDetailSerializer(lr)
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=True, methods=["post"])
    def approve(self, request, pk=None):
        lr = self.get_object()
        try:
            lr = services.approve_leave(lr, request.user, approve=True)
            return Response(LeaveRequestDetailSerializer(lr).data)
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=True, methods=["post"])
    def reject(self, request, pk=None):
        lr = self.get_object()
        reason = request.data.get("rejection_reason", "")
        try:
            lr = services.approve_leave(lr, request.user, approve=False, rejection_reason=reason)
            return Response(LeaveRequestDetailSerializer(lr).data)
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)


class SalaryComponentViewSet(viewsets.ModelViewSet):
    queryset = SalaryComponent.objects.all()
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return SalaryComponentListSerializer
        if self.action in ("create", "update", "partial_update"):
            return SalaryComponentCreateSerializer
        return SalaryComponentDetailSerializer


class SalaryStructureViewSet(viewsets.ModelViewSet):
    queryset = SalaryStructure.objects.prefetch_related("lines__component")
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return SalaryStructureListSerializer
        if self.action in ("create", "update", "partial_update"):
            return SalaryStructureCreateSerializer
        return SalaryStructureDetailSerializer


class PayrollViewSet(viewsets.ModelViewSet):
    queryset = Payroll.objects.select_related(
        "plant", "created_by", "approved_by", "salary_voucher", "pf_voucher"
    ).prefetch_related("lines")
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return PayrollListSerializer
        if self.action in ("create", "update", "partial_update"):
            return PayrollCreateSerializer
        return PayrollDetailSerializer

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)

    @action(detail=False, methods=["post"])
    def generate(self, request):
        """
        Generate payroll for plant/month/year.
        Payload: { "plant": <int>, "month": <int>, "year": <int> }
        Dispatches async Celery task.
        """
        from apps.hr.tasks import generate_payroll_task

        plant_id = request.data.get("plant")
        month = request.data.get("month")
        year = request.data.get("year")

        if not all([plant_id, month, year]):
            return Response(
                {"error": "plant, month, year are required."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        task = generate_payroll_task.delay(
            int(plant_id), int(month), int(year), request.user.pk
        )
        return Response({
            "message": "Payroll generation queued.",
            "task_id": task.id,
            "plant": plant_id, "month": month, "year": year,
        })

    @action(detail=True, methods=["post"])
    def approve(self, request, pk=None):
        payroll = self.get_object()
        if payroll.status not in ("REVIEW",):
            return Response(
                {"error": f"Cannot approve payroll in status '{payroll.status}'."},
                status=status.HTTP_400_BAD_REQUEST,
            )
        from django.utils import timezone
        payroll.status = "APPROVED"
        payroll.approved_by = request.user
        payroll.approved_at = timezone.now()
        payroll.save(update_fields=["status", "approved_by", "approved_at"])

        from apps.hr.tasks import send_payslip_notifications
        send_payslip_notifications.delay(payroll.pk)

        return Response(PayrollDetailSerializer(payroll).data)

    @action(detail=True, methods=["post"])
    def close(self, request, pk=None):
        payroll = self.get_object()
        try:
            payroll = services.close_payroll(payroll, closed_by=request.user)
            return Response(PayrollDetailSerializer(payroll).data)
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=True, methods=["get"])
    def bank_export(self, request, pk=None):
        """Download NEFT/RTGS bank upload file."""
        payroll = self.get_object()
        fmt = request.query_params.get("format", "NEFT").upper()
        try:
            content = services.export_payroll_to_bank(payroll, format=fmt)
            from django.http import HttpResponse
            response = HttpResponse(content, content_type="text/plain; charset=utf-8")
            response["Content-Disposition"] = (
                f'attachment; filename="{payroll.payroll_number}_{fmt}.txt"'
            )
            return response
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=True, methods=["get"])
    def pf_esi_summary(self, request, pk=None):
        """Return PF/ESI summary for the payroll."""
        payroll = self.get_object()
        lines = payroll.lines.select_related("employee")
        data = [
            {
                "employee_code": pl.employee.employee_code,
                "employee_name": pl.employee.full_name,
                "uan": pl.employee.uan,
                "esic_number": pl.employee.esic_number,
                "employer_pf": str(pl.employer_pf),
                "employer_esi": str(pl.employer_esi),
                "net_salary": str(pl.net_salary),
            }
            for pl in lines
        ]
        return Response({
            "payroll_number": payroll.payroll_number,
            "total_employer_pf": str(payroll.total_employer_pf),
            "total_employer_esi": str(payroll.total_employer_esi),
            "lines": data,
        })


class PayrollLineViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = PayrollLine.objects.select_related(
        "payroll", "employee"
    ).prefetch_related("parts__component")
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return PayrollLineListSerializer
        return PayrollLineDetailSerializer

    def get_queryset(self):
        qs = super().get_queryset()
        payroll = self.request.query_params.get("payroll")
        employee = self.request.query_params.get("employee")
        if payroll:
            qs = qs.filter(payroll=payroll)
        if employee:
            qs = qs.filter(employee=employee)
        return qs
