"""HR & Payroll API URL configuration."""
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from apps.hr.api.viewsets import (
    DepartmentViewSet, DesignationViewSet, EmployeeViewSet,
    AttendanceViewSet, LeaveTypeViewSet, LeaveRequestViewSet,
    SalaryComponentViewSet, SalaryStructureViewSet,
    PayrollViewSet, PayrollLineViewSet,
)

router = DefaultRouter()
router.register("departments", DepartmentViewSet, basename="hr-department")
router.register("designations", DesignationViewSet, basename="hr-designation")
router.register("employees", EmployeeViewSet, basename="employee")
router.register("attendance", AttendanceViewSet, basename="attendance")
router.register("leave-types", LeaveTypeViewSet, basename="leave-type")
router.register("leave-requests", LeaveRequestViewSet, basename="leave-request")
router.register("salary-components", SalaryComponentViewSet, basename="salary-component")
router.register("salary-structures", SalaryStructureViewSet, basename="salary-structure")
router.register("payrolls", PayrollViewSet, basename="payroll")
router.register("payroll-lines", PayrollLineViewSet, basename="payroll-line")

urlpatterns = [
    path("", include(router.urls)),
]
