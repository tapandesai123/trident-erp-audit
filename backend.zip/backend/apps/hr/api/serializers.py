"""HR & Payroll API Serializers — 3 variants per major model."""
from rest_framework import serializers
from apps.hr.models import (
    Department, Designation, Employee,
    Attendance, LeaveType, LeaveRequest,
    SalaryComponent, SalaryStructure, SalaryStructureLine,
    Payroll, PayrollLine, PayrollLinePart,
)


# ─── Department ───────────────────────────────────────────────────

class DepartmentListSerializer(serializers.ModelSerializer):
    plant_code = serializers.CharField(source="plant.code", read_only=True)

    class Meta:
        model = Department
        fields = ["id", "uuid", "code", "name", "plant", "plant_code", "is_active"]


class DepartmentDetailSerializer(serializers.ModelSerializer):
    plant_code = serializers.CharField(source="plant.code", read_only=True)
    head_name = serializers.SerializerMethodField()

    class Meta:
        model = Department
        fields = "__all__"

    def get_head_name(self, obj):
        return obj.head.get_full_name() if obj.head else None


class DepartmentCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Department
        fields = ["plant", "code", "name", "head", "is_active"]


# ─── Designation ──────────────────────────────────────────────────

class DesignationListSerializer(serializers.ModelSerializer):
    plant_code = serializers.CharField(source="plant.code", read_only=True)

    class Meta:
        model = Designation
        fields = ["id", "uuid", "code", "name", "grade", "plant", "plant_code", "is_active"]


class DesignationDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = Designation
        fields = "__all__"


class DesignationCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Designation
        fields = ["plant", "code", "name", "grade"]


# ─── Employee ─────────────────────────────────────────────────────

class EmployeeListSerializer(serializers.ModelSerializer):
    full_name = serializers.CharField(read_only=True)
    department_name = serializers.CharField(source="department.name", read_only=True)
    designation_name = serializers.CharField(source="designation.name", read_only=True)
    plant_code = serializers.CharField(source="plant.code", read_only=True)
    monthly_ctc = serializers.DecimalField(max_digits=14, decimal_places=2, read_only=True)

    class Meta:
        model = Employee
        fields = [
            "id", "uuid", "employee_code", "full_name",
            "department", "department_name",
            "designation", "designation_name",
            "employment_type", "status",
            "plant", "plant_code",
            "date_of_joining", "monthly_ctc",
        ]


class EmployeeDetailSerializer(serializers.ModelSerializer):
    full_name = serializers.CharField(read_only=True)
    monthly_ctc = serializers.DecimalField(max_digits=14, decimal_places=2, read_only=True)
    department_name = serializers.CharField(source="department.name", read_only=True)
    designation_name = serializers.CharField(source="designation.name", read_only=True)
    reporting_manager_name = serializers.SerializerMethodField()
    salary_structure_name = serializers.CharField(source="salary_structure.name", read_only=True)

    class Meta:
        model = Employee
        fields = "__all__"
        extra_kwargs = {
            "aadhaar": {"write_only": True},
            "bank_account_number": {"write_only": True},
        }

    def get_reporting_manager_name(self, obj):
        return obj.reporting_manager.full_name if obj.reporting_manager else None


class EmployeeCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Employee
        fields = [
            "plant", "employee_code", "first_name", "last_name",
            "gender", "date_of_birth", "pan", "aadhaar", "uan", "esic_number",
            "department", "designation", "employment_type",
            "date_of_joining", "reporting_manager",
            "email", "phone", "address",
            "bank_name", "bank_account_number", "bank_ifsc", "bank_account_type",
            "salary_structure", "ctc", "user",
        ]


# ─── Attendance ───────────────────────────────────────────────────

class AttendanceListSerializer(serializers.ModelSerializer):
    employee_code = serializers.CharField(source="employee.employee_code", read_only=True)
    employee_name = serializers.CharField(source="employee.full_name", read_only=True)

    class Meta:
        model = Attendance
        fields = [
            "id", "uuid", "employee", "employee_code", "employee_name",
            "date", "status", "in_time", "out_time", "overtime_hours",
        ]


class AttendanceDetailSerializer(serializers.ModelSerializer):
    employee_code = serializers.CharField(source="employee.employee_code", read_only=True)

    class Meta:
        model = Attendance
        fields = "__all__"


class AttendanceCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Attendance
        fields = ["employee", "date", "status", "in_time", "out_time", "overtime_hours", "remarks"]


# ─── Leave ────────────────────────────────────────────────────────

class LeaveTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = LeaveType
        fields = "__all__"


class LeaveRequestListSerializer(serializers.ModelSerializer):
    employee_code = serializers.CharField(source="employee.employee_code", read_only=True)
    employee_name = serializers.CharField(source="employee.full_name", read_only=True)
    leave_type_name = serializers.CharField(source="leave_type.name", read_only=True)

    class Meta:
        model = LeaveRequest
        fields = [
            "id", "uuid", "employee", "employee_code", "employee_name",
            "leave_type", "leave_type_name",
            "from_date", "to_date", "no_of_days", "status", "applied_on",
        ]


class LeaveRequestDetailSerializer(serializers.ModelSerializer):
    employee_code = serializers.CharField(source="employee.employee_code", read_only=True)
    leave_type_name = serializers.CharField(source="leave_type.name", read_only=True)
    approved_by_name = serializers.SerializerMethodField()

    class Meta:
        model = LeaveRequest
        fields = "__all__"

    def get_approved_by_name(self, obj):
        return obj.approved_by.get_full_name() if obj.approved_by else None


class LeaveRequestCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = LeaveRequest
        fields = ["employee", "leave_type", "from_date", "to_date", "reason"]


# ─── Salary Structure ─────────────────────────────────────────────

class SalaryComponentListSerializer(serializers.ModelSerializer):
    class Meta:
        model = SalaryComponent
        fields = [
            "id", "uuid", "code", "name", "component_type", "calc_type",
            "default_amount", "default_percentage", "is_taxable", "sequence", "is_active",
        ]


class SalaryComponentDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = SalaryComponent
        fields = "__all__"


class SalaryComponentCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = SalaryComponent
        fields = [
            "code", "name", "component_type", "calc_type",
            "default_amount", "default_percentage", "formula",
            "is_taxable", "sequence",
        ]


class SalaryStructureLineSerializer(serializers.ModelSerializer):
    component_code = serializers.CharField(source="component.code", read_only=True)
    component_name = serializers.CharField(source="component.name", read_only=True)
    component_type = serializers.CharField(source="component.component_type", read_only=True)

    class Meta:
        model = SalaryStructureLine
        fields = [
            "id", "component", "component_code", "component_name", "component_type",
            "override_amount", "override_percentage", "is_active",
        ]


class SalaryStructureListSerializer(serializers.ModelSerializer):
    line_count = serializers.IntegerField(source="lines.count", read_only=True)

    class Meta:
        model = SalaryStructure
        fields = ["id", "uuid", "code", "name", "line_count", "is_active"]


class SalaryStructureDetailSerializer(serializers.ModelSerializer):
    lines = SalaryStructureLineSerializer(many=True, read_only=True)

    class Meta:
        model = SalaryStructure
        fields = "__all__"


class SalaryStructureCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = SalaryStructure
        fields = ["code", "name", "description"]


# ─── Payroll ──────────────────────────────────────────────────────

class PayrollLinePartSerializer(serializers.ModelSerializer):
    component_code = serializers.CharField(source="component.code", read_only=True)
    component_name = serializers.CharField(source="component.name", read_only=True)
    component_type = serializers.CharField(source="component.component_type", read_only=True)
    amount = serializers.DecimalField(max_digits=14, decimal_places=2, read_only=True)

    class Meta:
        model = PayrollLinePart
        fields = [
            "id", "component", "component_code", "component_name", "component_type",
            "computed_amount", "override_amount", "amount",
        ]


class PayrollLineListSerializer(serializers.ModelSerializer):
    employee_code = serializers.CharField(source="employee.employee_code", read_only=True)
    employee_name = serializers.CharField(source="employee.full_name", read_only=True)

    class Meta:
        model = PayrollLine
        fields = [
            "id", "uuid", "employee", "employee_code", "employee_name",
            "days_present", "days_absent",
            "gross_salary", "total_deductions", "net_salary",
            "employer_pf", "employer_esi", "status",
        ]


class PayrollLineDetailSerializer(serializers.ModelSerializer):
    employee_code = serializers.CharField(source="employee.employee_code", read_only=True)
    employee_name = serializers.CharField(source="employee.full_name", read_only=True)
    parts = PayrollLinePartSerializer(many=True, read_only=True)

    class Meta:
        model = PayrollLine
        fields = "__all__"


class PayrollListSerializer(serializers.ModelSerializer):
    plant_code = serializers.CharField(source="plant.code", read_only=True)

    class Meta:
        model = Payroll
        fields = [
            "id", "uuid", "payroll_number", "plant", "plant_code",
            "month", "year", "status",
            "employee_count", "total_gross", "total_net",
            "period_start", "period_end",
        ]


class PayrollDetailSerializer(serializers.ModelSerializer):
    plant_code = serializers.CharField(source="plant.code", read_only=True)
    lines = PayrollLineListSerializer(many=True, read_only=True)
    salary_voucher_number = serializers.CharField(
        source="salary_voucher.voucher_number", read_only=True
    )
    pf_voucher_number = serializers.CharField(
        source="pf_voucher.voucher_number", read_only=True
    )

    class Meta:
        model = Payroll
        fields = "__all__"


class PayrollCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Payroll
        fields = ["plant", "month", "year", "notes"]
