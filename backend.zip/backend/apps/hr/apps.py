"""HR & Payroll app configuration."""
from django.apps import AppConfig


class HRConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.hr"
    verbose_name = "HR & Payroll"

    def ready(self):
        pass  # signals would be imported here if needed
