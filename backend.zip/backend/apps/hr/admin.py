"""HR & Payroll admin registrations."""
from django.contrib import admin
from django.utils.html import format_html
from apps.hr.models import (
    Department, Designation, Employee,
    Attendance, LeaveType, LeaveRequest,
    SalaryComponent, SalaryStructure, SalaryStructureLine,
    Payroll, PayrollLine, PayrollLinePart,
)


# ─── Organisation ─────────────────────────────────────────────────

@admin.register(Department)
class DepartmentAdmin(admin.ModelAdmin):
    list_display = ["code", "name", "plant", "head", "is_active"]
    list_filter = ["plant", "is_active"]
    search_fields = ["code", "name"]
    readonly_fields = ["uuid", "created_at", "updated_at"]


@admin.register(Designation)
class DesignationAdmin(admin.ModelAdmin):
    list_display = ["code", "name", "grade", "plant", "is_active"]
    list_filter = ["plant", "is_active"]
    search_fields = ["code", "name"]
    readonly_fields = ["uuid", "created_at", "updated_at"]


# ─── Employee ─────────────────────────────────────────────────────

@admin.register(Employee)
class EmployeeAdmin(admin.ModelAdmin):
    list_display = [
        "employee_code", "full_name", "department", "designation",
        "employment_type", "status", "date_of_joining", "plant",
    ]
    list_filter = ["status", "employment_type", "department", "plant"]
    search_fields = ["employee_code", "first_name", "last_name", "email", "pan"]
    readonly_fields = ["uuid", "full_name", "monthly_ctc", "created_at", "updated_at"]
    fieldsets = (
        ("Personal", {
            "fields": (
                "plant", "employee_code", "first_name", "last_name",
                "gender", "date_of_birth", "pan", "aadhaar",
                "uan", "esic_number", "email", "phone", "address",
            )
        }),
        ("Employment", {
            "fields": (
                "department", "designation", "employment_type",
                "date_of_joining", "date_of_leaving",
                "reporting_manager", "status", "user",
            )
        }),
        ("Salary", {
            "fields": ("salary_structure", "ctc", "monthly_ctc"),
        }),
        ("Bank", {
            "fields": (
                "bank_name", "bank_account_number", "bank_ifsc", "bank_account_type",
            )
        }),
        ("Metadata", {"fields": ("uuid", "created_at", "updated_at", "created_by")}),
    )

    def full_name(self, obj):
        return obj.full_name
    full_name.short_description = "Full Name"


# ─── Attendance ───────────────────────────────────────────────────

@admin.register(Attendance)
class AttendanceAdmin(admin.ModelAdmin):
    list_display = ["employee", "date", "status", "in_time", "out_time", "overtime_hours"]
    list_filter = ["status", "date"]
    search_fields = ["employee__employee_code", "employee__first_name"]
    readonly_fields = ["uuid", "created_at", "updated_at"]
    date_hierarchy = "date"


# ─── Leave ────────────────────────────────────────────────────────

@admin.register(LeaveType)
class LeaveTypeAdmin(admin.ModelAdmin):
    list_display = ["code", "name", "days_per_year", "is_paid", "carry_forward", "is_active"]
    search_fields = ["code", "name"]
    readonly_fields = ["uuid"]


@admin.register(LeaveRequest)
class LeaveRequestAdmin(admin.ModelAdmin):
    list_display = [
        "employee", "leave_type", "from_date", "to_date", "no_of_days",
        "status", "applied_on", "approved_by",
    ]
    list_filter = ["status", "leave_type"]
    search_fields = ["employee__employee_code", "employee__first_name"]
    readonly_fields = ["uuid", "applied_on", "created_at", "updated_at"]
    date_hierarchy = "from_date"


# ─── Salary Structure ─────────────────────────────────────────────

@admin.register(SalaryComponent)
class SalaryComponentAdmin(admin.ModelAdmin):
    list_display = [
        "code", "name", "component_type", "calc_type",
        "default_amount", "default_percentage", "is_taxable", "sequence", "is_active",
    ]
    list_filter = ["component_type", "calc_type", "is_active"]
    search_fields = ["code", "name"]
    readonly_fields = ["uuid"]


class SalaryStructureLineInline(admin.TabularInline):
    model = SalaryStructureLine
    extra = 0
    fields = ["component", "override_amount", "override_percentage", "is_active"]


@admin.register(SalaryStructure)
class SalaryStructureAdmin(admin.ModelAdmin):
    list_display = ["code", "name", "is_active"]
    search_fields = ["code", "name"]
    readonly_fields = ["uuid", "created_at", "updated_at"]
    inlines = [SalaryStructureLineInline]


# ─── Payroll ──────────────────────────────────────────────────────

class PayrollLineInline(admin.TabularInline):
    model = PayrollLine
    extra = 0
    fields = [
        "employee", "days_present", "days_absent", "gross_salary",
        "total_deductions", "net_salary", "employer_pf", "employer_esi", "status",
    ]
    readonly_fields = [
        "gross_salary", "total_deductions", "net_salary",
        "employer_pf", "employer_esi",
    ]
    can_delete = False


@admin.register(Payroll)
class PayrollAdmin(admin.ModelAdmin):
    list_display = [
        "payroll_number", "plant", "month", "year", "status",
        "employee_count", "total_gross", "total_net", "colored_status",
    ]
    list_filter = ["status", "plant", "year"]
    search_fields = ["payroll_number"]
    readonly_fields = [
        "uuid", "payroll_number", "total_gross", "total_deductions", "total_net",
        "total_employer_pf", "total_employer_esi", "employee_count",
        "created_at", "updated_at", "closed_at", "approved_at",
    ]
    inlines = [PayrollLineInline]

    def colored_status(self, obj):
        colors = {
            "DRAFT": "gray", "PROCESSING": "blue", "REVIEW": "orange",
            "APPROVED": "green", "CLOSED": "darkgreen", "CANCELLED": "red",
        }
        color = colors.get(obj.status, "black")
        return format_html('<span style="color: {}"><b>{}</b></span>', color, obj.status)
    colored_status.short_description = "Status"


class PayrollLinePartInline(admin.TabularInline):
    model = PayrollLinePart
    extra = 0
    fields = ["component", "computed_amount", "override_amount"]
    readonly_fields = ["component", "computed_amount"]


@admin.register(PayrollLine)
class PayrollLineAdmin(admin.ModelAdmin):
    list_display = [
        "payroll", "employee", "days_present", "gross_salary",
        "total_deductions", "net_salary", "status",
    ]
    list_filter = ["status", "payroll__status"]
    search_fields = ["employee__employee_code", "employee__first_name"]
    readonly_fields = ["uuid", "gross_salary", "total_deductions", "net_salary"]
    inlines = [PayrollLinePartInline]
