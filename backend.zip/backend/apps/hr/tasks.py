"""HR & Payroll Celery tasks."""
from celery import shared_task
from django.utils import timezone


@shared_task(bind=True, max_retries=3, default_retry_delay=120)
def generate_payroll_task(self, plant_id: int, month: int, year: int, user_id: int = None):
    """Async payroll generation for a plant/month."""
    try:
        from apps.core.models import Plant
        from apps.hr.services import generate_payroll

        plant = Plant.objects.get(pk=plant_id)
        user = None
        if user_id:
            from django.contrib.auth import get_user_model
            User = get_user_model()
            user = User.objects.filter(pk=user_id).first()

        payroll = generate_payroll(plant, month, year, user)
        return {
            "payroll_id": payroll.pk,
            "payroll_number": payroll.payroll_number,
            "employee_count": payroll.employee_count,
            "total_net": str(payroll.total_net),
        }
    except Exception as exc:
        raise self.retry(exc=exc)


@shared_task
def auto_mark_absent():
    """
    Periodic task: for all ACTIVE employees, mark yesterday as Absent
    if no attendance record exists for that date.
    Schedule: daily at midnight via Celery Beat.
    """
    from datetime import date, timedelta
    from apps.hr.models import Employee, Attendance

    yesterday = date.today() - timedelta(days=1)
    # Skip weekends (0=Mon, 6=Sun; 5=Sat, 6=Sun)
    if yesterday.weekday() in (5, 6):
        return {"skipped": "weekend"}

    active_employees = Employee.objects.filter(status="ACTIVE").values_list("pk", flat=True)
    already_marked = set(
        Attendance.objects.filter(
            employee_id__in=active_employees, date=yesterday
        ).values_list("employee_id", flat=True)
    )

    unmarked = [eid for eid in active_employees if eid not in already_marked]
    to_create = [
        Attendance(employee_id=eid, date=yesterday, status="A", remarks="Auto-marked absent")
        for eid in unmarked
    ]
    Attendance.objects.bulk_create(to_create, ignore_conflicts=True)
    return {"date": str(yesterday), "auto_absent_count": len(to_create)}


@shared_task
def send_payslip_notifications(payroll_id: int):
    """
    Notify employees that their payslip is ready after payroll is approved.
    """
    from apps.hr.models import Payroll, PayrollLine
    from apps.core.models import Notification

    try:
        payroll = Payroll.objects.get(pk=payroll_id)
    except Payroll.DoesNotExist:
        return {"error": "Payroll not found"}

    if payroll.status not in ("APPROVED", "CLOSED"):
        return {"skipped": "Payroll not approved"}

    lines = PayrollLine.objects.filter(
        payroll=payroll
    ).select_related("employee__user")

    notified = 0
    for pl in lines:
        emp = pl.employee
        if emp.user:
            Notification.objects.get_or_create(
                user=emp.user,
                module="hr",
                resource="PayrollLine",
                resource_id=pl.pk,
                title=f"Payslip ready: {payroll.month:02d}/{payroll.year}",
                defaults={
                    "message": (
                        f"Your payslip for {payroll.month:02d}/{payroll.year} is ready. "
                        f"Net Salary: ₹{pl.net_salary:,.2f}"
                    ),
                    "notification_type": "IN_APP",
                },
            )
            notified += 1

    return {"payroll": payroll.payroll_number, "notified": notified}


@shared_task
def send_leave_expiry_reminders():
    """
    Warn employees who have unused leave that will lapse at year-end.
    Run monthly. Only warns for non-carry-forward leave types.
    """
    from datetime import date
    from apps.hr.models import LeaveType, LeaveRequest, Employee
    from apps.core.models import Notification

    today = date.today()
    # Warn in November (month 11) about Dec 31 expiry
    if today.month != 11:
        return {"skipped": "Not November"}

    non_cf_types = LeaveType.objects.filter(carry_forward=False, is_active=True)
    warned = 0

    for lt in non_cf_types:
        employees = Employee.objects.filter(status="ACTIVE")
        for emp in employees:
            approved_days = LeaveRequest.objects.filter(
                employee=emp,
                leave_type=lt,
                status="APPROVED",
                from_date__year=today.year,
            ).aggregate(total=__import__("django.db.models", fromlist=["Sum"]).Sum("no_of_days"))["total"] or 0

            remaining = float(lt.days_per_year) - float(approved_days)
            if remaining > 0 and emp.user:
                Notification.objects.get_or_create(
                    user=emp.user,
                    module="hr",
                    resource="LeaveType",
                    resource_id=lt.pk,
                    title=f"Leave Expiry Reminder: {lt.name}",
                    defaults={
                        "message": (
                            f"You have {remaining:.1f} unused {lt.name} days "
                            f"that will lapse on 31-Dec-{today.year}."
                        ),
                        "notification_type": "IN_APP",
                    },
                )
                warned += 1

    return {"warned": warned}
