"""
HR & Payroll Module Models — Section 11

Models:
  Department       — HR department (separate from core.Department)
  Designation      — Job title / grade
  Employee         — Master record: personal, employment, bank details
  Attendance       — Daily attendance log (Present/Absent/Half-day/On-leave)
  LeaveRequest     — Leave application with approval workflow
  SalaryComponent  — Configurable earnings/deductions (Basic, HRA, PF, ESI …)
  SalaryStructure  — Named package: mapping of components to formulae
  SalaryStructureLine — One component inside a structure
  Payroll          — Monthly payroll run header
  PayrollLine      — Per-employee payroll computation inside a run
  PayrollLinePart  — Each component breakdown inside a PayrollLine
"""
import uuid
from decimal import Decimal
from django.db import models
from django.conf import settings
from apps.core.models import UUIDModel, TimeStampedModel, Plant


# ═══════════════════════════════════════════════════════════════════
# ORGANISATION
# ═══════════════════════════════════════════════════════════════════

class Department(UUIDModel, TimeStampedModel):
    plant = models.ForeignKey(Plant, on_delete=models.PROTECT, related_name="hr_departments")
    code = models.CharField(max_length=20)
    name = models.CharField(max_length=150)
    head = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="headed_hr_departments",
    )
    is_active = models.BooleanField(default=True)

    class Meta:
        unique_together = [["plant", "code"]]
        ordering = ["code"]

    def __str__(self):
        return f"{self.code} — {self.name}"


class Designation(UUIDModel, TimeStampedModel):
    plant = models.ForeignKey(Plant, on_delete=models.PROTECT, related_name="designations")
    code = models.CharField(max_length=20)
    name = models.CharField(max_length=150)
    grade = models.CharField(max_length=20, blank=True, help_text="Pay grade e.g. L1, M2")
    is_active = models.BooleanField(default=True)

    class Meta:
        unique_together = [["plant", "code"]]
        ordering = ["code"]

    def __str__(self):
        return f"{self.code} — {self.name}"


# ═══════════════════════════════════════════════════════════════════
# EMPLOYEE
# ═══════════════════════════════════════════════════════════════════

class Employee(UUIDModel, TimeStampedModel):
    GENDER_CHOICES = [("M", "Male"), ("F", "Female"), ("O", "Other")]
    EMPLOYMENT_TYPE = [
        ("PERMANENT", "Permanent"),
        ("CONTRACT", "Contract"),
        ("PROBATION", "Probation"),
        ("TRAINEE", "Trainee"),
        ("CONSULTANT", "Consultant"),
    ]
    STATUS_CHOICES = [
        ("ACTIVE", "Active"),
        ("RESIGNED", "Resigned"),
        ("TERMINATED", "Terminated"),
        ("RETIRED", "Retired"),
        ("ON_NOTICE", "On Notice"),
    ]

    plant = models.ForeignKey(Plant, on_delete=models.PROTECT, related_name="employees")
    employee_code = models.CharField(max_length=30, unique=True)
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100, blank=True)
    gender = models.CharField(max_length=1, choices=GENDER_CHOICES, blank=True)
    date_of_birth = models.DateField(null=True, blank=True)
    pan = models.CharField(max_length=10, blank=True, verbose_name="PAN")
    aadhaar = models.CharField(max_length=12, blank=True)
    uan = models.CharField(max_length=12, blank=True, verbose_name="UAN (PF)")
    esic_number = models.CharField(max_length=20, blank=True, verbose_name="ESIC No.")

    # Employment
    department = models.ForeignKey(
        Department, on_delete=models.PROTECT, related_name="employees"
    )
    designation = models.ForeignKey(
        Designation, on_delete=models.PROTECT, related_name="employees"
    )
    employment_type = models.CharField(max_length=20, choices=EMPLOYMENT_TYPE, default="PERMANENT")
    date_of_joining = models.DateField()
    date_of_leaving = models.DateField(null=True, blank=True)
    reporting_manager = models.ForeignKey(
        "self", on_delete=models.SET_NULL, null=True, blank=True,
        related_name="reportees",
    )
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="ACTIVE")

    # Contact
    email = models.EmailField(blank=True)
    phone = models.CharField(max_length=20, blank=True)
    address = models.TextField(blank=True)

    # Bank details for salary
    bank_name = models.CharField(max_length=100, blank=True)
    bank_account_number = models.CharField(max_length=30, blank=True)
    bank_ifsc = models.CharField(max_length=11, blank=True, verbose_name="IFSC Code")
    bank_account_type = models.CharField(
        max_length=20, blank=True,
        choices=[("SAVINGS", "Savings"), ("CURRENT", "Current")],
        default="SAVINGS",
    )

    # Salary
    salary_structure = models.ForeignKey(
        "SalaryStructure", on_delete=models.SET_NULL,
        null=True, blank=True, related_name="employees",
    )
    ctc = models.DecimalField(
        max_digits=14, decimal_places=2, default=0,
        verbose_name="Annual CTC",
    )

    # Linked user account (optional)
    user = models.OneToOneField(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="employee_profile",
    )

    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="employees_created",
    )

    class Meta:
        ordering = ["employee_code"]
        indexes = [
            models.Index(fields=["plant", "status"]),
            models.Index(fields=["department"]),
        ]

    def __str__(self):
        return f"{self.employee_code} — {self.first_name} {self.last_name}"

    @property
    def full_name(self):
        return f"{self.first_name} {self.last_name}".strip()

    @property
    def monthly_ctc(self):
        return (self.ctc / 12).quantize(Decimal("0.01"))


# ═══════════════════════════════════════════════════════════════════
# ATTENDANCE
# ═══════════════════════════════════════════════════════════════════

class Attendance(UUIDModel, TimeStampedModel):
    STATUS_CHOICES = [
        ("P", "Present"),
        ("A", "Absent"),
        ("H", "Half Day"),
        ("L", "On Leave"),
        ("PH", "Public Holiday"),
        ("WO", "Week Off"),
        ("CO", "Comp Off"),
    ]

    employee = models.ForeignKey(Employee, on_delete=models.CASCADE, related_name="attendances")
    date = models.DateField(db_index=True)
    status = models.CharField(max_length=5, choices=STATUS_CHOICES, default="P")
    in_time = models.TimeField(null=True, blank=True)
    out_time = models.TimeField(null=True, blank=True)
    overtime_hours = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    remarks = models.CharField(max_length=300, blank=True)
    marked_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="attendances_marked",
    )

    class Meta:
        unique_together = [["employee", "date"]]
        ordering = ["-date", "employee__employee_code"]

    def __str__(self):
        return f"{self.employee.employee_code} | {self.date} | {self.get_status_display()}"


# ═══════════════════════════════════════════════════════════════════
# LEAVE
# ═══════════════════════════════════════════════════════════════════

class LeaveType(UUIDModel, TimeStampedModel):
    code = models.CharField(max_length=10, unique=True)
    name = models.CharField(max_length=100)
    days_per_year = models.DecimalField(max_digits=5, decimal_places=1, default=0)
    is_paid = models.BooleanField(default=True)
    carry_forward = models.BooleanField(default=False)
    max_carry_forward = models.DecimalField(max_digits=5, decimal_places=1, default=0)
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ["code"]

    def __str__(self):
        return f"{self.code} — {self.name}"


class LeaveRequest(UUIDModel, TimeStampedModel):
    STATUS_CHOICES = [
        ("DRAFT", "Draft"),
        ("APPLIED", "Applied"),
        ("APPROVED", "Approved"),
        ("REJECTED", "Rejected"),
        ("CANCELLED", "Cancelled"),
    ]

    employee = models.ForeignKey(Employee, on_delete=models.CASCADE, related_name="leave_requests")
    leave_type = models.ForeignKey(LeaveType, on_delete=models.PROTECT, related_name="requests")
    from_date = models.DateField()
    to_date = models.DateField()
    no_of_days = models.DecimalField(max_digits=5, decimal_places=1, default=0)
    reason = models.TextField(blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="DRAFT")
    applied_on = models.DateTimeField(auto_now_add=True)
    approved_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="leave_approvals",
    )
    approved_on = models.DateTimeField(null=True, blank=True)
    rejection_reason = models.TextField(blank=True)

    class Meta:
        ordering = ["-from_date"]
        indexes = [
            models.Index(fields=["employee", "status"]),
            models.Index(fields=["from_date", "to_date"]),
        ]

    def __str__(self):
        return f"{self.employee.employee_code} | {self.leave_type.code} | {self.from_date}–{self.to_date}"


# ═══════════════════════════════════════════════════════════════════
# SALARY STRUCTURE
# ═══════════════════════════════════════════════════════════════════

class SalaryComponent(UUIDModel, TimeStampedModel):
    COMPONENT_TYPE = [
        ("EARNING", "Earning"),
        ("DEDUCTION", "Deduction"),
        ("STATUTORY", "Statutory Deduction"),
        ("EMPLOYER_CONTRIBUTION", "Employer Contribution"),
    ]
    CALC_TYPE = [
        ("FIXED", "Fixed Amount"),
        ("PCT_BASIC", "% of Basic"),
        ("PCT_GROSS", "% of Gross"),
        ("FORMULA", "Custom Formula"),
        ("STATUTORY", "Statutory (PF/ESI)"),
    ]

    code = models.CharField(max_length=20, unique=True)
    name = models.CharField(max_length=150)
    component_type = models.CharField(max_length=30, choices=COMPONENT_TYPE, default="EARNING")
    calc_type = models.CharField(max_length=20, choices=CALC_TYPE, default="FIXED")
    default_amount = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    default_percentage = models.DecimalField(max_digits=6, decimal_places=4, default=0)
    formula = models.TextField(
        blank=True,
        help_text="Python-safe expression. Variables: basic, gross, ctc, days_worked, total_days",
    )
    is_taxable = models.BooleanField(default=True)
    is_active = models.BooleanField(default=True)
    sequence = models.PositiveSmallIntegerField(default=100)

    # For statutory: link to accounting
    pf_account_code = models.CharField(max_length=50, blank=True)
    esi_account_code = models.CharField(max_length=50, blank=True)

    class Meta:
        ordering = ["sequence", "code"]

    def __str__(self):
        return f"{self.code} — {self.name} ({self.get_component_type_display()})"


class SalaryStructure(UUIDModel, TimeStampedModel):
    code = models.CharField(max_length=20, unique=True)
    name = models.CharField(max_length=150)
    description = models.TextField(blank=True)
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ["code"]

    def __str__(self):
        return f"{self.code} — {self.name}"


class SalaryStructureLine(models.Model):
    structure = models.ForeignKey(
        SalaryStructure, on_delete=models.CASCADE, related_name="lines"
    )
    component = models.ForeignKey(
        SalaryComponent, on_delete=models.PROTECT, related_name="structure_lines"
    )
    override_amount = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)
    override_percentage = models.DecimalField(max_digits=6, decimal_places=4, null=True, blank=True)
    is_active = models.BooleanField(default=True)

    class Meta:
        unique_together = [["structure", "component"]]
        ordering = ["component__sequence"]

    def __str__(self):
        return f"{self.structure.code} / {self.component.code}"


# ═══════════════════════════════════════════════════════════════════
# PAYROLL
# ═══════════════════════════════════════════════════════════════════

class Payroll(UUIDModel, TimeStampedModel):
    STATUS_CHOICES = [
        ("DRAFT", "Draft"),
        ("PROCESSING", "Processing"),
        ("REVIEW", "Under Review"),
        ("APPROVED", "Approved"),
        ("CLOSED", "Closed"),
        ("CANCELLED", "Cancelled"),
    ]

    plant = models.ForeignKey(Plant, on_delete=models.PROTECT, related_name="payrolls")
    payroll_number = models.CharField(max_length=50, unique=True)
    month = models.PositiveSmallIntegerField(help_text="1=Jan … 12=Dec")
    year = models.PositiveSmallIntegerField()
    period_start = models.DateField()
    period_end = models.DateField()
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="DRAFT")

    # Totals (populated on generate)
    total_gross = models.DecimalField(max_digits=16, decimal_places=2, default=0)
    total_deductions = models.DecimalField(max_digits=16, decimal_places=2, default=0)
    total_net = models.DecimalField(max_digits=16, decimal_places=2, default=0)
    total_employer_pf = models.DecimalField(max_digits=16, decimal_places=2, default=0)
    total_employer_esi = models.DecimalField(max_digits=16, decimal_places=2, default=0)
    employee_count = models.PositiveIntegerField(default=0)

    # Linked accounting voucher
    salary_voucher = models.ForeignKey(
        "accounts.Voucher", on_delete=models.SET_NULL,
        null=True, blank=True, related_name="payrolls",
    )
    pf_voucher = models.ForeignKey(
        "accounts.Voucher", on_delete=models.SET_NULL,
        null=True, blank=True, related_name="pf_payrolls",
    )

    notes = models.TextField(blank=True)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="payrolls_created",
    )
    approved_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="payrolls_approved",
    )
    approved_at = models.DateTimeField(null=True, blank=True)
    closed_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        unique_together = [["plant", "month", "year"]]
        ordering = ["-year", "-month"]

    def __str__(self):
        return f"{self.payroll_number} ({self.month:02d}/{self.year})"


class PayrollLine(UUIDModel, TimeStampedModel):
    STATUS_CHOICES = [
        ("COMPUTED", "Computed"),
        ("HOLD", "Hold"),
        ("PAID", "Paid"),
    ]

    payroll = models.ForeignKey(Payroll, on_delete=models.CASCADE, related_name="lines")
    employee = models.ForeignKey(Employee, on_delete=models.PROTECT, related_name="payroll_lines")

    # Attendance metrics for this month
    working_days = models.DecimalField(max_digits=5, decimal_places=1, default=0)
    days_present = models.DecimalField(max_digits=5, decimal_places=1, default=0)
    days_absent = models.DecimalField(max_digits=5, decimal_places=1, default=0)
    days_leave = models.DecimalField(max_digits=5, decimal_places=1, default=0)
    overtime_hours = models.DecimalField(max_digits=6, decimal_places=2, default=0)

    # Amounts
    gross_salary = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    total_deductions = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    net_salary = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    employer_pf = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    employer_esi = models.DecimalField(max_digits=12, decimal_places=2, default=0)

    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="COMPUTED")
    bank_transfer_ref = models.CharField(max_length=100, blank=True)
    remarks = models.CharField(max_length=300, blank=True)

    class Meta:
        unique_together = [["payroll", "employee"]]
        ordering = ["employee__employee_code"]

    def __str__(self):
        return f"{self.payroll.payroll_number} / {self.employee.employee_code}"


class PayrollLinePart(models.Model):
    """Breakdown of each salary component for a PayrollLine."""
    payroll_line = models.ForeignKey(
        PayrollLine, on_delete=models.CASCADE, related_name="parts"
    )
    component = models.ForeignKey(
        SalaryComponent, on_delete=models.PROTECT, related_name="payroll_parts"
    )
    computed_amount = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    override_amount = models.DecimalField(max_digits=14, decimal_places=2, null=True, blank=True)

    @property
    def amount(self):
        return self.override_amount if self.override_amount is not None else self.computed_amount

    class Meta:
        unique_together = [["payroll_line", "component"]]
        ordering = ["component__sequence"]

    def __str__(self):
        return f"{self.payroll_line} / {self.component.code} = {self.amount}"
