"""
HR & Payroll Module Tests — Section 11
22 test cases covering models, services, attendance, leave, payroll generation,
PF/ESI calculation, bank export, and API actions.
"""
from decimal import Decimal
from datetime import date, timedelta
from django.test import TestCase
from django.contrib.auth import get_user_model

from apps.core.models import Plant, Company
from apps.hr.models import (
    Department, Designation, Employee,
    Attendance, LeaveType, LeaveRequest,
    SalaryComponent, SalaryStructure, SalaryStructureLine,
    Payroll, PayrollLine, PayrollLinePart,
)
from apps.hr import services

User = get_user_model()


# ─── Fixtures ─────────────────────────────────────────────────────

def make_base():
    company = Company.objects.create(name="HR Test Co", financial_year_start=4)
    plant = Plant.objects.create(company=company, code="HP1", name="HR Plant 1")
    hr_user = User.objects.create_user(username="hrmanager", email="hr@test.com", password="x")
    return dict(company=company, plant=plant, hr_user=hr_user)


def make_salary_structure(plant):
    basic = SalaryComponent.objects.create(
        code="BASIC", name="Basic Salary",
        component_type="EARNING", calc_type="FIXED",
        default_amount=Decimal("20000"), sequence=10,
    )
    hra = SalaryComponent.objects.create(
        code="HRA", name="House Rent Allowance",
        component_type="EARNING", calc_type="PCT_BASIC",
        default_percentage=Decimal("40"), sequence=20,
    )
    pf = SalaryComponent.objects.create(
        code="PF", name="PF Deduction",
        component_type="STATUTORY", calc_type="STATUTORY",
        sequence=50,
    )
    esi = SalaryComponent.objects.create(
        code="ESI", name="ESI Deduction",
        component_type="STATUTORY", calc_type="STATUTORY",
        sequence=51,
    )
    structure = SalaryStructure.objects.create(code="STD", name="Standard Structure")
    SalaryStructureLine.objects.create(structure=structure, component=basic)
    SalaryStructureLine.objects.create(structure=structure, component=hra)
    SalaryStructureLine.objects.create(structure=structure, component=pf)
    SalaryStructureLine.objects.create(structure=structure, component=esi)
    return structure


def make_employee(plant, department, designation, structure, user=None, ctc=Decimal("360000")):
    return Employee.objects.create(
        plant=plant,
        employee_code=f"EMP{Employee.objects.count() + 1:04d}",
        first_name="Test",
        last_name="Employee",
        department=department,
        designation=designation,
        date_of_joining=date(2024, 1, 1),
        status="ACTIVE",
        employment_type="PERMANENT",
        salary_structure=structure,
        ctc=ctc,
        bank_account_number="1234567890",
        bank_ifsc="HDFC0001234",
        bank_name="HDFC Bank",
        uan="100000000001",
        user=user,
    )


# ═══════════════════════════════════════════════════════════════════
# MODEL TESTS
# ═══════════════════════════════════════════════════════════════════

class TestHRModels(TestCase):
    def setUp(self):
        self.f = make_base()
        self.dept = Department.objects.create(
            plant=self.f["plant"], code="HR", name="Human Resources"
        )
        self.desig = Designation.objects.create(
            plant=self.f["plant"], code="MGR", name="Manager", grade="M1"
        )
        self.structure = make_salary_structure(self.f["plant"])
        self.emp = make_employee(
            self.f["plant"], self.dept, self.desig, self.structure
        )

    def test_01_department_str(self):
        self.assertIn("HR", str(self.dept))

    def test_02_employee_full_name(self):
        self.assertEqual(self.emp.full_name, "Test Employee")

    def test_03_employee_monthly_ctc(self):
        expected = Decimal("360000") / 12
        self.assertEqual(self.emp.monthly_ctc, expected.quantize(Decimal("0.01")))

    def test_04_salary_structure_line_count(self):
        self.assertEqual(self.structure.lines.count(), 4)

    def test_05_attendance_str(self):
        att = Attendance.objects.create(
            employee=self.emp, date=date(2025, 10, 1), status="P"
        )
        self.assertIn("P", str(att))

    def test_06_leave_request_str(self):
        lt = LeaveType.objects.create(code="CL", name="Casual Leave", days_per_year=12, is_paid=True)
        lr = LeaveRequest.objects.create(
            employee=self.emp, leave_type=lt,
            from_date=date(2025, 10, 5), to_date=date(2025, 10, 6),
            no_of_days=2, status="APPLIED",
        )
        self.assertIn(self.emp.employee_code, str(lr))


# ═══════════════════════════════════════════════════════════════════
# PF / ESI CALCULATION TESTS
# ═══════════════════════════════════════════════════════════════════

class TestPFESICalculation(TestCase):

    def test_07_pf_esi_normal(self):
        result = services.calculate_pf_esi(Decimal("20000"), Decimal("28000"))
        # PF: 12% of min(20000, 15000) = 12% of 15000 = 1800
        self.assertEqual(result["employee_pf"], Decimal("1800.00"))
        self.assertEqual(result["employer_pf"], Decimal("1800.00"))
        # ESI: gross 28000 > 21000 → not applicable
        self.assertEqual(result["employee_esi"], Decimal("0.00"))
        self.assertFalse(result["esi_applicable"])

    def test_08_pf_esi_low_salary(self):
        result = services.calculate_pf_esi(Decimal("10000"), Decimal("12000"))
        # PF: 12% of 10000 = 1200
        self.assertEqual(result["employee_pf"], Decimal("1200.00"))
        # ESI: 0.75% of 12000 = 90
        self.assertEqual(result["employee_esi"], Decimal("90.00"))
        self.assertEqual(result["employer_esi"], Decimal("390.00"))
        self.assertTrue(result["esi_applicable"])

    def test_09_pf_ceiling_applied(self):
        result = services.calculate_pf_esi(Decimal("50000"), Decimal("80000"))
        # PF capped at 15000: 12% of 15000 = 1800
        self.assertEqual(result["employee_pf"], Decimal("1800.00"))
        self.assertEqual(result["pf_base"], Decimal("15000.00"))


# ═══════════════════════════════════════════════════════════════════
# ATTENDANCE TESTS
# ═══════════════════════════════════════════════════════════════════

class TestAttendance(TestCase):
    def setUp(self):
        self.f = make_base()
        self.dept = Department.objects.create(
            plant=self.f["plant"], code="OPS", name="Operations"
        )
        self.desig = Designation.objects.create(
            plant=self.f["plant"], code="ENG", name="Engineer"
        )
        self.structure = make_salary_structure(self.f["plant"])
        self.emp = make_employee(
            self.f["plant"], self.dept, self.desig, self.structure
        )

    def test_10_mark_attendance_present(self):
        att_date = date.today() - timedelta(days=1)
        records = [{"employee_id": self.emp.pk, "status": "P", "overtime_hours": 0}]
        result = services.mark_attendance(
            self.f["plant"], att_date, records, self.f["hr_user"]
        )
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0].status, "P")

    def test_11_mark_attendance_future_raises(self):
        future = date.today() + timedelta(days=1)
        records = [{"employee_id": self.emp.pk, "status": "P"}]
        with self.assertRaises(ValueError):
            services.mark_attendance(self.f["plant"], future, records)

    def test_12_mark_attendance_upsert(self):
        att_date = date.today() - timedelta(days=2)
        records = [{"employee_id": self.emp.pk, "status": "P"}]
        services.mark_attendance(self.f["plant"], att_date, records)
        # Mark again as Absent — should update
        records[0]["status"] = "A"
        services.mark_attendance(self.f["plant"], att_date, records)
        self.assertEqual(Attendance.objects.get(employee=self.emp, date=att_date).status, "A")


# ═══════════════════════════════════════════════════════════════════
# LEAVE TESTS
# ═══════════════════════════════════════════════════════════════════

class TestLeave(TestCase):
    def setUp(self):
        self.f = make_base()
        self.dept = Department.objects.create(
            plant=self.f["plant"], code="FIN", name="Finance"
        )
        self.desig = Designation.objects.create(
            plant=self.f["plant"], code="ANL", name="Analyst"
        )
        self.structure = make_salary_structure(self.f["plant"])
        self.emp = make_employee(
            self.f["plant"], self.dept, self.desig, self.structure,
            user=self.f["hr_user"]
        )
        self.lt = LeaveType.objects.create(
            code="EL", name="Earned Leave", days_per_year=21, is_paid=True
        )

    def test_13_apply_leave_success(self):
        lr = services.apply_leave(
            self.emp, self.lt,
            date(2025, 11, 10), date(2025, 11, 12),
            reason="Personal work",
            user=self.f["hr_user"],
        )
        self.assertEqual(lr.status, "APPLIED")
        self.assertEqual(lr.no_of_days, Decimal("3"))

    def test_14_apply_leave_invalid_dates(self):
        with self.assertRaises(ValueError):
            services.apply_leave(
                self.emp, self.lt,
                date(2025, 11, 12), date(2025, 11, 10),
            )

    def test_15_apply_leave_overlap_rejected(self):
        services.apply_leave(
            self.emp, self.lt,
            date(2025, 12, 1), date(2025, 12, 5),
        )
        with self.assertRaises(ValueError):
            services.apply_leave(
                self.emp, self.lt,
                date(2025, 12, 3), date(2025, 12, 7),
            )

    def test_16_approve_leave(self):
        lr = services.apply_leave(
            self.emp, self.lt,
            date(2026, 1, 5), date(2026, 1, 6),
        )
        lr = services.approve_leave(lr, self.f["hr_user"], approve=True)
        self.assertEqual(lr.status, "APPROVED")
        # Attendance records created
        self.assertTrue(
            Attendance.objects.filter(employee=self.emp, date=date(2026, 1, 5), status="L").exists()
        )

    def test_17_reject_leave(self):
        lr = services.apply_leave(
            self.emp, self.lt,
            date(2026, 2, 10), date(2026, 2, 11),
        )
        lr = services.approve_leave(lr, self.f["hr_user"], approve=False, rejection_reason="Not enough leave")
        self.assertEqual(lr.status, "REJECTED")
        self.assertIn("Not enough leave", lr.rejection_reason)


# ═══════════════════════════════════════════════════════════════════
# PAYROLL TESTS
# ═══════════════════════════════════════════════════════════════════

class TestPayroll(TestCase):
    def setUp(self):
        self.f = make_base()
        self.dept = Department.objects.create(
            plant=self.f["plant"], code="PROD", name="Production"
        )
        self.desig = Designation.objects.create(
            plant=self.f["plant"], code="OP", name="Operator"
        )
        self.structure = make_salary_structure(self.f["plant"])
        self.emp1 = make_employee(
            self.f["plant"], self.dept, self.desig, self.structure, ctc=Decimal("240000")
        )
        self.emp2 = make_employee(
            self.f["plant"], self.dept, self.desig, self.structure, ctc=Decimal("360000")
        )

    def test_18_generate_payroll_creates_header(self):
        payroll = services.generate_payroll(self.f["plant"], 10, 2025, self.f["hr_user"])
        self.assertEqual(payroll.status, "REVIEW")
        self.assertEqual(payroll.employee_count, 2)
        self.assertTrue(payroll.payroll_number.startswith("PAY/"))

    def test_19_payroll_lines_created(self):
        payroll = services.generate_payroll(self.f["plant"], 10, 2025)
        self.assertEqual(PayrollLine.objects.filter(payroll=payroll).count(), 2)

    def test_20_payroll_parts_created(self):
        payroll = services.generate_payroll(self.f["plant"], 10, 2025)
        lines = PayrollLine.objects.filter(payroll=payroll)
        for line in lines:
            self.assertGreater(line.parts.count(), 0)

    def test_21_payroll_totals_non_zero(self):
        payroll = services.generate_payroll(self.f["plant"], 10, 2025)
        self.assertGreater(payroll.total_gross, Decimal("0"))
        self.assertGreater(payroll.total_net, Decimal("0"))

    def test_22_bank_export_bytes(self):
        payroll = services.generate_payroll(self.f["plant"], 10, 2025)
        # Must be in REVIEW or later state with computed lines
        content = services.export_payroll_to_bank(payroll, format="NEFT")
        self.assertIsInstance(content, bytes)
        text = content.decode("utf-8")
        self.assertIn("NEFT", text)
        self.assertIn(payroll.payroll_number, text)
        # Lines marked PAID after export
        self.assertTrue(
            PayrollLine.objects.filter(payroll=payroll, status="PAID").exists()
        )
