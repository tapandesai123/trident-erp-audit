"""
HR & Payroll Module Services — Section 11

All business logic. No logic in viewsets.

Services:
  mark_attendance()          — Bulk-mark daily attendance for a list of employees
  apply_leave()              — Submit leave request (validates balance)
  approve_leave()            — HR/manager approves or rejects a leave
  generate_payroll()         — Build PayrollLine + PayrollLinePart for entire plant/month
  close_payroll()            — Mark as CLOSED, create salary journal + PF/ESI voucher
  calculate_pf_esi()         — Return (employee_pf, employee_esi, employer_pf, employer_esi)
  export_payroll_to_bank()   — NEFT/RTGS formatted text file for bank upload
"""
from __future__ import annotations

import io
import calendar
from datetime import date, timedelta
from decimal import Decimal, ROUND_HALF_UP
from typing import Optional

from django.db import transaction
from django.utils import timezone

from apps.core.models import AuditLog, DocSequence, Notification

# ─── Helpers ──────────────────────────────────────────────────────

def _two(val) -> Decimal:
    return Decimal(str(val)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def _log(user, action: str, resource: str, resource_id, details: dict = None):
    AuditLog.objects.create(
        user=user,
        action=action,
        module="hr",
        resource=resource,
        resource_id=resource_id,
        new_values=details or {},
    )


def _notify(user, title: str, message: str, resource: str, resource_id):
    if user:
        Notification.objects.create(
            user=user,
            title=title,
            message=message,
            notification_type="IN_APP",
            module="hr",
            resource=resource,
            resource_id=resource_id,
        )


def get_next_doc_number(plant, doc_type: str, prefix: str) -> str:
    """Thread-safe sequential document numbering."""
    today = date.today()
    fy_start = today.year if today.month >= 4 else today.year - 1
    fy_label = f"{fy_start}-{str(fy_start + 1)[2:]}"

    with transaction.atomic():
        seq, _ = DocSequence.objects.select_for_update().get_or_create(
            plant=plant,
            doc_type=doc_type,
            defaults={"last_number": 0, "financial_year": fy_label},
        )
        if seq.financial_year != fy_label:
            seq.financial_year = fy_label
            seq.last_number = 0

        seq.last_number += 1
        seq.save(update_fields=["last_number", "financial_year"])
        return f"{prefix}/{fy_label}/{seq.last_number:05d}"


# ─── PF / ESI CALCULATION ─────────────────────────────────────────

# Statutory rates (India, FY 2025-26)
PF_EMPLOYEE_PCT = Decimal("12")       # 12% of Basic (employee)
PF_EMPLOYER_PCT = Decimal("12")       # 12% of Basic (employer — to EPF + EPS)
ESI_EMPLOYEE_PCT = Decimal("0.75")    # 0.75% of Gross
ESI_EMPLOYER_PCT = Decimal("3.25")    # 3.25% of Gross
ESI_WAGE_CEILING = Decimal("21000")   # ESI applies only if Gross <= 21000
PF_WAGE_CEILING = Decimal("15000")    # PF on max ₹15,000 Basic
PROFESSIONAL_TAX_DEFAULT = Decimal("200")  # monthly PT default


def calculate_pf_esi(
    basic: Decimal,
    gross: Decimal,
) -> dict:
    """
    Returns a dict with all four PF/ESI components (employee + employer).

    PF: 12% of min(Basic, 15000) for both employee and employer.
    ESI: applicable only when gross <= 21000.
      - Employee: 0.75% of Gross
      - Employer: 3.25% of Gross
    """
    pf_base = min(_two(basic), PF_WAGE_CEILING)
    employee_pf = _two(pf_base * PF_EMPLOYEE_PCT / 100)
    employer_pf = _two(pf_base * PF_EMPLOYER_PCT / 100)

    if gross <= ESI_WAGE_CEILING:
        employee_esi = _two(gross * ESI_EMPLOYEE_PCT / 100)
        employer_esi = _two(gross * ESI_EMPLOYER_PCT / 100)
    else:
        employee_esi = Decimal("0.00")
        employer_esi = Decimal("0.00")

    return {
        "employee_pf": employee_pf,
        "employer_pf": employer_pf,
        "employee_esi": employee_esi,
        "employer_esi": employer_esi,
        "pf_base": pf_base,
        "esi_applicable": gross <= ESI_WAGE_CEILING,
    }


# ─── ATTENDANCE ───────────────────────────────────────────────────

@transaction.atomic
def mark_attendance(
    plant,
    attendance_date: date,
    records: list[dict],
    marked_by=None,
) -> list:
    """
    Bulk-mark attendance for a list of employees on a given date.

    records: list of {"employee_id": int, "status": "P"|"A"|"H"|"L"|"PH"|"WO"|"CO",
                       "in_time": time|None, "out_time": time|None,
                       "overtime_hours": Decimal, "remarks": str}

    Returns list of Attendance objects (created or updated).
    """
    from apps.hr.models import Attendance, Employee

    if attendance_date > date.today():
        raise ValueError("Cannot mark attendance for a future date.")

    results = []
    for rec in records:
        emp = Employee.objects.select_related("plant").get(
            pk=rec["employee_id"], plant=plant
        )
        att, created = Attendance.objects.update_or_create(
            employee=emp,
            date=attendance_date,
            defaults={
                "status": rec.get("status", "P"),
                "in_time": rec.get("in_time"),
                "out_time": rec.get("out_time"),
                "overtime_hours": _two(rec.get("overtime_hours", 0)),
                "remarks": rec.get("remarks", ""),
                "marked_by": marked_by,
            },
        )
        results.append(att)

    _log(
        marked_by, "CREATE", "Attendance", attendance_date.isoformat(),
        {"date": str(attendance_date), "count": len(results)},
    )
    return results


# ─── LEAVE ────────────────────────────────────────────────────────

@transaction.atomic
def apply_leave(
    employee,
    leave_type,
    from_date: date,
    to_date: date,
    reason: str = "",
    user=None,
) -> "LeaveRequest":
    """
    Submit a leave request.

    Validates:
    - from_date <= to_date
    - No overlapping pending/approved leave for the same employee
    - Employee is ACTIVE
    """
    from apps.hr.models import LeaveRequest

    if from_date > to_date:
        raise ValueError("from_date must be on or before to_date.")

    if employee.status != "ACTIVE":
        raise ValueError(f"Employee {employee.employee_code} is not ACTIVE.")

    # Overlap check
    overlap = LeaveRequest.objects.filter(
        employee=employee,
        status__in=("APPLIED", "APPROVED"),
        from_date__lte=to_date,
        to_date__gte=from_date,
    ).exists()
    if overlap:
        raise ValueError("Overlapping leave request already exists for this period.")

    # Calculate number of days (simple calendar days; weekends excluded if needed)
    delta = (to_date - from_date).days + 1
    no_of_days = Decimal(str(delta))

    lr = LeaveRequest.objects.create(
        employee=employee,
        leave_type=leave_type,
        from_date=from_date,
        to_date=to_date,
        no_of_days=no_of_days,
        reason=reason,
        status="APPLIED",
    )

    _log(user or (employee.user if employee.user else None), "CREATE", "LeaveRequest", lr.pk,
         {"employee": employee.employee_code, "leave_type": leave_type.code,
          "from": str(from_date), "to": str(to_date), "days": str(no_of_days)})

    # Notify manager
    if employee.reporting_manager and employee.reporting_manager.user:
        _notify(
            employee.reporting_manager.user,
            f"Leave request from {employee.full_name}",
            f"{employee.full_name} applied for {leave_type.name} from {from_date} to {to_date}.",
            "LeaveRequest", lr.pk,
        )

    return lr


@transaction.atomic
def approve_leave(leave_request, approved_by, approve: bool, rejection_reason: str = "") -> "LeaveRequest":
    """
    Approve or reject a leave request.

    On approval, marks corresponding Attendance records as 'L'.
    """
    from apps.hr.models import LeaveRequest, Attendance

    if leave_request.status not in ("APPLIED",):
        raise ValueError(f"Cannot action a leave in status '{leave_request.status}'.")

    if approve:
        leave_request.status = "APPROVED"
        leave_request.approved_by = approved_by
        leave_request.approved_on = timezone.now()
        leave_request.save(update_fields=["status", "approved_by", "approved_on"])

        # Mark attendance as Leave for each day in range
        emp = leave_request.employee
        current = leave_request.from_date
        while current <= leave_request.to_date:
            Attendance.objects.update_or_create(
                employee=emp,
                date=current,
                defaults={"status": "L", "marked_by": approved_by},
            )
            current += timedelta(days=1)

        _log(approved_by, "APPROVE", "LeaveRequest", leave_request.pk,
             {"approved": True, "employee": emp.employee_code})
        _notify(
            emp.user if emp.user else None,
            f"Leave Approved: {leave_request.leave_type.name}",
            f"Your leave from {leave_request.from_date} to {leave_request.to_date} has been approved.",
            "LeaveRequest", leave_request.pk,
        )
    else:
        leave_request.status = "REJECTED"
        leave_request.rejection_reason = rejection_reason
        leave_request.save(update_fields=["status", "rejection_reason"])

        _log(approved_by, "REJECT", "LeaveRequest", leave_request.pk,
             {"approved": False, "reason": rejection_reason})
        emp = leave_request.employee
        _notify(
            emp.user if emp.user else None,
            f"Leave Rejected: {leave_request.leave_type.name}",
            f"Your leave from {leave_request.from_date} to {leave_request.to_date} was rejected. {rejection_reason}",
            "LeaveRequest", leave_request.pk,
        )

    return leave_request


# ─── PAYROLL COMPUTATION ──────────────────────────────────────────

def _compute_component_amount(
    component,
    structure_line,
    basic: Decimal,
    gross_so_far: Decimal,
    ctc: Decimal,
    days_worked: Decimal,
    total_days: int,
) -> Decimal:
    """Compute a single salary component amount."""
    calc_type = component.calc_type

    # Use override values from structure line if present
    amount = structure_line.override_amount if structure_line.override_amount is not None else component.default_amount
    pct = structure_line.override_percentage if structure_line.override_percentage is not None else component.default_percentage

    if calc_type == "FIXED":
        result = _two(amount)
    elif calc_type == "PCT_BASIC":
        result = _two(basic * pct / 100)
    elif calc_type == "PCT_GROSS":
        result = _two(gross_so_far * pct / 100)
    elif calc_type == "FORMULA":
        try:
            ctx = {
                "basic": float(basic), "gross": float(gross_so_far),
                "ctc": float(ctc), "days_worked": float(days_worked),
                "total_days": float(total_days),
            }
            result = _two(eval(component.formula, {"__builtins__": {}}, ctx))  # nosec
        except Exception:
            result = Decimal("0.00")
    elif calc_type == "STATUTORY":
        # Will be overridden by calculate_pf_esi later
        result = Decimal("0.00")
    else:
        result = Decimal("0.00")

    # Prorate for days worked
    if total_days > 0 and calc_type not in ("STATUTORY",):
        result = _two(result * days_worked / total_days)

    return result


@transaction.atomic
def generate_payroll(plant, month: int, year: int, user=None) -> "Payroll":
    """
    Generate (or regenerate) the monthly payroll for all ACTIVE employees in a plant.

    Steps:
    1. Create or reset Payroll header.
    2. For each active employee with a SalaryStructure:
       a. Sum attendance for month → days_present
       b. Compute each earning component
       c. Compute PF/ESI statutory deductions
       d. Build PayrollLine + PayrollLinePart records
    3. Update Payroll totals.
    """
    from apps.hr.models import (
        Payroll, PayrollLine, PayrollLinePart, Employee,
        Attendance, SalaryComponent,
    )

    # Validate
    if not (1 <= month <= 12):
        raise ValueError("Month must be between 1 and 12.")

    period_start = date(year, month, 1)
    _, last_day = calendar.monthrange(year, month)
    period_end = date(year, month, last_day)
    total_days = last_day

    # Get or create payroll header
    payroll, created = Payroll.objects.get_or_create(
        plant=plant, month=month, year=year,
        defaults={
            "payroll_number": get_next_doc_number(plant, "PAY", "PAY"),
            "period_start": period_start,
            "period_end": period_end,
            "status": "DRAFT",
        },
    )

    if not created and payroll.status == "CLOSED":
        raise ValueError(f"Payroll {payroll.payroll_number} is already CLOSED.")

    if not created:
        # Regenerate: delete existing lines
        PayrollLine.objects.filter(payroll=payroll).delete()
        payroll.status = "DRAFT"
        payroll.save(update_fields=["status"])

    employees = Employee.objects.filter(
        plant=plant,
        status="ACTIVE",
        salary_structure__isnull=False,
    ).select_related("salary_structure", "designation", "department")

    total_gross = Decimal("0.00")
    total_deductions = Decimal("0.00")
    total_net = Decimal("0.00")
    total_employer_pf = Decimal("0.00")
    total_employer_esi = Decimal("0.00")

    for emp in employees:
        structure = emp.salary_structure

        # Attendance summary
        att_qs = Attendance.objects.filter(
            employee=emp,
            date__range=(period_start, period_end),
        )
        days_present = _two(
            att_qs.filter(status__in=("P", "H", "L", "CO")).count()
            + att_qs.filter(status="H").count() * Decimal("-0.5")
        )
        days_present = max(days_present, Decimal("0"))
        days_absent = _two(att_qs.filter(status="A").count())
        days_leave = _two(att_qs.filter(status="L").count())
        overtime_hours = _two(att_qs.aggregate(
            ot=__import__("django.db.models", fromlist=["Sum"]).Sum("overtime_hours")
        )["ot"] or 0)

        # If no attendance records, assume full month worked
        if not att_qs.exists():
            days_present = Decimal(str(total_days))
            days_absent = Decimal("0")
            days_leave = Decimal("0")

        ctc = emp.ctc or Decimal("0")
        monthly_ctc = _two(ctc / 12)

        # Compute earnings in component sequence order
        earnings = Decimal("0.00")
        deductions = Decimal("0.00")
        gross = Decimal("0.00")
        basic = Decimal("0.00")
        line_parts_data = []

        structure_lines = structure.lines.filter(
            is_active=True
        ).select_related("component").order_by("component__sequence")

        for sl in structure_lines:
            comp = sl.component
            if not comp.is_active:
                continue

            computed = _compute_component_amount(
                comp, sl, basic, gross, monthly_ctc,
                days_present, total_days,
            )

            # Track basic for subsequent PCT_BASIC calcs
            if comp.code.upper() in ("BASIC", "BASIC_SALARY"):
                basic = computed

            if comp.component_type == "EARNING":
                earnings += computed
                gross += computed
            elif comp.component_type in ("DEDUCTION", "STATUTORY"):
                deductions += computed

            line_parts_data.append((comp, computed))

        # Statutory PF/ESI (override STATUTORY components)
        pf_esi = calculate_pf_esi(basic, gross)

        # Apply statutory deductions to parts list
        refreshed_parts = []
        for comp, computed in line_parts_data:
            if comp.calc_type == "STATUTORY":
                if comp.code.upper() in ("PF", "EPF", "EMPLOYEE_PF"):
                    computed = pf_esi["employee_pf"]
                elif comp.code.upper() in ("ESI", "ESIC", "EMPLOYEE_ESI"):
                    computed = pf_esi["employee_esi"]
            refreshed_parts.append((comp, computed))

        # Re-sum deductions with corrected statutory values
        deductions = sum(
            amt for comp, amt in refreshed_parts
            if comp.component_type in ("DEDUCTION", "STATUTORY")
        )

        net = _two(gross - deductions)

        # Create PayrollLine
        pl = PayrollLine.objects.create(
            payroll=payroll,
            employee=emp,
            working_days=Decimal(str(total_days)),
            days_present=days_present,
            days_absent=days_absent,
            days_leave=days_leave,
            overtime_hours=overtime_hours,
            gross_salary=_two(gross),
            total_deductions=_two(deductions),
            net_salary=net,
            employer_pf=pf_esi["employer_pf"],
            employer_esi=pf_esi["employer_esi"],
            status="COMPUTED",
        )

        # Create parts
        PayrollLinePart.objects.bulk_create([
            PayrollLinePart(
                payroll_line=pl,
                component=comp,
                computed_amount=_two(amt),
            )
            for comp, amt in refreshed_parts
        ])

        total_gross += _two(gross)
        total_deductions += _two(deductions)
        total_net += net
        total_employer_pf += pf_esi["employer_pf"]
        total_employer_esi += pf_esi["employer_esi"]

    payroll.total_gross = _two(total_gross)
    payroll.total_deductions = _two(total_deductions)
    payroll.total_net = _two(total_net)
    payroll.total_employer_pf = _two(total_employer_pf)
    payroll.total_employer_esi = _two(total_employer_esi)
    payroll.employee_count = employees.count()
    payroll.status = "REVIEW"
    payroll.save(update_fields=[
        "total_gross", "total_deductions", "total_net",
        "total_employer_pf", "total_employer_esi", "employee_count", "status",
    ])

    _log(user, "CREATE", "Payroll", payroll.pk,
         {"payroll_number": payroll.payroll_number, "month": month, "year": year,
          "employee_count": payroll.employee_count, "total_net": str(payroll.total_net)})

    if user:
        _notify(user, f"Payroll Generated: {payroll.payroll_number}",
                f"Payroll for {month:02d}/{year} generated. "
                f"{payroll.employee_count} employees, Net: ₹{payroll.total_net:,.2f}",
                "Payroll", payroll.pk)

    return payroll


@transaction.atomic
def close_payroll(payroll, closed_by=None) -> "Payroll":
    """
    Close a payroll run:
    1. Validate status is APPROVED.
    2. Create salary journal voucher → accounts.Voucher (JOURNAL type).
    3. Create PF+ESI statutory voucher → accounts.Voucher.
    4. Mark payroll CLOSED.
    """
    from apps.accounts.models import (
        Voucher, VoucherLine, LedgerAccount, AccountGroup,
    )

    if payroll.status != "APPROVED":
        raise ValueError(f"Payroll must be in APPROVED status to close. Current: {payroll.status}")

    if payroll.salary_voucher_id:
        raise ValueError("Payroll already has a salary voucher — already closed.")

    plant = payroll.plant
    today = date.today()

    # ── 1. Salary Journal Voucher ──────────────────────────────────
    # DR: Salary Expense Ledger  | CR: Salary Payable Ledger (each line = net per employee)
    sal_voucher = Voucher.objects.create(
        plant=plant,
        voucher_number=get_next_doc_number(plant, "JNL", "JNL"),
        voucher_type=Voucher.VoucherType.JOURNAL,
        voucher_date=date(payroll.year, payroll.month, 1),
        narration=(
            f"Salary journal for payroll {payroll.payroll_number} "
            f"({payroll.month:02d}/{payroll.year})"
        ),
        total_amount=payroll.total_gross,
        status=Voucher.VoucherStatus.POSTED,
        created_by=closed_by,
    )

    # Try to find system ledgers; gracefully skip if not configured
    try:
        salary_expense_ledger = LedgerAccount.objects.get(
            plant=plant, sub_type="SALARY_EXPENSE", is_system=True
        )
        salary_payable_ledger = LedgerAccount.objects.get(
            plant=plant, sub_type="SALARY_PAYABLE", is_system=True
        )
        # DR Salary Expense (total gross)
        VoucherLine.objects.create(
            voucher=sal_voucher,
            ledger=salary_expense_ledger,
            debit_amount=payroll.total_gross,
            credit_amount=Decimal("0.00"),
            narration="Salary expense",
        )
        # CR Salary Payable (total net)
        VoucherLine.objects.create(
            voucher=sal_voucher,
            ledger=salary_payable_ledger,
            debit_amount=Decimal("0.00"),
            credit_amount=payroll.total_net,
            narration="Salary payable",
        )
    except LedgerAccount.DoesNotExist:
        pass  # Ledgers not yet seeded — voucher created without lines

    payroll.salary_voucher = sal_voucher

    # ── 2. PF / ESI Statutory Voucher ─────────────────────────────
    pf_esi_total = _two(
        payroll.total_employer_pf + payroll.total_employer_esi
    )
    pf_voucher = Voucher.objects.create(
        plant=plant,
        voucher_number=get_next_doc_number(plant, "JNL", "JNL"),
        voucher_type=Voucher.VoucherType.JOURNAL,
        voucher_date=date(payroll.year, payroll.month, 1),
        narration=(
            f"PF/ESI employer contribution for {payroll.payroll_number}"
        ),
        total_amount=pf_esi_total,
        status=Voucher.VoucherStatus.POSTED,
        created_by=closed_by,
    )

    try:
        pf_expense_ledger = LedgerAccount.objects.get(
            plant=plant, sub_type="PF_EXPENSE", is_system=True
        )
        pf_payable_ledger = LedgerAccount.objects.get(
            plant=plant, sub_type="PF_PAYABLE", is_system=True
        )
        VoucherLine.objects.create(
            voucher=pf_voucher,
            ledger=pf_expense_ledger,
            debit_amount=pf_esi_total,
            credit_amount=Decimal("0.00"),
            narration="Employer PF+ESI contribution",
        )
        VoucherLine.objects.create(
            voucher=pf_voucher,
            ledger=pf_payable_ledger,
            debit_amount=Decimal("0.00"),
            credit_amount=pf_esi_total,
            narration="PF/ESI payable",
        )
    except LedgerAccount.DoesNotExist:
        pass

    payroll.pf_voucher = pf_voucher
    payroll.status = "CLOSED"
    payroll.closed_at = timezone.now()
    payroll.save(update_fields=[
        "salary_voucher", "pf_voucher", "status", "closed_at"
    ])

    _log(closed_by, "UPDATE", "Payroll", payroll.pk,
         {"status": "CLOSED", "salary_voucher": sal_voucher.voucher_number,
          "pf_voucher": pf_voucher.voucher_number})

    if closed_by:
        _notify(closed_by, f"Payroll Closed: {payroll.payroll_number}",
                f"Payroll {payroll.payroll_number} closed. "
                f"Vouchers: {sal_voucher.voucher_number}, {pf_voucher.voucher_number}",
                "Payroll", payroll.pk)

    return payroll


# ─── BANK EXPORT ──────────────────────────────────────────────────

def export_payroll_to_bank(payroll, format: str = "NEFT") -> bytes:
    """
    Generate NEFT/RTGS bank upload file.

    Format: fixed-width text (HDFC/SBI compatible)
    Columns: Serial | Account No | IFSC | Amount | Beneficiary Name | Employee Code | Remarks

    Returns bytes.
    """
    from apps.hr.models import PayrollLine

    lines = PayrollLine.objects.filter(
        payroll=payroll,
        status="COMPUTED",
    ).select_related("employee").order_by("employee__employee_code")

    if not lines.exists():
        raise ValueError("No computed payroll lines found for bank export.")

    buf = io.StringIO()

    # Header
    buf.write(
        f"# TRIDENT ERP — {format} Bank Export\n"
        f"# Payroll: {payroll.payroll_number}  Period: {payroll.month:02d}/{payroll.year}\n"
        f"# Generated: {timezone.now().strftime('%Y-%m-%d %H:%M')}\n"
        f"# Plant: {payroll.plant.code} — {payroll.plant.name}\n"
        f"# Total Records: {lines.count()}  Total Amount: {payroll.total_net:,.2f}\n"
        f"#{'─' * 100}\n"
    )

    # Column header
    buf.write(
        f"{'SL':>5}  "
        f"{'ACCOUNT_NO':<20}  "
        f"{'IFSC':<12}  "
        f"{'AMOUNT':>14}  "
        f"{'BENEFICIARY_NAME':<40}  "
        f"{'EMP_CODE':<15}  "
        f"{'MODE':<6}  "
        f"REMARKS\n"
    )
    buf.write(f"{'─' * 130}\n")

    for idx, pl in enumerate(lines, start=1):
        emp = pl.employee
        amount = pl.net_salary

        # Determine NEFT vs RTGS (RTGS for amounts >= 2 lakhs)
        mode = "RTGS" if (format == "RTGS" or amount >= Decimal("200000")) else "NEFT"

        buf.write(
            f"{idx:>5}  "
            f"{emp.bank_account_number or 'N/A':<20}  "
            f"{emp.bank_ifsc or 'N/A':<12}  "
            f"{amount:>14,.2f}  "
            f"{emp.full_name[:40]:<40}  "
            f"{emp.employee_code:<15}  "
            f"{mode:<6}  "
            f"SAL/{payroll.month:02d}/{payroll.year}\n"
        )

    buf.write(f"{'─' * 130}\n")
    buf.write(
        f"{'TOTAL':>5}  "
        f"{'':20}  {'':12}  "
        f"{payroll.total_net:>14,.2f}  "
        f"{'':40}  {'':15}\n"
    )

    # Mark lines as PAID
    lines.update(
        status="PAID",
        bank_transfer_ref=f"{format}/{payroll.payroll_number}/{date.today().isoformat()}",
    )

    return buf.getvalue().encode("utf-8")
