"""
Migration: Add unique_together constraint on LoadingInstruction (dispatch_order, item).
Fixes BUG-014: prevents duplicate loading instructions for the same item on the same dispatch order.
"""
from django.db import migrations


class Migration(migrations.Migration):

    dependencies = [
        ('dispatch', '0001_initial'),
    ]

    operations = [
        migrations.AlterUniqueTogether(
            name='loadinginstruction',
            unique_together={('dispatch_order', 'item')},
        ),
    ]
