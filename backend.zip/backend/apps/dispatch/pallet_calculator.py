"""
Pallet Stuffing / Container Load Calculator (F2)

Calculates how many boxes fit on a pallet and how many pallets
fit in a shipping container given box and container dimensions.
"""
from decimal import Decimal


CONTAINER_SPECS = {
    "20FT": {"length_mm": 5898, "width_mm": 2352, "height_mm": 2393},
    "40FT": {"length_mm": 12032, "width_mm": 2352, "height_mm": 2393},
    "40HC": {"length_mm": 12032, "width_mm": 2352, "height_mm": 2693},
}

PALLET_LENGTH_MM = 1200
PALLET_WIDTH_MM = 1000
MAX_PALLET_HEIGHT_MM = 1200
MAX_PALLET_WEIGHT_KG = 1000


def calculate_stuffing(
    box_length_mm, box_width_mm, box_height_mm,
    total_qty, container_type="20FT",
    box_weight_kg=None
):
    """
    Calculate pallet/container stuffing for given box dimensions.

    Returns a dict with:
      - boxes_per_layer
      - layers_per_pallet
      - boxes_per_pallet
      - pallets_in_container
      - boxes_per_container
      - containers_needed
      - weight_per_pallet_kg (if box_weight_kg provided)
      - weight_warning (bool)
    """
    if container_type not in CONTAINER_SPECS:
        raise ValueError(f"Unknown container type: {container_type}. Choose from {list(CONTAINER_SPECS)}")

    if any(v is None for v in [box_length_mm, box_width_mm, box_height_mm, total_qty]):
        raise ValueError(
            "box_length_mm, box_width_mm, box_height_mm and total_qty must all be "
            "non-None. Ensure Item has box dimensions populated before calling this function."
        )

    l, w, h = int(box_length_mm), int(box_width_mm), int(box_height_mm)
    if l <= 0 or w <= 0 or h <= 0:
        raise ValueError("Box dimensions must be positive integers (mm)")

    container = CONTAINER_SPECS[container_type]
    c_l = container["length_mm"]
    c_w = container["width_mm"]

    # Boxes per layer on pallet (try both orientations, pick best)
    orientation_1 = (PALLET_LENGTH_MM // l) * (PALLET_WIDTH_MM // w)
    orientation_2 = (PALLET_LENGTH_MM // w) * (PALLET_WIDTH_MM // l)
    boxes_per_layer = max(orientation_1, orientation_2)

    if boxes_per_layer == 0:
        return {
            "error": "Box footprint exceeds pallet dimensions",
            "boxes_per_layer": 0,
            "layers_per_pallet": 0,
            "boxes_per_pallet": 0,
            "pallets_in_container": 0,
            "boxes_per_container": 0,
            "containers_needed": 0,
        }

    layers_per_pallet = MAX_PALLET_HEIGHT_MM // h
    if layers_per_pallet == 0:
        layers_per_pallet = 1  # At least 1 layer even for tall boxes

    boxes_per_pallet = boxes_per_layer * layers_per_pallet

    # Pallets per container row (length) and column (width)
    pallets_per_row = c_l // PALLET_LENGTH_MM
    pallets_per_col = c_w // PALLET_WIDTH_MM
    # Also try rotated pallet 90°
    pallets_per_row_r = c_l // PALLET_WIDTH_MM
    pallets_per_col_r = c_w // PALLET_LENGTH_MM
    pallets_in_container = max(
        pallets_per_row * pallets_per_col,
        pallets_per_row_r * pallets_per_col_r
    )

    boxes_per_container = pallets_in_container * boxes_per_pallet
    containers_needed = 0
    if boxes_per_container > 0 and total_qty > 0:
        import math
        containers_needed = math.ceil(int(total_qty) / boxes_per_container)

    result = {
        "container_type": container_type,
        "boxes_per_layer": boxes_per_layer,
        "layers_per_pallet": layers_per_pallet,
        "boxes_per_pallet": boxes_per_pallet,
        "pallets_in_container": pallets_in_container,
        "boxes_per_container": boxes_per_container,
        "containers_needed": containers_needed,
        "total_qty": int(total_qty),
    }

    # Weight check
    weight_warning = False
    if box_weight_kg is not None:
        weight_per_pallet = float(box_weight_kg) * boxes_per_pallet
        result["weight_per_pallet_kg"] = round(weight_per_pallet, 2)
        if weight_per_pallet > MAX_PALLET_WEIGHT_KG:
            weight_warning = True
            # Recalculate max boxes based on weight limit
            max_boxes_by_weight = int(MAX_PALLET_WEIGHT_KG / float(box_weight_kg))
            result["boxes_per_pallet_weight_limited"] = max_boxes_by_weight
            result["weight_warning_message"] = (
                f"Pallet weight {weight_per_pallet:.1f} kg exceeds {MAX_PALLET_WEIGHT_KG} kg limit. "
                f"Reduce to {max_boxes_by_weight} boxes/pallet."
            )
    result["weight_warning"] = weight_warning

    return result
