"""Dispatch & Logistics Module Django Admin."""
from django.contrib import admin
from apps.dispatch.models import (
    VehicleType, Vehicle, LogisticsVendor, DeliveryRoute,
    DispatchPlan, DispatchPlanLine, DispatchOrder,
    LoadingInstruction, PodUpload, TransporterPayment,
)


@admin.register(VehicleType)
class VehicleTypeAdmin(admin.ModelAdmin):
    list_display = ["code", "name", "plant", "capacity_kg", "capacity_cft", "is_active"]
    list_filter = ["plant", "is_active"]


@admin.register(LogisticsVendor)
class LogisticsVendorAdmin(admin.ModelAdmin):
    list_display = ["code", "name", "plant", "phone", "has_rate_contract", "is_active"]
    list_filter = ["plant", "has_rate_contract", "is_active"]
    search_fields = ["code", "name", "gst_number"]


@admin.register(Vehicle)
class VehicleAdmin(admin.ModelAdmin):
    list_display = [
        "vehicle_number", "vehicle_type", "ownership",
        "logistics_vendor", "status",
        "driver_name", "fitness_valid_until", "insurance_valid_until",
    ]
    list_filter = ["plant", "vehicle_type", "ownership", "status"]
    search_fields = ["vehicle_number", "driver_name", "driver_phone"]
    raw_id_fields = ["logistics_vendor"]


@admin.register(DeliveryRoute)
class DeliveryRouteAdmin(admin.ModelAdmin):
    list_display = [
        "route_code", "name", "origin", "destination",
        "distance_km", "standard_transit_days", "preferred_vendor", "is_active",
    ]
    list_filter = ["plant", "is_active"]
    raw_id_fields = ["preferred_vendor"]


class DispatchPlanLineInline(admin.TabularInline):
    model = DispatchPlanLine
    extra = 0
    fields = ["line_number", "sales_order", "customer", "item_description", "quantity", "weight_kg", "no_of_packages"]
    raw_id_fields = ["sales_order", "customer"]


@admin.register(DispatchPlan)
class DispatchPlanAdmin(admin.ModelAdmin):
    list_display = [
        "plan_number", "plan_date", "status",
        "vehicle", "logistics_vendor",
        "total_packages", "total_weight_kg", "freight_amount",
        "scheduled_dispatch_date", "expected_delivery_date",
    ]
    list_filter = ["plant", "status"]
    search_fields = ["plan_number", "lr_number"]
    raw_id_fields = ["vehicle", "logistics_vendor", "route", "confirmed_by"]
    readonly_fields = ["plan_number", "confirmed_at"]
    inlines = [DispatchPlanLineInline]


class LoadingInstructionInline(admin.TabularInline):
    model = LoadingInstruction
    extra = 0
    fields = ["line_number", "item", "instructed_qty", "loaded_qty", "status", "stock_issue"]
    readonly_fields = ["stock_issue"]


class PodUploadInline(admin.TabularInline):
    model = PodUpload
    extra = 0
    fields = ["pod_date", "received_by", "customer_ge_number", "status", "uploaded_by"]
    readonly_fields = ["uploaded_by"]


@admin.register(DispatchOrder)
class DispatchOrderAdmin(admin.ModelAdmin):
    list_display = [
        "dispatch_number", "status", "plan",
        "sales_order", "customer",
        "no_of_packages", "gross_weight_kg",
        "expected_delivery", "actual_delivery", "pod_received",
    ]
    list_filter = ["plant", "status", "pod_received"]
    search_fields = ["dispatch_number", "lr_number"]
    raw_id_fields = ["plan", "plan_line", "sales_order", "customer", "vehicle", "logistics_vendor", "despatch"]
    readonly_fields = ["dispatch_number", "actual_dispatch"]
    inlines = [LoadingInstructionInline, PodUploadInline]


@admin.register(PodUpload)
class PodUploadAdmin(admin.ModelAdmin):
    list_display = [
        "dispatch_order", "pod_date", "status",
        "received_by", "customer_ge_number",
        "accepted_by", "accepted_at",
    ]
    list_filter = ["status"]
    search_fields = ["dispatch_order__dispatch_number", "customer_ge_number"]
    raw_id_fields = ["dispatch_order", "accepted_by", "invoice_reach_record"]
    readonly_fields = ["accepted_at"]


@admin.register(TransporterPayment)
class TransporterPaymentAdmin(admin.ModelAdmin):
    list_display = [
        "payment_number", "payment_date", "status",
        "logistics_vendor", "freight_amount", "gst_amount", "tds_amount", "net_payable",
        "payment_mode", "voucher",
    ]
    list_filter = ["plant", "status", "payment_mode"]
    search_fields = ["payment_number", "reference_number"]
    raw_id_fields = ["logistics_vendor", "dispatch_plan", "voucher", "approved_by"]
    readonly_fields = ["payment_number", "gst_amount", "tds_amount", "net_payable", "approved_at"]
    filter_horizontal = ["dispatch_orders"]
