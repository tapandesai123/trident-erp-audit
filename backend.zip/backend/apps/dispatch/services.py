"""
Dispatch & Logistics Module Services — Section 16

Services:
  create_dispatch_plan()          — Batch multiple SOs into a plan with auto-number
  create_dispatch_order()         — Execution record per SO; link sales.Despatch
  record_loading()                — Verify & record loaded qty; create stores.StockIssue
  upload_pod()                    — Attach POD; mark delivery; link InvoiceReachRecord
  create_transporter_payment()    — Post accounts.Voucher (Transport Exp DR / Vendor CR)
  get_dispatch_summary_report()   — On-time %, POD-pending list, cost-per-kg summary
"""
from __future__ import annotations

from datetime import date, timedelta
from decimal import Decimal, ROUND_HALF_UP
from typing import List, Dict, Any, Optional

from django.db import transaction
from django.utils import timezone

from apps.core.models import AuditLog, DocSequence, Notification


# ─── Helpers ──────────────────────────────────────────────────────

def _two(val) -> Decimal:
    return Decimal(str(val)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def _log(user, action: str, resource: str, resource_id, details: dict = None):
    AuditLog.objects.create(
        user=user,
        action=action,
        module="dispatch",
        resource=resource,
        resource_id=str(resource_id),
        new_values=details or {},
    )


def _notify(user, title: str, message: str, resource: str, resource_id):
    if user:
        Notification.objects.create(
            user=user,
            title=title,
            message=message,
            notification_type="IN_APP",
            module="dispatch",
            resource=resource,
            resource_id=resource_id,
        )


def get_next_doc_number(plant, doc_type: str, prefix: str) -> str:
    """Thread-safe sequential document numbering. Format: PREFIX/YYYY-YY/00001"""
    today = date.today()
    fy_start = today.year if today.month >= 4 else today.year - 1
    fy_label = f"{fy_start}-{str(fy_start + 1)[2:]}"

    with transaction.atomic():
        seq, _ = DocSequence.objects.select_for_update().get_or_create(
            plant=plant,
            doc_type=doc_type,
            defaults={"last_number": 0, "financial_year": fy_label},
        )
        if seq.financial_year != fy_label:
            seq.financial_year = fy_label
            seq.last_number = 0

        seq.last_number += 1
        seq.save(update_fields=["last_number", "financial_year"])
        return f"{prefix}/{fy_label}/{seq.last_number:05d}"


# ═══════════════════════════════════════════════════════════════════
# CREATE DISPATCH PLAN
# ═══════════════════════════════════════════════════════════════════

@transaction.atomic
def create_dispatch_plan(
    *,
    plant,
    plan_date: date,
    vehicle=None,
    logistics_vendor=None,
    route=None,
    driver_name: str = "",
    driver_phone: str = "",
    scheduled_dispatch_date: date | None = None,
    expected_delivery_date: date | None = None,
    freight_amount: Decimal = Decimal("0"),
    lines: List[Dict[str, Any]],
    notes: str = "",
    created_by=None,
):
    """
    Create a DispatchPlan batching multiple SOs.

    lines: [
      {sales_order_id, customer_id, delivery_address, item_description,
       quantity, uom, weight_kg, no_of_packages, notes}
    ]
    """
    from apps.dispatch.models import DispatchPlan, DispatchPlanLine

    plan_number = get_next_doc_number(plant, "DISP_PLAN", "DPL")

    # Compute totals from lines
    total_packages = sum(int(l.get("no_of_packages", 0)) for l in lines)
    total_weight = _two(sum(Decimal(str(l.get("weight_kg", 0))) for l in lines))

    # Derive expected_delivery from route if not provided
    if not expected_delivery_date and route and scheduled_dispatch_date:
        expected_delivery_date = scheduled_dispatch_date + timedelta(
            days=route.standard_transit_days
        )

    plan = DispatchPlan.objects.create(
        plant=plant,
        plan_number=plan_number,
        plan_date=plan_date,
        status=DispatchPlan.PlanStatus.DRAFT,
        vehicle=vehicle,
        logistics_vendor=logistics_vendor,
        route=route,
        driver_name=driver_name,
        driver_phone=driver_phone,
        scheduled_dispatch_date=scheduled_dispatch_date,
        expected_delivery_date=expected_delivery_date,
        total_packages=total_packages,
        total_weight_kg=total_weight,
        freight_amount=_two(freight_amount),
        notes=notes,
        created_by=created_by,
    )

    for idx, line_data in enumerate(lines, start=1):
        from apps.sales.models import SalesOrder
        from apps.masters.models import Customer
        try:
            so = SalesOrder.objects.get(pk=line_data["sales_order_id"])
            customer = Customer.objects.get(pk=line_data["customer_id"])
        except (SalesOrder.DoesNotExist, Customer.DoesNotExist) as e:
            raise ValueError(f"Line {idx}: {e}")

        DispatchPlanLine.objects.create(
            plan=plan,
            line_number=idx,
            sales_order=so,
            customer=customer,
            delivery_address=line_data.get("delivery_address", ""),
            item_description=line_data.get("item_description", ""),
            quantity=Decimal(str(line_data.get("quantity", 0))),
            uom=line_data.get("uom", ""),
            weight_kg=_two(line_data.get("weight_kg", 0)),
            no_of_packages=int(line_data.get("no_of_packages", 0)),
            notes=line_data.get("notes", ""),
        )

    _log(created_by, "CREATE", "DispatchPlan", plan.id, {
        "plan_number": plan_number,
        "lines": len(lines),
        "total_weight_kg": str(total_weight),
    })

    return plan


# ═══════════════════════════════════════════════════════════════════
# CREATE DISPATCH ORDER
# ═══════════════════════════════════════════════════════════════════

@transaction.atomic
def create_dispatch_order(
    *,
    plan,
    plan_line,
    sales_order,
    customer,
    delivery_address: str = "",
    scheduled_dispatch: date | None = None,
    expected_delivery: date | None = None,
    no_of_packages: int = 0,
    gross_weight_kg: Decimal = Decimal("0"),
    freight_amount: Decimal = Decimal("0"),
    notes: str = "",
    created_by=None,
):
    """
    Create a DispatchOrder execution record for one SO.
    Vehicle/vendor inherited from plan; can be overridden later.
    Does NOT yet link sales.Despatch — that happens at gate-out (record_loading).
    """
    from apps.dispatch.models import DispatchOrder

    # BUG-005: Verify SalesOrder is in a dispatchable status
    if sales_order.status not in ('CONFIRMED', 'IN_PROGRESS'):
        raise ValueError(
            f"Cannot create DispatchOrder: SalesOrder {sales_order.so_number} "
            f"is in status '{sales_order.status}'. Must be CONFIRMED or IN_PROGRESS."
        )

    # BUG-006: Prevent duplicate dispatches for the same SalesOrder
    if DispatchOrder.objects.filter(
        sales_order=sales_order,
        status__in=['PENDING', 'LOADING', 'GATE_OUT', 'IN_TRANSIT', 'POD_PENDING'],
    ).exists():
        raise ValueError(
            f"An active DispatchOrder already exists for SalesOrder {sales_order.so_number}."
        )

    dispatch_number = get_next_doc_number(plan.plant, "DISP_ORDER", "DSO")

    order = DispatchOrder.objects.create(
        plant=plan.plant,
        dispatch_number=dispatch_number,
        plan=plan,
        plan_line=plan_line,
        status=DispatchOrder.OrderStatus.PENDING,
        sales_order=sales_order,
        customer=customer,
        delivery_address=delivery_address,
        vehicle=plan.vehicle,
        logistics_vendor=plan.logistics_vendor,
        driver_name=plan.driver_name,
        driver_phone=plan.driver_phone,
        lr_number=plan.lr_number,
        lr_date=plan.lr_date,
        scheduled_dispatch=scheduled_dispatch or plan.scheduled_dispatch_date,
        expected_delivery=expected_delivery or plan.expected_delivery_date,
        no_of_packages=no_of_packages,
        gross_weight_kg=_two(gross_weight_kg),
        freight_amount=_two(freight_amount),
        notes=notes,
        created_by=created_by,
    )

    _log(created_by, "CREATE", "DispatchOrder", order.id, {
        "dispatch_number": dispatch_number,
        "plan_number": plan.plan_number,
        "sales_order": str(sales_order),
    })

    return order


# ═══════════════════════════════════════════════════════════════════
# RECORD LOADING
# ═══════════════════════════════════════════════════════════════════

@transaction.atomic
def record_loading(
    *,
    dispatch_order,
    loading_lines: List[Dict[str, Any]],
    warehouse,
    issued_to_dept=None,
    despatch=None,
    loaded_by=None,
):
    """
    Record the loading of goods onto the vehicle.

    For each loading line:
      1. Update LoadingInstruction loaded_qty + status
      2. Create a stores.StockIssue (type=OTHER, "DISPATCH") and link it

    Also links the sales.Despatch to the DispatchOrder and updates status to LOADING.

    loading_lines: [
      {loading_instruction_id, loaded_qty, remarks}
    ]
    """
    from apps.dispatch.models import LoadingInstruction, DispatchOrder

    try:
        from apps.stores.models import StockIssue
        from apps.core.models import DocSequence
        stores_available = True
    except ImportError:
        stores_available = False

    if despatch:
        dispatch_order.despatch = despatch
        dispatch_order.save(update_fields=["despatch"])

    dispatch_order.status = DispatchOrder.OrderStatus.LOADING
    dispatch_order.save(update_fields=["status"])

    stock_issue = None
    if stores_available:
        # Create a single StockIssue for all lines in this loading
        issue_number = get_next_doc_number(
            dispatch_order.plant, "DISPATCH_ISSUE", "DIS"
        )
        try:
            stock_issue = StockIssue.objects.create(
                plant=dispatch_order.plant,
                issue_number=issue_number,
                issue_date=date.today(),
                issue_type=StockIssue.IssueType.OTHER,
                status=StockIssue.IssueStatus.ISSUED,
                from_warehouse=warehouse,
                issued_to_dept=issued_to_dept,
                issued_by=loaded_by,
                remarks=f"Dispatch loading: {dispatch_order.dispatch_number}",
            )
        except Exception:
            stock_issue = None

    processed = []
    for line_data in loading_lines:
        try:
            instr = LoadingInstruction.objects.get(
                pk=line_data["loading_instruction_id"],
                dispatch_order=dispatch_order,
            )
        except LoadingInstruction.DoesNotExist:
            continue

        loaded_qty = Decimal(str(line_data.get("loaded_qty", 0)))
        instr.loaded_qty = loaded_qty
        instr.shortfall_qty = max(Decimal("0"), instr.instructed_qty - loaded_qty)
        instr.status = (
            LoadingInstruction.LoadingStatus.LOADED
            if loaded_qty >= instr.instructed_qty
            else LoadingInstruction.LoadingStatus.SHORTFALL
        )
        instr.loaded_by = loaded_by
        instr.loaded_at = timezone.now()
        instr.remarks = line_data.get("remarks", "")
        if stock_issue:
            instr.stock_issue = stock_issue
        instr.save()
        processed.append(instr)

    _log(loaded_by, "LOADING", "DispatchOrder", dispatch_order.id, {
        "dispatch_number": dispatch_order.dispatch_number,
        "lines_loaded": len(processed),
        "stock_issue": stock_issue.issue_number if stock_issue else None,
    })

    return dispatch_order, stock_issue


# ═══════════════════════════════════════════════════════════════════
# UPLOAD POD
# ═══════════════════════════════════════════════════════════════════

@transaction.atomic
def upload_pod(
    *,
    dispatch_order,
    pod_date: date,
    received_by: str = "",
    customer_ge_number: str = "",
    pod_document=None,
    remarks: str = "",
    uploaded_by=None,
):
    """
    Upload Proof-of-Delivery for a dispatch order.

    1. Create PodUpload record
    2. Mark DispatchOrder as POD_PENDING (acceptance pending)
    3. Link to sales.InvoiceReachRecord on the related invoice (if exists)
    4. Update dispatch_order.actual_delivery
    5. Notify dispatch manager
    """
    from apps.dispatch.models import PodUpload, DispatchOrder

    pod = PodUpload.objects.create(
        dispatch_order=dispatch_order,
        pod_date=pod_date,
        received_by=received_by,
        customer_ge_number=customer_ge_number,
        pod_document=pod_document,
        status=PodUpload.PodStatus.UPLOADED,
        remarks=remarks,
        uploaded_by=uploaded_by,
    )

    # Update dispatch order
    dispatch_order.status = DispatchOrder.OrderStatus.POD_PENDING
    dispatch_order.actual_delivery = timezone.make_aware(
        timezone.datetime.combine(pod_date, timezone.datetime.min.time())
    )
    dispatch_order.pod_received = True
    dispatch_order.save(update_fields=["status", "actual_delivery", "pod_received"])

    # BUG-007: Update SalesOrder status to DELIVERED when POD is uploaded
    try:
        so = dispatch_order.sales_order
        if so.status not in ('DELIVERED', 'CLOSED'):
            so.status = 'DELIVERED'
            so.save(update_fields=['status', 'updated_at'])
    except Exception:
        pass  # Never fail POD upload due to SO update error

    # Try linking to sales.InvoiceReachRecord
    try:
        from apps.sales.models import InvoiceReachRecord, Invoice
        # Find invoice for this sales order
        invoice = Invoice.objects.filter(
            sales_order=dispatch_order.sales_order
        ).order_by("-invoice_date").first()

        if invoice:
            reach_record, created = InvoiceReachRecord.objects.get_or_create(
                invoice=invoice,
                defaults={
                    "customer_ge_number": customer_ge_number,
                    "customer_ge_date": pod_date,
                    "received_by_customer": received_by,
                    "recorded_by": uploaded_by,
                }
            )
            if not created:
                # Update existing
                reach_record.customer_ge_number = customer_ge_number or reach_record.customer_ge_number
                reach_record.customer_ge_date = reach_record.customer_ge_date or pod_date
                reach_record.received_by_customer = received_by or reach_record.received_by_customer
                reach_record.save(update_fields=[
                    "customer_ge_number", "customer_ge_date", "received_by_customer"
                ])
            pod.invoice_reach_record = reach_record
            pod.save(update_fields=["invoice_reach_record"])
    except Exception:
        pass

    _log(uploaded_by, "POD_UPLOAD", "DispatchOrder", dispatch_order.id, {
        "dispatch_number": dispatch_order.dispatch_number,
        "pod_date": str(pod_date),
        "customer_ge_number": customer_ge_number,
    })

    # Notify dispatch team
    if dispatch_order.created_by:
        _notify(
            dispatch_order.created_by,
            f"POD Received: {dispatch_order.dispatch_number}",
            f"POD uploaded for {dispatch_order.dispatch_number}. "
            f"Customer GE: {customer_ge_number or 'not provided'}.",
            "PodUpload", pod.id,
        )

    return pod


# ═══════════════════════════════════════════════════════════════════
# CREATE TRANSPORTER PAYMENT
# ═══════════════════════════════════════════════════════════════════

@transaction.atomic
def create_transporter_payment(
    *,
    plant,
    logistics_vendor,
    payment_date: date,
    freight_amount: Decimal,
    gst_rate: Decimal = Decimal("0"),
    tds_rate: Decimal = Decimal("0"),
    dispatch_plan=None,
    dispatch_order_ids: list | None = None,
    payment_mode: str = "",
    reference_number: str = "",
    notes: str = "",
    created_by=None,
):
    """
    Create a TransporterPayment and post an accounts.Voucher:
      DR  Transport Expense A/c   freight_amount + gst_amount
      CR  Vendor Payable A/c      net_payable
      CR  TDS Payable A/c         tds_amount  (if tds > 0)
    """
    from apps.dispatch.models import TransporterPayment, DispatchOrder

    payment_number = get_next_doc_number(plant, "TRANS_PMT", "TPY")

    gst_amount = _two(freight_amount * gst_rate / 100)
    tds_amount = _two(freight_amount * tds_rate / 100)
    net_payable = _two(freight_amount + gst_amount - tds_amount)

    payment = TransporterPayment.objects.create(
        plant=plant,
        payment_number=payment_number,
        payment_date=payment_date,
        status=TransporterPayment.PaymentStatus.DRAFT,
        logistics_vendor=logistics_vendor,
        dispatch_plan=dispatch_plan,
        freight_amount=_two(freight_amount),
        gst_amount=gst_amount,
        tds_amount=tds_amount,
        net_payable=net_payable,
        payment_mode=payment_mode,
        reference_number=reference_number,
        notes=notes,
        created_by=created_by,
    )

    if dispatch_order_ids:
        orders = DispatchOrder.objects.filter(pk__in=dispatch_order_ids, plant=plant)
        payment.dispatch_orders.set(orders)

    # Post accounts.Voucher (graceful: skip if ledger accounts not seeded)
    try:
        from apps.accounts.models import Voucher, VoucherLine, LedgerAccount

        voucher_number = get_next_doc_number(plant, "TRANSPORT_VOUCHER", "JV")
        voucher = Voucher.objects.create(
            plant=plant,
            voucher_number=voucher_number,
            voucher_date=payment_date,
            voucher_type=Voucher.VoucherType.JOURNAL,
            narration=f"Transport freight: {payment_number} — {logistics_vendor.name}",
            status=Voucher.VoucherStatus.DRAFT,
            created_by=created_by,
        )

        gross_dr = _two(freight_amount + gst_amount)

        # DR Transport Expense
        try:
            transport_ledger = LedgerAccount.objects.get(
                plant=plant, account_code__icontains="TRANSPORT"
            )
            VoucherLine.objects.create(
                voucher=voucher,
                ledger_account=transport_ledger,
                debit_amount=gross_dr,
                credit_amount=Decimal("0"),
                narration="Freight charges",
            )
        except LedgerAccount.DoesNotExist:
            pass

        # CR Vendor Payable
        try:
            vendor_ledger = LedgerAccount.objects.get(
                plant=plant,
                account_name__icontains=logistics_vendor.name[:20],
            )
            VoucherLine.objects.create(
                voucher=voucher,
                ledger_account=vendor_ledger,
                debit_amount=Decimal("0"),
                credit_amount=net_payable,
                narration=f"Payable to {logistics_vendor.name}",
            )
        except LedgerAccount.DoesNotExist:
            pass

        # CR TDS Payable (if applicable)
        if tds_amount > 0:
            try:
                tds_ledger = LedgerAccount.objects.get(plant=plant, account_code__icontains="TDS")
                VoucherLine.objects.create(
                    voucher=voucher,
                    ledger_account=tds_ledger,
                    debit_amount=Decimal("0"),
                    credit_amount=tds_amount,
                    narration="TDS on transport",
                )
            except LedgerAccount.DoesNotExist:
                pass

        payment.voucher = voucher
        payment.save(update_fields=["voucher"])

    except Exception:
        pass  # Graceful degradation when accounts module not seeded

    _log(created_by, "CREATE", "TransporterPayment", payment.id, {
        "payment_number": payment_number,
        "vendor": logistics_vendor.name,
        "net_payable": str(net_payable),
    })

    return payment


# ═══════════════════════════════════════════════════════════════════
# GET DISPATCH SUMMARY REPORT
# ═══════════════════════════════════════════════════════════════════

# ═══════════════════════════════════════════════════════════════════
# CANCEL DISPATCH ORDER
# ═══════════════════════════════════════════════════════════════════

@transaction.atomic
def cancel_dispatch_order(*, dispatch_order, reason: str = '', cancelled_by=None):
    """
    Cancel a DispatchOrder and atomically restore any stock that was issued during loading.

    - Cannot cancel already CANCELLED orders.
    - Cannot cancel DELIVERED or CLOSED orders.
    - Reverses StockIssue for each LOADED LoadingInstruction.
    """
    from apps.dispatch.models import DispatchOrder as _DO, LoadingInstruction

    if dispatch_order.status == _DO.OrderStatus.CANCELLED:
        raise ValueError('Already cancelled.')
    if dispatch_order.status in (_DO.OrderStatus.DELIVERED, _DO.OrderStatus.CLOSED):
        raise ValueError('Cannot cancel a delivered/closed dispatch.')

    # Reverse stock issues for each loaded instruction
    for instr in dispatch_order.loading_instructions.filter(status='LOADED'):
        if instr.stock_issue_id:
            try:
                from apps.stores.models import StockIssue
                issue = StockIssue.objects.get(pk=instr.stock_issue_id)
                # Void the stock issue so inventory is restored
                issue.status = 'VOID'
                issue.save(update_fields=['status'])
            except Exception:
                pass
        instr.status = LoadingInstruction.LoadingStatus.SKIPPED
        instr.save(update_fields=['status'])

    dispatch_order.status = _DO.OrderStatus.CANCELLED
    if reason:
        dispatch_order.notes = (dispatch_order.notes or '') + f' | Cancelled: {reason}'
    dispatch_order.save(update_fields=['status', 'notes'])

    _log(cancelled_by, 'CANCEL', 'DispatchOrder', dispatch_order.id, {'reason': reason})
    return dispatch_order


def get_dispatch_summary_report(plant, filters: dict | None = None) -> dict:
    """
    Return a dispatch performance summary.

    filters: {date_from, date_to, logistics_vendor_id, status}

    Returns:
    {
      total_orders, delivered_count, on_time_count, on_time_pct,
      pod_pending_count, in_transit_count,
      total_weight_kg, total_freight_amount, cost_per_kg,
      by_vendor: [{vendor, orders, weight_kg, freight_amount, on_time_pct}],
      pod_pending_orders: [{dispatch_number, customer, expected_delivery}]
    }
    """
    from apps.dispatch.models import DispatchOrder
    from django.db.models import Count, Sum, Q

    qs = DispatchOrder.objects.filter(plant=plant).select_related(
        "logistics_vendor", "customer", "vehicle"
    )

    if filters:
        if filters.get("date_from"):
            qs = qs.filter(actual_dispatch__date__gte=filters["date_from"])
        if filters.get("date_to"):
            qs = qs.filter(actual_dispatch__date__lte=filters["date_to"])
        if filters.get("logistics_vendor_id"):
            qs = qs.filter(logistics_vendor_id=filters["logistics_vendor_id"])
        if filters.get("status"):
            qs = qs.filter(status=filters["status"])

    totals = qs.aggregate(
        total_orders=Count("id"),
        total_weight=Sum("gross_weight_kg"),
        total_freight=Sum("freight_amount"),
    )

    delivered_qs = qs.filter(status__in=["DELIVERED", "POD_PENDING", "CLOSED"])
    delivered_count = delivered_qs.count()

    # On-time: actual_delivery.date <= expected_delivery
    on_time_count = 0
    for o in delivered_qs.filter(
        actual_delivery__isnull=False, expected_delivery__isnull=False
    ):
        if o.is_on_time:
            on_time_count += 1

    on_time_pct = round(on_time_count / delivered_count * 100, 2) if delivered_count else 0

    pod_pending = qs.filter(status="POD_PENDING")
    in_transit = qs.filter(status="IN_TRANSIT")

    total_weight = totals["total_weight"] or Decimal("0")
    total_freight = totals["total_freight"] or Decimal("0")
    cost_per_kg = _two(total_freight / total_weight) if total_weight > 0 else Decimal("0")

    # By vendor
    from django.db.models import FloatField
    by_vendor_raw = list(
        qs.values("logistics_vendor__name", "logistics_vendor__id")
        .annotate(
            order_count=Count("id"),
            weight_kg=Sum("gross_weight_kg"),
            freight=Sum("freight_amount"),
        )
        .order_by("-freight")
    )

    by_vendor = []
    for v in by_vendor_raw:
        v_qs = qs.filter(logistics_vendor_id=v["logistics_vendor__id"])
        v_delivered = v_qs.filter(status__in=["DELIVERED", "POD_PENDING", "CLOSED"])
        v_delivered_count = v_delivered.count()
        v_on_time = sum(
            1 for o in v_delivered.filter(
                actual_delivery__isnull=False, expected_delivery__isnull=False
            )
            if o.is_on_time
        )
        v_on_time_pct = round(v_on_time / v_delivered_count * 100, 2) if v_delivered_count else 0
        by_vendor.append({
            "vendor": v["logistics_vendor__name"] or "Unassigned",
            "orders": v["order_count"],
            "weight_kg": str(_two(v["weight_kg"] or 0)),
            "freight_amount": str(_two(v["freight"] or 0)),
            "on_time_pct": v_on_time_pct,
        })

    pod_pending_list = [
        {
            "dispatch_number": o.dispatch_number,
            "customer": str(o.customer),
            "expected_delivery": str(o.expected_delivery) if o.expected_delivery else None,
            "actual_dispatch": str(o.actual_dispatch.date()) if o.actual_dispatch else None,
        }
        for o in pod_pending.order_by("expected_delivery")[:50]
    ]

    return {
        "total_orders": totals["total_orders"] or 0,
        "delivered_count": delivered_count,
        "on_time_count": on_time_count,
        "on_time_pct": on_time_pct,
        "pod_pending_count": pod_pending.count(),
        "in_transit_count": in_transit.count(),
        "total_weight_kg": str(_two(total_weight)),
        "total_freight_amount": str(_two(total_freight)),
        "cost_per_kg": str(cost_per_kg),
        "by_vendor": by_vendor,
        "pod_pending_orders": pod_pending_list,
    }
