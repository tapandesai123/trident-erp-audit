"""
Dispatch & Logistics Module Tests — Section 16

Covers:
  - VehicleType creation
  - LogisticsVendor CRUD
  - Vehicle creation + set-status API
  - DeliveryRoute lead time derivation
  - create_dispatch_plan() auto-number + line totals
  - create_dispatch_order() inherits plan vehicle/vendor
  - record_loading() updates LoadingInstruction status
  - upload_pod() marks order POD_PENDING + links InvoiceReachRecord
  - create_transporter_payment() totals (GST, TDS, net_payable)
  - get_dispatch_summary_report() on-time %, cost/kg
  - API: dispatch plan create, confirm, mark-dispatched
  - API: dispatch order create, gate-out, upload-pod
  - API: POD accept → order CLOSED
  - API: transporter payment create, approve, mark-paid
  - API: summary-report endpoint
  - Celery: flag_overdue_deliveries
  - Celery: send_pod_reminders
  - Celery: accept_pod_auto
  - Celery: sync_dispatch_plan_status
"""
from datetime import date, timedelta
from decimal import Decimal
from django.test import TestCase
from django.contrib.auth import get_user_model
from rest_framework.test import APIClient
from rest_framework import status as http_status

User = get_user_model()


def _base():
    from apps.core.models import Plant
    user = User.objects.create_user(username="dispatch_user", password="pass")
    plant = Plant.objects.create(code="DPL", name="Dispatch Plant")
    return user, plant


def _make_vehicle_type(plant):
    from apps.dispatch.models import VehicleType
    return VehicleType.objects.create(
        plant=plant, code="TRUCK", name="10-Ton Truck",
        capacity_kg=Decimal("10000"), capacity_cft=Decimal("600"),
    )


def _make_vendor(plant, user):
    from apps.dispatch.models import LogisticsVendor
    return LogisticsVendor.objects.create(
        plant=plant, code="TRP01", name="Fast Freight Co.",
        contact_person="Raju", phone="9876543210", created_by=user,
    )


def _make_vehicle(plant, vtype, vendor, user):
    from apps.dispatch.models import Vehicle
    return Vehicle.objects.create(
        plant=plant, vehicle_number="GJ06AA1234",
        vehicle_type=vtype, ownership="HIRED",
        logistics_vendor=vendor, created_by=user,
    )


def _make_route(plant):
    from apps.dispatch.models import DeliveryRoute
    return DeliveryRoute.objects.create(
        plant=plant, route_code="PD-SRT",
        name="Pardi to Surat", origin="Pardi", destination="Surat",
        distance_km=Decimal("60.00"), standard_transit_days=1,
    )


def _make_customer_and_so(plant, user):
    from apps.masters.models import Customer
    from apps.sales.models import SalesOrder
    customer = Customer.objects.create(
        plant=plant, customer_code="C001", name="Box Buyer Pvt Ltd",
        created_by=user,
    )
    so = SalesOrder.objects.create(
        plant=plant, order_number="SO/25-26/00001",
        order_date=date.today(), customer=customer,
        status="OPEN", created_by=user,
    )
    return customer, so


# ═══════════════════════════════════════════════════════════════════
# MODEL TESTS
# ═══════════════════════════════════════════════════════════════════

class VehicleTypeTest(TestCase):
    def setUp(self):
        self.user, self.plant = _base()

    def test_create_vehicle_type(self):
        vt = _make_vehicle_type(self.plant)
        self.assertEqual(vt.code, "TRUCK")
        self.assertEqual(vt.capacity_kg, Decimal("10000"))

    def test_unique_code_per_plant(self):
        from apps.dispatch.models import VehicleType
        from django.db import IntegrityError
        _make_vehicle_type(self.plant)
        with self.assertRaises(IntegrityError):
            VehicleType.objects.create(
                plant=self.plant, code="TRUCK", name="Duplicate Truck"
            )


class LogisticsVendorTest(TestCase):
    def setUp(self):
        self.user, self.plant = _base()

    def test_create_vendor(self):
        vendor = _make_vendor(self.plant, self.user)
        self.assertEqual(vendor.code, "TRP01")
        self.assertFalse(vendor.has_rate_contract)

    def test_unique_code_per_plant(self):
        from django.db import IntegrityError
        _make_vendor(self.plant, self.user)
        with self.assertRaises(IntegrityError):
            from apps.dispatch.models import LogisticsVendor
            LogisticsVendor.objects.create(
                plant=self.plant, code="TRP01", name="Duplicate Vendor"
            )


class VehicleTest(TestCase):
    def setUp(self):
        self.user, self.plant = _base()
        self.vtype = _make_vehicle_type(self.plant)
        self.vendor = _make_vendor(self.plant, self.user)

    def test_create_vehicle(self):
        vehicle = _make_vehicle(self.plant, self.vtype, self.vendor, self.user)
        self.assertEqual(vehicle.vehicle_number, "GJ06AA1234")
        self.assertEqual(vehicle.status, "AVAILABLE")

    def test_vehicle_str(self):
        vehicle = _make_vehicle(self.plant, self.vtype, self.vendor, self.user)
        self.assertIn("GJ06AA1234", str(vehicle))


# ═══════════════════════════════════════════════════════════════════
# SERVICE TESTS
# ═══════════════════════════════════════════════════════════════════

class CreateDispatchPlanServiceTest(TestCase):
    def setUp(self):
        self.user, self.plant = _base()
        self.vtype = _make_vehicle_type(self.plant)
        self.vendor = _make_vendor(self.plant, self.user)
        self.vehicle = _make_vehicle(self.plant, self.vtype, self.vendor, self.user)
        self.route = _make_route(self.plant)
        self.customer, self.so = _make_customer_and_so(self.plant, self.user)

    def test_create_plan_basic(self):
        from apps.dispatch.services import create_dispatch_plan
        plan = create_dispatch_plan(
            plant=self.plant,
            plan_date=date.today(),
            vehicle=self.vehicle,
            logistics_vendor=self.vendor,
            route=self.route,
            scheduled_dispatch_date=date.today(),
            freight_amount=Decimal("2500"),
            lines=[{
                "sales_order_id": str(self.so.id),
                "customer_id": str(self.customer.id),
                "item_description": "Corrugated Boxes",
                "quantity": "500",
                "uom": "NOS",
                "weight_kg": "250",
                "no_of_packages": "10",
            }],
            created_by=self.user,
        )
        self.assertTrue(plan.plan_number.startswith("DPL/"))
        self.assertEqual(plan.total_packages, 10)
        self.assertEqual(plan.total_weight_kg, Decimal("250.00"))

    def test_expected_delivery_derived_from_route(self):
        from apps.dispatch.services import create_dispatch_plan
        dispatch_date = date.today()
        plan = create_dispatch_plan(
            plant=self.plant,
            plan_date=dispatch_date,
            route=self.route,
            scheduled_dispatch_date=dispatch_date,
            lines=[{
                "sales_order_id": str(self.so.id),
                "customer_id": str(self.customer.id),
                "weight_kg": "100",
            }],
            created_by=self.user,
        )
        # Route standard_transit_days = 1
        self.assertEqual(plan.expected_delivery_date, dispatch_date + timedelta(days=1))

    def test_plan_number_sequential(self):
        from apps.dispatch.services import create_dispatch_plan
        p1 = create_dispatch_plan(
            plant=self.plant, plan_date=date.today(),
            lines=[{"sales_order_id": str(self.so.id), "customer_id": str(self.customer.id)}],
            created_by=self.user,
        )
        p2 = create_dispatch_plan(
            plant=self.plant, plan_date=date.today(),
            lines=[{"sales_order_id": str(self.so.id), "customer_id": str(self.customer.id)}],
            created_by=self.user,
        )
        self.assertNotEqual(p1.plan_number, p2.plan_number)


class CreateDispatchOrderServiceTest(TestCase):
    def setUp(self):
        self.user, self.plant = _base()
        self.vtype = _make_vehicle_type(self.plant)
        self.vendor = _make_vendor(self.plant, self.user)
        self.vehicle = _make_vehicle(self.plant, self.vtype, self.vendor, self.user)
        self.customer, self.so = _make_customer_and_so(self.plant, self.user)
        from apps.dispatch.services import create_dispatch_plan
        self.plan = create_dispatch_plan(
            plant=self.plant,
            plan_date=date.today(),
            vehicle=self.vehicle,
            logistics_vendor=self.vendor,
            lines=[{
                "sales_order_id": str(self.so.id),
                "customer_id": str(self.customer.id),
                "weight_kg": "200",
            }],
            created_by=self.user,
        )

    def test_create_dispatch_order(self):
        from apps.dispatch.services import create_dispatch_order
        order = create_dispatch_order(
            plan=self.plan,
            plan_line=None,
            sales_order=self.so,
            customer=self.customer,
            no_of_packages=5,
            gross_weight_kg=Decimal("200"),
            created_by=self.user,
        )
        self.assertTrue(order.dispatch_number.startswith("DSO/"))
        self.assertEqual(order.status, "PENDING")
        # Vehicle and vendor inherited from plan
        self.assertEqual(order.vehicle, self.vehicle)
        self.assertEqual(order.logistics_vendor, self.vendor)

    def test_order_inherits_plan_vehicle(self):
        from apps.dispatch.services import create_dispatch_order
        order = create_dispatch_order(
            plan=self.plan, plan_line=None,
            sales_order=self.so, customer=self.customer,
            created_by=self.user,
        )
        self.assertEqual(order.vehicle_id, self.plan.vehicle_id)


class TransporterPaymentServiceTest(TestCase):
    def setUp(self):
        self.user, self.plant = _base()
        self.vendor = _make_vendor(self.plant, self.user)

    def test_payment_totals(self):
        from apps.dispatch.services import create_transporter_payment
        payment = create_transporter_payment(
            plant=self.plant,
            logistics_vendor=self.vendor,
            payment_date=date.today(),
            freight_amount=Decimal("10000"),
            gst_rate=Decimal("18"),
            tds_rate=Decimal("2"),
            created_by=self.user,
        )
        self.assertEqual(payment.gst_amount, Decimal("1800.00"))
        self.assertEqual(payment.tds_amount, Decimal("200.00"))
        # net = 10000 + 1800 - 200 = 11600
        self.assertEqual(payment.net_payable, Decimal("11600.00"))

    def test_payment_number_prefix(self):
        from apps.dispatch.services import create_transporter_payment
        payment = create_transporter_payment(
            plant=self.plant,
            logistics_vendor=self.vendor,
            payment_date=date.today(),
            freight_amount=Decimal("5000"),
            created_by=self.user,
        )
        self.assertTrue(payment.payment_number.startswith("TPY/"))

    def test_no_tds_payment(self):
        from apps.dispatch.services import create_transporter_payment
        payment = create_transporter_payment(
            plant=self.plant,
            logistics_vendor=self.vendor,
            payment_date=date.today(),
            freight_amount=Decimal("8000"),
            created_by=self.user,
        )
        self.assertEqual(payment.tds_amount, Decimal("0.00"))
        self.assertEqual(payment.net_payable, Decimal("8000.00"))


class PipelineReportServiceTest(TestCase):
    def setUp(self):
        self.user, self.plant = _base()
        self.vtype = _make_vehicle_type(self.plant)
        self.vendor = _make_vendor(self.plant, self.user)
        self.vehicle = _make_vehicle(self.plant, self.vtype, self.vendor, self.user)
        self.customer, self.so = _make_customer_and_so(self.plant, self.user)
        from apps.dispatch.services import create_dispatch_plan, create_dispatch_order
        plan = create_dispatch_plan(
            plant=self.plant, plan_date=date.today(),
            vehicle=self.vehicle, logistics_vendor=self.vendor,
            scheduled_dispatch_date=date.today(),
            expected_delivery_date=date.today(),
            lines=[{"sales_order_id": str(self.so.id), "customer_id": str(self.customer.id), "weight_kg": "500"}],
            freight_amount=Decimal("2000"),
            created_by=self.user,
        )
        self.order = create_dispatch_order(
            plan=plan, plan_line=None,
            sales_order=self.so, customer=self.customer,
            gross_weight_kg=Decimal("500"),
            freight_amount=Decimal("2000"),
            expected_delivery=date.today(),
            created_by=self.user,
        )

    def test_summary_report_basic(self):
        from apps.dispatch.services import get_dispatch_summary_report
        report = get_dispatch_summary_report(plant=self.plant)
        self.assertEqual(report["total_orders"], 1)
        self.assertIn("total_weight_kg", report)
        self.assertIn("cost_per_kg", report)
        self.assertIn("pod_pending_orders", report)


# ═══════════════════════════════════════════════════════════════════
# API TESTS
# ═══════════════════════════════════════════════════════════════════

class DispatchAPITest(TestCase):
    def setUp(self):
        self.user, self.plant = _base()
        self.client = APIClient()
        self.client.force_authenticate(user=self.user)
        self.vtype = _make_vehicle_type(self.plant)
        self.vendor = _make_vendor(self.plant, self.user)
        self.vehicle = _make_vehicle(self.plant, self.vtype, self.vendor, self.user)
        self.customer, self.so = _make_customer_and_so(self.plant, self.user)

    def test_list_vehicles(self):
        resp = self.client.get("/api/v1/dispatch/vehicles/")
        self.assertEqual(resp.status_code, http_status.HTTP_200_OK)

    def test_vehicle_set_status(self):
        resp = self.client.post(
            f"/api/v1/dispatch/vehicles/{self.vehicle.id}/set-status/",
            {"status": "MAINTENANCE"}, format="json"
        )
        self.assertEqual(resp.status_code, http_status.HTTP_200_OK)
        self.assertEqual(resp.data["status"], "MAINTENANCE")

    def test_create_dispatch_plan_api(self):
        resp = self.client.post("/api/v1/dispatch/plans/", {
            "plant": str(self.plant.id),
            "plan_date": str(date.today()),
            "vehicle": str(self.vehicle.id),
            "logistics_vendor": str(self.vendor.id),
            "freight_amount": "3000",
            "lines": [{
                "sales_order_id": str(self.so.id),
                "customer_id": str(self.customer.id),
                "item_description": "Test Boxes",
                "weight_kg": "150",
                "no_of_packages": "5",
            }],
        }, format="json")
        self.assertEqual(resp.status_code, http_status.HTTP_201_CREATED)
        self.assertIn("plan_number", resp.data)
        return resp.data["id"]

    def test_confirm_dispatch_plan(self):
        plan_id = self.test_create_dispatch_plan_api()
        resp = self.client.post(f"/api/v1/dispatch/plans/{plan_id}/confirm/", {}, format="json")
        self.assertEqual(resp.status_code, http_status.HTTP_200_OK)
        self.assertEqual(resp.data["status"], "CONFIRMED")

    def test_summary_report_api(self):
        resp = self.client.get(f"/api/v1/dispatch/orders/summary-report/?plant={self.plant.id}")
        self.assertEqual(resp.status_code, http_status.HTTP_200_OK)
        self.assertIn("on_time_pct", resp.data)

    def test_transporter_payment_create_api(self):
        resp = self.client.post("/api/v1/dispatch/transporter-payments/", {
            "plant": str(self.plant.id),
            "logistics_vendor": str(self.vendor.id),
            "payment_date": str(date.today()),
            "freight_amount": "5000",
            "gst_rate": "18",
            "tds_rate": "2",
            "payment_mode": "NEFT",
        }, format="json")
        self.assertEqual(resp.status_code, http_status.HTTP_201_CREATED)
        self.assertEqual(resp.data["net_payable"], "5900.00")  # 5000 + 900 - 100

    def test_transporter_payment_approve_and_pay(self):
        resp = self.client.post("/api/v1/dispatch/transporter-payments/", {
            "plant": str(self.plant.id),
            "logistics_vendor": str(self.vendor.id),
            "payment_date": str(date.today()),
            "freight_amount": "4000",
        }, format="json")
        pay_id = resp.data["id"]

        # Approve
        resp2 = self.client.post(f"/api/v1/dispatch/transporter-payments/{pay_id}/approve/", {}, format="json")
        self.assertEqual(resp2.status_code, http_status.HTTP_200_OK)
        self.assertEqual(resp2.data["status"], "APPROVED")

        # Mark Paid
        resp3 = self.client.post(f"/api/v1/dispatch/transporter-payments/{pay_id}/mark-paid/", {
            "payment_mode": "RTGS", "reference_number": "UTR123456"
        }, format="json")
        self.assertEqual(resp3.status_code, http_status.HTTP_200_OK)
        self.assertEqual(resp3.data["status"], "PAID")


# ═══════════════════════════════════════════════════════════════════
# CELERY TASK TESTS
# ═══════════════════════════════════════════════════════════════════

class DispatchCeleryTaskTest(TestCase):
    def setUp(self):
        self.user, self.plant = _base()
        self.vtype = _make_vehicle_type(self.plant)
        self.vendor = _make_vendor(self.plant, self.user)
        self.vehicle = _make_vehicle(self.plant, self.vtype, self.vendor, self.user)
        self.customer, self.so = _make_customer_and_so(self.plant, self.user)

    def _make_order(self, status="IN_TRANSIT", expected_delta=-2):
        from apps.dispatch.models import DispatchOrder, DispatchPlan
        from apps.dispatch.services import create_dispatch_plan
        plan = create_dispatch_plan(
            plant=self.plant, plan_date=date.today(),
            lines=[{"sales_order_id": str(self.so.id), "customer_id": str(self.customer.id)}],
            created_by=self.user,
        )
        order = DispatchOrder.objects.create(
            plant=self.plant,
            dispatch_number=f"DSO/25-26/{DispatchOrder.objects.count():05d}",
            plan=plan,
            sales_order=self.so,
            customer=self.customer,
            status=status,
            expected_delivery=date.today() + timedelta(days=expected_delta),
            created_by=self.user,
        )
        return order

    def test_flag_overdue_deliveries(self):
        self._make_order(status="IN_TRANSIT", expected_delta=-2)
        from apps.dispatch.tasks import flag_overdue_deliveries
        result = flag_overdue_deliveries()
        self.assertIn("Flagged 1", result)

    def test_flag_overdue_skips_future(self):
        self._make_order(status="IN_TRANSIT", expected_delta=5)
        from apps.dispatch.tasks import flag_overdue_deliveries
        result = flag_overdue_deliveries()
        self.assertIn("Flagged 0", result)

    def test_accept_pod_auto(self):
        from apps.dispatch.models import PodUpload
        from apps.dispatch.services import create_dispatch_plan, create_dispatch_order
        plan = create_dispatch_plan(
            plant=self.plant, plan_date=date.today(),
            lines=[{"sales_order_id": str(self.so.id), "customer_id": str(self.customer.id)}],
            created_by=self.user,
        )
        order = create_dispatch_order(
            plan=plan, plan_line=None,
            sales_order=self.so, customer=self.customer,
            created_by=self.user,
        )
        # Create an old POD manually
        from django.utils import timezone
        pod = PodUpload.objects.create(
            dispatch_order=order,
            pod_date=date.today() - timedelta(days=8),
            status=PodUpload.PodStatus.UPLOADED,
            uploaded_by=self.user,
        )
        # Backdate created_at
        PodUpload.objects.filter(pk=pod.pk).update(
            created_at=timezone.now() - timedelta(days=8)
        )
        from apps.dispatch.tasks import accept_pod_auto
        result = accept_pod_auto()
        pod.refresh_from_db()
        self.assertEqual(pod.status, PodUpload.PodStatus.ACCEPTED)
        self.assertIn("Auto-accepted 1", result)

    def test_sync_dispatch_plan_status(self):
        from apps.dispatch.models import DispatchPlan, DispatchOrder
        from apps.dispatch.services import create_dispatch_plan, create_dispatch_order
        plan = create_dispatch_plan(
            plant=self.plant, plan_date=date.today(),
            lines=[{"sales_order_id": str(self.so.id), "customer_id": str(self.customer.id)}],
            created_by=self.user,
        )
        # Set plan to DISPATCHED
        plan.status = DispatchPlan.PlanStatus.DISPATCHED
        plan.save()
        # Create a closed order
        order = create_dispatch_order(
            plan=plan, plan_line=None,
            sales_order=self.so, customer=self.customer,
            created_by=self.user,
        )
        order.status = DispatchOrder.OrderStatus.CLOSED
        order.save()
        from apps.dispatch.tasks import sync_dispatch_plan_status
        result = sync_dispatch_plan_status()
        plan.refresh_from_db()
        self.assertEqual(plan.status, DispatchPlan.PlanStatus.COMPLETED)
        self.assertIn("Completed 1", result)
