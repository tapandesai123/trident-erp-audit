"""
Dispatch & Logistics Module Models — Section 16

Models:
  VehicleType        — Category of vehicle (truck, tempo, container…)
  Vehicle            — Individual vehicle master with capacity, fitness, insurance
  LogisticsVendor    — Transporter / logistics vendor master
  DeliveryRoute      — Named origin-destination route with distance & lead time
  DispatchPlan       — Batched dispatch plan grouping multiple SOs
  DispatchPlanLine   — Individual SO / delivery line on a plan
  DispatchOrder      — Execution record linking plan to sales.Despatch
  LoadingInstruction — Loading checklist line per dispatch order
  PodUpload          — Proof-of-Delivery upload with acceptance status
  TransporterPayment — Payment to logistics vendor; posts accounts.Voucher
"""
import uuid
from decimal import Decimal
from django.conf import settings
from django.db import models
from django.utils import timezone
from apps.core.models import TimeStampedModel, UUIDModel, Plant


# ═══════════════════════════════════════════════════════════════════
# VEHICLE TYPE
# ═══════════════════════════════════════════════════════════════════

class VehicleType(UUIDModel, TimeStampedModel):
    """Category of vehicle (e.g. 20-ft Container, 10-ton Truck, Tempo)."""

    plant = models.ForeignKey(Plant, on_delete=models.CASCADE, related_name="vehicle_types")
    code = models.CharField(max_length=20)
    name = models.CharField(max_length=100)
    capacity_kg = models.DecimalField(
        max_digits=10, decimal_places=2, null=True, blank=True,
        help_text="Payload capacity in kg"
    )
    capacity_cft = models.DecimalField(
        max_digits=10, decimal_places=2, null=True, blank=True,
        help_text="Volume capacity in cubic feet"
    )
    is_active = models.BooleanField(default=True)
    notes = models.TextField(blank=True)

    class Meta:
        ordering = ["plant", "code"]
        unique_together = [("plant", "code")]

    def __str__(self):
        return f"{self.code} — {self.name}"


# ═══════════════════════════════════════════════════════════════════
# LOGISTICS VENDOR
# ═══════════════════════════════════════════════════════════════════

class LogisticsVendor(UUIDModel, TimeStampedModel):
    """Transporter / logistics vendor master (separate from masters.Vendor for dispatch context)."""

    plant = models.ForeignKey(Plant, on_delete=models.CASCADE, related_name="logistics_vendors")
    # Optional link to masters.Vendor if already registered as a supplier
    vendor = models.ForeignKey(
        "masters.Vendor", on_delete=models.SET_NULL,
        null=True, blank=True, related_name="logistics_vendor_profiles",
        help_text="Link to masters.Vendor if exists"
    )
    code = models.CharField(max_length=20)
    name = models.CharField(max_length=200)
    contact_person = models.CharField(max_length=100, blank=True)
    phone = models.CharField(max_length=20, blank=True)
    email = models.EmailField(blank=True)
    gst_number = models.CharField(max_length=20, blank=True)
    pan_number = models.CharField(max_length=20, blank=True)
    address = models.TextField(blank=True)
    city = models.CharField(max_length=100, blank=True)
    state = models.CharField(max_length=100, blank=True)
    pincode = models.CharField(max_length=10, blank=True)

    # Rate contract
    has_rate_contract = models.BooleanField(default=False)
    rate_contract_valid_until = models.DateField(null=True, blank=True)
    base_rate_per_km = models.DecimalField(
        max_digits=10, decimal_places=2, null=True, blank=True
    )
    base_rate_per_kg = models.DecimalField(
        max_digits=10, decimal_places=2, null=True, blank=True
    )

    is_active = models.BooleanField(default=True)
    notes = models.TextField(blank=True)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="logistics_vendors_created"
    )

    class Meta:
        ordering = ["plant", "code"]
        unique_together = [("plant", "code")]

    def __str__(self):
        return f"{self.code} — {self.name}"


# ═══════════════════════════════════════════════════════════════════
# VEHICLE
# ═══════════════════════════════════════════════════════════════════

class Vehicle(UUIDModel, TimeStampedModel):
    """Individual vehicle master."""

    class OwnershipType(models.TextChoices):
        OWN       = "OWN",       "Own Vehicle"
        HIRED     = "HIRED",     "Hired"
        VENDOR    = "VENDOR",    "Vendor Vehicle"

    class VehicleStatus(models.TextChoices):
        AVAILABLE   = "AVAILABLE",   "Available"
        LOADED      = "LOADED",      "Loaded / On Trip"
        MAINTENANCE = "MAINTENANCE", "Under Maintenance"
        BREAKDOWN   = "BREAKDOWN",   "Breakdown"
        RETIRED     = "RETIRED",     "Retired"

    plant = models.ForeignKey(Plant, on_delete=models.CASCADE, related_name="vehicles")
    vehicle_number = models.CharField(max_length=30, unique=True, help_text="Registration number e.g. GJ06AA1234")
    vehicle_type = models.ForeignKey(
        VehicleType, on_delete=models.PROTECT, related_name="vehicles"
    )
    ownership = models.CharField(
        max_length=10, choices=OwnershipType.choices, default=OwnershipType.HIRED
    )
    logistics_vendor = models.ForeignKey(
        LogisticsVendor, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="vehicles",
        help_text="Owning vendor for hired/vendor vehicles"
    )
    status = models.CharField(
        max_length=15, choices=VehicleStatus.choices, default=VehicleStatus.AVAILABLE
    )

    driver_name = models.CharField(max_length=100, blank=True)
    driver_phone = models.CharField(max_length=20, blank=True)
    driver_license_no = models.CharField(max_length=30, blank=True)
    driver_license_valid_until = models.DateField(null=True, blank=True)

    # Compliance dates
    fitness_valid_until = models.DateField(null=True, blank=True)
    insurance_valid_until = models.DateField(null=True, blank=True)
    puc_valid_until = models.DateField(null=True, blank=True, help_text="Pollution Under Control")

    capacity_kg = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    capacity_cft = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)

    notes = models.TextField(blank=True)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="vehicles_created"
    )

    class Meta:
        ordering = ["plant", "vehicle_number"]

    def __str__(self):
        return f"{self.vehicle_number} ({self.vehicle_type.code})"


# ═══════════════════════════════════════════════════════════════════
# DELIVERY ROUTE
# ═══════════════════════════════════════════════════════════════════

class DeliveryRoute(UUIDModel, TimeStampedModel):
    """Named origin → destination route with distance and standard lead time."""

    plant = models.ForeignKey(Plant, on_delete=models.CASCADE, related_name="delivery_routes")
    route_code = models.CharField(max_length=30)
    name = models.CharField(max_length=200)
    origin = models.CharField(max_length=100)
    destination = models.CharField(max_length=100)
    distance_km = models.DecimalField(max_digits=8, decimal_places=2, null=True, blank=True)
    standard_transit_days = models.PositiveIntegerField(
        default=1, help_text="Expected transit days"
    )
    # Preferred vendor on this route
    preferred_vendor = models.ForeignKey(
        LogisticsVendor, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="preferred_routes"
    )
    is_active = models.BooleanField(default=True)
    notes = models.TextField(blank=True)

    class Meta:
        ordering = ["plant", "route_code"]
        unique_together = [("plant", "route_code")]

    def __str__(self):
        return f"{self.route_code}: {self.origin} → {self.destination}"


# ═══════════════════════════════════════════════════════════════════
# DISPATCH PLAN
# ═══════════════════════════════════════════════════════════════════

class DispatchPlan(UUIDModel, TimeStampedModel):
    """
    Batched dispatch plan — groups multiple SOs / deliveries for
    a single vehicle trip / shipment.
    """

    class PlanStatus(models.TextChoices):
        DRAFT     = "DRAFT",     "Draft"
        CONFIRMED = "CONFIRMED", "Confirmed"
        LOADING   = "LOADING",   "Loading in Progress"
        DISPATCHED= "DISPATCHED","Dispatched"
        COMPLETED = "COMPLETED", "Completed"
        CANCELLED = "CANCELLED", "Cancelled"

    plant = models.ForeignKey(Plant, on_delete=models.CASCADE, related_name="dispatch_plans")
    plan_number = models.CharField(max_length=50, unique=True)
    plan_date = models.DateField()
    status = models.CharField(
        max_length=15, choices=PlanStatus.choices, default=PlanStatus.DRAFT
    )

    vehicle = models.ForeignKey(
        Vehicle, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="dispatch_plans"
    )
    logistics_vendor = models.ForeignKey(
        LogisticsVendor, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="dispatch_plans"
    )
    route = models.ForeignKey(
        DeliveryRoute, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="dispatch_plans"
    )

    driver_name = models.CharField(max_length=100, blank=True)
    driver_phone = models.CharField(max_length=20, blank=True)
    lr_number = models.CharField(max_length=100, blank=True, help_text="Lorry Receipt number")
    lr_date = models.DateField(null=True, blank=True)

    scheduled_dispatch_date = models.DateField(null=True, blank=True)
    expected_delivery_date = models.DateField(null=True, blank=True)
    actual_dispatch_date = models.DateField(null=True, blank=True)

    # Totals (maintained by services)
    total_packages = models.PositiveIntegerField(default=0)
    total_weight_kg = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    total_volume_cft = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    freight_amount = models.DecimalField(max_digits=14, decimal_places=2, default=0)

    notes = models.TextField(blank=True)
    confirmed_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="confirmed_dispatch_plans"
    )
    confirmed_at = models.DateTimeField(null=True, blank=True)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="dispatch_plans_created"
    )

    class Meta:
        ordering = ["-plan_date", "-created_at"]

    def __str__(self):
        return f"{self.plan_number} ({self.status})"


# ═══════════════════════════════════════════════════════════════════
# DISPATCH PLAN LINE
# ═══════════════════════════════════════════════════════════════════

class DispatchPlanLine(UUIDModel, TimeStampedModel):
    """Individual SO / delivery line on a DispatchPlan."""

    plan = models.ForeignKey(DispatchPlan, on_delete=models.CASCADE, related_name="lines")
    line_number = models.PositiveIntegerField(default=1)

    sales_order = models.ForeignKey(
        "sales.SalesOrder", on_delete=models.PROTECT, related_name="dispatch_plan_lines"
    )
    customer = models.ForeignKey(
        "masters.Customer", on_delete=models.PROTECT, related_name="dispatch_plan_lines"
    )
    delivery_address = models.TextField(blank=True)

    # Item summary on this line (denormalized for quick reads)
    item_description = models.CharField(max_length=300, blank=True)
    quantity = models.DecimalField(max_digits=15, decimal_places=3, default=0)
    uom = models.CharField(max_length=30, blank=True)
    weight_kg = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    no_of_packages = models.PositiveIntegerField(default=0)

    notes = models.CharField(max_length=300, blank=True)

    class Meta:
        ordering = ["plan", "line_number"]

    def __str__(self):
        return f"{self.plan.plan_number} L{self.line_number} — {self.customer}"


# ═══════════════════════════════════════════════════════════════════
# DISPATCH ORDER
# ═══════════════════════════════════════════════════════════════════

class DispatchOrder(UUIDModel, TimeStampedModel):
    """
    Execution record for a single SO delivery.
    Links DispatchPlan → sales.Despatch (DC).
    """

    class OrderStatus(models.TextChoices):
        PENDING     = "PENDING",    "Pending"
        LOADING     = "LOADING",    "Loading"
        GATE_OUT    = "GATE_OUT",   "Gate Out"
        IN_TRANSIT  = "IN_TRANSIT", "In Transit"
        DELIVERED   = "DELIVERED",  "Delivered"
        POD_PENDING = "POD_PENDING","POD Pending"
        CLOSED      = "CLOSED",     "Closed"
        CANCELLED   = "CANCELLED",  "Cancelled"

    plant = models.ForeignKey(Plant, on_delete=models.CASCADE, related_name="dispatch_orders")
    dispatch_number = models.CharField(max_length=50, unique=True)
    plan = models.ForeignKey(
        DispatchPlan, on_delete=models.PROTECT, related_name="orders"
    )
    plan_line = models.ForeignKey(
        DispatchPlanLine, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="dispatch_orders"
    )
    status = models.CharField(
        max_length=15, choices=OrderStatus.choices, default=OrderStatus.PENDING
    )

    sales_order = models.ForeignKey(
        "sales.SalesOrder", on_delete=models.PROTECT, related_name="dispatch_orders"
    )
    despatch = models.ForeignKey(
        "sales.Despatch", on_delete=models.SET_NULL,
        null=True, blank=True, related_name="dispatch_orders",
        help_text="Linked sales.Despatch (DC) — set on gate-out"
    )

    customer = models.ForeignKey(
        "masters.Customer", on_delete=models.PROTECT, related_name="dispatch_orders"
    )
    delivery_address = models.TextField(blank=True)

    # Transport details (copied from plan, overridable)
    vehicle = models.ForeignKey(
        Vehicle, on_delete=models.SET_NULL, null=True, blank=True, related_name="dispatch_orders"
    )
    logistics_vendor = models.ForeignKey(
        LogisticsVendor, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="dispatch_orders"
    )
    driver_name = models.CharField(max_length=100, blank=True)
    driver_phone = models.CharField(max_length=20, blank=True)
    lr_number = models.CharField(max_length=100, blank=True)
    lr_date = models.DateField(null=True, blank=True)

    # Timeline
    scheduled_dispatch = models.DateField(null=True, blank=True)
    actual_dispatch = models.DateTimeField(null=True, blank=True)
    expected_delivery = models.DateField(null=True, blank=True)
    actual_delivery = models.DateTimeField(null=True, blank=True)

    # Cargo
    no_of_packages = models.PositiveIntegerField(default=0)
    gross_weight_kg = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    freight_amount = models.DecimalField(max_digits=14, decimal_places=2, default=0)

    # POD flag
    pod_received = models.BooleanField(default=False)

    notes = models.TextField(blank=True)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="dispatch_orders_created"
    )

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.dispatch_number} ({self.status})"

    @property
    def is_on_time(self) -> bool:
        """True if delivered on or before expected_delivery."""
        if self.actual_delivery and self.expected_delivery:
            return self.actual_delivery.date() <= self.expected_delivery
        return False


# ═══════════════════════════════════════════════════════════════════
# LOADING INSTRUCTION
# ═══════════════════════════════════════════════════════════════════

class LoadingInstruction(UUIDModel, TimeStampedModel):
    """
    Loading checklist / instruction line per dispatch order.
    Each line represents one product batch to be loaded.
    Linked to stores.StockIssue for stock deduction.
    """

    class LoadingStatus(models.TextChoices):
        PENDING  = "PENDING",  "Pending"
        LOADED   = "LOADED",   "Loaded"
        SHORTFALL= "SHORTFALL","Shortfall"
        SKIPPED  = "SKIPPED",  "Skipped"

    dispatch_order = models.ForeignKey(
        DispatchOrder, on_delete=models.CASCADE, related_name="loading_instructions"
    )
    line_number = models.PositiveIntegerField(default=1)

    item = models.ForeignKey(
        "masters.Item", on_delete=models.PROTECT, related_name="loading_instructions"
    )
    item_description = models.CharField(max_length=300)
    uom = models.CharField(max_length=30, blank=True)

    instructed_qty = models.DecimalField(max_digits=15, decimal_places=3)
    loaded_qty = models.DecimalField(max_digits=15, decimal_places=3, default=0)
    shortfall_qty = models.DecimalField(max_digits=15, decimal_places=3, default=0)

    status = models.CharField(
        max_length=10, choices=LoadingStatus.choices, default=LoadingStatus.PENDING
    )

    # Stock issue link (created by record_loading service)
    stock_issue = models.ForeignKey(
        "stores.StockIssue", on_delete=models.SET_NULL,
        null=True, blank=True, related_name="dispatch_loading_instructions"
    )

    loaded_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="loading_instructions_done"
    )
    loaded_at = models.DateTimeField(null=True, blank=True)
    remarks = models.CharField(max_length=300, blank=True)

    class Meta:
        unique_together = [["dispatch_order", "item"]]

    class Meta:
        ordering = ["dispatch_order", "line_number"]

    def __str__(self):
        return f"{self.dispatch_order.dispatch_number} L{self.line_number} — {self.item_description}"


# ═══════════════════════════════════════════════════════════════════
# POD UPLOAD
# ═══════════════════════════════════════════════════════════════════

class PodUpload(UUIDModel, TimeStampedModel):
    """
    Proof-of-Delivery upload.
    Marks dispatch order DELIVERED and optionally links to sales.InvoiceReachRecord.
    """

    class PodStatus(models.TextChoices):
        UPLOADED  = "UPLOADED",  "Uploaded — Pending Acceptance"
        ACCEPTED  = "ACCEPTED",  "Accepted"
        REJECTED  = "REJECTED",  "Rejected — Short/Damage"
        DISPUTED  = "DISPUTED",  "Disputed"

    dispatch_order = models.ForeignKey(
        DispatchOrder, on_delete=models.CASCADE, related_name="pod_uploads"
    )
    pod_document = models.FileField(
        upload_to="dispatch/pod/", null=True, blank=True,
        help_text="Scanned/photographed POD document"
    )
    pod_date = models.DateField(help_text="Date on the POD / customer's GE date")
    received_by = models.CharField(max_length=100, blank=True, help_text="Customer's signatory name")
    customer_ge_number = models.CharField(
        max_length=100, blank=True, help_text="Customer's inward gate entry number"
    )
    status = models.CharField(
        max_length=10, choices=PodStatus.choices, default=PodStatus.UPLOADED
    )
    remarks = models.TextField(blank=True)

    # Acceptance
    accepted_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="pod_accepted"
    )
    accepted_at = models.DateTimeField(null=True, blank=True)
    rejection_reason = models.CharField(max_length=300, blank=True)

    # Link to sales.InvoiceReachRecord (set by upload_pod service)
    invoice_reach_record = models.ForeignKey(
        "sales.InvoiceReachRecord", on_delete=models.SET_NULL,
        null=True, blank=True, related_name="dispatch_pod_uploads"
    )

    uploaded_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="pod_uploads_created"
    )

    class Meta:
        ordering = ["-pod_date", "-created_at"]

    def __str__(self):
        return f"POD: {self.dispatch_order.dispatch_number} — {self.pod_date} ({self.status})"


# ═══════════════════════════════════════════════════════════════════
# TRANSPORTER PAYMENT
# ═══════════════════════════════════════════════════════════════════

class TransporterPayment(UUIDModel, TimeStampedModel):
    """
    Payment to logistics vendor for freight services.
    Posts a JOURNAL accounts.Voucher (Transport Expense DR / Vendor Payable CR).
    """

    class PaymentStatus(models.TextChoices):
        DRAFT    = "DRAFT",    "Draft"
        APPROVED = "APPROVED", "Approved"
        PAID     = "PAID",     "Paid"
        CANCELLED= "CANCELLED","Cancelled"

    class PaymentMode(models.TextChoices):
        NEFT   = "NEFT",   "NEFT"
        RTGS   = "RTGS",   "RTGS"
        CHEQUE = "CHEQUE", "Cheque"
        CASH   = "CASH",   "Cash"
        UPI    = "UPI",    "UPI"

    plant = models.ForeignKey(Plant, on_delete=models.CASCADE, related_name="transporter_payments")
    payment_number = models.CharField(max_length=50, unique=True)
    payment_date = models.DateField()
    status = models.CharField(
        max_length=10, choices=PaymentStatus.choices, default=PaymentStatus.DRAFT
    )

    logistics_vendor = models.ForeignKey(
        LogisticsVendor, on_delete=models.PROTECT, related_name="payments"
    )
    dispatch_plan = models.ForeignKey(
        DispatchPlan, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="transporter_payments"
    )
    dispatch_orders = models.ManyToManyField(
        DispatchOrder, blank=True, related_name="transporter_payments",
        help_text="Dispatch orders covered by this payment"
    )

    # Freight details
    freight_amount = models.DecimalField(max_digits=14, decimal_places=2)
    gst_amount = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    tds_amount = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    net_payable = models.DecimalField(max_digits=14, decimal_places=2, default=0)

    payment_mode = models.CharField(
        max_length=10, choices=PaymentMode.choices, blank=True
    )
    reference_number = models.CharField(max_length=100, blank=True, help_text="UTR / Cheque No")
    paid_at = models.DateTimeField(null=True, blank=True)

    # Voucher link
    voucher = models.ForeignKey(
        "accounts.Voucher", on_delete=models.SET_NULL,
        null=True, blank=True, related_name="transporter_payments"
    )

    notes = models.TextField(blank=True)
    approved_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="approved_transporter_payments"
    )
    approved_at = models.DateTimeField(null=True, blank=True)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="transporter_payments_created"
    )

    class Meta:
        ordering = ["-payment_date", "-created_at"]

    def __str__(self):
        return f"{self.payment_number} — {self.logistics_vendor.name} — ₹{self.net_payable}"
