"""Dispatch & Logistics API Viewsets."""
from decimal import Decimal
from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated

from apps.dispatch.models import (
    VehicleType, Vehicle, LogisticsVendor, DeliveryRoute,
    DispatchPlan, DispatchPlanLine, DispatchOrder,
    LoadingInstruction, PodUpload, TransporterPayment,
)
from apps.dispatch.api.serializers import (
    VehicleTypeListSerializer, VehicleTypeDetailSerializer, VehicleTypeCreateSerializer,
    VehicleListSerializer, VehicleDetailSerializer, VehicleCreateSerializer,
    LogisticsVendorListSerializer, LogisticsVendorDetailSerializer, LogisticsVendorCreateSerializer,
    DeliveryRouteListSerializer, DeliveryRouteDetailSerializer, DeliveryRouteCreateSerializer,
    DispatchPlanListSerializer, DispatchPlanDetailSerializer, DispatchPlanCreateSerializer,
    DispatchOrderListSerializer, DispatchOrderDetailSerializer, DispatchOrderCreateSerializer,
    LoadingInstructionSerializer, LoadingInstructionCreateSerializer,
    PodUploadListSerializer, PodUploadDetailSerializer, PodUploadCreateSerializer,
    TransporterPaymentListSerializer, TransporterPaymentDetailSerializer,
    TransporterPaymentCreateSerializer,
)
from apps.dispatch import services


# ─── VehicleType ──────────────────────────────────────────────────

class VehicleTypeViewSet(viewsets.ModelViewSet):
    queryset = VehicleType.objects.select_related("plant")
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return VehicleTypeListSerializer
        if self.action in ("create", "update", "partial_update"):
            return VehicleTypeCreateSerializer
        return VehicleTypeDetailSerializer

    def get_queryset(self):
        qs = super().get_queryset()
        plant = self.request.query_params.get("plant")
        if plant:
            qs = qs.filter(plant=plant)
        return qs


# ─── LogisticsVendor ──────────────────────────────────────────────

class LogisticsVendorViewSet(viewsets.ModelViewSet):
    queryset = LogisticsVendor.objects.select_related("plant", "vendor")
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return LogisticsVendorListSerializer
        if self.action in ("create", "update", "partial_update"):
            return LogisticsVendorCreateSerializer
        return LogisticsVendorDetailSerializer

    def get_queryset(self):
        qs = super().get_queryset()
        plant = self.request.query_params.get("plant")
        if plant:
            qs = qs.filter(plant=plant)
        return qs.filter(is_active=True)

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)


# ─── Vehicle ──────────────────────────────────────────────────────

class VehicleViewSet(viewsets.ModelViewSet):
    queryset = Vehicle.objects.select_related("plant", "vehicle_type", "logistics_vendor")
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return VehicleListSerializer
        if self.action in ("create", "update", "partial_update"):
            return VehicleCreateSerializer
        return VehicleDetailSerializer

    def get_queryset(self):
        qs = super().get_queryset()
        plant = self.request.query_params.get("plant")
        veh_status = self.request.query_params.get("status")
        ownership = self.request.query_params.get("ownership")
        if plant:
            qs = qs.filter(plant=plant)
        if veh_status:
            qs = qs.filter(status=veh_status)
        if ownership:
            qs = qs.filter(ownership=ownership)
        return qs

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)

    @action(detail=True, methods=["post"], url_path="set-status")
    def set_status(self, request, pk=None):
        """Update vehicle operational status."""
        vehicle = self.get_object()
        new_status = request.data.get("status")
        allowed = [c[0] for c in Vehicle.VehicleStatus.choices]
        if new_status not in allowed:
            return Response(
                {"detail": f"Invalid status. Choices: {allowed}"},
                status=status.HTTP_400_BAD_REQUEST,
            )
        vehicle.status = new_status
        vehicle.save(update_fields=["status"])
        return Response(VehicleDetailSerializer(vehicle).data)


# ─── DeliveryRoute ────────────────────────────────────────────────

class DeliveryRouteViewSet(viewsets.ModelViewSet):
    queryset = DeliveryRoute.objects.select_related("plant", "preferred_vendor")
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return DeliveryRouteListSerializer
        if self.action in ("create", "update", "partial_update"):
            return DeliveryRouteCreateSerializer
        return DeliveryRouteDetailSerializer

    def get_queryset(self):
        qs = super().get_queryset()
        plant = self.request.query_params.get("plant")
        if plant:
            qs = qs.filter(plant=plant)
        return qs.filter(is_active=True)


# ─── DispatchPlan ─────────────────────────────────────────────────

class DispatchPlanViewSet(viewsets.ModelViewSet):
    queryset = DispatchPlan.objects.select_related(
        "plant", "vehicle", "logistics_vendor", "route", "confirmed_by"
    ).prefetch_related("lines")
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return DispatchPlanListSerializer
        if self.action in ("create", "update", "partial_update"):
            return DispatchPlanCreateSerializer
        return DispatchPlanDetailSerializer

    def get_queryset(self):
        qs = super().get_queryset()
        plant = self.request.query_params.get("plant")
        plan_status = self.request.query_params.get("status")
        if plant:
            qs = qs.filter(plant=plant)
        if plan_status:
            qs = qs.filter(status=plan_status)
        return qs

    def create(self, request, *args, **kwargs):
        from apps.core.models import Plant
        try:
            plant = Plant.objects.get(pk=request.data["plant"])

            vehicle = None
            if request.data.get("vehicle"):
                vehicle = Vehicle.objects.get(pk=request.data["vehicle"])

            vendor = None
            if request.data.get("logistics_vendor"):
                vendor = LogisticsVendor.objects.get(pk=request.data["logistics_vendor"])

            route = None
            if request.data.get("route"):
                route = DeliveryRoute.objects.get(pk=request.data["route"])

            plan = services.create_dispatch_plan(
                plant=plant,
                plan_date=request.data["plan_date"],
                vehicle=vehicle,
                logistics_vendor=vendor,
                route=route,
                driver_name=request.data.get("driver_name", ""),
                driver_phone=request.data.get("driver_phone", ""),
                scheduled_dispatch_date=request.data.get("scheduled_dispatch_date"),
                expected_delivery_date=request.data.get("expected_delivery_date"),
                freight_amount=Decimal(str(request.data.get("freight_amount", 0))),
                lines=request.data.get("lines", []),
                notes=request.data.get("notes", ""),
                created_by=request.user,
            )
            return Response(DispatchPlanDetailSerializer(plan).data, status=status.HTTP_201_CREATED)
        except Exception as e:
            return Response({"detail": str(e)}, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=True, methods=["post"], url_path="confirm")
    def confirm(self, request, pk=None):
        """Confirm a draft dispatch plan."""
        from django.utils import timezone as tz
        plan = self.get_object()
        if plan.status != DispatchPlan.PlanStatus.DRAFT:
            return Response(
                {"detail": f"Cannot confirm plan in status '{plan.status}'."},
                status=status.HTTP_400_BAD_REQUEST,
            )
        plan.status = DispatchPlan.PlanStatus.CONFIRMED
        plan.confirmed_by = request.user
        plan.confirmed_at = tz.now()
        plan.save(update_fields=["status", "confirmed_by", "confirmed_at"])
        return Response(DispatchPlanDetailSerializer(plan).data)

    @action(detail=True, methods=["post"], url_path="mark-dispatched")
    def mark_dispatched(self, request, pk=None):
        """Mark plan as DISPATCHED with actual dispatch date."""
        plan = self.get_object()
        import datetime
        plan.status = DispatchPlan.PlanStatus.DISPATCHED
        plan.actual_dispatch_date = request.data.get("actual_dispatch_date") or datetime.date.today()
        plan.save(update_fields=["status", "actual_dispatch_date"])

        # Update all non-cancelled orders to IN_TRANSIT
        plan.orders.filter(
            status__in=[DispatchOrder.OrderStatus.LOADING, DispatchOrder.OrderStatus.GATE_OUT]
        ).update(status=DispatchOrder.OrderStatus.IN_TRANSIT)

        return Response(DispatchPlanDetailSerializer(plan).data)

    @action(detail=True, methods=["get"], url_path="summary")
    def summary(self, request, pk=None):
        """Return a summary of the plan and its orders."""
        plan = self.get_object()
        orders = plan.orders.all()
        return Response({
            "plan_number": plan.plan_number,
            "status": plan.status,
            "total_orders": orders.count(),
            "delivered": orders.filter(status__in=["DELIVERED", "POD_PENDING", "CLOSED"]).count(),
            "in_transit": orders.filter(status="IN_TRANSIT").count(),
            "pending": orders.filter(status="PENDING").count(),
            "total_packages": plan.total_packages,
            "total_weight_kg": str(plan.total_weight_kg),
            "freight_amount": str(plan.freight_amount),
        })


# ─── DispatchOrder ────────────────────────────────────────────────

class DispatchOrderViewSet(viewsets.ModelViewSet):
    queryset = DispatchOrder.objects.select_related(
        "plant", "plan", "sales_order", "customer", "vehicle",
        "logistics_vendor", "despatch",
    ).prefetch_related("loading_instructions", "pod_uploads")
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return DispatchOrderListSerializer
        if self.action in ("create", "update", "partial_update"):
            return DispatchOrderCreateSerializer
        return DispatchOrderDetailSerializer

    def get_queryset(self):
        qs = super().get_queryset()
        plant = self.request.query_params.get("plant")
        order_status = self.request.query_params.get("status")
        plan = self.request.query_params.get("plan")
        customer = self.request.query_params.get("customer")
        pod_pending = self.request.query_params.get("pod_pending")
        if plant:
            qs = qs.filter(plant=plant)
        if order_status:
            qs = qs.filter(status=order_status)
        if plan:
            qs = qs.filter(plan=plan)
        if customer:
            qs = qs.filter(customer=customer)
        if pod_pending == "true":
            qs = qs.filter(status=DispatchOrder.OrderStatus.POD_PENDING)
        return qs

    def create(self, request, *args, **kwargs):
        try:
            from apps.sales.models import SalesOrder
            from apps.masters.models import Customer

            plan = DispatchPlan.objects.get(pk=request.data["plan"])
            so = SalesOrder.objects.get(pk=request.data["sales_order"])
            customer = Customer.objects.get(pk=request.data["customer"])
            plan_line = None
            if request.data.get("plan_line"):
                plan_line = DispatchPlanLine.objects.get(pk=request.data["plan_line"])

            order = services.create_dispatch_order(
                plan=plan,
                plan_line=plan_line,
                sales_order=so,
                customer=customer,
                delivery_address=request.data.get("delivery_address", ""),
                scheduled_dispatch=request.data.get("scheduled_dispatch"),
                expected_delivery=request.data.get("expected_delivery"),
                no_of_packages=int(request.data.get("no_of_packages", 0)),
                gross_weight_kg=Decimal(str(request.data.get("gross_weight_kg", 0))),
                freight_amount=Decimal(str(request.data.get("freight_amount", 0))),
                notes=request.data.get("notes", ""),
                created_by=request.user,
            )
            return Response(DispatchOrderDetailSerializer(order).data, status=status.HTTP_201_CREATED)
        except Exception as e:
            return Response({"detail": str(e)}, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=True, methods=["post"], url_path="record-loading")
    def record_loading(self, request, pk=None):
        """Record loading of goods for this dispatch order."""
        dispatch_order = self.get_object()
        try:
            from apps.stores.models import Warehouse
            warehouse = Warehouse.objects.get(pk=request.data["warehouse"])

            despatch = None
            if request.data.get("despatch"):
                from apps.sales.models import Despatch
                despatch = Despatch.objects.get(pk=request.data["despatch"])

            dispatch_order, stock_issue = services.record_loading(
                dispatch_order=dispatch_order,
                loading_lines=request.data.get("loading_lines", []),
                warehouse=warehouse,
                despatch=despatch,
                loaded_by=request.user,
            )
            return Response({
                "dispatch_order": DispatchOrderDetailSerializer(dispatch_order).data,
                "stock_issue_number": stock_issue.issue_number if stock_issue else None,
            })
        except Exception as e:
            return Response({"detail": str(e)}, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=True, methods=["post"], url_path="gate-out")
    def gate_out(self, request, pk=None):
        """Mark dispatch order as GATE_OUT (vehicle left the premises)."""
        from django.utils import timezone as tz
        dispatch_order = self.get_object()
        dispatch_order.status = DispatchOrder.OrderStatus.GATE_OUT
        dispatch_order.actual_dispatch = tz.now()
        dispatch_order.save(update_fields=["status", "actual_dispatch"])
        return Response(DispatchOrderDetailSerializer(dispatch_order).data)

    @action(detail=True, methods=["post"], url_path="upload-pod")
    def upload_pod(self, request, pk=None):
        """Upload Proof-of-Delivery."""
        dispatch_order = self.get_object()
        try:
            pod = services.upload_pod(
                dispatch_order=dispatch_order,
                pod_date=request.data["pod_date"],
                received_by=request.data.get("received_by", ""),
                customer_ge_number=request.data.get("customer_ge_number", ""),
                pod_document=request.FILES.get("pod_document"),
                remarks=request.data.get("remarks", ""),
                uploaded_by=request.user,
            )
            return Response(PodUploadDetailSerializer(pod).data, status=status.HTTP_201_CREATED)
        except Exception as e:
            return Response({"detail": str(e)}, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=False, methods=["get"], url_path="summary-report")
    def summary_report(self, request):
        """Dispatch summary report: on-time %, POD-pending, cost/kg."""
        from apps.core.models import Plant
        plant_id = request.query_params.get("plant")
        if not plant_id:
            return Response({"detail": "plant param required."}, status=status.HTTP_400_BAD_REQUEST)
        try:
            plant = Plant.objects.get(pk=plant_id)
        except Plant.DoesNotExist:
            return Response({"detail": "Plant not found."}, status=status.HTTP_404_NOT_FOUND)

        filters = {
            k: request.query_params.get(k)
            for k in ("date_from", "date_to", "logistics_vendor_id", "status")
            if request.query_params.get(k)
        }
        report = services.get_dispatch_summary_report(plant=plant, filters=filters)
        return Response(report)


# ─── LoadingInstruction ───────────────────────────────────────────

class LoadingInstructionViewSet(viewsets.ModelViewSet):
    queryset = LoadingInstruction.objects.select_related(
        "dispatch_order", "item", "stock_issue", "loaded_by"
    )
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action in ("create", "update", "partial_update"):
            return LoadingInstructionCreateSerializer
        return LoadingInstructionSerializer

    def get_queryset(self):
        qs = super().get_queryset()
        dispatch_order = self.request.query_params.get("dispatch_order")
        if dispatch_order:
            qs = qs.filter(dispatch_order=dispatch_order)
        return qs


# ─── PodUpload ────────────────────────────────────────────────────

class PodUploadViewSet(viewsets.ModelViewSet):
    queryset = PodUpload.objects.select_related(
        "dispatch_order", "accepted_by", "uploaded_by"
    )
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return PodUploadListSerializer
        if self.action in ("create", "update", "partial_update"):
            return PodUploadCreateSerializer
        return PodUploadDetailSerializer

    def get_queryset(self):
        qs = super().get_queryset()
        dispatch_order = self.request.query_params.get("dispatch_order")
        pod_status = self.request.query_params.get("status")
        if dispatch_order:
            qs = qs.filter(dispatch_order=dispatch_order)
        if pod_status:
            qs = qs.filter(status=pod_status)
        return qs

    def create(self, request, *args, **kwargs):
        try:
            dispatch_order = DispatchOrder.objects.get(pk=request.data["dispatch_order"])
            pod = services.upload_pod(
                dispatch_order=dispatch_order,
                pod_date=request.data["pod_date"],
                received_by=request.data.get("received_by", ""),
                customer_ge_number=request.data.get("customer_ge_number", ""),
                pod_document=request.FILES.get("pod_document"),
                remarks=request.data.get("remarks", ""),
                uploaded_by=request.user,
            )
            return Response(PodUploadDetailSerializer(pod).data, status=status.HTTP_201_CREATED)
        except Exception as e:
            return Response({"detail": str(e)}, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=True, methods=["post"], url_path="accept")
    def accept(self, request, pk=None):
        """Accept a POD — marks dispatch order CLOSED."""
        from django.utils import timezone as tz
        pod = self.get_object()
        if pod.status not in (PodUpload.PodStatus.UPLOADED, PodUpload.PodStatus.DISPUTED):
            return Response(
                {"detail": f"Cannot accept POD in status '{pod.status}'."},
                status=status.HTTP_400_BAD_REQUEST,
            )
        pod.status = PodUpload.PodStatus.ACCEPTED
        pod.accepted_by = request.user
        pod.accepted_at = tz.now()
        pod.save(update_fields=["status", "accepted_by", "accepted_at"])

        # Close the dispatch order
        pod.dispatch_order.status = DispatchOrder.OrderStatus.CLOSED
        pod.dispatch_order.save(update_fields=["status"])

        return Response(PodUploadDetailSerializer(pod).data)

    @action(detail=True, methods=["post"], url_path="reject")
    def reject(self, request, pk=None):
        """Reject a POD — mark as REJECTED with reason."""
        pod = self.get_object()
        pod.status = PodUpload.PodStatus.REJECTED
        pod.rejection_reason = request.data.get("rejection_reason", "")
        pod.save(update_fields=["status", "rejection_reason"])
        return Response(PodUploadDetailSerializer(pod).data)


# ─── TransporterPayment ───────────────────────────────────────────

class TransporterPaymentViewSet(viewsets.ModelViewSet):
    queryset = TransporterPayment.objects.select_related(
        "plant", "logistics_vendor", "dispatch_plan", "voucher", "approved_by"
    )
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return TransporterPaymentListSerializer
        if self.action in ("create", "update", "partial_update"):
            return TransporterPaymentCreateSerializer
        return TransporterPaymentDetailSerializer

    def get_queryset(self):
        qs = super().get_queryset()
        plant = self.request.query_params.get("plant")
        pay_status = self.request.query_params.get("status")
        vendor = self.request.query_params.get("logistics_vendor")
        if plant:
            qs = qs.filter(plant=plant)
        if pay_status:
            qs = qs.filter(status=pay_status)
        if vendor:
            qs = qs.filter(logistics_vendor=vendor)
        return qs

    def create(self, request, *args, **kwargs):
        from apps.core.models import Plant
        try:
            plant = Plant.objects.get(pk=request.data["plant"])
            vendor = LogisticsVendor.objects.get(pk=request.data["logistics_vendor"])
            plan = None
            if request.data.get("dispatch_plan"):
                plan = DispatchPlan.objects.get(pk=request.data["dispatch_plan"])

            payment = services.create_transporter_payment(
                plant=plant,
                logistics_vendor=vendor,
                payment_date=request.data["payment_date"],
                freight_amount=Decimal(str(request.data["freight_amount"])),
                gst_rate=Decimal(str(request.data.get("gst_rate", 0))),
                tds_rate=Decimal(str(request.data.get("tds_rate", 0))),
                dispatch_plan=plan,
                dispatch_order_ids=request.data.get("dispatch_order_ids", []),
                payment_mode=request.data.get("payment_mode", ""),
                reference_number=request.data.get("reference_number", ""),
                notes=request.data.get("notes", ""),
                created_by=request.user,
            )
            return Response(
                TransporterPaymentDetailSerializer(payment).data,
                status=status.HTTP_201_CREATED,
            )
        except Exception as e:
            return Response({"detail": str(e)}, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=True, methods=["post"], url_path="approve")
    def approve(self, request, pk=None):
        """Approve a transporter payment."""
        from django.utils import timezone as tz
        payment = self.get_object()
        if payment.status != TransporterPayment.PaymentStatus.DRAFT:
            return Response(
                {"detail": f"Cannot approve payment in status '{payment.status}'."},
                status=status.HTTP_400_BAD_REQUEST,
            )
        payment.status = TransporterPayment.PaymentStatus.APPROVED
        payment.approved_by = request.user
        payment.approved_at = tz.now()
        payment.save(update_fields=["status", "approved_by", "approved_at"])
        return Response(TransporterPaymentDetailSerializer(payment).data)

    @action(detail=True, methods=["post"], url_path="mark-paid")
    def mark_paid(self, request, pk=None):
        """Mark payment as PAID."""
        from django.utils import timezone as tz
        payment = self.get_object()
        if payment.status != TransporterPayment.PaymentStatus.APPROVED:
            return Response(
                {"detail": "Payment must be APPROVED before marking PAID."},
                status=status.HTTP_400_BAD_REQUEST,
            )
        payment.status = TransporterPayment.PaymentStatus.PAID
        payment.payment_mode = request.data.get("payment_mode", payment.payment_mode)
        payment.reference_number = request.data.get("reference_number", payment.reference_number)
        payment.paid_at = tz.now()
        payment.save(update_fields=["status", "payment_mode", "reference_number", "paid_at"])
        return Response(TransporterPaymentDetailSerializer(payment).data)


# ─── Pallet/Container Calculator (F2) ───────────────────────────────

from rest_framework.views import APIView
from apps.dispatch.pallet_calculator import calculate_stuffing, CONTAINER_SPECS


class PalletCalculatorView(APIView):
    """
    POST /api/v1/dispatch/pallet-calculator/

    Calculate how many boxes fit on pallets and containers.

    Request body:
        box_length_mm, box_width_mm, box_height_mm (required)
        total_qty (required)
        container_type: 20FT | 40FT | 40HC (default: 20FT)
        box_weight_kg (optional)

    Returns stuffing calculation result.
    """
    permission_classes = [IsAuthenticated]

    def post(self, request):
        data = request.data
        required = ["box_length_mm", "box_width_mm", "box_height_mm", "total_qty"]
        missing = [f for f in required if not data.get(f)]
        if missing:
            return Response(
                {"detail": f"Missing required fields: {', '.join(missing)}"},
                status=status.HTTP_400_BAD_REQUEST
            )
        try:
            result = calculate_stuffing(
                box_length_mm=data["box_length_mm"],
                box_width_mm=data["box_width_mm"],
                box_height_mm=data["box_height_mm"],
                total_qty=data["total_qty"],
                container_type=data.get("container_type", "20FT"),
                box_weight_kg=data.get("box_weight_kg"),
            )
        except ValueError as e:
            return Response({"detail": str(e)}, status=status.HTTP_400_BAD_REQUEST)
        return Response(result, status=status.HTTP_200_OK)
