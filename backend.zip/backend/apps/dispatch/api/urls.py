"""Dispatch & Logistics API URL Configuration."""
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from apps.dispatch.api.viewsets import (
    VehicleTypeViewSet, VehicleViewSet,
    LogisticsVendorViewSet, DeliveryRouteViewSet,
    DispatchPlanViewSet, DispatchOrderViewSet,
    LoadingInstructionViewSet, PodUploadViewSet,
    TransporterPaymentViewSet,
    PalletCalculatorView,
)

router = DefaultRouter()
router.register(r"vehicle-types", VehicleTypeViewSet, basename="dispatch-vehicle-type")
router.register(r"vehicles", VehicleViewSet, basename="dispatch-vehicle")
router.register(r"vendors", LogisticsVendorViewSet, basename="dispatch-vendor")
router.register(r"routes", DeliveryRouteViewSet, basename="dispatch-route")
router.register(r"plans", DispatchPlanViewSet, basename="dispatch-plan")
router.register(r"orders", DispatchOrderViewSet, basename="dispatch-order")
router.register(r"loading-instructions", LoadingInstructionViewSet, basename="dispatch-loading")
router.register(r"pod-uploads", PodUploadViewSet, basename="dispatch-pod")
router.register(r"transporter-payments", TransporterPaymentViewSet, basename="dispatch-payment")

urlpatterns = [
    path("", include(router.urls)),
    path("pallet-calculator/", PalletCalculatorView.as_view(), name="pallet-calculator"),
]
