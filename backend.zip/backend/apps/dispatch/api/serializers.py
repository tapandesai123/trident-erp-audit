"""Dispatch & Logistics API Serializers — 3 variants per major model."""
from rest_framework import serializers
from django.core.validators import FileExtensionValidator
from apps.dispatch.models import (
    VehicleType, Vehicle, LogisticsVendor, DeliveryRoute,
    DispatchPlan, DispatchPlanLine, DispatchOrder,
    LoadingInstruction, PodUpload, TransporterPayment,
)


# ─── VehicleType ──────────────────────────────────────────────────

class VehicleTypeListSerializer(serializers.ModelSerializer):
    plant_code = serializers.CharField(source="plant.code", read_only=True)

    class Meta:
        model = VehicleType
        fields = ["id", "uuid", "code", "name", "plant", "plant_code", "capacity_kg", "capacity_cft", "is_active"]


class VehicleTypeDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = VehicleType
        fields = "__all__"


class VehicleTypeCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = VehicleType
        fields = ["plant", "code", "name", "capacity_kg", "capacity_cft", "is_active", "notes"]


# ─── LogisticsVendor ──────────────────────────────────────────────

class LogisticsVendorListSerializer(serializers.ModelSerializer):
    plant_code = serializers.CharField(source="plant.code", read_only=True)

    class Meta:
        model = LogisticsVendor
        fields = [
            "id", "uuid", "code", "name", "plant", "plant_code",
            "contact_person", "phone", "has_rate_contract", "is_active",
        ]


class LogisticsVendorDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = LogisticsVendor
        fields = "__all__"


class LogisticsVendorCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = LogisticsVendor
        fields = [
            "plant", "vendor", "code", "name", "contact_person",
            "phone", "email", "gst_number", "pan_number",
            "address", "city", "state", "pincode",
            "has_rate_contract", "rate_contract_valid_until",
            "base_rate_per_km", "base_rate_per_kg", "is_active", "notes",
        ]


# ─── Vehicle ──────────────────────────────────────────────────────

class VehicleListSerializer(serializers.ModelSerializer):
    vehicle_type_name = serializers.CharField(source="vehicle_type.name", read_only=True)
    vendor_name = serializers.CharField(source="logistics_vendor.name", read_only=True)

    class Meta:
        model = Vehicle
        fields = [
            "id", "uuid", "vehicle_number", "vehicle_type", "vehicle_type_name",
            "ownership", "status", "logistics_vendor", "vendor_name",
            "driver_name", "driver_phone",
            "fitness_valid_until", "insurance_valid_until",
        ]


class VehicleDetailSerializer(serializers.ModelSerializer):
    vehicle_type_name = serializers.CharField(source="vehicle_type.name", read_only=True)
    vendor_name = serializers.CharField(source="logistics_vendor.name", read_only=True)

    class Meta:
        model = Vehicle
        fields = "__all__"


class VehicleCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Vehicle
        fields = [
            "plant", "vehicle_number", "vehicle_type", "ownership",
            "logistics_vendor", "driver_name", "driver_phone", "driver_license_no",
            "driver_license_valid_until", "fitness_valid_until",
            "insurance_valid_until", "puc_valid_until",
            "capacity_kg", "capacity_cft", "notes",
        ]


# ─── DeliveryRoute ────────────────────────────────────────────────

class DeliveryRouteListSerializer(serializers.ModelSerializer):
    class Meta:
        model = DeliveryRoute
        fields = [
            "id", "uuid", "route_code", "name", "origin", "destination",
            "distance_km", "standard_transit_days", "is_active",
        ]


class DeliveryRouteDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = DeliveryRoute
        fields = "__all__"


class DeliveryRouteCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = DeliveryRoute
        fields = [
            "plant", "route_code", "name", "origin", "destination",
            "distance_km", "standard_transit_days",
            "preferred_vendor", "is_active", "notes",
        ]


# ─── DispatchPlanLine ─────────────────────────────────────────────

class DispatchPlanLineSerializer(serializers.ModelSerializer):
    customer_name = serializers.CharField(source="customer.name", read_only=True)
    so_number = serializers.CharField(source="sales_order.order_number", read_only=True)

    class Meta:
        model = DispatchPlanLine
        fields = "__all__"


class DispatchPlanLineCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = DispatchPlanLine
        fields = [
            "sales_order", "customer", "delivery_address",
            "item_description", "quantity", "uom", "weight_kg", "no_of_packages", "notes",
        ]


# ─── DispatchPlan ─────────────────────────────────────────────────

class DispatchPlanListSerializer(serializers.ModelSerializer):
    vehicle_number = serializers.CharField(source="vehicle.vehicle_number", read_only=True)
    vendor_name = serializers.CharField(source="logistics_vendor.name", read_only=True)

    class Meta:
        model = DispatchPlan
        fields = [
            "id", "uuid", "plan_number", "plan_date", "status",
            "vehicle", "vehicle_number", "logistics_vendor", "vendor_name",
            "total_packages", "total_weight_kg", "freight_amount",
            "scheduled_dispatch_date", "expected_delivery_date", "actual_dispatch_date",
        ]


class DispatchPlanDetailSerializer(serializers.ModelSerializer):
    lines = DispatchPlanLineSerializer(many=True, read_only=True)
    vehicle_number = serializers.CharField(source="vehicle.vehicle_number", read_only=True)
    vendor_name = serializers.CharField(source="logistics_vendor.name", read_only=True)
    route_name = serializers.CharField(source="route.name", read_only=True)

    class Meta:
        model = DispatchPlan
        fields = "__all__"


class DispatchPlanCreateSerializer(serializers.ModelSerializer):
    lines = DispatchPlanLineCreateSerializer(many=True, write_only=True)

    class Meta:
        model = DispatchPlan
        fields = [
            "plant", "plan_date", "vehicle", "logistics_vendor", "route",
            "driver_name", "driver_phone",
            "scheduled_dispatch_date", "expected_delivery_date",
            "freight_amount", "notes", "lines",
        ]


# ─── DispatchOrder ────────────────────────────────────────────────

class DispatchOrderListSerializer(serializers.ModelSerializer):
    customer_name = serializers.CharField(source="customer.name", read_only=True)
    so_number = serializers.CharField(source="sales_order.order_number", read_only=True)
    vehicle_number = serializers.CharField(source="vehicle.vehicle_number", read_only=True)

    class Meta:
        model = DispatchOrder
        fields = [
            "id", "uuid", "dispatch_number", "status",
            "plan", "sales_order", "so_number",
            "customer", "customer_name",
            "vehicle", "vehicle_number",
            "no_of_packages", "gross_weight_kg",
            "expected_delivery", "actual_delivery", "pod_received",
        ]


class DispatchOrderDetailSerializer(serializers.ModelSerializer):
    customer_name = serializers.CharField(source="customer.name", read_only=True)
    so_number = serializers.CharField(source="sales_order.order_number", read_only=True)
    vehicle_number = serializers.CharField(source="vehicle.vehicle_number", read_only=True)
    vendor_name = serializers.CharField(source="logistics_vendor.name", read_only=True)
    is_on_time = serializers.BooleanField(read_only=True)
    loading_instructions = serializers.SerializerMethodField()
    pod_uploads = serializers.SerializerMethodField()

    class Meta:
        model = DispatchOrder
        fields = "__all__"

    def get_loading_instructions(self, obj):
        return LoadingInstructionSerializer(
            obj.loading_instructions.all(), many=True
        ).data

    def get_pod_uploads(self, obj):
        return PodUploadListSerializer(obj.pod_uploads.all(), many=True).data


class DispatchOrderCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = DispatchOrder
        fields = [
            "plan", "plan_line", "sales_order", "customer",
            "delivery_address", "scheduled_dispatch", "expected_delivery",
            "no_of_packages", "gross_weight_kg", "freight_amount", "notes",
        ]


# ─── LoadingInstruction ───────────────────────────────────────────

class LoadingInstructionSerializer(serializers.ModelSerializer):
    item_code = serializers.CharField(source="item.code", read_only=True)

    class Meta:
        model = LoadingInstruction
        fields = "__all__"


class LoadingInstructionCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = LoadingInstruction
        fields = [
            "dispatch_order", "item", "item_description", "uom", "instructed_qty",
        ]


# ─── PodUpload ────────────────────────────────────────────────────

class PodUploadListSerializer(serializers.ModelSerializer):
    class Meta:
        model = PodUpload
        fields = [
            "id", "uuid", "pod_date", "status",
            "received_by", "customer_ge_number", "accepted_at",
        ]


class PodUploadDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = PodUpload
        fields = "__all__"


class PodUploadCreateSerializer(serializers.ModelSerializer):
    pod_document = serializers.FileField(
        required=False,
        allow_null=True,
        validators=[FileExtensionValidator(allowed_extensions=['pdf', 'jpg', 'jpeg'])],
    )

    class Meta:
        model = PodUpload
        fields = [
            "dispatch_order", "pod_date", "received_by",
            "customer_ge_number", "pod_document", "remarks",
        ]

    def validate_pod_document(self, value):
        if value and hasattr(value, 'size') and value.size > 10 * 1024 * 1024:
            raise serializers.ValidationError(
                "POD document must not exceed 10 MB. Please upload a smaller file."
            )
        return value


# ─── TransporterPayment ───────────────────────────────────────────

class TransporterPaymentListSerializer(serializers.ModelSerializer):
    vendor_name = serializers.CharField(source="logistics_vendor.name", read_only=True)
    voucher_number = serializers.CharField(source="voucher.voucher_number", read_only=True)

    class Meta:
        model = TransporterPayment
        fields = [
            "id", "uuid", "payment_number", "payment_date", "status",
            "logistics_vendor", "vendor_name",
            "freight_amount", "gst_amount", "tds_amount", "net_payable",
            "payment_mode", "voucher", "voucher_number",
        ]


class TransporterPaymentDetailSerializer(serializers.ModelSerializer):
    vendor_name = serializers.CharField(source="logistics_vendor.name", read_only=True)
    voucher_number = serializers.CharField(source="voucher.voucher_number", read_only=True)

    class Meta:
        model = TransporterPayment
        fields = "__all__"


class TransporterPaymentCreateSerializer(serializers.ModelSerializer):
    gst_rate = serializers.DecimalField(max_digits=5, decimal_places=2, default=0, write_only=True)
    tds_rate = serializers.DecimalField(max_digits=5, decimal_places=2, default=0, write_only=True)
    dispatch_order_ids = serializers.ListField(
        child=serializers.UUIDField(), required=False, write_only=True
    )

    class Meta:
        model = TransporterPayment
        fields = [
            "plant", "logistics_vendor", "payment_date", "freight_amount",
            "gst_rate", "tds_rate",
            "dispatch_plan", "dispatch_order_ids",
            "payment_mode", "reference_number", "notes",
        ]
