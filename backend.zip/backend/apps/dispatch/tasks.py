"""Dispatch & Logistics Celery Tasks."""
from celery import shared_task
from django.utils import timezone
from django.db.models import Q


@shared_task
def flag_overdue_deliveries():
    """
    Daily: Flag IN_TRANSIT orders whose expected_delivery < today as overdue.
    Sends in-app notification to dispatch team.
    """
    from apps.dispatch.models import DispatchOrder
    from apps.core.models import Notification
    today = timezone.now().date()

    overdue = DispatchOrder.objects.filter(
        status=DispatchOrder.OrderStatus.IN_TRANSIT,
        expected_delivery__lt=today,
    ).select_related("customer", "created_by")

    count = 0
    for order in overdue:
        if order.created_by:
            Notification.objects.create(
                user=order.created_by,
                title=f"Overdue Delivery: {order.dispatch_number}",
                message=(
                    f"Order {order.dispatch_number} to {order.customer} was expected by "
                    f"{order.expected_delivery} but is still IN_TRANSIT."
                ),
                notification_type="IN_APP",
                module="dispatch",
                resource="DispatchOrder",
                resource_id=order.id,
            )
        count += 1
    return f"Flagged {count} overdue deliveries."


@shared_task
def send_pod_reminders():
    """
    Daily: Remind dispatch team of orders where POD is still pending 3+ days after dispatch.
    """
    from apps.dispatch.models import DispatchOrder
    from apps.core.models import Notification
    cutoff = timezone.now() - timezone.timedelta(days=3)

    pod_pending = DispatchOrder.objects.filter(
        status=DispatchOrder.OrderStatus.POD_PENDING,
        created_at__lt=cutoff,
        created_by__isnull=False,
    ).select_related("customer", "created_by")

    count = 0
    for order in pod_pending:
        Notification.objects.create(
            user=order.created_by,
            title=f"POD Pending: {order.dispatch_number}",
            message=f"Order {order.dispatch_number} ({order.customer}) has POD pending for 3+ days.",
            notification_type="IN_APP",
            module="dispatch",
            resource="DispatchOrder",
            resource_id=order.id,
        )
        count += 1
    return f"Sent {count} POD reminders."


@shared_task
def vehicle_compliance_alert():
    """
    Weekly: Alert for vehicles with fitness/insurance/PUC expiring within 30 days.
    """
    from apps.dispatch.models import Vehicle
    from apps.core.models import Notification
    from django.contrib.auth import get_user_model
    User = get_user_model()

    today = timezone.now().date()
    alert_date = today + timezone.timedelta(days=30)

    vehicles = Vehicle.objects.filter(
        status__in=["AVAILABLE", "LOADED"],
    ).filter(
        Q(fitness_valid_until__lte=alert_date, fitness_valid_until__gte=today) |
        Q(insurance_valid_until__lte=alert_date, insurance_valid_until__gte=today) |
        Q(puc_valid_until__lte=alert_date, puc_valid_until__gte=today)
    )

    # Notify all superusers / dispatch managers
    admins = User.objects.filter(is_staff=True)
    count = 0
    for vehicle in vehicles:
        expiry_info = []
        if vehicle.fitness_valid_until and vehicle.fitness_valid_until <= alert_date:
            expiry_info.append(f"Fitness: {vehicle.fitness_valid_until}")
        if vehicle.insurance_valid_until and vehicle.insurance_valid_until <= alert_date:
            expiry_info.append(f"Insurance: {vehicle.insurance_valid_until}")
        if vehicle.puc_valid_until and vehicle.puc_valid_until <= alert_date:
            expiry_info.append(f"PUC: {vehicle.puc_valid_until}")

        if expiry_info:
            for admin_user in admins:
                Notification.objects.create(
                    user=admin_user,
                    title=f"Vehicle Compliance Expiring: {vehicle.vehicle_number}",
                    message=f"Vehicle {vehicle.vehicle_number} has expiring docs: {', '.join(expiry_info)}.",
                    notification_type="IN_APP",
                    module="dispatch",
                    resource="Vehicle",
                    resource_id=vehicle.id,
                )
            count += 1
    return f"Sent compliance alerts for {count} vehicles."


@shared_task
def accept_pod_auto():
    """
    Daily: Auto-accept PODs that have been UPLOADED for 7+ days without rejection.
    """
    from apps.dispatch.models import PodUpload, DispatchOrder
    cutoff = timezone.now() - timezone.timedelta(days=7)

    stale_pods = PodUpload.objects.filter(
        status=PodUpload.PodStatus.UPLOADED,
        created_at__lt=cutoff,
    )

    count = 0
    for pod in stale_pods:
        pod.status = PodUpload.PodStatus.ACCEPTED
        pod.accepted_at = timezone.now()
        pod.save(update_fields=["status", "accepted_at"])

        # Mark dispatch order CLOSED
        pod.dispatch_order.status = DispatchOrder.OrderStatus.CLOSED
        pod.dispatch_order.save(update_fields=["status"])
        count += 1

    return f"Auto-accepted {count} PODs."


@shared_task
def sync_dispatch_plan_status():
    """
    Hourly: Update DispatchPlan status based on its orders.
    COMPLETED when all orders are CLOSED.
    """
    from apps.dispatch.models import DispatchPlan, DispatchOrder

    active_plans = DispatchPlan.objects.filter(
        status__in=[DispatchPlan.PlanStatus.DISPATCHED]
    )

    count = 0
    for plan in active_plans:
        orders = plan.orders.all()
        if not orders.exists():
            continue
        all_closed = not orders.exclude(
            status__in=[DispatchOrder.OrderStatus.CLOSED, DispatchOrder.OrderStatus.CANCELLED]
        ).exists()
        if all_closed:
            plan.status = DispatchPlan.PlanStatus.COMPLETED
            plan.save(update_fields=["status"])
            count += 1

    return f"Completed {count} dispatch plans."
