"""
Purchase Module Services.
Encapsulates business logic: auto-lookup, tolerance checks, MRR→inventory,
document numbering, status transitions, and notification triggers.
"""
import json
import qrcode
import io
import base64
from decimal import Decimal
from datetime import date
from django.db import transaction
from django.db.models import Sum, Max, F
from django.utils import timezone
from django.conf import settings

from apps.core.models import AuditLog, DocSequence, Notification
from apps.masters.models import Item, ItemVendorLink
from apps.purchase.models import (
    PurchaseRequisition, PRLine, PRApproval,
    PurchaseOrder, POLine, POApproval,
    GateEntry, GateEntryLine,
    MRR, MRRLine,
)
from apps.stores.models import InventoryLot, InventoryTransaction, Warehouse


def _log_audit(user, action, resource, resource_id, **kwargs):
    AuditLog.objects.create(
        user=user, action=action, module="purchase",
        resource=resource, resource_id=resource_id, **kwargs
    )


def _notify(user, title, message, module="purchase", resource="", resource_id=None):
    Notification.objects.create(
        user=user, title=title, message=message,
        notification_type="IN_APP", module=module,
        resource=resource, resource_id=resource_id,
    )


def get_financial_year(ref_date=None):
    """Return financial year string e.g., '2026-27'."""
    d = ref_date or date.today()
    fy_start = settings.TRIDENT.get("FINANCIAL_YEAR_START_MONTH", 4)
    if d.month >= fy_start:
        return f"{d.year}-{str(d.year + 1)[-2:]}"
    return f"{d.year - 1}-{str(d.year)[-2:]}"


def get_next_doc_number(plant, doc_type, prefix=None):
    """Thread-safe document number generation."""
    fy = get_financial_year()
    seq, created = DocSequence.objects.get_or_create(
        plant=plant, doc_type=doc_type, financial_year=fy,
        defaults={
            "prefix": prefix or doc_type,
            "format_pattern": f"{prefix or doc_type}/{fy}/{{num:05d}}",
        }
    )
    return seq.get_next_number()


# ═══════════════════════════════════════════════════════════════════
# PR SERVICES
# ═══════════════════════════════════════════════════════════════════

def populate_pr_line_auto_data(pr_line: PRLine):
    """Auto-populate last vendor/price/stock info on PR line."""
    item = pr_line.item

    # Last PO for this item
    last_po_line = POLine.objects.filter(
        item=item, po__status__in=["APPROVED", "PARTIALLY_RECEIVED", "FULLY_RECEIVED"]
    ).order_by("-po__po_date").first()

    if last_po_line:
        pr_line.last_vendor = last_po_line.po.vendor
        pr_line.last_rate = last_po_line.rate
        pr_line.last_po_date = last_po_line.po.po_date

    # Current stock
    stock_agg = InventoryLot.objects.filter(
        item=item, is_active=True, status="AVAILABLE"
    ).aggregate(total=Sum("current_qty"))
    pr_line.current_stock = stock_agg["total"] or Decimal("0")
    pr_line.min_stock = item.min_stock
    pr_line.save(update_fields=[
        "last_vendor", "last_rate", "last_po_date", "current_stock", "min_stock"
    ])


def submit_pr(pr: PurchaseRequisition, user):
    """Submit PR for approval. No PO without approved PR."""
    if pr.status != PurchaseRequisition.Status.DRAFT:
        raise ValueError("Only DRAFT PRs can be submitted.")

    # Auto-populate line data
    for line in pr.lines.all():
        populate_pr_line_auto_data(line)

    pr.status = PurchaseRequisition.Status.SUBMITTED
    pr.submitted_at = timezone.now()
    pr.save(update_fields=["status", "submitted_at"])
    _log_audit(user, "UPDATE", "purchase_requisition", pr.id, notes="PR submitted for approval")
    return pr


def approve_pr(pr: PurchaseRequisition, approver, level, action, remarks=""):
    """Multi-level PR approval: HOD(1) → Plant Head(2) → Director(3)."""
    valid_transitions = {
        1: (PurchaseRequisition.Status.SUBMITTED, PurchaseRequisition.Status.HOD_APPROVED),
        2: (PurchaseRequisition.Status.HOD_APPROVED, PurchaseRequisition.Status.PLANT_HEAD_APPROVED),
        3: (PurchaseRequisition.Status.PLANT_HEAD_APPROVED, PurchaseRequisition.Status.DIRECTOR_APPROVED),
    }

    if level not in valid_transitions:
        raise ValueError(f"Invalid approval level: {level}")

    expected_status, next_status = valid_transitions[level]
    if pr.status != expected_status:
        raise ValueError(f"PR must be in '{expected_status}' status for level {level} approval. Current: {pr.status}")

    PRApproval.objects.create(
        pr=pr, approver=approver, action=action, level=level, remarks=remarks
    )

    if action == "APPROVED":
        pr.status = next_status
        if level == 3:  # Director only = fully approved
            pr.final_approved_at = timezone.now()
        pr.save(update_fields=["status", "final_approved_at"])
        _log_audit(approver, "APPROVE", "purchase_requisition", pr.id,
                   notes=f"Level {level} approved")
    elif action == "REJECTED":
        pr.status = PurchaseRequisition.Status.REJECTED
        pr.save(update_fields=["status"])
        _log_audit(approver, "REJECT", "purchase_requisition", pr.id, notes=remarks)
        _notify(pr.requested_by, f"PR {pr.pr_number} Rejected",
                f"Your PR was rejected at level {level}: {remarks}",
                resource="purchase_requisition", resource_id=pr.id)
    elif action == "RETURNED":
        pr.status = PurchaseRequisition.Status.DRAFT  # Back to draft for revision
        pr.save(update_fields=["status"])
        _notify(pr.requested_by, f"PR {pr.pr_number} Returned",
                f"Your PR was returned for revision: {remarks}",
                resource="purchase_requisition", resource_id=pr.id)

    return pr


# ═══════════════════════════════════════════════════════════════════
# PO SERVICES
# ═══════════════════════════════════════════════════════════════════

def create_po_from_pr(pr: PurchaseRequisition, vendor, user, po_type="FIXED_QTY"):
    """Create a PO from an approved PR. No PO without PR rule."""
    if not pr.is_fully_approved:
        raise ValueError("Cannot create PO from unapproved PR.")

    with transaction.atomic():
        po_number = get_next_doc_number(pr.plant, "PO", "PO")
        po = PurchaseOrder.objects.create(
            po_number=po_number,
            plant=pr.plant,
            vendor=vendor,
            po_date=date.today(),
            po_type=po_type,
            pr=pr,
            created_by=user,
            status=PurchaseOrder.Status.DRAFT,
        )

        for pr_line in pr.lines.all():
            gst_rate = pr_line.item.gst_rate
            rate = pr_line.estimated_rate or pr_line.last_rate or Decimal("0")
            POLine.objects.create(
                po=po,
                line_number=pr_line.line_number,
                item=pr_line.item,
                pr_line=pr_line,
                quantity=pr_line.quantity,
                rate=rate,
                gst_rate=gst_rate,
                uom=pr_line.uom,
                delivery_date=pr.required_date,
            )

        po.recalculate_totals()
        pr.status = PurchaseRequisition.Status.PO_CREATED
        pr.save(update_fields=["status"])
        _log_audit(user, "CREATE", "purchase_order", po.id,
                   notes=f"Created from PR {pr.pr_number}")
    return po


def check_po_price_increase(po: PurchaseOrder):
    """Check if any PO line has a price increase vs. last PO. Returns list of alerts."""
    alerts = []
    for line in po.lines.select_related("item"):
        last_po_line = POLine.objects.filter(
            item=line.item,
            po__vendor=po.vendor,
            po__status__in=["APPROVED", "PARTIALLY_RECEIVED", "FULLY_RECEIVED"],
        ).exclude(po=po).order_by("-po__po_date").first()

        if last_po_line and line.rate > last_po_line.rate:
            increase_pct = ((line.rate - last_po_line.rate) / last_po_line.rate * 100)
            alerts.append({
                "item_code": line.item.code,
                "item_name": line.item.name,
                "current_rate": float(line.rate),
                "last_rate": float(last_po_line.rate),
                "increase_pct": round(float(increase_pct), 2),
                "last_po": last_po_line.po.po_number,
                "last_po_date": str(last_po_line.po.po_date),
            })
    return alerts


def approve_po(po: PurchaseOrder, approver, action, remarks=""):
    """PO approval (single level + optional accounts check)."""
    if action == "APPROVED":
        po.status = PurchaseOrder.Status.APPROVED
        po.approved_by = approver
        po.approved_at = timezone.now()
        po.save(update_fields=["status", "approved_by", "approved_at"])
        _log_audit(approver, "APPROVE", "purchase_order", po.id)

        # Update item-vendor link
        for line in po.lines.select_related("item"):
            ItemVendorLink.objects.update_or_create(
                item=line.item, vendor=po.vendor,
                defaults={
                    "last_rate": line.rate,
                    "last_po_date": po.po_date,
                    "last_po_number": po.po_number,
                }
            )
    elif action == "REJECTED":
        po.status = PurchaseOrder.Status.CANCELLED
        po.save(update_fields=["status"])
        _log_audit(approver, "REJECT", "purchase_order", po.id, notes=remarks)

    POApproval.objects.create(
        po=po, approver=approver, action=action, level=1, remarks=remarks
    )
    return po


# ═══════════════════════════════════════════════════════════════════
# GATE ENTRY SERVICES
# ═══════════════════════════════════════════════════════════════════

def validate_gate_entry_against_po(gate_entry: GateEntry):
    """
    Validate gate entry lines against PO.
    Rules:
    - No gate entry without checked/approved PO
    - Quantity cannot exceed PO + tolerance
    Returns list of errors (empty = valid).
    """
    errors = []
    po = gate_entry.po

    if gate_entry.entry_type == GateEntry.EntryType.AGAINST_PO:
        if not po:
            errors.append("Gate entry against PO requires a linked PO.")
            return errors

        if po.status not in (PurchaseOrder.Status.APPROVED,
                             PurchaseOrder.Status.PARTIALLY_RECEIVED):
            errors.append(f"PO {po.po_number} is not approved (status: {po.status}).")
            return errors

        for ge_line in gate_entry.lines.all():
            if not ge_line.po_line:
                errors.append(f"Line {ge_line.line_number}: No PO line linked.")
                continue

            po_line = ge_line.po_line
            max_qty = po_line.tolerance_max_qty
            already_received = po_line.received_qty
            total_after = already_received + ge_line.quantity

            if total_after > max_qty:
                errors.append(
                    f"Line {ge_line.line_number} ({ge_line.item.code}): "
                    f"Qty {ge_line.quantity} would exceed PO tolerance. "
                    f"PO qty: {po_line.quantity}, tolerance: {po.tolerance_pct}%, "
                    f"already received: {already_received}, max allowed: {max_qty}"
                )

    return errors


def create_gate_entry(data, lines_data, user, plant):
    """Create gate entry with validation."""
    with transaction.atomic():
        ge_number = get_next_doc_number(plant, "GE", "GE")
        gate_entry = GateEntry.objects.create(
            gate_entry_number=ge_number,
            plant=plant,
            created_by=user,
            **data
        )

        for line_data in lines_data:
            GateEntryLine.objects.create(gate_entry=gate_entry, **line_data)

        errors = validate_gate_entry_against_po(gate_entry)
        if errors:
            raise ValueError("; ".join(errors))

        _log_audit(user, "CREATE", "gate_entry", gate_entry.id)
        return gate_entry


# ═══════════════════════════════════════════════════════════════════
# MRR SERVICES
# ═══════════════════════════════════════════════════════════════════

def generate_qr_code_data(mrr_line: MRRLine, mrr: MRR):
    """Generate QR code content for an MRR line / inventory lot."""
    data = {
        "mrr": mrr.mrr_number,
        "item": mrr_line.item.code,
        "item_name": mrr_line.item.name[:50],
        "lot": mrr_line.lot_number,
        "roll": mrr_line.roll_number,
        "qty": str(mrr_line.quantity),
        "supplier": mrr.vendor.code if mrr.vendor else "",
        "date": str(mrr.mrr_date),
        "weight": str(mrr_line.gross_weight_kg or ""),
        "gsm": str(mrr_line.item.gsm or ""),
    }
    return json.dumps(data, separators=(",", ":"))


def generate_qr_image_base64(qr_data: str) -> str:
    """Generate QR code image as base64 string."""
    qr = qrcode.QRCode(version=1, error_correction=qrcode.constants.ERROR_CORRECT_M, box_size=8, border=2)
    qr.add_data(qr_data)
    qr.make(fit=True)
    img = qr.make_image(fill_color="black", back_color="white")
    buffer = io.BytesIO()
    img.save(buffer, format="PNG")
    return base64.b64encode(buffer.getvalue()).decode()


def create_mrr_from_gate_entry(gate_entry: GateEntry, warehouse, user):
    """
    Create MRR from gate entry and generate inventory lots + QR codes.
    This is the key function that bridges Purchase → Stores.
    """
    if gate_entry.status == GateEntry.Status.MRR_CREATED:
        raise ValueError("MRR already created for this gate entry.")
    if gate_entry.status != GateEntry.Status.PENDING:
        raise ValueError(
            f"Gate entry must be in PENDING status to create an MRR (current status: {gate_entry.status})."
        )

    with transaction.atomic():
        mrr_number = get_next_doc_number(gate_entry.plant, "MRR", "MRR")
        mrr = MRR.objects.create(
            mrr_number=mrr_number,
            plant=gate_entry.plant,
            gate_entry=gate_entry,
            po=gate_entry.po,
            vendor=gate_entry.vendor,
            mrr_date=date.today(),
            mrr_type=MRR.MRRType.FIXED_PO if gate_entry.po else MRR.MRRType.CUSTOMER_JOB_WORK,
            warehouse=warehouse,
            status=MRR.Status.QC_PENDING,
            created_by=user,
        )

        for ge_line in gate_entry.lines.all():
            # Generate lot/roll number
            lot_num = f"{mrr.mrr_number}-L{ge_line.line_number}"
            roll_num = ge_line.roll_number or ""

            mrr_line = MRRLine.objects.create(
                mrr=mrr,
                line_number=ge_line.line_number,
                item=ge_line.item,
                gate_entry_line=ge_line,
                po_line=ge_line.po_line,
                quantity=ge_line.quantity,
                accepted_qty=ge_line.quantity,  # default to full, QC may reduce
                uom=ge_line.uom,
                rate=ge_line.po_line.rate if ge_line.po_line else None,
                lot_number=lot_num,
                roll_number=roll_num,
                gross_weight_kg=ge_line.gross_weight_kg,
                net_weight_kg=ge_line.net_weight_kg,
            )

            # Generate QR code
            qr_data = generate_qr_code_data(mrr_line, mrr)
            mrr_line.qr_code_data = qr_data
            mrr_line.save(update_fields=["qr_code_data"])

            # Create inventory lot
            lot = InventoryLot.objects.create(
                item=ge_line.item,
                plant=gate_entry.plant,
                warehouse=warehouse,
                lot_number=lot_num,
                roll_number=roll_num,
                original_qty=ge_line.quantity,
                current_qty=ge_line.quantity,
                gross_weight_kg=ge_line.gross_weight_kg,
                net_weight_kg=ge_line.net_weight_kg,
                deckle_mm=ge_line.deckle_mm,
                supplier=gate_entry.vendor,
                receipt_date=date.today(),
                qc_status="PENDING",
                qr_code_data=qr_data,
                fifo_date=date.today(),
                status="QUARANTINE",  # Until QC passes
                mrr_id=mrr.id,
                gate_entry_id=gate_entry.id,
            )

            # Create receipt transaction
            InventoryTransaction.objects.create(
                lot=lot,
                transaction_type="RECEIPT",
                quantity=ge_line.quantity,
                reference_type="MRR",
                reference_id=mrr.id,
                to_location=None,
                done_by=user,
                remarks=f"Receipt via MRR {mrr.mrr_number}",
            )

            # Link back
            mrr_line.inventory_lot = lot
            mrr_line.save(update_fields=["inventory_lot"])

            # Update PO received qty
            if ge_line.po_line:
                po_line = ge_line.po_line
                po_line.received_qty = F("received_qty") + ge_line.quantity
                po_line.save(update_fields=["received_qty"])
                po_line.refresh_from_db()

        # Update gate entry status
        gate_entry.status = GateEntry.Status.MRR_CREATED
        gate_entry.save(update_fields=["status"])

        # Update PO status
        if gate_entry.po:
            po = gate_entry.po
            po.refresh_from_db()
            if po.is_fully_received:
                po.status = PurchaseOrder.Status.FULLY_RECEIVED
            else:
                po.status = PurchaseOrder.Status.PARTIALLY_RECEIVED
            po.save(update_fields=["status"])

        _log_audit(user, "CREATE", "mrr", mrr.id,
                   notes=f"Created from GE {gate_entry.gate_entry_number}")

        return mrr


# ═══════════════════════════════════════════════════════════════════
# TAT & REPORT HELPERS
# ═══════════════════════════════════════════════════════════════════

def get_pr_to_po_tat(plant=None, days_back=30):
    """TAT: PR submission to PO creation."""
    from django.db.models import F, ExpressionWrapper, DurationField
    qs = PurchaseRequisition.objects.filter(
        status=PurchaseRequisition.Status.PO_CREATED,
        submitted_at__isnull=False,
    )
    if plant:
        qs = qs.filter(plant=plant)

    results = []
    for pr in qs.order_by("-submitted_at")[:100]:
        po = pr.purchase_orders.first()
        if po:
            tat_days = (po.created_at.date() - pr.submitted_at.date()).days
            results.append({
                "pr_number": pr.pr_number,
                "po_number": po.po_number,
                "pr_submitted": str(pr.submitted_at.date()),
                "po_created": str(po.created_at.date()),
                "tat_days": tat_days,
            })
    return results


def get_pending_reports(plant=None):
    """Summary of pending items across the purchase pipeline."""
    filters = {}
    if plant:
        filters["plant"] = plant

    return {
        "pr_not_approved": PurchaseRequisition.objects.filter(
            status__in=["SUBMITTED", "HOD_APPROVED"], **filters
        ).count(),
        "pr_approved_no_po": PurchaseRequisition.objects.filter(
            status="DIRECTOR_APPROVED",
            purchase_orders__isnull=True, **filters
        ).count(),
        "po_not_approved": PurchaseOrder.objects.filter(
            status__in=["DRAFT", "SUBMITTED", "ACCOUNTS_CHECKED"], **filters
        ).count(),
        "po_approved_no_mrr": PurchaseOrder.objects.filter(
            status="APPROVED", gate_entries__isnull=True, **filters
        ).count(),
        "gate_entry_pending_mrr": GateEntry.objects.filter(
            status="PENDING", **filters
        ).count(),
        "mrr_qc_pending": MRR.objects.filter(
            status="QC_PENDING", **filters
        ).count(),
    }


# ═══════════════════════════════════════════════════════════════════
# VENDOR SAUDA SERVICES
# ═══════════════════════════════════════════════════════════════════

def link_po_to_sauda(po_line, sauda):
    """
    Validates balance, creates SaudaPOLink, updates sauda.ordered_qty.
    Raises ValueError if sauda is exhausted or qty exceeds balance + tolerance.
    """
    from apps.purchase.models import SaudaPOLink, VendorSauda
    from decimal import Decimal

    if sauda.status in (VendorSauda.SaudaStatus.EXHAUSTED, VendorSauda.SaudaStatus.CANCELLED):
        raise ValueError(f"Sauda {sauda.sauda_number} is {sauda.status} — cannot link PO.")

    max_allowed = sauda.agreed_qty * (1 + sauda.tolerance_pct / Decimal("100"))
    if sauda.ordered_qty + po_line.quantity > max_allowed:
        raise ValueError(
            f"Linking this PO line would exceed sauda balance "
            f"(balance: {sauda.balance_qty}, tolerance: {sauda.tolerance_pct}%)"
        )

    link, created = SaudaPOLink.objects.get_or_create(
        sauda=sauda,
        po_line=po_line,
        defaults={"qty": po_line.quantity},
    )
    if created:
        sauda.ordered_qty += po_line.quantity
        sauda.save(update_fields=["ordered_qty"])
        check_sauda_exhaustion(sauda)
    return link


def check_sauda_exhaustion(sauda):
    """Sets status to EXHAUSTED if ordered_qty >= agreed_qty."""
    from apps.purchase.models import VendorSauda
    if sauda.ordered_qty >= sauda.agreed_qty:
        sauda.status = VendorSauda.SaudaStatus.EXHAUSTED
        sauda.save(update_fields=["status"])
    return sauda


# ═══════════════════════════════════════════════════════════════════
# RGP RECONCILIATION SERVICES
# ═══════════════════════════════════════════════════════════════════

def reconcile_rgp_with_mrr(rgp_id, mrr_id):
    """
    Matches MRR lines to RGP lines by item, updates returned_qty.
    Auto-closes RGP if all lines fully returned.
    Returns dict with reconciliation summary.
    """
    from apps.purchase.models import RGPChallan, MRR, RGPLine

    try:
        rgp = RGPChallan.objects.prefetch_related("lines__item").get(id=rgp_id)
    except RGPChallan.DoesNotExist:
        return {"error": f"RGP {rgp_id} not found"}

    try:
        mrr = MRR.objects.prefetch_related("lines__item").get(id=mrr_id)
    except MRR.DoesNotExist:
        return {"error": f"MRR {mrr_id} not found"}

    # Set RGP reference on MRR
    mrr.rgp_reference = rgp
    mrr.save(update_fields=["rgp_reference"])

    reconciled = []
    for mrr_line in mrr.lines.all():
        matching_rgp_lines = rgp.lines.filter(item=mrr_line.item)
        remaining_mrr_qty = mrr_line.quantity
        for rgp_line in matching_rgp_lines:
            return_qty = min(remaining_mrr_qty, rgp_line.pending_qty)
            remaining_mrr_qty -= return_qty
            if remaining_mrr_qty <= 0:
                break
            if return_qty > 0:
                rgp_line.returned_qty += return_qty
                rgp_line.save(update_fields=["returned_qty"])
                reconciled.append({
                    "item_code": mrr_line.item.code,
                    "returned_qty": float(return_qty),
                    "pending_qty": float(rgp_line.pending_qty),
                })

    # Check if fully returned
    lines_fresh = list(rgp.lines.all())
    all_returned = all(line.pending_qty <= 0 for line in lines_fresh)
    any_returned = any(line.returned_qty > 0 for line in lines_fresh)

    if all_returned:
        rgp.status = "RETURNED"
    elif any_returned:
        rgp.status = "PARTIAL"
    rgp.save(update_fields=["status"])

    return {
        "rgp_number": rgp.rgp_number,
        "mrr_number": mrr.mrr_number,
        "status": rgp.status,
        "reconciled_lines": reconciled,
        "fully_returned": all_returned,
    }
