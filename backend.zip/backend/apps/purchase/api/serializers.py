"""
Purchase Module Serializers.
PR, PO, Gate Entry, MRR with nested lines, auto-populated fields,
and validation logic.
"""
from rest_framework import serializers
from django.utils import timezone
from decimal import Decimal

from apps.purchase.models import (
    PurchaseRequisition, PRLine, PRApproval,
    PurchaseOrder, POLine, POApproval,
    GateEntry, GateEntryLine,
    MRR, MRRLine,
)


# ═══════════════════════════════════════════════════════════════════
# PR SERIALIZERS
# ═══════════════════════════════════════════════════════════════════

class PRLineSerializer(serializers.ModelSerializer):
    item_code = serializers.CharField(source="item.code", read_only=True)
    item_name = serializers.CharField(source="item.name", read_only=True)
    uom_code = serializers.CharField(source="uom.code", read_only=True)
    last_vendor_name = serializers.CharField(source="last_vendor.name", read_only=True, default="")

    class Meta:
        model = PRLine
        fields = [
            "id", "line_number", "item", "item_code", "item_name",
            "quantity", "uom", "uom_code", "estimated_rate",
            "last_vendor", "last_vendor_name", "last_rate", "last_po_date",
            "current_stock", "min_stock", "remarks",
        ]
        read_only_fields = ["last_vendor", "last_rate", "last_po_date", "current_stock", "min_stock"]


class PRApprovalSerializer(serializers.ModelSerializer):
    approver_name = serializers.CharField(source="approver.get_full_name", read_only=True)

    class Meta:
        model = PRApproval
        fields = ["id", "approver", "approver_name", "action", "level", "remarks", "acted_at"]
        read_only_fields = ["approver", "acted_at"]


class PRListSerializer(serializers.ModelSerializer):
    requested_by_name = serializers.CharField(source="requested_by.get_full_name", read_only=True)
    status_display = serializers.CharField(source="get_status_display", read_only=True)
    priority_display = serializers.CharField(source="get_priority_display", read_only=True)
    line_count = serializers.IntegerField(read_only=True)
    total_estimated_value = serializers.DecimalField(max_digits=15, decimal_places=2, read_only=True)

    class Meta:
        model = PurchaseRequisition
        fields = [
            "id", "uuid", "pr_number", "plant", "department",
            "pr_date", "required_date", "priority", "priority_display",
            "status", "status_display", "requested_by", "requested_by_name",
            "line_count", "total_estimated_value", "created_at",
        ]


class PRDetailSerializer(serializers.ModelSerializer):
    lines = PRLineSerializer(many=True, required=False)
    approvals = PRApprovalSerializer(many=True, read_only=True)
    requested_by_name = serializers.CharField(source="requested_by.get_full_name", read_only=True)
    status_display = serializers.CharField(source="get_status_display", read_only=True)

    class Meta:
        model = PurchaseRequisition
        fields = "__all__"
        read_only_fields = [
            "uuid", "pr_number", "status", "requested_by",
            "current_approver", "submitted_at", "final_approved_at",
            "created_at", "updated_at",
        ]

    def create(self, validated_data):
        lines_data = validated_data.pop("lines", [])
        request = self.context.get("request")
        plant = request.plant if request else None

        from apps.purchase.services import get_next_doc_number
        pr_number = get_next_doc_number(
            plant or validated_data.get("plant"), "PR", "PR"
        )

        pr = PurchaseRequisition.objects.create(
            **validated_data,
            pr_number=pr_number,
            requested_by=request.user if request else None,
        )

        for i, line_data in enumerate(lines_data, 1):
            line_data.setdefault("line_number", i)
            PRLine.objects.create(pr=pr, **line_data)

        return pr

    def update(self, instance, validated_data):
        lines_data = validated_data.pop("lines", None)
        for attr, value in validated_data.items():
            setattr(instance, attr, value)
        instance.save()

        if lines_data is not None:
            instance.lines.all().delete()
            for i, line_data in enumerate(lines_data, 1):
                line_data.setdefault("line_number", i)
                PRLine.objects.create(pr=instance, **line_data)

        return instance


class PRSubmitSerializer(serializers.Serializer):
    """Submit PR for approval."""
    pass  # No additional data needed


class PRApproveActionSerializer(serializers.Serializer):
    action = serializers.ChoiceField(choices=["APPROVED", "REJECTED", "RETURNED"])
    level = serializers.IntegerField(min_value=1, max_value=3)
    remarks = serializers.CharField(required=False, allow_blank=True, default="")


# ═══════════════════════════════════════════════════════════════════
# PO SERIALIZERS
# ═══════════════════════════════════════════════════════════════════

class POLineSerializer(serializers.ModelSerializer):
    item_code = serializers.CharField(source="item.code", read_only=True)
    item_name = serializers.CharField(source="item.name", read_only=True)
    uom_code = serializers.CharField(source="uom.code", read_only=True, default="")
    pending_qty = serializers.DecimalField(max_digits=15, decimal_places=3, read_only=True)
    tolerance_max_qty = serializers.DecimalField(max_digits=15, decimal_places=3, read_only=True)

    class Meta:
        model = POLine
        fields = [
            "id", "line_number", "item", "item_code", "item_name",
            "pr_line", "quantity", "received_qty", "pending_qty",
            "tolerance_max_qty", "rate", "discount_pct",
            "gst_rate", "amount", "gst_amount", "total_amount",
            "uom", "uom_code", "delivery_date", "remarks",
        ]
        read_only_fields = ["received_qty", "amount", "gst_amount", "total_amount"]


class POApprovalSerializer(serializers.ModelSerializer):
    approver_name = serializers.CharField(source="approver.get_full_name", read_only=True)

    class Meta:
        model = POApproval
        fields = ["id", "approver", "approver_name", "action", "level", "remarks", "acted_at"]


class POListSerializer(serializers.ModelSerializer):
    vendor_name = serializers.CharField(source="vendor.name", read_only=True)
    vendor_code = serializers.CharField(source="vendor.code", read_only=True)
    status_display = serializers.CharField(source="get_status_display", read_only=True)
    po_type_display = serializers.CharField(source="get_po_type_display", read_only=True)
    receipt_percentage = serializers.FloatField(read_only=True)

    class Meta:
        model = PurchaseOrder
        fields = [
            "id", "uuid", "po_number", "plant", "vendor", "vendor_code",
            "vendor_name", "po_date", "po_type", "po_type_display",
            "delivery_date", "status", "status_display",
            "subtotal", "total_amount", "receipt_percentage",
            "created_at",
        ]


class PODetailSerializer(serializers.ModelSerializer):
    lines = POLineSerializer(many=True, required=False)
    approvals = POApprovalSerializer(many=True, read_only=True)
    vendor_name = serializers.CharField(source="vendor.name", read_only=True)
    status_display = serializers.CharField(source="get_status_display", read_only=True)
    created_by_name = serializers.CharField(source="created_by.get_full_name", read_only=True, default="")
    approved_by_name = serializers.CharField(source="approved_by.get_full_name", read_only=True, default="")

    class Meta:
        model = PurchaseOrder
        fields = "__all__"
        read_only_fields = [
            "uuid", "po_number", "subtotal", "gst_amount", "tcs_amount",
            "total_amount", "status", "accounts_checked", "accounts_checked_by",
            "accounts_checked_at", "approved_by", "approved_at",
            "amendment_number", "amended_from",
            "created_by", "updated_by", "created_at", "updated_at",
        ]

    def create(self, validated_data):
        lines_data = validated_data.pop("lines", [])
        request = self.context.get("request")
        plant = request.plant if request else validated_data.get("plant")

        from apps.purchase.services import get_next_doc_number
        po_number = get_next_doc_number(plant, "PO", "PO")

        po = PurchaseOrder.objects.create(
            **validated_data,
            po_number=po_number,
            created_by=request.user if request else None,
        )

        for i, line_data in enumerate(lines_data, 1):
            line_data.setdefault("line_number", i)
            POLine.objects.create(po=po, **line_data)

        po.recalculate_totals()
        return po

    def update(self, instance, validated_data):
        lines_data = validated_data.pop("lines", None)
        request = self.context.get("request")
        if request:
            validated_data["updated_by"] = request.user

        for attr, value in validated_data.items():
            setattr(instance, attr, value)
        instance.save()

        if lines_data is not None:
            instance.lines.all().delete()
            for i, line_data in enumerate(lines_data, 1):
                line_data.setdefault("line_number", i)
                POLine.objects.create(po=instance, **line_data)
            instance.recalculate_totals()

        return instance


class POApproveActionSerializer(serializers.Serializer):
    action = serializers.ChoiceField(choices=["APPROVED", "REJECTED"])
    remarks = serializers.CharField(required=False, allow_blank=True, default="")


class POFromPRSerializer(serializers.Serializer):
    """Create PO from an approved PR."""
    pr_id = serializers.IntegerField()
    vendor_id = serializers.IntegerField()
    po_type = serializers.ChoiceField(
        choices=PurchaseOrder.POType.choices, default="FIXED_QTY"
    )


# ═══════════════════════════════════════════════════════════════════
# GATE ENTRY SERIALIZERS
# ═══════════════════════════════════════════════════════════════════

class GateEntryLineSerializer(serializers.ModelSerializer):
    item_code = serializers.CharField(source="item.code", read_only=True)
    item_name = serializers.CharField(source="item.name", read_only=True)

    class Meta:
        model = GateEntryLine
        fields = [
            "id", "line_number", "item", "item_code", "item_name",
            "po_line", "quantity", "uom",
            "roll_number", "gross_weight_kg", "net_weight_kg", "deckle_mm",
            "remarks",
        ]


class GateEntryListSerializer(serializers.ModelSerializer):
    vendor_name = serializers.CharField(source="vendor.name", read_only=True, default="")
    status_display = serializers.CharField(source="get_status_display", read_only=True)
    entry_type_display = serializers.CharField(source="get_entry_type_display", read_only=True)

    class Meta:
        model = GateEntry
        fields = [
            "id", "uuid", "gate_entry_number", "plant", "entry_type",
            "entry_type_display", "vendor", "vendor_name", "po",
            "vehicle_number", "entry_datetime", "status", "status_display",
            "gst_transporter_copy_received", "created_at",
        ]


class GateEntryDetailSerializer(serializers.ModelSerializer):
    lines = GateEntryLineSerializer(many=True, required=False)
    vendor_name = serializers.CharField(source="vendor.name", read_only=True, default="")
    status_display = serializers.CharField(source="get_status_display", read_only=True)

    class Meta:
        model = GateEntry
        fields = "__all__"
        read_only_fields = ["uuid", "gate_entry_number", "status", "created_by", "created_at", "updated_at"]

    def create(self, validated_data):
        lines_data = validated_data.pop("lines", [])
        request = self.context.get("request")
        plant = request.plant if request else validated_data.get("plant")

        from apps.purchase.services import create_gate_entry
        gate_entry = create_gate_entry(
            data=validated_data,
            lines_data=[{**ld, "line_number": i} for i, ld in enumerate(lines_data, 1)],
            user=request.user if request else None,
            plant=plant,
        )
        return gate_entry


# ═══════════════════════════════════════════════════════════════════
# MRR SERIALIZERS
# ═══════════════════════════════════════════════════════════════════

class MRRLineSerializer(serializers.ModelSerializer):
    item_code = serializers.CharField(source="item.code", read_only=True)
    item_name = serializers.CharField(source="item.name", read_only=True)
    qr_image_base64 = serializers.SerializerMethodField()

    class Meta:
        model = MRRLine
        fields = [
            "id", "line_number", "item", "item_code", "item_name",
            "gate_entry_line", "po_line",
            "quantity", "accepted_qty", "rejected_qty", "uom", "rate",
            "bin_location", "lot_number", "roll_number",
            "gross_weight_kg", "net_weight_kg",
            "qr_code_data", "qr_printed", "qc_status", "qc_remarks",
            "inventory_lot", "qr_image_base64", "remarks",
        ]
        read_only_fields = ["qr_code_data", "inventory_lot"]

    def get_qr_image_base64(self, obj):
        if obj.qr_code_data:
            from apps.purchase.services import generate_qr_image_base64
            return generate_qr_image_base64(obj.qr_code_data)
        return None


class MRRListSerializer(serializers.ModelSerializer):
    vendor_name = serializers.CharField(source="vendor.name", read_only=True, default="")
    status_display = serializers.CharField(source="get_status_display", read_only=True)
    gate_entry_number = serializers.CharField(source="gate_entry.gate_entry_number", read_only=True)

    class Meta:
        model = MRR
        fields = [
            "id", "uuid", "mrr_number", "plant", "gate_entry",
            "gate_entry_number", "po", "vendor", "vendor_name",
            "mrr_date", "mrr_type", "warehouse", "status", "status_display",
            "created_at",
        ]


class MRRDetailSerializer(serializers.ModelSerializer):
    lines = MRRLineSerializer(many=True, read_only=True)
    vendor_name = serializers.CharField(source="vendor.name", read_only=True, default="")
    status_display = serializers.CharField(source="get_status_display", read_only=True)
    gate_entry_number = serializers.CharField(source="gate_entry.gate_entry_number", read_only=True)

    class Meta:
        model = MRR
        fields = "__all__"
        read_only_fields = ["uuid", "mrr_number", "status", "created_by", "created_at", "updated_at"]


class CreateMRRSerializer(serializers.Serializer):
    """Create MRR from a gate entry."""
    gate_entry_id = serializers.IntegerField()
    warehouse_id = serializers.IntegerField()


# ── Vendor Sauda Serializers ──────────────────────────────────────

class VendorSaudaSerializer(serializers.ModelSerializer):
    vendor_name      = serializers.CharField(source="vendor.name", read_only=True)
    item_code        = serializers.CharField(source="item.code", read_only=True)
    uom_name         = serializers.CharField(source="uom.name", read_only=True)
    balance_qty      = serializers.DecimalField(max_digits=15, decimal_places=3, read_only=True)
    balance_value    = serializers.DecimalField(max_digits=15, decimal_places=2, read_only=True)
    utilization_pct  = serializers.FloatField(read_only=True)
    status_display   = serializers.CharField(source="get_status_display", read_only=True)

    class Meta:
        from apps.purchase.models import VendorSauda
        model = VendorSauda
        fields = [
            "id", "uuid", "sauda_number", "plant", "vendor", "vendor_name",
            "item", "item_code", "agreed_qty", "agreed_rate", "uom", "uom_name",
            "valid_from", "valid_to", "tolerance_pct", "ordered_qty", "received_qty",
            "balance_qty", "balance_value", "utilization_pct",
            "status", "status_display", "terms", "created_at",
        ]
        read_only_fields = ["uuid", "sauda_number", "ordered_qty", "received_qty", "created_at"]


# ── RGP Challan Serializers ───────────────────────────────────────

class RGPLineSerializer(serializers.ModelSerializer):
    item_code    = serializers.CharField(source="item.code", read_only=True)
    item_name    = serializers.CharField(source="item.name", read_only=True)
    uom_name     = serializers.CharField(source="uom.name", read_only=True)
    pending_qty  = serializers.DecimalField(max_digits=15, decimal_places=3, read_only=True)

    class Meta:
        from apps.purchase.models import RGPLine
        model = RGPLine
        fields = [
            "id", "item", "item_code", "item_name", "asset_tag",
            "sent_qty", "returned_qty", "pending_qty", "uom", "uom_name", "description",
        ]


class RGPChallanSerializer(serializers.ModelSerializer):
    vendor_name    = serializers.CharField(source="vendor.name", read_only=True)
    lines          = RGPLineSerializer(many=True, read_only=True)
    status_display = serializers.CharField(source="get_status_display", read_only=True)
    is_overdue     = serializers.BooleanField(read_only=True)

    class Meta:
        from apps.purchase.models import RGPChallan
        model = RGPChallan
        fields = [
            "id", "uuid", "rgp_number", "plant", "vendor", "vendor_name",
            "challan_date", "expected_return", "status", "status_display",
            "job_work_po", "transport_details", "remarks", "is_overdue",
            "lines", "created_at",
        ]
        read_only_fields = ["uuid", "rgp_number", "created_at"]
