"""Purchase Module Filters."""
import django_filters
from apps.purchase.models import PurchaseRequisition, PurchaseOrder, GateEntry, MRR


class PRFilter(django_filters.FilterSet):
    pr_number = django_filters.CharFilter(lookup_expr="icontains")
    status = django_filters.ChoiceFilter(choices=PurchaseRequisition.Status.choices)
    priority = django_filters.ChoiceFilter(choices=PurchaseRequisition.Priority.choices)
    department = django_filters.NumberFilter()
    requested_by = django_filters.NumberFilter()
    pr_date_from = django_filters.DateFilter(field_name="pr_date", lookup_expr="gte")
    pr_date_to = django_filters.DateFilter(field_name="pr_date", lookup_expr="lte")
    plant = django_filters.NumberFilter()

    class Meta:
        model = PurchaseRequisition
        fields = ["status", "priority", "department", "requested_by", "plant"]


class POFilter(django_filters.FilterSet):
    po_number = django_filters.CharFilter(lookup_expr="icontains")
    status = django_filters.ChoiceFilter(choices=PurchaseOrder.Status.choices)
    po_type = django_filters.ChoiceFilter(choices=PurchaseOrder.POType.choices)
    vendor = django_filters.NumberFilter()
    vendor_name = django_filters.CharFilter(field_name="vendor__name", lookup_expr="icontains")
    po_date_from = django_filters.DateFilter(field_name="po_date", lookup_expr="gte")
    po_date_to = django_filters.DateFilter(field_name="po_date", lookup_expr="lte")
    total_min = django_filters.NumberFilter(field_name="total_amount", lookup_expr="gte")
    total_max = django_filters.NumberFilter(field_name="total_amount", lookup_expr="lte")
    plant = django_filters.NumberFilter()

    class Meta:
        model = PurchaseOrder
        fields = ["status", "po_type", "vendor", "plant"]


class GateEntryFilter(django_filters.FilterSet):
    entry_type = django_filters.ChoiceFilter(choices=GateEntry.EntryType.choices)
    status = django_filters.ChoiceFilter(choices=GateEntry.Status.choices)
    vendor = django_filters.NumberFilter()
    po = django_filters.NumberFilter()
    date_from = django_filters.DateFilter(field_name="entry_datetime", lookup_expr="date__gte")
    date_to = django_filters.DateFilter(field_name="entry_datetime", lookup_expr="date__lte")
    gst_copy_received = django_filters.BooleanFilter(field_name="gst_transporter_copy_received")
    plant = django_filters.NumberFilter()

    class Meta:
        model = GateEntry
        fields = ["entry_type", "status", "vendor", "po", "plant"]


class MRRFilter(django_filters.FilterSet):
    status = django_filters.ChoiceFilter(choices=MRR.Status.choices)
    mrr_type = django_filters.ChoiceFilter(choices=MRR.MRRType.choices)
    vendor = django_filters.NumberFilter()
    warehouse = django_filters.NumberFilter()
    date_from = django_filters.DateFilter(field_name="mrr_date", lookup_expr="gte")
    date_to = django_filters.DateFilter(field_name="mrr_date", lookup_expr="lte")
    plant = django_filters.NumberFilter()

    class Meta:
        model = MRR
        fields = ["status", "mrr_type", "vendor", "warehouse", "plant"]
