"""Purchase Module URL Configuration."""
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from apps.purchase.api.viewsets import (
    PurchaseRequisitionViewSet,
    PurchaseOrderViewSet,
    GateEntryViewSet,
    MRRViewSet,
    PurchaseReportsViewSet,
    VendorSaudaViewSet,
    RGPChallanViewSet,
)

app_name = "purchase"

router = DefaultRouter()
router.register(r"requisitions", PurchaseRequisitionViewSet, basename="pr")
router.register(r"orders", PurchaseOrderViewSet, basename="po")
router.register(r"gate-entries", GateEntryViewSet, basename="gate-entry")
router.register(r"mrrs", MRRViewSet, basename="mrr")
router.register(r"reports", PurchaseReportsViewSet, basename="purchase-reports")
router.register(r"sauda", VendorSaudaViewSet, basename="sauda")
router.register(r"rgp", RGPChallanViewSet, basename="rgp")

urlpatterns = [
    path("", include(router.urls)),
]
