"""
Purchase Module ViewSets.
PR, PO, Gate Entry, MRR with approval workflows, price checks, TAT reports.
"""
from django.utils import timezone
from rest_framework import viewsets, status, filters
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django_filters.rest_framework import DjangoFilterBackend

from apps.purchase.models import (
    PurchaseRequisition, PRLine,
    PurchaseOrder, POLine,
    GateEntry, GateEntryLine,
    MRR, MRRLine,
)
from apps.purchase.api.serializers import (
    PRListSerializer, PRDetailSerializer, PRSubmitSerializer, PRApproveActionSerializer,
    POListSerializer, PODetailSerializer, POApproveActionSerializer, POFromPRSerializer,
    GateEntryListSerializer, GateEntryDetailSerializer,
    MRRListSerializer, MRRDetailSerializer, CreateMRRSerializer,
)
from apps.purchase.api.filters import PRFilter, POFilter, GateEntryFilter, MRRFilter
from apps.purchase.services import (
    submit_pr, approve_pr,
    create_po_from_pr, check_po_price_increase, approve_po,
    validate_gate_entry_against_po,
    create_mrr_from_gate_entry,
    get_pr_to_po_tat, get_pending_reports,
)
from apps.masters.models import Vendor
from apps.stores.models import Warehouse


# ═══════════════════════════════════════════════════════════════════
# PURCHASE REQUISITION
# ═══════════════════════════════════════════════════════════════════

class PurchaseRequisitionViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_class = PRFilter
    search_fields = ["pr_number", "remarks"]
    ordering_fields = ["pr_date", "created_at", "priority", "status"]
    ordering = ["-pr_date"]

    def get_queryset(self):
        qs = PurchaseRequisition.objects.select_related(
            "plant", "department", "requested_by", "current_approver"
        ).prefetch_related("lines__item", "lines__uom", "approvals")
        plant = getattr(self.request, "plant", None)
        if plant:
            qs = qs.filter(plant=plant)
        return qs

    def get_serializer_class(self):
        if self.action == "list":
            return PRListSerializer
        return PRDetailSerializer

    @action(detail=True, methods=["post"])
    def submit(self, request, pk=None):
        """Submit PR for approval. Auto-populates last vendor/price/stock."""
        pr = self.get_object()
        try:
            pr = submit_pr(pr, request.user)
            return Response(PRListSerializer(pr).data)
        except ValueError as e:
            return Response({"error": str(e)}, status=400)

    @action(detail=True, methods=["post"])
    def approve(self, request, pk=None):
        """Multi-level approval: HOD(1) → Plant Head(2) → Director(3)."""
        pr = self.get_object()
        ser = PRApproveActionSerializer(data=request.data)
        ser.is_valid(raise_exception=True)

        try:
            pr = approve_pr(
                pr, request.user,
                level=ser.validated_data["level"],
                action=ser.validated_data["action"],
                remarks=ser.validated_data.get("remarks", ""),
            )
            return Response(PRListSerializer(pr).data)
        except ValueError as e:
            return Response({"error": str(e)}, status=400)

    @action(detail=False, methods=["get"])
    def pending_approval(self, request):
        """PRs waiting for my approval."""
        qs = self.get_queryset().filter(
            status__in=["SUBMITTED", "HOD_APPROVED", "PLANT_HEAD_APPROVED"]
        )
        page = self.paginate_queryset(qs)
        return self.get_paginated_response(PRListSerializer(page, many=True).data)

    @action(detail=False, methods=["get"])
    def not_approved(self, request):
        """PRs submitted but not yet approved."""
        qs = self.get_queryset().filter(status="SUBMITTED")
        serializer = PRListSerializer(qs, many=True)
        return Response(serializer.data)

    @action(detail=False, methods=["get"])
    def approved_no_po(self, request):
        """PRs approved but no PO created yet."""
        qs = self.get_queryset().filter(
            status__in=["HOD_APPROVED", "PLANT_HEAD_APPROVED", "DIRECTOR_APPROVED"],
            purchase_orders__isnull=True,
        )
        serializer = PRListSerializer(qs, many=True)
        return Response(serializer.data)


# ═══════════════════════════════════════════════════════════════════
# PURCHASE ORDER
# ═══════════════════════════════════════════════════════════════════

class PurchaseOrderViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_class = POFilter
    search_fields = ["po_number", "vendor__name", "remarks"]
    ordering_fields = ["po_date", "created_at", "total_amount", "status"]
    ordering = ["-po_date"]

    def get_queryset(self):
        qs = PurchaseOrder.objects.select_related(
            "plant", "vendor", "pr", "created_by", "approved_by"
        ).prefetch_related("lines__item", "lines__uom", "approvals")
        plant = getattr(self.request, "plant", None)
        if plant:
            qs = qs.filter(plant=plant)
        return qs

    def create(self, request, *args, **kwargs):
        """Direct PO creation is disabled. Use /create_from_pr/ or /create_from_sauda/ endpoints."""
        return Response(
            {"error": "Direct PO creation is not allowed. Use POST /create_from_pr/."},
            status=status.HTTP_405_METHOD_NOT_ALLOWED,
        )

    def perform_create(self, serializer):
        # Only called by custom @actions that bypass create()
        plant = getattr(self.request, "plant", None)
        serializer.save(created_by=self.request.user, plant=plant)

    def get_serializer_class(self):
        if self.action == "list":
            return POListSerializer
        return PODetailSerializer

    @action(detail=False, methods=["post"])
    def create_from_pr(self, request):
        """Create PO from an approved PR."""
        ser = POFromPRSerializer(data=request.data)
        ser.is_valid(raise_exception=True)

        try:
            pr = PurchaseRequisition.objects.get(pk=ser.validated_data["pr_id"])
            vendor = Vendor.objects.get(pk=ser.validated_data["vendor_id"])
            po = create_po_from_pr(pr, vendor, request.user, ser.validated_data.get("po_type", "FIXED_QTY"))
            return Response(PODetailSerializer(po).data, status=201)
        except (PurchaseRequisition.DoesNotExist, Vendor.DoesNotExist) as e:
            return Response({"error": str(e)}, status=404)
        except ValueError as e:
            return Response({"error": str(e)}, status=400)

    @action(detail=True, methods=["post"])
    def accounts_check(self, request, pk=None):
        """Accounts department check before approval."""
        po = self.get_object()
        po.accounts_checked = True
        po.accounts_checked_by = request.user
        po.accounts_checked_at = timezone.now()
        po.status = PurchaseOrder.Status.ACCOUNTS_CHECKED
        po.save(update_fields=["accounts_checked", "accounts_checked_by", "accounts_checked_at", "status"])
        return Response({"status": "accounts_checked", "po": po.po_number})

    @action(detail=True, methods=["post"])
    def approve(self, request, pk=None):
        """Approve or reject PO."""
        po = self.get_object()
        ser = POApproveActionSerializer(data=request.data)
        ser.is_valid(raise_exception=True)

        try:
            po = approve_po(po, request.user, ser.validated_data["action"], ser.validated_data.get("remarks", ""))
            return Response(POListSerializer(po).data)
        except ValueError as e:
            return Response({"error": str(e)}, status=400)

    @action(detail=True, methods=["get"])
    def price_check(self, request, pk=None):
        """Check for price increases vs. last PO."""
        po = self.get_object()
        alerts = check_po_price_increase(po)
        return Response({"alerts": alerts, "has_increases": len(alerts) > 0})

    @action(detail=True, methods=["post"])
    def recalculate(self, request, pk=None):
        """Force recalculation of PO totals."""
        po = self.get_object()
        po.recalculate_totals()
        return Response(PODetailSerializer(po).data)

    @action(detail=False, methods=["get"])
    def not_approved(self, request):
        """POs pending approval."""
        qs = self.get_queryset().filter(status__in=["DRAFT", "SUBMITTED", "ACCOUNTS_CHECKED"])
        return Response(POListSerializer(qs, many=True).data)

    @action(detail=False, methods=["get"])
    def approved_no_receipt(self, request):
        """Approved POs with no gate entry / MRR yet."""
        qs = self.get_queryset().filter(status="APPROVED", gate_entries__isnull=True)
        return Response(POListSerializer(qs, many=True).data)

    @action(detail=False, methods=["get"])
    def with_price_increase(self, request):
        """POs that have price increases vs. previous orders.

        Performance fix: batch-fetches last approved rate per (item, vendor) pair
        in two queries instead of one query per PO line.
        """
        from django.db.models import OuterRef, Subquery

        pos = list(
            self.get_queryset()
            .filter(status__in=["DRAFT", "SUBMITTED", "ACCOUNTS_CHECKED"])
            .prefetch_related("lines__item")[:50]
        )
        if not pos:
            return Response([])

        # Collect all (item_id, vendor_id) pairs across all PO lines
        po_ids = [po.pk for po in pos]
        all_lines = (
            POLine.objects
            .filter(po__in=po_ids)
            .select_related("item", "po__vendor", "po")
        )

        # For each (item, vendor) build a lookup of the last approved rate
        item_vendor_pairs = {(l.item_id, l.po.vendor_id) for l in all_lines}
        last_rate_map = {}
        for item_id, vendor_id in item_vendor_pairs:
            last_line = (
                POLine.objects
                .filter(
                    item_id=item_id,
                    po__vendor_id=vendor_id,
                    po__status__in=["APPROVED", "PARTIALLY_RECEIVED", "FULLY_RECEIVED"],
                )
                .exclude(po__in=po_ids)
                .order_by("-po__po_date")
                .select_related("po")
                .first()
            )
            if last_line:
                last_rate_map[(item_id, vendor_id)] = last_line

        # Build results using the pre-fetched data
        results = []
        for po in pos:
            alerts = []
            for line in po.lines.all():
                key = (line.item_id, po.vendor_id)
                last_line = last_rate_map.get(key)
                if last_line and line.rate > last_line.rate:
                    increase_pct = (line.rate - last_line.rate) / last_line.rate * 100
                    alerts.append({
                        "item_code": line.item.code,
                        "item_name": line.item.name,
                        "current_rate": float(line.rate),
                        "last_rate": float(last_line.rate),
                        "increase_pct": round(float(increase_pct), 2),
                        "last_po": last_line.po.po_number,
                        "last_po_date": str(last_line.po.po_date),
                    })
            if alerts:
                results.append({
                    "po_number": po.po_number,
                    "vendor": po.vendor.name,
                    "alerts": alerts,
                })
        return Response(results)


# ═══════════════════════════════════════════════════════════════════
# GATE ENTRY
# ═══════════════════════════════════════════════════════════════════

class GateEntryViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_class = GateEntryFilter
    search_fields = ["gate_entry_number", "vehicle_number", "lr_number", "bill_number"]
    ordering_fields = ["entry_datetime", "created_at"]
    ordering = ["-entry_datetime"]

    def get_queryset(self):
        qs = GateEntry.objects.select_related(
            "plant", "vendor", "po", "customer", "created_by"
        ).prefetch_related("lines__item", "lines__po_line")
        plant = getattr(self.request, "plant", None)
        if plant:
            qs = qs.filter(plant=plant)
        return qs

    def get_serializer_class(self):
        if self.action == "list":
            return GateEntryListSerializer
        return GateEntryDetailSerializer

    @action(detail=True, methods=["get"])
    def validate(self, request, pk=None):
        """Validate gate entry against PO (tolerance, qty checks)."""
        ge = self.get_object()
        errors = validate_gate_entry_against_po(ge)
        return Response({
            "valid": len(errors) == 0,
            "errors": errors,
        })

    @action(detail=False, methods=["get"])
    def pending_mrr(self, request):
        """Gate entries pending MRR creation."""
        qs = self.get_queryset().filter(status="PENDING")
        return Response(GateEntryListSerializer(qs, many=True).data)

    @action(detail=False, methods=["get"])
    def gst_copy_pending(self, request):
        """Gate entries where GST transporter copy not received."""
        qs = self.get_queryset().filter(
            gst_transporter_copy_received=False,
            entry_type="AGAINST_PO",
        )
        return Response(GateEntryListSerializer(qs, many=True).data)


# ═══════════════════════════════════════════════════════════════════
# MRR
# ═══════════════════════════════════════════════════════════════════

class MRRViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_class = MRRFilter
    search_fields = ["mrr_number"]
    ordering_fields = ["mrr_date", "created_at"]
    ordering = ["-mrr_date"]

    def get_queryset(self):
        qs = MRR.objects.select_related(
            "plant", "gate_entry", "po", "vendor", "warehouse", "created_by"
        ).prefetch_related(
            "lines__item", "lines__uom", "lines__inventory_lot",
            "lines__item__item_group", "vendor__vendor_group",
        )
        plant = getattr(self.request, "plant", None)
        if plant:
            qs = qs.filter(plant=plant)
        return qs

    def get_serializer_class(self):
        if self.action == "list":
            return MRRListSerializer
        return MRRDetailSerializer

    @action(detail=False, methods=["post"])
    def create_from_gate_entry(self, request):
        """Create MRR from a gate entry. Generates inventory lots + QR codes."""
        ser = CreateMRRSerializer(data=request.data)
        ser.is_valid(raise_exception=True)

        try:
            ge = GateEntry.objects.get(pk=ser.validated_data["gate_entry_id"])
            wh = Warehouse.objects.get(pk=ser.validated_data["warehouse_id"])
            mrr = create_mrr_from_gate_entry(ge, wh, request.user)
            return Response(MRRDetailSerializer(mrr).data, status=201)
        except GateEntry.DoesNotExist:
            return Response({"error": "Gate entry not found."}, status=404)
        except Warehouse.DoesNotExist:
            return Response({"error": "Warehouse not found."}, status=404)
        except ValueError as e:
            return Response({"error": str(e)}, status=400)

    @action(detail=True, methods=["get"])
    def qr_labels(self, request, pk=None):
        """Get QR code labels data for printing."""
        mrr = self.get_object()
        labels = []
        for line in mrr.lines.all():
            if line.qr_code_data:
                from apps.purchase.services import generate_qr_image_base64
                labels.append({
                    "line_number": line.line_number,
                    "item_code": line.item.code,
                    "item_name": line.item.name,
                    "lot_number": line.lot_number,
                    "roll_number": line.roll_number,
                    "quantity": str(line.quantity),
                    "qr_data": line.qr_code_data,
                    "qr_image_base64": generate_qr_image_base64(line.qr_code_data),
                })
        return Response({"mrr_number": mrr.mrr_number, "labels": labels})

    @action(detail=False, methods=["get"])
    def qc_pending(self, request):
        """MRRs with QC still pending."""
        qs = self.get_queryset().filter(status="QC_PENDING")
        return Response(MRRListSerializer(qs, many=True).data)

    @action(detail=True, methods=["post"])
    def mark_qr_printed(self, request, pk=None):
        """Mark QR labels as printed for an MRR."""
        mrr = self.get_object()
        mrr.lines.all().update(qr_printed=True)
        return Response({"status": "marked_printed", "mrr": mrr.mrr_number})


# ═══════════════════════════════════════════════════════════════════
# PURCHASE REPORTS
# ═══════════════════════════════════════════════════════════════════

class PurchaseReportsViewSet(viewsets.ViewSet):
    """Aggregate purchase reports and dashboards."""
    permission_classes = [IsAuthenticated]

    @action(detail=False, methods=["get"])
    def pipeline_summary(self, request):
        """Summary of pending items across the purchase pipeline."""
        plant_id = request.query_params.get("plant")
        plant = None
        if plant_id:
            from apps.core.models import Plant
            plant = Plant.objects.filter(pk=plant_id).first()
        elif getattr(self.request, "plant", None):
            plant = self.request.plant

        return Response(get_pending_reports(plant))

    @action(detail=False, methods=["get"])
    def tat_pr_to_po(self, request):
        """Turn-around time: PR submission → PO creation."""
        plant = request.plant
        data = get_pr_to_po_tat(plant)
        return Response(data)

    @action(detail=False, methods=["get"])
    def po_qty_vs_pr(self, request):
        """POs where quantity differs from PR (over or under)."""
        results = []
        po_lines = POLine.objects.filter(
            pr_line__isnull=False,
        ).select_related("po", "item", "pr_line")[:200]

        for pol in po_lines:
            pr_qty = pol.pr_line.quantity
            po_qty = pol.quantity
            if po_qty != pr_qty:
                diff_pct = ((po_qty - pr_qty) / pr_qty * 100) if pr_qty else 0
                results.append({
                    "po_number": pol.po.po_number,
                    "item_code": pol.item.code,
                    "pr_qty": float(pr_qty),
                    "po_qty": float(po_qty),
                    "diff_pct": round(float(diff_pct), 1),
                    "direction": "OVER" if po_qty > pr_qty else "UNDER",
                })
        return Response(results)

    @action(detail=False, methods=["get"])
    def mrr_pending_for_payment(self, request):
        """MRRs completed but payment voucher not yet created."""
        mrrs = MRR.objects.filter(
            status__in=["QC_PASSED", "COMPLETED"],
        ).select_related("vendor", "po")[:100]

        data = []
        for mrr in mrrs:
            data.append({
                "mrr_number": mrr.mrr_number,
                "vendor": mrr.vendor.name if mrr.vendor else "",
                "mrr_date": str(mrr.mrr_date),
                "po_number": mrr.po.po_number if mrr.po else "",
            })
        return Response(data)


# ═══════════════════════════════════════════════════════════════════
# VENDOR SAUDA VIEWSET
# ═══════════════════════════════════════════════════════════════════

class VendorSaudaViewSet(viewsets.ModelViewSet):
    """Bulk purchase agreement management."""
    permission_classes = [IsAuthenticated]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ["vendor", "item", "status"]
    search_fields = ["sauda_number", "vendor__name", "item__code"]
    ordering_fields = ["valid_from", "valid_to", "created_at"]
    ordering = ["-created_at"]

    def get_queryset(self):
        from apps.purchase.models import VendorSauda
        qs = VendorSauda.objects.select_related("vendor", "item", "uom", "plant")
        if hasattr(self.request, "plant"):
            qs = qs.filter(plant=self.request.plant)
        return qs

    def get_serializer_class(self):
        from apps.purchase.api.serializers import VendorSaudaSerializer
        return VendorSaudaSerializer

    def perform_create(self, serializer):
        plant = getattr(self.request, "plant", None)
        serializer.save(created_by=self.request.user, plant=plant)

    @action(detail=True, methods=["get"])
    def po_history(self, request, pk=None):
        """All POs drawn against this sauda."""
        sauda = self.get_object()
        links = sauda.po_links.select_related(
            "po_line__po", "po_line__item"
        ).order_by("-linked_at")
        data = [
            {
                "po_number": link.po_line.po.po_number,
                "po_date": str(link.po_line.po.po_date),
                "item_code": link.po_line.item.code,
                "qty": float(link.qty),
                "po_status": link.po_line.po.status,
            }
            for link in links
        ]
        return Response(data)

    @action(detail=True, methods=["get"])
    def pending_report(self, request, pk=None):
        """Balance qty/value, % utilized."""
        sauda = self.get_object()
        return Response({
            "sauda_number": sauda.sauda_number,
            "agreed_qty": float(sauda.agreed_qty),
            "ordered_qty": float(sauda.ordered_qty),
            "received_qty": float(sauda.received_qty),
            "balance_qty": float(sauda.balance_qty),
            "balance_value": float(sauda.balance_value),
            "utilization_pct": sauda.utilization_pct,
            "status": sauda.status,
            "valid_to": str(sauda.valid_to),
        })


# ═══════════════════════════════════════════════════════════════════
# RGP CHALLAN VIEWSET
# ═══════════════════════════════════════════════════════════════════

class RGPChallanViewSet(viewsets.ModelViewSet):
    """Returnable Gate Pass management for job worker repairs."""
    permission_classes = [IsAuthenticated]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ["vendor", "status"]
    search_fields = ["rgp_number", "vendor__name"]
    ordering = ["-challan_date"]

    def get_queryset(self):
        from apps.purchase.models import RGPChallan
        qs = RGPChallan.objects.prefetch_related("lines__item").select_related("vendor", "plant")
        if hasattr(self.request, "plant"):
            qs = qs.filter(plant=self.request.plant)
        return qs

    def get_serializer_class(self):
        from apps.purchase.api.serializers import RGPChallanSerializer
        return RGPChallanSerializer

    def perform_create(self, serializer):
        plant = getattr(self.request, "plant", None)
        serializer.save(created_by=self.request.user, plant=plant)

    @action(detail=True, methods=["post"])
    def send_out(self, request, pk=None):
        """Change status to SENT (assets dispatched to job worker)."""
        rgp = self.get_object()
        if rgp.status != "DRAFT":
            return Response({"error": "Can only send DRAFT RGPs"}, status=400)
        rgp.status = "SENT"
        rgp.save(update_fields=["status"])
        return Response({"status": "SENT", "message": f"RGP {rgp.rgp_number} sent to job worker"})

    @action(detail=True, methods=["post"])
    def mark_returned(self, request, pk=None):
        """Reconcile against MRR lines."""
        rgp = self.get_object()
        mrr_id = request.data.get("mrr_id")
        if not mrr_id:
            return Response({"error": "mrr_id required"}, status=400)
        from apps.purchase.services import reconcile_rgp_with_mrr
        result = reconcile_rgp_with_mrr(rgp.id, mrr_id)
        return Response(result)

    @action(detail=False, methods=["get"])
    def pending_returns(self, request):
        """All RGPs overdue for return."""
        from apps.purchase.models import RGPChallan
        from django.utils import timezone
        today = timezone.now().date()
        overdue = RGPChallan.objects.filter(
            expected_return__lt=today
        ).exclude(status="RETURNED").select_related("vendor")
        data = [
            {
                "rgp_number": r.rgp_number,
                "vendor": r.vendor.name,
                "challan_date": str(r.challan_date),
                "expected_return": str(r.expected_return),
                "days_overdue": (today - r.expected_return).days,
                "status": r.status,
            }
            for r in overdue
        ]
        return Response(data)
