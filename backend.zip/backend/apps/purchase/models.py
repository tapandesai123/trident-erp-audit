"""
Purchase Module Models:
- PurchaseRequisition (PR) + lines + approvals
- PurchaseOrder (PO) + lines + approvals + amendments
- GateEntry (material inward) + lines + photos
- MRR (Material Receipt Report) + lines → creates inventory lots
"""
from decimal import Decimal
from django.conf import settings
from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator
from apps.core.models import TimeStampedModel, UUIDModel, Plant, Department


# ═══════════════════════════════════════════════════════════════════
# PURCHASE REQUISITION (PR)
# ═══════════════════════════════════════════════════════════════════

class PurchaseRequisition(UUIDModel, TimeStampedModel):
    class Status(models.TextChoices):
        DRAFT = "DRAFT", "Draft"
        SUBMITTED = "SUBMITTED", "Submitted"
        HOD_APPROVED = "HOD_APPROVED", "HOD Approved"
        PLANT_HEAD_APPROVED = "PLANT_HEAD_APPROVED", "Plant Head Approved"
        DIRECTOR_APPROVED = "DIRECTOR_APPROVED", "Director Approved"
        REJECTED = "REJECTED", "Rejected"
        CANCELLED = "CANCELLED", "Cancelled"
        PO_CREATED = "PO_CREATED", "PO Created"

    class Priority(models.TextChoices):
        URGENT = "URGENT", "Urgent"
        HIGH = "HIGH", "High"
        NORMAL = "NORMAL", "Normal"
        LOW = "LOW", "Low"

    pr_number = models.CharField(max_length=30, unique=True, db_index=True)
    plant = models.ForeignKey(Plant, on_delete=models.CASCADE, related_name="purchase_requisitions")
    department = models.ForeignKey(Department, on_delete=models.SET_NULL, null=True, blank=True, related_name="purchase_requisitions")
    pr_date = models.DateField()
    required_date = models.DateField(null=True, blank=True)
    priority = models.CharField(max_length=20, choices=Priority.choices, default=Priority.NORMAL)
    status = models.CharField(max_length=30, choices=Status.choices, default=Status.DRAFT)
    remarks = models.TextField(blank=True)

    requested_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="requested_prs"
    )
    current_approver = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="pending_pr_approvals"
    )

    # Tracking
    submitted_at = models.DateTimeField(null=True, blank=True)
    final_approved_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-pr_date", "-created_at"]
        indexes = [
            models.Index(fields=["status"]),
            models.Index(fields=["pr_date"]),
            models.Index(fields=["requested_by"]),
        ]

    def __str__(self):
        return f"{self.pr_number} ({self.get_status_display()})"

    @property
    def total_estimated_value(self):
        return sum(
            (line.estimated_rate or 0) * line.quantity
            for line in self.lines.all()
        )

    @property
    def is_fully_approved(self):
        return self.status in (
            self.Status.HOD_APPROVED,
            self.Status.PLANT_HEAD_APPROVED,
            self.Status.DIRECTOR_APPROVED,
        )

    @property
    def line_count(self):
        return self.lines.count()


class PRLine(models.Model):
    pr = models.ForeignKey(PurchaseRequisition, on_delete=models.CASCADE, related_name="lines")
    line_number = models.IntegerField()
    item = models.ForeignKey("masters.Item", on_delete=models.PROTECT, related_name="pr_lines")
    quantity = models.DecimalField(max_digits=15, decimal_places=3, validators=[MinValueValidator(Decimal("0.001"))])
    uom = models.ForeignKey("masters.UOM", on_delete=models.PROTECT)
    estimated_rate = models.DecimalField(max_digits=15, decimal_places=4, null=True, blank=True)

    # Auto-populated from last PO
    last_vendor = models.ForeignKey(
        "masters.Vendor", on_delete=models.SET_NULL, null=True, blank=True,
        help_text="Auto-populated: last vendor for this item"
    )
    last_rate = models.DecimalField(max_digits=15, decimal_places=4, null=True, blank=True)
    last_po_date = models.DateField(null=True, blank=True)

    # Auto-populated from stock
    current_stock = models.DecimalField(max_digits=15, decimal_places=3, null=True, blank=True)
    min_stock = models.DecimalField(max_digits=15, decimal_places=3, null=True, blank=True)

    remarks = models.TextField(blank=True)

    class Meta:
        unique_together = ["pr", "line_number"]
        ordering = ["line_number"]

    def __str__(self):
        return f"PR {self.pr.pr_number} L{self.line_number}: {self.item.code}"


class PRApproval(models.Model):
    """Approval history for PR — multi-level: HOD → Plant Head → Director."""
    class Action(models.TextChoices):
        APPROVED = "APPROVED", "Approved"
        REJECTED = "REJECTED", "Rejected"
        RETURNED = "RETURNED", "Returned for Revision"

    pr = models.ForeignKey(PurchaseRequisition, on_delete=models.CASCADE, related_name="approvals")
    approver = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="pr_approval_actions")
    action = models.CharField(max_length=20, choices=Action.choices)
    level = models.IntegerField(help_text="1=HOD, 2=Plant Head, 3=Director")
    remarks = models.TextField(blank=True)
    acted_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["acted_at"]

    def __str__(self):
        return f"PR {self.pr.pr_number} L{self.level}: {self.action} by {self.approver}"


# ═══════════════════════════════════════════════════════════════════
# PURCHASE ORDER (PO)
# ═══════════════════════════════════════════════════════════════════

class PurchaseOrder(UUIDModel, TimeStampedModel):
    class POType(models.TextChoices):
        FIXED_QTY = "FIXED_QTY", "Fixed Quantity"
        JOB_WORK = "JOB_WORK", "Job Work"
        SERVICE = "SERVICE", "Service"
        CAPITAL_GOODS = "CAPITAL_GOODS", "Capital Goods"
        IMPORT = "IMPORT", "Import"

    class Status(models.TextChoices):
        DRAFT = "DRAFT", "Draft"
        SUBMITTED = "SUBMITTED", "Submitted"
        ACCOUNTS_CHECKED = "ACCOUNTS_CHECKED", "Accounts Checked"
        APPROVED = "APPROVED", "Approved"
        PARTIALLY_RECEIVED = "PARTIALLY_RECEIVED", "Partially Received"
        FULLY_RECEIVED = "FULLY_RECEIVED", "Fully Received"
        CANCELLED = "CANCELLED", "Cancelled"
        AMENDED = "AMENDED", "Amended"
        CLOSED = "CLOSED", "Closed"

    po_number = models.CharField(max_length=30, unique=True, db_index=True)
    plant = models.ForeignKey(Plant, on_delete=models.CASCADE, related_name="purchase_orders")
    vendor = models.ForeignKey("masters.Vendor", on_delete=models.PROTECT, related_name="purchase_orders")
    po_date = models.DateField()
    po_type = models.CharField(max_length=30, choices=POType.choices, default=POType.FIXED_QTY)
    delivery_date = models.DateField(null=True, blank=True)
    payment_terms = models.TextField(blank=True)
    freight_terms = models.CharField(max_length=100, blank=True)
    status = models.CharField(max_length=30, choices=Status.choices, default=Status.DRAFT)
    tolerance_pct = models.DecimalField(
        max_digits=5, decimal_places=2, default=Decimal("10.00"),
        help_text="Allowed +/- % on quantity"
    )

    # Totals (auto-calculated)
    subtotal = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    gst_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    tcs_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    total_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    currency = models.CharField(max_length=3, default="INR")

    # Accounts verification
    accounts_checked = models.BooleanField(default=False)
    accounts_checked_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="po_accounts_checks"
    )
    accounts_checked_at = models.DateTimeField(null=True, blank=True)

    # Approval
    current_approver = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="pending_po_approvals"
    )
    approved_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="approved_pos"
    )
    approved_at = models.DateTimeField(null=True, blank=True)

    # Linked PR
    pr = models.ForeignKey(
        PurchaseRequisition, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="purchase_orders"
    )

    # Amendment tracking
    amendment_number = models.IntegerField(default=0)
    amended_from = models.ForeignKey(
        "self", on_delete=models.SET_NULL, null=True, blank=True, related_name="amendments"
    )

    remarks = models.TextField(blank=True)
    terms_conditions = models.TextField(blank=True)

    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="created_pos"
    )
    updated_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="updated_pos"
    )

    class Meta:
        ordering = ["-po_date", "-created_at"]
        indexes = [
            models.Index(fields=["status"]),
            models.Index(fields=["vendor"]),
            models.Index(fields=["po_date"]),
        ]

    def __str__(self):
        return f"{self.po_number} → {self.vendor.code} ({self.get_status_display()})"

    def recalculate_totals(self):
        """Recalculate PO totals from line items."""
        subtotal = Decimal("0")
        gst_total = Decimal("0")
        for line in self.lines.all():
            line_amount = line.quantity * line.rate * (1 - line.discount_pct / 100)
            line_gst = line_amount * (line.gst_rate or 0) / 100
            subtotal += line_amount
            gst_total += line_gst
            line.amount = line_amount
            line.gst_amount = line_gst
            line.total_amount = line_amount + line_gst
            line.save(update_fields=["amount", "gst_amount", "total_amount"])

        tcs = Decimal("0")
        if self.vendor.tcs_applicable and self.vendor.tcs_rate:
            tcs = subtotal * self.vendor.tcs_rate / 100

        self.subtotal = subtotal
        self.gst_amount = gst_total
        self.tcs_amount = tcs
        self.total_amount = subtotal + gst_total + tcs
        self.save(update_fields=["subtotal", "gst_amount", "tcs_amount", "total_amount"])

    @property
    def is_fully_received(self):
        return all(line.pending_qty <= 0 for line in self.lines.all())

    @property
    def receipt_percentage(self):
        total_qty = sum(l.quantity for l in self.lines.all()) or 1
        received = sum(l.received_qty for l in self.lines.all())
        return round(float(received / total_qty * 100), 1)


class POLine(models.Model):
    po = models.ForeignKey(PurchaseOrder, on_delete=models.CASCADE, related_name="lines")
    line_number = models.IntegerField()
    item = models.ForeignKey("masters.Item", on_delete=models.PROTECT, related_name="po_lines")
    pr_line = models.ForeignKey(PRLine, on_delete=models.SET_NULL, null=True, blank=True, related_name="po_lines")
    quantity = models.DecimalField(max_digits=15, decimal_places=3, validators=[MinValueValidator(Decimal("0.001"))])
    received_qty = models.DecimalField(max_digits=15, decimal_places=3, default=0)
    rate = models.DecimalField(max_digits=15, decimal_places=4, validators=[MinValueValidator(Decimal("0.0001"))])
    discount_pct = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    gst_rate = models.DecimalField(max_digits=5, decimal_places=2, null=True, blank=True)
    amount = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    gst_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    total_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    delivery_date = models.DateField(null=True, blank=True)
    uom = models.ForeignKey("masters.UOM", on_delete=models.PROTECT, null=True, blank=True)
    remarks = models.TextField(blank=True)

    class Meta:
        unique_together = ["po", "line_number"]
        ordering = ["line_number"]

    def __str__(self):
        return f"PO {self.po.po_number} L{self.line_number}: {self.item.code} x{self.quantity}"

    @property
    def pending_qty(self):
        return self.quantity - self.received_qty

    @property
    def tolerance_max_qty(self):
        """Max receivable quantity including tolerance."""
        return self.quantity * (1 + self.po.tolerance_pct / 100)


class POApproval(models.Model):
    class Action(models.TextChoices):
        APPROVED = "APPROVED", "Approved"
        REJECTED = "REJECTED", "Rejected"
        RETURNED = "RETURNED", "Returned"

    po = models.ForeignKey(PurchaseOrder, on_delete=models.CASCADE, related_name="approvals")
    approver = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    action = models.CharField(max_length=20, choices=Action.choices)
    level = models.IntegerField(help_text="1=Accounts, 2=HOD, 3=Plant Head, 4=Director")
    remarks = models.TextField(blank=True)
    acted_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["acted_at"]


# ═══════════════════════════════════════════════════════════════════
# GATE ENTRY (Material Inward)
# ═══════════════════════════════════════════════════════════════════

class GateEntry(UUIDModel, TimeStampedModel):
    class EntryType(models.TextChoices):
        AGAINST_PO = "AGAINST_PO", "Against PO"
        CUSTOMER_JOB_WORK = "CUSTOMER_JOB_WORK", "Customer Job Work"
        FROM_JOB_WORKER = "FROM_JOB_WORKER", "From Job Worker"
        RETURNABLE = "RETURNABLE", "Returnable Gate Pass"
        NON_RETURNABLE = "NON_RETURNABLE", "Non-Returnable"

    class Status(models.TextChoices):
        PENDING = "PENDING", "Pending MRR"
        MRR_CREATED = "MRR_CREATED", "MRR Created"
        REJECTED = "REJECTED", "Rejected"

    gate_entry_number = models.CharField(max_length=30, unique=True, db_index=True)
    plant = models.ForeignKey(Plant, on_delete=models.CASCADE, related_name="gate_entries")
    entry_type = models.CharField(max_length=30, choices=EntryType.choices, default=EntryType.AGAINST_PO)
    vendor = models.ForeignKey("masters.Vendor", on_delete=models.SET_NULL, null=True, blank=True, related_name="gate_entries")
    po = models.ForeignKey(PurchaseOrder, on_delete=models.SET_NULL, null=True, blank=True, related_name="gate_entries")
    customer = models.ForeignKey("masters.Customer", on_delete=models.SET_NULL, null=True, blank=True, related_name="job_work_entries")

    # Transport details
    vehicle_number = models.CharField(max_length=20, blank=True)
    transporter_name = models.CharField(max_length=200, blank=True)
    lr_number = models.CharField(max_length=50, blank=True, help_text="Lorry Receipt number")
    lr_date = models.DateField(null=True, blank=True)
    driver_name = models.CharField(max_length=100, blank=True)
    driver_phone = models.CharField(max_length=20, blank=True)

    entry_datetime = models.DateTimeField()

    # Bill/Challan
    bill_number = models.CharField(max_length=50, blank=True)
    bill_date = models.DateField(null=True, blank=True)
    challan_number = models.CharField(max_length=50, blank=True)
    challan_date = models.DateField(null=True, blank=True)

    # Photos (URLs to S3/MinIO)
    bill_photo = models.ImageField(upload_to="gate_entry/bills/%Y/%m/", blank=True, null=True)
    shipment_photo = models.ImageField(upload_to="gate_entry/shipments/%Y/%m/", blank=True, null=True)
    truck_photo = models.ImageField(upload_to="gate_entry/trucks/%Y/%m/", blank=True, null=True)

    # GST transporter copy tracking
    gst_transporter_copy_received = models.BooleanField(default=False)

    status = models.CharField(max_length=20, choices=Status.choices, default=Status.PENDING)
    remarks = models.TextField(blank=True)

    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="created_gate_entries"
    )

    class Meta:
        ordering = ["-entry_datetime"]
        verbose_name_plural = "gate entries"
        indexes = [
            models.Index(fields=["status"]),
            models.Index(fields=["entry_datetime"]),
            models.Index(fields=["po"]),
        ]

    def __str__(self):
        return f"{self.gate_entry_number} ({self.get_entry_type_display()})"


class GateEntryLine(models.Model):
    gate_entry = models.ForeignKey(GateEntry, on_delete=models.CASCADE, related_name="lines")
    line_number = models.IntegerField()
    item = models.ForeignKey("masters.Item", on_delete=models.PROTECT, related_name="gate_entry_lines")
    po_line = models.ForeignKey(POLine, on_delete=models.SET_NULL, null=True, blank=True, related_name="gate_entry_lines")
    quantity = models.DecimalField(max_digits=15, decimal_places=3, validators=[MinValueValidator(Decimal("0.001"))])
    uom = models.ForeignKey("masters.UOM", on_delete=models.PROTECT)

    # Paper roll specifics
    roll_number = models.CharField(max_length=50, blank=True)
    gross_weight_kg = models.DecimalField(max_digits=10, decimal_places=3, null=True, blank=True)
    net_weight_kg = models.DecimalField(max_digits=10, decimal_places=3, null=True, blank=True)
    deckle_mm = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)

    remarks = models.TextField(blank=True)

    class Meta:
        unique_together = ["gate_entry", "line_number"]
        ordering = ["line_number"]

    def __str__(self):
        return f"GE {self.gate_entry.gate_entry_number} L{self.line_number}: {self.item.code}"


# ═══════════════════════════════════════════════════════════════════
# MATERIAL RECEIPT REPORT (MRR)
# ═══════════════════════════════════════════════════════════════════

class MRR(UUIDModel, TimeStampedModel):
    class MRRType(models.TextChoices):
        FIXED_PO = "FIXED_PO", "Against Fixed PO"
        CUSTOMER_JOB_WORK = "CUSTOMER_JOB_WORK", "Customer Job Work"
        JOB_WORKER_RETURN = "JOB_WORKER_RETURN", "Job Worker Return"

    class Status(models.TextChoices):
        DRAFT = "DRAFT", "Draft"
        QC_PENDING = "QC_PENDING", "QC Pending"
        QC_PASSED = "QC_PASSED", "QC Passed"
        QC_REJECTED = "QC_REJECTED", "QC Rejected"
        COMPLETED = "COMPLETED", "Completed"

    mrr_number = models.CharField(max_length=30, unique=True, db_index=True)
    plant = models.ForeignKey(Plant, on_delete=models.CASCADE, related_name="mrrs")
    gate_entry = models.ForeignKey(GateEntry, on_delete=models.CASCADE, related_name="mrrs")
    po = models.ForeignKey(PurchaseOrder, on_delete=models.SET_NULL, null=True, blank=True, related_name="mrrs")
    vendor = models.ForeignKey("masters.Vendor", on_delete=models.SET_NULL, null=True, blank=True, related_name="mrrs")
    mrr_date = models.DateField()
    mrr_type = models.CharField(max_length=30, choices=MRRType.choices, default=MRRType.FIXED_PO)
    warehouse = models.ForeignKey("stores.Warehouse", on_delete=models.PROTECT, related_name="mrrs")

    status = models.CharField(max_length=20, choices=Status.choices, default=Status.DRAFT)
    remarks = models.TextField(blank=True)
    rgp_reference = models.ForeignKey(
        "RGPChallan", on_delete=models.SET_NULL, null=True, blank=True,
        related_name="return_mrrs", help_text="Set when MRR is a return against an RGP challan"
    )

    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="created_mrrs"
    )

    class Meta:
        ordering = ["-mrr_date", "-created_at"]
        verbose_name = "MRR"
        verbose_name_plural = "MRRs"
        indexes = [
            models.Index(fields=["status"]),
            models.Index(fields=["mrr_date"]),
        ]

    def __str__(self):
        return f"{self.mrr_number} ({self.get_status_display()})"


class MRRLine(models.Model):
    mrr = models.ForeignKey(MRR, on_delete=models.CASCADE, related_name="lines")
    line_number = models.IntegerField()
    item = models.ForeignKey("masters.Item", on_delete=models.PROTECT, related_name="mrr_lines")
    gate_entry_line = models.ForeignKey(GateEntryLine, on_delete=models.SET_NULL, null=True, blank=True)
    po_line = models.ForeignKey(POLine, on_delete=models.SET_NULL, null=True, blank=True, related_name="mrr_lines")
    quantity = models.DecimalField(max_digits=15, decimal_places=3)
    accepted_qty = models.DecimalField(max_digits=15, decimal_places=3, null=True, blank=True)
    rejected_qty = models.DecimalField(max_digits=15, decimal_places=3, default=0)
    uom = models.ForeignKey("masters.UOM", on_delete=models.PROTECT)
    rate = models.DecimalField(max_digits=15, decimal_places=4, null=True, blank=True)
    bin_location = models.ForeignKey("stores.BinLocation", on_delete=models.SET_NULL, null=True, blank=True)

    # Per roll/lot
    lot_number = models.CharField(max_length=50, blank=True)
    roll_number = models.CharField(max_length=50, blank=True)
    gross_weight_kg = models.DecimalField(max_digits=10, decimal_places=3, null=True, blank=True)
    net_weight_kg = models.DecimalField(max_digits=10, decimal_places=3, null=True, blank=True)

    # QR code
    qr_code_data = models.TextField(blank=True)
    qr_printed = models.BooleanField(default=False)

    # QC
    qc_status = models.CharField(max_length=20, default="PENDING",
                                  choices=[("PENDING", "Pending"), ("PASSED", "Passed"),
                                           ("REJECTED", "Rejected"), ("ON_HOLD", "On Hold")])
    qc_remarks = models.TextField(blank=True)

    # Link to created inventory lot
    inventory_lot = models.ForeignKey(
        "stores.InventoryLot", on_delete=models.SET_NULL,
        null=True, blank=True, related_name="mrr_source"
    )

    remarks = models.TextField(blank=True)

    class Meta:
        unique_together = ["mrr", "line_number"]
        ordering = ["line_number"]

    def __str__(self):
        return f"MRR {self.mrr.mrr_number} L{self.line_number}: {self.item.code}"


# ═══════════════════════════════════════════════════════════════════
# VENDOR SAUDA (BULK PURCHASE AGREEMENT)
# ═══════════════════════════════════════════════════════════════════

class VendorSauda(UUIDModel, TimeStampedModel):
    """
    Bulk rate agreement with vendor (e.g., 100 tons of kraft paper at ₹42/kg).
    Daily purchase orders reduce the sauda balance.
    """
    class SaudaStatus(models.TextChoices):
        ACTIVE    = "ACTIVE",    "Active"
        EXHAUSTED = "EXHAUSTED", "Exhausted"
        EXPIRED   = "EXPIRED",   "Expired"
        CANCELLED = "CANCELLED", "Cancelled"

    plant        = models.ForeignKey("core.Plant", on_delete=models.CASCADE, related_name="vendor_saudas")
    sauda_number = models.CharField(max_length=50, unique=True)
    vendor       = models.ForeignKey("masters.Vendor", on_delete=models.PROTECT, related_name="saudas")
    item         = models.ForeignKey("masters.Item", on_delete=models.PROTECT, related_name="saudas")
    agreed_qty   = models.DecimalField(max_digits=15, decimal_places=3)
    agreed_rate  = models.DecimalField(max_digits=15, decimal_places=2)
    uom          = models.ForeignKey("masters.UOM", on_delete=models.PROTECT)
    valid_from   = models.DateField()
    valid_to     = models.DateField()
    tolerance_pct= models.DecimalField(max_digits=5, decimal_places=2, default=5)
    ordered_qty  = models.DecimalField(max_digits=15, decimal_places=3, default=0,
                                       help_text="Auto-updated when POs are created against this sauda")
    received_qty = models.DecimalField(max_digits=15, decimal_places=3, default=0,
                                       help_text="Auto-updated on MRR")
    status       = models.CharField(max_length=20, choices=SaudaStatus.choices, default=SaudaStatus.ACTIVE)
    terms        = models.TextField(blank=True)
    created_by   = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True)

    class Meta:
        ordering = ["-created_at"]
        verbose_name = "Vendor Sauda"
        verbose_name_plural = "Vendor Saudas"

    def __str__(self):
        return f"{self.sauda_number} – {self.vendor} ({self.status})"

    @property
    def balance_qty(self):
        return self.agreed_qty - self.ordered_qty

    @property
    def balance_value(self):
        return self.balance_qty * self.agreed_rate

    @property
    def utilization_pct(self):
        if self.agreed_qty:
            return round(float(self.ordered_qty / self.agreed_qty) * 100, 1)
        return 0


class SaudaPOLink(models.Model):
    """Links a PO line to a Vendor Sauda — reduces balance on PO approval."""
    sauda     = models.ForeignKey(VendorSauda, on_delete=models.CASCADE, related_name="po_links")
    po_line   = models.ForeignKey(POLine, on_delete=models.CASCADE, related_name="sauda_link")
    qty       = models.DecimalField(max_digits=15, decimal_places=3)
    linked_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = [("sauda", "po_line")]

    def __str__(self):
        return f"Sauda {self.sauda.sauda_number} → PO Line {self.po_line_id}"


# ═══════════════════════════════════════════════════════════════════
# JOB WORKER RGP SYSTEM (RETURNABLE GATE PASS)
# ═══════════════════════════════════════════════════════════════════

class RGPChallan(UUIDModel, TimeStampedModel):
    """
    Returnable Gate Pass — asset/equipment sent to job worker for repair.
    Returned via MRR (linked rgp_reference on MRR model).
    """
    class RGPStatus(models.TextChoices):
        DRAFT    = "DRAFT",    "Draft"
        SENT     = "SENT",     "Sent to Job Worker"
        PARTIAL  = "PARTIAL",  "Partially Returned"
        RETURNED = "RETURNED", "Fully Returned"
        OVERDUE  = "OVERDUE",  "Overdue"

    plant             = models.ForeignKey("core.Plant", on_delete=models.CASCADE, related_name="rgp_challans")
    rgp_number        = models.CharField(max_length=50, unique=True)
    vendor            = models.ForeignKey("masters.Vendor", on_delete=models.PROTECT,
                                          related_name="rgp_challans",
                                          help_text="Job worker / repair vendor")
    challan_date      = models.DateField()
    expected_return   = models.DateField()
    status            = models.CharField(max_length=20, choices=RGPStatus.choices, default=RGPStatus.DRAFT)
    job_work_po       = models.ForeignKey("PurchaseOrder", on_delete=models.SET_NULL,
                                          null=True, blank=True, related_name="rgp_challans",
                                          help_text="Optional job-work PO for this repair")
    transport_details = models.CharField(max_length=300, blank=True)
    remarks           = models.TextField(blank=True)
    created_by        = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True)

    class Meta:
        ordering = ["-challan_date", "-created_at"]
        verbose_name = "RGP Challan"
        verbose_name_plural = "RGP Challans"

    def __str__(self):
        return f"{self.rgp_number} – {self.vendor} ({self.status})"

    @property
    def is_overdue(self):
        from django.utils import timezone
        return (self.expected_return < timezone.now().date()
                and self.status not in (self.RGPStatus.RETURNED,))


class RGPLine(models.Model):
    rgp          = models.ForeignKey(RGPChallan, on_delete=models.CASCADE, related_name="lines")
    item         = models.ForeignKey("masters.Item", on_delete=models.PROTECT)
    asset_tag    = models.CharField(max_length=100, blank=True,
                                    help_text="Asset/equipment tag or serial number")
    sent_qty     = models.DecimalField(max_digits=15, decimal_places=3)
    returned_qty = models.DecimalField(max_digits=15, decimal_places=3, default=0)
    uom          = models.ForeignKey("masters.UOM", on_delete=models.PROTECT)
    description  = models.TextField(blank=True, help_text="Nature of repair")

    class Meta:
        ordering = ["id"]

    def __str__(self):
        return f"RGP {self.rgp.rgp_number} – {self.item.code}"

    @property
    def pending_qty(self):
        return self.sent_qty - self.returned_qty


# Add rgp_reference to MRR — done via monkey-patch / migration field addition
# (actual field added below via migration; here we note the FK)
