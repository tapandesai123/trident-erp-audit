"""Django Admin for Purchase module."""
from django.contrib import admin
from apps.purchase.models import (
    PurchaseRequisition, PRLine, PRApproval,
    PurchaseOrder, POLine, POApproval,
    GateEntry, GateEntryLine,
    MRR, MRRLine,
)


class PRLineInline(admin.TabularInline):
    model = PRLine
    extra = 0
    raw_id_fields = ["item", "uom", "last_vendor"]
    readonly_fields = ["last_rate", "last_po_date", "current_stock", "min_stock"]


class PRApprovalInline(admin.TabularInline):
    model = PRApproval
    extra = 0
    readonly_fields = ["approver", "action", "level", "remarks", "acted_at"]


@admin.register(PurchaseRequisition)
class PRAdmin(admin.ModelAdmin):
    list_display = ["pr_number", "plant", "pr_date", "priority", "status", "requested_by", "created_at"]
    list_filter = ["status", "priority", "plant", "department"]
    search_fields = ["pr_number"]
    readonly_fields = ["uuid", "pr_number", "created_at", "updated_at"]
    inlines = [PRLineInline, PRApprovalInline]
    date_hierarchy = "pr_date"


class POLineInline(admin.TabularInline):
    model = POLine
    extra = 0
    raw_id_fields = ["item", "uom"]
    readonly_fields = ["received_qty", "amount", "gst_amount", "total_amount"]


class POApprovalInline(admin.TabularInline):
    model = POApproval
    extra = 0
    readonly_fields = ["approver", "action", "level", "remarks", "acted_at"]


@admin.register(PurchaseOrder)
class POAdmin(admin.ModelAdmin):
    list_display = [
        "po_number", "vendor", "po_date", "po_type", "status",
        "total_amount", "approved_by", "created_at",
    ]
    list_filter = ["status", "po_type", "plant"]
    search_fields = ["po_number", "vendor__name"]
    readonly_fields = [
        "uuid", "po_number", "subtotal", "gst_amount", "tcs_amount",
        "total_amount", "created_at", "updated_at",
    ]
    inlines = [POLineInline, POApprovalInline]
    raw_id_fields = ["vendor", "pr"]
    date_hierarchy = "po_date"


class GateEntryLineInline(admin.TabularInline):
    model = GateEntryLine
    extra = 0
    raw_id_fields = ["item", "uom", "po_line"]


@admin.register(GateEntry)
class GateEntryAdmin(admin.ModelAdmin):
    list_display = [
        "gate_entry_number", "entry_type", "vendor", "po",
        "vehicle_number", "entry_datetime", "status",
        "gst_transporter_copy_received",
    ]
    list_filter = ["entry_type", "status", "gst_transporter_copy_received", "plant"]
    search_fields = ["gate_entry_number", "vehicle_number", "lr_number"]
    readonly_fields = ["uuid", "gate_entry_number", "created_at", "updated_at"]
    inlines = [GateEntryLineInline]
    raw_id_fields = ["vendor", "po", "customer"]


class MRRLineInline(admin.TabularInline):
    model = MRRLine
    extra = 0
    raw_id_fields = ["item", "uom", "bin_location", "inventory_lot"]
    readonly_fields = ["qr_code_data"]


@admin.register(MRR)
class MRRAdmin(admin.ModelAdmin):
    list_display = [
        "mrr_number", "gate_entry", "vendor", "mrr_date",
        "mrr_type", "warehouse", "status",
    ]
    list_filter = ["status", "mrr_type", "warehouse", "plant"]
    search_fields = ["mrr_number"]
    readonly_fields = ["uuid", "mrr_number", "created_at", "updated_at"]
    inlines = [MRRLineInline]
    raw_id_fields = ["gate_entry", "po", "vendor", "warehouse"]
    date_hierarchy = "mrr_date"
