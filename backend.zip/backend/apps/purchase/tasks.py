"""Purchase Module Celery Tasks."""
from celery import shared_task
from django.utils import timezone
from datetime import timedelta
from django.db.models import Sum, Count, Q
import logging

logger = logging.getLogger(__name__)


@shared_task(name="purchase.check_po_delivery_dates")
def check_po_delivery_dates():
    """
    Daily: Find POs past delivery_date that aren't fully received.
    Notify purchase HOD about delayed deliveries.
    """
    from apps.purchase.models import PurchaseOrder
    from apps.core.models import Notification, User
    
    today = timezone.now().date()
    
    # Find POs that are:
    # - Status is APPROVED or PARTIALLY_RECEIVED
    # - delivery_date has passed
    # - Not fully received
    overdue_pos = PurchaseOrder.objects.filter(
        Q(status=PurchaseOrder.Status.APPROVED) | Q(status=PurchaseOrder.Status.PARTIALLY_RECEIVED),
        delivery_date__lt=today
    ).select_related('vendor', 'plant', 'created_by')
    
    if not overdue_pos.exists():
        return "No overdue POs found."
    
    # Get purchase HOD (assuming role name is 'Purchase Manager' or 'Purchase HOD')
    # Try to find users with purchase-related roles
    try:
        from apps.core.models import Role
        purchase_roles_qs = Role.objects.filter(
            Q(name__icontains='Purchase') & (Q(name__icontains='Manager') | Q(name__icontains='HOD'))
        )

        if purchase_roles_qs.exists():
            hod_users = User.objects.filter(
                roles__in=purchase_roles_qs, is_active=True
            ).distinct()
        else:
            # Fallback to superadmins
            hod_users = User.objects.filter(is_superadmin=True, is_active=True)
    except Exception as e:
        logger.warning("Failed to resolve purchase HOD users: %s", e)
        hod_users = User.objects.filter(is_superadmin=True, is_active=True)
    
    # Create notifications
    count = 0
    for po in overdue_pos[:50]:  # Limit to 50 POs per run
        days_overdue = (today - po.delivery_date).days
        
        for user in hod_users:
            Notification.objects.create(
                user=user,
                title=f"Overdue PO: {po.po_number}",
                message=f"PO {po.po_number} from {po.vendor.name} is overdue by {days_overdue} days. "
                        f"Expected delivery: {po.delivery_date}",
                notification_type="IN_APP",
                module="purchase",
                resource="PurchaseOrder",
                resource_id=po.id,
            )
            count += 1
    
    return f"Sent {count} overdue PO notifications for {overdue_pos.count()} POs."


@shared_task(name="purchase.send_pr_approval_reminders")
def send_pr_approval_reminders():
    """
    Daily: Remind approvers of pending PRs older than 2 days.
    """
    from apps.purchase.models import PurchaseRequisition
    from apps.core.models import Notification
    
    cutoff_date = timezone.now() - timedelta(days=2)
    
    # Find PRs in SUBMITTED status older than 2 days
    pending_prs = PurchaseRequisition.objects.filter(
        status=PurchaseRequisition.Status.SUBMITTED,
        created_at__lt=cutoff_date
    ).select_related('created_by', 'plant')
    
    if not pending_prs.exists():
        return "No pending PRs requiring reminders."
    
    # Get approvers (users with purchase approval permission)
    from apps.core.models import User, Permission
    
    try:
        approve_perm = Permission.objects.filter(
            module="purchase",
            action="approve",
            resource="purchase_requisition"
        ).first()
        
        if approve_perm:
            approvers = User.objects.filter(
                userrole__role__permissions__permission=approve_perm,
                userrole__role__is_active=True,
                is_active=True
            ).distinct()
        else:
            # Fallback to managers and admins
            approvers = User.objects.filter(
                Q(is_staff=True) | Q(is_superadmin=True),
                is_active=True
            )
    except Exception as e:
        logger.warning("Failed to resolve PR approvers: %s", e)
        approvers = User.objects.filter(is_superadmin=True, is_active=True)
    
    count = 0
    pr_count = pending_prs.count()
    sms_count = 0

    for approver in approvers:
        for pr in pending_prs:
            days_pending = (timezone.now().date() - pr.created_at.date()).days
            Notification.objects.create(
                user=approver,
                title=f"PR Pending Approval: {pr.pr_number}",
                message=(
                    f"Purchase requisition {pr.pr_number} has been pending approval for "
                    f"{days_pending} days. "
                    f"Requested by: {pr.created_by.get_full_name() if pr.created_by else 'Unknown'}"
                ),
                notification_type="IN_APP",
                module="purchase",
                resource="PurchaseRequisition",
                resource_id=pr.id,
            )
            count += 1

        # Send ONE SMS per approver summarising all their pending PRs
        if approver.phone:
            try:
                from apps.core.sms import SMSService
                sms_text = (
                    f"Trident ERP: {pr_count} Purchase Requisition"
                    f"{'s' if pr_count != 1 else ''} pending your approval. "
                    "Login to approve."
                )
                SMSService.send(approver.phone, sms_text)
                sms_count += 1
            except Exception as exc:
                logger.warning("[PR-REMINDER] SMS failed for %s: %s", approver.username, exc)

    return (
        f"Sent {count} PR approval reminders for {pr_count} requisitions. "
        f"SMS sent to {sms_count} approvers."
    )


@shared_task(name="purchase.weekly_purchase_summary")
def weekly_purchase_summary():
    """
    Weekly: Email purchase summary (PR/PO counts, pending amounts).
    Runs Monday at 9:00 AM.
    """
    from apps.purchase.models import PurchaseRequisition, PurchaseOrder
    from apps.core.models import Notification, User
    from decimal import Decimal
    
    # Get date range for last week
    today = timezone.now().date()
    week_start = today - timedelta(days=7)
    
    # PR Summary
    pr_created = PurchaseRequisition.objects.filter(
        created_at__date__gte=week_start
    ).count()
    
    pr_pending = PurchaseRequisition.objects.filter(
        status__in=[
            PurchaseRequisition.Status.DRAFT,
            PurchaseRequisition.Status.SUBMITTED
        ]
    ).count()
    
    # PO Summary
    po_created = PurchaseOrder.objects.filter(
        created_at__date__gte=week_start
    ).count()
    
    po_pending_approval = PurchaseOrder.objects.filter(
        status=PurchaseOrder.Status.SUBMITTED
    ).count()
    
    # Pending amount calculation
    pending_pos = PurchaseOrder.objects.filter(
        status__in=[
            PurchaseOrder.Status.APPROVED,
            PurchaseOrder.Status.PARTIALLY_RECEIVED
        ]
    )
    
    pending_amount = pending_pos.aggregate(
        total=Sum('grand_total')
    )['total'] or Decimal('0.00')
    
    # Create summary message
    summary = f"""
Weekly Purchase Summary (Last 7 days):

Purchase Requisitions:
- Created: {pr_created}
- Pending Approval: {pr_pending}

Purchase Orders:
- Created: {po_created}
- Pending Approval: {po_pending_approval}
- Approved/Partially Received: {pending_pos.count()}
- Total Pending Amount: ₹{pending_amount:,.2f}

This is an automated weekly summary.
    """.strip()
    
    # Send to purchase team and managers
    purchase_users = User.objects.filter(
        Q(is_staff=True) | Q(userrole__role__name__icontains='Purchase'),
        is_active=True
    ).distinct()
    
    count = 0
    for user in purchase_users:
        Notification.objects.create(
            user=user,
            title="Weekly Purchase Summary",
            message=summary,
            notification_type="IN_APP",
            module="purchase",
            resource="Summary",
            resource_id=0,
        )
        count += 1
    
    return f"Sent weekly summary to {count} users."
