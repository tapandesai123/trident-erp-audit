"""
Maintenance & AMC Module Services — Section 17

Services:
  create_maintenance_schedule()  — Preventive maintenance calendar per asset
  raise_maintenance_request()    — Breakdown/routine request with priority + downtime start
  create_maintenance_order()     — Convert request → work order; set asset UNDER_MAINTENANCE
  complete_maintenance_order()   — Record work done; consume spares (StockIssue); post Voucher;
                                   update asset.amc_expiry / last_maintenance_date equivalent
  create_amc_contract()          — AMC with vendor; cover assets; compute next_visit_date
  get_maintenance_report()       — MTBF, downtime hours, cost summary per asset
"""
from __future__ import annotations

from datetime import date, timedelta
from decimal import Decimal, ROUND_HALF_UP
from typing import List, Dict, Any, Optional

from django.db import transaction
from django.utils import timezone

from apps.core.models import AuditLog, DocSequence, Notification


# ─── Helpers ──────────────────────────────────────────────────────

def _two(val) -> Decimal:
    return Decimal(str(val)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def _log(user, action: str, resource: str, resource_id, details: dict = None):
    AuditLog.objects.create(
        user=user,
        action=action,
        module="maintenance",
        resource=resource,
        resource_id=str(resource_id),
        new_values=details or {},
    )


def _notify(user, title: str, message: str, resource: str, resource_id):
    if user:
        Notification.objects.create(
            user=user,
            title=title,
            message=message,
            notification_type="IN_APP",
            module="maintenance",
            resource=resource,
            resource_id=resource_id,
        )


def get_next_doc_number(plant, doc_type: str, prefix: str) -> str:
    """Thread-safe sequential document numbering. Format: PREFIX/YYYY-YY/00001"""
    today = date.today()
    fy_start = today.year if today.month >= 4 else today.year - 1
    fy_label = f"{fy_start}-{str(fy_start + 1)[2:]}"
    with transaction.atomic():
        seq, _ = DocSequence.objects.select_for_update().get_or_create(
            plant=plant,
            doc_type=doc_type,
            defaults={"last_number": 0, "financial_year": fy_label},
        )
        if seq.financial_year != fy_label:
            seq.financial_year = fy_label
            seq.last_number = 0
        seq.last_number += 1
        seq.save(update_fields=["last_number", "financial_year"])
        return f"{prefix}/{fy_label}/{seq.last_number:05d}"


def _compute_next_due(last_done: date, frequency_value: int, frequency_unit: str) -> date:
    """Calculate next due date from last completed date and frequency."""
    if frequency_unit == "DAILY":
        return last_done + timedelta(days=frequency_value)
    if frequency_unit == "WEEKLY":
        return last_done + timedelta(weeks=frequency_value)
    if frequency_unit == "MONTHLY":
        # Approximate: 30 days per month
        return last_done + timedelta(days=frequency_value * 30)
    if frequency_unit == "YEARLY":
        return last_done + timedelta(days=frequency_value * 365)
    # HOURS — cannot compute from calendar; use today + 30 days as fallback
    return last_done + timedelta(days=30)


# ═══════════════════════════════════════════════════════════════════
# CREATE MAINTENANCE SCHEDULE
# ═══════════════════════════════════════════════════════════════════

@transaction.atomic
def create_maintenance_schedule(
    *,
    plant,
    asset,
    maintenance_type,
    title: str,
    frequency_value: int,
    frequency_unit: str,
    description: str = "",
    last_done_date: date | None = None,
    next_due_date: date | None = None,
    assigned_to=None,
    estimated_duration_hours: Decimal | None = None,
    estimated_cost: Decimal = Decimal("0"),
    notes: str = "",
    created_by=None,
):
    """
    Create a preventive maintenance schedule for an asset.
    Auto-computes next_due_date if last_done_date is given but next_due_date is not.
    """
    from apps.maintenance.models import MaintenanceSchedule

    if not next_due_date and last_done_date:
        next_due_date = _compute_next_due(last_done_date, frequency_value, frequency_unit)
    elif not next_due_date:
        # Default: start from today
        next_due_date = _compute_next_due(date.today(), frequency_value, frequency_unit)

    schedule = MaintenanceSchedule.objects.create(
        plant=plant,
        asset=asset,
        maintenance_type=maintenance_type,
        title=title,
        description=description,
        frequency_value=frequency_value,
        frequency_unit=frequency_unit,
        last_done_date=last_done_date,
        next_due_date=next_due_date,
        assigned_to=assigned_to,
        estimated_duration_hours=estimated_duration_hours,
        estimated_cost=_two(estimated_cost),
        status=MaintenanceSchedule.ScheduleStatus.ACTIVE,
        notes=notes,
        created_by=created_by,
    )

    _log(created_by, "CREATE", "MaintenanceSchedule", schedule.id, {
        "asset": asset.asset_number,
        "title": title,
        "next_due_date": str(next_due_date),
    })

    return schedule


# ═══════════════════════════════════════════════════════════════════
# RAISE MAINTENANCE REQUEST
# ═══════════════════════════════════════════════════════════════════

@transaction.atomic
def raise_maintenance_request(
    *,
    plant,
    asset,
    title: str,
    request_type: str,
    priority: str = "MEDIUM",
    maintenance_type=None,
    schedule=None,
    description: str = "",
    reported_by=None,
    downtime_start=None,
    notes: str = "",
    created_by=None,
):
    """
    Raise a maintenance request.
    For BREAKDOWN requests, optionally starts downtime clock and sets asset UNDER_MAINTENANCE.
    Notifies assigned maintenance manager.
    """
    from apps.maintenance.models import MaintenanceRequest

    request_number = get_next_doc_number(plant, "MAINT_REQ", "MRQ")

    req = MaintenanceRequest.objects.create(
        plant=plant,
        request_number=request_number,
        request_date=timezone.now(),
        request_type=request_type,
        priority=priority,
        status=MaintenanceRequest.RequestStatus.OPEN,
        asset=asset,
        maintenance_type=maintenance_type,
        schedule=schedule,
        title=title,
        description=description,
        reported_by=reported_by,
        downtime_start=downtime_start or (timezone.now() if request_type == "BREAKDOWN" else None),
        notes=notes,
        created_by=created_by,
    )

    # Mark asset UNDER_MAINTENANCE for breakdowns
    if request_type == "BREAKDOWN":
        asset.status = "UNDER_MAINTENANCE"
        asset.save(update_fields=["status"])

    _log(created_by, "CREATE", "MaintenanceRequest", req.id, {
        "request_number": request_number,
        "asset": asset.asset_number,
        "priority": priority,
        "request_type": request_type,
    })

    # Notify plant superusers / maintenance managers
    try:
        from django.contrib.auth import get_user_model
        User = get_user_model()
        managers = User.objects.filter(is_staff=True, is_active=True)
        for mgr in managers[:3]:  # cap notifications
            _notify(
                mgr,
                f"[{priority}] Maintenance Request: {request_number}",
                f"{request_type} on {asset.asset_number} — {title}. "
                f"Priority: {priority}.",
                "MaintenanceRequest", req.id,
            )
    except Exception:
        pass

    return req


# ═══════════════════════════════════════════════════════════════════
# CREATE MAINTENANCE ORDER
# ═══════════════════════════════════════════════════════════════════

@transaction.atomic
def create_maintenance_order(
    *,
    plant,
    asset,
    title: str,
    request=None,
    maintenance_type=None,
    priority: str = "MEDIUM",
    description: str = "",
    scheduled_start=None,
    scheduled_end=None,
    assigned_to=None,
    estimated_cost: Decimal = Decimal("0"),
    lines: List[Dict[str, Any]] | None = None,
    notes: str = "",
    created_by=None,
):
    """
    Create a MaintenanceOrder work order.
    Optionally converts from a request; adds order lines.

    lines: [{line_type, description, quantity, uom, unit_cost}]
    """
    from apps.maintenance.models import MaintenanceOrder, MaintenanceOrderLine

    order_number = get_next_doc_number(plant, "MAINT_ORDER", "MWO")

    order = MaintenanceOrder.objects.create(
        plant=plant,
        order_number=order_number,
        order_date=date.today(),
        status=MaintenanceOrder.OrderStatus.OPEN,
        asset=asset,
        request=request,
        maintenance_type=maintenance_type or (request.maintenance_type if request else None),
        title=title,
        description=description,
        priority=priority,
        scheduled_start=scheduled_start,
        scheduled_end=scheduled_end,
        assigned_to=assigned_to,
        estimated_cost=_two(estimated_cost),
        notes=notes,
        created_by=created_by,
    )

    # Update request status
    if request:
        request.status = "ASSIGNED"
        request.assigned_to = assigned_to
        request.assigned_at = timezone.now()
        request.save(update_fields=["status", "assigned_to", "assigned_at"])

    # Create order lines
    for idx, line_data in enumerate(lines or [], start=1):
        qty = Decimal(str(line_data.get("quantity", 1)))
        unit_cost = Decimal(str(line_data.get("unit_cost", 0)))
        MaintenanceOrderLine.objects.create(
            order=order,
            line_number=idx,
            line_type=line_data.get("line_type", "TASK"),
            description=line_data["description"],
            quantity=qty,
            uom=line_data.get("uom", ""),
            unit_cost=unit_cost,
            line_total=_two(qty * unit_cost),
        )

    _log(created_by, "CREATE", "MaintenanceOrder", order.id, {
        "order_number": order_number,
        "asset": asset.asset_number,
        "from_request": request.request_number if request else None,
    })

    if assigned_to:
        _notify(
            assigned_to,
            f"Work Order Assigned: {order_number}",
            f"You have been assigned maintenance work order '{title}' "
            f"on asset {asset.asset_number}.",
            "MaintenanceOrder", order.id,
        )

    return order


# ═══════════════════════════════════════════════════════════════════
# COMPLETE MAINTENANCE ORDER
# ═══════════════════════════════════════════════════════════════════

@transaction.atomic
def complete_maintenance_order(
    *,
    order,
    work_done_remarks: str,
    root_cause: str = "",
    corrective_action: str = "",
    actual_start=None,
    actual_end=None,
    actual_labour_cost: Decimal = Decimal("0"),
    actual_other_cost: Decimal = Decimal("0"),
    spare_usages: List[Dict[str, Any]] | None = None,
    warehouse=None,
    completed_by=None,
):
    """
    Complete a MaintenanceOrder:
    1. Record actual work remarks, root cause, corrective action
    2. Consume spare parts → create stores.StockIssue (MAINTENANCE type)
    3. Compute total_actual_cost
    4. Post accounts.Voucher (Maintenance Expense DR / Creditor CR)
    5. Update asset status → ACTIVE; update asset.amc_expiry notes / schedule.last_done_date
    6. Close linked MaintenanceRequest + end downtime

    spare_usages: [{spare_part_id, quantity_used, unit_cost, remarks}]
    """
    from apps.maintenance.models import (
        MaintenanceOrder, SparePartUsage, SparePart, MaintenanceRequest
    )

    if order.status in (MaintenanceOrder.OrderStatus.COMPLETED, MaintenanceOrder.OrderStatus.CLOSED):
        raise ValueError(f"Order {order.order_number} is already {order.status}.")

    now = timezone.now()
    order.actual_start = actual_start or order.actual_start or now
    order.actual_end = actual_end or now
    order.work_done_remarks = work_done_remarks
    order.root_cause = root_cause
    order.corrective_action = corrective_action
    order.actual_labour_cost = _two(actual_labour_cost)
    order.actual_other_cost = _two(actual_other_cost)
    order.completed_by = completed_by
    order.completed_at = now
    order.status = MaintenanceOrder.OrderStatus.COMPLETED

    # ── Spare part consumption ──────────────────────────────────────
    total_spare_cost = Decimal("0")
    stock_issue = None

    if spare_usages and warehouse:
        try:
            from apps.stores.models import StockIssue, StockIssueLine
            issue_number = get_next_doc_number(order.plant, "MAINT_ISSUE", "MSI")
            stock_issue = StockIssue.objects.create(
                plant=order.plant,
                issue_number=issue_number,
                issue_date=date.today(),
                issue_type=StockIssue.IssueType.MAINTENANCE,
                status=StockIssue.IssueStatus.ISSUED,
                from_warehouse=warehouse,
                issued_by=completed_by,
                remarks=f"Maintenance: {order.order_number}",
            )
        except Exception:
            stock_issue = None

        for su_data in spare_usages:
            try:
                spare = SparePart.objects.get(pk=su_data["spare_part_id"])
                qty = Decimal(str(su_data.get("quantity_used", 1)))
                u_cost = _two(su_data.get("unit_cost") or spare.unit_cost)
                t_cost = _two(qty * u_cost)
                total_spare_cost += t_cost

                usage = SparePartUsage.objects.create(
                    order=order,
                    spare_part=spare,
                    quantity_used=qty,
                    unit_cost=u_cost,
                    total_cost=t_cost,
                    stock_issue=stock_issue,
                    remarks=su_data.get("remarks", ""),
                    recorded_by=completed_by,
                )

                # Add StockIssueLine if stock_issue was created and spare has item link
                if stock_issue and spare.item:
                    try:
                        # Find a FIFO lot for this item
                        from apps.stores.models import InventoryLot
                        from apps.masters.models import UOM
                        lot = InventoryLot.objects.filter(
                            item=spare.item,
                            warehouse=warehouse,
                            available_qty__gte=qty,
                        ).order_by("receipt_date").first()
                        if lot:
                            StockIssueLine.objects.create(
                                issue=stock_issue,
                                lot=lot,
                                item=spare.item,
                                requested_qty=qty,
                                issued_qty=qty,
                            )
                            lot.available_qty -= qty
                            lot.save(update_fields=["available_qty"])
                    except Exception:
                        pass

            except SparePart.DoesNotExist:
                continue

    order.actual_spare_cost = _two(total_spare_cost)
    order.total_actual_cost = _two(
        order.actual_labour_cost + total_spare_cost + order.actual_other_cost
    )

    # ── Post accounts.Voucher ────────────────────────────────────────
    try:
        from apps.accounts.models import Voucher, VoucherLine, LedgerAccount

        voucher_number = get_next_doc_number(order.plant, "MAINT_VOUCHER", "JV")
        voucher = Voucher.objects.create(
            plant=order.plant,
            voucher_number=voucher_number,
            voucher_date=date.today(),
            voucher_type=Voucher.VoucherType.JOURNAL,
            narration=f"Maintenance expense: {order.order_number} — {order.asset.asset_number}",
            status=Voucher.VoucherStatus.DRAFT,
            created_by=completed_by,
        )
        # DR Maintenance Expense
        try:
            maint_ledger = LedgerAccount.objects.filter(
                plant=order.plant, account_code__icontains="MAINT"
            ).first()
            if maint_ledger:
                VoucherLine.objects.create(
                    voucher=voucher,
                    ledger_account=maint_ledger,
                    debit_amount=order.total_actual_cost,
                    credit_amount=Decimal("0"),
                    narration="Maintenance expense",
                )
        except Exception:
            pass

        order.voucher = voucher
    except Exception:
        pass

    order.save()

    # ── Update asset status ──────────────────────────────────────────
    asset = order.asset
    asset.status = "ACTIVE"
    asset.save(update_fields=["status"])

    # ── Update linked schedule ───────────────────────────────────────
    if order.request and order.request.schedule:
        schedule = order.request.schedule
        today = date.today()
        schedule.last_done_date = today
        schedule.next_due_date = _compute_next_due(
            today, schedule.frequency_value, schedule.frequency_unit
        )
        schedule.save(update_fields=["last_done_date", "next_due_date"])

    # ── Close linked request + end downtime ─────────────────────────
    if order.request:
        req = order.request
        req.status = MaintenanceRequest.RequestStatus.COMPLETED
        if req.downtime_start and not req.downtime_end:
            req.downtime_end = now
        req.save(update_fields=["status", "downtime_end"])

    _log(completed_by, "COMPLETE", "MaintenanceOrder", order.id, {
        "order_number": order.order_number,
        "total_actual_cost": str(order.total_actual_cost),
        "stock_issue": stock_issue.issue_number if stock_issue else None,
    })

    return order


# ═══════════════════════════════════════════════════════════════════
# CREATE AMC CONTRACT
# ═══════════════════════════════════════════════════════════════════

@transaction.atomic
def create_amc_contract(
    *,
    plant,
    vendor,
    contract_date: date,
    start_date: date,
    end_date: date,
    contract_type: str,
    contract_value: Decimal,
    payment_frequency: str = "QUARTERLY",
    payment_amount: Decimal = Decimal("0"),
    visits_per_year: int = 4,
    scope_of_work: str = "",
    exclusions: str = "",
    asset_lines: List[Dict[str, Any]] | None = None,
    notes: str = "",
    created_by=None,
):
    """
    Create an AMC contract covering multiple assets.
    Computes next_visit_date from visits_per_year.
    Updates asset.amc_expiry on each covered asset.

    asset_lines: [{asset_id, description, allocated_value}]
    """
    from apps.maintenance.models import AMCContract, AMCContractLine

    contract_number = get_next_doc_number(plant, "AMC_CONTRACT", "AMC")

    # Compute next visit date
    days_between_visits = 365 // max(visits_per_year, 1)
    next_visit = start_date + timedelta(days=days_between_visits)

    contract = AMCContract.objects.create(
        plant=plant,
        contract_number=contract_number,
        contract_date=contract_date,
        status=AMCContract.ContractStatus.DRAFT,
        contract_type=contract_type,
        vendor=vendor,
        start_date=start_date,
        end_date=end_date,
        contract_value=_two(contract_value),
        payment_frequency=payment_frequency,
        payment_amount=_two(payment_amount),
        visits_per_year=visits_per_year,
        next_visit_date=next_visit,
        scope_of_work=scope_of_work,
        exclusions=exclusions,
        notes=notes,
        created_by=created_by,
    )

    for idx, line_data in enumerate(asset_lines or [], start=1):
        from apps.assets.models import Asset
        try:
            asset = Asset.objects.get(pk=line_data["asset_id"])
        except Asset.DoesNotExist:
            continue

        AMCContractLine.objects.create(
            contract=contract,
            line_number=idx,
            asset=asset,
            description=line_data.get("description", ""),
            allocated_value=_two(line_data.get("allocated_value", 0)),
            notes=line_data.get("notes", ""),
        )

        # Update asset.amc_expiry
        asset.amc_expiry = end_date
        asset.save(update_fields=["amc_expiry"])

    _log(created_by, "CREATE", "AMCContract", contract.id, {
        "contract_number": contract_number,
        "vendor": str(vendor),
        "assets_covered": len(asset_lines or []),
        "contract_value": str(_two(contract_value)),
    })

    return contract


# ═══════════════════════════════════════════════════════════════════
# GET MAINTENANCE REPORT
# ═══════════════════════════════════════════════════════════════════

def get_maintenance_report(plant, filters: dict | None = None) -> dict:
    """
    Return maintenance performance report.

    filters: {asset_id, maintenance_type_id, date_from, date_to, status}

    Returns:
    {
      total_orders, completed_orders, open_orders,
      total_actual_cost, total_downtime_hours,
      mtbf_days (mean time between failures),
      by_asset: [{asset_number, name, breakdown_count, downtime_hours, total_cost, last_maintenance}],
      by_type:  [{type_name, count, total_cost}],
      overdue_schedules: [{asset, title, next_due_date, overdue_days}],
      spare_cost_by_part: [{part_name, qty_used, total_cost}]
    }
    """
    from apps.maintenance.models import MaintenanceOrder, MaintenanceRequest, MaintenanceSchedule
    from django.db.models import Count, Sum, Q
    from django.utils import timezone as tz

    orders_qs = MaintenanceOrder.objects.filter(plant=plant).select_related(
        "asset", "maintenance_type"
    )
    requests_qs = MaintenanceRequest.objects.filter(plant=plant)

    if filters:
        if filters.get("asset_id"):
            orders_qs = orders_qs.filter(asset_id=filters["asset_id"])
            requests_qs = requests_qs.filter(asset_id=filters["asset_id"])
        if filters.get("maintenance_type_id"):
            orders_qs = orders_qs.filter(maintenance_type_id=filters["maintenance_type_id"])
        if filters.get("date_from"):
            orders_qs = orders_qs.filter(order_date__gte=filters["date_from"])
        if filters.get("date_to"):
            orders_qs = orders_qs.filter(order_date__lte=filters["date_to"])
        if filters.get("status"):
            orders_qs = orders_qs.filter(status=filters["status"])

    totals = orders_qs.aggregate(
        total_orders=Count("id"),
        total_cost=Sum("total_actual_cost"),
    )

    completed_count = orders_qs.filter(
        status__in=["COMPLETED", "CLOSED"]
    ).count()
    open_count = orders_qs.filter(
        status__in=["DRAFT", "OPEN", "IN_PROGRESS", "ON_HOLD"]
    ).count()

    # Total downtime from requests
    total_downtime = Decimal("0")
    for req in requests_qs.filter(
        downtime_start__isnull=False, downtime_end__isnull=False
    ):
        total_downtime += req.downtime_hours

    # MTBF: if we have multiple breakdowns per asset, avg days between them
    breakdown_requests = list(
        requests_qs.filter(request_type="BREAKDOWN")
        .values("asset_id")
        .annotate(count=Count("id"))
    )
    mtbf_days = None
    if filters and filters.get("date_from") and filters.get("date_to"):
        try:
            from datetime import datetime
            d1 = datetime.fromisoformat(str(filters["date_from"]))
            d2 = datetime.fromisoformat(str(filters["date_to"]))
            period_days = (d2 - d1).days
            total_breakdowns = sum(b["count"] for b in breakdown_requests)
            if total_breakdowns > 0:
                mtbf_days = round(period_days / total_breakdowns, 1)
        except Exception:
            pass

    # By asset
    by_asset_raw = list(
        orders_qs.values("asset__asset_number", "asset__name", "asset__id")
        .annotate(
            order_count=Count("id"),
            total_cost=Sum("total_actual_cost"),
        )
        .order_by("-total_cost")
    )
    by_asset = []
    for a in by_asset_raw:
        # Breakdown count from requests
        bd_count = requests_qs.filter(
            asset_id=a["asset__id"], request_type="BREAKDOWN"
        ).count()
        # Downtime for this asset
        asset_dt = Decimal("0")
        for req in requests_qs.filter(
            asset_id=a["asset__id"],
            downtime_start__isnull=False, downtime_end__isnull=False
        ):
            asset_dt += req.downtime_hours
        # Last maintenance
        last = orders_qs.filter(
            asset_id=a["asset__id"], status__in=["COMPLETED", "CLOSED"]
        ).order_by("-completed_at").first()
        by_asset.append({
            "asset_number": a["asset__asset_number"],
            "name": a["asset__name"],
            "order_count": a["order_count"],
            "breakdown_count": bd_count,
            "downtime_hours": str(_two(asset_dt)),
            "total_cost": str(_two(a["total_cost"] or 0)),
            "last_maintenance": str(last.completed_at.date()) if last and last.completed_at else None,
        })

    # By maintenance type
    by_type = list(
        orders_qs.values("maintenance_type__name")
        .annotate(count=Count("id"), total_cost=Sum("total_actual_cost"))
        .order_by("-count")
    )

    # Overdue schedules
    today = date.today()
    overdue_schedules = []
    for s in MaintenanceSchedule.objects.filter(
        plant=plant,
        status="ACTIVE",
        next_due_date__lt=today,
    ).select_related("asset")[:20]:
        overdue_schedules.append({
            "asset_number": s.asset.asset_number,
            "asset_name": s.asset.name,
            "title": s.title,
            "next_due_date": str(s.next_due_date),
            "overdue_days": (today - s.next_due_date).days,
        })

    # Spare cost by part
    from apps.maintenance.models import SparePartUsage
    spare_agg = list(
        SparePartUsage.objects.filter(order__plant=plant)
        .values("spare_part__name", "spare_part__part_number")
        .annotate(qty_used=Sum("quantity_used"), total_cost=Sum("total_cost"))
        .order_by("-total_cost")[:10]
    )

    return {
        "total_orders": totals["total_orders"] or 0,
        "completed_orders": completed_count,
        "open_orders": open_count,
        "total_actual_cost": str(_two(totals["total_cost"] or 0)),
        "total_downtime_hours": str(_two(total_downtime)),
        "mtbf_days": mtbf_days,
        "by_asset": by_asset,
        "by_type": [
            {
                "type": t["maintenance_type__name"] or "Unclassified",
                "count": t["count"],
                "total_cost": str(_two(t["total_cost"] or 0)),
            }
            for t in by_type
        ],
        "overdue_schedules": overdue_schedules,
        "spare_cost_by_part": [
            {
                "part": f"{s['spare_part__part_number']} — {s['spare_part__name']}",
                "qty_used": str(s["qty_used"] or 0),
                "total_cost": str(_two(s["total_cost"] or 0)),
            }
            for s in spare_agg
        ],
    }
