"""Maintenance & AMC API Serializers — 3 variants per major model."""
from rest_framework import serializers
from apps.maintenance.models import (
    MaintenanceType, SparePart, MaintenanceSchedule,
    MaintenanceRequest, MaintenanceOrder, MaintenanceOrderLine,
    SparePartUsage, AMCContract, AMCContractLine,
)


# ─── MaintenanceType ──────────────────────────────────────────────

class MaintenanceTypeListSerializer(serializers.ModelSerializer):
    plant_code = serializers.CharField(source="plant.code", read_only=True)

    class Meta:
        model = MaintenanceType
        fields = ["id", "uuid", "code", "name", "plant", "plant_code", "is_active"]


class MaintenanceTypeDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = MaintenanceType
        fields = "__all__"


class MaintenanceTypeCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = MaintenanceType
        fields = ["plant", "code", "name", "description", "is_active"]


# ─── SparePart ────────────────────────────────────────────────────

class SparePartListSerializer(serializers.ModelSerializer):
    plant_code = serializers.CharField(source="plant.code", read_only=True)

    class Meta:
        model = SparePart
        fields = [
            "id", "uuid", "part_number", "name", "plant", "plant_code",
            "uom", "unit_cost", "min_stock_qty", "is_active",
        ]


class SparePartDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = SparePart
        fields = "__all__"


class SparePartCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = SparePart
        fields = [
            "plant", "part_number", "name", "description",
            "uom", "item", "unit_cost", "min_stock_qty", "is_active", "notes",
        ]


# ─── MaintenanceSchedule ──────────────────────────────────────────

class MaintenanceScheduleListSerializer(serializers.ModelSerializer):
    asset_number = serializers.CharField(source="asset.asset_number", read_only=True)
    asset_name = serializers.CharField(source="asset.name", read_only=True)
    type_name = serializers.CharField(source="maintenance_type.name", read_only=True)

    class Meta:
        model = MaintenanceSchedule
        fields = [
            "id", "uuid", "asset", "asset_number", "asset_name",
            "maintenance_type", "type_name", "title",
            "frequency_value", "frequency_unit",
            "last_done_date", "next_due_date", "status",
        ]


class MaintenanceScheduleDetailSerializer(serializers.ModelSerializer):
    asset_number = serializers.CharField(source="asset.asset_number", read_only=True)
    asset_name = serializers.CharField(source="asset.name", read_only=True)

    class Meta:
        model = MaintenanceSchedule
        fields = "__all__"


class MaintenanceScheduleCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = MaintenanceSchedule
        fields = [
            "plant", "asset", "maintenance_type", "title", "description",
            "frequency_value", "frequency_unit",
            "last_done_date", "next_due_date",
            "assigned_to", "estimated_duration_hours",
            "estimated_cost", "notes",
        ]


# ─── MaintenanceRequest ───────────────────────────────────────────

class MaintenanceRequestListSerializer(serializers.ModelSerializer):
    asset_number = serializers.CharField(source="asset.asset_number", read_only=True)
    reported_by_name = serializers.CharField(source="reported_by.get_full_name", read_only=True)

    class Meta:
        model = MaintenanceRequest
        fields = [
            "id", "uuid", "request_number", "request_date",
            "request_type", "priority", "status",
            "asset", "asset_number", "title",
            "reported_by", "reported_by_name",
            "assigned_to", "downtime_hours",
        ]


class MaintenanceRequestDetailSerializer(serializers.ModelSerializer):
    asset_number = serializers.CharField(source="asset.asset_number", read_only=True)
    asset_name = serializers.CharField(source="asset.name", read_only=True)
    downtime_hours = serializers.DecimalField(max_digits=8, decimal_places=2, read_only=True)

    class Meta:
        model = MaintenanceRequest
        fields = "__all__"


class MaintenanceRequestCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = MaintenanceRequest
        fields = [
            "plant", "request_type", "priority", "asset",
            "maintenance_type", "schedule", "title", "description",
            "downtime_start", "notes",
        ]


# ─── MaintenanceOrderLine ─────────────────────────────────────────

class MaintenanceOrderLineSerializer(serializers.ModelSerializer):
    class Meta:
        model = MaintenanceOrderLine
        fields = "__all__"


class MaintenanceOrderLineCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = MaintenanceOrderLine
        fields = [
            "order", "line_type", "description",
            "quantity", "uom", "unit_cost",
        ]


# ─── SparePartUsage ───────────────────────────────────────────────

class SparePartUsageSerializer(serializers.ModelSerializer):
    part_name = serializers.CharField(source="spare_part.name", read_only=True)

    class Meta:
        model = SparePartUsage
        fields = "__all__"


# ─── MaintenanceOrder ─────────────────────────────────────────────

class MaintenanceOrderListSerializer(serializers.ModelSerializer):
    asset_number = serializers.CharField(source="asset.asset_number", read_only=True)
    asset_name = serializers.CharField(source="asset.name", read_only=True)
    assigned_to_name = serializers.CharField(source="assigned_to.get_full_name", read_only=True)

    class Meta:
        model = MaintenanceOrder
        fields = [
            "id", "uuid", "order_number", "order_date", "status",
            "asset", "asset_number", "asset_name",
            "priority", "title",
            "assigned_to", "assigned_to_name",
            "estimated_cost", "total_actual_cost",
            "scheduled_start", "actual_end",
        ]


class MaintenanceOrderDetailSerializer(serializers.ModelSerializer):
    asset_number = serializers.CharField(source="asset.asset_number", read_only=True)
    asset_name = serializers.CharField(source="asset.name", read_only=True)
    actual_duration_hours = serializers.DecimalField(
        max_digits=8, decimal_places=2, read_only=True
    )
    lines = MaintenanceOrderLineSerializer(many=True, read_only=True)
    spare_usages = SparePartUsageSerializer(many=True, read_only=True)

    class Meta:
        model = MaintenanceOrder
        fields = "__all__"


class MaintenanceOrderCreateSerializer(serializers.ModelSerializer):
    lines = MaintenanceOrderLineCreateSerializer(many=True, required=False, write_only=True)

    class Meta:
        model = MaintenanceOrder
        fields = [
            "plant", "asset", "request", "maintenance_type",
            "title", "description", "priority",
            "scheduled_start", "scheduled_end",
            "assigned_to", "estimated_cost", "notes", "lines",
        ]


# ─── AMCContractLine ─────────────────────────────────────────────

class AMCContractLineSerializer(serializers.ModelSerializer):
    asset_number = serializers.CharField(source="asset.asset_number", read_only=True)
    asset_name = serializers.CharField(source="asset.name", read_only=True)

    class Meta:
        model = AMCContractLine
        fields = "__all__"


class AMCContractLineCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = AMCContractLine
        fields = ["asset", "description", "allocated_value", "notes"]


# ─── AMCContract ─────────────────────────────────────────────────

class AMCContractListSerializer(serializers.ModelSerializer):
    vendor_name = serializers.CharField(source="vendor.name", read_only=True)
    assets_count = serializers.SerializerMethodField()

    class Meta:
        model = AMCContract
        fields = [
            "id", "uuid", "contract_number", "contract_date", "status",
            "contract_type", "vendor", "vendor_name",
            "start_date", "end_date", "contract_value",
            "visits_per_year", "next_visit_date", "assets_count",
        ]

    def get_assets_count(self, obj):
        return obj.lines.count()


class AMCContractDetailSerializer(serializers.ModelSerializer):
    vendor_name = serializers.CharField(source="vendor.name", read_only=True)
    lines = AMCContractLineSerializer(many=True, read_only=True)

    class Meta:
        model = AMCContract
        fields = "__all__"


class AMCContractCreateSerializer(serializers.ModelSerializer):
    asset_lines = AMCContractLineCreateSerializer(many=True, required=False, write_only=True)

    class Meta:
        model = AMCContract
        fields = [
            "plant", "contract_date", "contract_type", "vendor",
            "vendor_contact", "vendor_phone",
            "start_date", "end_date", "contract_value",
            "payment_frequency", "payment_amount",
            "visits_per_year", "scope_of_work", "exclusions",
            "notes", "asset_lines",
        ]
