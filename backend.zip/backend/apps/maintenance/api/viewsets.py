"""Maintenance & AMC API Viewsets."""
from decimal import Decimal
from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated

from apps.maintenance.models import (
    MaintenanceType, SparePart, MaintenanceSchedule,
    MaintenanceRequest, MaintenanceOrder, MaintenanceOrderLine,
    SparePartUsage, AMCContract, AMCContractLine,
)
from apps.maintenance.api.serializers import (
    MaintenanceTypeListSerializer, MaintenanceTypeDetailSerializer,
    MaintenanceTypeCreateSerializer,
    SparePartListSerializer, SparePartDetailSerializer, SparePartCreateSerializer,
    MaintenanceScheduleListSerializer, MaintenanceScheduleDetailSerializer,
    MaintenanceScheduleCreateSerializer,
    MaintenanceRequestListSerializer, MaintenanceRequestDetailSerializer,
    MaintenanceRequestCreateSerializer,
    MaintenanceOrderListSerializer, MaintenanceOrderDetailSerializer,
    MaintenanceOrderCreateSerializer,
    MaintenanceOrderLineSerializer, MaintenanceOrderLineCreateSerializer,
    SparePartUsageSerializer,
    AMCContractListSerializer, AMCContractDetailSerializer, AMCContractCreateSerializer,
)
from apps.maintenance import services


# ─── MaintenanceType ──────────────────────────────────────────────

class MaintenanceTypeViewSet(viewsets.ModelViewSet):
    queryset = MaintenanceType.objects.select_related("plant")
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return MaintenanceTypeListSerializer
        if self.action in ("create", "update", "partial_update"):
            return MaintenanceTypeCreateSerializer
        return MaintenanceTypeDetailSerializer

    def get_queryset(self):
        qs = super().get_queryset()
        if plant := self.request.query_params.get("plant"):
            qs = qs.filter(plant=plant)
        return qs


# ─── SparePart ────────────────────────────────────────────────────

class SparePartViewSet(viewsets.ModelViewSet):
    queryset = SparePart.objects.select_related("plant", "item")
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return SparePartListSerializer
        if self.action in ("create", "update", "partial_update"):
            return SparePartCreateSerializer
        return SparePartDetailSerializer

    def get_queryset(self):
        qs = super().get_queryset()
        if plant := self.request.query_params.get("plant"):
            qs = qs.filter(plant=plant)
        if search := self.request.query_params.get("search"):
            qs = qs.filter(name__icontains=search) | qs.filter(part_number__icontains=search)
        return qs.filter(is_active=True)

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)


# ─── MaintenanceSchedule ──────────────────────────────────────────

class MaintenanceScheduleViewSet(viewsets.ModelViewSet):
    queryset = MaintenanceSchedule.objects.select_related(
        "plant", "asset", "maintenance_type", "assigned_to"
    )
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return MaintenanceScheduleListSerializer
        if self.action in ("create", "update", "partial_update"):
            return MaintenanceScheduleCreateSerializer
        return MaintenanceScheduleDetailSerializer

    def get_queryset(self):
        qs = super().get_queryset()
        if plant := self.request.query_params.get("plant"):
            qs = qs.filter(plant=plant)
        if asset := self.request.query_params.get("asset"):
            qs = qs.filter(asset=asset)
        if sched_status := self.request.query_params.get("status"):
            qs = qs.filter(status=sched_status)
        return qs

    def create(self, request, *args, **kwargs):
        from apps.core.models import Plant
        from apps.assets.models import Asset
        try:
            plant = Plant.objects.get(pk=request.data["plant"])
            asset = Asset.objects.get(pk=request.data["asset"])
            mtype = MaintenanceType.objects.get(pk=request.data["maintenance_type"])
            assigned_to = None
            if request.data.get("assigned_to"):
                from django.contrib.auth import get_user_model
                assigned_to = get_user_model().objects.get(pk=request.data["assigned_to"])

            schedule = services.create_maintenance_schedule(
                plant=plant,
                asset=asset,
                maintenance_type=mtype,
                title=request.data["title"],
                frequency_value=int(request.data["frequency_value"]),
                frequency_unit=request.data["frequency_unit"],
                description=request.data.get("description", ""),
                last_done_date=request.data.get("last_done_date"),
                next_due_date=request.data.get("next_due_date"),
                assigned_to=assigned_to,
                estimated_duration_hours=request.data.get("estimated_duration_hours"),
                estimated_cost=Decimal(str(request.data.get("estimated_cost", 0))),
                notes=request.data.get("notes", ""),
                created_by=request.user,
            )
            return Response(
                MaintenanceScheduleDetailSerializer(schedule).data,
                status=status.HTTP_201_CREATED,
            )
        except Exception as e:
            return Response({"detail": str(e)}, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=False, methods=["get"], url_path="overdue")
    def overdue(self, request):
        """List schedules that are overdue (next_due_date < today)."""
        from datetime import date
        qs = self.get_queryset().filter(
            status=MaintenanceSchedule.ScheduleStatus.ACTIVE,
            next_due_date__lt=date.today(),
        )
        return Response(MaintenanceScheduleListSerializer(qs, many=True).data)


# ─── MaintenanceRequest ───────────────────────────────────────────

class MaintenanceRequestViewSet(viewsets.ModelViewSet):
    queryset = MaintenanceRequest.objects.select_related(
        "plant", "asset", "maintenance_type", "schedule",
        "reported_by", "assigned_to",
    )
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return MaintenanceRequestListSerializer
        if self.action in ("create", "update", "partial_update"):
            return MaintenanceRequestCreateSerializer
        return MaintenanceRequestDetailSerializer

    def get_queryset(self):
        qs = super().get_queryset()
        if plant := self.request.query_params.get("plant"):
            qs = qs.filter(plant=plant)
        if req_status := self.request.query_params.get("status"):
            qs = qs.filter(status=req_status)
        if priority := self.request.query_params.get("priority"):
            qs = qs.filter(priority=priority)
        if req_type := self.request.query_params.get("request_type"):
            qs = qs.filter(request_type=req_type)
        if asset := self.request.query_params.get("asset"):
            qs = qs.filter(asset=asset)
        return qs

    def create(self, request, *args, **kwargs):
        from apps.core.models import Plant
        from apps.assets.models import Asset
        try:
            plant = Plant.objects.get(pk=request.data["plant"])
            asset = Asset.objects.get(pk=request.data["asset"])
            mtype = None
            if request.data.get("maintenance_type"):
                mtype = MaintenanceType.objects.get(pk=request.data["maintenance_type"])
            schedule = None
            if request.data.get("schedule"):
                schedule = MaintenanceSchedule.objects.get(pk=request.data["schedule"])

            req = services.raise_maintenance_request(
                plant=plant,
                asset=asset,
                title=request.data["title"],
                request_type=request.data["request_type"],
                priority=request.data.get("priority", "MEDIUM"),
                maintenance_type=mtype,
                schedule=schedule,
                description=request.data.get("description", ""),
                reported_by=request.user,
                downtime_start=request.data.get("downtime_start"),
                notes=request.data.get("notes", ""),
                created_by=request.user,
            )
            return Response(
                MaintenanceRequestDetailSerializer(req).data,
                status=status.HTTP_201_CREATED,
            )
        except Exception as e:
            return Response({"detail": str(e)}, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=True, methods=["post"], url_path="assign")
    def assign(self, request, pk=None):
        """Assign a request to a maintenance technician."""
        from django.contrib.auth import get_user_model
        from django.utils import timezone as tz
        req = self.get_object()
        try:
            technician = get_user_model().objects.get(pk=request.data["assigned_to"])
            req.assigned_to = technician
            req.assigned_at = tz.now()
            req.status = MaintenanceRequest.RequestStatus.ASSIGNED
            req.save(update_fields=["assigned_to", "assigned_at", "status"])
            return Response(MaintenanceRequestDetailSerializer(req).data)
        except Exception as e:
            return Response({"detail": str(e)}, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=True, methods=["post"], url_path="cancel")
    def cancel(self, request, pk=None):
        req = self.get_object()
        req.status = MaintenanceRequest.RequestStatus.CANCELLED
        req.notes = request.data.get("reason", req.notes)
        req.save(update_fields=["status", "notes"])
        return Response(MaintenanceRequestDetailSerializer(req).data)


# ─── MaintenanceOrder ─────────────────────────────────────────────

class MaintenanceOrderViewSet(viewsets.ModelViewSet):
    queryset = MaintenanceOrder.objects.select_related(
        "plant", "asset", "request", "maintenance_type",
        "assigned_to", "completed_by", "voucher",
    ).prefetch_related("lines", "spare_usages")
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return MaintenanceOrderListSerializer
        if self.action in ("create", "update", "partial_update"):
            return MaintenanceOrderCreateSerializer
        return MaintenanceOrderDetailSerializer

    def get_queryset(self):
        qs = super().get_queryset()
        if plant := self.request.query_params.get("plant"):
            qs = qs.filter(plant=plant)
        if ord_status := self.request.query_params.get("status"):
            qs = qs.filter(status=ord_status)
        if asset := self.request.query_params.get("asset"):
            qs = qs.filter(asset=asset)
        if priority := self.request.query_params.get("priority"):
            qs = qs.filter(priority=priority)
        if assigned_to := self.request.query_params.get("assigned_to"):
            qs = qs.filter(assigned_to=assigned_to)
        return qs

    def create(self, request, *args, **kwargs):
        from apps.core.models import Plant
        from apps.assets.models import Asset
        try:
            plant = Plant.objects.get(pk=request.data["plant"])
            asset = Asset.objects.get(pk=request.data["asset"])
            req_obj = None
            if request.data.get("request"):
                req_obj = MaintenanceRequest.objects.get(pk=request.data["request"])
            mtype = None
            if request.data.get("maintenance_type"):
                mtype = MaintenanceType.objects.get(pk=request.data["maintenance_type"])
            assigned_to = None
            if request.data.get("assigned_to"):
                from django.contrib.auth import get_user_model
                assigned_to = get_user_model().objects.get(pk=request.data["assigned_to"])

            order = services.create_maintenance_order(
                plant=plant,
                asset=asset,
                title=request.data["title"],
                request=req_obj,
                maintenance_type=mtype,
                priority=request.data.get("priority", "MEDIUM"),
                description=request.data.get("description", ""),
                scheduled_start=request.data.get("scheduled_start"),
                scheduled_end=request.data.get("scheduled_end"),
                assigned_to=assigned_to,
                estimated_cost=Decimal(str(request.data.get("estimated_cost", 0))),
                lines=request.data.get("lines", []),
                notes=request.data.get("notes", ""),
                created_by=request.user,
            )
            return Response(
                MaintenanceOrderDetailSerializer(order).data,
                status=status.HTTP_201_CREATED,
            )
        except Exception as e:
            return Response({"detail": str(e)}, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=True, methods=["post"], url_path="start")
    def start(self, request, pk=None):
        """Mark order as IN_PROGRESS with actual start time."""
        from django.utils import timezone as tz
        order = self.get_object()
        order.status = MaintenanceOrder.OrderStatus.IN_PROGRESS
        order.actual_start = request.data.get("actual_start") or tz.now()
        order.save(update_fields=["status", "actual_start"])
        return Response(MaintenanceOrderDetailSerializer(order).data)

    @action(detail=True, methods=["post"], url_path="complete")
    def complete(self, request, pk=None):
        """Complete the work order — record work done, consume spares, post voucher."""
        order = self.get_object()
        try:
            warehouse = None
            if request.data.get("warehouse"):
                from apps.stores.models import Warehouse
                warehouse = Warehouse.objects.get(pk=request.data["warehouse"])

            order = services.complete_maintenance_order(
                order=order,
                work_done_remarks=request.data["work_done_remarks"],
                root_cause=request.data.get("root_cause", ""),
                corrective_action=request.data.get("corrective_action", ""),
                actual_start=request.data.get("actual_start"),
                actual_end=request.data.get("actual_end"),
                actual_labour_cost=Decimal(str(request.data.get("actual_labour_cost", 0))),
                actual_other_cost=Decimal(str(request.data.get("actual_other_cost", 0))),
                spare_usages=request.data.get("spare_usages", []),
                warehouse=warehouse,
                completed_by=request.user,
            )
            return Response(MaintenanceOrderDetailSerializer(order).data)
        except Exception as e:
            return Response({"detail": str(e)}, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=True, methods=["post"], url_path="put-on-hold")
    def put_on_hold(self, request, pk=None):
        """Put order on hold (e.g., awaiting spares)."""
        order = self.get_object()
        order.status = MaintenanceOrder.OrderStatus.ON_HOLD
        order.notes = request.data.get("reason", order.notes)
        order.save(update_fields=["status", "notes"])
        return Response(MaintenanceOrderDetailSerializer(order).data)

    @action(detail=False, methods=["get"], url_path="maintenance-report")
    def maintenance_report(self, request):
        """Full maintenance performance report."""
        from apps.core.models import Plant
        plant_id = request.query_params.get("plant")
        if not plant_id:
            return Response(
                {"detail": "plant param required."},
                status=status.HTTP_400_BAD_REQUEST,
            )
        try:
            plant = Plant.objects.get(pk=plant_id)
        except Plant.DoesNotExist:
            return Response({"detail": "Plant not found."}, status=status.HTTP_404_NOT_FOUND)

        filters = {
            k: request.query_params.get(k)
            for k in ("asset_id", "maintenance_type_id", "date_from", "date_to", "status")
            if request.query_params.get(k)
        }
        report = services.get_maintenance_report(plant=plant, filters=filters)
        return Response(report)


# ─── MaintenanceOrderLine ─────────────────────────────────────────

class MaintenanceOrderLineViewSet(viewsets.ModelViewSet):
    queryset = MaintenanceOrderLine.objects.select_related("order")
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action in ("create", "update", "partial_update"):
            return MaintenanceOrderLineCreateSerializer
        return MaintenanceOrderLineSerializer

    def get_queryset(self):
        qs = super().get_queryset()
        if order := self.request.query_params.get("order"):
            qs = qs.filter(order=order)
        return qs


# ─── AMCContract ─────────────────────────────────────────────────

class AMCContractViewSet(viewsets.ModelViewSet):
    queryset = AMCContract.objects.select_related("plant", "vendor").prefetch_related("lines")
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return AMCContractListSerializer
        if self.action in ("create", "update", "partial_update"):
            return AMCContractCreateSerializer
        return AMCContractDetailSerializer

    def get_queryset(self):
        qs = super().get_queryset()
        if plant := self.request.query_params.get("plant"):
            qs = qs.filter(plant=plant)
        if cont_status := self.request.query_params.get("status"):
            qs = qs.filter(status=cont_status)
        if vendor := self.request.query_params.get("vendor"):
            qs = qs.filter(vendor=vendor)
        return qs

    def create(self, request, *args, **kwargs):
        from apps.core.models import Plant
        from apps.masters.models import Vendor
        try:
            plant = Plant.objects.get(pk=request.data["plant"])
            vendor = Vendor.objects.get(pk=request.data["vendor"])

            contract = services.create_amc_contract(
                plant=plant,
                vendor=vendor,
                contract_date=request.data["contract_date"],
                start_date=request.data["start_date"],
                end_date=request.data["end_date"],
                contract_type=request.data["contract_type"],
                contract_value=Decimal(str(request.data["contract_value"])),
                payment_frequency=request.data.get("payment_frequency", "QUARTERLY"),
                payment_amount=Decimal(str(request.data.get("payment_amount", 0))),
                visits_per_year=int(request.data.get("visits_per_year", 4)),
                scope_of_work=request.data.get("scope_of_work", ""),
                exclusions=request.data.get("exclusions", ""),
                asset_lines=request.data.get("asset_lines", []),
                notes=request.data.get("notes", ""),
                created_by=request.user,
            )
            return Response(
                AMCContractDetailSerializer(contract).data,
                status=status.HTTP_201_CREATED,
            )
        except Exception as e:
            return Response({"detail": str(e)}, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=True, methods=["post"], url_path="activate")
    def activate(self, request, pk=None):
        """Activate a draft AMC contract."""
        contract = self.get_object()
        if contract.status != AMCContract.ContractStatus.DRAFT:
            return Response(
                {"detail": f"Cannot activate contract in status '{contract.status}'."},
                status=status.HTTP_400_BAD_REQUEST,
            )
        contract.status = AMCContract.ContractStatus.ACTIVE
        contract.save(update_fields=["status"])
        return Response(AMCContractDetailSerializer(contract).data)

    @action(detail=True, methods=["post"], url_path="record-visit")
    def record_visit(self, request, pk=None):
        """Record a completed AMC visit; advance next_visit_date."""
        from datetime import timedelta
        contract = self.get_object()
        visit_date = request.data.get("visit_date")
        if not visit_date:
            from datetime import date
            visit_date = str(date.today())

        from datetime import date as dt
        try:
            vd = dt.fromisoformat(str(visit_date))
        except ValueError:
            return Response({"detail": "Invalid visit_date."}, status=status.HTTP_400_BAD_REQUEST)

        contract.last_visit_date = vd
        days_between = 365 // max(contract.visits_per_year, 1)
        contract.next_visit_date = vd + timedelta(days=days_between)
        contract.save(update_fields=["last_visit_date", "next_visit_date"])
        return Response(AMCContractDetailSerializer(contract).data)

    @action(detail=False, methods=["get"], url_path="expiring")
    def expiring(self, request):
        """List contracts expiring within 30 days."""
        from datetime import date, timedelta
        today = date.today()
        alert_date = today + timedelta(days=30)
        qs = self.get_queryset().filter(
            status=AMCContract.ContractStatus.ACTIVE,
            end_date__lte=alert_date,
            end_date__gte=today,
        )
        return Response(AMCContractListSerializer(qs, many=True).data)
