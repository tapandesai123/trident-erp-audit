"""Maintenance & AMC API URL Configuration."""
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from apps.maintenance.api.viewsets import (
    MaintenanceTypeViewSet,
    SparePartViewSet,
    MaintenanceScheduleViewSet,
    MaintenanceRequestViewSet,
    MaintenanceOrderViewSet,
    MaintenanceOrderLineViewSet,
    AMCContractViewSet,
)

router = DefaultRouter()
router.register(r"types", MaintenanceTypeViewSet, basename="maint-type")
router.register(r"spare-parts", SparePartViewSet, basename="maint-spare")
router.register(r"schedules", MaintenanceScheduleViewSet, basename="maint-schedule")
router.register(r"requests", MaintenanceRequestViewSet, basename="maint-request")
router.register(r"orders", MaintenanceOrderViewSet, basename="maint-order")
router.register(r"order-lines", MaintenanceOrderLineViewSet, basename="maint-order-line")
router.register(r"amc-contracts", AMCContractViewSet, basename="maint-amc")

urlpatterns = [
    path("", include(router.urls)),
]
