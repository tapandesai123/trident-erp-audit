"""Maintenance & AMC Application Configuration."""
from django.apps import AppConfig


class MaintenanceConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.maintenance"
    verbose_name = "Maintenance & AMC"

    def ready(self):
        pass
