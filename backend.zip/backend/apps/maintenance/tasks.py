"""Maintenance & AMC Module Celery Tasks."""
from celery import shared_task
from django.utils import timezone


@shared_task
def generate_pm_orders():
    """
    Daily: Auto-generate MaintenanceOrders for schedules due today or overdue.
    Only creates an order if no OPEN/IN_PROGRESS order already exists for the asset+schedule.
    """
    from apps.maintenance.models import MaintenanceSchedule, MaintenanceOrder
    from apps.maintenance.services import create_maintenance_order

    today = timezone.now().date()
    due_schedules = MaintenanceSchedule.objects.filter(
        status=MaintenanceSchedule.ScheduleStatus.ACTIVE,
        next_due_date__lte=today,
    ).select_related("asset", "maintenance_type", "assigned_to", "plant")

    created_count = 0
    for schedule in due_schedules:
        # Skip if already has an open order from this schedule
        existing = MaintenanceOrder.objects.filter(
            asset=schedule.asset,
            request__schedule=schedule,
            status__in=["DRAFT", "OPEN", "IN_PROGRESS"],
        ).exists()
        if existing:
            continue

        try:
            from apps.maintenance.services import raise_maintenance_request
            req = raise_maintenance_request(
                plant=schedule.plant,
                asset=schedule.asset,
                title=schedule.title,
                request_type="PREVENTIVE",
                priority="LOW",
                maintenance_type=schedule.maintenance_type,
                schedule=schedule,
                description=schedule.description,
                created_by=schedule.assigned_to,
            )
            create_maintenance_order(
                plant=schedule.plant,
                asset=schedule.asset,
                title=schedule.title,
                request=req,
                maintenance_type=schedule.maintenance_type,
                priority="LOW",
                description=schedule.description,
                assigned_to=schedule.assigned_to,
                estimated_cost=schedule.estimated_cost,
                created_by=schedule.assigned_to,
            )
            created_count += 1
        except Exception:
            continue

    return f"Generated {created_count} PM work orders."


@shared_task
def amc_expiry_alert():
    """
    Weekly: Alert for AMC contracts expiring within 30 days.
    """
    from apps.maintenance.models import AMCContract
    from apps.core.models import Notification
    from django.contrib.auth import get_user_model
    from datetime import timedelta

    User = get_user_model()
    today = timezone.now().date()
    alert_date = today + timedelta(days=30)

    expiring = AMCContract.objects.filter(
        status=AMCContract.ContractStatus.ACTIVE,
        end_date__lte=alert_date,
        end_date__gte=today,
    ).select_related("vendor")

    admins = list(User.objects.filter(is_staff=True, is_active=True)[:5])
    count = 0
    for contract in expiring:
        days_left = (contract.end_date - today).days
        for admin_user in admins:
            Notification.objects.create(
                user=admin_user,
                title=f"AMC Expiring: {contract.contract_number}",
                message=(
                    f"AMC contract {contract.contract_number} with {contract.vendor.name} "
                    f"expires on {contract.end_date} ({days_left} days left)."
                ),
                notification_type="IN_APP",
                module="maintenance",
                resource="AMCContract",
                resource_id=contract.id,
            )
        count += 1
    return f"Sent expiry alerts for {count} AMC contracts."


@shared_task
def amc_visit_reminder():
    """
    Daily: Remind maintenance team of upcoming AMC visits due in 3 days.
    """
    from apps.maintenance.models import AMCContract
    from apps.core.models import Notification
    from django.contrib.auth import get_user_model
    from datetime import timedelta

    User = get_user_model()
    today = timezone.now().date()
    remind_date = today + timedelta(days=3)

    due = AMCContract.objects.filter(
        status=AMCContract.ContractStatus.ACTIVE,
        next_visit_date__lte=remind_date,
        next_visit_date__gte=today,
    ).select_related("vendor")

    admins = list(User.objects.filter(is_staff=True, is_active=True)[:5])
    count = 0
    for contract in due:
        for admin_user in admins:
            Notification.objects.create(
                user=admin_user,
                title=f"AMC Visit Due: {contract.contract_number}",
                message=(
                    f"AMC visit for {contract.contract_number} ({contract.vendor.name}) "
                    f"is scheduled on {contract.next_visit_date}."
                ),
                notification_type="IN_APP",
                module="maintenance",
                resource="AMCContract",
                resource_id=contract.id,
            )
        count += 1
    return f"Sent visit reminders for {count} AMC contracts."


@shared_task
def breakdown_escalation():
    """
    Every 2 hours: Escalate CRITICAL/HIGH maintenance requests open for too long.
    CRITICAL > 2 hours, HIGH > 6 hours.
    """
    from apps.maintenance.models import MaintenanceRequest
    from apps.core.models import Notification
    from django.contrib.auth import get_user_model
    from datetime import timedelta

    User = get_user_model()
    now = timezone.now()
    admins = list(User.objects.filter(is_staff=True, is_active=True)[:5])

    thresholds = {
        "CRITICAL": timedelta(hours=2),
        "HIGH": timedelta(hours=6),
    }

    count = 0
    for priority, threshold in thresholds.items():
        overdue = MaintenanceRequest.objects.filter(
            priority=priority,
            status__in=["OPEN", "ASSIGNED"],
            request_date__lt=now - threshold,
        ).select_related("asset")

        for req in overdue:
            elapsed = now - req.request_date
            elapsed_hrs = round(elapsed.total_seconds() / 3600, 1)
            for admin_user in admins:
                Notification.objects.create(
                    user=admin_user,
                    title=f"ESCALATION [{priority}]: {req.request_number}",
                    message=(
                        f"{priority} request {req.request_number} on asset "
                        f"{req.asset.asset_number} has been open for {elapsed_hrs} hours. "
                        f"Immediate action required."
                    ),
                    notification_type="IN_APP",
                    module="maintenance",
                    resource="MaintenanceRequest",
                    resource_id=req.id,
                )
            count += 1
    return f"Escalated {count} overdue maintenance requests."


@shared_task
def expire_amc_contracts():
    """
    Daily: Mark AMC contracts whose end_date has passed as EXPIRED.
    """
    from apps.maintenance.models import AMCContract
    today = timezone.now().date()
    expired = AMCContract.objects.filter(
        status=AMCContract.ContractStatus.ACTIVE,
        end_date__lt=today,
    ).update(status=AMCContract.ContractStatus.EXPIRED)
    return f"Expired {expired} AMC contracts."
