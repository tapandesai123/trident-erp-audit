"""
Maintenance & AMC Module Models — Section 17

Models:
  MaintenanceType       — Category of maintenance task (electrical, mechanical, civil…)
  MaintenanceSchedule   — Preventive maintenance calendar entry per asset
  MaintenanceRequest    — Breakdown or routine request raised by any user
  MaintenanceOrder      — Work order (converted from request or direct)
  MaintenanceOrderLine  — Task / labour / material line on a work order
  SparePart             — Spare part master (plant-level catalogue)
  SparePartUsage        — Spare consumption per order → stores.StockIssue
  AMCContract           — Annual Maintenance Contract with a vendor
  AMCContractLine       — Asset covered under an AMC contract
"""
import uuid
from decimal import Decimal
from django.conf import settings
from django.db import models
from django.utils import timezone
from apps.core.models import TimeStampedModel, UUIDModel, Plant


# ═══════════════════════════════════════════════════════════════════
# MAINTENANCE TYPE
# ═══════════════════════════════════════════════════════════════════

class MaintenanceType(UUIDModel, TimeStampedModel):
    """Category of maintenance task."""

    plant = models.ForeignKey(Plant, on_delete=models.CASCADE, related_name="maintenance_types")
    code = models.CharField(max_length=20)
    name = models.CharField(max_length=100)
    description = models.TextField(blank=True)
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ["plant", "code"]
        unique_together = [("plant", "code")]

    def __str__(self):
        return f"{self.code} — {self.name}"


# ═══════════════════════════════════════════════════════════════════
# SPARE PART
# ═══════════════════════════════════════════════════════════════════

class SparePart(UUIDModel, TimeStampedModel):
    """Spare part master — plant-level catalogue for maintenance."""

    plant = models.ForeignKey(Plant, on_delete=models.CASCADE, related_name="spare_parts")
    part_number = models.CharField(max_length=50)
    name = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    uom = models.CharField(max_length=20, default="NOS")
    # Link to masters.Item for store stock tracking
    item = models.ForeignKey(
        "masters.Item", on_delete=models.SET_NULL,
        null=True, blank=True, related_name="spare_parts",
        help_text="Link to masters.Item for store inventory"
    )
    unit_cost = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    min_stock_qty = models.DecimalField(max_digits=12, decimal_places=3, default=0)
    is_active = models.BooleanField(default=True)
    notes = models.TextField(blank=True)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="spare_parts_created"
    )

    class Meta:
        ordering = ["plant", "part_number"]
        unique_together = [("plant", "part_number")]

    def __str__(self):
        return f"{self.part_number} — {self.name}"


# ═══════════════════════════════════════════════════════════════════
# MAINTENANCE SCHEDULE
# ═══════════════════════════════════════════════════════════════════

class MaintenanceSchedule(UUIDModel, TimeStampedModel):
    """
    Preventive maintenance calendar entry for an asset.
    Drives auto-generation of MaintenanceOrders via Celery.
    """

    class FrequencyUnit(models.TextChoices):
        DAILY   = "DAILY",   "Daily"
        WEEKLY  = "WEEKLY",  "Weekly"
        MONTHLY = "MONTHLY", "Monthly"
        YEARLY  = "YEARLY",  "Yearly"
        HOURS   = "HOURS",   "Running Hours"

    class ScheduleStatus(models.TextChoices):
        ACTIVE    = "ACTIVE",    "Active"
        SUSPENDED = "SUSPENDED", "Suspended"
        COMPLETED = "COMPLETED", "Completed"

    plant = models.ForeignKey(Plant, on_delete=models.CASCADE, related_name="maintenance_schedules")
    asset = models.ForeignKey(
        "assets.Asset", on_delete=models.CASCADE, related_name="maintenance_schedules"
    )
    maintenance_type = models.ForeignKey(
        MaintenanceType, on_delete=models.PROTECT, related_name="schedules"
    )
    title = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    frequency_value = models.PositiveIntegerField(help_text="e.g. 3 for every 3 months")
    frequency_unit = models.CharField(
        max_length=10, choices=FrequencyUnit.choices, default=FrequencyUnit.MONTHLY
    )
    last_done_date = models.DateField(null=True, blank=True)
    next_due_date = models.DateField(null=True, blank=True)
    assigned_to = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="assigned_schedules"
    )
    estimated_duration_hours = models.DecimalField(
        max_digits=6, decimal_places=2, null=True, blank=True
    )
    estimated_cost = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    status = models.CharField(
        max_length=15, choices=ScheduleStatus.choices, default=ScheduleStatus.ACTIVE
    )
    notes = models.TextField(blank=True)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="maintenance_schedules_created"
    )

    class Meta:
        ordering = ["next_due_date", "asset"]

    def __str__(self):
        return f"{self.asset.asset_number} — {self.title} (every {self.frequency_value} {self.frequency_unit})"


# ═══════════════════════════════════════════════════════════════════
# MAINTENANCE REQUEST
# ═══════════════════════════════════════════════════════════════════

class MaintenanceRequest(UUIDModel, TimeStampedModel):
    """Breakdown or routine maintenance request raised by any user."""

    class RequestType(models.TextChoices):
        BREAKDOWN   = "BREAKDOWN",   "Breakdown"
        PREVENTIVE  = "PREVENTIVE",  "Preventive (PM)"
        ROUTINE     = "ROUTINE",     "Routine"
        CORRECTIVE  = "CORRECTIVE",  "Corrective"
        IMPROVEMENT = "IMPROVEMENT", "Improvement"
        INSPECTION  = "INSPECTION",  "Inspection"

    class Priority(models.TextChoices):
        CRITICAL = "CRITICAL", "Critical — Immediate"
        HIGH     = "HIGH",     "High — Within 4 hrs"
        MEDIUM   = "MEDIUM",   "Medium — Within 24 hrs"
        LOW      = "LOW",      "Low — Scheduled"

    class RequestStatus(models.TextChoices):
        OPEN       = "OPEN",       "Open"
        ASSIGNED   = "ASSIGNED",   "Assigned"
        IN_PROGRESS= "IN_PROGRESS","In Progress"
        ON_HOLD    = "ON_HOLD",    "On Hold — Spares Awaited"
        COMPLETED  = "COMPLETED",  "Completed"
        CANCELLED  = "CANCELLED",  "Cancelled"
        REJECTED   = "REJECTED",   "Rejected"

    plant = models.ForeignKey(Plant, on_delete=models.CASCADE, related_name="maintenance_requests")
    request_number = models.CharField(max_length=50, unique=True)
    request_date = models.DateTimeField(default=timezone.now)
    request_type = models.CharField(
        max_length=15, choices=RequestType.choices, default=RequestType.BREAKDOWN
    )
    priority = models.CharField(
        max_length=10, choices=Priority.choices, default=Priority.MEDIUM
    )
    status = models.CharField(
        max_length=15, choices=RequestStatus.choices, default=RequestStatus.OPEN
    )

    asset = models.ForeignKey(
        "assets.Asset", on_delete=models.PROTECT, related_name="maintenance_requests"
    )
    maintenance_type = models.ForeignKey(
        MaintenanceType, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="requests"
    )
    schedule = models.ForeignKey(
        MaintenanceSchedule, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="requests",
        help_text="Linked schedule if raised from PM"
    )

    # Problem description
    title = models.CharField(max_length=300)
    description = models.TextField(blank=True)
    reported_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="maintenance_requests_reported"
    )

    # Assignment
    assigned_to = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="maintenance_requests_assigned"
    )
    assigned_at = models.DateTimeField(null=True, blank=True)

    # Downtime tracking
    downtime_start = models.DateTimeField(null=True, blank=True)
    downtime_end = models.DateTimeField(null=True, blank=True)

    rejection_reason = models.CharField(max_length=300, blank=True)
    notes = models.TextField(blank=True)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="maintenance_requests_created"
    )

    class Meta:
        ordering = ["-request_date"]

    def __str__(self):
        return f"{self.request_number} — {self.title[:60]} [{self.priority}]"

    @property
    def downtime_hours(self) -> Decimal:
        if self.downtime_start and self.downtime_end:
            delta = self.downtime_end - self.downtime_start
            return Decimal(str(round(delta.total_seconds() / 3600, 2)))
        return Decimal("0")


# ═══════════════════════════════════════════════════════════════════
# MAINTENANCE ORDER
# ═══════════════════════════════════════════════════════════════════

class MaintenanceOrder(UUIDModel, TimeStampedModel):
    """Work order — converted from a request or raised directly."""

    class OrderStatus(models.TextChoices):
        DRAFT      = "DRAFT",      "Draft"
        OPEN       = "OPEN",       "Open"
        IN_PROGRESS= "IN_PROGRESS","In Progress"
        ON_HOLD    = "ON_HOLD",    "On Hold"
        COMPLETED  = "COMPLETED",  "Completed"
        CLOSED     = "CLOSED",     "Closed"
        CANCELLED  = "CANCELLED",  "Cancelled"

    plant = models.ForeignKey(Plant, on_delete=models.CASCADE, related_name="maintenance_orders")
    order_number = models.CharField(max_length=50, unique=True)
    order_date = models.DateField()
    status = models.CharField(
        max_length=15, choices=OrderStatus.choices, default=OrderStatus.DRAFT
    )

    asset = models.ForeignKey(
        "assets.Asset", on_delete=models.PROTECT, related_name="maintenance_orders"
    )
    request = models.ForeignKey(
        MaintenanceRequest, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="orders"
    )
    maintenance_type = models.ForeignKey(
        MaintenanceType, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="orders"
    )

    title = models.CharField(max_length=300)
    description = models.TextField(blank=True)
    priority = models.CharField(
        max_length=10,
        choices=MaintenanceRequest.Priority.choices,
        default=MaintenanceRequest.Priority.MEDIUM,
    )

    # Scheduling
    scheduled_start = models.DateTimeField(null=True, blank=True)
    scheduled_end = models.DateTimeField(null=True, blank=True)
    actual_start = models.DateTimeField(null=True, blank=True)
    actual_end = models.DateTimeField(null=True, blank=True)

    # Assignment
    assigned_to = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="maintenance_orders_assigned"
    )

    # Costs (maintained by services)
    estimated_cost = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    actual_labour_cost = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    actual_spare_cost = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    actual_other_cost = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    total_actual_cost = models.DecimalField(max_digits=14, decimal_places=2, default=0)

    # Completion
    work_done_remarks = models.TextField(blank=True)
    root_cause = models.TextField(blank=True)
    corrective_action = models.TextField(blank=True)
    completed_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="maintenance_orders_completed"
    )
    completed_at = models.DateTimeField(null=True, blank=True)

    # Accounts integration
    voucher = models.ForeignKey(
        "accounts.Voucher", on_delete=models.SET_NULL,
        null=True, blank=True, related_name="maintenance_orders"
    )

    notes = models.TextField(blank=True)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="maintenance_orders_created"
    )

    class Meta:
        ordering = ["-order_date", "-created_at"]

    def __str__(self):
        return f"{self.order_number} — {self.title[:60]} [{self.status}]"

    @property
    def actual_duration_hours(self) -> Decimal:
        if self.actual_start and self.actual_end:
            delta = self.actual_end - self.actual_start
            return Decimal(str(round(delta.total_seconds() / 3600, 2)))
        return Decimal("0")


# ═══════════════════════════════════════════════════════════════════
# MAINTENANCE ORDER LINE
# ═══════════════════════════════════════════════════════════════════

class MaintenanceOrderLine(UUIDModel, TimeStampedModel):
    """Task, labour, or material line on a maintenance work order."""

    class LineType(models.TextChoices):
        TASK     = "TASK",     "Task / Activity"
        LABOUR   = "LABOUR",   "Labour"
        MATERIAL = "MATERIAL", "Material / Spare"
        OTHER    = "OTHER",    "Other"

    order = models.ForeignKey(
        MaintenanceOrder, on_delete=models.CASCADE, related_name="lines"
    )
    line_number = models.PositiveIntegerField(default=1)
    line_type = models.CharField(
        max_length=10, choices=LineType.choices, default=LineType.TASK
    )
    description = models.CharField(max_length=300)
    quantity = models.DecimalField(max_digits=12, decimal_places=3, default=1)
    uom = models.CharField(max_length=20, blank=True)
    unit_cost = models.DecimalField(max_digits=14, decimal_places=4, default=0)
    line_total = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    is_completed = models.BooleanField(default=False)
    completion_notes = models.CharField(max_length=300, blank=True)

    class Meta:
        ordering = ["order", "line_number"]

    def __str__(self):
        return f"{self.order.order_number} L{self.line_number} — {self.description[:60]}"


# ═══════════════════════════════════════════════════════════════════
# SPARE PART USAGE
# ═══════════════════════════════════════════════════════════════════

class SparePartUsage(UUIDModel, TimeStampedModel):
    """
    Spare part consumed during a maintenance order.
    Links to stores.StockIssue for inventory deduction.
    """

    order = models.ForeignKey(
        MaintenanceOrder, on_delete=models.CASCADE, related_name="spare_usages"
    )
    spare_part = models.ForeignKey(
        SparePart, on_delete=models.PROTECT, related_name="usages"
    )
    quantity_used = models.DecimalField(max_digits=12, decimal_places=3)
    unit_cost = models.DecimalField(max_digits=14, decimal_places=4, default=0)
    total_cost = models.DecimalField(max_digits=14, decimal_places=2, default=0)

    # Stock issue link (set by complete_maintenance_order service)
    stock_issue = models.ForeignKey(
        "stores.StockIssue", on_delete=models.SET_NULL,
        null=True, blank=True, related_name="spare_part_usages"
    )
    stock_issue_line_ref = models.CharField(
        max_length=50, blank=True, help_text="Line reference in stock issue"
    )

    remarks = models.CharField(max_length=300, blank=True)
    recorded_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="spare_usages_recorded"
    )

    class Meta:
        ordering = ["order", "spare_part"]

    def __str__(self):
        return f"{self.order.order_number} — {self.spare_part.name} × {self.quantity_used}"


# ═══════════════════════════════════════════════════════════════════
# AMC CONTRACT
# ═══════════════════════════════════════════════════════════════════

class AMCContract(UUIDModel, TimeStampedModel):
    """Annual Maintenance Contract with an external vendor."""

    class ContractStatus(models.TextChoices):
        DRAFT   = "DRAFT",   "Draft"
        ACTIVE  = "ACTIVE",  "Active"
        EXPIRED = "EXPIRED", "Expired"
        RENEWED = "RENEWED", "Renewed"
        CANCELLED="CANCELLED","Cancelled"

    class ContractType(models.TextChoices):
        COMPREHENSIVE = "COMPREHENSIVE", "Comprehensive (Parts + Labour)"
        LABOUR_ONLY   = "LABOUR_ONLY",   "Labour Only"
        PARTS_ONLY    = "PARTS_ONLY",    "Parts Only"
        INSPECTION    = "INSPECTION",    "Inspection Only"

    plant = models.ForeignKey(Plant, on_delete=models.CASCADE, related_name="amc_contracts")
    contract_number = models.CharField(max_length=50, unique=True)
    contract_date = models.DateField()
    status = models.CharField(
        max_length=15, choices=ContractStatus.choices, default=ContractStatus.DRAFT
    )
    contract_type = models.CharField(
        max_length=20, choices=ContractType.choices, default=ContractType.COMPREHENSIVE
    )

    vendor = models.ForeignKey(
        "masters.Vendor", on_delete=models.PROTECT, related_name="amc_contracts"
    )
    vendor_contact = models.CharField(max_length=100, blank=True)
    vendor_phone = models.CharField(max_length=20, blank=True)

    start_date = models.DateField()
    end_date = models.DateField()
    contract_value = models.DecimalField(max_digits=16, decimal_places=2)

    # Payment terms
    payment_frequency = models.CharField(
        max_length=20,
        choices=[
            ("MONTHLY", "Monthly"), ("QUARTERLY", "Quarterly"),
            ("HALF_YEARLY", "Half-Yearly"), ("ANNUAL", "Annual"),
            ("ON_COMPLETION", "On Completion"),
        ],
        default="QUARTERLY",
    )
    payment_amount = models.DecimalField(
        max_digits=14, decimal_places=2, default=0,
        help_text="Amount per payment instalment"
    )

    # PM schedule settings (for auto-generating orders)
    visits_per_year = models.PositiveIntegerField(default=4)
    last_visit_date = models.DateField(null=True, blank=True)
    next_visit_date = models.DateField(null=True, blank=True)

    scope_of_work = models.TextField(blank=True)
    exclusions = models.TextField(blank=True)
    notes = models.TextField(blank=True)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="amc_contracts_created"
    )

    class Meta:
        ordering = ["-start_date"]

    def __str__(self):
        return f"{self.contract_number} — {self.vendor.name} ({self.status})"


# ═══════════════════════════════════════════════════════════════════
# AMC CONTRACT LINE
# ═══════════════════════════════════════════════════════════════════

class AMCContractLine(UUIDModel, TimeStampedModel):
    """Asset covered under an AMC contract."""

    contract = models.ForeignKey(
        AMCContract, on_delete=models.CASCADE, related_name="lines"
    )
    line_number = models.PositiveIntegerField(default=1)
    asset = models.ForeignKey(
        "assets.Asset", on_delete=models.PROTECT, related_name="amc_lines"
    )
    description = models.CharField(max_length=300, blank=True)
    # Per-asset value split (informational)
    allocated_value = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    notes = models.CharField(max_length=300, blank=True)

    class Meta:
        ordering = ["contract", "line_number"]
        unique_together = [("contract", "asset")]

    def __str__(self):
        return f"{self.contract.contract_number} — {self.asset.asset_number}"
