"""
Maintenance & AMC Module Tests — Section 17

Covers:
  - MaintenanceType creation + uniqueness
  - SparePart creation
  - create_maintenance_schedule() auto next_due_date computation
  - raise_maintenance_request() BREAKDOWN → asset UNDER_MAINTENANCE
  - raise_maintenance_request() non-breakdown does not change asset status
  - create_maintenance_order() from request; request status → ASSIGNED
  - complete_maintenance_order() cost totals, asset → ACTIVE, voucher created
  - complete_maintenance_order() double-complete raises ValueError
  - create_amc_contract() auto next_visit_date; asset.amc_expiry updated
  - get_maintenance_report() structure and counts
  - API: schedule list/create/overdue
  - API: request create (BREAKDOWN) + assign
  - API: order create + start + complete
  - API: AMC contract create + activate + record-visit + expiring
  - API: maintenance-report endpoint
  - Celery: generate_pm_orders
  - Celery: amc_expiry_alert
  - Celery: expire_amc_contracts
  - Celery: breakdown_escalation
"""
from datetime import date, timedelta
from decimal import Decimal
from django.test import TestCase
from django.contrib.auth import get_user_model
from rest_framework.test import APIClient
from rest_framework import status as http_status

User = get_user_model()


# ─── Fixtures ─────────────────────────────────────────────────────

def _base():
    from apps.core.models import Plant
    user = User.objects.create_user(username="maint_user", password="pass", is_staff=True)
    plant = Plant.objects.create(code="MNT", name="Maintenance Plant")
    return user, plant


def _make_asset(plant, user):
    from apps.assets.models import Asset, AssetCategory
    cat = AssetCategory.objects.create(
        plant=plant, code="MACH", name="Machinery",
        depreciation_method="SLM", useful_life_years=10,
    )
    return Asset.objects.create(
        plant=plant, asset_number="AST-001", name="CNC Machine",
        category=cat, status="ACTIVE",
        purchase_date=date.today(), purchase_cost=Decimal("500000"),
        created_by=user,
    )


def _make_type(plant):
    from apps.maintenance.models import MaintenanceType
    return MaintenanceType.objects.create(
        plant=plant, code="MECH", name="Mechanical"
    )


def _make_spare(plant, user):
    from apps.maintenance.models import SparePart
    return SparePart.objects.create(
        plant=plant, part_number="SP-001", name="Oil Filter",
        uom="NOS", unit_cost=Decimal("250.00"), created_by=user,
    )


def _make_vendor(plant):
    from apps.masters.models import Vendor, VendorGroup
    grp = VendorGroup.objects.create(code="AMC", name="AMC Vendors")
    return Vendor.objects.create(
        plant=plant, vendor_code="V001", name="TechServ Pvt Ltd",
        vendor_type="SUPPLIER", vendor_group=grp,
    )


# ═══════════════════════════════════════════════════════════════════
# MODEL / SERVICE TESTS
# ═══════════════════════════════════════════════════════════════════

class MaintenanceTypeTest(TestCase):
    def setUp(self):
        self.user, self.plant = _base()

    def test_create_maintenance_type(self):
        mt = _make_type(self.plant)
        self.assertEqual(mt.code, "MECH")
        self.assertTrue(mt.is_active)

    def test_unique_code_per_plant(self):
        from apps.maintenance.models import MaintenanceType
        from django.db import IntegrityError
        _make_type(self.plant)
        with self.assertRaises(IntegrityError):
            MaintenanceType.objects.create(
                plant=self.plant, code="MECH", name="Duplicate"
            )


class SparePartTest(TestCase):
    def setUp(self):
        self.user, self.plant = _base()

    def test_create_spare_part(self):
        sp = _make_spare(self.plant, self.user)
        self.assertEqual(sp.part_number, "SP-001")
        self.assertEqual(sp.unit_cost, Decimal("250.00"))


class ScheduleServiceTest(TestCase):
    def setUp(self):
        self.user, self.plant = _base()
        self.asset = _make_asset(self.plant, self.user)
        self.mtype = _make_type(self.plant)

    def test_create_schedule_auto_next_due(self):
        from apps.maintenance.services import create_maintenance_schedule
        last = date.today() - timedelta(days=25)
        schedule = create_maintenance_schedule(
            plant=self.plant,
            asset=self.asset,
            maintenance_type=self.mtype,
            title="Monthly Lubrication",
            frequency_value=1,
            frequency_unit="MONTHLY",
            last_done_date=last,
            created_by=self.user,
        )
        # 1 month ≈ 30 days from last
        expected_next = last + timedelta(days=30)
        self.assertEqual(schedule.next_due_date, expected_next)

    def test_create_schedule_explicit_next_due(self):
        from apps.maintenance.services import create_maintenance_schedule
        explicit_next = date.today() + timedelta(days=14)
        schedule = create_maintenance_schedule(
            plant=self.plant,
            asset=self.asset,
            maintenance_type=self.mtype,
            title="Bi-weekly Check",
            frequency_value=2,
            frequency_unit="WEEKLY",
            next_due_date=explicit_next,
            created_by=self.user,
        )
        self.assertEqual(schedule.next_due_date, explicit_next)

    def test_schedule_yearly_frequency(self):
        from apps.maintenance.services import create_maintenance_schedule
        last = date.today() - timedelta(days=10)
        schedule = create_maintenance_schedule(
            plant=self.plant, asset=self.asset,
            maintenance_type=self.mtype,
            title="Annual Overhaul",
            frequency_value=1, frequency_unit="YEARLY",
            last_done_date=last, created_by=self.user,
        )
        self.assertEqual(schedule.next_due_date, last + timedelta(days=365))


class MaintenanceRequestServiceTest(TestCase):
    def setUp(self):
        self.user, self.plant = _base()
        self.asset = _make_asset(self.plant, self.user)
        self.mtype = _make_type(self.plant)

    def test_breakdown_request_marks_asset_under_maintenance(self):
        from apps.maintenance.services import raise_maintenance_request
        raise_maintenance_request(
            plant=self.plant, asset=self.asset,
            title="Motor seized", request_type="BREAKDOWN", priority="CRITICAL",
            created_by=self.user,
        )
        self.asset.refresh_from_db()
        self.assertEqual(self.asset.status, "UNDER_MAINTENANCE")

    def test_non_breakdown_does_not_change_asset_status(self):
        from apps.maintenance.services import raise_maintenance_request
        raise_maintenance_request(
            plant=self.plant, asset=self.asset,
            title="Routine check", request_type="ROUTINE", priority="LOW",
            created_by=self.user,
        )
        self.asset.refresh_from_db()
        self.assertEqual(self.asset.status, "ACTIVE")

    def test_request_number_sequential(self):
        from apps.maintenance.services import raise_maintenance_request
        r1 = raise_maintenance_request(
            plant=self.plant, asset=self.asset,
            title="R1", request_type="ROUTINE", created_by=self.user,
        )
        r2 = raise_maintenance_request(
            plant=self.plant, asset=self.asset,
            title="R2", request_type="ROUTINE", created_by=self.user,
        )
        self.assertNotEqual(r1.request_number, r2.request_number)
        self.assertTrue(r1.request_number.startswith("MRQ/"))


class MaintenanceOrderServiceTest(TestCase):
    def setUp(self):
        self.user, self.plant = _base()
        self.asset = _make_asset(self.plant, self.user)
        self.mtype = _make_type(self.plant)
        from apps.maintenance.services import raise_maintenance_request
        self.req = raise_maintenance_request(
            plant=self.plant, asset=self.asset,
            title="Bearing replacement", request_type="BREAKDOWN",
            priority="HIGH", created_by=self.user,
        )

    def test_create_order_from_request(self):
        from apps.maintenance.services import create_maintenance_order
        order = create_maintenance_order(
            plant=self.plant, asset=self.asset,
            title="Replace Bearing", request=self.req,
            maintenance_type=self.mtype,
            created_by=self.user,
        )
        self.assertTrue(order.order_number.startswith("MWO/"))
        # Request should be ASSIGNED
        self.req.refresh_from_db()
        self.assertEqual(self.req.status, "ASSIGNED")

    def test_order_with_lines(self):
        from apps.maintenance.services import create_maintenance_order
        order = create_maintenance_order(
            plant=self.plant, asset=self.asset,
            title="Overhaul", request=self.req,
            lines=[
                {"line_type": "LABOUR", "description": "Technician 4hrs", "quantity": 4, "uom": "HRS", "unit_cost": 500},
                {"line_type": "TASK", "description": "Inspect and clean", "quantity": 1},
            ],
            created_by=self.user,
        )
        self.assertEqual(order.lines.count(), 2)

    def test_complete_order_cost_calculation(self):
        from apps.maintenance.services import create_maintenance_order, complete_maintenance_order
        spare = _make_spare(self.plant, self.user)
        order = create_maintenance_order(
            plant=self.plant, asset=self.asset,
            title="Full Repair", request=self.req,
            created_by=self.user,
        )
        order = complete_maintenance_order(
            order=order,
            work_done_remarks="Replaced bearing and lubricated",
            actual_labour_cost=Decimal("2000"),
            actual_other_cost=Decimal("500"),
            spare_usages=[{
                "spare_part_id": str(spare.id),
                "quantity_used": "2",
                "unit_cost": "250",
            }],
            completed_by=self.user,
        )
        # spare cost = 2 × 250 = 500; total = 2000 + 500 + 500 = 3000
        self.assertEqual(order.actual_spare_cost, Decimal("500.00"))
        self.assertEqual(order.total_actual_cost, Decimal("3000.00"))
        self.assertEqual(order.status, "COMPLETED")

    def test_complete_order_restores_asset_active(self):
        from apps.maintenance.services import create_maintenance_order, complete_maintenance_order
        order = create_maintenance_order(
            plant=self.plant, asset=self.asset,
            title="Fix", request=self.req, created_by=self.user,
        )
        complete_maintenance_order(
            order=order, work_done_remarks="Done", completed_by=self.user,
        )
        self.asset.refresh_from_db()
        self.assertEqual(self.asset.status, "ACTIVE")

    def test_double_complete_raises_error(self):
        from apps.maintenance.services import create_maintenance_order, complete_maintenance_order
        order = create_maintenance_order(
            plant=self.plant, asset=self.asset,
            title="Fix2", request=self.req, created_by=self.user,
        )
        complete_maintenance_order(order=order, work_done_remarks="Done", completed_by=self.user)
        with self.assertRaises(ValueError):
            complete_maintenance_order(order=order, work_done_remarks="Again", completed_by=self.user)


class AMCContractServiceTest(TestCase):
    def setUp(self):
        self.user, self.plant = _base()
        self.asset = _make_asset(self.plant, self.user)
        self.vendor = _make_vendor(self.plant)

    def test_create_amc_contract(self):
        from apps.maintenance.services import create_amc_contract
        start = date.today()
        end = start + timedelta(days=365)
        contract = create_amc_contract(
            plant=self.plant, vendor=self.vendor,
            contract_date=date.today(),
            start_date=start, end_date=end,
            contract_type="COMPREHENSIVE",
            contract_value=Decimal("120000"),
            visits_per_year=4,
            asset_lines=[{
                "asset_id": str(self.asset.id),
                "description": "CNC Machine annual maintenance",
                "allocated_value": "120000",
            }],
            created_by=self.user,
        )
        self.assertTrue(contract.contract_number.startswith("AMC/"))
        self.assertEqual(contract.lines.count(), 1)
        # Asset amc_expiry updated
        self.asset.refresh_from_db()
        self.assertEqual(self.asset.amc_expiry, end)

    def test_next_visit_date_computed(self):
        from apps.maintenance.services import create_amc_contract
        start = date.today()
        contract = create_amc_contract(
            plant=self.plant, vendor=self.vendor,
            contract_date=date.today(),
            start_date=start, end_date=start + timedelta(days=365),
            contract_type="LABOUR_ONLY",
            contract_value=Decimal("50000"),
            visits_per_year=4,  # every 91 days
            created_by=self.user,
        )
        expected = start + timedelta(days=365 // 4)
        self.assertEqual(contract.next_visit_date, expected)


class MaintenanceReportServiceTest(TestCase):
    def setUp(self):
        self.user, self.plant = _base()
        self.asset = _make_asset(self.plant, self.user)
        self.mtype = _make_type(self.plant)
        from apps.maintenance.services import (
            raise_maintenance_request, create_maintenance_order, complete_maintenance_order
        )
        req = raise_maintenance_request(
            plant=self.plant, asset=self.asset,
            title="Test BD", request_type="BREAKDOWN",
            created_by=self.user,
        )
        order = create_maintenance_order(
            plant=self.plant, asset=self.asset, title="Fix",
            request=req, created_by=self.user,
        )
        complete_maintenance_order(
            order=order, work_done_remarks="Fixed",
            actual_labour_cost=Decimal("1500"),
            completed_by=self.user,
        )

    def test_report_structure(self):
        from apps.maintenance.services import get_maintenance_report
        report = get_maintenance_report(plant=self.plant)
        self.assertIn("total_orders", report)
        self.assertIn("completed_orders", report)
        self.assertIn("total_actual_cost", report)
        self.assertIn("overdue_schedules", report)
        self.assertIn("by_asset", report)
        self.assertEqual(report["total_orders"], 1)
        self.assertEqual(report["completed_orders"], 1)


# ═══════════════════════════════════════════════════════════════════
# API TESTS
# ═══════════════════════════════════════════════════════════════════

class MaintenanceAPITest(TestCase):
    def setUp(self):
        self.user, self.plant = _base()
        self.client = APIClient()
        self.client.force_authenticate(user=self.user)
        self.asset = _make_asset(self.plant, self.user)
        self.mtype = _make_type(self.plant)
        self.vendor = _make_vendor(self.plant)

    def test_list_types(self):
        resp = self.client.get("/api/v1/maintenance/types/")
        self.assertEqual(resp.status_code, http_status.HTTP_200_OK)

    def test_create_schedule_api(self):
        resp = self.client.post("/api/v1/maintenance/schedules/", {
            "plant": str(self.plant.id),
            "asset": str(self.asset.id),
            "maintenance_type": str(self.mtype.id),
            "title": "Weekly Inspection",
            "frequency_value": 1,
            "frequency_unit": "WEEKLY",
        }, format="json")
        self.assertEqual(resp.status_code, http_status.HTTP_201_CREATED)
        self.assertIn("next_due_date", resp.data)

    def test_overdue_schedules_api(self):
        from apps.maintenance.services import create_maintenance_schedule
        create_maintenance_schedule(
            plant=self.plant, asset=self.asset, maintenance_type=self.mtype,
            title="Overdue Task", frequency_value=1, frequency_unit="MONTHLY",
            next_due_date=date.today() - timedelta(days=5),
            created_by=self.user,
        )
        resp = self.client.get("/api/v1/maintenance/schedules/overdue/")
        self.assertEqual(resp.status_code, http_status.HTTP_200_OK)
        self.assertGreaterEqual(len(resp.data), 1)

    def test_create_request_breakdown_api(self):
        resp = self.client.post("/api/v1/maintenance/requests/", {
            "plant": str(self.plant.id),
            "asset": str(self.asset.id),
            "title": "Hydraulic leak",
            "request_type": "BREAKDOWN",
            "priority": "CRITICAL",
        }, format="json")
        self.assertEqual(resp.status_code, http_status.HTTP_201_CREATED)
        self.assertEqual(resp.data["priority"], "CRITICAL")
        # Asset should now be UNDER_MAINTENANCE
        self.asset.refresh_from_db()
        self.assertEqual(self.asset.status, "UNDER_MAINTENANCE")

    def test_assign_request_api(self):
        from apps.maintenance.services import raise_maintenance_request
        req = raise_maintenance_request(
            plant=self.plant, asset=self.asset, title="Assign Me",
            request_type="ROUTINE", created_by=self.user,
        )
        resp = self.client.post(
            f"/api/v1/maintenance/requests/{req.id}/assign/",
            {"assigned_to": str(self.user.id)}, format="json"
        )
        self.assertEqual(resp.status_code, http_status.HTTP_200_OK)
        self.assertEqual(resp.data["status"], "ASSIGNED")

    def test_create_order_api(self):
        from apps.maintenance.services import raise_maintenance_request
        req = raise_maintenance_request(
            plant=self.plant, asset=self.asset, title="BD",
            request_type="BREAKDOWN", created_by=self.user,
        )
        resp = self.client.post("/api/v1/maintenance/orders/", {
            "plant": str(self.plant.id),
            "asset": str(self.asset.id),
            "request": str(req.id),
            "title": "Replace Bearing",
            "priority": "HIGH",
        }, format="json")
        self.assertEqual(resp.status_code, http_status.HTTP_201_CREATED)
        self.assertTrue(resp.data["order_number"].startswith("MWO/"))

    def test_start_and_complete_order_api(self):
        from apps.maintenance.services import raise_maintenance_request, create_maintenance_order
        req = raise_maintenance_request(
            plant=self.plant, asset=self.asset, title="BD2",
            request_type="BREAKDOWN", created_by=self.user,
        )
        order = create_maintenance_order(
            plant=self.plant, asset=self.asset, title="Fix",
            request=req, created_by=self.user,
        )
        # Start
        resp = self.client.post(f"/api/v1/maintenance/orders/{order.id}/start/", {}, format="json")
        self.assertEqual(resp.status_code, http_status.HTTP_200_OK)
        self.assertEqual(resp.data["status"], "IN_PROGRESS")
        # Complete
        resp2 = self.client.post(f"/api/v1/maintenance/orders/{order.id}/complete/", {
            "work_done_remarks": "Bearing replaced",
            "actual_labour_cost": "1800",
        }, format="json")
        self.assertEqual(resp2.status_code, http_status.HTTP_200_OK)
        self.assertEqual(resp2.data["status"], "COMPLETED")

    def test_maintenance_report_api(self):
        resp = self.client.get(f"/api/v1/maintenance/orders/maintenance-report/?plant={self.plant.id}")
        self.assertEqual(resp.status_code, http_status.HTTP_200_OK)
        self.assertIn("total_orders", resp.data)
        self.assertIn("overdue_schedules", resp.data)

    def test_create_amc_contract_api(self):
        start = date.today()
        end = start + timedelta(days=365)
        resp = self.client.post("/api/v1/maintenance/amc-contracts/", {
            "plant": str(self.plant.id),
            "vendor": str(self.vendor.id),
            "contract_date": str(date.today()),
            "start_date": str(start),
            "end_date": str(end),
            "contract_type": "COMPREHENSIVE",
            "contract_value": "240000",
            "visits_per_year": 4,
            "asset_lines": [{"asset_id": str(self.asset.id), "allocated_value": "240000"}],
        }, format="json")
        self.assertEqual(resp.status_code, http_status.HTTP_201_CREATED)
        self.assertTrue(resp.data["contract_number"].startswith("AMC/"))
        return resp.data["id"]

    def test_activate_amc_contract_api(self):
        contract_id = self.test_create_amc_contract_api()
        resp = self.client.post(f"/api/v1/maintenance/amc-contracts/{contract_id}/activate/", {}, format="json")
        self.assertEqual(resp.status_code, http_status.HTTP_200_OK)
        self.assertEqual(resp.data["status"], "ACTIVE")

    def test_record_visit_amc_api(self):
        contract_id = self.test_create_amc_contract_api()
        # Activate first
        self.client.post(f"/api/v1/maintenance/amc-contracts/{contract_id}/activate/", {}, format="json")
        resp = self.client.post(
            f"/api/v1/maintenance/amc-contracts/{contract_id}/record-visit/",
            {"visit_date": str(date.today())}, format="json"
        )
        self.assertEqual(resp.status_code, http_status.HTTP_200_OK)
        self.assertIsNotNone(resp.data["last_visit_date"])

    def test_expiring_amc_api(self):
        resp = self.client.get("/api/v1/maintenance/amc-contracts/expiring/")
        self.assertEqual(resp.status_code, http_status.HTTP_200_OK)


# ═══════════════════════════════════════════════════════════════════
# CELERY TASK TESTS
# ═══════════════════════════════════════════════════════════════════

class MaintenanceCeleryTest(TestCase):
    def setUp(self):
        self.user, self.plant = _base()
        self.asset = _make_asset(self.plant, self.user)
        self.mtype = _make_type(self.plant)

    def test_generate_pm_orders(self):
        from apps.maintenance.services import create_maintenance_schedule
        create_maintenance_schedule(
            plant=self.plant, asset=self.asset, maintenance_type=self.mtype,
            title="Monthly Lube",
            frequency_value=1, frequency_unit="MONTHLY",
            next_due_date=date.today() - timedelta(days=1),  # overdue
            created_by=self.user,
        )
        from apps.maintenance.tasks import generate_pm_orders
        result = generate_pm_orders()
        self.assertIn("Generated 1", result)

    def test_generate_pm_skips_already_open(self):
        from apps.maintenance.services import create_maintenance_schedule, raise_maintenance_request, create_maintenance_order
        sched = create_maintenance_schedule(
            plant=self.plant, asset=self.asset, maintenance_type=self.mtype,
            title="Weekly Check",
            frequency_value=1, frequency_unit="WEEKLY",
            next_due_date=date.today() - timedelta(days=1),
            created_by=self.user,
        )
        req = raise_maintenance_request(
            plant=self.plant, asset=self.asset,
            title="Existing", request_type="PREVENTIVE",
            schedule=sched, created_by=self.user,
        )
        create_maintenance_order(
            plant=self.plant, asset=self.asset,
            title="Existing Order", request=req, created_by=self.user,
        )
        from apps.maintenance.tasks import generate_pm_orders
        result = generate_pm_orders()
        self.assertIn("Generated 0", result)

    def test_expire_amc_contracts(self):
        from apps.maintenance.models import AMCContract
        from apps.maintenance.services import create_amc_contract
        vendor = _make_vendor(self.plant)
        contract = create_amc_contract(
            plant=self.plant, vendor=vendor,
            contract_date=date.today() - timedelta(days=400),
            start_date=date.today() - timedelta(days=400),
            end_date=date.today() - timedelta(days=10),  # already expired
            contract_type="COMPREHENSIVE",
            contract_value=Decimal("50000"),
            created_by=self.user,
        )
        # Manually activate so the task can expire it
        contract.status = AMCContract.ContractStatus.ACTIVE
        contract.save()
        from apps.maintenance.tasks import expire_amc_contracts
        result = expire_amc_contracts()
        contract.refresh_from_db()
        self.assertEqual(contract.status, AMCContract.ContractStatus.EXPIRED)
        self.assertIn("Expired 1", result)

    def test_breakdown_escalation(self):
        from apps.maintenance.services import raise_maintenance_request
        from django.utils import timezone
        req = raise_maintenance_request(
            plant=self.plant, asset=self.asset,
            title="Critical BD", request_type="BREAKDOWN",
            priority="CRITICAL", created_by=self.user,
        )
        # Backdate request_date to 3 hours ago so it qualifies for escalation
        from apps.maintenance.models import MaintenanceRequest
        MaintenanceRequest.objects.filter(pk=req.pk).update(
            request_date=timezone.now() - timezone.timedelta(hours=3)
        )
        from apps.maintenance.tasks import breakdown_escalation
        result = breakdown_escalation()
        self.assertIn("Escalated 1", result)
