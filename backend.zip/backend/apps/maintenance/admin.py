"""Maintenance & AMC Module Django Admin."""
from django.contrib import admin
from apps.maintenance.models import (
    MaintenanceType, SparePart, MaintenanceSchedule,
    MaintenanceRequest, MaintenanceOrder, MaintenanceOrderLine,
    SparePartUsage, AMCContract, AMCContractLine,
)


@admin.register(MaintenanceType)
class MaintenanceTypeAdmin(admin.ModelAdmin):
    list_display = ["code", "name", "plant", "is_active"]
    list_filter = ["plant", "is_active"]


@admin.register(SparePart)
class SparePartAdmin(admin.ModelAdmin):
    list_display = ["part_number", "name", "plant", "uom", "unit_cost", "min_stock_qty", "is_active"]
    list_filter = ["plant", "is_active"]
    search_fields = ["part_number", "name"]
    raw_id_fields = ["item"]


@admin.register(MaintenanceSchedule)
class MaintenanceScheduleAdmin(admin.ModelAdmin):
    list_display = [
        "asset", "title", "maintenance_type",
        "frequency_value", "frequency_unit",
        "last_done_date", "next_due_date", "status",
    ]
    list_filter = ["plant", "frequency_unit", "status"]
    search_fields = ["title", "asset__asset_number"]
    raw_id_fields = ["asset", "maintenance_type", "assigned_to"]


class MaintenanceOrderInline(admin.TabularInline):
    model = MaintenanceOrder
    extra = 0
    fields = ["order_number", "status", "assigned_to", "scheduled_start", "total_actual_cost"]
    readonly_fields = ["order_number", "total_actual_cost"]


@admin.register(MaintenanceRequest)
class MaintenanceRequestAdmin(admin.ModelAdmin):
    list_display = [
        "request_number", "title", "asset", "request_type",
        "priority", "status", "reported_by", "request_date",
    ]
    list_filter = ["plant", "request_type", "priority", "status"]
    search_fields = ["request_number", "title", "asset__asset_number"]
    raw_id_fields = ["asset", "maintenance_type", "schedule", "reported_by", "assigned_to"]
    readonly_fields = ["request_number", "assigned_at"]
    inlines = [MaintenanceOrderInline]


class MaintenanceOrderLineInline(admin.TabularInline):
    model = MaintenanceOrderLine
    extra = 1
    fields = ["line_number", "line_type", "description", "quantity", "uom", "unit_cost", "line_total", "is_completed"]
    readonly_fields = ["line_total"]


class SparePartUsageInline(admin.TabularInline):
    model = SparePartUsage
    extra = 0
    fields = ["spare_part", "quantity_used", "unit_cost", "total_cost", "stock_issue"]
    readonly_fields = ["total_cost", "stock_issue"]


@admin.register(MaintenanceOrder)
class MaintenanceOrderAdmin(admin.ModelAdmin):
    list_display = [
        "order_number", "order_date", "status", "asset",
        "priority", "assigned_to",
        "estimated_cost", "total_actual_cost",
        "scheduled_start", "actual_end",
    ]
    list_filter = ["plant", "status", "priority"]
    search_fields = ["order_number", "title", "asset__asset_number"]
    raw_id_fields = ["asset", "request", "maintenance_type", "assigned_to", "completed_by", "voucher"]
    readonly_fields = [
        "order_number", "total_actual_cost",
        "actual_spare_cost", "completed_at",
    ]
    inlines = [MaintenanceOrderLineInline, SparePartUsageInline]


class AMCContractLineInline(admin.TabularInline):
    model = AMCContractLine
    extra = 1
    fields = ["line_number", "asset", "description", "allocated_value"]
    raw_id_fields = ["asset"]


@admin.register(AMCContract)
class AMCContractAdmin(admin.ModelAdmin):
    list_display = [
        "contract_number", "contract_date", "status", "contract_type",
        "vendor", "start_date", "end_date",
        "contract_value", "visits_per_year", "next_visit_date",
    ]
    list_filter = ["plant", "status", "contract_type", "payment_frequency"]
    search_fields = ["contract_number", "vendor__name"]
    raw_id_fields = ["vendor"]
    readonly_fields = ["contract_number", "next_visit_date"]
    inlines = [AMCContractLineInline]
