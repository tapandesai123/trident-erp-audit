"""Asset Management admin registrations."""
from django.contrib import admin
from django.utils.html import format_html
from apps.assets.models import (
    AssetCategory, Asset, DepreciationSchedule,
    AssetDepreciation, AssetMaintenance,
    AssetTransfer, AssetDisposal,
)


# ─── Category ─────────────────────────────────────────────────────

@admin.register(AssetCategory)
class AssetCategoryAdmin(admin.ModelAdmin):
    list_display = [
        "code", "name", "depreciation_method", "useful_life_years",
        "depreciation_rate", "residual_value_pct", "is_active",
    ]
    list_filter = ["depreciation_method", "is_active"]
    search_fields = ["code", "name"]
    readonly_fields = ["uuid", "created_at", "updated_at"]


# ─── Asset ────────────────────────────────────────────────────────

class DepreciationScheduleInline(admin.TabularInline):
    model = DepreciationSchedule
    extra = 0
    fields = [
        "year_number", "financial_year", "opening_value",
        "depreciation_amount", "closing_value", "is_posted",
    ]
    readonly_fields = [
        "year_number", "financial_year", "opening_value",
        "depreciation_amount", "closing_value",
    ]
    can_delete = False


class AssetDepreciationInline(admin.TabularInline):
    model = AssetDepreciation
    extra = 0
    fields = ["period_label", "period_type", "depreciation_amount",
              "opening_book_value", "closing_book_value", "voucher"]
    readonly_fields = ["depreciation_amount", "opening_book_value",
                       "closing_book_value", "voucher"]
    can_delete = False


class AssetMaintenanceInline(admin.TabularInline):
    model = AssetMaintenance
    extra = 0
    fields = ["maintenance_type", "scheduled_date", "status", "cost",
              "vendor_name", "next_maintenance_date"]
    readonly_fields = []


@admin.register(Asset)
class AssetAdmin(admin.ModelAdmin):
    list_display = [
        "asset_number", "name", "category", "plant",
        "status", "purchase_date", "purchase_cost",
        "accumulated_depreciation", "book_value_display", "colored_status",
    ]
    list_filter = ["status", "category", "plant"]
    search_fields = ["asset_number", "name", "serial_number", "invoice_number"]
    readonly_fields = [
        "uuid", "asset_number", "book_value_display",
        "accumulated_depreciation", "created_at", "updated_at",
    ]
    inlines = [DepreciationScheduleInline, AssetDepreciationInline, AssetMaintenanceInline]
    fieldsets = (
        ("Identity", {
            "fields": (
                "plant", "asset_number", "name", "description",
                "category", "status",
            )
        }),
        ("Location", {
            "fields": ("location", "department", "custodian"),
        }),
        ("Purchase", {
            "fields": (
                "purchase_date", "purchase_cost", "vendor_name",
                "invoice_number", "invoice_date", "mrr",
            )
        }),
        ("Technical", {
            "fields": (
                "serial_number", "model_number",
                "warranty_expiry", "amc_expiry",
            )
        }),
        ("Depreciation", {
            "fields": (
                "depreciation_method", "useful_life_years",
                "residual_value", "accumulated_depreciation", "book_value_display",
            )
        }),
        ("Disposal", {
            "fields": ("disposal_date", "disposal_value", "disposal_remarks"),
        }),
        ("Metadata", {"fields": ("uuid", "notes", "created_at", "updated_at", "created_by")}),
    )

    def book_value_display(self, obj):
        bv = obj.book_value
        color = "green" if bv > 0 else "red"
        return format_html('<span style="color:{}"><b>₹{:,.2f}</b></span>', color, bv)
    book_value_display.short_description = "Book Value"

    def colored_status(self, obj):
        colors = {
            "ACTIVE": "green", "IDLE": "orange",
            "UNDER_MAINTENANCE": "blue", "DISPOSED": "gray",
            "SCRAPPED": "red", "TRANSFERRED": "purple",
        }
        return format_html(
            '<span style="color:{}"><b>{}</b></span>',
            colors.get(obj.status, "black"), obj.status,
        )
    colored_status.short_description = "Status"


# ─── Depreciation ─────────────────────────────────────────────────

@admin.register(AssetDepreciation)
class AssetDepreciationAdmin(admin.ModelAdmin):
    list_display = [
        "asset", "period_label", "period_type",
        "depreciation_amount", "opening_book_value", "closing_book_value",
        "posted_by", "voucher",
    ]
    list_filter = ["period_type"]
    search_fields = ["asset__asset_number", "period_label"]
    readonly_fields = [
        "uuid", "depreciation_amount", "opening_book_value",
        "closing_book_value", "voucher", "created_at", "updated_at",
    ]


# ─── Maintenance ──────────────────────────────────────────────────

@admin.register(AssetMaintenance)
class AssetMaintenanceAdmin(admin.ModelAdmin):
    list_display = [
        "asset", "maintenance_type", "scheduled_date", "completed_date",
        "status", "cost", "vendor_name", "next_maintenance_date",
    ]
    list_filter = ["status", "maintenance_type"]
    search_fields = ["asset__asset_number", "asset__name", "vendor_name"]
    readonly_fields = ["uuid", "created_at", "updated_at"]
    date_hierarchy = "scheduled_date"


# ─── Transfer ─────────────────────────────────────────────────────

@admin.register(AssetTransfer)
class AssetTransferAdmin(admin.ModelAdmin):
    list_display = [
        "transfer_number", "asset", "from_plant", "to_plant",
        "transfer_date", "status", "initiated_by", "approved_by",
    ]
    list_filter = ["status", "from_plant", "to_plant"]
    search_fields = ["transfer_number", "asset__asset_number"]
    readonly_fields = ["uuid", "transfer_number", "created_at", "updated_at", "approved_at"]


# ─── Disposal ─────────────────────────────────────────────────────

@admin.register(AssetDisposal)
class AssetDisposalAdmin(admin.ModelAdmin):
    list_display = [
        "disposal_number", "asset", "disposal_method", "disposal_date",
        "book_value_at_disposal", "sale_proceeds", "gain_loss_display", "status",
    ]
    list_filter = ["status", "disposal_method"]
    search_fields = ["disposal_number", "asset__asset_number", "buyer_name"]
    readonly_fields = [
        "uuid", "disposal_number", "gain_loss",
        "book_value_at_disposal", "voucher",
        "approved_at", "created_at", "updated_at",
    ]

    def gain_loss_display(self, obj):
        color = "green" if obj.gain_loss >= 0 else "red"
        label = "GAIN" if obj.gain_loss >= 0 else "LOSS"
        return format_html(
            '<span style="color:{}"><b>{}: ₹{:,.2f}</b></span>',
            color, label, abs(obj.gain_loss),
        )
    gain_loss_display.short_description = "Gain / Loss"
