"""Asset Management API URL configuration."""
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from apps.assets.api.viewsets import (
    AssetCategoryViewSet, AssetViewSet,
    AssetDepreciationViewSet, AssetMaintenanceViewSet,
    AssetTransferViewSet, AssetDisposalViewSet,
)

router = DefaultRouter()
router.register("categories", AssetCategoryViewSet, basename="asset-category")
router.register("assets", AssetViewSet, basename="asset")
router.register("depreciations", AssetDepreciationViewSet, basename="asset-depreciation")
router.register("maintenances", AssetMaintenanceViewSet, basename="asset-maintenance")
router.register("transfers", AssetTransferViewSet, basename="asset-transfer")
router.register("disposals", AssetDisposalViewSet, basename="asset-disposal")

urlpatterns = [
    path("", include(router.urls)),
]
