"""Asset Management API Viewsets."""
from decimal import Decimal
from datetime import date as date_type
from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated

from apps.assets.models import (
    AssetCategory, Asset, DepreciationSchedule,
    AssetDepreciation, AssetMaintenance,
    AssetTransfer, AssetDisposal,
)
from apps.assets.api.serializers import (
    AssetCategoryListSerializer, AssetCategoryDetailSerializer, AssetCategoryCreateSerializer,
    AssetListSerializer, AssetDetailSerializer, AssetCreateSerializer,
    AssetDepreciationListSerializer, AssetDepreciationDetailSerializer, AssetDepreciationCreateSerializer,
    AssetMaintenanceListSerializer, AssetMaintenanceDetailSerializer, AssetMaintenanceCreateSerializer,
    AssetTransferListSerializer, AssetTransferDetailSerializer, AssetTransferCreateSerializer,
    AssetDisposalListSerializer, AssetDisposalDetailSerializer, AssetDisposalCreateSerializer,
    DepreciationScheduleSerializer,
)
from apps.assets import services


class AssetCategoryViewSet(viewsets.ModelViewSet):
    queryset = AssetCategory.objects.all()
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return AssetCategoryListSerializer
        if self.action in ("create", "update", "partial_update"):
            return AssetCategoryCreateSerializer
        return AssetCategoryDetailSerializer


class AssetViewSet(viewsets.ModelViewSet):
    queryset = Asset.objects.select_related(
        "plant", "category", "custodian", "mrr"
    ).prefetch_related("depreciation_schedule")
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return AssetListSerializer
        if self.action in ("create", "update", "partial_update"):
            return AssetCreateSerializer
        return AssetDetailSerializer

    def get_queryset(self):
        qs = super().get_queryset()
        plant = self.request.query_params.get("plant")
        status_filter = self.request.query_params.get("status")
        category = self.request.query_params.get("category")
        if plant:
            qs = qs.filter(plant=plant)
        if status_filter:
            qs = qs.filter(status=status_filter)
        if category:
            qs = qs.filter(category=category)
        return qs

    def create(self, request, *args, **kwargs):
        """Use service to create asset with auto-scheduling."""
        from apps.assets.models import AssetCategory as AC
        from apps.core.models import Plant

        try:
            plant = Plant.objects.get(pk=request.data["plant"])
            category = AC.objects.get(pk=request.data["category"])
            purchase_date = date_type.fromisoformat(request.data["purchase_date"])
            purchase_cost = Decimal(str(request.data["purchase_cost"]))

            custodian = None
            if request.data.get("custodian"):
                from django.contrib.auth import get_user_model
                custodian = get_user_model().objects.filter(pk=request.data["custodian"]).first()

            mrr = None
            if request.data.get("mrr"):
                from apps.purchase.models import MRR
                mrr = MRR.objects.filter(pk=request.data["mrr"]).first()

            asset = services.create_asset(
                plant=plant,
                name=request.data["name"],
                category=category,
                purchase_date=purchase_date,
                purchase_cost=purchase_cost,
                description=request.data.get("description", ""),
                location=request.data.get("location", ""),
                department=request.data.get("department", ""),
                custodian=custodian,
                vendor_name=request.data.get("vendor_name", ""),
                invoice_number=request.data.get("invoice_number", ""),
                invoice_date=(
                    date_type.fromisoformat(request.data["invoice_date"])
                    if request.data.get("invoice_date") else None
                ),
                serial_number=request.data.get("serial_number", ""),
                model_number=request.data.get("model_number", ""),
                warranty_expiry=(
                    date_type.fromisoformat(request.data["warranty_expiry"])
                    if request.data.get("warranty_expiry") else None
                ),
                amc_expiry=(
                    date_type.fromisoformat(request.data["amc_expiry"])
                    if request.data.get("amc_expiry") else None
                ),
                useful_life_years=request.data.get("useful_life_years"),
                residual_value=Decimal(str(request.data["residual_value"])) if request.data.get("residual_value") else None,
                depreciation_method=request.data.get("depreciation_method", ""),
                mrr=mrr,
                notes=request.data.get("notes", ""),
                created_by=request.user,
                auto_schedule=request.data.get("auto_schedule", True),
            )
            return Response(AssetDetailSerializer(asset).data, status=status.HTTP_201_CREATED)
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)

    @action(detail=True, methods=["post"])
    def regenerate_schedule(self, request, pk=None):
        """Regenerate the depreciation schedule for this asset."""
        asset = self.get_object()
        try:
            rows = services.generate_depreciation_schedule(asset)
            return Response({
                "message": f"Schedule regenerated with {len(rows)} year(s).",
                "rows": DepreciationScheduleSerializer(rows, many=True).data,
            })
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=True, methods=["post"])
    def post_depreciation(self, request, pk=None):
        """
        Post depreciation for a period.
        Payload: { "period_label": "2025-26", "period_type": "ANNUAL",
                   "depreciation_amount": "optional" }
        """
        asset = self.get_object()
        period_label = request.data.get("period_label")
        if not period_label:
            return Response({"error": "period_label is required."}, status=status.HTTP_400_BAD_REQUEST)

        dep_amount = None
        if request.data.get("depreciation_amount"):
            dep_amount = Decimal(str(request.data["depreciation_amount"]))

        try:
            dep = services.post_depreciation(
                asset, period_label,
                depreciation_amount=dep_amount,
                period_type=request.data.get("period_type", "ANNUAL"),
                posted_by=request.user,
                notes=request.data.get("notes", ""),
            )
            return Response(AssetDepreciationDetailSerializer(dep).data, status=status.HTTP_201_CREATED)
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=True, methods=["post"])
    def schedule_maintenance(self, request, pk=None):
        """
        Log a maintenance event.
        Payload: { "maintenance_type": "PREVENTIVE", "scheduled_date": "2026-03-01",
                   "complete": false, ... }
        """
        asset = self.get_object()
        scheduled_date_str = request.data.get("scheduled_date")
        if not scheduled_date_str:
            return Response({"error": "scheduled_date is required."}, status=status.HTTP_400_BAD_REQUEST)

        try:
            maint = services.schedule_maintenance(
                asset=asset,
                maintenance_type=request.data.get("maintenance_type", "PREVENTIVE"),
                scheduled_date=date_type.fromisoformat(scheduled_date_str),
                description=request.data.get("description", ""),
                vendor_name=request.data.get("vendor_name", ""),
                cost=Decimal(str(request.data.get("cost", "0"))),
                performed_by=request.user,
                complete=request.data.get("complete", False),
                completed_date=(
                    date_type.fromisoformat(request.data["completed_date"])
                    if request.data.get("completed_date") else None
                ),
                findings=request.data.get("findings", ""),
                parts_replaced=request.data.get("parts_replaced", ""),
                next_maintenance_date=(
                    date_type.fromisoformat(request.data["next_maintenance_date"])
                    if request.data.get("next_maintenance_date") else None
                ),
            )
            return Response(AssetMaintenanceDetailSerializer(maint).data, status=status.HTTP_201_CREATED)
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=True, methods=["post"])
    def transfer(self, request, pk=None):
        """
        Initiate or complete an asset transfer.
        Payload: { "to_plant": <int>, "transfer_date": "2026-02-01",
                   "to_department": "...", "to_custodian": <int>,
                   "reason": "...", "complete": true }
        """
        asset = self.get_object()
        from apps.core.models import Plant

        to_plant_id = request.data.get("to_plant")
        transfer_date_str = request.data.get("transfer_date")
        if not to_plant_id or not transfer_date_str:
            return Response(
                {"error": "to_plant and transfer_date are required."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        try:
            to_plant = Plant.objects.get(pk=to_plant_id)
            to_custodian = None
            if request.data.get("to_custodian"):
                from django.contrib.auth import get_user_model
                to_custodian = get_user_model().objects.filter(pk=request.data["to_custodian"]).first()

            tr = services.transfer_asset(
                asset=asset,
                to_plant=to_plant,
                transfer_date=date_type.fromisoformat(transfer_date_str),
                from_department=request.data.get("from_department", ""),
                to_department=request.data.get("to_department", ""),
                to_custodian=to_custodian,
                reason=request.data.get("reason", ""),
                initiated_by=request.user,
                complete=request.data.get("complete", False),
                approved_by=request.user if request.data.get("complete") else None,
            )
            return Response(AssetTransferDetailSerializer(tr).data, status=status.HTTP_201_CREATED)
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=True, methods=["post"])
    def dispose(self, request, pk=None):
        """
        Dispose an asset (sale/scrap/write-off).
        Payload: { "disposal_method": "SALE", "disposal_date": "2026-03-31",
                   "sale_proceeds": "50000", "buyer_name": "...", "notes": "..." }
        """
        asset = self.get_object()
        disposal_date_str = request.data.get("disposal_date")
        if not disposal_date_str:
            return Response({"error": "disposal_date is required."}, status=status.HTTP_400_BAD_REQUEST)

        try:
            disposal = services.dispose_asset(
                asset=asset,
                disposal_method=request.data.get("disposal_method", "SALE"),
                disposal_date=date_type.fromisoformat(disposal_date_str),
                sale_proceeds=Decimal(str(request.data.get("sale_proceeds", "0"))),
                buyer_name=request.data.get("buyer_name", ""),
                buyer_contact=request.data.get("buyer_contact", ""),
                notes=request.data.get("notes", ""),
                initiated_by=request.user,
                approved_by=request.user,
                auto_approve=True,
            )
            return Response(AssetDisposalDetailSerializer(disposal).data, status=status.HTTP_201_CREATED)
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=False, methods=["get"])
    def register(self, request):
        """Return full asset register with book values."""
        from apps.core.models import Plant
        plant_id = request.query_params.get("plant")
        if not plant_id:
            return Response({"error": "plant query param required."}, status=status.HTTP_400_BAD_REQUEST)
        try:
            plant = Plant.objects.get(pk=plant_id)
            data = services.get_asset_register(
                plant,
                status=request.query_params.get("status"),
            )
            return Response(data)
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=False, methods=["post"])
    def bulk_depreciation(self, request):
        """Dispatch async annual depreciation posting for a plant+FY."""
        from apps.assets.tasks import post_annual_depreciation_task

        plant_id = request.data.get("plant")
        financial_year = request.data.get("financial_year")
        if not plant_id or not financial_year:
            return Response(
                {"error": "plant and financial_year are required."},
                status=status.HTTP_400_BAD_REQUEST,
            )
        task = post_annual_depreciation_task.delay(
            int(plant_id), financial_year, request.user.pk
        )
        return Response({
            "message": "Annual depreciation posting queued.",
            "task_id": task.id,
            "plant": plant_id,
            "financial_year": financial_year,
        })


class AssetDepreciationViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = AssetDepreciation.objects.select_related("asset", "voucher", "posted_by")
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return AssetDepreciationListSerializer
        return AssetDepreciationDetailSerializer

    def get_queryset(self):
        qs = super().get_queryset()
        asset = self.request.query_params.get("asset")
        if asset:
            qs = qs.filter(asset=asset)
        return qs


class AssetMaintenanceViewSet(viewsets.ModelViewSet):
    queryset = AssetMaintenance.objects.select_related("asset", "performed_by")
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return AssetMaintenanceListSerializer
        if self.action in ("create", "update", "partial_update"):
            return AssetMaintenanceCreateSerializer
        return AssetMaintenanceDetailSerializer

    def get_queryset(self):
        qs = super().get_queryset()
        asset = self.request.query_params.get("asset")
        maint_status = self.request.query_params.get("status")
        if asset:
            qs = qs.filter(asset=asset)
        if maint_status:
            qs = qs.filter(status=maint_status)
        return qs

    @action(detail=True, methods=["post"])
    def complete(self, request, pk=None):
        """Mark a maintenance as completed."""
        maint = self.get_object()
        if maint.status == "COMPLETED":
            return Response({"error": "Already completed."}, status=status.HTTP_400_BAD_REQUEST)
        from django.utils import timezone as tz
        maint.status = "COMPLETED"
        maint.completed_date = request.data.get("completed_date") or date_type.today().isoformat()
        maint.findings = request.data.get("findings", "")
        maint.parts_replaced = request.data.get("parts_replaced", "")
        maint.next_maintenance_date = request.data.get("next_maintenance_date")
        maint.cost = Decimal(str(request.data.get("cost", maint.cost)))
        maint.save()
        # Restore asset status if it was under maintenance
        if maint.asset.status == "UNDER_MAINTENANCE":
            maint.asset.status = "ACTIVE"
            maint.asset.save(update_fields=["status"])
        return Response(AssetMaintenanceDetailSerializer(maint).data)


class AssetTransferViewSet(viewsets.ModelViewSet):
    queryset = AssetTransfer.objects.select_related(
        "asset", "from_plant", "to_plant", "from_custodian", "to_custodian", "initiated_by"
    )
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return AssetTransferListSerializer
        if self.action in ("create", "update", "partial_update"):
            return AssetTransferCreateSerializer
        return AssetTransferDetailSerializer

    def get_queryset(self):
        qs = super().get_queryset()
        asset = self.request.query_params.get("asset")
        tr_status = self.request.query_params.get("status")
        if asset:
            qs = qs.filter(asset=asset)
        if tr_status:
            qs = qs.filter(status=tr_status)
        return qs


class AssetDisposalViewSet(viewsets.ModelViewSet):
    queryset = AssetDisposal.objects.select_related(
        "asset", "voucher", "approved_by", "initiated_by"
    )
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return AssetDisposalListSerializer
        if self.action in ("create", "update", "partial_update"):
            return AssetDisposalCreateSerializer
        return AssetDisposalDetailSerializer

    def get_queryset(self):
        qs = super().get_queryset()
        disp_status = self.request.query_params.get("status")
        if disp_status:
            qs = qs.filter(status=disp_status)
        return qs
