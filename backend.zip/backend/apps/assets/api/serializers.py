"""Asset Management API Serializers — 3 variants per major model."""
from rest_framework import serializers
from apps.assets.models import (
    AssetCategory, Asset, DepreciationSchedule,
    AssetDepreciation, AssetMaintenance,
    AssetTransfer, AssetDisposal,
)


# ─── AssetCategory ────────────────────────────────────────────────

class AssetCategoryListSerializer(serializers.ModelSerializer):
    class Meta:
        model = AssetCategory
        fields = [
            "id", "uuid", "code", "name", "depreciation_method",
            "useful_life_years", "depreciation_rate", "residual_value_pct", "is_active",
        ]


class AssetCategoryDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = AssetCategory
        fields = "__all__"


class AssetCategoryCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = AssetCategory
        fields = [
            "code", "name", "depreciation_method", "useful_life_years",
            "depreciation_rate", "residual_value_pct",
            "asset_ledger_subtype", "accumulated_dep_ledger_subtype",
            "dep_expense_ledger_subtype",
        ]


# ─── DepreciationSchedule ─────────────────────────────────────────

class DepreciationScheduleSerializer(serializers.ModelSerializer):
    class Meta:
        model = DepreciationSchedule
        fields = [
            "id", "year_number", "financial_year",
            "opening_value", "depreciation_amount", "closing_value", "is_posted",
        ]


# ─── Asset ────────────────────────────────────────────────────────

class AssetListSerializer(serializers.ModelSerializer):
    category_name = serializers.CharField(source="category.name", read_only=True)
    plant_code = serializers.CharField(source="plant.code", read_only=True)
    book_value = serializers.DecimalField(max_digits=16, decimal_places=2, read_only=True)
    custodian_name = serializers.SerializerMethodField()

    class Meta:
        model = Asset
        fields = [
            "id", "uuid", "asset_number", "name",
            "category", "category_name",
            "plant", "plant_code",
            "status", "purchase_date", "purchase_cost",
            "accumulated_depreciation", "book_value",
            "location", "department", "custodian_name",
        ]

    def get_custodian_name(self, obj):
        return obj.custodian.get_full_name() if obj.custodian else None


class AssetDetailSerializer(serializers.ModelSerializer):
    category_name = serializers.CharField(source="category.name", read_only=True)
    plant_code = serializers.CharField(source="plant.code", read_only=True)
    book_value = serializers.DecimalField(max_digits=16, decimal_places=2, read_only=True)
    effective_depreciation_method = serializers.CharField(read_only=True)
    effective_useful_life = serializers.IntegerField(read_only=True)
    custodian_name = serializers.SerializerMethodField()
    depreciation_schedule = DepreciationScheduleSerializer(many=True, read_only=True)

    class Meta:
        model = Asset
        fields = "__all__"

    def get_custodian_name(self, obj):
        return obj.custodian.get_full_name() if obj.custodian else None


class AssetCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Asset
        fields = [
            "plant", "name", "description", "category",
            "purchase_date", "purchase_cost",
            "location", "department", "custodian",
            "vendor_name", "invoice_number", "invoice_date",
            "serial_number", "model_number",
            "warranty_expiry", "amc_expiry",
            "useful_life_years", "residual_value",
            "depreciation_method", "mrr", "notes",
        ]


# ─── AssetDepreciation ────────────────────────────────────────────

class AssetDepreciationListSerializer(serializers.ModelSerializer):
    asset_number = serializers.CharField(source="asset.asset_number", read_only=True)
    asset_name = serializers.CharField(source="asset.name", read_only=True)
    voucher_number = serializers.CharField(source="voucher.voucher_number", read_only=True)

    class Meta:
        model = AssetDepreciation
        fields = [
            "id", "uuid", "asset", "asset_number", "asset_name",
            "period_label", "period_type", "depreciation_amount",
            "opening_book_value", "closing_book_value",
            "voucher_number", "posted_by",
        ]


class AssetDepreciationDetailSerializer(serializers.ModelSerializer):
    asset_number = serializers.CharField(source="asset.asset_number", read_only=True)
    voucher_number = serializers.CharField(source="voucher.voucher_number", read_only=True)

    class Meta:
        model = AssetDepreciation
        fields = "__all__"


class AssetDepreciationCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = AssetDepreciation
        fields = ["asset", "period_label", "period_type", "depreciation_amount", "notes"]


# ─── AssetMaintenance ─────────────────────────────────────────────

class AssetMaintenanceListSerializer(serializers.ModelSerializer):
    asset_number = serializers.CharField(source="asset.asset_number", read_only=True)
    asset_name = serializers.CharField(source="asset.name", read_only=True)

    class Meta:
        model = AssetMaintenance
        fields = [
            "id", "uuid", "asset", "asset_number", "asset_name",
            "maintenance_type", "scheduled_date", "completed_date",
            "status", "cost", "vendor_name", "next_maintenance_date",
        ]


class AssetMaintenanceDetailSerializer(serializers.ModelSerializer):
    asset_number = serializers.CharField(source="asset.asset_number", read_only=True)

    class Meta:
        model = AssetMaintenance
        fields = "__all__"


class AssetMaintenanceCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = AssetMaintenance
        fields = [
            "asset", "maintenance_type", "scheduled_date",
            "description", "vendor_name", "vendor_contact", "cost",
            "next_maintenance_date",
        ]


# ─── AssetTransfer ────────────────────────────────────────────────

class AssetTransferListSerializer(serializers.ModelSerializer):
    asset_number = serializers.CharField(source="asset.asset_number", read_only=True)
    from_plant_code = serializers.CharField(source="from_plant.code", read_only=True)
    to_plant_code = serializers.CharField(source="to_plant.code", read_only=True)

    class Meta:
        model = AssetTransfer
        fields = [
            "id", "uuid", "transfer_number",
            "asset", "asset_number",
            "from_plant", "from_plant_code",
            "to_plant", "to_plant_code",
            "transfer_date", "status",
        ]


class AssetTransferDetailSerializer(serializers.ModelSerializer):
    asset_number = serializers.CharField(source="asset.asset_number", read_only=True)
    from_plant_code = serializers.CharField(source="from_plant.code", read_only=True)
    to_plant_code = serializers.CharField(source="to_plant.code", read_only=True)

    class Meta:
        model = AssetTransfer
        fields = "__all__"


class AssetTransferCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = AssetTransfer
        fields = [
            "asset", "to_plant", "transfer_date",
            "from_department", "to_department",
            "from_custodian", "to_custodian", "reason",
        ]


# ─── AssetDisposal ────────────────────────────────────────────────

class AssetDisposalListSerializer(serializers.ModelSerializer):
    asset_number = serializers.CharField(source="asset.asset_number", read_only=True)
    asset_name = serializers.CharField(source="asset.name", read_only=True)
    voucher_number = serializers.CharField(source="voucher.voucher_number", read_only=True)

    class Meta:
        model = AssetDisposal
        fields = [
            "id", "uuid", "disposal_number",
            "asset", "asset_number", "asset_name",
            "disposal_method", "disposal_date",
            "book_value_at_disposal", "sale_proceeds", "gain_loss",
            "status", "voucher_number",
        ]


class AssetDisposalDetailSerializer(serializers.ModelSerializer):
    asset_number = serializers.CharField(source="asset.asset_number", read_only=True)
    voucher_number = serializers.CharField(source="voucher.voucher_number", read_only=True)

    class Meta:
        model = AssetDisposal
        fields = "__all__"


class AssetDisposalCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = AssetDisposal
        fields = [
            "asset", "disposal_method", "disposal_date",
            "sale_proceeds", "buyer_name", "buyer_contact", "notes",
        ]
