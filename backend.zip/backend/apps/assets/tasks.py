"""Asset Management Celery tasks."""
from celery import shared_task
from django.utils import timezone


@shared_task(bind=True, max_retries=3, default_retry_delay=120)
def post_annual_depreciation_task(self, plant_id: int, financial_year: str, user_id: int = None):
    """
    Async: post annual depreciation for all active assets in a plant for a given FY.
    Example: post_annual_depreciation_task.delay(1, '2025-26', user_id=5)
    """
    try:
        from apps.core.models import Plant
        from apps.assets.models import Asset
        from apps.assets.services import post_depreciation

        plant = Plant.objects.get(pk=plant_id)
        user = None
        if user_id:
            from django.contrib.auth import get_user_model
            user = get_user_model().objects.filter(pk=user_id).first()

        assets = Asset.objects.filter(plant=plant, status__in=("ACTIVE", "IDLE"))
        posted = []
        errors = []

        for asset in assets:
            try:
                dep = post_depreciation(
                    asset, financial_year,
                    period_type="ANNUAL",
                    posted_by=user,
                )
                posted.append({"asset": asset.asset_number, "amount": str(dep.depreciation_amount)})
            except Exception as e:
                errors.append({"asset": asset.asset_number, "error": str(e)})

        return {"plant": plant.code, "fy": financial_year, "posted": posted, "errors": errors}
    except Exception as exc:
        raise self.retry(exc=exc)


@shared_task
def send_maintenance_due_alerts():
    """
    Periodic: notify custodians of assets with maintenance due in the next 7 days.
    Schedule: daily.
    """
    from datetime import date, timedelta
    from apps.assets.models import AssetMaintenance
    from apps.core.models import Notification

    today = date.today()
    upcoming = today + timedelta(days=7)

    due = AssetMaintenance.objects.filter(
        next_maintenance_date__gte=today,
        next_maintenance_date__lte=upcoming,
        status__in=("COMPLETED", "SCHEDULED"),
    ).select_related("asset__custodian")

    notified = 0
    for maint in due:
        custodian = maint.asset.custodian
        if custodian:
            Notification.objects.get_or_create(
                user=custodian,
                module="assets",
                resource="AssetMaintenance",
                resource_id=maint.pk,
                title=f"Maintenance Due: {maint.asset.asset_number}",
                defaults={
                    "message": (
                        f"Asset {maint.asset.name} is due for "
                        f"{maint.get_maintenance_type_display()} maintenance "
                        f"on {maint.next_maintenance_date}."
                    ),
                    "notification_type": "IN_APP",
                },
            )
            notified += 1

    return {"due_maintenance_alerts": notified, "checked_date": str(today)}


@shared_task
def send_warranty_expiry_alerts():
    """
    Periodic: notify custodians of assets with warranty or AMC expiring in 30 days.
    Schedule: weekly.
    """
    from datetime import date, timedelta
    from apps.assets.models import Asset
    from apps.core.models import Notification

    today = date.today()
    threshold = today + timedelta(days=30)

    warranty_expiring = Asset.objects.filter(
        status="ACTIVE",
        warranty_expiry__gte=today,
        warranty_expiry__lte=threshold,
        custodian__isnull=False,
    ).select_related("custodian")

    amc_expiring = Asset.objects.filter(
        status="ACTIVE",
        amc_expiry__gte=today,
        amc_expiry__lte=threshold,
        custodian__isnull=False,
    ).select_related("custodian")

    notified = 0
    for asset in warranty_expiring:
        Notification.objects.get_or_create(
            user=asset.custodian,
            module="assets",
            resource="Asset",
            resource_id=asset.pk,
            title=f"Warranty Expiring: {asset.asset_number}",
            defaults={
                "message": (
                    f"Warranty for {asset.name} expires on {asset.warranty_expiry}. "
                    "Please arrange renewal or replacement."
                ),
                "notification_type": "IN_APP",
            },
        )
        notified += 1

    for asset in amc_expiring:
        Notification.objects.get_or_create(
            user=asset.custodian,
            module="assets",
            resource="Asset",
            resource_id=asset.pk,
            title=f"AMC Expiring: {asset.asset_number}",
            defaults={
                "message": (
                    f"AMC for {asset.name} expires on {asset.amc_expiry}. "
                    "Please arrange renewal."
                ),
                "notification_type": "IN_APP",
            },
        )
        notified += 1

    return {"warranty_amc_alerts": notified}


@shared_task
def auto_generate_depreciation_schedules(plant_id: int):
    """
    Re-generate depreciation schedules for all assets in a plant
    that have no schedule yet (e.g. assets added without auto_schedule).
    """
    from apps.core.models import Plant
    from apps.assets.models import Asset
    from apps.assets.services import generate_depreciation_schedule

    plant = Plant.objects.get(pk=plant_id)
    generated = 0

    for asset in Asset.objects.filter(plant=plant, status__in=("ACTIVE", "IDLE")):
        if not asset.depreciation_schedule.exists():
            if asset.category.depreciation_method != "NO_DEP":
                generate_depreciation_schedule(asset)
                generated += 1

    return {"plant": plant.code, "schedules_generated": generated}
