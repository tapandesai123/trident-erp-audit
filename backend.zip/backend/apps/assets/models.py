"""
Asset Management Module Models — Section 12

Models:
  AssetCategory       — Classification (IT Equipment, Machinery, Furniture …)
  Asset               — Master record: purchase, location, value, linked MRR/GRN
  DepreciationSchedule — Pre-computed yearly depreciation table for an asset
  AssetDepreciation   — Posted monthly/annual depreciation entry (linked to Voucher)
  AssetMaintenance    — Maintenance/service records with scheduled next date
  AssetTransfer       — Inter-plant / inter-department transfer log
  AssetDisposal       — Disposal/scrap/sale record (triggers gain-loss voucher)
"""
import uuid
from decimal import Decimal
from django.db import models
from django.conf import settings
from apps.core.models import UUIDModel, TimeStampedModel, Plant


# ═══════════════════════════════════════════════════════════════════
# CATEGORY
# ═══════════════════════════════════════════════════════════════════

class AssetCategory(UUIDModel, TimeStampedModel):
    DEPRECIATION_METHOD = [
        ("SLM", "Straight-Line (SLM)"),
        ("WDV", "Written-Down Value (WDV)"),
        ("UNITS", "Units of Production"),
        ("NO_DEP", "Non-Depreciable"),
    ]

    code = models.CharField(max_length=20, unique=True)
    name = models.CharField(max_length=150)
    depreciation_method = models.CharField(
        max_length=20, choices=DEPRECIATION_METHOD, default="SLM"
    )
    useful_life_years = models.PositiveSmallIntegerField(
        default=5, help_text="Expected useful life in years"
    )
    depreciation_rate = models.DecimalField(
        max_digits=8, decimal_places=4, default=0,
        help_text="Annual % for WDV; not used for SLM (derived from useful life)"
    )
    residual_value_pct = models.DecimalField(
        max_digits=6, decimal_places=2, default=0,
        help_text="% of cost retained as residual/scrap value"
    )
    # Accounting ledger sub-types (must match accounts.LedgerAccount.sub_type)
    asset_ledger_subtype = models.CharField(
        max_length=50, blank=True, default="FIXED_ASSET",
        help_text="LedgerAccount sub_type for asset block"
    )
    accumulated_dep_ledger_subtype = models.CharField(
        max_length=50, blank=True, default="ACCUM_DEPRECIATION",
    )
    dep_expense_ledger_subtype = models.CharField(
        max_length=50, blank=True, default="DEPRECIATION_EXPENSE",
    )
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ["code"]
        verbose_name_plural = "Asset categories"

    def __str__(self):
        return f"{self.code} — {self.name} ({self.get_depreciation_method_display()})"


# ═══════════════════════════════════════════════════════════════════
# ASSET
# ═══════════════════════════════════════════════════════════════════

class Asset(UUIDModel, TimeStampedModel):
    STATUS_CHOICES = [
        ("ACTIVE", "Active"),
        ("IDLE", "Idle"),
        ("UNDER_MAINTENANCE", "Under Maintenance"),
        ("DISPOSED", "Disposed"),
        ("SCRAPPED", "Scrapped"),
        ("TRANSFERRED", "Transferred"),
    ]

    plant = models.ForeignKey(Plant, on_delete=models.PROTECT, related_name="assets")
    asset_number = models.CharField(max_length=50, unique=True)
    name = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    category = models.ForeignKey(
        AssetCategory, on_delete=models.PROTECT, related_name="assets"
    )
    status = models.CharField(max_length=25, choices=STATUS_CHOICES, default="ACTIVE")

    # Location
    location = models.CharField(max_length=200, blank=True)
    department = models.CharField(max_length=100, blank=True)
    custodian = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="custodied_assets",
    )

    # Purchase details
    purchase_date = models.DateField()
    purchase_cost = models.DecimalField(max_digits=16, decimal_places=2)
    vendor_name = models.CharField(max_length=200, blank=True)
    invoice_number = models.CharField(max_length=100, blank=True)
    invoice_date = models.DateField(null=True, blank=True)

    # Link to purchase module
    mrr = models.ForeignKey(
        "purchase.MRR", on_delete=models.SET_NULL,
        null=True, blank=True, related_name="assets",
    )

    # Warranty
    warranty_expiry = models.DateField(null=True, blank=True)
    amc_expiry = models.DateField(null=True, blank=True)
    serial_number = models.CharField(max_length=100, blank=True)
    model_number = models.CharField(max_length=100, blank=True)

    # Depreciation
    depreciation_method = models.CharField(
        max_length=20,
        choices=AssetCategory.DEPRECIATION_METHOD,
        blank=True,
        help_text="Override category method if needed",
    )
    useful_life_years = models.PositiveSmallIntegerField(
        null=True, blank=True,
        help_text="Override category useful life if needed"
    )
    residual_value = models.DecimalField(
        max_digits=16, decimal_places=2, default=0,
        help_text="Absolute residual/scrap value (not %)"
    )
    accumulated_depreciation = models.DecimalField(
        max_digits=16, decimal_places=2, default=0,
        help_text="Total depreciation posted to date"
    )

    # Current book value = purchase_cost - accumulated_depreciation
    @property
    def book_value(self) -> Decimal:
        return Decimal(str(self.purchase_cost)) - Decimal(str(self.accumulated_depreciation))

    @property
    def effective_depreciation_method(self) -> str:
        return self.depreciation_method or self.category.depreciation_method

    @property
    def effective_useful_life(self) -> int:
        return self.useful_life_years or self.category.useful_life_years

    # Disposal
    disposal_date = models.DateField(null=True, blank=True)
    disposal_value = models.DecimalField(
        max_digits=16, decimal_places=2, null=True, blank=True
    )
    disposal_remarks = models.TextField(blank=True)

    notes = models.TextField(blank=True)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="assets_created",
    )

    class Meta:
        ordering = ["asset_number"]
        indexes = [
            models.Index(fields=["plant", "status"]),
            models.Index(fields=["category"]),
            models.Index(fields=["purchase_date"]),
        ]

    def __str__(self):
        return f"{self.asset_number} — {self.name} [{self.status}]"


# ═══════════════════════════════════════════════════════════════════
# DEPRECIATION SCHEDULE
# ═══════════════════════════════════════════════════════════════════

class DepreciationSchedule(models.Model):
    """
    Pre-computed yearly depreciation schedule for an asset.
    One row per year, generated by generate_depreciation_schedule().
    """
    asset = models.ForeignKey(
        Asset, on_delete=models.CASCADE, related_name="depreciation_schedule"
    )
    year_number = models.PositiveSmallIntegerField(help_text="1 = first year, 2 = second …")
    financial_year = models.CharField(max_length=10, help_text="e.g. 2025-26")
    opening_value = models.DecimalField(max_digits=16, decimal_places=2)
    depreciation_amount = models.DecimalField(max_digits=16, decimal_places=2)
    closing_value = models.DecimalField(max_digits=16, decimal_places=2)
    is_posted = models.BooleanField(default=False)

    class Meta:
        unique_together = [["asset", "year_number"]]
        ordering = ["asset", "year_number"]

    def __str__(self):
        return f"{self.asset.asset_number} | Year {self.year_number} | Dep: {self.depreciation_amount}"


# ═══════════════════════════════════════════════════════════════════
# ASSET DEPRECIATION (POSTED ENTRIES)
# ═══════════════════════════════════════════════════════════════════

class AssetDepreciation(UUIDModel, TimeStampedModel):
    PERIOD_TYPE = [
        ("MONTHLY", "Monthly"),
        ("QUARTERLY", "Quarterly"),
        ("ANNUAL", "Annual"),
    ]

    asset = models.ForeignKey(Asset, on_delete=models.PROTECT, related_name="depreciations")
    period_type = models.CharField(max_length=15, choices=PERIOD_TYPE, default="ANNUAL")
    period_label = models.CharField(max_length=20, help_text="e.g. '2025-26' or '2025-10'")
    depreciation_amount = models.DecimalField(max_digits=16, decimal_places=2)
    opening_book_value = models.DecimalField(max_digits=16, decimal_places=2)
    closing_book_value = models.DecimalField(max_digits=16, decimal_places=2)

    # Linked accounting voucher
    voucher = models.ForeignKey(
        "accounts.Voucher", on_delete=models.SET_NULL,
        null=True, blank=True, related_name="asset_depreciations",
    )
    posted_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="asset_depreciations_posted",
    )
    notes = models.TextField(blank=True)

    class Meta:
        unique_together = [["asset", "period_label"]]
        ordering = ["-period_label"]

    def __str__(self):
        return f"{self.asset.asset_number} | {self.period_label} | ₹{self.depreciation_amount}"


# ═══════════════════════════════════════════════════════════════════
# ASSET MAINTENANCE
# ═══════════════════════════════════════════════════════════════════

class AssetMaintenance(UUIDModel, TimeStampedModel):
    MAINTENANCE_TYPE = [
        ("PREVENTIVE", "Preventive"),
        ("CORRECTIVE", "Corrective"),
        ("BREAKDOWN", "Breakdown"),
        ("AMC", "AMC Service"),
        ("CALIBRATION", "Calibration"),
        ("INSPECTION", "Inspection"),
    ]
    STATUS_CHOICES = [
        ("SCHEDULED", "Scheduled"),
        ("IN_PROGRESS", "In Progress"),
        ("COMPLETED", "Completed"),
        ("CANCELLED", "Cancelled"),
    ]

    asset = models.ForeignKey(Asset, on_delete=models.CASCADE, related_name="maintenances")
    maintenance_type = models.CharField(max_length=20, choices=MAINTENANCE_TYPE, default="PREVENTIVE")
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="SCHEDULED")
    scheduled_date = models.DateField()
    completed_date = models.DateField(null=True, blank=True)
    next_maintenance_date = models.DateField(null=True, blank=True)
    vendor_name = models.CharField(max_length=200, blank=True)
    vendor_contact = models.CharField(max_length=100, blank=True)
    cost = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    description = models.TextField(blank=True)
    findings = models.TextField(blank=True)
    parts_replaced = models.TextField(blank=True)
    performed_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="asset_maintenances",
    )

    class Meta:
        ordering = ["-scheduled_date"]
        indexes = [
            models.Index(fields=["asset", "status"]),
            models.Index(fields=["scheduled_date"]),
            models.Index(fields=["next_maintenance_date"]),
        ]

    def __str__(self):
        return (
            f"{self.asset.asset_number} | {self.get_maintenance_type_display()} "
            f"| {self.scheduled_date} | {self.status}"
        )


# ═══════════════════════════════════════════════════════════════════
# ASSET TRANSFER
# ═══════════════════════════════════════════════════════════════════

class AssetTransfer(UUIDModel, TimeStampedModel):
    STATUS_CHOICES = [
        ("PENDING", "Pending"),
        ("APPROVED", "Approved"),
        ("COMPLETED", "Completed"),
        ("CANCELLED", "Cancelled"),
    ]

    transfer_number = models.CharField(max_length=50, unique=True)
    asset = models.ForeignKey(Asset, on_delete=models.PROTECT, related_name="transfers")
    from_plant = models.ForeignKey(
        Plant, on_delete=models.PROTECT, related_name="asset_transfers_out"
    )
    to_plant = models.ForeignKey(
        Plant, on_delete=models.PROTECT, related_name="asset_transfers_in"
    )
    from_department = models.CharField(max_length=100, blank=True)
    to_department = models.CharField(max_length=100, blank=True)
    from_custodian = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="asset_transfers_from",
    )
    to_custodian = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="asset_transfers_to",
    )
    transfer_date = models.DateField()
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="PENDING")
    reason = models.TextField(blank=True)
    approved_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="asset_transfers_approved",
    )
    approved_at = models.DateTimeField(null=True, blank=True)
    initiated_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="asset_transfers_initiated",
    )

    class Meta:
        ordering = ["-transfer_date"]

    def __str__(self):
        return (
            f"{self.transfer_number} | {self.asset.asset_number} | "
            f"{self.from_plant.code} → {self.to_plant.code} | {self.status}"
        )


# ═══════════════════════════════════════════════════════════════════
# ASSET DISPOSAL
# ═══════════════════════════════════════════════════════════════════

class AssetDisposal(UUIDModel, TimeStampedModel):
    DISPOSAL_METHOD = [
        ("SALE", "Sale"),
        ("SCRAP", "Scrap"),
        ("WRITE_OFF", "Write-Off"),
        ("DONATION", "Donation"),
        ("EXCHANGE", "Exchange"),
    ]
    STATUS_CHOICES = [
        ("DRAFT", "Draft"),
        ("APPROVED", "Approved"),
        ("COMPLETED", "Completed"),
        ("CANCELLED", "Cancelled"),
    ]

    disposal_number = models.CharField(max_length=50, unique=True)
    asset = models.OneToOneField(
        Asset, on_delete=models.PROTECT, related_name="disposal",
    )
    disposal_method = models.CharField(max_length=20, choices=DISPOSAL_METHOD, default="SALE")
    disposal_date = models.DateField()
    book_value_at_disposal = models.DecimalField(max_digits=16, decimal_places=2)
    sale_proceeds = models.DecimalField(max_digits=16, decimal_places=2, default=0)
    gain_loss = models.DecimalField(
        max_digits=16, decimal_places=2, default=0,
        help_text="Positive = gain, negative = loss"
    )
    buyer_name = models.CharField(max_length=200, blank=True)
    buyer_contact = models.CharField(max_length=100, blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="DRAFT")

    # Linked accounting voucher for gain/loss
    voucher = models.ForeignKey(
        "accounts.Voucher", on_delete=models.SET_NULL,
        null=True, blank=True, related_name="asset_disposals",
    )
    approved_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="asset_disposals_approved",
    )
    approved_at = models.DateTimeField(null=True, blank=True)
    initiated_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="asset_disposals_initiated",
    )
    notes = models.TextField(blank=True)

    class Meta:
        ordering = ["-disposal_date"]

    def __str__(self):
        return (
            f"{self.disposal_number} | {self.asset.asset_number} | "
            f"{self.get_disposal_method_display()} | Gain/Loss: {self.gain_loss}"
        )
