"""
Asset Management Module Services — Section 12

All business logic. No logic in viewsets.

Services:
  create_asset()                    — Register a new asset; auto-generate number; link MRR
  generate_depreciation_schedule()  — Pre-compute yearly SLM/WDV schedule
  post_depreciation()               — Post a depreciation period → accounts.Voucher
  schedule_maintenance()            — Log planned/completed maintenance; update asset status
  transfer_asset()                  — Initiate/complete inter-plant transfer
  dispose_asset()                   — Record disposal; compute gain/loss; post voucher
  get_asset_register()              — Summary report of all assets with book values
"""
from __future__ import annotations

from datetime import date
from decimal import Decimal, ROUND_HALF_UP
from typing import Optional

from django.db import transaction
from django.utils import timezone

from apps.core.models import AuditLog, DocSequence, Notification


# ─── Helpers ──────────────────────────────────────────────────────

def _two(val) -> Decimal:
    return Decimal(str(val)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def _log(user, action: str, resource: str, resource_id, details: dict = None):
    AuditLog.objects.create(
        user=user,
        action=action,
        module="assets",
        resource=resource,
        resource_id=str(resource_id),
        new_values=details or {},
    )


def _notify(user, title: str, message: str, resource: str, resource_id):
    if user:
        Notification.objects.create(
            user=user,
            title=title,
            message=message,
            notification_type="IN_APP",
            module="assets",
            resource=resource,
            resource_id=resource_id,
        )


def get_next_doc_number(plant, doc_type: str, prefix: str) -> str:
    """Thread-safe sequential document numbering. Format: PREFIX/YYYY-YY/00001"""
    today = date.today()
    fy_start = today.year if today.month >= 4 else today.year - 1
    fy_label = f"{fy_start}-{str(fy_start + 1)[2:]}"

    with transaction.atomic():
        seq, _ = DocSequence.objects.select_for_update().get_or_create(
            plant=plant,
            doc_type=doc_type,
            defaults={"last_number": 0, "financial_year": fy_label},
        )
        if seq.financial_year != fy_label:
            seq.financial_year = fy_label
            seq.last_number = 0

        seq.last_number += 1
        seq.save(update_fields=["last_number", "financial_year"])
        return f"{prefix}/{fy_label}/{seq.last_number:05d}"


def _financial_year_label(d: date) -> str:
    fy_start = d.year if d.month >= 4 else d.year - 1
    return f"{fy_start}-{str(fy_start + 1)[2:]}"


# ─── DEPRECIATION MATHS ───────────────────────────────────────────

def _compute_slm_annual(cost: Decimal, residual: Decimal, useful_life: int) -> Decimal:
    """Straight-Line Method: equal charge each year."""
    if useful_life <= 0:
        return Decimal("0.00")
    return _two((cost - residual) / useful_life)


def _compute_wdv_annual(opening_value: Decimal, rate_pct: Decimal) -> Decimal:
    """Written-Down Value: rate% of opening book value."""
    return _two(opening_value * rate_pct / 100)


# ═══════════════════════════════════════════════════════════════════
# CREATE ASSET
# ═══════════════════════════════════════════════════════════════════

@transaction.atomic
def create_asset(
    plant,
    name: str,
    category,
    purchase_date: date,
    purchase_cost: Decimal,
    *,
    description: str = "",
    location: str = "",
    department: str = "",
    custodian=None,
    vendor_name: str = "",
    invoice_number: str = "",
    invoice_date: date = None,
    serial_number: str = "",
    model_number: str = "",
    warranty_expiry: date = None,
    amc_expiry: date = None,
    useful_life_years: int = None,
    residual_value: Decimal = None,
    depreciation_method: str = "",
    mrr=None,
    notes: str = "",
    created_by=None,
    auto_schedule: bool = True,
) -> "Asset":
    """
    Register a new fixed asset.

    1. Generate asset_number (AST/YYYY-YY/00001).
    2. Compute residual_value from category.residual_value_pct if not provided.
    3. Create Asset record.
    4. Auto-generate depreciation schedule if auto_schedule=True.
    5. AuditLog + Notification.
    """
    from apps.assets.models import Asset

    # Residual value default: % of cost from category
    if residual_value is None:
        residual_value = _two(
            Decimal(str(purchase_cost)) * category.residual_value_pct / 100
        )

    asset_number = get_next_doc_number(plant, "AST", "AST")

    asset = Asset.objects.create(
        plant=plant,
        asset_number=asset_number,
        name=name,
        description=description,
        category=category,
        purchase_date=purchase_date,
        purchase_cost=_two(purchase_cost),
        location=location,
        department=department,
        custodian=custodian,
        vendor_name=vendor_name,
        invoice_number=invoice_number,
        invoice_date=invoice_date,
        serial_number=serial_number,
        model_number=model_number,
        warranty_expiry=warranty_expiry,
        amc_expiry=amc_expiry,
        useful_life_years=useful_life_years,
        residual_value=residual_value,
        depreciation_method=depreciation_method,
        mrr=mrr,
        notes=notes,
        status="ACTIVE",
        created_by=created_by,
    )

    if auto_schedule and category.depreciation_method != "NO_DEP":
        generate_depreciation_schedule(asset)

    _log(created_by, "CREATE", "Asset", asset.pk, {
        "asset_number": asset_number,
        "category": category.code,
        "purchase_cost": str(purchase_cost),
        "plant": plant.code,
    })
    _notify(created_by, f"Asset Registered: {asset_number}",
            f"Asset '{name}' ({asset_number}) registered at ₹{purchase_cost:,.2f}.",
            "Asset", asset.pk)

    return asset


# ═══════════════════════════════════════════════════════════════════
# DEPRECIATION SCHEDULE
# ═══════════════════════════════════════════════════════════════════

@transaction.atomic
def generate_depreciation_schedule(asset) -> list:
    """
    Pre-compute and store yearly depreciation schedule.

    SLM: equal annual charge = (cost - residual) / useful_life
    WDV: rate% of opening book value each year
    NO_DEP: no schedule generated

    Returns list of DepreciationSchedule rows.
    """
    from apps.assets.models import DepreciationSchedule

    method = asset.effective_depreciation_method
    if method == "NO_DEP":
        return []

    # Delete existing schedule (regenerate)
    DepreciationSchedule.objects.filter(asset=asset).delete()

    useful_life = asset.effective_useful_life
    cost = _two(asset.purchase_cost)
    residual = _two(asset.residual_value)
    wdv_rate = asset.category.depreciation_rate

    # Determine FY start year from purchase date
    p = asset.purchase_date
    fy_start_year = p.year if p.month >= 4 else p.year - 1

    opening = cost
    rows = []

    for yr in range(1, useful_life + 1):
        fy_label = f"{fy_start_year + yr - 1}-{str(fy_start_year + yr)[2:]}"

        if method == "WDV":
            dep = _compute_wdv_annual(opening, wdv_rate)
        else:  # SLM or UNITS
            dep = _compute_slm_annual(cost, residual, useful_life)

        # Don't depreciate below residual
        closing = max(_two(opening - dep), residual)
        dep = _two(opening - closing)

        row = DepreciationSchedule.objects.create(
            asset=asset,
            year_number=yr,
            financial_year=fy_label,
            opening_value=opening,
            depreciation_amount=dep,
            closing_value=closing,
        )
        rows.append(row)
        opening = closing

        if closing <= residual:
            break  # fully depreciated

    return rows


# ═══════════════════════════════════════════════════════════════════
# POST DEPRECIATION
# ═══════════════════════════════════════════════════════════════════

@transaction.atomic
def post_depreciation(
    asset,
    period_label: str,
    depreciation_amount: Decimal = None,
    period_type: str = "ANNUAL",
    posted_by=None,
    notes: str = "",
) -> "AssetDepreciation":
    """
    Post a depreciation entry for an asset.

    Steps:
    1. Validate: asset is ACTIVE; period not already posted.
    2. If depreciation_amount not provided, look up DepreciationSchedule.
    3. Update asset.accumulated_depreciation.
    4. Create accounts.Voucher (JOURNAL):
         DR  Depreciation Expense
         CR  Accumulated Depreciation
    5. Create AssetDepreciation record.
    6. Mark DepreciationSchedule row as is_posted=True.
    """
    from apps.assets.models import AssetDepreciation, DepreciationSchedule
    from apps.accounts.models import Voucher, VoucherLine, LedgerAccount

    if asset.status not in ("ACTIVE", "IDLE"):
        raise ValueError(
            f"Cannot post depreciation for asset in status '{asset.status}'."
        )

    # Prevent duplicate posting
    if AssetDepreciation.objects.filter(asset=asset, period_label=period_label).exists():
        raise ValueError(
            f"Depreciation already posted for asset {asset.asset_number} "
            f"in period '{period_label}'."
        )

    # Resolve amount from schedule if not supplied
    if depreciation_amount is None:
        sched_row = DepreciationSchedule.objects.filter(
            asset=asset, financial_year=period_label, is_posted=False
        ).first()
        if sched_row:
            depreciation_amount = sched_row.depreciation_amount
        else:
            raise ValueError(
                f"No unposted depreciation schedule found for period '{period_label}'. "
                "Supply depreciation_amount explicitly."
            )
    else:
        depreciation_amount = _two(depreciation_amount)
        sched_row = None

    opening_bv = asset.book_value
    closing_bv = _two(opening_bv - depreciation_amount)

    # ── Accounting Voucher ─────────────────────────────────────────
    plant = asset.plant
    voucher = Voucher.objects.create(
        plant=plant,
        voucher_number=get_next_doc_number(plant, "JNL", "JNL"),
        voucher_type=Voucher.VoucherType.JOURNAL,
        voucher_date=date.today(),
        narration=(
            f"Depreciation on {asset.asset_number} — {asset.name} "
            f"for period {period_label}"
        ),
        total_amount=depreciation_amount,
        status=Voucher.VoucherStatus.POSTED,
        created_by=posted_by,
    )

    # Post voucher lines if system ledgers are configured
    try:
        dep_expense = LedgerAccount.objects.get(
            plant=plant,
            sub_type=asset.category.dep_expense_ledger_subtype,
            is_system=True,
        )
        accum_dep = LedgerAccount.objects.get(
            plant=plant,
            sub_type=asset.category.accumulated_dep_ledger_subtype,
            is_system=True,
        )
        VoucherLine.objects.create(
            voucher=voucher,
            ledger=dep_expense,
            debit_amount=depreciation_amount,
            credit_amount=Decimal("0.00"),
            narration=f"Dep on {asset.asset_number} | {period_label}",
        )
        VoucherLine.objects.create(
            voucher=voucher,
            ledger=accum_dep,
            debit_amount=Decimal("0.00"),
            credit_amount=depreciation_amount,
            narration=f"Accum dep {asset.asset_number} | {period_label}",
        )
    except LedgerAccount.DoesNotExist:
        pass  # Ledgers not seeded yet — voucher created without lines

    # Update asset accumulated depreciation
    asset.accumulated_depreciation = _two(
        asset.accumulated_depreciation + depreciation_amount
    )
    asset.save(update_fields=["accumulated_depreciation"])

    # Create depreciation record
    dep_entry = AssetDepreciation.objects.create(
        asset=asset,
        period_type=period_type,
        period_label=period_label,
        depreciation_amount=depreciation_amount,
        opening_book_value=opening_bv,
        closing_book_value=closing_bv,
        voucher=voucher,
        posted_by=posted_by,
        notes=notes,
    )

    # Mark schedule row posted
    if sched_row:
        sched_row.is_posted = True
        sched_row.save(update_fields=["is_posted"])

    _log(posted_by, "CREATE", "AssetDepreciation", dep_entry.pk, {
        "asset_number": asset.asset_number,
        "period": period_label,
        "amount": str(depreciation_amount),
        "voucher": voucher.voucher_number,
    })

    return dep_entry


# ═══════════════════════════════════════════════════════════════════
# MAINTENANCE
# ═══════════════════════════════════════════════════════════════════

@transaction.atomic
def schedule_maintenance(
    asset,
    maintenance_type: str,
    scheduled_date: date,
    *,
    description: str = "",
    vendor_name: str = "",
    cost: Decimal = Decimal("0"),
    performed_by=None,
    complete: bool = False,
    completed_date: date = None,
    findings: str = "",
    parts_replaced: str = "",
    next_maintenance_date: date = None,
) -> "AssetMaintenance":
    """
    Log a maintenance event (scheduled or completed).

    If complete=True: status set to COMPLETED, asset status restored to ACTIVE.
    If complete=False: status set to SCHEDULED, asset status set to UNDER_MAINTENANCE
    only for BREAKDOWN / CORRECTIVE types.
    """
    from apps.assets.models import AssetMaintenance

    maint = AssetMaintenance.objects.create(
        asset=asset,
        maintenance_type=maintenance_type,
        scheduled_date=scheduled_date,
        description=description,
        vendor_name=vendor_name,
        cost=_two(cost),
        performed_by=performed_by,
        next_maintenance_date=next_maintenance_date,
        status="COMPLETED" if complete else "SCHEDULED",
        completed_date=completed_date if complete else None,
        findings=findings if complete else "",
        parts_replaced=parts_replaced if complete else "",
    )

    # Update asset status
    if complete:
        if asset.status == "UNDER_MAINTENANCE":
            asset.status = "ACTIVE"
            asset.save(update_fields=["status"])
    elif maintenance_type in ("BREAKDOWN", "CORRECTIVE"):
        asset.status = "UNDER_MAINTENANCE"
        asset.save(update_fields=["status"])

    _log(performed_by, "CREATE", "AssetMaintenance", maint.pk, {
        "asset_number": asset.asset_number,
        "type": maintenance_type,
        "scheduled_date": str(scheduled_date),
        "complete": complete,
    })

    # Notify custodian
    if asset.custodian:
        _notify(
            asset.custodian,
            f"Maintenance {'Completed' if complete else 'Scheduled'}: {asset.asset_number}",
            f"{asset.name} — {maintenance_type} maintenance "
            f"{'completed' if complete else 'scheduled for'} {completed_date or scheduled_date}.",
            "AssetMaintenance", maint.pk,
        )

    return maint


# ═══════════════════════════════════════════════════════════════════
# TRANSFER
# ═══════════════════════════════════════════════════════════════════

@transaction.atomic
def transfer_asset(
    asset,
    to_plant,
    transfer_date: date,
    *,
    from_department: str = "",
    to_department: str = "",
    from_custodian=None,
    to_custodian=None,
    reason: str = "",
    initiated_by=None,
    complete: bool = False,
    approved_by=None,
) -> "AssetTransfer":
    """
    Initiate or complete an asset transfer.

    On complete=True: asset.plant updated to to_plant, status → ACTIVE.
    On complete=False: creates PENDING transfer record.
    """
    from apps.assets.models import AssetTransfer

    if asset.status == "DISPOSED":
        raise ValueError("Cannot transfer a disposed asset.")

    tr_number = get_next_doc_number(asset.plant, "ATR", "ATR")

    tr_status = "COMPLETED" if complete else "PENDING"
    tr = AssetTransfer.objects.create(
        transfer_number=tr_number,
        asset=asset,
        from_plant=asset.plant,
        to_plant=to_plant,
        from_department=from_department or asset.department,
        to_department=to_department,
        from_custodian=from_custodian or asset.custodian,
        to_custodian=to_custodian,
        transfer_date=transfer_date,
        reason=reason,
        status=tr_status,
        initiated_by=initiated_by,
        approved_by=approved_by if complete else None,
        approved_at=timezone.now() if complete else None,
    )

    if complete:
        asset.plant = to_plant
        asset.department = to_department or asset.department
        asset.custodian = to_custodian or asset.custodian
        asset.status = "ACTIVE"
        asset.save(update_fields=["plant", "department", "custodian", "status"])

    _log(initiated_by, "UPDATE" if complete else "CREATE", "AssetTransfer", tr.pk, {
        "transfer_number": tr_number,
        "asset_number": asset.asset_number,
        "from_plant": asset.plant.code if not complete else tr.from_plant.code,
        "to_plant": to_plant.code,
        "status": tr_status,
    })

    if to_custodian:
        _notify(
            to_custodian,
            f"Asset Transferred to you: {asset.asset_number}",
            f"Asset {asset.name} has been transferred to you at {to_plant.name}.",
            "AssetTransfer", tr.pk,
        )

    return tr


# ═══════════════════════════════════════════════════════════════════
# DISPOSAL
# ═══════════════════════════════════════════════════════════════════

@transaction.atomic
def dispose_asset(
    asset,
    disposal_method: str,
    disposal_date: date,
    sale_proceeds: Decimal = Decimal("0"),
    *,
    buyer_name: str = "",
    buyer_contact: str = "",
    notes: str = "",
    initiated_by=None,
    approved_by=None,
    auto_approve: bool = False,
) -> "AssetDisposal":
    """
    Dispose / scrap / write-off an asset.

    Steps:
    1. Validate: asset not already disposed.
    2. Compute book_value_at_disposal = purchase_cost - accumulated_depreciation.
    3. Compute gain_loss = sale_proceeds - book_value_at_disposal.
    4. Create accounts.Voucher (JOURNAL) for gain/loss:
         DR  Accumulated Depreciation (to clear)
         DR  Cash/Proceeds Receivable (sale_proceeds)
         CR  Asset Ledger (original cost)
         CR/DR  Gain/Loss on Disposal
    5. Update asset.status → DISPOSED.
    6. Create AssetDisposal record.
    """
    from apps.assets.models import AssetDisposal
    from apps.accounts.models import Voucher, VoucherLine, LedgerAccount

    if asset.status == "DISPOSED":
        raise ValueError(f"Asset {asset.asset_number} is already disposed.")

    if AssetDisposal.objects.filter(asset=asset).exclude(status="CANCELLED").exists():
        raise ValueError(f"An active disposal record already exists for {asset.asset_number}.")

    sale_proceeds = _two(sale_proceeds)
    book_value = asset.book_value
    gain_loss = _two(sale_proceeds - book_value)

    disposal_number = get_next_doc_number(asset.plant, "DIS", "DIS")

    # ── Accounting Voucher ─────────────────────────────────────────
    plant = asset.plant
    voucher_amount = _two(max(abs(gain_loss), asset.accumulated_depreciation))

    voucher = Voucher.objects.create(
        plant=plant,
        voucher_number=get_next_doc_number(plant, "JNL", "JNL"),
        voucher_type=Voucher.VoucherType.JOURNAL,
        voucher_date=disposal_date,
        narration=(
            f"Disposal of {asset.asset_number} — {asset.name} "
            f"by {disposal_method}. Gain/Loss: ₹{gain_loss}"
        ),
        total_amount=voucher_amount,
        status=Voucher.VoucherStatus.POSTED,
        created_by=initiated_by,
    )

    # Post gain/loss lines if ledgers available
    try:
        asset_ledger = LedgerAccount.objects.get(
            plant=plant,
            sub_type=asset.category.asset_ledger_subtype,
            is_system=True,
        )
        accum_dep_ledger = LedgerAccount.objects.get(
            plant=plant,
            sub_type=asset.category.accumulated_dep_ledger_subtype,
            is_system=True,
        )
        # DR: Accumulated Depreciation (clear)
        if asset.accumulated_depreciation > 0:
            VoucherLine.objects.create(
                voucher=voucher,
                ledger=accum_dep_ledger,
                debit_amount=_two(asset.accumulated_depreciation),
                credit_amount=Decimal("0.00"),
                narration="Clear accumulated depreciation on disposal",
            )
        # CR: Asset at cost
        VoucherLine.objects.create(
            voucher=voucher,
            ledger=asset_ledger,
            debit_amount=Decimal("0.00"),
            credit_amount=_two(asset.purchase_cost),
            narration=f"Remove asset {asset.asset_number} at cost",
        )
        # Gain or loss entry
        if gain_loss != 0:
            try:
                gl_subtype = "GAIN_ON_DISPOSAL" if gain_loss > 0 else "LOSS_ON_DISPOSAL"
                gl_ledger = LedgerAccount.objects.get(
                    plant=plant, sub_type=gl_subtype, is_system=True
                )
                if gain_loss > 0:
                    VoucherLine.objects.create(
                        voucher=voucher, ledger=gl_ledger,
                        debit_amount=Decimal("0.00"), credit_amount=gain_loss,
                        narration="Gain on disposal",
                    )
                else:
                    VoucherLine.objects.create(
                        voucher=voucher, ledger=gl_ledger,
                        debit_amount=abs(gain_loss), credit_amount=Decimal("0.00"),
                        narration="Loss on disposal",
                    )
            except LedgerAccount.DoesNotExist:
                pass
    except LedgerAccount.DoesNotExist:
        pass  # Ledgers not configured — voucher created without detail lines

    # Mark asset disposed
    asset.status = "DISPOSED"
    asset.disposal_date = disposal_date
    asset.disposal_value = sale_proceeds
    asset.disposal_remarks = notes
    asset.save(update_fields=["status", "disposal_date", "disposal_value", "disposal_remarks"])

    disposal_status = "COMPLETED" if (auto_approve or approved_by) else "APPROVED" if approved_by else "DRAFT"
    disposal = AssetDisposal.objects.create(
        disposal_number=disposal_number,
        asset=asset,
        disposal_method=disposal_method,
        disposal_date=disposal_date,
        book_value_at_disposal=book_value,
        sale_proceeds=sale_proceeds,
        gain_loss=gain_loss,
        buyer_name=buyer_name,
        buyer_contact=buyer_contact,
        status="COMPLETED" if (auto_approve or approved_by) else "DRAFT",
        voucher=voucher,
        approved_by=approved_by,
        approved_at=timezone.now() if approved_by else None,
        initiated_by=initiated_by,
        notes=notes,
    )

    _log(initiated_by, "UPDATE", "AssetDisposal", disposal.pk, {
        "disposal_number": disposal_number,
        "asset_number": asset.asset_number,
        "method": disposal_method,
        "sale_proceeds": str(sale_proceeds),
        "gain_loss": str(gain_loss),
        "voucher": voucher.voucher_number,
    })

    _notify(
        initiated_by,
        f"Asset Disposed: {asset.asset_number}",
        f"Asset {asset.name} disposed by {disposal_method}. "
        f"{'Gain' if gain_loss >= 0 else 'Loss'}: ₹{abs(gain_loss):,.2f}",
        "AssetDisposal", disposal.pk,
    )

    return disposal


# ═══════════════════════════════════════════════════════════════════
# ASSET REGISTER REPORT
# ═══════════════════════════════════════════════════════════════════

def get_asset_register(plant, status: str = None, category=None) -> list[dict]:
    """
    Return asset register: all assets with purchase cost, accumulated dep, book value.
    Optionally filtered by status or category.
    """
    from apps.assets.models import Asset

    qs = Asset.objects.filter(plant=plant).select_related("category", "custodian")
    if status:
        qs = qs.filter(status=status)
    if category:
        qs = qs.filter(category=category)

    result = []
    for asset in qs:
        result.append({
            "asset_number": asset.asset_number,
            "name": asset.name,
            "category": asset.category.name,
            "status": asset.status,
            "purchase_date": str(asset.purchase_date),
            "purchase_cost": asset.purchase_cost,
            "accumulated_depreciation": asset.accumulated_depreciation,
            "book_value": asset.book_value,
            "residual_value": asset.residual_value,
            "location": asset.location,
            "department": asset.department,
            "custodian": asset.custodian.get_full_name() if asset.custodian else "",
        })

    return result
