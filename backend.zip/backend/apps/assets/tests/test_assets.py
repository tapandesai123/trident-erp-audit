"""
Asset Management Module Tests — Section 12
22 test cases covering models, depreciation maths (SLM/WDV),
schedule generation, posting, maintenance, transfer, disposal, and asset register.
"""
from decimal import Decimal
from datetime import date, timedelta
from django.test import TestCase
from django.contrib.auth import get_user_model

from apps.core.models import Plant, Company
from apps.assets.models import (
    AssetCategory, Asset, DepreciationSchedule,
    AssetDepreciation, AssetMaintenance,
    AssetTransfer, AssetDisposal,
)
from apps.assets import services

User = get_user_model()


# ─── Fixtures ─────────────────────────────────────────────────────

def make_base():
    company = Company.objects.create(name="AST Test Co", financial_year_start=4)
    plant = Plant.objects.create(company=company, code="AST1", name="Asset Plant 1")
    plant2 = Plant.objects.create(company=company, code="AST2", name="Asset Plant 2")
    user = User.objects.create_user(username="assetmgr", email="assetmgr@test.com", password="x")
    return dict(company=company, plant=plant, plant2=plant2, user=user)


def make_slm_category():
    return AssetCategory.objects.create(
        code="MACH", name="Machinery",
        depreciation_method="SLM",
        useful_life_years=10,
        residual_value_pct=Decimal("5"),
    )


def make_wdv_category():
    return AssetCategory.objects.create(
        code="IT", name="IT Equipment",
        depreciation_method="WDV",
        useful_life_years=3,
        depreciation_rate=Decimal("33.33"),
        residual_value_pct=Decimal("0"),
    )


def make_asset(plant, category, user, purchase_cost=Decimal("100000"),
               purchase_date=date(2025, 4, 1)):
    return services.create_asset(
        plant=plant,
        name=f"Test Asset {Asset.objects.count() + 1}",
        category=category,
        purchase_date=purchase_date,
        purchase_cost=purchase_cost,
        location="Floor 1",
        department="Production",
        vendor_name="ACME Supplies",
        created_by=user,
        auto_schedule=True,
    )


# ═══════════════════════════════════════════════════════════════════
# MODEL TESTS
# ═══════════════════════════════════════════════════════════════════

class TestAssetModels(TestCase):
    def setUp(self):
        self.f = make_base()
        self.cat = make_slm_category()

    def test_01_asset_category_str(self):
        self.assertIn("MACH", str(self.cat))
        self.assertIn("Straight-Line", str(self.cat))

    def test_02_asset_number_generated(self):
        asset = make_asset(self.f["plant"], self.cat, self.f["user"])
        self.assertTrue(asset.asset_number.startswith("AST/"))

    def test_03_asset_book_value_property(self):
        asset = make_asset(self.f["plant"], self.cat, self.f["user"], purchase_cost=Decimal("100000"))
        self.assertEqual(asset.book_value, Decimal("100000.00"))

    def test_04_asset_book_value_after_depreciation(self):
        asset = make_asset(self.f["plant"], self.cat, self.f["user"], purchase_cost=Decimal("100000"))
        asset.accumulated_depreciation = Decimal("9500")
        asset.save()
        self.assertEqual(asset.book_value, Decimal("90500.00"))

    def test_05_asset_str(self):
        asset = make_asset(self.f["plant"], self.cat, self.f["user"])
        self.assertIn("ACTIVE", str(asset))

    def test_06_disposal_str(self):
        asset = make_asset(self.f["plant"], self.cat, self.f["user"])
        disposal = services.dispose_asset(
            asset, "SCRAP", date.today(),
            sale_proceeds=Decimal("5000"),
            initiated_by=self.f["user"],
            auto_approve=True,
        )
        self.assertIn("DIS/", str(disposal))


# ═══════════════════════════════════════════════════════════════════
# DEPRECIATION SCHEDULE TESTS
# ═══════════════════════════════════════════════════════════════════

class TestDepreciationSchedule(TestCase):
    def setUp(self):
        self.f = make_base()

    def test_07_slm_schedule_generated(self):
        """SLM: 10-year asset, residual 5% → 10 equal rows."""
        cat = make_slm_category()
        asset = make_asset(self.f["plant"], cat, self.f["user"],
                           purchase_cost=Decimal("100000"))
        rows = list(asset.depreciation_schedule.all())
        self.assertEqual(len(rows), 10)

    def test_08_slm_annual_depreciation_correct(self):
        """SLM: (100000 - 5000) / 10 = 9500 per year."""
        cat = make_slm_category()
        asset = make_asset(self.f["plant"], cat, self.f["user"],
                           purchase_cost=Decimal("100000"))
        first = asset.depreciation_schedule.first()
        self.assertEqual(first.depreciation_amount, Decimal("9500.00"))

    def test_09_slm_closing_value_correct(self):
        """SLM: closing of year 10 should equal residual."""
        cat = make_slm_category()
        asset = make_asset(self.f["plant"], cat, self.f["user"],
                           purchase_cost=Decimal("100000"))
        last = asset.depreciation_schedule.order_by("year_number").last()
        self.assertEqual(last.closing_value, Decimal("5000.00"))

    def test_10_wdv_schedule_generated(self):
        """WDV: 3-year IT asset gets up to 3 schedule rows."""
        cat = make_wdv_category()
        asset = make_asset(self.f["plant"], cat, self.f["user"],
                           purchase_cost=Decimal("60000"))
        rows = asset.depreciation_schedule.count()
        self.assertGreaterEqual(rows, 1)

    def test_11_wdv_first_year_dep_correct(self):
        """WDV: 33.33% of 60000 = 19998."""
        cat = make_wdv_category()
        asset = make_asset(self.f["plant"], cat, self.f["user"],
                           purchase_cost=Decimal("60000"))
        first = asset.depreciation_schedule.first()
        # 33.33% of 60000 = 19998
        self.assertAlmostEqual(float(first.depreciation_amount), 19998.0, places=0)

    def test_12_no_dep_category_no_schedule(self):
        """NO_DEP category produces empty schedule."""
        cat = AssetCategory.objects.create(
            code="LAND", name="Land",
            depreciation_method="NO_DEP",
            useful_life_years=0,
        )
        asset = make_asset(self.f["plant"], cat, self.f["user"])
        self.assertEqual(asset.depreciation_schedule.count(), 0)


# ═══════════════════════════════════════════════════════════════════
# POST DEPRECIATION TESTS
# ═══════════════════════════════════════════════════════════════════

class TestPostDepreciation(TestCase):
    def setUp(self):
        self.f = make_base()
        self.cat = make_slm_category()
        self.asset = make_asset(self.f["plant"], self.cat, self.f["user"],
                                purchase_cost=Decimal("100000"),
                                purchase_date=date(2025, 4, 1))

    def test_13_post_depreciation_creates_entry(self):
        dep = services.post_depreciation(
            self.asset, "2025-26", posted_by=self.f["user"]
        )
        self.assertIsNotNone(dep)
        self.assertEqual(dep.depreciation_amount, Decimal("9500.00"))

    def test_14_accumulated_dep_updated(self):
        services.post_depreciation(self.asset, "2025-26", posted_by=self.f["user"])
        self.asset.refresh_from_db()
        self.assertEqual(self.asset.accumulated_depreciation, Decimal("9500.00"))

    def test_15_duplicate_period_raises(self):
        services.post_depreciation(self.asset, "2025-26", posted_by=self.f["user"])
        with self.assertRaises(ValueError):
            services.post_depreciation(self.asset, "2025-26")

    def test_16_schedule_row_marked_posted(self):
        services.post_depreciation(self.asset, "2025-26", posted_by=self.f["user"])
        row = DepreciationSchedule.objects.get(asset=self.asset, financial_year="2025-26")
        self.assertTrue(row.is_posted)


# ═══════════════════════════════════════════════════════════════════
# MAINTENANCE TESTS
# ═══════════════════════════════════════════════════════════════════

class TestMaintenance(TestCase):
    def setUp(self):
        self.f = make_base()
        self.asset = make_asset(
            self.f["plant"], make_slm_category(), self.f["user"]
        )

    def test_17_schedule_maintenance_creates_record(self):
        maint = services.schedule_maintenance(
            self.asset, "PREVENTIVE", date.today() + timedelta(days=30),
            description="Monthly PM", vendor_name="Tech Services",
            cost=Decimal("2500"),
        )
        self.assertEqual(maint.status, "SCHEDULED")
        self.assertEqual(maint.maintenance_type, "PREVENTIVE")

    def test_18_breakdown_sets_asset_under_maintenance(self):
        services.schedule_maintenance(
            self.asset, "BREAKDOWN", date.today(),
            description="Motor failure",
        )
        self.asset.refresh_from_db()
        self.assertEqual(self.asset.status, "UNDER_MAINTENANCE")

    def test_19_complete_maintenance_restores_active(self):
        services.schedule_maintenance(
            self.asset, "BREAKDOWN", date.today(),
            description="Motor failure",
        )
        services.schedule_maintenance(
            self.asset, "CORRECTIVE", date.today(),
            description="Motor replaced",
            complete=True,
            completed_date=date.today(),
        )
        self.asset.refresh_from_db()
        self.assertEqual(self.asset.status, "ACTIVE")


# ═══════════════════════════════════════════════════════════════════
# TRANSFER TESTS
# ═══════════════════════════════════════════════════════════════════

class TestTransfer(TestCase):
    def setUp(self):
        self.f = make_base()
        self.asset = make_asset(
            self.f["plant"], make_slm_category(), self.f["user"]
        )

    def test_20_transfer_pending(self):
        tr = services.transfer_asset(
            self.asset, self.f["plant2"], date.today(),
            reason="Capacity rebalancing",
            initiated_by=self.f["user"],
            complete=False,
        )
        self.assertEqual(tr.status, "PENDING")
        # Asset plant unchanged while pending
        self.asset.refresh_from_db()
        self.assertEqual(self.asset.plant_id, self.f["plant"].pk)

    def test_21_transfer_complete_moves_asset(self):
        services.transfer_asset(
            self.asset, self.f["plant2"], date.today(),
            to_department="Engineering",
            initiated_by=self.f["user"],
            complete=True,
            approved_by=self.f["user"],
        )
        self.asset.refresh_from_db()
        self.assertEqual(self.asset.plant_id, self.f["plant2"].pk)
        self.assertEqual(self.asset.department, "Engineering")


# ═══════════════════════════════════════════════════════════════════
# DISPOSAL TESTS
# ═══════════════════════════════════════════════════════════════════

class TestDisposal(TestCase):
    def setUp(self):
        self.f = make_base()
        self.asset = make_asset(
            self.f["plant"], make_slm_category(), self.f["user"],
            purchase_cost=Decimal("100000"),
        )
        # Partially depreciate
        self.asset.accumulated_depreciation = Decimal("30000")
        self.asset.save()

    def test_22_disposal_gain_computed(self):
        """book_value = 70000; sale_proceeds = 80000 → gain = 10000"""
        disposal = services.dispose_asset(
            self.asset, "SALE", date.today(),
            sale_proceeds=Decimal("80000"),
            buyer_name="ABC Corp",
            initiated_by=self.f["user"],
            auto_approve=True,
        )
        self.assertEqual(disposal.gain_loss, Decimal("10000.00"))
        self.assertEqual(disposal.book_value_at_disposal, Decimal("70000.00"))
        self.asset.refresh_from_db()
        self.assertEqual(self.asset.status, "DISPOSED")

    def test_23_disposal_loss_computed(self):
        """book_value = 70000; scrap proceeds = 10000 → loss = -60000"""
        disposal = services.dispose_asset(
            self.asset, "SCRAP", date.today(),
            sale_proceeds=Decimal("10000"),
            initiated_by=self.f["user"],
            auto_approve=True,
        )
        self.assertEqual(disposal.gain_loss, Decimal("-60000.00"))

    def test_24_double_disposal_raises(self):
        services.dispose_asset(
            self.asset, "SCRAP", date.today(),
            initiated_by=self.f["user"], auto_approve=True,
        )
        with self.assertRaises(ValueError):
            services.dispose_asset(
                self.asset, "SALE", date.today(),
                initiated_by=self.f["user"],
            )
