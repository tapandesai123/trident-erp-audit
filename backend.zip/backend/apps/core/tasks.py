"""
Core Celery tasks — system maintenance and MLF billing automation.
"""
from celery import shared_task
from django.utils import timezone
from django.db.models import Count
import logging

logger = logging.getLogger(__name__)


@shared_task(bind=True, max_retries=3)
def snapshot_daily_usage(self):
    """
    Nightly task: Creates MLFUsageSnapshot from AuditLog counts.
    Captures active users and per-module transaction counts for billing evidence.
    """
    from apps.core.models import AuditLog, MLFUsageSnapshot

    today = timezone.now().date()

    # Skip if snapshot already exists for today
    if MLFUsageSnapshot.objects.filter(date=today).exists():
        logger.info(f"MLF snapshot for {today} already exists — skipping.")
        return

    try:
        # Count active users (users who performed any action today)
        today_logs = AuditLog.objects.filter(timestamp__date=today)
        active_users = today_logs.values("user").distinct().count()
        login_count = today_logs.filter(action="LOGIN").count()

        # Per-module transaction counts
        transactions = {}
        module_actions = today_logs.values("module").annotate(count=Count("id"))
        for row in module_actions:
            if row["module"]:
                transactions[row["module"]] = row["count"]

        MLFUsageSnapshot.objects.create(
            date=today,
            active_users=active_users,
            login_count=login_count,
            transactions=transactions,
        )
        logger.info(f"MLF snapshot created for {today}: {active_users} users, {sum(transactions.values())} txns.")

    except Exception as exc:
        logger.error(f"Failed to create MLF snapshot: {exc}")
        raise self.retry(exc=exc, countdown=3600)


@shared_task
def auto_mark_overdue_rgp():
    """
    Daily task: Mark RGP challans as OVERDUE when expected_return < today and not yet returned.
    """
    from apps.purchase.models import RGPChallan

    today = timezone.now().date()
    overdue_qs = RGPChallan.objects.filter(
        expected_return__lt=today,
        status__in=["DRAFT", "SENT", "PARTIAL"],
    )
    count = overdue_qs.update(status="OVERDUE")
    logger.info(f"Marked {count} RGP challans as OVERDUE.")
    return count


@shared_task
def auto_update_sauda_status():
    """
    Daily task: Expire saudas past their valid_to date; mark exhausted ones.
    """
    from apps.purchase.models import VendorSauda
    from django.db.models import F

    today = timezone.now().date()

    # Expire past valid_to
    expired = VendorSauda.objects.filter(
        valid_to__lt=today, status="ACTIVE"
    ).update(status="EXPIRED")

    # Exhausted — ordered_qty >= agreed_qty
    exhausted = VendorSauda.objects.filter(
        status="ACTIVE", ordered_qty__gte=F("agreed_qty")
    ).update(status="EXHAUSTED")

    logger.info(f"Sauda auto-status: {expired} expired, {exhausted} exhausted.")
    return {"expired": expired, "exhausted": exhausted}
