"""
Middleware to inject plant context from request header or user default.
All views can access request.plant for the current plant.
"""
from apps.core.models import Plant


class PlantContextMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        plant = None
        # Check header first (X-Plant-Code)
        plant_code = request.META.get("HTTP_X_PLANT_CODE")
        if plant_code:
            try:
                plant = Plant.objects.get(code=plant_code, is_active=True)
            except Plant.DoesNotExist:
                pass

        # Fallback to user's default plant
        if not plant and hasattr(request, "user") and request.user.is_authenticated:
            plant = getattr(request.user, "plant", None)

        request.plant = plant
        return self.get_response(request)
