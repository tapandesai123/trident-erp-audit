"""Core signals - audit logging, notifications, etc."""
# Signals will be implemented in subsequent sections.
# Example: post_save on critical models to create AuditLog entries.
