"""
Core models: Company, Plant, User (custom), Department, Role, Permission, AuditLog,
SystemConfig, DocSequence, Attachment, Notification.
"""
import uuid
from decimal import Decimal
from django.conf import settings
from django.contrib.auth.models import AbstractUser, BaseUserManager
from django.db import models
from django.utils import timezone


# ─── Abstract Base ─────────────────────────────────────────────────

class TimeStampedModel(models.Model):
    """Abstract base with created/updated timestamps."""
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        abstract = True


class UUIDModel(models.Model):
    """Abstract base with UUID field."""
    uuid = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)

    class Meta:
        abstract = True


# ─── Company & Plant ───────────────────────────────────────────────

class Company(UUIDModel, TimeStampedModel):
    name = models.CharField(max_length=200)
    legal_name = models.CharField(max_length=300, blank=True)
    gstin = models.CharField(max_length=15, blank=True)
    pan = models.CharField(max_length=10, blank=True)
    cin = models.CharField(max_length=21, blank=True)
    address_line1 = models.CharField(max_length=300, blank=True)
    address_line2 = models.CharField(max_length=300, blank=True)
    city = models.CharField(max_length=100, blank=True)
    state = models.CharField(max_length=100, blank=True)
    pincode = models.CharField(max_length=10, blank=True)
    country = models.CharField(max_length=100, default="India")
    phone = models.CharField(max_length=20, blank=True)
    email = models.EmailField(blank=True)
    website = models.URLField(blank=True)
    logo = models.ImageField(upload_to="company_logos/", blank=True, null=True)
    financial_year_start = models.IntegerField(
        default=4, help_text="Month number (1-12) when FY starts"
    )
    is_active = models.BooleanField(default=True)

    class Meta:
        verbose_name_plural = "companies"
        ordering = ["name"]

    def __str__(self):
        return self.name


class Plant(UUIDModel, TimeStampedModel):
    company = models.ForeignKey(Company, on_delete=models.CASCADE, related_name="plants")
    code = models.CharField(max_length=10, unique=True)
    name = models.CharField(max_length=200)
    address_line1 = models.CharField(max_length=300, blank=True)
    address_line2 = models.CharField(max_length=300, blank=True)
    city = models.CharField(max_length=100, blank=True)
    state = models.CharField(max_length=100, blank=True)
    pincode = models.CharField(max_length=10, blank=True)
    gstin = models.CharField(max_length=15, blank=True)
    is_active = models.BooleanField(default=True)
    fifo_enforcement = models.CharField(
        max_length=10,
        choices=[('OFF', 'Off'), ('WARN', 'Warn only'), ('HARD', 'Hard block')],
        default='WARN',
    )

    # Stock issue mode (F5)
    STOCK_ISSUE_FIFO   = "FIFO"
    STOCK_ISSUE_FEFO   = "FEFO"
    STOCK_ISSUE_MANUAL = "MANUAL"
    STOCK_ISSUE_MODE_CHOICES = [
        (STOCK_ISSUE_FIFO,   "FIFO (oldest first)"),
        (STOCK_ISSUE_FEFO,   "FEFO (earliest expiry first)"),
        (STOCK_ISSUE_MANUAL, "Manual (operator selects)"),
    ]
    stock_issue_mode = models.CharField(
        max_length=10,
        choices=STOCK_ISSUE_MODE_CHOICES,
        default=STOCK_ISSUE_FIFO,
        help_text="Stock issuing mode: FIFO, FEFO, or Manual",
    )

    class Meta:
        ordering = ["code"]
        verbose_name = "Plant"
        verbose_name_plural = "Plants"

    def __str__(self):
        return f"{self.code} - {self.name}"


class Department(TimeStampedModel):
    plant = models.ForeignKey(Plant, on_delete=models.CASCADE, related_name="departments")
    code = models.CharField(max_length=20)
    name = models.CharField(max_length=100)
    is_active = models.BooleanField(default=True)

    class Meta:
        unique_together = ["plant", "code"]
        ordering = ["code"]

    def __str__(self):
        return f"{self.code} - {self.name}"


# ─── RBAC ──────────────────────────────────────────────────────────

class Role(TimeStampedModel):
    name = models.CharField(max_length=100, unique=True)
    description = models.TextField(blank=True)
    is_system = models.BooleanField(default=False, help_text="Built-in role, cannot be deleted")
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ["name"]

    def __str__(self):
        return self.name


class Permission(models.Model):
    MODULE_CHOICES = [
        ("core", "Core"),
        ("masters", "Masters"),
        ("purchase", "Purchase"),
        ("stores", "Stores"),
        ("sales", "Sales"),
        ("accounts", "Accounts"),
        ("production", "Production"),
        ("quality", "Quality"),
        ("tasks", "Tasks"),
        ("reports", "Reports"),
        ("webtel", "Webtel"),
        ("hr", "HR & Payroll"),
        ("assets", "Asset Management"),
    ]

    module = models.CharField(max_length=50, choices=MODULE_CHOICES)
    action = models.CharField(max_length=50)  # create, read, update, delete, approve, export
    resource = models.CharField(max_length=100)  # purchase_order, vendor_master, etc.
    description = models.TextField(blank=True)

    class Meta:
        unique_together = ["module", "action", "resource"]
        ordering = ["module", "resource", "action"]

    def __str__(self):
        return f"{self.module}.{self.resource}.{self.action}"


class RolePermission(models.Model):
    role = models.ForeignKey(Role, on_delete=models.CASCADE, related_name="permissions")
    permission = models.ForeignKey(Permission, on_delete=models.CASCADE)

    class Meta:
        unique_together = ["role", "permission"]


# ─── Custom User ───────────────────────────────────────────────────

class UserManager(BaseUserManager):
    def create_user(self, username, email, password=None, **extra_fields):
        if not email:
            raise ValueError("Email is required")
        email = self.normalize_email(email)
        user = self.model(username=username, email=email, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, username, email, password=None, **extra_fields):
        extra_fields.setdefault("is_staff", True)
        extra_fields.setdefault("is_superuser", True)
        extra_fields.setdefault("is_superadmin", True)
        return self.create_user(username, email, password, **extra_fields)


class User(AbstractUser, UUIDModel):
    email = models.EmailField(unique=True)
    phone = models.CharField(max_length=20, blank=True)
    employee_code = models.CharField(max_length=20, blank=True)
    department = models.ForeignKey(
        Department, on_delete=models.SET_NULL, null=True, blank=True, related_name="users"
    )
    plant = models.ForeignKey(
        Plant, on_delete=models.SET_NULL, null=True, blank=True, related_name="users"
    )
    is_superadmin = models.BooleanField(default=False)

    # 2FA
    otp_secret = models.CharField(max_length=64, blank=True)
    otp_enabled = models.BooleanField(default=False)

    # Security
    password_changed_at = models.DateTimeField(null=True, blank=True)
    failed_login_count = models.IntegerField(default=0)
    locked_until = models.DateTimeField(null=True, blank=True)

    # RBAC
    roles = models.ManyToManyField(Role, through="UserRole", blank=True)

    objects = UserManager()

    USERNAME_FIELD = "username"
    REQUIRED_FIELDS = ["email"]

    class Meta:
        ordering = ["username"]

    def __str__(self):
        return f"{self.username} ({self.get_full_name()})"

    @property
    def is_locked(self):
        if self.locked_until and self.locked_until > timezone.now():
            return True
        return False

    def get_all_permissions_list(self):
        """Return flat list of permission strings for this user."""
        if self.is_superadmin:
            return Permission.objects.values_list("module", "action", "resource")
        return Permission.objects.filter(
            rolepermission__role__userrole__user=self,
            rolepermission__role__is_active=True,
        ).values_list("module", "action", "resource")

    def has_erp_permission(self, module, action, resource):
        """Check if user has a specific ERP permission."""
        if self.is_superadmin:
            return True
        return Permission.objects.filter(
            module=module,
            action=action,
            resource=resource,
            rolepermission__role__userrole__user=self,
            rolepermission__role__is_active=True,
        ).exists()


class UserRole(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    role = models.ForeignKey(Role, on_delete=models.CASCADE)
    plant = models.ForeignKey(Plant, on_delete=models.SET_NULL, null=True, blank=True)

    class Meta:
        unique_together = ["user", "role", "plant"]


# ─── Audit Log ─────────────────────────────────────────────────────

class AuditLog(models.Model):
    ACTION_CHOICES = [
        ("CREATE",   "Create"),
        ("UPDATE",   "Update"),
        ("DELETE",   "Delete"),
        ("LOGIN",    "Login"),
        ("LOGOUT",   "Logout"),
        ("APPROVE",  "Approve"),
        ("REJECT",   "Reject"),
        ("EXPORT",   "Export"),
        ("SMS_SENT", "SMS Sent"),   # Task 17
        ("FIFO_OVERRIDE", "FIFO Override"),  # Task 18
        ("BIN_ASSIGN",    "Bin Assigned"),
        ("STOCK_ISSUE",   "Stock Issued"),
        ("STOCK_RETURN",  "Stock Returned"),
        ("STOCK_TRANSFER", "Stock Transfer"),
        ("PV_START",      "PV Started"),
        ("PV_COMPLETE",   "PV Completed"),
        ("PV_POSTED",     "PV Adjustments Posted"),
    ]

    user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name="audit_logs")
    action = models.CharField(max_length=20, choices=ACTION_CHOICES)
    module = models.CharField(max_length=50)
    resource = models.CharField(max_length=100)
    resource_id = models.IntegerField(null=True, blank=True)
    resource_uuid = models.UUIDField(null=True, blank=True)
    old_values = models.JSONField(null=True, blank=True)
    new_values = models.JSONField(null=True, blank=True)
    ip_address = models.GenericIPAddressField(null=True, blank=True)
    user_agent = models.TextField(blank=True)
    notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)

    class Meta:
        ordering = ["-created_at"]
        indexes = [
            models.Index(fields=["module", "resource", "resource_id"]),
            models.Index(fields=["user", "created_at"]),
        ]

    def __str__(self):
        return f"{self.user} {self.action} {self.module}.{self.resource} #{self.resource_id}"


# ─── System Configuration ─────────────────────────────────────────

class SystemConfig(models.Model):
    VALUE_TYPES = [("string", "String"), ("integer", "Integer"), ("boolean", "Boolean"), ("json", "JSON")]

    plant = models.ForeignKey(Plant, on_delete=models.CASCADE, null=True, blank=True)
    config_key = models.CharField(max_length=100)
    config_value = models.TextField(blank=True)
    value_type = models.CharField(max_length=20, choices=VALUE_TYPES, default="string")
    description = models.TextField(blank=True)

    class Meta:
        unique_together = ["plant", "config_key"]
        ordering = ["config_key"]

    def __str__(self):
        return f"{self.config_key} = {self.config_value}"

    def get_typed_value(self):
        if self.value_type == "integer":
            return int(self.config_value)
        elif self.value_type == "boolean":
            return self.config_value.lower() in ("true", "1", "yes")
        elif self.value_type == "json":
            import json
            return json.loads(self.config_value)
        return self.config_value


# ─── Document Numbering ───────────────────────────────────────────

class DocSequence(models.Model):
    plant = models.ForeignKey(Plant, on_delete=models.CASCADE, related_name="doc_sequences")
    doc_type = models.CharField(max_length=50)  # PR, PO, MRR, INV, DC, SO, WO
    prefix = models.CharField(max_length=20, blank=True)
    financial_year = models.CharField(max_length=10)  # e.g., '2026-27'
    last_number = models.IntegerField(default=0)
    format_pattern = models.CharField(
        max_length=100,
        default="{prefix}/{fy}/{num:05d}",
        help_text="Pattern: {prefix}, {fy}, {num:05d}"
    )

    class Meta:
        unique_together = ["plant", "doc_type", "financial_year"]

    def __str__(self):
        return f"{self.plant.code}/{self.doc_type}/{self.financial_year} - Last: {self.last_number}"

    def get_next_number(self):
        """Thread-safe next number generation using select_for_update."""
        from django.db import transaction
        with transaction.atomic():
            seq = DocSequence.objects.select_for_update().get(pk=self.pk)
            seq.last_number += 1
            seq.save(update_fields=["last_number"])
            return seq.format_pattern.format(
                prefix=seq.prefix,
                fy=seq.financial_year,
                num=seq.last_number,
            )


# ─── Attachments ──────────────────────────────────────────────────

class Attachment(UUIDModel, TimeStampedModel):
    module = models.CharField(max_length=50)
    resource = models.CharField(max_length=100)
    resource_id = models.IntegerField()
    file_name = models.CharField(max_length=300)
    file = models.FileField(upload_to="attachments/%Y/%m/")
    file_size = models.BigIntegerField(null=True, blank=True)
    mime_type = models.CharField(max_length=100, blank=True)
    uploaded_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)

    class Meta:
        indexes = [
            models.Index(fields=["module", "resource", "resource_id"]),
        ]

    def __str__(self):
        return f"{self.file_name} ({self.module}/{self.resource})"


# ─── Notifications ────────────────────────────────────────────────

class Notification(TimeStampedModel):
    TYPE_CHOICES = [
        ("EMAIL", "Email"),
        ("SMS", "SMS"),
        ("PUSH", "Push"),
        ("IN_APP", "In-App"),
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="notifications")
    title = models.CharField(max_length=300)
    message = models.TextField(blank=True)
    notification_type = models.CharField(max_length=30, choices=TYPE_CHOICES, default="IN_APP")
    module = models.CharField(max_length=50, blank=True)
    resource = models.CharField(max_length=100, blank=True)
    resource_id = models.IntegerField(null=True, blank=True)
    is_read = models.BooleanField(default=False)
    sent_at = models.DateTimeField(null=True, blank=True)
    read_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-created_at"]
        indexes = [
            models.Index(fields=["user", "is_read"]),
        ]

    def __str__(self):
        return f"{self.title} → {self.user.username}"


# ─── Approval Workflow Engine ─────────────────────────────────────

class ApprovalWorkflow(models.Model):
    name = models.CharField(max_length=100)
    doc_type = models.CharField(max_length=50, unique=True)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.name} ({self.doc_type})"


class ApprovalStep(models.Model):
    workflow = models.ForeignKey(ApprovalWorkflow, on_delete=models.CASCADE, related_name="steps")
    step_order = models.IntegerField()
    approver_role = models.ForeignKey(Role, on_delete=models.SET_NULL, null=True, blank=True)
    approver_user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    condition = models.JSONField(
        null=True, blank=True,
        help_text='Conditional routing, e.g., {"amount_gt": 50000}'
    )

    class Meta:
        unique_together = ["workflow", "step_order"]
        ordering = ["step_order"]

    def __str__(self):
        approver = self.approver_user or self.approver_role
        return f"Step {self.step_order}: {approver}"


class ApprovalRequest(TimeStampedModel):
    STATUS_CHOICES = [
        ("PENDING", "Pending"),
        ("APPROVED", "Approved"),
        ("REJECTED", "Rejected"),
        ("CANCELLED", "Cancelled"),
    ]

    workflow = models.ForeignKey(ApprovalWorkflow, on_delete=models.CASCADE)
    doc_type = models.CharField(max_length=50)
    doc_id = models.IntegerField()
    current_step = models.IntegerField(default=1)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="PENDING")
    initiated_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)

    def __str__(self):
        return f"{self.doc_type} #{self.doc_id} - {self.status}"


class ApprovalAction(models.Model):
    ACTION_CHOICES = [
        ("APPROVED", "Approved"),
        ("REJECTED", "Rejected"),
        ("RETURNED", "Returned"),
    ]

    request = models.ForeignKey(ApprovalRequest, on_delete=models.CASCADE, related_name="actions")
    step = models.ForeignKey(ApprovalStep, on_delete=models.CASCADE)
    action = models.CharField(max_length=20, choices=ACTION_CHOICES)
    acted_by = models.ForeignKey(User, on_delete=models.CASCADE)
    remarks = models.TextField(blank=True)
    acted_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["acted_at"]


# ═══════════════════════════════════════════════════════════════════
# MLF BILLING (MONTHLY LICENSE FEE SIMULATION)
# ═══════════════════════════════════════════════════════════════════

class MLFBillingRecord(UUIDModel, TimeStampedModel):
    """Monthly License Fee simulation. Tracks usage and generates quarterly bills."""
    class BillingStatus(models.TextChoices):
        DRAFT   = "DRAFT",   "Draft"
        ISSUED  = "ISSUED",  "Invoice Issued"
        PAID    = "PAID",    "Paid"
        OVERDUE = "OVERDUE", "Overdue"

    period_start       = models.DateField()
    period_end         = models.DateField()
    quarter            = models.CharField(max_length=20, help_text="e.g., Q1 FY2027-28")
    base_rate          = models.DecimalField(max_digits=10, decimal_places=2)
    inflation_pct      = models.DecimalField(max_digits=5, decimal_places=2, default=Decimal("7.0"))
    months_in_period   = models.PositiveSmallIntegerField(default=3)
    subtotal           = models.DecimalField(max_digits=12, decimal_places=2)
    gst_rate           = models.DecimalField(max_digits=5, decimal_places=2, default=Decimal("18.0"))
    gst_amount         = models.DecimalField(max_digits=12, decimal_places=2)
    total_amount       = models.DecimalField(max_digits=12, decimal_places=2)
    is_free_period     = models.BooleanField(default=False,
                                              help_text="Year 1: Apr-26 to Mar-27 is free")
    status             = models.CharField(max_length=20, choices=BillingStatus.choices,
                                           default=BillingStatus.DRAFT)
    invoice_number     = models.CharField(max_length=50, blank=True)
    due_date           = models.DateField(null=True, blank=True)
    paid_date          = models.DateField(null=True, blank=True)
    active_users       = models.PositiveIntegerField(default=0)
    transactions_count = models.PositiveIntegerField(default=0)
    notes              = models.TextField(blank=True)

    class Meta:
        ordering = ["-period_start"]
        verbose_name = "MLF Billing Record"
        verbose_name_plural = "MLF Billing Records"

    def __str__(self):
        return f"{self.quarter} – ₹{self.total_amount} ({self.status})"


class MLFUsageSnapshot(models.Model):
    """Daily snapshot of system usage for billing evidence."""
    date          = models.DateField(unique=True)
    active_users  = models.PositiveIntegerField(default=0)
    login_count   = models.PositiveIntegerField(default=0)
    transactions  = models.JSONField(default=dict,
                                      help_text="Per-module transaction counts")

    class Meta:
        ordering = ["-date"]
        verbose_name = "MLF Usage Snapshot"
        verbose_name_plural = "MLF Usage Snapshots"

    def __str__(self):
        return f"Usage {self.date}: {self.active_users} users"
