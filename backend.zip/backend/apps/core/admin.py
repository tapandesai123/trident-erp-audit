"""Django Admin configuration for Core module."""
from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from apps.core.models import (
    Company, Plant, Department, Role, Permission, RolePermission,
    User, UserRole, AuditLog, SystemConfig, DocSequence,
    Notification, ApprovalWorkflow, ApprovalStep,
)


@admin.register(Company)
class CompanyAdmin(admin.ModelAdmin):
    list_display = ["name", "gstin", "city", "state", "is_active"]
    search_fields = ["name", "gstin"]


@admin.register(Plant)
class PlantAdmin(admin.ModelAdmin):
    list_display = ["code", "name", "company", "city", "state", "gstin", "fifo_enforcement", "is_active"]
    list_filter = ["company", "is_active", "fifo_enforcement"]
    fieldsets = [
        (None, {"fields": ["company", "code", "name", "is_active"]}),
        ("Address", {"fields": ["address_line1", "address_line2", "city", "state", "pincode", "gstin"]}),
        ("Inventory Settings", {"fields": ["fifo_enforcement"]}),
    ]


@admin.register(Department)
class DepartmentAdmin(admin.ModelAdmin):
    list_display = ["code", "name", "plant", "is_active"]
    list_filter = ["plant"]


class UserRoleInline(admin.TabularInline):
    model = UserRole
    extra = 0


@admin.register(User)
class UserAdmin(BaseUserAdmin):
    list_display = ["username", "email", "employee_code", "department", "plant", "is_active", "is_superadmin"]
    list_filter = ["is_active", "is_superadmin", "plant", "department"]
    inlines = [UserRoleInline]
    fieldsets = BaseUserAdmin.fieldsets + (
        ("ERP Fields", {"fields": ("employee_code", "phone", "department", "plant", "is_superadmin")}),
        ("Security", {"fields": ("otp_enabled", "otp_secret", "failed_login_count", "locked_until")}),
    )


@admin.register(Role)
class RoleAdmin(admin.ModelAdmin):
    list_display = ["name", "is_system", "is_active"]
    list_filter = ["is_system", "is_active"]


@admin.register(Permission)
class PermissionAdmin(admin.ModelAdmin):
    list_display = ["module", "action", "resource"]
    list_filter = ["module", "action"]
    search_fields = ["resource"]


@admin.register(AuditLog)
class AuditLogAdmin(admin.ModelAdmin):
    list_display = ["user", "action", "module", "resource", "resource_id", "created_at"]
    list_filter = ["action", "module", "created_at"]
    search_fields = ["module", "resource", "notes"]
    readonly_fields = ["user", "action", "module", "resource", "resource_id", "old_values", "new_values", "ip_address", "created_at"]
    date_hierarchy = "created_at"

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return False


@admin.register(SystemConfig)
class SystemConfigAdmin(admin.ModelAdmin):
    list_display = ["config_key", "config_value", "value_type", "plant"]
    list_filter = ["value_type", "plant"]
    search_fields = ["config_key"]


@admin.register(DocSequence)
class DocSequenceAdmin(admin.ModelAdmin):
    list_display = ["plant", "doc_type", "prefix", "financial_year", "last_number"]
    list_filter = ["plant", "doc_type"]


@admin.register(ApprovalWorkflow)
class ApprovalWorkflowAdmin(admin.ModelAdmin):
    list_display = ["name", "doc_type", "is_active"]


@admin.register(ApprovalStep)
class ApprovalStepAdmin(admin.ModelAdmin):
    list_display = ["workflow", "step_order", "approver_role", "approver_user"]
    list_filter = ["workflow"]
