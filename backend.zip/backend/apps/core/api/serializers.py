from rest_framework import serializers
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer


class PlantSerializer(serializers.ModelSerializer):
    fifo_enforcement_display = serializers.CharField(source='get_fifo_enforcement_display', read_only=True)
    stock_issue_mode_display = serializers.CharField(source='get_stock_issue_mode_display', read_only=True)

    class Meta:
        from apps.core.models import Plant
        model = Plant
        fields = [
            'id', 'uuid', 'code', 'name', 'address_line1', 'address_line2',
            'city', 'state', 'pincode', 'gstin', 'is_active',
            'fifo_enforcement', 'fifo_enforcement_display',
            'stock_issue_mode', 'stock_issue_mode_display',
        ]
        read_only_fields = ['uuid']


class CustomTokenObtainPairSerializer(TokenObtainPairSerializer):
    @classmethod
    def get_token(cls, user):
        token = super().get_token(user)
        token["username"] = user.username
        token["email"] = user.email
        token["full_name"] = user.get_full_name()
        if user.plant:
            token["plant_code"] = user.plant.code
        return token


# ── MLF Billing Serializers ───────────────────────────────────────

class MLFBillingRecordSerializer(serializers.ModelSerializer):
    status_display = serializers.CharField(source="get_status_display", read_only=True)

    class Meta:
        from apps.core.models import MLFBillingRecord
        model = MLFBillingRecord
        fields = [
            "id", "uuid", "quarter", "period_start", "period_end",
            "base_rate", "inflation_pct", "months_in_period",
            "subtotal", "gst_rate", "gst_amount", "total_amount",
            "is_free_period", "status", "status_display",
            "invoice_number", "due_date", "paid_date",
            "active_users", "transactions_count", "notes", "created_at",
        ]
        read_only_fields = ["uuid", "created_at"]


class MLFUsageSnapshotSerializer(serializers.ModelSerializer):
    class Meta:
        from apps.core.models import MLFUsageSnapshot
        model = MLFUsageSnapshot
        fields = "__all__"
