from django.urls import path, include
from rest_framework.routers import DefaultRouter
from apps.core.api.viewsets import MLFBillingViewSet, PlantViewSet

app_name = "core"

router = DefaultRouter()
router.register("mlf", MLFBillingViewSet, basename="mlf-billing")
router.register("plants", PlantViewSet, basename="plant")

urlpatterns = [
    path("", include(router.urls)),
]
