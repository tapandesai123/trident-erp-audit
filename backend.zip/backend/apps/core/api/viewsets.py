"""Core API Viewsets — MLF Billing Admin Panel."""
from decimal import Decimal
from datetime import date, timedelta
from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, IsAdminUser
from django.contrib.auth import get_user_model

User = get_user_model()


class PlantViewSet(viewsets.ModelViewSet):
    """ViewSet for Plant management including FIFO enforcement settings."""
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        from apps.core.models import Plant
        return Plant.objects.all().order_by('code')

    def get_serializer_class(self):
        from apps.core.api.serializers import PlantSerializer
        return PlantSerializer

MLF_BASE_RATE = Decimal("14670.00")
MLF_INFLATION_PCT = Decimal("7.0")
MLF_FREE_YEAR_END = date(2027, 3, 31)   # Year 1: Apr-26 to Mar-27 free


class MLFBillingViewSet(viewsets.ModelViewSet):
    """
    Admin-only viewset for Monthly License Fee billing simulation.
    Tracks usage, generates quarterly bills with 7% annual inflation.
    """
    permission_classes = [IsAuthenticated, IsAdminUser]

    def get_queryset(self):
        from apps.core.models import MLFBillingRecord
        return MLFBillingRecord.objects.all().order_by("-period_start")

    def get_serializer_class(self):
        from apps.core.api.serializers import MLFBillingRecordSerializer
        return MLFBillingRecordSerializer

    @action(detail=False, methods=["post"])
    def generate_quarter(self, request):
        """Generate the next billing record using base rate + 7% annual inflation."""
        from apps.core.models import MLFBillingRecord

        last = MLFBillingRecord.objects.order_by("-period_end").first()

        if last:
            period_start = last.period_end + timedelta(days=1)
        else:
            # Start from April 2027 (after free year)
            period_start = date(2027, 4, 1)

        period_end = date(period_start.year + (1 if period_start.month > 9 else 0),
                          ((period_start.month + 2) % 12) or 12,
                          30)
        # Simplify: always 3 months
        m = period_start.month
        y = period_start.year
        end_month = ((m + 2 - 1) % 12) + 1
        end_year = y + ((m + 2 - 1) // 12)
        import calendar
        last_day = calendar.monthrange(end_year, end_month)[1]
        period_end = date(end_year, end_month, last_day)

        is_free = period_end <= MLF_FREE_YEAR_END

        # Inflation: count full financial years after FY 2026-27
        fy_start = date(2027, 4, 1)
        if period_start > fy_start:
            years_elapsed = (period_start.year - fy_start.year)
            if period_start.month < 4:
                years_elapsed -= 1
            years_elapsed = max(0, years_elapsed)
        else:
            years_elapsed = 0

        effective_rate = MLF_BASE_RATE * ((1 + MLF_INFLATION_PCT / 100) ** years_elapsed)
        effective_rate = effective_rate.quantize(Decimal("0.01"))

        subtotal = Decimal("0.00") if is_free else (effective_rate * 3)
        gst_rate = Decimal("18.0")
        gst_amount = (subtotal * gst_rate / 100).quantize(Decimal("0.01"))
        total_amount = subtotal + gst_amount

        fy_year = period_start.year if period_start.month >= 4 else period_start.year - 1
        q_num = ((period_start.month - 4) % 12) // 3 + 1 if period_start.month >= 4 else \
                ((period_start.month + 8) % 12) // 3 + 1
        quarter_label = f"Q{q_num} FY{fy_year}-{str(fy_year + 1)[-2:]}"

        record = MLFBillingRecord.objects.create(
            period_start=period_start,
            period_end=period_end,
            quarter=quarter_label,
            base_rate=effective_rate,
            inflation_pct=MLF_INFLATION_PCT,
            months_in_period=3,
            subtotal=subtotal,
            gst_rate=gst_rate,
            gst_amount=gst_amount,
            total_amount=total_amount,
            is_free_period=is_free,
            status="DRAFT",
        )

        from apps.core.api.serializers import MLFBillingRecordSerializer
        return Response(MLFBillingRecordSerializer(record).data, status=201)

    @action(detail=True, methods=["post"])
    def mark_paid(self, request, pk=None):
        """Mark a billing record as paid."""
        from apps.core.models import MLFBillingRecord
        record = self.get_object()
        paid_date_str = request.data.get("paid_date", str(date.today()))
        record.status = MLFBillingRecord.BillingStatus.PAID
        record.paid_date = date.fromisoformat(paid_date_str)
        record.save(update_fields=["status", "paid_date"])
        from apps.core.api.serializers import MLFBillingRecordSerializer
        return Response(MLFBillingRecordSerializer(record).data)

    @action(detail=False, methods=["get"])
    def usage_summary(self, request):
        """Current month active users, login count, module transaction counts."""
        from apps.core.models import AuditLog, MLFUsageSnapshot
        from django.utils import timezone
        from django.db.models import Count

        today = timezone.now().date()
        month_start = today.replace(day=1)

        # Active users today
        active_today = AuditLog.objects.filter(
            timestamp__date=today
        ).values("user").distinct().count() if hasattr(AuditLog, "user") else 0

        # Monthly login count (action = LOGIN)
        login_count = AuditLog.objects.filter(
            timestamp__date__gte=month_start,
            action="LOGIN",
        ).count() if hasattr(AuditLog, "action") else 0

        # Module-level transaction counts
        module_counts = {}
        try:
            module_counts = dict(
                AuditLog.objects.filter(
                    timestamp__date__gte=month_start
                ).values_list("resource_type").annotate(count=Count("id")).values_list("resource_type", "count")
            )
        except Exception:
            pass

        # Latest snapshot
        latest_snapshot = MLFUsageSnapshot.objects.first()

        return Response({
            "today": str(today),
            "active_users_today": active_today,
            "login_count_this_month": login_count,
            "module_transactions": module_counts,
            "latest_snapshot": {
                "date": str(latest_snapshot.date) if latest_snapshot else None,
                "active_users": latest_snapshot.active_users if latest_snapshot else 0,
            },
            "current_rate": float(MLF_BASE_RATE),
            "free_until": str(MLF_FREE_YEAR_END),
        })
