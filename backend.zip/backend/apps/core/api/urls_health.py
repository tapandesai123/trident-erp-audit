from django.urls import path
from django.http import JsonResponse


def health_check(request):
    return JsonResponse({"status": "ok", "service": "trident-erp"})


urlpatterns = [
    path("", health_check, name="health-check"),
]
