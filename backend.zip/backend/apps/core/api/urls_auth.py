from django.urls import path
from rest_framework_simplejwt.views import TokenRefreshView, TokenObtainPairView
from apps.core.api.views_auth import LoginView, LogoutView, MeView

app_name = "auth"
urlpatterns = [
    # Frontend-compatible endpoints
    path("login/", LoginView.as_view(), name="login"),
    path("logout/", LogoutView.as_view(), name="logout"),
    path("me/", MeView.as_view(), name="me"),
    # Raw JWT endpoints (for API clients)
    path("token/obtain/", TokenObtainPairView.as_view(), name="token-obtain"),
    path("token/refresh/", TokenRefreshView.as_view(), name="token-refresh"),
]
