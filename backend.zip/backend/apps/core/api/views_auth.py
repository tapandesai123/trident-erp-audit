"""Custom auth views to match the frontend's expected API contract."""
from django.contrib.auth import get_user_model
from django.utils.decorators import method_decorator
from django.views.decorators.csrf import csrf_exempt
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework_simplejwt.exceptions import TokenError

User = get_user_model()


@method_decorator(csrf_exempt, name="dispatch")
class LoginView(APIView):
    """
    POST /api/v1/auth/login/
    Body: { username, password }
    Returns: { access, refresh, user, plants }
    """
    permission_classes = [AllowAny]
    authentication_classes = []  # No session auth — prevents DRF re-enabling CSRF

    def post(self, request):
        from django.contrib.auth import authenticate
        from apps.core.models import Plant

        username = request.data.get("username", "").strip()
        password = request.data.get("password", "")

        if not username or not password:
            return Response(
                {"detail": "Username and password are required."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        user = authenticate(request, username=username, password=password)

        if user is None:
            return Response(
                {"detail": "Invalid credentials. Please try again."},
                status=status.HTTP_401_UNAUTHORIZED,
            )

        if not user.is_active:
            return Response(
                {"detail": "This account has been disabled."},
                status=status.HTTP_403_FORBIDDEN,
            )

        # Check account lockout
        from django.utils import timezone
        if user.locked_until and user.locked_until > timezone.now():
            return Response(
                {"detail": "Account is temporarily locked. Please try later."},
                status=status.HTTP_403_FORBIDDEN,
            )

        # Reset failed login count on success
        user.failed_login_count = 0
        user.save(update_fields=["failed_login_count"])

        # Generate JWT tokens
        refresh = RefreshToken.for_user(user)
        access = refresh.access_token

        # Add custom claims
        access["username"] = user.username
        access["email"] = user.email
        access["full_name"] = user.get_full_name()
        if user.plant:
            access["plant_code"] = user.plant.code

        # Build user payload
        user_data = {
            "id": user.id,
            "username": user.username,
            "email": user.email,
            "first_name": user.first_name,
            "last_name": user.last_name,
            "full_name": user.get_full_name(),
            "is_staff": user.is_staff,
            "is_active": user.is_active,
            "roles": list(user.userrole_set.values_list("role__name", flat=True)),
            "permissions": [],
        }

        # Fetch plants (superadmin sees all, regular user sees their plant only)
        if user.is_superadmin or user.is_staff:
            plants = Plant.objects.filter(is_active=True).values("id", "code", "name")
        elif user.plant:
            plants = Plant.objects.filter(id=user.plant_id, is_active=True).values("id", "code", "name")
        else:
            plants = Plant.objects.filter(is_active=True).values("id", "code", "name")

        return Response({
            "access": str(access),
            "refresh": str(refresh),
            "user": user_data,
            "plants": list(plants),
        }, status=status.HTTP_200_OK)


@method_decorator(csrf_exempt, name="dispatch")
class LogoutView(APIView):
    """
    POST /api/v1/auth/logout/
    Body: { refresh }
    Blacklists the refresh token.
    """
    permission_classes = [IsAuthenticated]
    authentication_classes = []  # JWT only, no session auth

    def post(self, request):
        refresh_token = request.data.get("refresh")
        if not refresh_token:
            return Response({"detail": "Refresh token required."}, status=status.HTTP_400_BAD_REQUEST)
        try:
            token = RefreshToken(refresh_token)
            token.blacklist()
        except TokenError:
            pass  # Already blacklisted or invalid — still return 200
        return Response({"detail": "Logged out successfully."}, status=status.HTTP_200_OK)


class MeView(APIView):
    """
    GET /api/v1/auth/me/
    Returns current user profile.
    """
    permission_classes = [IsAuthenticated]

    def get(self, request):
        user = request.user
        return Response({
            "id": user.id,
            "username": user.username,
            "email": user.email,
            "first_name": user.first_name,
            "last_name": user.last_name,
            "full_name": user.get_full_name(),
            "is_staff": user.is_staff,
            "is_active": user.is_active,
            "plant": {
                "id": user.plant.id,
                "code": user.plant.code,
                "name": user.plant.name,
            } if user.plant else None,
            "roles": list(user.userrole_set.values_list("role__name", flat=True)),
        })
