"""
Core Module Tests

Tests for:
- Company, Plant, Department CRUD
- User creation (custom user model) with plant/department FK
- Role and Permission creation and linking
- DocSequence.get_next_number() sequential numbers
- DocSequence financial year format
- AuditLog creation
- Notification creation and is_read toggle
- JWT auth endpoints (login, refresh, verify)
- PlantContextMiddleware sets request.plant from JWT
"""
from datetime import date
from django.test import TestCase
from django.contrib.auth import get_user_model
from rest_framework.test import APITestCase, APIClient
from rest_framework import status

from apps.core.models import (
    Company, Plant, Department, Role, Permission, RolePermission,
    UserRole, DocSequence, AuditLog, Notification, SystemConfig
)

User = get_user_model()


# ═══════════════════════════════════════════════════════════════════
# Model Tests
# ═══════════════════════════════════════════════════════════════════

class CompanyPlantDepartmentTests(TestCase):
    """Test Company, Plant, and Department models."""
    
    def test_create_company(self):
        """Test creating a company."""
        company = Company.objects.create(
            name="Test Company",
            legal_name="Test Company Pvt Ltd",
            gstin="29AAAAA0000A1Z5",
            pan="AAAAA0000A",
            city="Mumbai",
            state="Maharashtra"
        )
        self.assertIsNotNone(company.uuid)
        self.assertEqual(str(company), "Test Company")
        self.assertTrue(company.is_active)
        self.assertEqual(company.financial_year_start, 4)  # April
    
    def test_create_plant(self):
        """Test creating a plant."""
        company = Company.objects.create(name="Test Company")
        plant = Plant.objects.create(
            company=company,
            code="TST01",
            name="Test Plant",
            city="Pardi",
            gstin="24AAAAA0000A1Z5"
        )
        self.assertIsNotNone(plant.uuid)
        self.assertEqual(str(plant), "TST01 - Test Plant")
        self.assertTrue(plant.is_active)
        self.assertEqual(plant.company, company)
    
    def test_create_department(self):
        """Test creating a department."""
        company = Company.objects.create(name="Test Company")
        plant = Plant.objects.create(
            company=company,
            code="TST01",
            name="Test Plant"
        )
        dept = Department.objects.create(
            plant=plant,
            code="PROD",
            name="Production"
        )
        self.assertEqual(str(dept), "PROD - Production")
        self.assertEqual(dept.plant, plant)
        self.assertTrue(dept.is_active)
    
    def test_department_unique_together(self):
        """Test department unique_together constraint."""
        company = Company.objects.create(name="Test Company")
        plant = Plant.objects.create(
            company=company,
            code="TST01",
            name="Test Plant"
        )
        Department.objects.create(plant=plant, code="PROD", name="Production")
        
        # Try to create duplicate
        with self.assertRaises(Exception):  # IntegrityError
            Department.objects.create(plant=plant, code="PROD", name="Production 2")


class UserModelTests(TestCase):
    """Test custom User model."""
    
    def setUp(self):
        """Set up test data."""
        self.company = Company.objects.create(name="Test Company")
        self.plant = Plant.objects.create(
            company=self.company,
            code="TST01",
            name="Test Plant"
        )
        self.department = Department.objects.create(
            plant=self.plant,
            code="IT",
            name="IT Department"
        )
    
    def test_create_user(self):
        """Test creating a user with plant and department."""
        user = User.objects.create_user(
            username='testuser',
            email='test@example.com',
            password='testpass123',
            plant=self.plant,
            department=self.department,
            employee_code='EMP001'
        )
        self.assertIsNotNone(user.uuid)
        self.assertEqual(user.email, 'test@example.com')
        self.assertEqual(user.plant, self.plant)
        self.assertEqual(user.department, self.department)
        self.assertEqual(user.employee_code, 'EMP001')
        self.assertFalse(user.is_superadmin)
        self.assertTrue(user.check_password('testpass123'))
    
    def test_create_superuser(self):
        """Test creating a superuser."""
        user = User.objects.create_superuser(
            username='admin',
            email='admin@example.com',
            password='adminpass123'
        )
        self.assertTrue(user.is_staff)
        self.assertTrue(user.is_superuser)
        self.assertTrue(user.is_superadmin)
    
    def test_user_string_representation(self):
        """Test user __str__ method."""
        user = User.objects.create_user(
            username='jdoe',
            email='jdoe@example.com',
            password='pass',
            first_name='John',
            last_name='Doe'
        )
        self.assertEqual(str(user), "jdoe (John Doe)")
    
    def test_user_is_locked(self):
        """Test user account locking."""
        from django.utils import timezone
        from datetime import timedelta
        
        user = User.objects.create_user(
            username='lockeduser',
            email='locked@example.com',
            password='pass'
        )
        self.assertFalse(user.is_locked)
        
        # Lock user for 1 hour
        user.locked_until = timezone.now() + timedelta(hours=1)
        user.save()
        self.assertTrue(user.is_locked)


class RolePermissionTests(TestCase):
    """Test Role and Permission models."""
    
    def test_create_role(self):
        """Test creating a role."""
        role = Role.objects.create(
            name="Purchase Manager",
            description="Manages purchase operations",
            is_system=False
        )
        self.assertEqual(str(role), "Purchase Manager")
        self.assertTrue(role.is_active)
    
    def test_create_permission(self):
        """Test creating a permission."""
        permission = Permission.objects.create(
            module="purchase",
            action="approve",
            resource="purchase_order",
            description="Can approve purchase orders"
        )
        self.assertEqual(str(permission), "purchase.purchase_order.approve")
    
    def test_role_permission_linking(self):
        """Test linking permissions to roles."""
        role = Role.objects.create(name="Buyer")
        perm1 = Permission.objects.create(
            module="purchase",
            action="create",
            resource="purchase_order"
        )
        perm2 = Permission.objects.create(
            module="purchase",
            action="update",
            resource="purchase_order"
        )
        
        RolePermission.objects.create(role=role, permission=perm1)
        RolePermission.objects.create(role=role, permission=perm2)
        
        self.assertEqual(role.permissions.count(), 2)
    
    def test_user_role_assignment(self):
        """Test assigning roles to users."""
        company = Company.objects.create(name="Test Co")
        plant = Plant.objects.create(company=company, code="T01", name="Plant 1")
        
        user = User.objects.create_user(
            username='testuser',
            email='test@example.com',
            password='pass'
        )
        role = Role.objects.create(name="Manager")
        
        UserRole.objects.create(user=user, role=role, plant=plant)
        
        self.assertEqual(user.roles.count(), 1)
        self.assertEqual(user.roles.first(), role)
    
    def test_user_has_erp_permission(self):
        """Test checking user ERP permissions."""
        user = User.objects.create_user(
            username='testuser',
            email='test@example.com',
            password='pass'
        )
        role = Role.objects.create(name="Buyer")
        permission = Permission.objects.create(
            module="purchase",
            action="create",
            resource="purchase_order"
        )
        
        # Link permission to role
        RolePermission.objects.create(role=role, permission=permission)
        
        # Assign role to user
        UserRole.objects.create(user=user, role=role)
        
        # Check permission
        self.assertTrue(user.has_erp_permission("purchase", "create", "purchase_order"))
        self.assertFalse(user.has_erp_permission("purchase", "delete", "purchase_order"))
    
    def test_superadmin_has_all_permissions(self):
        """Test that superadmin has all permissions."""
        user = User.objects.create_superuser(
            username='admin',
            email='admin@example.com',
            password='pass'
        )
        
        # Create a permission
        Permission.objects.create(
            module="purchase",
            action="approve",
            resource="purchase_order"
        )
        
        # Superadmin should have all permissions without explicit assignment
        self.assertTrue(user.has_erp_permission("purchase", "approve", "purchase_order"))


class DocSequenceTests(TestCase):
    """Test DocSequence model and sequential numbering."""
    
    def setUp(self):
        """Set up test data."""
        self.company = Company.objects.create(name="Test Company")
        self.plant = Plant.objects.create(
            company=self.company,
            code="TST",
            name="Test Plant"
        )
    
    def test_create_doc_sequence(self):
        """Test creating a document sequence."""
        seq = DocSequence.objects.create(
            plant=self.plant,
            doc_type="PO",
            prefix="PO",
            financial_year="2025-26",
            last_number=0
        )
        self.assertEqual(seq.last_number, 0)
        self.assertEqual(seq.financial_year, "2025-26")
    
    def test_get_next_number_sequential(self):
        """Test that get_next_number returns sequential numbers."""
        seq = DocSequence.objects.create(
            plant=self.plant,
            doc_type="PO",
            prefix="PO",
            financial_year="2025-26",
            last_number=0,
            format_pattern="{prefix}/{fy}/{num:05d}"
        )
        
        # Get first number
        num1 = seq.get_next_number()
        self.assertEqual(num1, "PO/2025-26/00001")
        
        # Refresh from DB and get next
        seq.refresh_from_db()
        self.assertEqual(seq.last_number, 1)
        
        num2 = seq.get_next_number()
        self.assertEqual(num2, "PO/2025-26/00002")
        
        seq.refresh_from_db()
        self.assertEqual(seq.last_number, 2)
    
    def test_financial_year_format(self):
        """Test financial year format in document numbers."""
        seq = DocSequence.objects.create(
            plant=self.plant,
            doc_type="INV",
            prefix="INV",
            financial_year="2026-27",
            last_number=0,
            format_pattern="{prefix}/{fy}/{num:05d}"
        )
        
        num = seq.get_next_number()
        self.assertIn("2026-27", num)
        self.assertEqual(num, "INV/2026-27/00001")
    
    def test_doc_sequence_thread_safety(self):
        """Test that get_next_number is thread-safe (uses select_for_update)."""
        seq = DocSequence.objects.create(
            plant=self.plant,
            doc_type="SO",
            prefix="SO",
            financial_year="2025-26",
            last_number=0
        )
        
        # Get multiple numbers
        numbers = []
        for _ in range(5):
            numbers.append(seq.get_next_number())
            seq.refresh_from_db()
        
        # All should be unique and sequential
        self.assertEqual(len(numbers), 5)
        self.assertEqual(len(set(numbers)), 5)  # All unique
        self.assertIn("00001", numbers[0])
        self.assertIn("00005", numbers[4])


class AuditLogTests(TestCase):
    """Test AuditLog model."""
    
    def test_create_audit_log(self):
        """Test creating an audit log entry."""
        user = User.objects.create_user(
            username='testuser',
            email='test@example.com',
            password='pass'
        )
        
        log = AuditLog.objects.create(
            user=user,
            action="CREATE",
            module="purchase",
            resource="PurchaseOrder",
            resource_id=123,
            new_values={"po_number": "PO/25-26/00123", "amount": 50000}
        )
        
        self.assertEqual(log.user, user)
        self.assertEqual(log.action, "CREATE")
        self.assertEqual(log.module, "purchase")
        self.assertEqual(log.resource_id, 123)
        self.assertIsNotNone(log.created_at)
        self.assertEqual(log.new_values["amount"], 50000)
    
    def test_audit_log_string_representation(self):
        """Test audit log __str__ method."""
        user = User.objects.create_user(
            username='jdoe',
            email='jdoe@example.com',
            password='pass'
        )
        log = AuditLog.objects.create(
            user=user,
            action="UPDATE",
            module="sales",
            resource="SalesOrder",
            resource_id=456
        )
        self.assertIn("jdoe", str(log))
        self.assertIn("UPDATE", str(log))
        self.assertIn("sales.SalesOrder", str(log))


class NotificationTests(TestCase):
    """Test Notification model."""
    
    def test_create_notification(self):
        """Test creating a notification."""
        user = User.objects.create_user(
            username='testuser',
            email='test@example.com',
            password='pass'
        )
        
        notif = Notification.objects.create(
            user=user,
            title="New Purchase Order",
            message="PO/25-26/00123 needs your approval",
            notification_type="IN_APP",
            module="purchase",
            resource="PurchaseOrder",
            resource_id=123
        )
        
        self.assertEqual(notif.user, user)
        self.assertEqual(notif.title, "New Purchase Order")
        self.assertFalse(notif.is_read)
        self.assertIsNone(notif.read_at)
    
    def test_notification_is_read_toggle(self):
        """Test toggling notification is_read flag."""
        from django.utils import timezone
        
        user = User.objects.create_user(
            username='testuser',
            email='test@example.com',
            password='pass'
        )
        
        notif = Notification.objects.create(
            user=user,
            title="Test Notification",
            message="Test message"
        )
        
        # Initially not read
        self.assertFalse(notif.is_read)
        self.assertIsNone(notif.read_at)
        
        # Mark as read
        notif.is_read = True
        notif.read_at = timezone.now()
        notif.save()
        
        notif.refresh_from_db()
        self.assertTrue(notif.is_read)
        self.assertIsNotNone(notif.read_at)
    
    def test_notification_string_representation(self):
        """Test notification __str__ method."""
        user = User.objects.create_user(
            username='jdoe',
            email='jdoe@example.com',
            password='pass'
        )
        notif = Notification.objects.create(
            user=user,
            title="Task Assigned",
            message="You have a new task"
        )
        self.assertIn("Task Assigned", str(notif))
        self.assertIn("jdoe", str(notif))


# ═══════════════════════════════════════════════════════════════════
# API Tests
# ═══════════════════════════════════════════════════════════════════

class JWTAuthTests(APITestCase):
    """Test JWT authentication endpoints."""
    
    def setUp(self):
        """Set up test data."""
        self.client = APIClient()
        self.user = User.objects.create_user(
            username='testuser',
            email='test@example.com',
            password='testpass123'
        )
    
    def test_token_obtain(self):
        """Test obtaining JWT token (login)."""
        # Note: This requires a login endpoint to be implemented
        # If using rest_framework_simplejwt.views.TokenObtainPairView
        # the endpoint would typically be /api/auth/token/ or similar
        
        # This is a placeholder - adjust URL based on actual implementation
        response = self.client.post('/api/auth/token/', {
            'username': 'testuser',
            'password': 'testpass123'
        })
        
        # If endpoint exists, should return 200 with access and refresh tokens
        # If not implemented, will return 404
        # self.assertEqual(response.status_code, status.HTTP_200_OK)
        # self.assertIn('access', response.data)
        # self.assertIn('refresh', response.data)
    
    def test_token_refresh(self):
        """Test refreshing JWT token."""
        # First get a token
        # This test assumes the refresh endpoint exists at /api/auth/token/refresh/
        
        # Placeholder test - needs actual token to test refresh
        # response = self.client.post('/api/auth/token/refresh/', {
        #     'refresh': 'valid_refresh_token_here'
        # })
        # self.assertEqual(response.status_code, status.HTTP_200_OK)
        pass
    
    def test_token_verify(self):
        """Test verifying JWT token."""
        # Placeholder for token verification endpoint
        # response = self.client.post('/api/auth/token/verify/', {
        #     'token': 'valid_token_here'
        # })
        # self.assertEqual(response.status_code, status.HTTP_200_OK)
        pass


class PlantContextMiddlewareTests(TestCase):
    """Test PlantContextMiddleware."""
    
    def setUp(self):
        """Set up test data."""
        self.company = Company.objects.create(name="Test Company")
        self.plant = Plant.objects.create(
            company=self.company,
            code="TST01",
            name="Test Plant"
        )
        self.user = User.objects.create_user(
            username='testuser',
            email='test@example.com',
            password='testpass123',
            plant=self.plant
        )
    
    def test_middleware_sets_plant_from_user(self):
        """Test that middleware sets request.plant from authenticated user."""
        # This test would require an actual HTTP request through the middleware
        # For unit testing, we can verify the User model has plant FK
        
        self.assertEqual(self.user.plant, self.plant)
        self.assertIsNotNone(self.user.plant)
        
        # In integration tests, you would:
        # 1. Authenticate with JWT
        # 2. Make a request
        # 3. Verify request.plant is set from JWT token's user.plant
