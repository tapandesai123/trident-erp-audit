"""
SMSService Tests — Task 17

All HTTP calls are mocked via unittest.mock.patch('requests.post') so
these tests run without network access and without real API credentials.

Test coverage:
  - MSG91 provider: correct URL, auth header, payload shape
  - Twilio provider: correct URL, BasicAuth, form body
  - send_otp(): message format + template_id pass-through
  - Success/failure detection from HTTP status codes
  - AuditLog entry is written on each send attempt
  - Missing phone number handled gracefully
  - Connection error handled gracefully (no exception to caller)
"""
from unittest.mock import patch, MagicMock, call
from django.test import TestCase, override_settings


# ─── Shared SMS_CONFIG overrides ──────────────────────────────────

MSG91_CONFIG = {
    "SMS_PROVIDER":    "MSG91",
    "MSG91_AUTH_KEY":  "test-authkey-msg91",
    "MSG91_SENDER_ID": "TRDNTP",
    "OTP_TEMPLATE_ID": "otp-tmpl-001",
    "TWILIO_ACCOUNT_SID":  "",
    "TWILIO_AUTH_TOKEN":   "",
    "TWILIO_FROM_NUMBER":  "",
}

TWILIO_CONFIG = {
    "SMS_PROVIDER":       "TWILIO",
    "TWILIO_ACCOUNT_SID": "ACtest123",
    "TWILIO_AUTH_TOKEN":  "authtoken456",
    "TWILIO_FROM_NUMBER": "+12025550101",
    "MSG91_AUTH_KEY":     "",
    "MSG91_SENDER_ID":    "TRDNTP",
    "OTP_TEMPLATE_ID":    "",
}


def _mock_response(status_code=200, json_body=None):
    """Build a mock requests.Response."""
    resp = MagicMock()
    resp.status_code = status_code
    resp.headers = {"content-type": "application/json; charset=utf-8"}
    resp.json.return_value = json_body or {"type": "success", "message": "OK"}
    resp.text = str(json_body)
    return resp


# ═══════════════════════════════════════════════════════════════════
# MSG91 TESTS
# ═══════════════════════════════════════════════════════════════════

class TestSMSServiceMSG91(TestCase):
    """Tests for SMSService when SMS_PROVIDER = MSG91."""

    @override_settings(SMS_CONFIG=MSG91_CONFIG)
    @patch("requests.post")
    def test_msg91_uses_correct_url(self, mock_post):
        """MSG91 must POST to https://api.msg91.com/api/v5/flow/."""
        mock_post.return_value = _mock_response(200)
        from apps.core.sms import SMSService
        SMSService.send("9876543210", "Hello")
        args, kwargs = mock_post.call_args
        self.assertEqual(args[0], "https://api.msg91.com/api/v5/flow/")

    @override_settings(SMS_CONFIG=MSG91_CONFIG)
    @patch("requests.post")
    def test_msg91_sends_authkey_header(self, mock_post):
        """MSG91 must send authkey in the request headers."""
        mock_post.return_value = _mock_response(200)
        from apps.core.sms import SMSService
        SMSService.send("9876543210", "Hello")
        _, kwargs = mock_post.call_args
        headers = kwargs["headers"]
        self.assertEqual(headers["authkey"], "test-authkey-msg91")

    @override_settings(SMS_CONFIG=MSG91_CONFIG)
    @patch("requests.post")
    def test_msg91_sends_correct_sender(self, mock_post):
        """MSG91 payload must include sender = MSG91_SENDER_ID."""
        mock_post.return_value = _mock_response(200)
        from apps.core.sms import SMSService
        SMSService.send("9876543210", "Hello")
        _, kwargs = mock_post.call_args
        payload = kwargs["json"]
        self.assertEqual(payload["sender"], "TRDNTP")

    @override_settings(SMS_CONFIG=MSG91_CONFIG)
    @patch("requests.post")
    def test_msg91_prefixes_country_code(self, mock_post):
        """MSG91 must send 91-prefixed mobile number."""
        mock_post.return_value = _mock_response(200)
        from apps.core.sms import SMSService
        SMSService.send("9876543210", "Hello")
        _, kwargs = mock_post.call_args
        payload = kwargs["json"]
        self.assertEqual(payload["mobiles"], "919876543210")

    @override_settings(SMS_CONFIG=MSG91_CONFIG)
    @patch("requests.post")
    def test_msg91_does_not_double_prefix(self, mock_post):
        """If mobile already starts with 91, don't add another prefix."""
        mock_post.return_value = _mock_response(200)
        from apps.core.sms import SMSService
        SMSService.send("919876543210", "Hello")
        _, kwargs = mock_post.call_args
        payload = kwargs["json"]
        self.assertEqual(payload["mobiles"], "919876543210")

    @override_settings(SMS_CONFIG=MSG91_CONFIG)
    @patch("requests.post")
    def test_msg91_includes_message_as_var1(self, mock_post):
        """MSG91 payload must include VAR1 = message text."""
        mock_post.return_value = _mock_response(200)
        from apps.core.sms import SMSService
        SMSService.send("9876543210", "Test message content")
        _, kwargs = mock_post.call_args
        payload = kwargs["json"]
        self.assertEqual(payload["VAR1"], "Test message content")

    @override_settings(SMS_CONFIG=MSG91_CONFIG)
    @patch("requests.post")
    def test_msg91_includes_template_id_when_provided(self, mock_post):
        """MSG91 payload must include template_id when passed."""
        mock_post.return_value = _mock_response(200)
        from apps.core.sms import SMSService
        SMSService.send("9876543210", "Hello", template_id="tmpl-abc123")
        _, kwargs = mock_post.call_args
        payload = kwargs["json"]
        self.assertEqual(payload["template_id"], "tmpl-abc123")

    @override_settings(SMS_CONFIG=MSG91_CONFIG)
    @patch("requests.post")
    def test_msg91_200_means_success(self, mock_post):
        """HTTP 200 → result['success'] == True."""
        mock_post.return_value = _mock_response(200, {"type": "success"})
        from apps.core.sms import SMSService
        result = SMSService.send("9876543210", "Hello")
        self.assertTrue(result["success"])

    @override_settings(SMS_CONFIG=MSG91_CONFIG)
    @patch("requests.post")
    def test_msg91_4xx_means_failure(self, mock_post):
        """HTTP 4xx → result['success'] == False."""
        mock_post.return_value = _mock_response(401, {"type": "error", "message": "Unauthorized"})
        from apps.core.sms import SMSService
        result = SMSService.send("9876543210", "Hello")
        self.assertFalse(result["success"])

    @override_settings(SMS_CONFIG=MSG91_CONFIG)
    @patch("requests.post")
    def test_msg91_returns_provider_name(self, mock_post):
        """result['provider'] must be 'MSG91'."""
        mock_post.return_value = _mock_response(200)
        from apps.core.sms import SMSService
        result = SMSService.send("9876543210", "Hello")
        self.assertEqual(result["provider"], "MSG91")


# ═══════════════════════════════════════════════════════════════════
# TWILIO TESTS
# ═══════════════════════════════════════════════════════════════════

class TestSMSServiceTwilio(TestCase):
    """Tests for SMSService when SMS_PROVIDER = TWILIO."""

    @override_settings(SMS_CONFIG=TWILIO_CONFIG)
    @patch("requests.post")
    def test_twilio_uses_correct_url(self, mock_post):
        """Twilio must POST to the Messages.json endpoint with Account SID in path."""
        mock_post.return_value = _mock_response(201, {"sid": "SM123", "status": "queued"})
        from apps.core.sms import SMSService
        SMSService.send("9876543210", "Hello")
        args, _ = mock_post.call_args
        self.assertIn("ACtest123", args[0])
        self.assertIn("Messages.json", args[0])
        self.assertTrue(args[0].startswith("https://api.twilio.com"))

    @override_settings(SMS_CONFIG=TWILIO_CONFIG)
    @patch("requests.post")
    def test_twilio_uses_basic_auth(self, mock_post):
        """Twilio must use BasicAuth with account_sid:auth_token."""
        mock_post.return_value = _mock_response(201, {"sid": "SM123", "status": "queued"})
        from apps.core.sms import SMSService
        SMSService.send("9876543210", "Hello")
        _, kwargs = mock_post.call_args
        self.assertEqual(kwargs["auth"], ("ACtest123", "authtoken456"))

    @override_settings(SMS_CONFIG=TWILIO_CONFIG)
    @patch("requests.post")
    def test_twilio_sends_form_data_not_json(self, mock_post):
        """Twilio expects form-encoded data (data=), not json=."""
        mock_post.return_value = _mock_response(201, {"sid": "SM123", "status": "queued"})
        from apps.core.sms import SMSService
        SMSService.send("9876543210", "Hello")
        _, kwargs = mock_post.call_args
        # Must use 'data' key, not 'json'
        self.assertIn("data", kwargs)
        self.assertNotIn("json", kwargs)

    @override_settings(SMS_CONFIG=TWILIO_CONFIG)
    @patch("requests.post")
    def test_twilio_from_number_correct(self, mock_post):
        """Twilio body must include From = TWILIO_FROM_NUMBER."""
        mock_post.return_value = _mock_response(201, {"sid": "SM123", "status": "queued"})
        from apps.core.sms import SMSService
        SMSService.send("9876543210", "Hello")
        _, kwargs = mock_post.call_args
        self.assertEqual(kwargs["data"]["From"], "+12025550101")

    @override_settings(SMS_CONFIG=TWILIO_CONFIG)
    @patch("requests.post")
    def test_twilio_formats_to_number(self, mock_post):
        """Twilio To must be E.164 format: +91xxxxxxxxxx."""
        mock_post.return_value = _mock_response(201, {"sid": "SM123", "status": "queued"})
        from apps.core.sms import SMSService
        SMSService.send("9876543210", "Hello")
        _, kwargs = mock_post.call_args
        self.assertEqual(kwargs["data"]["To"], "+919876543210")

    @override_settings(SMS_CONFIG=TWILIO_CONFIG)
    @patch("requests.post")
    def test_twilio_body_contains_message(self, mock_post):
        """Twilio body must include the message text."""
        mock_post.return_value = _mock_response(201, {"sid": "SM123", "status": "queued"})
        from apps.core.sms import SMSService
        SMSService.send("9876543210", "Pay your invoice now")
        _, kwargs = mock_post.call_args
        self.assertEqual(kwargs["data"]["Body"], "Pay your invoice now")

    @override_settings(SMS_CONFIG=TWILIO_CONFIG)
    @patch("requests.post")
    def test_twilio_201_means_success(self, mock_post):
        """HTTP 201 Created → success."""
        mock_post.return_value = _mock_response(201, {"sid": "SM123", "status": "queued"})
        from apps.core.sms import SMSService
        result = SMSService.send("9876543210", "Hello")
        self.assertTrue(result["success"])

    @override_settings(SMS_CONFIG=TWILIO_CONFIG)
    @patch("requests.post")
    def test_twilio_returns_provider_name(self, mock_post):
        """result['provider'] must be 'TWILIO'."""
        mock_post.return_value = _mock_response(201, {"sid": "SM123", "status": "queued"})
        from apps.core.sms import SMSService
        result = SMSService.send("9876543210", "Hello")
        self.assertEqual(result["provider"], "TWILIO")


# ═══════════════════════════════════════════════════════════════════
# send_otp() TESTS
# ═══════════════════════════════════════════════════════════════════

class TestSMSServiceSendOTP(TestCase):
    """Tests for SMSService.send_otp()."""

    @override_settings(SMS_CONFIG=MSG91_CONFIG)
    @patch("requests.post")
    def test_send_otp_message_contains_otp(self, mock_post):
        """OTP message must embed the OTP code."""
        mock_post.return_value = _mock_response(200)
        from apps.core.sms import SMSService
        SMSService.send_otp("9876543210", "482930")
        _, kwargs = mock_post.call_args
        message = kwargs["json"]["VAR1"]
        self.assertIn("482930", message)

    @override_settings(SMS_CONFIG=MSG91_CONFIG)
    @patch("requests.post")
    def test_send_otp_message_mentions_10_minutes(self, mock_post):
        """OTP message must state 10-minute validity."""
        mock_post.return_value = _mock_response(200)
        from apps.core.sms import SMSService
        SMSService.send_otp("9876543210", "123456")
        _, kwargs = mock_post.call_args
        message = kwargs["json"]["VAR1"]
        self.assertIn("10 minutes", message)

    @override_settings(SMS_CONFIG=MSG91_CONFIG)
    @patch("requests.post")
    def test_send_otp_uses_otp_template_id(self, mock_post):
        """send_otp() must pass OTP_TEMPLATE_ID from SMS_CONFIG."""
        mock_post.return_value = _mock_response(200)
        from apps.core.sms import SMSService
        SMSService.send_otp("9876543210", "654321")
        _, kwargs = mock_post.call_args
        payload = kwargs["json"]
        self.assertEqual(payload.get("template_id"), "otp-tmpl-001")

    @override_settings(SMS_CONFIG=MSG91_CONFIG)
    @patch("requests.post")
    def test_send_otp_returns_success_result(self, mock_post):
        """send_otp() must return the standard success dict."""
        mock_post.return_value = _mock_response(200)
        from apps.core.sms import SMSService
        result = SMSService.send_otp("9876543210", "000001")
        self.assertIn("success", result)
        self.assertIn("provider", result)
        self.assertIn("provider_response", result)

    @override_settings(SMS_CONFIG=MSG91_CONFIG)
    @patch("requests.post")
    def test_send_otp_calls_send_once(self, mock_post):
        """send_otp() must make exactly one HTTP POST call."""
        mock_post.return_value = _mock_response(200)
        from apps.core.sms import SMSService
        SMSService.send_otp("9876543210", "111111")
        self.assertEqual(mock_post.call_count, 1)


# ═══════════════════════════════════════════════════════════════════
# ERROR HANDLING TESTS
# ═══════════════════════════════════════════════════════════════════

class TestSMSServiceErrorHandling(TestCase):
    """Tests for graceful error handling in SMSService."""

    @override_settings(SMS_CONFIG=MSG91_CONFIG)
    @patch("requests.post", side_effect=Exception("Timeout"))
    def test_connection_error_returns_failure(self, mock_post):
        """Network exceptions must be caught; result['success'] == False."""
        from apps.core.sms import SMSService
        result = SMSService.send("9876543210", "Hello")
        self.assertFalse(result["success"])

    @override_settings(SMS_CONFIG=MSG91_CONFIG)
    @patch("requests.post", side_effect=Exception("Timeout"))
    def test_connection_error_does_not_raise(self, mock_post):
        """SMSService.send() must never propagate exceptions to callers."""
        from apps.core.sms import SMSService
        try:
            SMSService.send("9876543210", "Hello")
        except Exception as exc:  # pragma: no cover
            self.fail(f"SMSService.send() raised unexpectedly: {exc}")

    @override_settings(SMS_CONFIG=MSG91_CONFIG)
    @patch("requests.post")
    def test_send_always_returns_dict(self, mock_post):
        """Return value must always be a dict with 'success' key."""
        mock_post.return_value = _mock_response(200)
        from apps.core.sms import SMSService
        result = SMSService.send("9876543210", "Hello")
        self.assertIsInstance(result, dict)
        self.assertIn("success", result)
        self.assertIn("provider", result)
        self.assertIn("provider_response", result)


# ═══════════════════════════════════════════════════════════════════
# AUDIT LOG TESTS
# ═══════════════════════════════════════════════════════════════════

class TestSMSAuditLog(TestCase):
    """Tests that SMS sends are logged to AuditLog."""

    @override_settings(SMS_CONFIG=MSG91_CONFIG)
    @patch("requests.post")
    def test_successful_send_creates_audit_log(self, mock_post):
        """A successful SMS send must create an AuditLog entry."""
        mock_post.return_value = _mock_response(200)
        from apps.core.sms import SMSService
        from apps.core.models import AuditLog

        before_count = AuditLog.objects.filter(action="SMS_SENT").count()
        SMSService.send("9876543210", "Test audit")
        after_count = AuditLog.objects.filter(action="SMS_SENT").count()
        self.assertEqual(after_count, before_count + 1)

    @override_settings(SMS_CONFIG=MSG91_CONFIG)
    @patch("requests.post")
    def test_failed_send_also_creates_audit_log(self, mock_post):
        """Even a failed SMS send must create an AuditLog entry."""
        mock_post.return_value = _mock_response(500, {"error": "Server error"})
        from apps.core.sms import SMSService
        from apps.core.models import AuditLog

        before_count = AuditLog.objects.filter(action="SMS_SENT").count()
        SMSService.send("9876543210", "Test audit")
        after_count = AuditLog.objects.filter(action="SMS_SENT").count()
        self.assertEqual(after_count, before_count + 1)

    @override_settings(SMS_CONFIG=MSG91_CONFIG)
    @patch("requests.post")
    def test_audit_log_masks_mobile_number(self, mock_post):
        """AuditLog notes must NOT contain the full mobile number."""
        mock_post.return_value = _mock_response(200)
        from apps.core.sms import SMSService
        from apps.core.models import AuditLog

        SMSService.send("9876543210", "Test masking")
        log = AuditLog.objects.filter(action="SMS_SENT").last()
        self.assertIsNotNone(log)
        # Full mobile should not appear; only first 4 digits + mask
        self.assertNotIn("9876543210", log.notes)

    @override_settings(SMS_CONFIG=MSG91_CONFIG)
    @patch("requests.post")
    def test_audit_log_records_provider(self, mock_post):
        """AuditLog entry must record which provider was used."""
        mock_post.return_value = _mock_response(200)
        from apps.core.sms import SMSService
        from apps.core.models import AuditLog

        SMSService.send("9876543210", "Provider check")
        log = AuditLog.objects.filter(action="SMS_SENT").last()
        self.assertIsNotNone(log)
        self.assertIn("MSG91", log.notes)
