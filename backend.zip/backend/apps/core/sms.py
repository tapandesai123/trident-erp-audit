"""
SMS Gateway Service — Task 17

Provides a unified SMSService that dispatches via MSG91 or Twilio
based on the SMS_CONFIG['SMS_PROVIDER'] setting.

Usage:
    from apps.core.sms import SMSService
    SMSService.send('9876543210', 'Hello from Trident ERP')
    SMSService.send_otp('9876543210', '482930')
"""
import logging
import requests
from django.conf import settings

logger = logging.getLogger(__name__)

# Maximum time to wait for provider HTTP response
_REQUEST_TIMEOUT = 10  # seconds


class SMSService:
    """
    Unified SMS gateway service.

    Provider is selected at runtime from SMS_CONFIG['SMS_PROVIDER']:
      'MSG91'  → MSG91 Flow API v5
      'TWILIO' → Twilio REST Messages API

    All send attempts are logged to AuditLog regardless of outcome.
    Failures are logged as errors but never raise to callers — SMS is
    best-effort; never block a business transaction over it.
    """

    @staticmethod
    def _cfg() -> dict:
        return getattr(settings, "SMS_CONFIG", {})

    # ── MSG91 ──────────────────────────────────────────────────────

    @staticmethod
    def _send_msg91(mobile: str, message: str, template_id: str) -> dict:
        cfg = SMSService._cfg()
        auth_key  = cfg.get("MSG91_AUTH_KEY", "")
        sender_id = cfg.get("MSG91_SENDER_ID", "TRDNTP")

        # MSG91 expects country code prefix; normalise Indian numbers
        normalized = f"91{mobile}" if not mobile.startswith("91") else mobile

        url  = "https://api.msg91.com/api/v5/flow/"
        headers = {
            "authkey":      auth_key,
            "content-type": "application/json",
            "accept":       "application/json",
        }
        payload: dict = {
            "sender":   sender_id,
            "mobiles":  normalized,
            "VAR1":     message,
        }
        if template_id:
            payload["template_id"] = template_id

        response = requests.post(url, json=payload, headers=headers, timeout=_REQUEST_TIMEOUT)
        return {
            "status_code": response.status_code,
            "body":        response.json() if response.headers.get("content-type", "").startswith("application/json") else response.text,
        }

    # ── Twilio ─────────────────────────────────────────────────────

    @staticmethod
    def _send_twilio(mobile: str, message: str) -> dict:
        cfg = SMSService._cfg()
        account_sid  = cfg.get("TWILIO_ACCOUNT_SID", "")
        auth_token   = cfg.get("TWILIO_AUTH_TOKEN", "")
        from_number  = cfg.get("TWILIO_FROM_NUMBER", "")

        # Twilio E.164 format
        to_number = f"+91{mobile}" if not mobile.startswith("+") else mobile

        url = f"https://api.twilio.com/2010-04-01/Accounts/{account_sid}/Messages.json"
        response = requests.post(
            url,
            auth=(account_sid, auth_token),
            data={
                "From": from_number,
                "To":   to_number,
                "Body": message,
            },
            timeout=_REQUEST_TIMEOUT,
        )
        return {
            "status_code": response.status_code,
            "body":        response.json() if response.headers.get("content-type", "").startswith("application/json") else response.text,
        }

    # ── Public interface ───────────────────────────────────────────

    @staticmethod
    def send(mobile: str, message: str, template_id: str = "") -> dict:
        """
        Send an SMS via the configured provider.

        Args:
            mobile:      10-digit mobile number (without country code).
            message:     Plain-text message body.
            template_id: DLT / provider-specific approved template ID.
                         Optional for Twilio, required for MSG91 regulated traffic.

        Returns:
            {
              'success': bool,
              'provider': str,
              'provider_response': dict,
            }
        """
        cfg      = SMSService._cfg()
        provider = cfg.get("SMS_PROVIDER", "MSG91").upper()

        provider_response: dict = {}
        success = False
        error_msg = ""

        try:
            if provider == "TWILIO":
                provider_response = SMSService._send_twilio(mobile, message)
            else:
                provider_response = SMSService._send_msg91(mobile, message, template_id)

            # Both providers return 2xx on success
            success = 200 <= provider_response.get("status_code", 0) < 300

        except requests.exceptions.Timeout:
            error_msg = "Request timed out"
            logger.error("[SMS] Timeout sending to %s via %s", mobile, provider)
        except requests.exceptions.ConnectionError as exc:
            error_msg = f"Connection error: {exc}"
            logger.error("[SMS] Connection error sending to %s via %s: %s", mobile, provider, exc)
        except Exception as exc:                # pragma: no cover
            error_msg = str(exc)
            logger.exception("[SMS] Unexpected error sending to %s via %s", mobile, provider)

        # ── Audit log ──────────────────────────────────────────────
        SMSService._log_attempt(mobile, provider, success, provider_response, error_msg)

        if not success:
            logger.warning(
                "[SMS] Failed to send to %s via %s — response: %s — error: %s",
                mobile, provider, provider_response, error_msg,
            )

        return {
            "success":           success,
            "provider":          provider,
            "provider_response": provider_response,
        }

    @staticmethod
    def send_otp(mobile: str, otp: str) -> dict:
        """
        Send an OTP SMS using the configured OTP template.

        Args:
            mobile: 10-digit mobile number.
            otp:    6-digit one-time password string.

        Returns:
            Same dict as send().
        """
        message     = f"Your Trident ERP OTP is {otp}. Valid for 10 minutes. Do not share."
        template_id = SMSService._cfg().get("OTP_TEMPLATE_ID", "")
        return SMSService.send(mobile, message, template_id)

    # ── Helpers ────────────────────────────────────────────────────

    @staticmethod
    def _log_attempt(
        mobile: str,
        provider: str,
        success: bool,
        provider_response: dict,
        error_msg: str,
    ) -> None:
        """Write a best-effort AuditLog entry. Never raises."""
        try:
            from apps.core.models import AuditLog

            # Mask last 6 digits of mobile for privacy in logs
            masked = mobile[:4] + "XXXXXX" if len(mobile) >= 6 else mobile

            AuditLog.objects.create(
                user=None,                        # system-generated
                action="SMS_SENT",
                module="core",
                resource="SMSService",
                notes=(
                    f"provider={provider} mobile={masked} "
                    f"success={success} "
                    + (f"error={error_msg}" if error_msg else f"status={provider_response.get('status_code')}")
                ),
                new_values={
                    "mobile_masked": masked,
                    "provider":      provider,
                    "success":       success,
                    "response":      provider_response,
                    **({"error": error_msg} if error_msg else {}),
                },
            )
        except Exception as exc:          # pragma: no cover
            logger.error("[SMS] AuditLog write failed: %s", exc)
