from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('core', '0001_initial'),
    ]

    operations = [
        migrations.AddField(
            model_name='plant',
            name='stock_issue_mode',
            field=models.CharField(
                choices=[('FIFO', 'FIFO (oldest first)'), ('LIFO', 'LIFO (newest first)'), ('MANUAL', 'Manual (operator selects)')],
                default='FIFO',
                help_text='Stock issuing mode: FIFO, LIFO, or Manual',
                max_length=10,
            ),
        ),
    ]
