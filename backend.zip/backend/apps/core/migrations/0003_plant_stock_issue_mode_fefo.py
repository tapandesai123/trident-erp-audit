from django.db import migrations, models


class Migration(migrations.Migration):
    """
    Replace LIFO with FEFO in Plant.stock_issue_mode choices.
    Any existing Plant rows with stock_issue_mode='LIFO' are migrated to 'FIFO'
    (safe default — FIFO is the system default and the most common mode).
    """

    dependencies = [
        ('core', '0002_plant_stock_issue_mode'),
    ]

    operations = [
        # Data migration: move any LIFO plants to FIFO before altering the field
        migrations.RunSQL(
            sql="UPDATE core_plant SET stock_issue_mode='FIFO' WHERE stock_issue_mode='LIFO';",
            reverse_sql="",  # Non-reversible — original LIFO data is gone
        ),
        migrations.AlterField(
            model_name='plant',
            name='stock_issue_mode',
            field=models.CharField(
                choices=[
                    ('FIFO', 'FIFO (oldest first)'),
                    ('FEFO', 'FEFO (earliest expiry first)'),
                    ('MANUAL', 'Manual (operator selects)'),
                ],
                default='FIFO',
                help_text='Stock issuing mode: FIFO, FEFO, or Manual',
                max_length=10,
            ),
        ),
    ]
