"""
Sales Module Services — Section 5
Business logic:
  - Enquiry → Quotation → SO pipeline
  - GST calculation (interstate IGST vs intrastate CGST+SGST)
  - Despatch creation from SO
  - Invoice creation from Despatch
  - Gate-out scan with auto-email
  - Invoice reach / POD recording
  - Pending order position reports
  - Auto-email: invoices made yesterday, pending order position
"""
from decimal import Decimal, ROUND_HALF_UP
from datetime import date
from django.db import transaction
from django.db.models import Sum, F, Q
from django.utils import timezone
from django.core.mail import send_mail
from django.conf import settings as django_settings

from apps.core.models import AuditLog, DocSequence, Notification
from apps.sales.models import (
    Enquiry, EnquiryFollowup,
    Quotation, QuotationLine,
    SalesOrder, SOLine, SOSchedule,
    Despatch, DespatchLine,
    Invoice, InvoiceLine,
    InvoiceReachRecord,
    CustomerComplaint,
)


# ═══════════════════════════════════════════════════════════════════
# HELPERS
# ═══════════════════════════════════════════════════════════════════

def _log(user, action, resource, resource_id, details=None):
    # BUG-020 fix: resource_id must be int (IntegerField); use new_values= not details=
    AuditLog.objects.create(
        user=user, action=action, module="sales",
        resource=resource, resource_id=int(resource_id),
        new_values=details or {},
    )


def _get_next_number(plant, doc_type, prefix):
    from apps.purchase.services import get_next_doc_number
    return get_next_doc_number(plant, doc_type, prefix)


def _two(val):
    """Round to 2 decimal places."""
    return Decimal(val).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


# ═══════════════════════════════════════════════════════════════════
# GST CALCULATION
# ═══════════════════════════════════════════════════════════════════

def determine_gst_type(plant, customer):
    """
    Returns ('IGST', rate) for interstate or ('CGST_SGST', rate) for intrastate.
    Compares plant state vs customer billing state.
    """
    plant_state    = (plant.gstin or "")[:2]  # First 2 chars = state code
    customer_state = (customer.gstin or "")[:2] if customer.gstin else ""

    if not customer_state or plant_state == customer_state:
        return "CGST_SGST"
    return "IGST"


def calculate_line_gst(unit_rate, qty, discount_pct, gst_pct, gst_type):
    """
    Returns dict with taxable_amt, cgst, sgst, igst, gst_amount, line_total.
    """
    gross     = _two(unit_rate * qty)
    discount  = _two(gross * discount_pct / 100)
    taxable   = _two(gross - discount)

    if gst_type == "IGST":
        igst = _two(taxable * gst_pct / 100)
        cgst = sgst = Decimal("0")
    else:
        half  = _two(gst_pct / 2)
        cgst  = _two(taxable * half / 100)
        sgst  = cgst
        igst  = Decimal("0")

    gst_amount = cgst + sgst + igst
    return {
        "taxable_amt":  taxable,
        "cgst_pct":     Decimal("0") if gst_type == "IGST" else _two(gst_pct / 2),
        "sgst_pct":     Decimal("0") if gst_type == "IGST" else _two(gst_pct / 2),
        "igst_pct":     gst_pct if gst_type == "IGST" else Decimal("0"),
        "cgst_amount":  cgst,
        "sgst_amount":  sgst,
        "igst_amount":  igst,
        "gst_amount":   gst_amount,
        "line_total":   _two(taxable + gst_amount),
    }


def recalculate_document_totals(lines):
    """
    Given a queryset/list of line objects, return header-level totals.
    """
    subtotal = cgst = sgst = igst = Decimal("0")
    for line in lines:
        subtotal += getattr(line, "taxable_amt", Decimal("0"))
        cgst     += getattr(line, "cgst_amount", Decimal("0"))
        sgst     += getattr(line, "sgst_amount", Decimal("0"))
        igst     += getattr(line, "igst_amount", Decimal("0"))
    gst_total = cgst + sgst + igst
    return {
        "subtotal":       _two(subtotal),
        "taxable_amount": _two(subtotal),
        "cgst_amount":    _two(cgst),
        "sgst_amount":    _two(sgst),
        "igst_amount":    _two(igst),
        "total_amount":   _two(subtotal + gst_total),
    }


# ═══════════════════════════════════════════════════════════════════
# ENQUIRY
# ═══════════════════════════════════════════════════════════════════

@transaction.atomic
def create_enquiry(data: dict, user, plant) -> Enquiry:
    enq_number = _get_next_number(plant, "ENQ", "ENQ")
    enquiry = Enquiry.objects.create(
        plant=plant,
        enquiry_number=enq_number,
        enquiry_date=data.get("enquiry_date", date.today()),
        source=data["source"],
        customer_id=data.get("customer_id"),
        prospect_name=data.get("prospect_name", ""),
        prospect_phone=data.get("prospect_phone", ""),
        prospect_email=data.get("prospect_email", ""),
        contact_person=data.get("contact_person", ""),
        product_description=data["product_description"],
        estimated_qty_per_month=data.get("estimated_qty_per_month"),
        target_price=data.get("target_price"),
        assigned_to_id=data.get("assigned_to_id") or user.pk,
        next_followup_date=data.get("next_followup_date"),
        remarks=data.get("remarks", ""),
    )
    _log(user, "CREATED", "Enquiry", enquiry.pk, {"number": enq_number})
    return enquiry


def add_followup(enquiry: Enquiry, data: dict, user) -> EnquiryFollowup:
    followup = EnquiryFollowup.objects.create(
        enquiry=enquiry,
        followup_date=data.get("followup_date", date.today()),
        followup_type=data["followup_type"],
        done_by=user,
        summary=data["summary"],
        outcome=data.get("outcome", ""),
        next_action=data.get("next_action", ""),
        next_date=data.get("next_date"),
    )
    # Update next followup on enquiry
    if data.get("next_date"):
        enquiry.next_followup_date = data["next_date"]
        enquiry.save(update_fields=["next_followup_date"])
    return followup


# ═══════════════════════════════════════════════════════════════════
# QUOTATION
# ═══════════════════════════════════════════════════════════════════

@transaction.atomic
def create_quotation(data: dict, lines_data: list, user, plant) -> Quotation:
    quot_number = _get_next_number(plant, "QT", "QT")
    gst_type = determine_gst_type(plant, data["customer"])

    quotation = Quotation.objects.create(
        plant=plant,
        quotation_number=quot_number,
        quotation_date=data.get("quotation_date", date.today()),
        valid_until=data.get("valid_until"),
        customer=data["customer"],
        ship_to_id=data.get("ship_to_id"),
        price_list_id=data.get("price_list_id"),
        discount_pct=data.get("discount_pct", 0),
        payment_terms=data.get("payment_terms", ""),
        delivery_terms=data.get("delivery_terms", ""),
        prepared_by=user,
        remarks=data.get("remarks", ""),
        terms_conditions=data.get("terms_conditions", ""),
    )

    for idx, ld in enumerate(lines_data, start=1):
        gst_calc = calculate_line_gst(
            unit_rate=Decimal(str(ld["unit_rate"])),
            qty=Decimal(str(ld["qty"])),
            discount_pct=Decimal(str(ld.get("discount_pct", 0))),
            gst_pct=Decimal(str(ld.get("gst_pct", 18))),
            gst_type=gst_type,
        )
        QuotationLine.objects.create(
            quotation=quotation,
            line_no=idx,
            item_id=ld.get("item_id"),
            description=ld.get("description", ""),
            hsn_code=ld.get("hsn_code", ""),
            qty=ld["qty"],
            uom_id=ld.get("uom_id"),
            unit_rate=ld["unit_rate"],
            discount_pct=ld.get("discount_pct", 0),
            gst_pct=ld.get("gst_pct", 18),
            **gst_calc,
        )

    # Update header totals
    totals = recalculate_document_totals(quotation.lines.all())
    for k, v in totals.items():
        setattr(quotation, k, v)
    quotation.save()

    _log(user, "CREATED", "Quotation", quotation.pk, {"number": quot_number})
    return quotation


def submit_quotation_for_approval(quotation: Quotation, user):
    quotation.status = Quotation.QuotationStatus.PENDING
    quotation.save(update_fields=["status"])
    _log(user, "SUBMITTED", "Quotation", quotation.pk)


def approve_quotation(quotation: Quotation, approver):
    quotation.status = Quotation.QuotationStatus.APPROVED
    quotation.approved_by = approver
    quotation.approved_at = timezone.now()
    quotation.save(update_fields=["status", "approved_by", "approved_at"])
    _log(approver, "APPROVED", "Quotation", quotation.pk)


@transaction.atomic
def revise_quotation(quotation: Quotation, lines_data: list, user) -> Quotation:
    """Create a new revision of an existing quotation."""
    new_rev = quotation.revision + 1
    new_number = f"{quotation.quotation_number}-R{new_rev}"

    # Mark old as revised
    quotation.status = Quotation.QuotationStatus.REVISED
    quotation.save(update_fields=["status"])

    # Copy and create new revision
    new_data = {
        "customer":      quotation.customer,
        "ship_to_id":    quotation.ship_to_id,
        "price_list_id": quotation.price_list_id,
        "discount_pct":  quotation.discount_pct,
        "payment_terms": quotation.payment_terms,
        "delivery_terms": quotation.delivery_terms,
        "remarks":       quotation.remarks,
    }
    new_quot = create_quotation(new_data, lines_data, user, quotation.plant)
    new_quot.revision        = new_rev
    new_quot.parent_quotation = quotation
    new_quot.quotation_number = new_number
    new_quot.save(update_fields=["revision", "parent_quotation", "quotation_number"])
    return new_quot


# ═══════════════════════════════════════════════════════════════════
# SALES ORDER
# ═══════════════════════════════════════════════════════════════════

@transaction.atomic
def create_sales_order(data: dict, lines_data: list, user, plant) -> SalesOrder:
    so_number = _get_next_number(plant, "SO", "SO")
    gst_type  = determine_gst_type(plant, data["customer"])

    so = SalesOrder.objects.create(
        plant=plant,
        so_number=so_number,
        so_date=data.get("so_date", date.today()),
        so_type=data.get("so_type", SalesOrder.SOType.REGULAR),
        customer=data["customer"],
        ship_to_id=data.get("ship_to_id"),
        customer_po_number=data.get("customer_po_number", ""),
        customer_po_date=data.get("customer_po_date"),
        quotation_id=data.get("quotation_id"),
        required_delivery_date=data.get("required_delivery_date"),
        payment_terms=data.get("payment_terms", ""),
        delivery_terms=data.get("delivery_terms", ""),
        transporter=data.get("transporter", ""),
        discount_pct=data.get("discount_pct", 0),
        price_list_id=data.get("price_list_id"),
        salesman_id=data.get("salesman_id") or user.pk,
        created_by=user,
        remarks=data.get("remarks", ""),
        status=SalesOrder.SOStatus.CONFIRMED,
    )

    for idx, ld in enumerate(lines_data, start=1):
        gst_calc = calculate_line_gst(
            unit_rate=Decimal(str(ld["unit_rate"])),
            qty=Decimal(str(ld["ordered_qty"])),
            discount_pct=Decimal(str(ld.get("discount_pct", 0))),
            gst_pct=Decimal(str(ld.get("gst_pct", 18))),
            gst_type=gst_type,
        )
        SOLine.objects.create(
            so=so,
            line_no=idx,
            item_id=ld.get("item_id"),
            description=ld.get("description", ""),
            hsn_code=ld.get("hsn_code", ""),
            ordered_qty=ld["ordered_qty"],
            uom_id=ld.get("uom_id"),
            unit_rate=ld["unit_rate"],
            discount_pct=ld.get("discount_pct", 0),
            gst_pct=ld.get("gst_pct", 18),
            required_date=ld.get("required_date"),
            remarks=ld.get("remarks", ""),
            **{k: v for k, v in gst_calc.items() if k not in
               ["cgst_amount","sgst_amount","igst_amount"]},
            # rename for SOLine fields
        )

    totals = recalculate_document_totals(so.lines.all())
    for k, v in totals.items():
        setattr(so, k, v)
    so.save()

    # Mark quotation as converted
    if so.quotation:
        so.quotation.status = Quotation.QuotationStatus.CONVERTED
        so.quotation.save(update_fields=["status"])

    _log(user, "CREATED", "SalesOrder", so.pk, {"so_number": so_number})
    return so


def confirm_sales_order(so: SalesOrder, user):
    so.status = SalesOrder.SOStatus.CONFIRMED
    so.save(update_fields=["status"])
    _log(user, "CONFIRMED", "SalesOrder", so.pk)


# ═══════════════════════════════════════════════════════════════════
# DESPATCH
# ═══════════════════════════════════════════════════════════════════

@transaction.atomic
def create_despatch(data: dict, lines_data: list, user, plant) -> Despatch:
    """Create DC from SO. Updates SO line despatched quantities."""
    dc_number = _get_next_number(plant, "DC", "DC")

    so = SalesOrder.objects.get(pk=data["sales_order_id"])

    despatch = Despatch.objects.create(
        plant=plant,
        dc_number=dc_number,
        dc_date=data.get("dc_date", date.today()),
        sales_order=so,
        customer=so.customer,
        ship_to_id=data.get("ship_to_id") or so.ship_to_id,
        transporter_name=data.get("transporter_name", ""),
        vehicle_number=data.get("vehicle_number", ""),
        lr_number=data.get("lr_number", ""),
        lr_date=data.get("lr_date"),
        driver_name=data.get("driver_name", ""),
        driver_phone=data.get("driver_phone", ""),
        no_of_packages=data.get("no_of_packages", 0),
        gross_weight_kg=data.get("gross_weight_kg"),
        prepared_by=user,
        remarks=data.get("remarks", ""),
        barcode_data=dc_number,  # Simple barcode = DC number
    )

    for ld in lines_data:
        so_line = SOLine.objects.select_for_update().get(pk=ld["so_line_id"])
        desp_qty = Decimal(str(ld["despatched_qty"]))

        if desp_qty > so_line.pending_qty:
            raise ValueError(
                f"Despatch qty ({desp_qty}) exceeds pending qty "
                f"({so_line.pending_qty}) for line {so_line.line_no}"
            )

        DespatchLine.objects.create(
            despatch=despatch,
            so_line=so_line,
            item=so_line.item,
            description=so_line.description,
            despatched_qty=desp_qty,
            uom=so_line.uom,
            unit_rate=so_line.unit_rate,
            remarks=ld.get("remarks", ""),
        )

        # Update SO line despatched quantity
        so_line.despatched_qty = F("despatched_qty") + desp_qty
        so_line.save(update_fields=["despatched_qty"])

    # Update SO status
    _update_so_status(so)

    _log(user, "CREATED", "Despatch", despatch.pk, {"dc_number": dc_number})
    return despatch


def _update_so_status(so: SalesOrder):
    """Recalculate SO status based on despatched quantities."""
    lines = so.lines.all()
    total_ordered   = sum(l.ordered_qty for l in lines)
    total_despatched = sum(l.despatched_qty for l in lines)
    if total_despatched >= total_ordered:
        so.status = SalesOrder.SOStatus.FULLY_DESPATCHED
    elif total_despatched > 0:
        so.status = SalesOrder.SOStatus.PARTIALLY_DESPATCHED
    so.save(update_fields=["status"])


@transaction.atomic
def record_gate_out(despatch: Despatch, user, qr_scan_data=""):
    """
    Android gate guard scans DC barcode → records gate-out time.
    Auto-emails customer and marketing team.
    Prevents duplicate gate-out.
    """
    if despatch.status == Despatch.DespatchStatus.GATE_OUT:
        raise ValueError(f"Gate-out already recorded for {despatch.dc_number}")

    despatch.status        = Despatch.DespatchStatus.GATE_OUT
    despatch.gate_out_time = timezone.now()
    despatch.gate_out_by   = user
    despatch.gate_out_qr_scan = qr_scan_data
    despatch.save(update_fields=["status", "gate_out_time", "gate_out_by", "gate_out_qr_scan"])

    # BUG-040 fix: send email after commit so DB gate_out is persisted before email fires
    # Prevents sending email if transaction rolls back, and avoids calling email mid-transaction
    from django.db import transaction as _tx
    _tx.on_commit(lambda: _send_gate_out_email(despatch))

    _log(user, "GATE_OUT", "Despatch", despatch.pk,
         {"dc_number": despatch.dc_number, "time": str(despatch.gate_out_time)})
    return despatch


def _send_gate_out_email(despatch: Despatch):
    """Send dispatch notification to customer and marketing."""
    customer_email = despatch.customer.email or ""
    lines_summary  = "\n".join([
        f"  • {l.description}: {l.despatched_qty} {l.uom.code if l.uom else ''}"
        for l in despatch.lines.all()
    ])
    body = (
        f"Dear {despatch.customer.name},\n\n"
        f"Your order has been dispatched.\n\n"
        f"DC No: {despatch.dc_number}\n"
        f"Date: {despatch.dc_date}\n"
        f"Vehicle: {despatch.vehicle_number}\n"
        f"Driver: {despatch.driver_name} ({despatch.driver_phone})\n\n"
        f"Items:\n{lines_summary}\n\n"
        f"Regards,\nTrindent Paper Box Industries"
    )
    if customer_email:
        send_mail(
            subject=f"Dispatch Notification — DC {despatch.dc_number}",
            message=body,
            from_email=getattr(django_settings, "DEFAULT_FROM_EMAIL", "erp@trident.com"),
            recipient_list=[customer_email],
            fail_silently=True,
        )
        despatch.customer_email_sent = True
        despatch.save(update_fields=["customer_email_sent"])

    # Also alert marketing/salesman
    marketing_emails = getattr(django_settings, "MARKETING_ALERT_EMAILS", [])
    if marketing_emails:
        send_mail(
            subject=f"[Gate Out] {despatch.dc_number} — {despatch.customer.name}",
            message=body,
            from_email=getattr(django_settings, "DEFAULT_FROM_EMAIL", "erp@trident.com"),
            recipient_list=marketing_emails,
            fail_silently=True,
        )
        despatch.marketing_email_sent = True
        despatch.save(update_fields=["marketing_email_sent"])


# ═══════════════════════════════════════════════════════════════════
# INVOICE
# ═══════════════════════════════════════════════════════════════════

@transaction.atomic
def create_invoice_from_despatch(despatch: Despatch, data: dict, user, plant) -> Invoice:
    """Create tax invoice from a despatch note."""
    inv_number = _get_next_number(plant, "INV", "INV")
    gst_type   = determine_gst_type(plant, despatch.customer)
    is_interstate = gst_type == "IGST"

    invoice = Invoice.objects.create(
        plant=plant,
        invoice_number=inv_number,
        invoice_date=data.get("invoice_date", date.today()),
        invoice_type=Invoice.InvoiceType.TAX_INVOICE,
        customer=despatch.customer,
        ship_to=despatch.ship_to,
        sales_order=despatch.sales_order,
        despatch=despatch,
        place_of_supply=data.get("place_of_supply", ""),
        is_interstate=is_interstate,
        customer_gstin=despatch.customer.gstin or "",
        currency="INR",
        transporter_name=despatch.transporter_name,
        vehicle_number=despatch.vehicle_number,
        lr_number=despatch.lr_number,
        barcode_data=inv_number,
        payment_terms=data.get("payment_terms", ""),
        prepared_by=user,
        remarks=data.get("remarks", ""),
        status=Invoice.InvoiceStatus.CONFIRMED,
    )

    for idx, desp_line in enumerate(despatch.lines.all(), start=1):
        so_line = desp_line.so_line
        gst_calc = calculate_line_gst(
            unit_rate=desp_line.unit_rate or so_line.unit_rate,
            qty=desp_line.despatched_qty,
            discount_pct=so_line.discount_pct,
            gst_pct=so_line.gst_pct,
            gst_type=gst_type,
        )
        InvoiceLine.objects.create(
            invoice=invoice,
            line_no=idx,
            so_line=so_line,
            item=desp_line.item,
            description=desp_line.description,
            hsn_code=so_line.hsn_code,
            qty=desp_line.despatched_qty,
            uom=desp_line.uom,
            unit_rate=desp_line.unit_rate or so_line.unit_rate,
            discount_pct=so_line.discount_pct,
            gst_pct=so_line.gst_pct,
            cgst_pct=gst_calc["cgst_pct"],
            sgst_pct=gst_calc["sgst_pct"],
            igst_pct=gst_calc["igst_pct"],
            taxable_amt=gst_calc["taxable_amt"],
            cgst_amount=gst_calc["cgst_amount"],
            sgst_amount=gst_calc["sgst_amount"],
            igst_amount=gst_calc["igst_amount"],
            line_total=gst_calc["line_total"],
        )
        # Update SO line invoiced qty
        so_line.invoiced_qty = F("invoiced_qty") + desp_line.despatched_qty
        so_line.save(update_fields=["invoiced_qty"])

    # Calculate TCS if applicable
    tcs_pct = despatch.customer.tcs_pct if hasattr(despatch.customer, "tcs_pct") else Decimal("0")

    # Update totals
    totals = recalculate_document_totals(invoice.lines.all())
    tcs_amount = _two(totals["total_amount"] * tcs_pct / 100)
    round_off  = _two(round(float(totals["total_amount"] + tcs_amount)) -
                       (totals["total_amount"] + tcs_amount))

    invoice.subtotal         = totals["subtotal"]
    invoice.taxable_amount   = totals["taxable_amount"]
    invoice.cgst_amount      = totals["cgst_amount"]
    invoice.sgst_amount      = totals["sgst_amount"]
    invoice.igst_amount      = totals["igst_amount"]
    invoice.tcs_pct          = tcs_pct
    invoice.tcs_amount       = tcs_amount
    invoice.round_off        = round_off
    invoice.total_amount     = totals["total_amount"] + tcs_amount + round_off
    invoice.outstanding_amount = invoice.total_amount
    invoice.status           = Invoice.InvoiceStatus.IRN_PENDING
    invoice.save()

    _log(user, "CREATED", "Invoice", invoice.pk, {"invoice_number": inv_number})
    return invoice


def record_invoice_reach(invoice: Invoice, data: dict, user) -> InvoiceReachRecord:
    """Record POD / invoice reach confirmation."""
    reach, _ = InvoiceReachRecord.objects.update_or_create(
        invoice=invoice,
        defaults={
            "customer_ge_number": data.get("customer_ge_number", ""),
            "customer_ge_date":   data.get("customer_ge_date"),
            "received_by_customer": data.get("received_by_customer", ""),
            "remarks":            data.get("remarks", ""),
            "recorded_by":        user,
        }
    )
    return reach


# ═══════════════════════════════════════════════════════════════════
# COMPLAINT
# ═══════════════════════════════════════════════════════════════════

@transaction.atomic
def create_complaint(data: dict, user, plant) -> CustomerComplaint:
    comp_number = _get_next_number(plant, "CC", "CC")
    complaint = CustomerComplaint.objects.create(
        plant=plant,
        complaint_number=comp_number,
        complaint_date=data.get("complaint_date", date.today()),
        category=data["category"],
        customer_id=data["customer_id"],
        invoice_id=data.get("invoice_id"),
        sales_order_id=data.get("sales_order_id"),
        complaint_details=data["complaint_details"],
        customer_contact=data.get("customer_contact", ""),
        assigned_to_id=data.get("assigned_to_id"),
        logged_by=user,
    )
    _log(user, "CREATED", "CustomerComplaint", complaint.pk, {"number": comp_number})
    return complaint


# ═══════════════════════════════════════════════════════════════════
# REPORTS
# ═══════════════════════════════════════════════════════════════════

def get_pending_order_position(plant, customer=None):
    """
    Orders vs despatch vs invoice — the daily dashboard report.
    Returns per-SO summary.
    """
    qs = SalesOrder.objects.filter(
        plant=plant,
        status__in=[
            SalesOrder.SOStatus.CONFIRMED,
            SalesOrder.SOStatus.IN_PRODUCTION,
            SalesOrder.SOStatus.READY,
            SalesOrder.SOStatus.PARTIALLY_DESPATCHED,
        ]
    ).select_related("customer")

    if customer:
        qs = qs.filter(customer=customer)

    result = []
    for so in qs:
        lines = so.lines.all()
        result.append({
            "so_number":     so.so_number,
            "so_date":       so.so_date,
            "customer":      so.customer.name,
            "status":        so.status,
            "total_ordered": sum(l.ordered_qty for l in lines),
            "total_despatched": sum(l.despatched_qty for l in lines),
            "total_pending": sum(l.pending_qty for l in lines),
            "required_date": so.required_delivery_date,
        })
    return result


def get_invoices_yesterday(plant):
    """Invoices made yesterday — for daily auto-email."""
    from datetime import timedelta
    yesterday = date.today() - timedelta(days=1)
    return Invoice.objects.filter(
        plant=plant,
        invoice_date=yesterday,
        invoice_type=Invoice.InvoiceType.TAX_INVOICE,
    ).select_related("customer", "sales_order")


def get_unreached_invoices(plant, days=30):
    """
    Invoices despatched but no POD recorded yet — transit loss risk.
    """
    from datetime import timedelta
    cutoff = date.today() - timedelta(days=days)
    return Invoice.objects.filter(
        plant=plant,
        invoice_date__lte=cutoff,
        gate_out_time__isnull=False,
        reach_record__isnull=True,
    ).select_related("customer")


def get_debtor_ageing(plant):
    """
    Outstanding invoices grouped into 0-30, 31-60, 61-90, 90+ buckets.
    """
    from datetime import timedelta
    today = date.today()
    invoices = Invoice.objects.filter(
        plant=plant,
        outstanding_amount__gt=0,
        status__in=[
            Invoice.InvoiceStatus.PAYMENT_PENDING,
            Invoice.InvoiceStatus.PARTIALLY_PAID,
        ]
    ).select_related("customer")

    buckets = {"0_30": [], "31_60": [], "61_90": [], "90_plus": []}
    for inv in invoices:
        age = (today - inv.invoice_date).days
        if age <= 30:
            buckets["0_30"].append(inv)
        elif age <= 60:
            buckets["31_60"].append(inv)
        elif age <= 90:
            buckets["61_90"].append(inv)
        else:
            buckets["90_plus"].append(inv)
    return buckets


# ═══════════════════════════════════════════════════════════════════
# EDI EXCEL UPLOAD SERVICE
# ═══════════════════════════════════════════════════════════════════

def parse_edi_excel(file, user, plant):
    """
    Parse customer PO Excel (Flipkart/Amazon format).
    Creates SalesOrder objects in DRAFT status for review.
    Column mapping configurable via SystemConfig.
    Returns: {"created": N, "skipped": N, "errors": [...]}
    """
    try:
        import openpyxl
    except ImportError:
        return {"error": "openpyxl not installed", "created": 0, "skipped": 0, "errors": []}

    from apps.sales.models import SalesOrder
    from apps.masters.models import Customer, Item
    from apps.core.models import SystemConfig
    import json

    # Default column mapping (overridable via SystemConfig)
    default_map = {
        "customer_name_col": "B",
        "item_code_col": "C",
        "quantity_col": "D",
        "required_date_col": "E",
        "remarks_col": "F",
    }

    try:
        config_obj = SystemConfig.objects.filter(key="EDI_COLUMN_MAP_DEFAULT").first()
        col_map = json.loads(config_obj.value) if config_obj else default_map
    except Exception:
        col_map = default_map

    wb = openpyxl.load_workbook(file, read_only=True, data_only=True)
    ws = wb.active

    created = 0
    skipped = 0
    errors = []

    # Skip header row
    rows = list(ws.iter_rows(min_row=2, values_only=True))

    for row_num, row in enumerate(rows, start=2):
        try:
            if not row or not any(row):
                skipped += 1
                continue

            # Basic extraction (adjust column indices as per mapping)
            customer_name = str(row[1]).strip() if len(row) > 1 and row[1] else ""
            item_code = str(row[2]).strip() if len(row) > 2 and row[2] else ""
            quantity = row[3] if len(row) > 3 else None
            required_date = row[4] if len(row) > 4 else None
            remarks = str(row[5]).strip() if len(row) > 5 and row[5] else ""

            if not customer_name or not item_code or not quantity:
                errors.append(f"Row {row_num}: missing customer, item, or quantity")
                skipped += 1
                continue

            # Find or note customer
            customer = Customer.objects.filter(name__icontains=customer_name).first()
            if not customer:
                errors.append(f"Row {row_num}: customer '{customer_name}' not found")
                skipped += 1
                continue

            # BUG-025 fix: use so_date= not order_date=; so_number required
            so = SalesOrder.objects.create(
                plant=plant,
                so_number=_get_next_number(plant, "SO", "SO"),
                so_date=__import__("datetime").date.today(),
                customer=customer,
                required_delivery_date=required_date if hasattr(required_date, "year") else None,
                status="DRAFT",
                remarks=f"EDI Upload – {remarks}",
                created_by=user,
            )

            # Add line if item found
            item = Item.objects.filter(code=item_code).first()
            if item:
                from apps.sales.models import SOLine
                # BUG-025 fix: line_no= not line_number=; ordered_qty= not quantity=; uom= not base_uom
                SOLine.objects.create(
                    so=so,
                    line_no=1,
                    item=item,
                    description=item.name,
                    ordered_qty=Decimal(str(quantity)),
                    uom=item.uom,
                    unit_rate=Decimal("0"),
                )

            created += 1

        except Exception as e:
            errors.append(f"Row {row_num}: {str(e)}")
            skipped += 1

    return {
        "created": created,
        "skipped": skipped,
        "errors": errors[:20],  # cap error list
    }


# ═══════════════════════════════════════════════════════════════════
# EXPORT PACKING LIST PDF (Task 15)
# ═══════════════════════════════════════════════════════════════════

def generate_packing_list_pdf(invoice_id) -> bytes:
    """
    Generate an export packing list PDF for the given invoice.
    Returns raw PDF bytes using WeasyPrint.

    Data chain: Invoice → Despatch → DespatchLine → SOLine → Item
    Falls back to InvoiceLines when no DespatchLines exist.
    """
    from decimal import Decimal, ROUND_HALF_UP

    # ── Fetch data ─────────────────────────────────────────────────
    invoice = Invoice.objects.select_related(
        "plant", "plant__company",
        "customer", "ship_to",
        "sales_order",
        "despatch",
    ).get(pk=invoice_id)

    company = invoice.plant.company
    plant   = invoice.plant
    customer = invoice.customer

    # ── Build line rows from DespatchLines, fallback to InvoiceLines ─
    rows = []
    total_qty = Decimal("0")
    total_gross_wt = Decimal("0")
    total_net_wt   = Decimal("0")
    total_fcy      = Decimal("0")
    total_inr      = Decimal("0")

    # Exchange rate: use invoice.exchange_rate or 1
    exchange_rate = (invoice.exchange_rate or Decimal("1"))
    if exchange_rate == 0:
        exchange_rate = Decimal("1")

    # Currency label
    currency = getattr(invoice, "export_currency", None) or invoice.foreign_currency or "USD"

    # Proportional weight per line: distribute invoice totals by qty fraction
    inv_gross = invoice.gross_weight_kg or Decimal("0")
    inv_net   = invoice.net_weight_kg   or Decimal("0")

    # Try DespatchLines first
    despatch_lines = []
    if invoice.despatch_id:
        despatch_lines = list(
            DespatchLine.objects.select_related(
                "item", "uom", "so_line",
            ).filter(despatch_id=invoice.despatch_id)
        )

    if despatch_lines:
        total_despatched_qty = sum(dl.despatched_qty for dl in despatch_lines) or Decimal("1")
        for i, dl in enumerate(despatch_lines, start=1):
            qty = dl.despatched_qty
            qty_fraction = qty / total_despatched_qty
            gross_wt = (inv_gross * qty_fraction).quantize(Decimal("0.001"), ROUND_HALF_UP)
            net_wt   = (inv_net   * qty_fraction).quantize(Decimal("0.001"), ROUND_HALF_UP)

            unit_rate_inr = dl.unit_rate or Decimal("0")
            amt_inr = (unit_rate_inr * qty).quantize(Decimal("0.01"), ROUND_HALF_UP)
            unit_price_fcy = (unit_rate_inr / exchange_rate).quantize(Decimal("0.0001"), ROUND_HALF_UP)
            amt_fcy = (amt_inr / exchange_rate).quantize(Decimal("0.01"), ROUND_HALF_UP)

            item = dl.item
            rows.append({
                "sl_no":           i,
                "customer_part":   item.code if item else "",
                "description":     dl.description or (item.name if item else ""),
                "hsn":             (item.hsn_code if item else "") or "",
                "qty":             qty,
                "unit":            dl.uom.code if dl.uom else "PCS",
                "gross_wt":        gross_wt,
                "net_wt":          net_wt,
                "unit_price_fcy":  unit_price_fcy,
                "amt_fcy":         amt_fcy,
                "amt_inr":         amt_inr,
            })
            total_qty      += qty
            total_gross_wt += gross_wt
            total_net_wt   += net_wt
            total_fcy      += amt_fcy
            total_inr      += amt_inr
    else:
        # Fallback: InvoiceLines
        inv_lines = list(
            InvoiceLine.objects.select_related("item", "uom").filter(invoice=invoice)
        )
        total_inv_qty = sum(il.qty for il in inv_lines) or Decimal("1")
        for i, il in enumerate(inv_lines, start=1):
            qty = il.qty
            qty_fraction = qty / total_inv_qty
            gross_wt = (inv_gross * qty_fraction).quantize(Decimal("0.001"), ROUND_HALF_UP)
            net_wt   = (inv_net   * qty_fraction).quantize(Decimal("0.001"), ROUND_HALF_UP)

            unit_rate_inr = il.unit_rate or Decimal("0")
            amt_inr = il.taxable_amt or (unit_rate_inr * qty).quantize(Decimal("0.01"), ROUND_HALF_UP)
            unit_price_fcy = (unit_rate_inr / exchange_rate).quantize(Decimal("0.0001"), ROUND_HALF_UP)
            amt_fcy = (amt_inr / exchange_rate).quantize(Decimal("0.01"), ROUND_HALF_UP)

            item = il.item
            rows.append({
                "sl_no":           i,
                "customer_part":   item.code if item else "",
                "description":     il.description or (item.name if item else ""),
                "hsn":             il.hsn_code or (item.hsn_code if item else "") or "",
                "qty":             qty,
                "unit":            il.uom.code if il.uom else "PCS",
                "gross_wt":        gross_wt,
                "net_wt":          net_wt,
                "unit_price_fcy":  unit_price_fcy,
                "amt_fcy":         amt_fcy,
                "amt_inr":         amt_inr,
            })
            total_qty      += qty
            total_gross_wt += gross_wt
            total_net_wt   += net_wt
            total_fcy      += amt_fcy
            total_inr      += amt_inr

    # ── Helper formatters ──────────────────────────────────────────
    def _d(val, places=2):
        if val is None:
            return "—"
        return f"{float(val):,.{places}f}"

    def _s(val):
        return val if val else "—"

    # ── Build HTML ─────────────────────────────────────────────────
    rows_html = ""
    for r in rows:
        rows_html += f"""
        <tr>
          <td class="center">{r['sl_no']}</td>
          <td>{r['customer_part']}</td>
          <td>{r['description']}</td>
          <td class="center">{r['hsn']}</td>
          <td class="right">{_d(r['qty'], 2)}</td>
          <td class="center">{r['unit']}</td>
          <td class="right">{_d(r['gross_wt'], 3)}</td>
          <td class="right">{_d(r['net_wt'], 3)}</td>
          <td class="right">{_d(r['unit_price_fcy'], 4)}</td>
          <td class="right">{_d(r['amt_fcy'], 2)}</td>
          <td class="right">{_d(r['amt_inr'], 2)}</td>
        </tr>"""

    html = f"""<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<style>
  @page {{ size: A4 landscape; margin: 12mm 10mm; }}
  * {{ box-sizing: border-box; margin: 0; padding: 0; }}
  body {{ font-family: 'DejaVu Sans', Arial, sans-serif; font-size: 9pt; color: #111; }}
  .page-border {{ border: 1.5pt solid #111; padding: 8px; min-height: 97%; }}

  /* HEADER */
  .header {{ display: flex; justify-content: space-between; border-bottom: 1pt solid #333; padding-bottom: 6px; margin-bottom: 6px; }}
  .company-name {{ font-size: 14pt; font-weight: bold; text-transform: uppercase; letter-spacing: 0.5px; }}
  .company-meta {{ font-size: 7.5pt; color: #444; margin-top: 2px; }}
  .doc-title {{ text-align: right; }}
  .doc-title h1 {{ font-size: 13pt; font-weight: bold; text-transform: uppercase; letter-spacing: 1px; color: #1a237e; }}
  .doc-title .doc-meta {{ font-size: 8pt; color: #555; margin-top: 3px; }}

  /* INFO BLOCKS */
  .info-grid {{ display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 0; border: 1pt solid #ccc; margin-bottom: 6px; }}
  .info-block {{ padding: 5px 7px; border-right: 1pt solid #ccc; }}
  .info-block:last-child {{ border-right: none; }}
  .info-block h4 {{ font-size: 7pt; font-weight: bold; text-transform: uppercase; color: #1a237e;
                    border-bottom: 0.5pt solid #ccc; padding-bottom: 2px; margin-bottom: 3px; }}
  .info-row {{ display: flex; gap: 4px; margin-bottom: 2px; font-size: 8pt; }}
  .info-label {{ color: #555; min-width: 80px; flex-shrink: 0; }}
  .info-val {{ font-weight: 500; word-break: break-all; }}

  /* ITEMS TABLE */
  table {{ width: 100%; border-collapse: collapse; font-size: 8pt; margin-bottom: 6px; }}
  thead tr th {{
    background: #1a237e; color: #fff; padding: 4px 5px;
    text-align: center; font-size: 7.5pt; font-weight: bold;
    border: 0.5pt solid #1a237e;
  }}
  tbody tr td {{ padding: 3px 5px; border: 0.5pt solid #ccc; }}
  tbody tr:nth-child(even) {{ background: #f5f5f5; }}
  .totals-row td {{ background: #e8eaf6; font-weight: bold; border-top: 1pt solid #555; }}
  .center {{ text-align: center; }}
  .right {{ text-align: right; }}

  /* FOOTER */
  .footer {{ display: grid; grid-template-columns: 2fr 1fr; gap: 10px; border-top: 1pt solid #ccc; padding-top: 6px; margin-top: 4px; }}
  .declaration {{ font-size: 7.5pt; color: #444; line-height: 1.5; }}
  .signatory {{ text-align: center; }}
  .signatory .sig-box {{ border-top: 1pt solid #333; margin-top: 30px; padding-top: 3px; font-size: 8pt; font-weight: bold; }}
</style>
</head>
<body>
<div class="page-border">

  <!-- HEADER -->
  <div class="header">
    <div>
      <div class="company-name">{company.name}</div>
      <div class="company-meta">
        {company.address_line1}{', ' + company.address_line2 if company.address_line2 else ''}<br>
        {company.city}{', ' + company.state if company.state else ''} – {company.pincode} | India<br>
        GSTIN: {_s(plant.gstin)} &nbsp;|&nbsp; IE Code: {_s(invoice.ie_code)} &nbsp;|&nbsp; LUT No: {_s(invoice.lut_number)}
      </div>
    </div>
    <div class="doc-title">
      <h1>Packing List</h1>
      <div class="doc-meta">
        Invoice No: <strong>{invoice.invoice_number}</strong><br>
        Date: <strong>{invoice.invoice_date.strftime('%d-%b-%Y')}</strong><br>
        {'SO No: <strong>' + (invoice.sales_order.so_number if invoice.sales_order else '—') + '</strong>'}
      </div>
    </div>
  </div>

  <!-- INFO BLOCKS -->
  <div class="info-grid">
    <!-- Exporter -->
    <div class="info-block">
      <h4>Exporter / Shipper</h4>
      <div class="info-row"><span class="info-label">Name:</span><span class="info-val">{company.name}</span></div>
      <div class="info-row"><span class="info-label">Address:</span><span class="info-val">{company.address_line1}{', ' + company.address_line2 if company.address_line2 else ''}, {company.city} – {company.pincode}</span></div>
      <div class="info-row"><span class="info-label">GSTIN:</span><span class="info-val">{_s(plant.gstin)}</span></div>
    </div>
    <!-- Consignee -->
    <div class="info-block">
      <h4>Consignee</h4>
      <div class="info-row"><span class="info-label">Name:</span><span class="info-val">{customer.name}</span></div>
      <div class="info-row"><span class="info-label">Address:</span><span class="info-val">{customer.address_line1}{', ' + customer.address_line2 if customer.address_line2 else ''}, {customer.city}</span></div>
      <div class="info-row"><span class="info-label">Country:</span><span class="info-val">{_s(customer.country)}</span></div>
      <div class="info-row"><span class="info-label">GSTIN:</span><span class="info-val">{invoice.customer_gstin or _s(customer.gstin)}</span></div>
    </div>
    <!-- Shipment -->
    <div class="info-block">
      <h4>Shipment Details</h4>
      <div class="info-row"><span class="info-label">Port of Loading:</span><span class="info-val">{_s(invoice.port_of_loading)}</span></div>
      <div class="info-row"><span class="info-label">Port of Discharge:</span><span class="info-val">{_s(invoice.port_of_discharge)}</span></div>
      <div class="info-row"><span class="info-label">Container No:</span><span class="info-val">{_s(invoice.container_number)}</span></div>
      <div class="info-row"><span class="info-label">Seal No:</span><span class="info-val">{_s(invoice.seal_number)}</span></div>
      <div class="info-row"><span class="info-label">Incoterms:</span><span class="info-val">{_s(invoice.incoterms)}</span></div>
      <div class="info-row"><span class="info-label">Currency:</span><span class="info-val">{currency} @ ₹{_d(exchange_rate, 4)}</span></div>
    </div>
  </div>

  <!-- ITEMS TABLE -->
  <table>
    <thead>
      <tr>
        <th style="width:30px;">Sl No</th>
        <th style="width:80px;">Cust Part No</th>
        <th>Description</th>
        <th style="width:50px;">HSN</th>
        <th style="width:50px;">Qty</th>
        <th style="width:35px;">Unit</th>
        <th style="width:60px;">Gross Wt (kg)</th>
        <th style="width:60px;">Net Wt (kg)</th>
        <th style="width:70px;">Unit Price ({currency})</th>
        <th style="width:70px;">Amt ({currency})</th>
        <th style="width:70px;">Amt (INR ₹)</th>
      </tr>
    </thead>
    <tbody>
      {rows_html}
      <tr class="totals-row">
        <td colspan="4" class="right">TOTAL</td>
        <td class="right">{_d(total_qty, 2)}</td>
        <td></td>
        <td class="right">{_d(total_gross_wt, 3)}</td>
        <td class="right">{_d(total_net_wt, 3)}</td>
        <td></td>
        <td class="right">{_d(total_fcy, 2)}</td>
        <td class="right">{_d(total_inr, 2)}</td>
      </tr>
    </tbody>
  </table>

  <!-- FOOTER -->
  <div class="footer">
    <div class="declaration">
      <strong>Declaration:</strong><br>
      We hereby declare that the goods described above are in accordance with the contract/purchase order
      and that the particulars given in this packing list are true and correct. The export of goods under
      LUT No. <strong>{_s(invoice.lut_number)}</strong> is in compliance with GST Rules 96A and we
      undertake to pay the IGST on the export value if the goods are not exported within the stipulated
      time frame.{' | Nepal/Bhutan INR Export — No IGST levied.' if invoice.nepal_bhutan_export else ''}
      <br><br>
      <strong>Total Packages:</strong> {invoice.no_of_packages or '—'} &nbsp;|&nbsp;
      <strong>Gross Weight:</strong> {_d(inv_gross, 3)} kg &nbsp;|&nbsp;
      <strong>Net Weight:</strong> {_d(inv_net, 3)} kg
    </div>
    <div class="signatory">
      <div style="font-size:8pt; color:#555;">For and on behalf of</div>
      <div style="font-size:9pt; font-weight:bold; margin-top:3px;">{company.name}</div>
      <div class="sig-box">Authorised Signatory</div>
    </div>
  </div>

</div>
</body>
</html>"""

    # ── Render via WeasyPrint ──────────────────────────────────────
    from weasyprint import HTML as WeasyHTML
    return WeasyHTML(string=html).write_pdf()



# ═══════════════════════════════════════════════════════════════════
# BUG-024 fix: MATERIAL READINESS SERVICE
# ═══════════════════════════════════════════════════════════════════

def update_material_ready_status(so: SalesOrder) -> bool:
    """
    Check if all BOM materials are in stock for this SO.
    Sets material_ready=True if all components available, clears if stock consumed.
    Called daily by check_material_readiness Celery task.
    """
    from apps.stores.models import InventoryLot
    from apps.production.models import ProductionBOMHeader
    from django.db.models import Sum

    all_ready = True
    for so_line in so.lines.all():
        item = so_line.item
        if not item:
            all_ready = False
            break
        bom = ProductionBOMHeader.objects.filter(
            finished_good=item, plant=so.plant, status="ACTIVE"
        ).prefetch_related("lines__component").first()
        if not bom:
            all_ready = False
            break
        for bom_line in bom.lines.all():
            req = bom_line.qty_per_base * so_line.ordered_qty
            avail = InventoryLot.objects.filter(
                item=bom_line.component, plant=so.plant,
                qc_status="PASSED", status__in=("AVAILABLE", "RESERVED"),
            ).aggregate(total=Sum("current_qty"))["total"] or Decimal("0")
            if avail < req:
                all_ready = False
                break
        if not all_ready:
            break

    if all_ready and not so.material_ready:
        # Newly ready - set flag and fire notification once
        so.material_ready = True
        so.material_ready_at = timezone.now()
        so.save(update_fields=["material_ready", "material_ready_at"])
        _notify_material_ready(so)
    elif not all_ready and so.material_ready:
        # Stock subsequently consumed - reset flag so dispatch cannot proceed on stale flag
        so.material_ready = False
        so.material_ready_at = None
        so.material_ready_notified = False
        so.save(update_fields=["material_ready", "material_ready_at", "material_ready_notified"])

    return all_ready


def _notify_material_ready(so: SalesOrder):
    """Fire a single notification when SO first becomes material-ready."""
    if so.material_ready_notified:
        return  # Guard: notify exactly once per readiness event
    recipient = so.salesman or so.created_by
    if recipient:
        Notification.objects.create(
            user=recipient,
            title=f"Materials Ready: {so.so_number}",
            message=(
                f"All BOM materials are available for {so.so_number} "
                f"({so.customer.name}). Ready for production/despatch."
            ),
            module="sales",
            resource="SalesOrder",
            resource_id=so.pk,
        )
    so.material_ready_notified = True
    so.save(update_fields=["material_ready_notified"])

# ─────────────────────────────────────────────────────────────────
# BOM-based Quotation Cost Builder
# ─────────────────────────────────────────────────────────────────

def build_quotation_cost(item, plant, qty, profit_pct=None):
    """
    Calculate suggested selling price for a finished good item.

    Logic:
      1. Explode BOM → get all RM components and qty_per_base
      2. For each component, get average unit_cost from recent QC-passed InventoryLots
      3. Sum RM cost per finished unit
      4. Add conversion cost: planned_hours × work_center cost_per_hour (if routing exists)
      5. Apply profit margin
      6. Return full breakdown dict

    Returns dict with rm_breakdown, suggested_rate, and warnings.
    """
    from apps.production.models import ProductionBOMHeader
    from apps.stores.models import InventoryLot
    from django.db.models import Avg
    from decimal import Decimal, ROUND_HALF_UP

    if profit_pct is None:
        profit_pct = Decimal("15")
    else:
        profit_pct = Decimal(str(profit_pct))

    result = {
        "item_code": item.code,
        "item_name": item.name,
        "qty": str(qty),
        "rm_breakdown": [],
        "rm_cost_per_unit": Decimal("0"),
        "conversion_cost_per_unit": Decimal("0"),
        "total_cost_per_unit": Decimal("0"),
        "profit_pct": str(profit_pct),
        "suggested_rate": Decimal("0"),
        "bom_found": False,
        "warning": None,
    }

    bom = ProductionBOMHeader.objects.filter(
        finished_good=item,
        plant=plant,
        status="ACTIVE",
    ).prefetch_related("lines__component").first()

    if not bom:
        result["warning"] = f"No active BOM found for {item.code}. Enter rate manually."
        return result

    result["bom_found"] = True
    rm_cost_total = Decimal("0")

    for bom_line in bom.lines.all():
        component = bom_line.component
        qty_needed = bom_line.qty_per_base

        avg_cost_raw = InventoryLot.objects.filter(
            item=component,
            plant=plant,
            qc_status="PASSED",
        ).aggregate(avg=Avg("unit_cost"))["avg"]

        if avg_cost_raw is None:
            avg_cost = Decimal("0")
            warn = f"No cost data for RM: {component.code}"
        else:
            avg_cost = Decimal(str(avg_cost_raw))
            warn = None

        line_cost = qty_needed * avg_cost
        rm_cost_total += line_cost

        result["rm_breakdown"].append({
            "component_code": component.code,
            "component_name": component.name,
            "qty_per_unit": str(qty_needed),
            "avg_rm_cost": str(avg_cost.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)),
            "line_cost": str(line_cost.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)),
            "warning": warn,
        })

    result["rm_cost_per_unit"] = rm_cost_total.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)

    # Conversion cost from BOM routing (if lines have planned_hours + work_center)
    conversion_cost = Decimal("0")
    for bom_line in bom.lines.all():
        planned_h = getattr(bom_line, "planned_hours", None)
        wc = getattr(bom_line, "work_center", None)
        if planned_h and wc:
            conversion_cost += Decimal(str(planned_h)) * Decimal(str(wc.cost_per_hour))
    result["conversion_cost_per_unit"] = conversion_cost.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)

    total_cost = result["rm_cost_per_unit"] + result["conversion_cost_per_unit"]
    result["total_cost_per_unit"] = total_cost
    margin = profit_pct / Decimal("100")
    suggested = total_cost * (1 + margin)
    result["suggested_rate"] = suggested.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)

    return result
