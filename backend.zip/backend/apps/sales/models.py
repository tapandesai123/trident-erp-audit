"""
Sales Module Models — Section 5
Full pipeline:
  CRM: Enquiry → Followup → Sample
  Quotation → Revision → Approval → Proforma Invoice
  Artwork Approval
  Sales Order → SOLine → Schedule
  Despatch (DC) → DespatchLine
  Invoice → InvoiceLine  (IRN / e-way bill fields for Webtel)
  Gate Out Entry (Android scan on truck exit)
  Invoice Reach Record (POD upload)
  Customer Complaint → CAPA
"""
import uuid
from decimal import Decimal
from django.conf import settings
from django.db import models
from django.utils import timezone
from apps.core.models import TimeStampedModel, UUIDModel, Plant


# ══════════════════════════════════════════════════════════════════
# CRM — ENQUIRY & FOLLOWUP
# ══════════════════════════════════════════════════════════════════

class Enquiry(UUIDModel, TimeStampedModel):
    """Pre-sales enquiry from any channel."""

    class EnquirySource(models.TextChoices):
        WALK_IN      = "WALK_IN",      "Walk-In"
        PHONE        = "PHONE",        "Phone Call"
        EMAIL        = "EMAIL",        "Email"
        EXHIBITION   = "EXHIBITION",   "Exhibition / Trade Show"
        REFERRAL     = "REFERRAL",     "Referral"
        ECOMMERCE    = "ECOMMERCE",    "E-Commerce Portal"
        SALESMAN     = "SALESMAN",     "Salesman Visit"
        WHATSAPP     = "WHATSAPP",     "WhatsApp"
        WEBSITE      = "WEBSITE",      "Website"

    class EnquiryStatus(models.TextChoices):
        OPEN        = "OPEN",       "Open"
        FOLLOWUP    = "FOLLOWUP",   "Follow-Up Scheduled"
        SAMPLE_SENT = "SAMPLE_SENT","Sample Sent"
        QUOTED      = "QUOTED",     "Quoted"
        CONVERTED   = "CONVERTED",  "Converted to Order"
        LOST        = "LOST",       "Lost"
        CANCELLED   = "CANCELLED",  "Cancelled"

    plant           = models.ForeignKey(Plant, on_delete=models.CASCADE, related_name="enquiries")
    enquiry_number  = models.CharField(max_length=50, unique=True)
    enquiry_date    = models.DateField()
    source          = models.CharField(max_length=30, choices=EnquirySource.choices)
    status          = models.CharField(max_length=20, choices=EnquiryStatus.choices,
                                        default=EnquiryStatus.OPEN)

    # Customer (may be a prospect not yet in masters)
    customer        = models.ForeignKey("masters.Customer", on_delete=models.SET_NULL,
                                         null=True, blank=True, related_name="enquiries")
    prospect_name   = models.CharField(max_length=200, blank=True,
                                        help_text="If customer not yet in system")
    prospect_phone  = models.CharField(max_length=20, blank=True)
    prospect_email  = models.EmailField(blank=True)
    contact_person  = models.CharField(max_length=100, blank=True)

    # Product interest
    product_description = models.TextField(help_text="What box/product they need")
    estimated_qty_per_month = models.DecimalField(max_digits=15, decimal_places=2,
                                                   null=True, blank=True)
    target_price    = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)

    # Assignment
    assigned_to     = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
                                         null=True, blank=True, related_name="assigned_enquiries")
    next_followup_date = models.DateField(null=True, blank=True)
    remarks         = models.TextField(blank=True)

    # Converted to
    quotation       = models.ForeignKey("Quotation", on_delete=models.SET_NULL,
                                         null=True, blank=True, related_name="from_enquiries")

    class Meta:
        ordering = ["-enquiry_date", "-created_at"]
        verbose_name_plural = "Enquiries"

    def __str__(self):
        name = self.customer.name if self.customer else self.prospect_name
        return f"{self.enquiry_number} — {name}"


class EnquiryFollowup(TimeStampedModel):
    """Log of all follow-up actions on an enquiry."""

    class FollowupType(models.TextChoices):
        CALL    = "CALL",    "Phone Call"
        EMAIL   = "EMAIL",   "Email"
        VISIT   = "VISIT",   "Physical Visit"
        WHATSAPP = "WHATSAPP","WhatsApp"
        SAMPLE  = "SAMPLE",  "Sample Sent"
        MEETING = "MEETING", "Meeting"

    enquiry     = models.ForeignKey(Enquiry, on_delete=models.CASCADE, related_name="followups")
    followup_date = models.DateField()
    followup_type = models.CharField(max_length=20, choices=FollowupType.choices)
    done_by     = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
                                     null=True, related_name="enquiry_followups")
    summary     = models.TextField()
    outcome     = models.CharField(max_length=200, blank=True)
    next_action = models.TextField(blank=True)
    next_date   = models.DateField(null=True, blank=True)

    class Meta:
        ordering = ["-followup_date"]

    def __str__(self):
        return f"{self.enquiry.enquiry_number} / {self.followup_type} / {self.followup_date}"


# ══════════════════════════════════════════════════════════════════
# QUOTATION
# ══════════════════════════════════════════════════════════════════

class Quotation(UUIDModel, TimeStampedModel):
    """
    1-page quotation without box specs (commercial only).
    Supports revisions. Links to SO on conversion.
    """
    class QuotationStatus(models.TextChoices):
        DRAFT      = "DRAFT",     "Draft"
        PENDING    = "PENDING",   "Pending Approval"
        APPROVED   = "APPROVED",  "Approved"
        SENT       = "SENT",      "Sent to Customer"
        REVISED    = "REVISED",   "Revised"
        CONVERTED  = "CONVERTED", "Converted to Order"
        REJECTED   = "REJECTED",  "Rejected"
        EXPIRED    = "EXPIRED",   "Expired"

    plant            = models.ForeignKey(Plant, on_delete=models.CASCADE, related_name="quotations")
    quotation_number = models.CharField(max_length=50, unique=True)
    quotation_date   = models.DateField()
    valid_until      = models.DateField(null=True, blank=True)
    status           = models.CharField(max_length=20, choices=QuotationStatus.choices,
                                         default=QuotationStatus.DRAFT)
    revision         = models.PositiveIntegerField(default=0,
                                                    help_text="0 = original, 1+ = revision number")
    parent_quotation = models.ForeignKey("self", on_delete=models.SET_NULL,
                                          null=True, blank=True, related_name="revisions",
                                          help_text="Previous revision this supersedes")

    customer         = models.ForeignKey("masters.Customer", on_delete=models.PROTECT,
                                          related_name="quotations")
    ship_to          = models.ForeignKey("masters.CustomerShipAddress", on_delete=models.SET_NULL,
                                          null=True, blank=True)
    price_list       = models.ForeignKey("masters.PriceList", on_delete=models.SET_NULL,
                                          null=True, blank=True)

    # Financials
    currency         = models.CharField(max_length=5, default="INR")
    discount_pct     = models.DecimalField(max_digits=6, decimal_places=2, default=0)
    payment_terms    = models.CharField(max_length=200, blank=True)
    delivery_terms   = models.CharField(max_length=200, blank=True)

    # Totals (auto-calculated)
    subtotal         = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    discount_amount  = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    taxable_amount   = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    cgst_amount      = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    sgst_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0)  # BUG-033 fix: was max_digits=10
    igst_amount      = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    total_amount     = models.DecimalField(max_digits=15, decimal_places=2, default=0)

    prepared_by      = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
                                          null=True, related_name="quotations_prepared")
    approved_by      = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
                                          null=True, blank=True, related_name="quotations_approved")
    approved_at      = models.DateTimeField(null=True, blank=True)
    sent_at          = models.DateTimeField(null=True, blank=True)
    remarks          = models.TextField(blank=True)
    terms_conditions = models.TextField(blank=True)

    class Meta:
        ordering = ["-quotation_date", "-created_at"]

    def __str__(self):
        return f"{self.quotation_number} Rev{self.revision} — {self.customer.name}"


class QuotationLine(models.Model):
    """One line per product/item in quotation."""
    quotation    = models.ForeignKey(Quotation, on_delete=models.CASCADE, related_name="lines")
    line_no      = models.PositiveIntegerField(default=1)
    item         = models.ForeignKey("masters.Item", on_delete=models.PROTECT,
                                      null=True, blank=True)
    description  = models.CharField(max_length=500, help_text="Custom description if item not in masters")
    hsn_code     = models.CharField(max_length=10, blank=True)
    qty          = models.DecimalField(max_digits=15, decimal_places=2)
    uom          = models.ForeignKey("masters.UOM", on_delete=models.PROTECT, null=True, blank=True)
    unit_rate    = models.DecimalField(max_digits=12, decimal_places=4)
    discount_pct = models.DecimalField(max_digits=6, decimal_places=2, default=0)
    taxable_amt  = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    gst_pct      = models.DecimalField(max_digits=5, decimal_places=2, default=18)
    cgst_pct     = models.DecimalField(max_digits=5, decimal_places=2, default=9)
    sgst_pct     = models.DecimalField(max_digits=5, decimal_places=2, default=9)
    igst_pct     = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    gst_amount   = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    line_total   = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    remarks      = models.CharField(max_length=300, blank=True)

    # Cost builder fields (optional — filled when using BOM cost calculator)
    rm_cost_per_unit    = models.DecimalField(
        max_digits=12, decimal_places=4, default=0,
        help_text="Raw material cost per unit based on BOM + current RM prices",
    )
    conversion_cost     = models.DecimalField(
        max_digits=12, decimal_places=4, default=0,
        help_text="Labour + machine cost per unit",
    )
    profit_pct          = models.DecimalField(
        max_digits=6, decimal_places=2, default=0,
        help_text="Profit margin % applied to arrive at selling price",
    )
    cost_based_rate     = models.DecimalField(
        max_digits=12, decimal_places=4, default=0,
        help_text="System-suggested rate = (rm_cost + conversion_cost) × (1 + profit_pct/100)",
    )
    cost_builder_used   = models.BooleanField(
        default=False,
        help_text="True when cost builder was used to generate this line rate",
    )

    class Meta:
        ordering = ["line_no"]

    def __str__(self):
        return f"Q#{self.quotation.quotation_number} L{self.line_no}"


# ══════════════════════════════════════════════════════════════════
# ARTWORK APPROVAL
# ══════════════════════════════════════════════════════════════════

class ArtworkApproval(UUIDModel, TimeStampedModel):
    """
    Packaging artwork workflow:
    Designer uploads → Boss approves → Customer reviews → Approved/Rejected
    """
    class ArtworkStatus(models.TextChoices):
        PENDING_DESIGN    = "PENDING_DESIGN",    "Pending Design"
        PENDING_INTERNAL  = "PENDING_INTERNAL",  "Pending Internal Approval"
        SENT_TO_CUSTOMER  = "SENT_TO_CUSTOMER",  "Sent to Customer"
        CUSTOMER_APPROVED = "CUSTOMER_APPROVED", "Customer Approved"
        CUSTOMER_REJECTED = "CUSTOMER_REJECTED", "Customer Rejected — Rework"
        APPROVED          = "APPROVED",          "Final Approved"

    plant           = models.ForeignKey(Plant, on_delete=models.CASCADE, related_name="artworks")
    artwork_number  = models.CharField(max_length=50, unique=True)
    customer        = models.ForeignKey("masters.Customer", on_delete=models.PROTECT,
                                         related_name="artworks")
    product_name    = models.CharField(max_length=200)
    status          = models.CharField(max_length=30, choices=ArtworkStatus.choices,
                                        default=ArtworkStatus.PENDING_DESIGN)

    assigned_designer = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
                                           null=True, blank=True, related_name="artwork_designs")
    internal_approver = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
                                           null=True, blank=True, related_name="artwork_approvals")

    artwork_file     = models.FileField(upload_to="artworks/", null=True, blank=True)
    version          = models.PositiveIntegerField(default=1)
    customer_email_sent_at = models.DateTimeField(null=True, blank=True)
    customer_remarks = models.TextField(blank=True)
    internal_remarks = models.TextField(blank=True)
    approved_at      = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.artwork_number} — {self.customer.name} v{self.version}"


# ══════════════════════════════════════════════════════════════════
# SALES ORDER
# ══════════════════════════════════════════════════════════════════

class SalesOrder(UUIDModel, TimeStampedModel):
    """
    Confirmed sales order. Links to production planning.
    Customer portal can enter new orders / schedules.
    """
    class SOStatus(models.TextChoices):
        DRAFT       = "DRAFT",       "Draft"
        CONFIRMED   = "CONFIRMED",   "Confirmed"
        IN_PRODUCTION = "IN_PRODUCTION", "In Production"
        READY       = "READY",       "Ready to Despatch"
        PARTIALLY_DESPATCHED = "PARTIALLY_DESPATCHED", "Partially Despatched"
        FULLY_DESPATCHED = "FULLY_DESPATCHED", "Fully Despatched"
        INVOICED    = "INVOICED",    "Fully Invoiced"
        CANCELLED   = "CANCELLED",   "Cancelled"
        ON_HOLD     = "ON_HOLD",     "On Hold"

    class SOType(models.TextChoices):
        REGULAR     = "REGULAR",     "Regular Order"
        REPEAT      = "REPEAT",      "Repeat Order"
        BLANKET     = "BLANKET",     "Blanket Order"
        SAMPLE      = "SAMPLE",      "Sample Order"
        EXPORT      = "EXPORT",      "Export Order"

    plant          = models.ForeignKey(Plant, on_delete=models.CASCADE, related_name="sales_orders")
    so_number      = models.CharField(max_length=50, unique=True)
    so_date        = models.DateField()
    so_type        = models.CharField(max_length=20, choices=SOType.choices, default=SOType.REGULAR)
    status         = models.CharField(max_length=30, choices=SOStatus.choices, default=SOStatus.DRAFT)

    customer       = models.ForeignKey("masters.Customer", on_delete=models.PROTECT,
                                        related_name="sales_orders")
    ship_to        = models.ForeignKey("masters.CustomerShipAddress", on_delete=models.SET_NULL,
                                        null=True, blank=True, related_name="sales_orders")
    customer_po_number = models.CharField(max_length=100, blank=True,
                                           help_text="Customer's own PO reference")
    customer_po_date   = models.DateField(null=True, blank=True)

    # From quotation (if applicable)
    quotation      = models.ForeignKey(Quotation, on_delete=models.SET_NULL,
                                        null=True, blank=True, related_name="sales_orders")

    # Delivery
    required_delivery_date = models.DateField(null=True, blank=True)
    payment_terms  = models.CharField(max_length=200, blank=True)
    delivery_terms = models.CharField(max_length=200, blank=True)
    transporter    = models.CharField(max_length=200, blank=True)

    # Financials
    currency       = models.CharField(max_length=5, default="INR")
    price_list     = models.ForeignKey("masters.PriceList", on_delete=models.SET_NULL,
                                        null=True, blank=True)
    discount_pct   = models.DecimalField(max_digits=6, decimal_places=2, default=0)
    subtotal       = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    discount_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    taxable_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    cgst_amount    = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    sgst_amount    = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    igst_amount    = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    total_amount   = models.DecimalField(max_digits=15, decimal_places=2, default=0)

    # Artwork
    artwork        = models.ForeignKey(ArtworkApproval, on_delete=models.SET_NULL,
                                        null=True, blank=True, related_name="sales_orders")

    # Hierarchy (salesman)
    salesman       = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
                                        null=True, blank=True, related_name="sales_orders_owned")
    created_by     = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
                                        null=True, related_name="sales_orders_created")
    remarks        = models.TextField(blank=True)
    internal_notes = models.TextField(blank=True)
    portal_source  = models.CharField(
        max_length=30, blank=True, default="",
        help_text="Set to PORTAL when order created via customer portal",
    )

    # Material availability tracking
    material_ready          = models.BooleanField(
        default=False,
        help_text="True when all BOM materials are available in QC-passed stock",
    )
    material_ready_notified = models.BooleanField(
        default=False,
        help_text="True when production team has been notified of material availability",
    )
    material_ready_at       = models.DateTimeField(
        null=True, blank=True,
        help_text="Timestamp when material became fully available",
    )

    class Meta:
        ordering = ["-so_date", "-created_at"]
        indexes = [
            models.Index(fields=["required_delivery_date"], name="sales_so_delivery_date_idx"),
            models.Index(fields=["status", "so_date"], name="sales_so_status_date_idx"),
        ]

    def __str__(self):
        return f"{self.so_number} — {self.customer.name}"


class SOLine(models.Model):
    """One line per product in the sales order."""
    so           = models.ForeignKey(SalesOrder, on_delete=models.CASCADE, related_name="lines")
    line_no      = models.PositiveIntegerField(default=1)
    item         = models.ForeignKey("masters.Item", on_delete=models.PROTECT,
                                      null=True, blank=True)
    description  = models.CharField(max_length=500)
    hsn_code     = models.CharField(max_length=10, blank=True)

    # Quantities
    ordered_qty  = models.DecimalField(max_digits=15, decimal_places=2)
    uom          = models.ForeignKey("masters.UOM", on_delete=models.PROTECT, null=True, blank=True)
    despatched_qty = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    invoiced_qty = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    cancelled_qty = models.DecimalField(max_digits=15, decimal_places=2, default=0)

    # Pricing
    unit_rate    = models.DecimalField(max_digits=12, decimal_places=4)
    discount_pct = models.DecimalField(max_digits=6, decimal_places=2, default=0)
    taxable_amt  = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    gst_pct      = models.DecimalField(max_digits=5, decimal_places=2, default=18)
    cgst_pct     = models.DecimalField(max_digits=5, decimal_places=2, default=9)
    sgst_pct     = models.DecimalField(max_digits=5, decimal_places=2, default=9)
    igst_pct     = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    gst_amount   = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    line_total   = models.DecimalField(max_digits=15, decimal_places=2, default=0)

    # Production link
    required_date = models.DateField(null=True, blank=True)
    remarks       = models.CharField(max_length=300, blank=True)

    @property
    def pending_qty(self):
        return max(self.ordered_qty - self.despatched_qty - self.cancelled_qty, Decimal("0"))

    class Meta:
        ordering = ["line_no"]

    def __str__(self):
        return f"{self.so.so_number} L{self.line_no}"


class SOSchedule(models.Model):
    """
    Delivery schedule for a SO line — customer specifies
    how many to deliver on which date.
    """
    so_line      = models.ForeignKey(SOLine, on_delete=models.CASCADE, related_name="schedules")
    schedule_date = models.DateField()
    scheduled_qty = models.DecimalField(max_digits=15, decimal_places=2)
    despatched_qty = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    remarks       = models.CharField(max_length=200, blank=True)
    entered_by    = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
                                       null=True, blank=True)
    entered_at    = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["schedule_date"]

    def __str__(self):
        return f"{self.so_line} / {self.schedule_date} / {self.scheduled_qty}"


# ══════════════════════════════════════════════════════════════════
# DESPATCH (DELIVERY CHALLAN)
# ══════════════════════════════════════════════════════════════════

class Despatch(UUIDModel, TimeStampedModel):
    """
    Delivery challan / despatch note.
    Barcode on DC scanned at gate-out by Android app.
    Auto-email sent to customer + marketing on gate-out.
    """
    class DespatchStatus(models.TextChoices):
        DRAFT       = "DRAFT",      "Draft"
        READY       = "READY",      "Ready"
        GATE_OUT    = "GATE_OUT",   "Gate Out"
        DELIVERED   = "DELIVERED",  "Delivered"
        CANCELLED   = "CANCELLED",  "Cancelled"

    plant           = models.ForeignKey(Plant, on_delete=models.CASCADE, related_name="despatches")
    dc_number       = models.CharField(max_length=50, unique=True)
    dc_date         = models.DateField()
    status          = models.CharField(max_length=20, choices=DespatchStatus.choices,
                                        default=DespatchStatus.DRAFT)

    sales_order     = models.ForeignKey(SalesOrder, on_delete=models.PROTECT,
                                         related_name="despatches")
    customer        = models.ForeignKey("masters.Customer", on_delete=models.PROTECT,
                                         related_name="despatches")
    ship_to         = models.ForeignKey("masters.CustomerShipAddress", on_delete=models.SET_NULL,
                                         null=True, blank=True)

    # Transport
    transporter_name = models.CharField(max_length=200, blank=True)
    vehicle_number   = models.CharField(max_length=30, blank=True)
    lr_number        = models.CharField(max_length=100, blank=True,
                                         help_text="Lorry Receipt number")
    lr_date          = models.DateField(null=True, blank=True)
    driver_name      = models.CharField(max_length=100, blank=True)
    driver_phone     = models.CharField(max_length=20, blank=True)
    no_of_packages   = models.PositiveIntegerField(default=0)
    gross_weight_kg  = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)

    # Gate-out (scanned by Android at factory gate)
    gate_out_time    = models.DateTimeField(null=True, blank=True)
    gate_out_by      = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
                                          null=True, blank=True, related_name="gate_outs")
    gate_out_qr_scan = models.TextField(blank=True)

    # Auto-email tracking
    customer_email_sent  = models.BooleanField(default=False)
    marketing_email_sent = models.BooleanField(default=False)

    # Barcode / QR for gate-out scanning
    barcode_data     = models.CharField(max_length=200, blank=True)

    prepared_by      = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
                                          null=True, related_name="despatches_prepared")
    remarks          = models.TextField(blank=True)

    class Meta:
        ordering = ["-dc_date", "-created_at"]

    def __str__(self):
        return f"{self.dc_number} — {self.customer.name}"


class DespatchLine(models.Model):
    """One line per SO line item despatched."""
    despatch     = models.ForeignKey(Despatch, on_delete=models.CASCADE, related_name="lines")
    so_line      = models.ForeignKey(SOLine, on_delete=models.PROTECT, related_name="despatch_lines")
    item         = models.ForeignKey("masters.Item", on_delete=models.PROTECT,
                                      null=True, blank=True)
    description  = models.CharField(max_length=500)
    despatched_qty = models.DecimalField(max_digits=15, decimal_places=2)
    uom          = models.ForeignKey("masters.UOM", on_delete=models.PROTECT, null=True, blank=True)
    unit_rate    = models.DecimalField(max_digits=12, decimal_places=4, default=0)
    batch_number = models.CharField(max_length=100, blank=True)
    remarks      = models.CharField(max_length=300, blank=True)

    def __str__(self):
        return f"{self.despatch.dc_number} / {self.item}"


# ══════════════════════════════════════════════════════════════════
# INVOICE
# ══════════════════════════════════════════════════════════════════

class Invoice(UUIDModel, TimeStampedModel):
    """
    Tax invoice. IRN + e-way bill fields for Webtel integration.
    Barcode on invoice scanned at gate-out (prevents duplicate invoices).
    """
    class InvoiceType(models.TextChoices):
        TAX_INVOICE   = "TAX_INVOICE",  "Tax Invoice"
        PROFORMA      = "PROFORMA",     "Proforma Invoice"
        DEBIT_NOTE    = "DEBIT_NOTE",   "Debit Note"
        CREDIT_NOTE   = "CREDIT_NOTE",  "Credit Note"
        EXPORT        = "EXPORT",       "Export Invoice"

    class InvoiceStatus(models.TextChoices):
        DRAFT       = "DRAFT",      "Draft"
        CONFIRMED   = "CONFIRMED",  "Confirmed"
        IRN_PENDING = "IRN_PENDING","IRN Pending"
        IRN_DONE    = "IRN_DONE",   "IRN Generated"
        PAYMENT_PENDING = "PAYMENT_PENDING", "Payment Pending"
        PARTIALLY_PAID  = "PARTIALLY_PAID",  "Partially Paid"
        PAID        = "PAID",       "Fully Paid"
        CANCELLED   = "CANCELLED",  "Cancelled"

    plant            = models.ForeignKey(Plant, on_delete=models.CASCADE, related_name="invoices")
    invoice_number   = models.CharField(max_length=50, unique=True)
    invoice_date     = models.DateField()
    invoice_type     = models.CharField(max_length=20, choices=InvoiceType.choices,
                                         default=InvoiceType.TAX_INVOICE)
    status           = models.CharField(max_length=20, choices=InvoiceStatus.choices,
                                         default=InvoiceStatus.DRAFT)

    # Customer & Order
    customer         = models.ForeignKey("masters.Customer", on_delete=models.PROTECT,
                                          related_name="invoices")
    ship_to          = models.ForeignKey("masters.CustomerShipAddress", on_delete=models.SET_NULL,
                                          null=True, blank=True, related_name="invoices")
    sales_order      = models.ForeignKey(SalesOrder, on_delete=models.SET_NULL,
                                          null=True, blank=True, related_name="invoices")
    despatch         = models.ForeignKey(Despatch, on_delete=models.SET_NULL,
                                          null=True, blank=True, related_name="invoices")

    # GST details
    place_of_supply  = models.CharField(max_length=50, blank=True,
                                         help_text="State code for GST determination")
    is_interstate    = models.BooleanField(default=False,
                                           help_text="True = IGST; False = CGST+SGST")
    reverse_charge   = models.BooleanField(default=False)
    customer_gstin   = models.CharField(max_length=15, blank=True)

    # Financials
    currency         = models.CharField(max_length=5, default="INR")
    subtotal         = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    discount_amount  = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    taxable_amount   = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    cgst_amount      = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    sgst_amount      = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    igst_amount      = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    tcs_pct          = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    tcs_amount       = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    round_off        = models.DecimalField(max_digits=8, decimal_places=2, default=0)
    total_amount     = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    amount_in_words  = models.CharField(max_length=500, blank=True)

    # Payments
    amount_paid      = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    outstanding_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    due_date         = models.DateField(null=True, blank=True)

    # Webtel / IRN / e-Way Bill
    irn              = models.CharField(max_length=100, blank=True,
                                         help_text="Invoice Reference Number from IRP")
    irn_generated_at = models.DateTimeField(null=True, blank=True)
    ack_number       = models.CharField(max_length=100, blank=True)
    ack_date         = models.DateTimeField(null=True, blank=True)
    qr_code_irn      = models.TextField(blank=True, help_text="QR code data from IRP")
    eway_bill_number = models.CharField(max_length=20, blank=True)
    eway_bill_date   = models.DateField(null=True, blank=True)
    eway_bill_valid_until = models.DateField(null=True, blank=True)

    # Transport (from despatch)
    transporter_name = models.CharField(max_length=200, blank=True)
    vehicle_number   = models.CharField(max_length=30, blank=True)
    lr_number        = models.CharField(max_length=100, blank=True)

    # ── Export-specific fields ────────────────────────────────────
    port_of_loading        = models.CharField(max_length=100, blank=True)
    port_of_discharge      = models.CharField(max_length=100, blank=True)
    port_code              = models.CharField(max_length=20, blank=True,
                                               help_text="ICEGATE port code for customs")
    shipping_bill_no       = models.CharField(max_length=50, blank=True)
    shipping_bill_date     = models.DateField(null=True, blank=True)
    lut_number             = models.CharField(max_length=50, blank=True,
                                               help_text="Letter of Undertaking number (zero-rated GST)")
    ie_code                = models.CharField(max_length=20, blank=True,
                                               help_text="Importer Exporter Code")
    lc_number              = models.CharField(max_length=100, blank=True,
                                               help_text="Letter of Credit number")
    bank_name              = models.CharField(max_length=200, blank=True,
                                               help_text="Bank for foreign remittance")
    bank_swift_code        = models.CharField(max_length=20, blank=True)
    container_number       = models.CharField(max_length=50, blank=True)
    container_size         = models.CharField(max_length=20, blank=True,
                                               help_text="e.g., 20FT, 40FT, 40HC")
    seal_number            = models.CharField(max_length=50, blank=True)
    net_weight_kg          = models.DecimalField(max_digits=12, decimal_places=3, null=True, blank=True)
    gross_weight_kg        = models.DecimalField(max_digits=12, decimal_places=3, null=True, blank=True)
    no_of_packages         = models.PositiveIntegerField(null=True, blank=True)
    country_of_destination = models.CharField(max_length=100, blank=True)
    incoterms              = models.CharField(max_length=20, blank=True,
                                               help_text="e.g., FOB, CIF, EXW")
    foreign_currency       = models.CharField(max_length=5, blank=True)
    foreign_amount         = models.DecimalField(max_digits=15, decimal_places=2, null=True, blank=True)
    exchange_rate          = models.DecimalField(max_digits=10, decimal_places=4, null=True, blank=True)
    nepal_bhutan_export    = models.BooleanField(default=False,
                                                  help_text="True for Nepal/Bhutan INR settlement exports")
    export_currency        = models.CharField(
        max_length=3, default="USD", blank=True,
        choices=[("USD", "USD"), ("EUR", "EUR"), ("GBP", "GBP"), ("AED", "AED"), ("INR", "INR")],
        help_text="Foreign currency for export invoices",
    )

    # Gate-out barcode
    barcode_data     = models.CharField(max_length=200, blank=True)
    gate_out_time    = models.DateTimeField(null=True, blank=True)

    # Debit/Credit note reference
    original_invoice = models.ForeignKey("self", on_delete=models.SET_NULL,
                                          null=True, blank=True, related_name="credit_debit_notes")
    dn_cn_reason     = models.TextField(blank=True)

    prepared_by      = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
                                          null=True, related_name="invoices_prepared")
    remarks          = models.TextField(blank=True)

    class Meta:
        ordering = ["-invoice_date", "-created_at"]
        indexes = [
            models.Index(fields=["invoice_date"], name="sales_invoice_date_idx"),
            models.Index(fields=["customer", "invoice_date"], name="sales_inv_cust_date_idx"),
            models.Index(fields=["status"], name="sales_invoice_status_idx"),
        ]

    def __str__(self):
        return f"{self.invoice_number} — {self.customer.name} — ₹{self.total_amount}"

    @property
    def is_export(self) -> bool:
        """True when this is an export invoice (regular export or Nepal/Bhutan)."""
        return self.invoice_type in (
            self.InvoiceType.EXPORT,
        ) or self.nepal_bhutan_export


class InvoiceLine(models.Model):
    """One line per item in invoice."""
    invoice      = models.ForeignKey(Invoice, on_delete=models.CASCADE, related_name="lines")
    line_no      = models.PositiveIntegerField(default=1)
    so_line      = models.ForeignKey(SOLine, on_delete=models.SET_NULL,
                                      null=True, blank=True, related_name="invoice_lines")
    item         = models.ForeignKey("masters.Item", on_delete=models.PROTECT,
                                      null=True, blank=True)
    description  = models.CharField(max_length=500)
    hsn_code     = models.CharField(max_length=10, blank=True)
    qty          = models.DecimalField(max_digits=15, decimal_places=2)
    uom          = models.ForeignKey("masters.UOM", on_delete=models.PROTECT, null=True, blank=True)
    unit_rate    = models.DecimalField(max_digits=12, decimal_places=4)
    discount_pct = models.DecimalField(max_digits=6, decimal_places=2, default=0)
    taxable_amt  = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    gst_pct      = models.DecimalField(max_digits=5, decimal_places=2, default=18)
    cgst_pct     = models.DecimalField(max_digits=5, decimal_places=2, default=9)
    sgst_pct     = models.DecimalField(max_digits=5, decimal_places=2, default=9)
    igst_pct     = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    cgst_amount  = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    sgst_amount  = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    igst_amount  = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    line_total   = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    batch_number = models.CharField(max_length=100, blank=True)

    class Meta:
        ordering = ["line_no"]

    def __str__(self):
        return f"{self.invoice.invoice_number} L{self.line_no}"


# ══════════════════════════════════════════════════════════════════
# INVOICE REACH RECORD (POD)
# ══════════════════════════════════════════════════════════════════

class InvoiceReachRecord(TimeStampedModel):
    """
    Tracks whether goods actually reached the customer.
    Customer's gate entry number, date, POD upload.
    Reduces transit loss risk.
    """
    invoice          = models.OneToOneField(Invoice, on_delete=models.CASCADE,
                                             related_name="reach_record")
    customer_ge_number = models.CharField(max_length=100, blank=True,
                                           help_text="Customer's inward gate entry number")
    customer_ge_date = models.DateField(null=True, blank=True)
    pod_document     = models.FileField(upload_to="pod_documents/", null=True, blank=True,
                                         help_text="Proof of Delivery scan/photo")
    received_by_customer = models.CharField(max_length=100, blank=True)
    remarks          = models.TextField(blank=True)
    recorded_by      = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
                                          null=True, related_name="pod_records")

    def __str__(self):
        return f"POD: {self.invoice.invoice_number}"


# ══════════════════════════════════════════════════════════════════
# CUSTOMER COMPLAINT & CAPA
# ══════════════════════════════════════════════════════════════════

class CustomerComplaint(UUIDModel, TimeStampedModel):
    """
    Customer complaints logged by sales / customer service.
    Routed to quality/marketing/production for resolution.
    """
    class ComplaintStatus(models.TextChoices):
        OPEN        = "OPEN",       "Open"
        UNDER_REVIEW = "UNDER_REVIEW","Under Review"
        ACTION_TAKEN = "ACTION_TAKEN","Action Taken"
        RESOLVED    = "RESOLVED",   "Resolved"
        CLOSED      = "CLOSED",     "Closed"
        ESCALATED   = "ESCALATED",  "Escalated"

    class ComplaintCategory(models.TextChoices):
        QUALITY     = "QUALITY",    "Quality Issue"
        DELIVERY    = "DELIVERY",   "Delivery Delay"
        QUANTITY    = "QUANTITY",   "Wrong Quantity"
        BILLING     = "BILLING",    "Billing Error"
        PACKAGING   = "PACKAGING",  "Packaging Damage"
        OTHER       = "OTHER",      "Other"

    plant              = models.ForeignKey(Plant, on_delete=models.CASCADE,
                                            related_name="customer_complaints")
    complaint_number   = models.CharField(max_length=50, unique=True)
    complaint_date     = models.DateField()
    status             = models.CharField(max_length=20, choices=ComplaintStatus.choices,
                                           default=ComplaintStatus.OPEN)
    category           = models.CharField(max_length=20, choices=ComplaintCategory.choices)

    customer           = models.ForeignKey("masters.Customer", on_delete=models.PROTECT,
                                            related_name="complaints")
    invoice            = models.ForeignKey(Invoice, on_delete=models.SET_NULL,
                                            null=True, blank=True, related_name="complaints")
    sales_order        = models.ForeignKey(SalesOrder, on_delete=models.SET_NULL,
                                            null=True, blank=True, related_name="complaints")

    complaint_details  = models.TextField()
    customer_contact   = models.CharField(max_length=100, blank=True)
    photo_evidence     = models.FileField(upload_to="complaint_photos/", null=True, blank=True)

    # Assignment
    assigned_to        = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
                                            null=True, blank=True, related_name="complaints_assigned")
    logged_by          = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
                                            null=True, related_name="complaints_logged")

    # Resolution
    root_cause         = models.TextField(blank=True)
    corrective_action  = models.TextField(blank=True)
    preventive_action  = models.TextField(blank=True)
    resolved_at        = models.DateTimeField(null=True, blank=True)
    resolved_by        = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
                                            null=True, blank=True, related_name="complaints_resolved")
    customer_satisfied = models.BooleanField(null=True, blank=True)
    satisfaction_remarks = models.TextField(blank=True)

    class Meta:
        ordering = ["-complaint_date", "-created_at"]

    def __str__(self):
        return f"{self.complaint_number} — {self.customer.name} ({self.status})"
