"""Sales Module Celery Tasks."""
from celery import shared_task
from django.utils import timezone
from datetime import timedelta
from django.db.models import Sum, Count, Q


@shared_task(name="sales.check_quotation_expiry")
def check_quotation_expiry():
    """
    Daily: Mark quotations past valid_until date as EXPIRED.
    """
    from apps.sales.models import Quotation
    
    today = timezone.now().date()
    
    # Find quotations that are:
    # - Status is SENT (sent to customer)
    # - valid_until date has passed
    expired = Quotation.objects.filter(
        status=Quotation.QuotationStatus.SENT,
        valid_until__lt=today
    ).update(status=Quotation.QuotationStatus.EXPIRED)
    
    return f"Marked {expired} quotations as EXPIRED."


@shared_task(name="sales.send_so_delivery_reminders")
def send_so_delivery_reminders():
    """
    Daily: Find SOs past delivery_date not fully dispatched.
    Notify sales team about delayed deliveries.
    """
    from apps.sales.models import SalesOrder
    from apps.core.models import Notification, User
    
    today = timezone.now().date()
    
    # Find sales orders that are:
    # - Status is CONFIRMED or IN_PRODUCTION or PARTIALLY_DISPATCHED
    # - delivery_date has passed
    # - Not fully dispatched
    overdue_sos = SalesOrder.objects.filter(
        status__in=[
            SalesOrder.SOStatus.CONFIRMED,
            SalesOrder.SOStatus.IN_PRODUCTION,
            SalesOrder.SOStatus.PARTIALLY_DESPATCHED  # BUG-022 fix
        ],
        required_delivery_date__lt=today  # BUG-022 fix
    ).select_related('customer', 'plant', 'salesman')  # BUG-022 fix
    
    if not overdue_sos.exists():
        return "No overdue sales orders found."
    
    # Get sales team (users with sales-related roles)
    try:
        from apps.core.models import Role
        sales_roles = Role.objects.filter(
            name__icontains='Sales'
        )
        
        if sales_roles.exists():
            sales_users = User.objects.filter(
                roles__in=sales_roles,
                is_active=True
            ).distinct()
        else:
            # Fallback to staff users
            sales_users = User.objects.filter(is_staff=True, is_active=True)
    except:
        sales_users = User.objects.filter(is_staff=True, is_active=True)
    
    # Create notifications
    count = 0
    for so in overdue_sos[:50]:  # Limit to 50 SOs per run
        days_overdue = (today - so.required_delivery_date).days  # BUG-022 fix
        
        # Notify salesperson if assigned
        recipients = []
        if so.salesman:  # BUG-022 fix
            recipients.append(so.salesman)
        
        # Also notify sales managers
        recipients.extend(sales_users)
        
        for user in set(recipients):  # Remove duplicates
            Notification.objects.create(
                user=user,
                title=f"Overdue SO: {so.so_number}",
                message=f"Sales order {so.so_number} for {so.customer.name} is overdue by {days_overdue} days. "
                        f"Expected delivery: {so.required_delivery_date}. Status: {so.get_status_display()}",
                notification_type="IN_APP",
                module="sales",
                resource="SalesOrder",
                resource_id=so.id,
            )
            count += 1
    
    return f"Sent {count} overdue SO notifications for {overdue_sos.count()} orders."


@shared_task(name="sales.weekly_sales_summary")
def weekly_sales_summary():
    """
    Weekly: Email sales pipeline summary.
    Runs Monday at 9:00 AM.
    """
    from apps.sales.models import Enquiry, Quotation, SalesOrder, Invoice
    from apps.core.models import Notification, User
    from decimal import Decimal
    
    # Get date range for last week
    today = timezone.now().date()
    week_start = today - timedelta(days=7)
    
    # Enquiry Summary
    enquiries_created = Enquiry.objects.filter(
        created_at__date__gte=week_start
    ).count()
    
    enquiries_converted = Enquiry.objects.filter(
        status=Enquiry.EnquiryStatus.CONVERTED,
        updated_at__date__gte=week_start
    ).count()
    
    enquiries_lost = Enquiry.objects.filter(
        status=Enquiry.EnquiryStatus.LOST,
        updated_at__date__gte=week_start
    ).count()
    
    # Quotation Summary
    quotations_sent = Quotation.objects.filter(
        status=Quotation.QuotationStatus.SENT,
        updated_at__date__gte=week_start
    ).count()
    
    quotations_accepted = Quotation.objects.filter(
        status=Quotation.QuotationStatus.APPROVED,  # BUG-023 fix
        updated_at__date__gte=week_start
    ).count()
    
    # Sales Order Summary
    so_created = SalesOrder.objects.filter(
        created_at__date__gte=week_start
    ).count()
    
    so_value = SalesOrder.objects.filter(
        created_at__date__gte=week_start
    ).aggregate(total=Sum('total_amount'))['total'] or Decimal('0.00')  # BUG-023 fix
    
    # Invoice Summary
    invoices_created = Invoice.objects.filter(
        created_at__date__gte=week_start
    ).count()
    
    invoice_value = Invoice.objects.filter(
        created_at__date__gte=week_start
    ).aggregate(total=Sum('total_amount'))['total'] or Decimal('0.00')  # BUG-023 fix
    
    # Pipeline Summary
    open_enquiries = Enquiry.objects.filter(
        status__in=[
            Enquiry.EnquiryStatus.OPEN,
            Enquiry.EnquiryStatus.FOLLOWUP,
            Enquiry.EnquiryStatus.SAMPLE_SENT
        ]
    ).count()
    
    pending_quotations = Quotation.objects.filter(
        status__in=[
            Quotation.QuotationStatus.DRAFT,
            Quotation.QuotationStatus.PENDING,  # BUG-023 fix
            Quotation.QuotationStatus.SENT
        ]
    ).count()
    
    active_orders = SalesOrder.objects.filter(
        status__in=[
            SalesOrder.SOStatus.CONFIRMED,
            SalesOrder.SOStatus.IN_PRODUCTION,
            SalesOrder.SOStatus.PARTIALLY_DESPATCHED  # BUG-023 fix
        ]
    ).count()
    
    # Create summary message
    summary = f"""
Weekly Sales Summary (Last 7 days):

Enquiries:
- New: {enquiries_created}
- Converted: {enquiries_converted}
- Lost: {enquiries_lost}
- Open in Pipeline: {open_enquiries}

Quotations:
- Sent to Customers: {quotations_sent}
- Accepted: {quotations_accepted}
- Pending: {pending_quotations}

Sales Orders:
- New Orders: {so_created}
- Order Value: ₹{so_value:,.2f}
- Active Orders: {active_orders}

Invoices:
- Created: {invoices_created}
- Invoice Value: ₹{invoice_value:,.2f}

This is an automated weekly summary.
    """.strip()
    
    # Send to sales team
    sales_users = User.objects.filter(
        Q(is_staff=True) | Q(userrole__role__name__icontains='Sales'),
        is_active=True
    ).distinct()
    
    count = 0
    for user in sales_users:
        Notification.objects.create(
            user=user,
            title="Weekly Sales Summary",
            message=summary,
            notification_type="IN_APP",
            module="sales",
            resource="Summary",
            resource_id=0,
        )
        count += 1
    
    return f"Sent weekly sales summary to {count} users."


# ── BUG-024 fix: Material readiness check task ──────────────────────────────

@shared_task(name="sales.check_material_readiness")
def check_material_readiness():
    """
    Daily: check if all BOM materials are available for confirmed SOs.
    Sets or clears material_ready flag via update_material_ready_status service.
    """
    from apps.sales.models import SalesOrder
    from apps.sales.services import update_material_ready_status
    from apps.core.models import Plant

    updated = 0
    for plant in Plant.objects.filter(is_active=True):
        sos = SalesOrder.objects.filter(
            plant=plant,
            status__in=[SalesOrder.SOStatus.CONFIRMED, SalesOrder.SOStatus.IN_PRODUCTION],
        )
        for so in sos:
            update_material_ready_status(so)
            updated += 1

    return f"Checked material readiness for {updated} sales orders."
