"""Sales Module Admin — Section 5"""
from django.contrib import admin
from apps.sales.models import (
    Enquiry, EnquiryFollowup,
    Quotation, QuotationLine,
    ArtworkApproval,
    SalesOrder, SOLine, SOSchedule,
    Despatch, DespatchLine,
    Invoice, InvoiceLine,
    InvoiceReachRecord,
    CustomerComplaint,
)


class EnquiryFollowupInline(admin.TabularInline):
    model = EnquiryFollowup
    extra = 0


@admin.register(Enquiry)
class EnquiryAdmin(admin.ModelAdmin):
    list_display  = ["enquiry_number","enquiry_date","customer","prospect_name",
                     "source","status","assigned_to","next_followup_date"]
    list_filter   = ["status","source","plant"]
    search_fields = ["enquiry_number","customer__name","prospect_name"]
    inlines       = [EnquiryFollowupInline]


class QuotationLineInline(admin.TabularInline):
    model = QuotationLine
    extra = 0


@admin.register(Quotation)
class QuotationAdmin(admin.ModelAdmin):
    list_display  = ["quotation_number","revision","quotation_date","customer","status","total_amount"]
    list_filter   = ["status","plant"]
    search_fields = ["quotation_number","customer__name"]
    inlines       = [QuotationLineInline]


@admin.register(ArtworkApproval)
class ArtworkAdmin(admin.ModelAdmin):
    list_display  = ["artwork_number","customer","product_name","status","version","assigned_designer"]
    list_filter   = ["status","plant"]


class SOLineInline(admin.TabularInline):
    model = SOLine
    extra = 0
    readonly_fields = ["despatched_qty","invoiced_qty"]


@admin.register(SalesOrder)
class SalesOrderAdmin(admin.ModelAdmin):
    list_display  = ["so_number","so_date","customer","so_type","status","total_amount","salesman"]
    list_filter   = ["status","so_type","plant"]
    search_fields = ["so_number","customer__name","customer_po_number"]
    inlines       = [SOLineInline]


class DespatchLineInline(admin.TabularInline):
    model = DespatchLine
    extra = 0


@admin.register(Despatch)
class DespatchAdmin(admin.ModelAdmin):
    list_display  = ["dc_number","dc_date","customer","status","vehicle_number","gate_out_time"]
    list_filter   = ["status","plant"]
    search_fields = ["dc_number","customer__name","vehicle_number","lr_number"]
    inlines       = [DespatchLineInline]


class InvoiceLineInline(admin.TabularInline):
    model = InvoiceLine
    extra = 0
    readonly_fields = ["taxable_amt","cgst_amount","sgst_amount","igst_amount","line_total"]


@admin.register(Invoice)
class InvoiceAdmin(admin.ModelAdmin):
    list_display  = ["invoice_number","invoice_date","customer","invoice_type","status",
                     "total_amount","outstanding_amount","irn","eway_bill_number"]
    list_filter   = ["status","invoice_type","is_interstate","plant"]
    search_fields = ["invoice_number","customer__name","irn","eway_bill_number"]
    inlines       = [InvoiceLineInline]


@admin.register(CustomerComplaint)
class ComplaintAdmin(admin.ModelAdmin):
    list_display  = ["complaint_number","complaint_date","customer","category","status","assigned_to"]
    list_filter   = ["status","category","plant"]
    search_fields = ["complaint_number","customer__name"]
