# BUG-033 fix: Quotation.sgst_amount max_digits was 10, corrected to 15
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('sales', '0002_salesorder_material_ready_quotationline_cost_fields'),
    ]

    operations = [
        migrations.AlterField(
            model_name='quotation',
            name='sgst_amount',
            field=models.DecimalField(
                max_digits=15,
                decimal_places=2,
                default=0,
                help_text='BUG-033 fix: was max_digits=10, now 15 to match all other tax amount fields'
            ),
        ),
    ]
