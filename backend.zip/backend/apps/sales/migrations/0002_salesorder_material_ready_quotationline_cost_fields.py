"""
Migration: P1 + P3
  - Add material_ready fields to SalesOrder
  - Add cost builder fields to QuotationLine
"""
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('sales', '0001_initial'),
    ]

    operations = [
        # P1 — SalesOrder material readiness fields
        migrations.AddField(
            model_name='salesorder',
            name='material_ready',
            field=models.BooleanField(default=False, help_text='True when all BOM materials are available in QC-passed stock'),
        ),
        migrations.AddField(
            model_name='salesorder',
            name='material_ready_notified',
            field=models.BooleanField(default=False, help_text='True when production team has been notified of material availability'),
        ),
        migrations.AddField(
            model_name='salesorder',
            name='material_ready_at',
            field=models.DateTimeField(blank=True, help_text='Timestamp when material became fully available', null=True),
        ),
        # P3 — QuotationLine cost builder fields
        migrations.AddField(
            model_name='quotationline',
            name='rm_cost_per_unit',
            field=models.DecimalField(decimal_places=4, default=0, help_text='Raw material cost per unit based on BOM + current RM prices', max_digits=12),
        ),
        migrations.AddField(
            model_name='quotationline',
            name='conversion_cost',
            field=models.DecimalField(decimal_places=4, default=0, help_text='Labour + machine cost per unit', max_digits=12),
        ),
        migrations.AddField(
            model_name='quotationline',
            name='profit_pct',
            field=models.DecimalField(decimal_places=2, default=0, help_text='Profit margin % applied to arrive at selling price', max_digits=6),
        ),
        migrations.AddField(
            model_name='quotationline',
            name='cost_based_rate',
            field=models.DecimalField(decimal_places=4, default=0, help_text='System-suggested rate = (rm_cost + conversion_cost) x (1 + profit_pct/100)', max_digits=12),
        ),
        migrations.AddField(
            model_name='quotationline',
            name='cost_builder_used',
            field=models.BooleanField(default=False, help_text='True when cost builder was used to generate this line rate'),
        ),
    ]
