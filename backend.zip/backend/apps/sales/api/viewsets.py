"""Sales Module ViewSets — Section 5"""
from rest_framework import viewsets, status, filters
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django_filters.rest_framework import DjangoFilterBackend
from django.utils import timezone

from apps.sales.models import (
    Enquiry, Quotation, ArtworkApproval,
    SalesOrder, SOLine, SOSchedule,
    Despatch, Invoice, InvoiceReachRecord,
    CustomerComplaint,
)
from apps.sales.api.serializers import (
    EnquiryListSerializer, EnquiryDetailSerializer,
    EnquiryFollowupSerializer,
    QuotationListSerializer, QuotationDetailSerializer, QuotationCreateSerializer,
    ArtworkApprovalSerializer,
    SOListSerializer, SODetailSerializer, SOCreateSerializer,
    SOScheduleSerializer,
    DespatchListSerializer, DespatchDetailSerializer, DespatchCreateSerializer,
    GateOutSerializer,
    InvoiceListSerializer, InvoiceDetailSerializer, InvoiceCreateSerializer,
    InvoiceReachSerializer,
    ComplaintListSerializer, ComplaintDetailSerializer,
)
from apps.sales import services


# ── Enquiry ──────────────────────────────────────────────────────

class EnquiryViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    filter_backends    = [filters.SearchFilter, DjangoFilterBackend, filters.OrderingFilter]
    search_fields      = ["enquiry_number", "prospect_name", "customer__name", "contact_person"]
    filterset_fields   = ["status", "source", "assigned_to", "plant"]
    ordering           = ["-enquiry_date"]

    def get_queryset(self):
        # BUG-026 fix: filter by user's plant to prevent cross-plant data exposure
        plant = getattr(self.request.user, 'plant', None)
        return Enquiry.objects.filter(plant=plant).select_related(
            "customer", "assigned_to", "quotation"
        ).prefetch_related("followups")

    def get_serializer_class(self):
        return EnquiryDetailSerializer if self.action == "retrieve" else EnquiryListSerializer

    def create(self, request, *args, **kwargs):
        enquiry = services.create_enquiry(request.data, request.user, request.user.plant)
        return Response(EnquiryDetailSerializer(enquiry).data, status=201)

    @action(detail=True, methods=["post"])
    def add_followup(self, request, pk=None):
        enquiry  = self.get_object()
        followup = services.add_followup(enquiry, request.data, request.user)
        return Response(EnquiryFollowupSerializer(followup).data, status=201)

    @action(detail=True, methods=["post"])
    def mark_lost(self, request, pk=None):
        enq = self.get_object()
        enq.status = Enquiry.EnquiryStatus.LOST
        enq.remarks = request.data.get("remarks", enq.remarks)
        enq.save(update_fields=["status", "remarks"])
        return Response({"status": "marked_lost"})

    @action(detail=False, methods=["get"])
    def due_followups(self, request):
        """Enquiries where next_followup_date <= today (overdue)."""
        from datetime import date
        qs = Enquiry.objects.filter(
            plant=request.user.plant,
            status__in=[Enquiry.EnquiryStatus.OPEN, Enquiry.EnquiryStatus.FOLLOWUP],
            next_followup_date__lte=date.today(),
        )
        return Response(EnquiryListSerializer(qs, many=True).data)


# ── Quotation ─────────────────────────────────────────────────────

class QuotationViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    filter_backends    = [filters.SearchFilter, DjangoFilterBackend]
    search_fields      = ["quotation_number", "customer__name"]
    filterset_fields   = ["status", "customer", "plant"]
    ordering           = ["-quotation_date"]

    def get_queryset(self):
        # BUG-026 fix: filter by user's plant
        plant = getattr(self.request.user, 'plant', None)
        return Quotation.objects.filter(plant=plant).select_related(
            "customer", "prepared_by", "approved_by"
        ).prefetch_related("lines")

    def get_serializer_class(self):
        if self.action in ["create", "update"]:
            return QuotationCreateSerializer
        return QuotationDetailSerializer if self.action == "retrieve" else QuotationListSerializer

    def create(self, request, *args, **kwargs):
        ser = QuotationCreateSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        from apps.masters.models import Customer
        customer = Customer.objects.get(pk=ser.validated_data["customer_id"])
        data = {**ser.validated_data, "customer": customer}
        lines = data.pop("lines")
        quot = services.create_quotation(data, lines, request.user, request.user.plant)
        return Response(QuotationDetailSerializer(quot).data, status=201)

    @action(detail=True, methods=["post"])
    def submit(self, request, pk=None):
        services.submit_quotation_for_approval(self.get_object(), request.user)
        return Response({"status": "submitted_for_approval"})

    @action(detail=True, methods=["post"])
    def approve(self, request, pk=None):
        services.approve_quotation(self.get_object(), request.user)
        return Response({"status": "approved"})

    @action(detail=True, methods=["post"])
    def revise(self, request, pk=None):
        ser = QuotationCreateSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        new_quot = services.revise_quotation(
            self.get_object(), ser.validated_data.pop("lines"), request.user
        )
        return Response(QuotationDetailSerializer(new_quot).data, status=201)

    @action(detail=True, methods=["get"])
    def convert_to_so(self, request, pk=None):
        """Preview data for converting this quotation to a SO."""
        quot = self.get_object()
        return Response({
            "customer_id":  quot.customer_id,
            "quotation_id": quot.pk,
            "lines": [
                {"item_id": l.item_id, "description": l.description,
                 "ordered_qty": l.qty, "unit_rate": l.unit_rate,
                 "gst_pct": l.gst_pct, "discount_pct": l.discount_pct}
                for l in quot.lines.all()
            ]
        })

    @action(detail=False, methods=["post"], url_path="cost-builder")
    def cost_builder(self, request):
        """
        POST /api/v1/sales/quotations/cost-builder/
        Body: { item_id, qty, profit_pct (optional, default 15) }
        Returns full BOM cost breakdown and suggested selling rate.
        """
        from apps.masters.models import Item
        from apps.sales.services import build_quotation_cost
        from decimal import Decimal

        item_id = request.data.get("item_id")
        qty = request.data.get("qty", 1)
        profit_pct = Decimal(str(request.data.get("profit_pct", 15)))

        if not item_id:
            return Response({"error": "item_id is required"}, status=status.HTTP_400_BAD_REQUEST)

        try:
            item = Item.objects.get(pk=item_id, item_type="FINISHED_GOOD")
        except Item.DoesNotExist:
            return Response({"error": "Item not found or not a finished good"}, status=status.HTTP_404_NOT_FOUND)

        plant = request.user.plant
        result = build_quotation_cost(item, plant, qty, profit_pct)
        # Convert Decimal values to string for JSON serialisation
        for key in ("rm_cost_per_unit", "conversion_cost_per_unit", "total_cost_per_unit", "suggested_rate"):
            if key in result:
                result[key] = str(result[key])
        return Response(result)


# ── Artwork ───────────────────────────────────────────────────────

class ArtworkApprovalViewSet(viewsets.ModelViewSet):
    serializer_class   = ArtworkApprovalSerializer
    permission_classes = [IsAuthenticated]
    filter_backends    = [filters.SearchFilter, DjangoFilterBackend]
    search_fields      = ["artwork_number", "customer__name", "product_name"]
    filterset_fields   = ["status", "customer", "plant"]

    def get_queryset(self):
        # BUG-026 fix: filter by user's plant
        plant = getattr(self.request.user, 'plant', None)
        return ArtworkApproval.objects.filter(plant=plant).select_related("customer", "assigned_designer")

    @action(detail=True, methods=["post"])
    def approve_internal(self, request, pk=None):
        artwork = self.get_object()
        artwork.status = ArtworkApproval.ArtworkStatus.SENT_TO_CUSTOMER
        artwork.internal_approver = request.user
        artwork.customer_email_sent_at = timezone.now()
        artwork.save(update_fields=["status", "internal_approver", "customer_email_sent_at"])
        return Response({"status": "sent_to_customer"})

    @action(detail=True, methods=["post"])
    def customer_approve(self, request, pk=None):
        # BUG-035 fix: verify caller is the customer linked to this artwork
        artwork = self.get_object()
        req_customer_id = getattr(request.user, 'customer_id', None)
        if req_customer_id and req_customer_id != artwork.customer_id:
            return Response(
                {"error": "You are not authorised to approve this artwork."},
                status=status.HTTP_403_FORBIDDEN,
            )
        artwork.status = ArtworkApproval.ArtworkStatus.APPROVED
        artwork.approved_at = timezone.now()
        artwork.customer_remarks = request.data.get("remarks", "")
        artwork.save(update_fields=["status", "approved_at", "customer_remarks"])
        return Response({"status": "customer_approved"})

    @action(detail=True, methods=["post"])
    def customer_reject(self, request, pk=None):
        # BUG-035 fix: verify caller is the customer linked to this artwork
        artwork = self.get_object()
        req_customer_id = getattr(request.user, 'customer_id', None)
        if req_customer_id and req_customer_id != artwork.customer_id:
            return Response(
                {"error": "You are not authorised to reject this artwork."},
                status=status.HTTP_403_FORBIDDEN,
            )
        artwork.status = ArtworkApproval.ArtworkStatus.CUSTOMER_REJECTED
        artwork.version += 1
        artwork.customer_remarks = request.data.get("remarks", "")
        artwork.save(update_fields=["status", "version", "customer_remarks"])
        return Response({"status": "rejected_rework_required"})


# ── Sales Order ───────────────────────────────────────────────────

class SalesOrderViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    filter_backends    = [filters.SearchFilter, DjangoFilterBackend, filters.OrderingFilter]
    search_fields      = ["so_number", "customer__name", "customer_po_number"]
    filterset_fields   = ["status", "so_type", "customer", "plant", "salesman"]
    ordering           = ["-so_date"]

    def get_queryset(self):
        # BUG-026 fix: filter by user's plant
        plant = getattr(self.request.user, 'plant', None)
        return SalesOrder.objects.filter(plant=plant).select_related(
            "customer", "ship_to", "quotation", "salesman"
        ).prefetch_related("lines__schedules")

    def get_serializer_class(self):
        if self.action == "create":
            return SOCreateSerializer
        return SODetailSerializer if self.action == "retrieve" else SOListSerializer

    def create(self, request, *args, **kwargs):
        ser = SOCreateSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        from apps.masters.models import Customer
        customer = Customer.objects.get(pk=ser.validated_data["customer_id"])
        data     = {**ser.validated_data, "customer": customer}
        lines    = data.pop("lines")
        so = services.create_sales_order(data, lines, request.user, request.user.plant)
        return Response(SODetailSerializer(so).data, status=201)

    @action(detail=True, methods=["post"])
    def add_schedule(self, request, pk=None):
        """Add a delivery schedule to a SO line."""
        so = self.get_object()
        so_line_id = request.data.get("so_line_id")
        try:
            so_line = so.lines.get(pk=so_line_id)
        except SOLine.DoesNotExist:
            return Response({"error": "SO line not found."}, status=404)
        schedule = SOSchedule.objects.create(
            so_line=so_line,
            schedule_date=request.data["schedule_date"],
            scheduled_qty=request.data["scheduled_qty"],
            remarks=request.data.get("remarks", ""),
            entered_by=request.user,
        )
        return Response(SOScheduleSerializer(schedule).data, status=201)

    @action(detail=True, methods=["post"])
    def cancel(self, request, pk=None):
        so = self.get_object()
        so.status = SalesOrder.SOStatus.CANCELLED
        so.internal_notes = request.data.get("reason", "")
        so.save(update_fields=["status", "internal_notes"])
        return Response({"status": "cancelled"})

    @action(detail=False, methods=["get"])
    def pending_order_position(self, request):
        """Daily report: orders vs despatch vs pending."""
        plant  = request.user.plant
        cust_id = request.query_params.get("customer_id")
        customer = None
        if cust_id:
            from apps.masters.models import Customer
            customer = Customer.objects.filter(pk=cust_id).first()
        data = services.get_pending_order_position(plant, customer)
        return Response(data)

    @action(detail=False, methods=["get"])
    def customer_portal(self, request):
        """
        Customer-facing view: their own orders, despatch status, pending.
        Filter by customer linked to current user.
        """
        customer_id = request.query_params.get("customer_id")
        qs = SalesOrder.objects.filter(
            plant=request.user.plant,
        )
        if customer_id:
            qs = qs.filter(customer_id=customer_id)
        return Response(SOListSerializer(qs, many=True).data)

    @action(detail=True, methods=["get"], url_path="material-status")
    def material_status(self, request, pk=None):
        """
        GET /api/v1/sales/orders/{id}/material-status/
        Returns BOM requirement vs available QC-passed stock for each component.
        """
        from django.db.models import Sum
        from decimal import Decimal
        from apps.stores.models import InventoryLot
        from apps.production.models import ProductionBOMHeader

        so = self.get_object()
        result = {
            "so_number": so.so_number,
            "customer": so.customer.name,
            "material_ready": so.material_ready,
            "material_ready_at": so.material_ready_at,
            "lines": [],
        }

        for so_line in so.lines.all():
            item = so_line.item
            if not item:
                continue
            bom = ProductionBOMHeader.objects.filter(
                finished_good=item, plant=so.plant, status="ACTIVE"
            ).prefetch_related("lines__component").first()
            if not bom:
                result["lines"].append({
                    "so_line": so_line.line_no,
                    "item": item.name,
                    "bom_found": False,
                    "components": [],
                })
                continue

            components = []
            all_ok = True
            for bom_line in bom.lines.all():
                req = bom_line.qty_per_base * so_line.ordered_qty  # BUG-028 fix: was so_line.quantity
                avail = InventoryLot.objects.filter(
                    item=bom_line.component, plant=so.plant,
                    qc_status="PASSED", status__in=("AVAILABLE", "RESERVED"),
                ).aggregate(total=Sum("current_qty"))["total"] or Decimal("0")
                ok = avail >= req
                if not ok:
                    all_ok = False
                components.append({
                    "component_code": bom_line.component.code,
                    "component_name": bom_line.component.name,
                    "required_qty": str(req),
                    "available_qty": str(avail),
                    "shortage": str(max(Decimal("0"), req - avail)),
                    "status": "OK" if ok else "SHORT",
                })
            result["lines"].append({
                "so_line": so_line.line_no,
                "item": item.name,
                "bom_found": True,
                "all_materials_ok": all_ok,
                "components": components,
            })

        return Response(result)


# ── Despatch ──────────────────────────────────────────────────────

class DespatchViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    filter_backends    = [filters.SearchFilter, DjangoFilterBackend, filters.OrderingFilter]
    search_fields      = ["dc_number", "customer__name", "vehicle_number", "lr_number"]
    filterset_fields   = ["status", "customer", "plant", "sales_order"]
    ordering           = ["-dc_date"]

    def get_queryset(self):
        # BUG-026 fix: filter by user's plant
        plant = getattr(self.request.user, 'plant', None)
        return Despatch.objects.filter(plant=plant).select_related(
            "customer", "ship_to", "sales_order", "prepared_by"
        ).prefetch_related("lines__item", "lines__so_line")

    def get_serializer_class(self):
        if self.action == "create":
            return DespatchCreateSerializer
        return DespatchDetailSerializer if self.action == "retrieve" else DespatchListSerializer

    def create(self, request, *args, **kwargs):
        ser = DespatchCreateSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        data  = ser.validated_data
        lines = data.pop("lines")
        try:
            dc = services.create_despatch(data, lines, request.user, request.user.plant)
            return Response(DespatchDetailSerializer(dc).data, status=201)
        except ValueError as e:
            return Response({"error": str(e)}, status=400)

    @action(detail=True, methods=["post"])
    def gate_out(self, request, pk=None):
        """Android gate guard scans barcode → records gate-out."""
        despatch = self.get_object()
        ser = GateOutSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        try:
            services.record_gate_out(
                despatch, request.user,
                ser.validated_data.get("qr_scan_data", "")
            )
            return Response({
                "status": "gate_out_recorded",
                "gate_out_time": despatch.gate_out_time,
                "dc_number": despatch.dc_number,
            })
        except ValueError as e:
            return Response({"error": str(e)}, status=400)

    @action(detail=False, methods=["get"])
    def pending_gate_out(self, request):
        """DCs that are ready but haven't been gate-out yet."""
        qs = Despatch.objects.filter(
            plant=request.user.plant,
            status=Despatch.DespatchStatus.READY,
        )
        return Response(DespatchListSerializer(qs, many=True).data)

    @action(detail=False, methods=["get"])
    def scan(self, request):
        """Gate-out QR/barcode scan lookup. ?barcode=DC/2026/00123"""
        barcode = request.query_params.get("barcode", "")
        try:
            dc = Despatch.objects.get(barcode_data=barcode)
            return Response(DespatchDetailSerializer(dc).data)
        except Despatch.DoesNotExist:
            return Response({"error": "DC not found for this barcode."}, status=404)


# ── Invoice ───────────────────────────────────────────────────────

class InvoiceViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    filter_backends    = [filters.SearchFilter, DjangoFilterBackend, filters.OrderingFilter]
    search_fields      = ["invoice_number", "customer__name", "irn", "eway_bill_number"]
    filterset_fields   = ["status", "invoice_type", "customer", "plant", "is_interstate"]
    ordering           = ["-invoice_date"]

    def get_queryset(self):
        # BUG-026 fix: filter by user's plant
        plant = getattr(self.request.user, 'plant', None)
        return Invoice.objects.filter(plant=plant).select_related(
            "customer", "ship_to", "sales_order", "despatch", "prepared_by"
        ).prefetch_related("lines__item", "lines__uom", "lines__so_line")

    def get_serializer_class(self):
        if self.action == "create":
            return InvoiceCreateSerializer
        return InvoiceDetailSerializer if self.action == "retrieve" else InvoiceListSerializer

    def create(self, request, *args, **kwargs):
        ser = InvoiceCreateSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        despatch = Despatch.objects.get(pk=ser.validated_data["despatch_id"])
        try:
            inv = services.create_invoice_from_despatch(
                despatch, ser.validated_data, request.user, request.user.plant
            )
            return Response(InvoiceDetailSerializer(inv).data, status=201)
        except Exception as e:
            return Response({"error": str(e)}, status=400)

    @action(detail=True, methods=["post"])
    def record_reach(self, request, pk=None):
        """Record customer gate entry (POD)."""
        invoice = self.get_object()
        reach = services.record_invoice_reach(invoice, request.data, request.user)
        return Response(InvoiceReachSerializer(reach).data)

    @action(detail=True, methods=["get"])
    def reach_status(self, request, pk=None):
        invoice = self.get_object()
        try:
            reach = invoice.reach_record
            return Response(InvoiceReachSerializer(reach).data)
        except InvoiceReachRecord.DoesNotExist:
            return Response({"reached": False, "message": "No POD recorded yet."})

    @action(detail=False, methods=["get"])
    def unreached(self, request):
        """Invoices despatched but POD not recorded — transit loss risk."""
        days = int(request.query_params.get("days", 30))
        invs = services.get_unreached_invoices(request.user.plant, days)
        return Response(InvoiceListSerializer(invs, many=True).data)

    @action(detail=False, methods=["get"])
    def invoices_yesterday(self, request):
        """Yesterday's invoices for auto-email report."""
        invs = services.get_invoices_yesterday(request.user.plant)
        return Response(InvoiceListSerializer(invs, many=True).data)

    @action(detail=True, methods=["get"], url_path="packing-list")
    def packing_list(self, request, pk=None):
        """
        Generate and return export packing list PDF.
        Only available for EXPORT invoice types.
        GET /api/v1/sales/invoices/{pk}/packing-list/
        """
        from django.http import HttpResponse
        invoice = self.get_object()
        if not invoice.is_export:
            return Response({"error": "Not an export invoice"}, status=400)
        try:
            pdf_bytes = services.generate_packing_list_pdf(invoice.pk)
        except Exception as exc:
            return Response({"error": f"PDF generation failed: {exc}"}, status=500)
        return HttpResponse(
            pdf_bytes,
            content_type="application/pdf",
            headers={
                "Content-Disposition": (
                    f'attachment; filename="PackingList_{invoice.invoice_number}.pdf"'
                )
            },
        )

    @action(detail=False, methods=["get"])
    def debtor_ageing(self, request):
        """Outstanding debtor ageing 0-30/31-60/61-90/90+."""
        buckets = services.get_debtor_ageing(request.user.plant)
        return Response({
            k: InvoiceListSerializer(v, many=True).data
            for k, v in buckets.items()
        })

    @action(detail=False, methods=["get"])
    def scan(self, request):
        """Invoice barcode scan lookup. ?barcode=INV/2026/00123"""
        barcode = request.query_params.get("barcode", "")
        try:
            inv = Invoice.objects.get(barcode_data=barcode)
            return Response(InvoiceDetailSerializer(inv).data)
        except Invoice.DoesNotExist:
            return Response({"error": "Invoice not found."}, status=404)

    @action(detail=True, methods=["post"])
    def irn_update(self, request, pk=None):
        """
        Called by Webtel integration to update IRN/ACK details.
        POST { irn, ack_number, ack_date, qr_code_irn }
        """
        inv = self.get_object()
        inv.irn              = request.data.get("irn", "")
        inv.ack_number       = request.data.get("ack_number", "")
        inv.qr_code_irn      = request.data.get("qr_code_irn", "")
        inv.irn_generated_at = timezone.now()
        inv.status           = Invoice.InvoiceStatus.IRN_DONE
        if request.data.get("ack_date"):
            inv.ack_date = request.data["ack_date"]
        inv.save()
        return Response({"status": "irn_updated", "irn": inv.irn})

    @action(detail=True, methods=["post"])
    def eway_bill_update(self, request, pk=None):
        """Update e-way bill details from Webtel."""
        inv = self.get_object()
        inv.eway_bill_number     = request.data.get("eway_bill_number", "")
        inv.eway_bill_date       = request.data.get("eway_bill_date")
        inv.eway_bill_valid_until = request.data.get("eway_bill_valid_until")
        inv.save(update_fields=["eway_bill_number","eway_bill_date","eway_bill_valid_until"])
        return Response({"status": "eway_bill_updated"})


# ── Customer Complaint ────────────────────────────────────────────

class CustomerComplaintViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    filter_backends    = [filters.SearchFilter, DjangoFilterBackend]
    search_fields      = ["complaint_number", "customer__name", "complaint_details"]
    filterset_fields   = ["status", "category", "customer", "plant", "assigned_to"]
    ordering           = ["-complaint_date"]

    def get_queryset(self):
        # BUG-026 fix: filter by user's plant
        plant = getattr(self.request.user, 'plant', None)
        return CustomerComplaint.objects.filter(plant=plant).select_related(
            "customer", "invoice", "assigned_to", "logged_by"
        )

    def get_serializer_class(self):
        return ComplaintDetailSerializer if self.action == "retrieve" else ComplaintListSerializer

    def create(self, request, *args, **kwargs):
        complaint = services.create_complaint(
            request.data, request.user, request.user.plant
        )
        return Response(ComplaintDetailSerializer(complaint).data, status=201)

    @action(detail=True, methods=["post"])
    def resolve(self, request, pk=None):
        comp = self.get_object()
        comp.root_cause        = request.data.get("root_cause", "")
        comp.corrective_action = request.data.get("corrective_action", "")
        comp.preventive_action = request.data.get("preventive_action", "")
        comp.status            = CustomerComplaint.ComplaintStatus.RESOLVED
        comp.resolved_at       = timezone.now()
        comp.resolved_by       = request.user
        comp.customer_satisfied = request.data.get("customer_satisfied")
        comp.satisfaction_remarks = request.data.get("satisfaction_remarks", "")
        comp.save()
        return Response({"status": "resolved"})

    @action(detail=False, methods=["get"])
    def open_list(self, request):
        """Untreated / open complaints list."""
        qs = CustomerComplaint.objects.filter(
            plant=request.user.plant,
            status__in=[
                CustomerComplaint.ComplaintStatus.OPEN,
                CustomerComplaint.ComplaintStatus.UNDER_REVIEW,
            ]
        )
        return Response(ComplaintListSerializer(qs, many=True).data)


# ── EDI Upload action added to SalesOrderViewSet ─────────────────
# (Monkey-patched here for non-invasive addition)

from rest_framework.parsers import MultiPartParser

@action(detail=False, methods=["post"], parser_classes=[MultiPartParser])
def edi_upload(self, request):
    """
    Upload customer PO Excel (Flipkart/Amazon format).
    Parses rows → creates SOs in DRAFT status for review.
    """
    file = request.FILES.get("file")
    if not file:
        return Response({"error": "No file uploaded"}, status=400)
    from apps.sales.services import parse_edi_excel
    plant = getattr(request, "plant", None) or getattr(request.user, "plant", None)
    result = parse_edi_excel(file, request.user, plant)
    return Response(result)


# Dynamically attach to SalesOrderViewSet
SalesOrderViewSet.edi_upload = edi_upload
