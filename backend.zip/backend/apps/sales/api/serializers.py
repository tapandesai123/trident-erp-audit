"""Sales Module Serializers — Section 5"""
from rest_framework import serializers
from apps.sales.models import (
    Enquiry, EnquiryFollowup,
    Quotation, QuotationLine,
    ArtworkApproval,
    SalesOrder, SOLine, SOSchedule,
    Despatch, DespatchLine,
    Invoice, InvoiceLine,
    InvoiceReachRecord,
    CustomerComplaint,
)


# ── Enquiry ──────────────────────────────────────────────────────

class EnquiryFollowupSerializer(serializers.ModelSerializer):
    done_by_name = serializers.CharField(source="done_by.get_full_name", read_only=True, default="")
    class Meta:
        model  = EnquiryFollowup
        fields = ["id","enquiry","followup_date","followup_type","done_by","done_by_name",
                  "summary","outcome","next_action","next_date","created_at"]


class EnquiryListSerializer(serializers.ModelSerializer):
    customer_name   = serializers.CharField(source="customer.name", read_only=True, default="")
    assigned_to_name = serializers.CharField(source="assigned_to.get_full_name", read_only=True, default="")
    class Meta:
        model  = Enquiry
        fields = ["id","uuid","enquiry_number","enquiry_date","source","status",
                  "customer","customer_name","prospect_name","contact_person",
                  "product_description","assigned_to","assigned_to_name","next_followup_date"]


class EnquiryDetailSerializer(serializers.ModelSerializer):
    followups    = EnquiryFollowupSerializer(many=True, read_only=True)
    customer_name = serializers.CharField(source="customer.name", read_only=True, default="")
    class Meta:
        model  = Enquiry
        fields = "__all__"


# ── Quotation ─────────────────────────────────────────────────────

class QuotationLineSerializer(serializers.ModelSerializer):
    item_code = serializers.CharField(source="item.code", read_only=True, default="")
    class Meta:
        model  = QuotationLine
        fields = ["id","line_no","item","item_code","description","hsn_code",
                  "qty","uom","unit_rate","discount_pct","taxable_amt",
                  "gst_pct","cgst_pct","sgst_pct","igst_pct","gst_amount","line_total","remarks",
                  "rm_cost_per_unit","conversion_cost","profit_pct","cost_based_rate","cost_builder_used"]


# BUG-034 fix: Portal-safe serializer excludes internal cost/margin fields
class QuotationLinePortalSerializer(serializers.ModelSerializer):
    """Safe for customer-portal consumption — omits cost, margin, and pricing fields."""
    item_code = serializers.CharField(source="item.code", read_only=True, default="")
    class Meta:
        model  = QuotationLine
        fields = ["id","line_no","item","item_code","description","hsn_code",
                  "qty","uom","unit_rate","discount_pct","taxable_amt",
                  "gst_pct","cgst_pct","sgst_pct","igst_pct","gst_amount","line_total","remarks"]
        # Excluded: rm_cost_per_unit, conversion_cost, profit_pct, cost_based_rate, cost_builder_used


class QuotationListSerializer(serializers.ModelSerializer):
    customer_name = serializers.CharField(source="customer.name", read_only=True)
    class Meta:
        model  = Quotation
        fields = ["id","uuid","quotation_number","quotation_date","revision",
                  "status","customer","customer_name","total_amount","valid_until","prepared_by"]


class QuotationDetailSerializer(serializers.ModelSerializer):
    lines         = QuotationLineSerializer(many=True, read_only=True)
    customer_name = serializers.CharField(source="customer.name", read_only=True)
    class Meta:
        model  = Quotation
        fields = "__all__"


class QuotationLineCreateSerializer(serializers.Serializer):
    item_id      = serializers.IntegerField(required=False, allow_null=True)
    description  = serializers.CharField(max_length=500)
    hsn_code     = serializers.CharField(required=False, allow_blank=True)
    qty          = serializers.DecimalField(max_digits=15, decimal_places=2)
    uom_id       = serializers.IntegerField(required=False, allow_null=True)
    unit_rate    = serializers.DecimalField(max_digits=12, decimal_places=4)
    discount_pct = serializers.DecimalField(max_digits=6, decimal_places=2, default=0)
    gst_pct      = serializers.DecimalField(max_digits=5, decimal_places=2, default=18)
    remarks      = serializers.CharField(required=False, allow_blank=True)


class QuotationCreateSerializer(serializers.Serializer):
    quotation_date  = serializers.DateField(required=False)
    valid_until     = serializers.DateField(required=False, allow_null=True)
    customer_id     = serializers.IntegerField()
    ship_to_id      = serializers.IntegerField(required=False, allow_null=True)
    price_list_id   = serializers.IntegerField(required=False, allow_null=True)
    discount_pct    = serializers.DecimalField(max_digits=6, decimal_places=2, default=0)
    payment_terms   = serializers.CharField(required=False, allow_blank=True)
    delivery_terms  = serializers.CharField(required=False, allow_blank=True)
    remarks         = serializers.CharField(required=False, allow_blank=True)
    terms_conditions = serializers.CharField(required=False, allow_blank=True)
    lines           = QuotationLineCreateSerializer(many=True)

    def validate_lines(self, v):
        if not v:
            raise serializers.ValidationError("At least one line required.")
        return v


# ── Artwork ───────────────────────────────────────────────────────

class ArtworkApprovalSerializer(serializers.ModelSerializer):
    customer_name = serializers.CharField(source="customer.name", read_only=True)
    class Meta:
        model  = ArtworkApproval
        fields = "__all__"


# ── Sales Order ───────────────────────────────────────────────────

class SOScheduleSerializer(serializers.ModelSerializer):
    class Meta:
        model  = SOSchedule
        fields = ["id","schedule_date","scheduled_qty","despatched_qty","remarks","entered_at"]


class SOLineSerializer(serializers.ModelSerializer):
    item_code   = serializers.CharField(source="item.code", read_only=True, default="")
    pending_qty = serializers.DecimalField(max_digits=15, decimal_places=2, read_only=True)
    schedules   = SOScheduleSerializer(many=True, read_only=True)
    class Meta:
        model  = SOLine
        fields = ["id","line_no","item","item_code","description","hsn_code",
                  "ordered_qty","despatched_qty","invoiced_qty","pending_qty","uom",
                  "unit_rate","discount_pct","taxable_amt","gst_pct",
                  "gst_amount","line_total","required_date","remarks","schedules"]


class SOListSerializer(serializers.ModelSerializer):
    customer_name = serializers.CharField(source="customer.name", read_only=True)
    class Meta:
        model  = SalesOrder
        fields = ["id","uuid","so_number","so_date","so_type","status",
                  "customer","customer_name","customer_po_number",
                  "total_amount","required_delivery_date","salesman"]


class SODetailSerializer(serializers.ModelSerializer):
    lines               = SOLineSerializer(many=True, read_only=True)
    customer_name       = serializers.CharField(source="customer.name", read_only=True)
    # BUG-031 fix: these fields must be read-only — only set by check_material_readiness task
    material_ready          = serializers.BooleanField(read_only=True)
    material_ready_at       = serializers.DateTimeField(read_only=True)
    material_ready_notified = serializers.BooleanField(read_only=True)
    class Meta:
        model  = SalesOrder
        fields = "__all__"


class SOLineCreateSerializer(serializers.Serializer):
    item_id      = serializers.IntegerField(required=False, allow_null=True)
    description  = serializers.CharField(max_length=500)
    hsn_code     = serializers.CharField(required=False, allow_blank=True)
    ordered_qty  = serializers.DecimalField(max_digits=15, decimal_places=2)
    uom_id       = serializers.IntegerField(required=False, allow_null=True)
    unit_rate    = serializers.DecimalField(max_digits=12, decimal_places=4)
    discount_pct = serializers.DecimalField(max_digits=6, decimal_places=2, default=0)
    gst_pct      = serializers.DecimalField(max_digits=5, decimal_places=2, default=18)
    required_date = serializers.DateField(required=False, allow_null=True)
    remarks      = serializers.CharField(required=False, allow_blank=True)


class SOCreateSerializer(serializers.Serializer):
    so_date        = serializers.DateField(required=False)
    so_type        = serializers.ChoiceField(choices=SalesOrder.SOType.choices,
                                              default=SalesOrder.SOType.REGULAR)
    customer_id    = serializers.IntegerField()
    ship_to_id     = serializers.IntegerField(required=False, allow_null=True)
    customer_po_number = serializers.CharField(required=False, allow_blank=True)
    customer_po_date   = serializers.DateField(required=False, allow_null=True)
    quotation_id   = serializers.IntegerField(required=False, allow_null=True)
    required_delivery_date = serializers.DateField(required=False, allow_null=True)
    payment_terms  = serializers.CharField(required=False, allow_blank=True)
    delivery_terms = serializers.CharField(required=False, allow_blank=True)
    discount_pct   = serializers.DecimalField(max_digits=6, decimal_places=2, default=0)
    salesman_id    = serializers.IntegerField(required=False, allow_null=True)
    remarks        = serializers.CharField(required=False, allow_blank=True)
    lines          = SOLineCreateSerializer(many=True)

    def validate_lines(self, v):
        if not v:
            raise serializers.ValidationError("At least one line required.")
        return v


# ── Despatch ──────────────────────────────────────────────────────

class DespatchLineSerializer(serializers.ModelSerializer):
    item_code = serializers.CharField(source="item.code", read_only=True, default="")
    class Meta:
        model  = DespatchLine
        fields = ["id","so_line","item","item_code","description",
                  "despatched_qty","uom","unit_rate","batch_number","remarks"]


class DespatchListSerializer(serializers.ModelSerializer):
    customer_name = serializers.CharField(source="customer.name", read_only=True)
    class Meta:
        model  = Despatch
        fields = ["id","uuid","dc_number","dc_date","status","customer","customer_name",
                  "vehicle_number","gate_out_time","customer_email_sent"]


class DespatchDetailSerializer(serializers.ModelSerializer):
    lines         = DespatchLineSerializer(many=True, read_only=True)
    customer_name = serializers.CharField(source="customer.name", read_only=True)
    class Meta:
        model  = Despatch
        fields = "__all__"


class DespatchLineCreateSerializer(serializers.Serializer):
    so_line_id     = serializers.IntegerField()
    despatched_qty = serializers.DecimalField(max_digits=15, decimal_places=2)
    remarks        = serializers.CharField(required=False, allow_blank=True)


class DespatchCreateSerializer(serializers.Serializer):
    sales_order_id    = serializers.IntegerField()
    dc_date           = serializers.DateField(required=False)
    ship_to_id        = serializers.IntegerField(required=False, allow_null=True)
    transporter_name  = serializers.CharField(required=False, allow_blank=True)
    vehicle_number    = serializers.CharField(required=False, allow_blank=True)
    lr_number         = serializers.CharField(required=False, allow_blank=True)
    lr_date           = serializers.DateField(required=False, allow_null=True)
    driver_name       = serializers.CharField(required=False, allow_blank=True)
    driver_phone      = serializers.CharField(required=False, allow_blank=True)
    no_of_packages    = serializers.IntegerField(required=False, default=0)
    gross_weight_kg   = serializers.DecimalField(max_digits=10, decimal_places=2,
                                                  required=False, allow_null=True)
    remarks           = serializers.CharField(required=False, allow_blank=True)
    lines             = DespatchLineCreateSerializer(many=True)


class GateOutSerializer(serializers.Serializer):
    qr_scan_data = serializers.CharField(required=False, allow_blank=True)


# ── Invoice ───────────────────────────────────────────────────────

class InvoiceLineSerializer(serializers.ModelSerializer):
    item_code = serializers.CharField(source="item.code", read_only=True, default="")
    class Meta:
        model  = InvoiceLine
        fields = ["id","line_no","item","item_code","description","hsn_code",
                  "qty","uom","unit_rate","discount_pct","taxable_amt",
                  "cgst_pct","sgst_pct","igst_pct",
                  "cgst_amount","sgst_amount","igst_amount","line_total","batch_number"]


class InvoiceListSerializer(serializers.ModelSerializer):
    customer_name = serializers.CharField(source="customer.name", read_only=True)
    class Meta:
        model  = Invoice
        fields = ["id","uuid","invoice_number","invoice_date","invoice_type","status",
                  "customer","customer_name","total_amount","outstanding_amount",
                  "irn","eway_bill_number","gate_out_time"]


class InvoiceDetailSerializer(serializers.ModelSerializer):
    lines         = InvoiceLineSerializer(many=True, read_only=True)
    customer_name = serializers.CharField(source="customer.name", read_only=True)
    class Meta:
        model  = Invoice
        fields = "__all__"


class InvoiceCreateSerializer(serializers.Serializer):
    despatch_id    = serializers.IntegerField()
    invoice_date   = serializers.DateField(required=False)
    place_of_supply = serializers.CharField(required=False, allow_blank=True)
    payment_terms  = serializers.CharField(required=False, allow_blank=True)
    remarks        = serializers.CharField(required=False, allow_blank=True)


# ── Invoice Reach ─────────────────────────────────────────────────

class InvoiceReachSerializer(serializers.ModelSerializer):
    class Meta:
        model  = InvoiceReachRecord
        fields = "__all__"


# ── Complaint ─────────────────────────────────────────────────────

class ComplaintListSerializer(serializers.ModelSerializer):
    customer_name = serializers.CharField(source="customer.name", read_only=True)
    class Meta:
        model  = CustomerComplaint
        fields = ["id","uuid","complaint_number","complaint_date","status","category",
                  "customer","customer_name","assigned_to","resolved_at"]


class ComplaintDetailSerializer(serializers.ModelSerializer):
    customer_name = serializers.CharField(source="customer.name", read_only=True)
    class Meta:
        model  = CustomerComplaint
        fields = "__all__"
