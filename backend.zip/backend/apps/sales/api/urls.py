"""Sales Module URLs — Section 5"""
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from apps.sales.api.viewsets import (
    EnquiryViewSet, QuotationViewSet, ArtworkApprovalViewSet,
    SalesOrderViewSet, DespatchViewSet, InvoiceViewSet,
    CustomerComplaintViewSet,
)

router = DefaultRouter()
router.register("enquiries",    EnquiryViewSet,           basename="enquiry")
router.register("quotations",   QuotationViewSet,         basename="quotation")
router.register("artworks",     ArtworkApprovalViewSet,   basename="artwork")
router.register("orders",       SalesOrderViewSet,        basename="sales-order")
router.register("despatches",   DespatchViewSet,          basename="despatch")
router.register("invoices",     InvoiceViewSet,           basename="invoice")
router.register("complaints",   CustomerComplaintViewSet, basename="complaint")

app_name = "sales"
urlpatterns = [path("", include(router.urls))]
