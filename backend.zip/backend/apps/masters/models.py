"""
Masters Module Models:
- VendorGroup, Vendor, VendorContact
- ItemGroup, UOM, Item (with paper-specific attributes), ItemAlternate, ItemVendorLink
- CustomerGroup, Customer, CustomerShipAddress, CustomerContact
- PriceList, PriceListItem
"""
import uuid
from django.conf import settings
from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator, RegexValidator
from apps.core.models import TimeStampedModel, UUIDModel, Plant


# ─── Validators ────────────────────────────────────────────────────

gstin_validator = RegexValidator(
    regex=r"^\d{2}[A-Z]{5}\d{4}[A-Z]{1}[A-Z\d]{1}[Z]{1}[A-Z\d]{1}$",
    message="Enter a valid 15-character GSTIN.",
)

pan_validator = RegexValidator(
    regex=r"^[A-Z]{5}\d{4}[A-Z]{1}$",
    message="Enter a valid 10-character PAN.",
)

hsn_validator = RegexValidator(
    regex=r"^\d{4,8}$",
    message="HSN code must be 4 to 8 digits.",
)


# ═══════════════════════════════════════════════════════════════════
# VENDOR MASTER
# ═══════════════════════════════════════════════════════════════════

class VendorGroup(models.Model):
    code = models.CharField(max_length=20, unique=True)
    name = models.CharField(max_length=100)
    parent = models.ForeignKey(
        "self", on_delete=models.SET_NULL, null=True, blank=True, related_name="children"
    )
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ["code"]
        verbose_name_plural = "vendor groups"

    def __str__(self):
        return f"{self.code} - {self.name}"


class Vendor(UUIDModel, TimeStampedModel):
    class VendorType(models.TextChoices):
        SUPPLIER = "SUPPLIER", "Supplier"
        TRANSPORTER = "TRANSPORTER", "Transporter"
        JOB_WORKER = "JOB_WORKER", "Job Worker"
        SERVICE_PROVIDER = "SERVICE_PROVIDER", "Service Provider"

    class GSTType(models.TextChoices):
        REGULAR = "REGULAR", "Regular"
        COMPOSITION = "COMPOSITION", "Composition"
        UNREGISTERED = "UNREGISTERED", "Unregistered"
        INTERNATIONAL = "INTERNATIONAL", "International"

    code = models.CharField(max_length=20, unique=True, db_index=True)
    name = models.CharField(max_length=200, db_index=True)
    legal_name = models.CharField(max_length=300, blank=True)
    vendor_group = models.ForeignKey(
        VendorGroup, on_delete=models.SET_NULL, null=True, blank=True, related_name="vendors"
    )
    vendor_type = models.CharField(max_length=30, choices=VendorType.choices, default=VendorType.SUPPLIER)

    address_line1 = models.CharField(max_length=300, blank=True)
    address_line2 = models.CharField(max_length=300, blank=True)
    city = models.CharField(max_length=100, blank=True)
    state = models.CharField(max_length=100, blank=True)
    pincode = models.CharField(max_length=10, blank=True)
    country = models.CharField(max_length=100, default="India")

    phone = models.CharField(max_length=20, blank=True)
    mobile = models.CharField(max_length=20, blank=True)
    email = models.EmailField(blank=True)
    website = models.URLField(blank=True)
    contact_person = models.CharField(max_length=200, blank=True)

    gstin = models.CharField(max_length=15, blank=True, validators=[gstin_validator])
    pan = models.CharField(max_length=10, blank=True, validators=[pan_validator])
    gst_type = models.CharField(max_length=30, choices=GSTType.choices, default=GSTType.REGULAR)
    tds_applicable = models.BooleanField(default=False)
    tds_section = models.CharField(max_length=10, blank=True)
    tds_rate = models.DecimalField(max_digits=5, decimal_places=2, default=0, validators=[MinValueValidator(0), MaxValueValidator(100)])
    tcs_applicable = models.BooleanField(default=False)
    tcs_rate = models.DecimalField(max_digits=5, decimal_places=2, default=0, validators=[MinValueValidator(0), MaxValueValidator(100)])

    msme_registered = models.BooleanField(default=False)
    msme_number = models.CharField(max_length=30, blank=True)
    msme_type = models.CharField(max_length=20, blank=True, choices=[("MICRO", "Micro"), ("SMALL", "Small"), ("MEDIUM", "Medium")])

    bank_name = models.CharField(max_length=200, blank=True)
    bank_account = models.CharField(max_length=50, blank=True)
    bank_ifsc = models.CharField(max_length=20, blank=True)
    bank_branch = models.CharField(max_length=200, blank=True)

    credit_days = models.IntegerField(default=30, validators=[MinValueValidator(0), MaxValueValidator(365)])
    credit_limit = models.DecimalField(max_digits=15, decimal_places=2, default=0, validators=[MinValueValidator(0)])
    payment_terms = models.TextField(blank=True)
    delivery_rating = models.DecimalField(max_digits=3, decimal_places=2, default=0)

    is_approved = models.BooleanField(default=False)
    approved_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name="approved_vendors")
    approved_at = models.DateTimeField(null=True, blank=True)

    is_active = models.BooleanField(default=True)
    notes = models.TextField(blank=True)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name="created_vendors")
    updated_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name="updated_vendors")

    class Meta:
        ordering = ["code"]
        indexes = [models.Index(fields=["name"]), models.Index(fields=["gstin"]), models.Index(fields=["vendor_type"])]

    def __str__(self):
        return f"{self.code} - {self.name}"

    @property
    def state_code(self):
        if self.gstin and len(self.gstin) >= 2:
            return self.gstin[:2]
        return ""


class VendorContact(TimeStampedModel):
    vendor = models.ForeignKey(Vendor, on_delete=models.CASCADE, related_name="contacts")
    name = models.CharField(max_length=200)
    designation = models.CharField(max_length=100, blank=True)
    phone = models.CharField(max_length=20, blank=True)
    mobile = models.CharField(max_length=20, blank=True)
    email = models.EmailField(blank=True)
    is_primary = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.name} ({self.vendor.code})"


# ═══════════════════════════════════════════════════════════════════
# ITEM / MATERIAL MASTER
# ═══════════════════════════════════════════════════════════════════

class ItemGroup(models.Model):
    code = models.CharField(max_length=20, unique=True)
    name = models.CharField(max_length=100)
    parent = models.ForeignKey("self", on_delete=models.SET_NULL, null=True, blank=True, related_name="children")
    item_type = models.CharField(
        max_length=30, blank=True,
        choices=[
            ("RAW_MATERIAL", "Raw Material"), ("BOUGHT_OUT", "Bought Out Part"),
            ("CONSUMABLE", "Consumable"), ("SPARE", "Spare Part"),
            ("FINISHED_GOOD", "Finished Good"), ("SEMI_FINISHED", "Semi-Finished"),
        ]
    )
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ["code"]

    def __str__(self):
        return f"{self.code} - {self.name}"


class UOM(models.Model):
    code = models.CharField(max_length=10, unique=True)
    name = models.CharField(max_length=50)
    decimal_places = models.IntegerField(default=2)

    class Meta:
        verbose_name = "UOM"
        verbose_name_plural = "UOMs"
        ordering = ["code"]

    def __str__(self):
        return f"{self.code} ({self.name})"


class Item(UUIDModel, TimeStampedModel):
    class ItemType(models.TextChoices):
        RAW_MATERIAL = "RAW_MATERIAL", "Raw Material"
        BOUGHT_OUT = "BOUGHT_OUT", "Bought Out Part"
        CONSUMABLE = "CONSUMABLE", "Consumable"
        SPARE = "SPARE", "Spare Part"
        FINISHED_GOOD = "FINISHED_GOOD", "Finished Good"
        SEMI_FINISHED = "SEMI_FINISHED", "Semi-Finished"

    class ApprovalStatus(models.TextChoices):
        DRAFT = "DRAFT", "Draft"
        PENDING = "PENDING", "Pending Approval"
        APPROVED = "APPROVED", "Approved"
        REJECTED = "REJECTED", "Rejected"

    code = models.CharField(max_length=30, unique=True, db_index=True)
    name = models.CharField(max_length=300, db_index=True)
    description = models.TextField(blank=True)
    item_group = models.ForeignKey(ItemGroup, on_delete=models.PROTECT, related_name="items")
    item_type = models.CharField(max_length=30, choices=ItemType.choices)

    uom = models.ForeignKey(UOM, on_delete=models.PROTECT, related_name="primary_items")
    secondary_uom = models.ForeignKey(UOM, on_delete=models.SET_NULL, null=True, blank=True, related_name="secondary_items")
    conversion_factor = models.DecimalField(max_digits=15, decimal_places=6, null=True, blank=True)

    hsn_code = models.CharField(max_length=10, blank=True, validators=[hsn_validator])
    gst_rate = models.DecimalField(max_digits=5, decimal_places=2, default=18.00, validators=[MinValueValidator(0), MaxValueValidator(100)])

    pack_size = models.CharField(max_length=50, blank=True)
    min_stock = models.DecimalField(max_digits=15, decimal_places=3, default=0)
    max_stock = models.DecimalField(max_digits=15, decimal_places=3, default=0)
    reorder_level = models.DecimalField(max_digits=15, decimal_places=3, default=0)
    lead_time_days = models.IntegerField(default=7, validators=[MinValueValidator(0)])
    shelf_life_days = models.IntegerField(null=True, blank=True, validators=[MinValueValidator(0)])

    # Paper-specific
    bf_rating = models.IntegerField(null=True, blank=True, validators=[MinValueValidator(0)])
    gsm = models.IntegerField(null=True, blank=True, validators=[MinValueValidator(0)])
    deckle_mm = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    paper_type = models.CharField(
        max_length=50, blank=True,
        choices=[
            ("KRAFT", "Kraft"), ("FLUTE", "Flute"), ("LINER", "Liner"),
            ("TESTLINER", "Test Liner"), ("SEMI_CHEMICAL", "Semi Chemical"), ("DUPLEX", "Duplex"),
        ]
    )

    approval_status = models.CharField(max_length=20, choices=ApprovalStatus.choices, default=ApprovalStatus.DRAFT)
    is_approved = models.BooleanField(default=False)
    approved_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name="approved_items")
    approved_at = models.DateTimeField(null=True, blank=True)
    rejection_reason = models.TextField(blank=True)

    # ── Auto PR / Replenishment ────────────────────────────────────
    auto_pr_enabled = models.BooleanField(
        default=False,
        help_text="Enable auto PR generation based on consumption history",
    )
    auto_pr_lead_days = models.PositiveIntegerField(
        default=7,
        help_text="Minimum days of stock to maintain; triggers auto PR when stock falls below this",
    )

    is_active = models.BooleanField(default=True)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name="created_items")
    updated_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name="updated_items")

    # Box dimensions (F6) - for finished goods / corrugated boxes
    BOX_TYPE_RSC         = "RSC"
    BOX_TYPE_HSC         = "HSC"
    BOX_TYPE_TOP_BOTTOM  = "TOP_BOTTOM"
    BOX_TYPE_DIE_CUT     = "DIE_CUT"
    BOX_TYPE_OTHER       = "OTHER"
    BOX_TYPE_CHOICES = [
        (BOX_TYPE_RSC,        "Regular Slotted Container (RSC)"),
        (BOX_TYPE_HSC,        "Half Slotted Container (HSC)"),
        (BOX_TYPE_TOP_BOTTOM, "Top & Bottom"),
        (BOX_TYPE_DIE_CUT,    "Die Cut"),
        (BOX_TYPE_OTHER,      "Other"),
    ]
    box_length_mm = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True, help_text="Internal length (mm)")
    box_width_mm  = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True, help_text="Internal width (mm)")
    box_height_mm = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True, help_text="Internal height (mm)")
    box_type      = models.CharField(max_length=20, choices=BOX_TYPE_CHOICES, blank=True, default="")
    ply_count     = models.PositiveSmallIntegerField(null=True, blank=True, help_text="Number of plies (3-ply, 5-ply, etc.)")
    box_weight_kg = models.DecimalField(max_digits=8, decimal_places=3, null=True, blank=True, help_text="Weight of one box (kg)")

    class Meta:
        ordering = ["code"]
        indexes = [models.Index(fields=["item_type"]), models.Index(fields=["hsn_code"]), models.Index(fields=["approval_status"])]
        constraints = [
            models.UniqueConstraint(
                fields=["paper_type", "bf_rating", "gsm", "deckle_mm"],
                condition=models.Q(item_type="RAW_MATERIAL", paper_type__gt=""),
                name="unique_paper_spec",
            )
        ]

    def __str__(self):
        return f"{self.code} - {self.name}"

    def save(self, *args, **kwargs):
        if self.item_type == self.ItemType.RAW_MATERIAL and self.paper_type:
            self.name = self._generate_paper_name()
        super().save(*args, **kwargs)

    def _generate_paper_name(self):
        parts = [self.get_paper_type_display()]
        if self.bf_rating:
            parts.append(f"BF{self.bf_rating}")
        if self.gsm:
            parts.append(f"{self.gsm}GSM")
        if self.deckle_mm:
            parts.append(f"{self.deckle_mm}mm")
        return " ".join(parts)

    @property
    def is_paper(self):
        return self.item_type == self.ItemType.RAW_MATERIAL and bool(self.paper_type)


class ItemAlternate(TimeStampedModel):
    item = models.ForeignKey(Item, on_delete=models.CASCADE, related_name="alternates")
    alternate_item = models.ForeignKey(Item, on_delete=models.CASCADE, related_name="alternate_for")
    priority = models.IntegerField(default=1)
    remarks = models.TextField(blank=True)

    class Meta:
        unique_together = ["item", "alternate_item"]
        ordering = ["priority"]


class ItemVendorLink(TimeStampedModel):
    item = models.ForeignKey(Item, on_delete=models.CASCADE, related_name="vendor_links")
    vendor = models.ForeignKey(Vendor, on_delete=models.CASCADE, related_name="item_links")
    is_preferred = models.BooleanField(default=False)
    last_rate = models.DecimalField(max_digits=15, decimal_places=4, null=True, blank=True)
    last_po_date = models.DateField(null=True, blank=True)
    last_po_number = models.CharField(max_length=30, blank=True)
    min_order_qty = models.DecimalField(max_digits=15, decimal_places=3, null=True, blank=True)
    lead_time_days = models.IntegerField(null=True, blank=True)
    remarks = models.TextField(blank=True)

    class Meta:
        unique_together = ["item", "vendor"]
        ordering = ["-is_preferred", "vendor__name"]

    def __str__(self):
        return f"{self.item.code} <-> {self.vendor.code}"


# ═══════════════════════════════════════════════════════════════════
# CUSTOMER MASTER
# ═══════════════════════════════════════════════════════════════════

class CustomerGroup(models.Model):
    code = models.CharField(max_length=20, unique=True)
    name = models.CharField(max_length=100)
    parent = models.ForeignKey("self", on_delete=models.SET_NULL, null=True, blank=True, related_name="children")
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ["code"]

    def __str__(self):
        return f"{self.code} - {self.name}"


class Customer(UUIDModel, TimeStampedModel):
    class CustomerType(models.TextChoices):
        DIRECT = "DIRECT", "Direct"
        DEALER = "DEALER", "Dealer"
        E_COMMERCE = "E_COMMERCE", "E-Commerce"
        INSTITUTIONAL = "INSTITUTIONAL", "Institutional"

    code = models.CharField(max_length=20, unique=True, db_index=True)
    name = models.CharField(max_length=200, db_index=True)
    legal_name = models.CharField(max_length=300, blank=True)
    customer_group = models.ForeignKey(CustomerGroup, on_delete=models.SET_NULL, null=True, blank=True, related_name="customers")
    customer_type = models.CharField(max_length=30, choices=CustomerType.choices, default=CustomerType.DIRECT)

    address_line1 = models.CharField(max_length=300, blank=True)
    address_line2 = models.CharField(max_length=300, blank=True)
    city = models.CharField(max_length=100, blank=True)
    state = models.CharField(max_length=100, blank=True)
    pincode = models.CharField(max_length=10, blank=True)
    country = models.CharField(max_length=100, default="India")

    phone = models.CharField(max_length=20, blank=True)
    mobile = models.CharField(max_length=20, blank=True)
    email = models.EmailField(blank=True)
    website = models.URLField(blank=True)
    contact_person = models.CharField(max_length=200, blank=True)

    gstin = models.CharField(max_length=15, blank=True, validators=[gstin_validator])
    pan = models.CharField(max_length=10, blank=True, validators=[pan_validator])
    gst_type = models.CharField(max_length=30, choices=Vendor.GSTType.choices, default=Vendor.GSTType.REGULAR)

    credit_days = models.IntegerField(default=30, validators=[MinValueValidator(0)])
    credit_limit = models.DecimalField(max_digits=15, decimal_places=2, default=0, validators=[MinValueValidator(0)])
    payment_terms = models.TextField(blank=True)

    sales_region = models.CharField(max_length=50, blank=True)
    sales_zone = models.CharField(max_length=50, blank=True)
    sales_territory = models.CharField(max_length=50, blank=True)
    assigned_rsm = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name="rsm_customers")
    assigned_tsm = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name="tsm_customers")
    assigned_zsm = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name="zsm_customers")

    portal_enabled = models.BooleanField(default=False)
    portal_user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name="customer_portal")

    is_active = models.BooleanField(default=True)
    notes = models.TextField(blank=True)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name="created_customers")
    updated_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name="updated_customers")

    class Meta:
        ordering = ["code"]
        indexes = [models.Index(fields=["name"]), models.Index(fields=["gstin"]), models.Index(fields=["customer_type"])]

    def __str__(self):
        return f"{self.code} - {self.name}"

    @property
    def state_code(self):
        if self.gstin and len(self.gstin) >= 2:
            return self.gstin[:2]
        return ""


class CustomerShipAddress(TimeStampedModel):
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE, related_name="ship_addresses")
    label = models.CharField(max_length=100)
    address_line1 = models.CharField(max_length=300)
    address_line2 = models.CharField(max_length=300, blank=True)
    city = models.CharField(max_length=100)
    state = models.CharField(max_length=100)
    pincode = models.CharField(max_length=10)
    gstin = models.CharField(max_length=15, blank=True, validators=[gstin_validator])
    contact_person = models.CharField(max_length=200, blank=True)
    phone = models.CharField(max_length=20, blank=True)
    is_default = models.BooleanField(default=False)
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ["-is_default", "label"]

    def __str__(self):
        return f"{self.customer.code} - {self.label}"

    def save(self, *args, **kwargs):
        if self.is_default:
            CustomerShipAddress.objects.filter(customer=self.customer, is_default=True).exclude(pk=self.pk).update(is_default=False)
        super().save(*args, **kwargs)


class CustomerContact(TimeStampedModel):
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE, related_name="contacts")
    name = models.CharField(max_length=200)
    designation = models.CharField(max_length=100, blank=True)
    phone = models.CharField(max_length=20, blank=True)
    mobile = models.CharField(max_length=20, blank=True)
    email = models.EmailField(blank=True)
    department = models.CharField(max_length=100, blank=True)
    is_primary = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.name} ({self.customer.code})"


# ═══════════════════════════════════════════════════════════════════
# PRICE LIST
# ═══════════════════════════════════════════════════════════════════

class PriceList(TimeStampedModel):
    name = models.CharField(max_length=100)
    plant = models.ForeignKey(Plant, on_delete=models.CASCADE, related_name="price_lists")
    effective_from = models.DateField()
    effective_to = models.DateField(null=True, blank=True)
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ["-effective_from"]

    def __str__(self):
        return f"{self.name} (from {self.effective_from})"


class PriceListItem(models.Model):
    price_list = models.ForeignKey(PriceList, on_delete=models.CASCADE, related_name="items")
    item = models.ForeignKey(Item, on_delete=models.CASCADE, related_name="price_entries")
    customer_group = models.ForeignKey(CustomerGroup, on_delete=models.SET_NULL, null=True, blank=True)
    customer = models.ForeignKey(Customer, on_delete=models.SET_NULL, null=True, blank=True)
    rate = models.DecimalField(max_digits=15, decimal_places=4)
    min_qty = models.DecimalField(max_digits=15, decimal_places=3, default=0)
    discount_pct = models.DecimalField(max_digits=5, decimal_places=2, default=0)

    class Meta:
        ordering = ["item__code"]

    def __str__(self):
        return f"{self.item.code} @ {self.rate}"
