"""
Masters Module ViewSets.
Full CRUD for Vendor, Item, Customer with:
- Search, filter, ordering
- Item approval workflow (entry by one, approval by another)
- Excel import/export
- Vendor-only edits after setup (permission-based)
"""
import io
from decimal import Decimal
from django.utils import timezone
from django.db.models import Q, Count
from django.http import HttpResponse
from rest_framework import viewsets, status, filters
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework.parsers import MultiPartParser
from django_filters.rest_framework import DjangoFilterBackend
import openpyxl

from apps.core.models import AuditLog
from apps.masters.models import (
    VendorGroup, Vendor, VendorContact,
    ItemGroup, UOM, Item, ItemAlternate, ItemVendorLink,
    CustomerGroup, Customer, CustomerShipAddress, CustomerContact,
    PriceList, PriceListItem,
)
from apps.masters.api.serializers import (
    VendorGroupSerializer, VendorListSerializer, VendorDetailSerializer,
    VendorApprovalSerializer, VendorImportSerializer,
    ItemGroupSerializer, UOMSerializer,
    ItemListSerializer, ItemDetailSerializer,
    ItemApprovalSerializer, ItemImportSerializer,
    ItemVendorLinkSerializer,
    CustomerGroupSerializer,
    CustomerListSerializer, CustomerDetailSerializer,
    CustomerShipAddressSerializer, CustomerContactSerializer,
    CustomerImportSerializer,
    PriceListSerializer, PriceListItemSerializer,
)
from apps.masters.api.filters import VendorFilter, ItemFilter, CustomerFilter


def _log_audit(user, action_type, module, resource, resource_id, old_vals=None, new_vals=None, notes=""):
    AuditLog.objects.create(
        user=user, action=action_type, module=module,
        resource=resource, resource_id=resource_id,
        old_values=old_vals, new_values=new_vals, notes=notes,
    )


# ═══════════════════════════════════════════════════════════════════
# VENDOR
# ═══════════════════════════════════════════════════════════════════

class VendorGroupViewSet(viewsets.ModelViewSet):
    queryset = VendorGroup.objects.annotate(vendor_count=Count("vendors"))
    serializer_class = VendorGroupSerializer
    permission_classes = [IsAuthenticated]
    search_fields = ["code", "name"]
    ordering_fields = ["code", "name"]

    @action(detail=False, methods=["get"])
    def tree(self, request):
        """Return hierarchical tree of vendor groups."""
        roots = VendorGroup.objects.filter(parent__isnull=True, is_active=True)
        data = []
        for root in roots:
            node = VendorGroupSerializer(root).data
            node["children"] = VendorGroupSerializer(
                root.children.filter(is_active=True), many=True
            ).data
            data.append(node)
        return Response(data)


class VendorViewSet(viewsets.ModelViewSet):
    queryset = Vendor.objects.select_related("vendor_group", "created_by", "approved_by")
    permission_classes = [IsAuthenticated]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_class = VendorFilter
    search_fields = ["code", "name", "gstin", "city", "contact_person"]
    ordering_fields = ["code", "name", "created_at", "delivery_rating"]
    ordering = ["code"]

    def get_serializer_class(self):
        if self.action == "list":
            return VendorListSerializer
        return VendorDetailSerializer

    def perform_create(self, serializer):
        vendor = serializer.save()
        _log_audit(self.request.user, "CREATE", "masters", "vendor", vendor.id,
                   new_vals=VendorDetailSerializer(vendor).data)

    def perform_update(self, serializer):
        old_data = VendorDetailSerializer(self.get_object()).data
        vendor = serializer.save()
        _log_audit(self.request.user, "UPDATE", "masters", "vendor", vendor.id,
                   old_vals=old_data, new_vals=VendorDetailSerializer(vendor).data)

    @action(detail=True, methods=["post"])
    def approve(self, request, pk=None):
        """Approve or reject a vendor."""
        vendor = self.get_object()
        ser = VendorApprovalSerializer(data=request.data)
        ser.is_valid(raise_exception=True)

        if ser.validated_data["action"] == "approve":
            vendor.is_approved = True
            vendor.approved_by = request.user
            vendor.approved_at = timezone.now()
            vendor.save(update_fields=["is_approved", "approved_by", "approved_at"])
            _log_audit(request.user, "APPROVE", "masters", "vendor", vendor.id,
                       notes=ser.validated_data.get("remarks", ""))
            return Response({"status": "approved", "vendor": vendor.code})
        else:
            vendor.is_approved = False
            vendor.save(update_fields=["is_approved"])
            _log_audit(request.user, "REJECT", "masters", "vendor", vendor.id,
                       notes=ser.validated_data.get("remarks", ""))
            return Response({"status": "rejected", "vendor": vendor.code})

    @action(detail=False, methods=["post"], parser_classes=[MultiPartParser])
    def import_excel(self, request):
        """Import vendors from Excel file."""
        file = request.FILES.get("file")
        if not file:
            return Response({"error": "No file uploaded."}, status=400)

        try:
            wb = openpyxl.load_workbook(file, read_only=True)
            ws = wb.active
        except Exception as e:
            return Response({"error": f"Invalid Excel file: {str(e)}"}, status=400)

        headers = [cell.value for cell in next(ws.iter_rows(min_row=1, max_row=1))]
        results = {"created": 0, "updated": 0, "errors": []}

        for row_num, row in enumerate(ws.iter_rows(min_row=2, values_only=True), start=2):
            row_data = dict(zip(headers, row))
            ser = VendorImportSerializer(data=row_data)
            if not ser.is_valid():
                results["errors"].append({"row": row_num, "errors": ser.errors})
                continue

            data = ser.validated_data
            group = None
            if data.get("vendor_group_code"):
                group = VendorGroup.objects.filter(code=data.pop("vendor_group_code")).first()

            vendor, created = Vendor.objects.update_or_create(
                code=data.pop("code"),
                defaults={**data, "vendor_group": group, "created_by": request.user},
            )
            if created:
                results["created"] += 1
            else:
                results["updated"] += 1

        return Response(results)

    @action(detail=False, methods=["get"])
    def export_excel(self, request):
        """Export vendors to Excel."""
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Vendors"

        headers = [
            "Code", "Name", "Type", "City", "State", "GSTIN", "PAN",
            "GST Type", "TDS Applicable", "TDS Section", "TDS Rate",
            "Credit Days", "Phone", "Email", "Group",
        ]
        ws.append(headers)

        vendors = self.filter_queryset(self.get_queryset())
        for v in vendors:
            ws.append([
                v.code, v.name, v.vendor_type, v.city, v.state,
                v.gstin, v.pan, v.gst_type, v.tds_applicable,
                v.tds_section, float(v.tds_rate), v.credit_days,
                v.phone, v.email,
                v.vendor_group.code if v.vendor_group else "",
            ])

        # Auto-adjust column widths
        for col in ws.columns:
            max_len = max(len(str(cell.value or "")) for cell in col)
            ws.column_dimensions[col[0].column_letter].width = min(max_len + 2, 40)

        buffer = io.BytesIO()
        wb.save(buffer)
        buffer.seek(0)
        response = HttpResponse(
            buffer.getvalue(),
            content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )
        response["Content-Disposition"] = 'attachment; filename="vendors_export.xlsx"'
        return response

    @action(detail=False, methods=["get"])
    def import_template(self, request):
        """Download blank Excel template for vendor import."""
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Vendor Import"
        headers = [
            "code", "name", "vendor_type", "address_line1", "city", "state",
            "pincode", "phone", "email", "gstin", "pan", "gst_type",
            "tds_applicable", "tds_section", "tds_rate", "credit_days",
            "vendor_group_code",
        ]
        ws.append(headers)
        # Add a sample row
        ws.append([
            "V001", "Sample Paper Mill", "SUPPLIER", "123 Industrial Area",
            "Vapi", "Gujarat", "396191", "9876543210", "info@example.com",
            "24AAKFT4708J2ZY", "AAKFT4708J", "REGULAR", False, "", 0, 30, "CR-PAPER",
        ])

        buffer = io.BytesIO()
        wb.save(buffer)
        buffer.seek(0)
        response = HttpResponse(
            buffer.getvalue(),
            content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )
        response["Content-Disposition"] = 'attachment; filename="vendor_import_template.xlsx"'
        return response


# ═══════════════════════════════════════════════════════════════════
# ITEM
# ═══════════════════════════════════════════════════════════════════

class ItemGroupViewSet(viewsets.ModelViewSet):
    queryset = ItemGroup.objects.annotate(items_count=Count("items"))
    serializer_class = ItemGroupSerializer
    permission_classes = [IsAuthenticated]
    search_fields = ["code", "name"]
    filterset_fields = ["item_type", "is_active"]

    @action(detail=False, methods=["get"])
    def tree(self, request):
        roots = ItemGroup.objects.filter(parent__isnull=True, is_active=True)
        data = []
        for root in roots:
            node = ItemGroupSerializer(root).data
            node["children"] = ItemGroupSerializer(root.children.filter(is_active=True), many=True).data
            data.append(node)
        return Response(data)


class UOMViewSet(viewsets.ModelViewSet):
    queryset = UOM.objects.all()
    serializer_class = UOMSerializer
    permission_classes = [IsAuthenticated]
    search_fields = ["code", "name"]
    pagination_class = None  # Return all UOMs (small dataset)


class ItemViewSet(viewsets.ModelViewSet):
    queryset = Item.objects.select_related("item_group", "uom", "secondary_uom", "created_by", "approved_by")
    permission_classes = [IsAuthenticated]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_class = ItemFilter
    search_fields = ["code", "name", "hsn_code", "description"]
    ordering_fields = ["code", "name", "created_at", "gst_rate", "min_stock"]
    ordering = ["code"]

    def get_serializer_class(self):
        if self.action == "list":
            return ItemListSerializer
        return ItemDetailSerializer

    def perform_create(self, serializer):
        item = serializer.save()
        _log_audit(self.request.user, "CREATE", "masters", "item", item.id,
                   new_vals={"code": item.code, "name": item.name})

    @action(detail=True, methods=["post"])
    def approve(self, request, pk=None):
        """
        Item code approval workflow: entry by one person, approval by another.
        Checks: name, HS code, group validity.
        """
        item = self.get_object()
        ser = ItemApprovalSerializer(data=request.data)
        ser.is_valid(raise_exception=True)

        # Cannot approve own item
        if item.created_by == request.user:
            return Response(
                {"error": "Cannot approve an item you created. Requires a different approver."},
                status=status.HTTP_403_FORBIDDEN,
            )

        if ser.validated_data["action"] == "approve":
            item.approval_status = Item.ApprovalStatus.APPROVED
            item.is_approved = True
            item.approved_by = request.user
            item.approved_at = timezone.now()
            item.save(update_fields=["approval_status", "is_approved", "approved_by", "approved_at"])
            _log_audit(request.user, "APPROVE", "masters", "item", item.id, notes="Item approved")
            return Response({"status": "approved", "item": item.code})
        else:
            reason = ser.validated_data.get("rejection_reason", "")
            item.approval_status = Item.ApprovalStatus.REJECTED
            item.is_approved = False
            item.rejection_reason = reason
            item.save(update_fields=["approval_status", "is_approved", "rejection_reason"])
            _log_audit(request.user, "REJECT", "masters", "item", item.id, notes=reason)
            return Response({"status": "rejected", "item": item.code, "reason": reason})

    @action(detail=True, methods=["post"])
    def submit_for_approval(self, request, pk=None):
        """Submit a draft item for approval."""
        item = self.get_object()
        if item.approval_status != Item.ApprovalStatus.DRAFT:
            return Response({"error": "Only DRAFT items can be submitted."}, status=400)
        item.approval_status = Item.ApprovalStatus.PENDING
        item.save(update_fields=["approval_status"])
        return Response({"status": "submitted", "item": item.code})

    @action(detail=False, methods=["get"])
    def pending_approval(self, request):
        """List items pending approval."""
        qs = self.get_queryset().filter(approval_status=Item.ApprovalStatus.PENDING)
        page = self.paginate_queryset(qs)
        serializer = ItemListSerializer(page, many=True)
        return self.get_paginated_response(serializer.data)

    @action(detail=False, methods=["get"])
    def below_minimum(self, request):
        """Items below minimum stock level."""
        # This requires a subquery or annotation from inventory
        items = Item.objects.filter(
            is_active=True, is_approved=True, min_stock__gt=0
        )
        result = []
        for item in items[:100]:  # Limit for performance
            from django.db.models import Sum
            from apps.stores.models import InventoryLot
            stock = InventoryLot.objects.filter(
                item=item, is_active=True, status="AVAILABLE"
            ).aggregate(total=Sum("current_qty"))["total"] or 0
            if stock < item.min_stock:
                data = ItemListSerializer(item).data
                data["current_stock"] = float(stock)
                data["shortage"] = float(item.min_stock - stock)
                result.append(data)
        return Response(result)

    @action(detail=False, methods=["post"], parser_classes=[MultiPartParser])
    def import_excel(self, request):
        """Import items from Excel."""
        file = request.FILES.get("file")
        if not file:
            return Response({"error": "No file uploaded."}, status=400)

        try:
            wb = openpyxl.load_workbook(file, read_only=True)
            ws = wb.active
        except Exception as e:
            return Response({"error": f"Invalid Excel file: {str(e)}"}, status=400)

        headers = [cell.value for cell in next(ws.iter_rows(min_row=1, max_row=1))]
        results = {"created": 0, "errors": []}

        for row_num, row in enumerate(ws.iter_rows(min_row=2, values_only=True), start=2):
            row_data = dict(zip(headers, row))
            ser = ItemImportSerializer(data=row_data)
            if not ser.is_valid():
                results["errors"].append({"row": row_num, "errors": ser.errors})
                continue

            data = ser.validated_data
            group = ItemGroup.objects.filter(code=data.pop("item_group_code")).first()
            uom = UOM.objects.filter(code=data.pop("uom_code")).first()
            if not group or not uom:
                results["errors"].append({
                    "row": row_num,
                    "errors": "Invalid item_group_code or uom_code",
                })
                continue

            if Item.objects.filter(code=data["code"]).exists():
                results["errors"].append({"row": row_num, "errors": f"Code {data['code']} already exists."})
                continue

            Item.objects.create(
                **data, item_group=group, uom=uom,
                created_by=request.user,
                approval_status=Item.ApprovalStatus.PENDING,
            )
            results["created"] += 1

        return Response(results)

    @action(detail=False, methods=["get"])
    def export_excel(self, request):
        """Export items to Excel."""
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Items"

        headers = [
            "Code", "Name", "Type", "Group", "UOM", "HSN",
            "GST Rate", "Min Stock", "Max Stock", "BF Rating",
            "GSM", "Deckle (mm)", "Paper Type", "Status",
        ]
        ws.append(headers)

        items = self.filter_queryset(self.get_queryset())
        for item in items:
            ws.append([
                item.code, item.name, item.item_type,
                item.item_group.code, item.uom.code, item.hsn_code,
                float(item.gst_rate), float(item.min_stock), float(item.max_stock),
                item.bf_rating, item.gsm,
                float(item.deckle_mm) if item.deckle_mm else None,
                item.paper_type, item.approval_status,
            ])

        for col in ws.columns:
            max_len = max(len(str(cell.value or "")) for cell in col)
            ws.column_dimensions[col[0].column_letter].width = min(max_len + 2, 40)

        buffer = io.BytesIO()
        wb.save(buffer)
        buffer.seek(0)
        response = HttpResponse(
            buffer.getvalue(),
            content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )
        response["Content-Disposition"] = 'attachment; filename="items_export.xlsx"'
        return response

    @action(detail=True, methods=["post"], url_path="pallet-stuffing")
    def pallet_stuffing(self, request, pk=None):
        """
        POST /api/v1/masters/items/{id}/pallet-stuffing/

        Calculate pallet/container stuffing using this item's saved box dimensions.
        Body: { total_qty: int, container_type: "20FT"|"40FT"|"40HC" }
        """
        from apps.dispatch.pallet_calculator import calculate_stuffing

        item = self.get_object()

        if not (item.box_length_mm and item.box_width_mm and item.box_height_mm):
            return Response(
                {"error": "Box dimensions (length, width, height) are not set for this item. "
                          "Please update the item master with box dimensions first."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        total_qty = request.data.get("total_qty")
        container_type = request.data.get("container_type", "20FT")

        if not total_qty:
            return Response({"error": "total_qty is required."}, status=status.HTTP_400_BAD_REQUEST)

        try:
            result = calculate_stuffing(
                box_length_mm=item.box_length_mm,
                box_width_mm=item.box_width_mm,
                box_height_mm=item.box_height_mm,
                total_qty=total_qty,
                container_type=container_type,
                box_weight_kg=item.box_weight_kg,
            )
        except ValueError as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)

        result["item_code"] = item.code
        result["item_name"] = item.name
        return Response(result, status=status.HTTP_200_OK)


class ItemVendorLinkViewSet(viewsets.ModelViewSet):
    """Manage preferred vendors for items."""
    serializer_class = ItemVendorLinkSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return ItemVendorLink.objects.select_related("vendor", "item").filter(
            item_id=self.kwargs.get("item_pk")
        )

    def perform_create(self, serializer):
        serializer.save(item_id=self.kwargs.get("item_pk"))


# ═══════════════════════════════════════════════════════════════════
# CUSTOMER
# ═══════════════════════════════════════════════════════════════════

class CustomerGroupViewSet(viewsets.ModelViewSet):
    queryset = CustomerGroup.objects.all()
    serializer_class = CustomerGroupSerializer
    permission_classes = [IsAuthenticated]
    search_fields = ["code", "name"]


class CustomerViewSet(viewsets.ModelViewSet):
    queryset = Customer.objects.select_related(
        "customer_group", "assigned_rsm", "assigned_tsm", "assigned_zsm", "created_by"
    )
    permission_classes = [IsAuthenticated]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_class = CustomerFilter
    search_fields = ["code", "name", "gstin", "city", "contact_person"]
    ordering_fields = ["code", "name", "created_at", "credit_limit"]
    ordering = ["code"]

    def get_serializer_class(self):
        if self.action == "list":
            return CustomerListSerializer
        return CustomerDetailSerializer

    def perform_create(self, serializer):
        customer = serializer.save()
        _log_audit(self.request.user, "CREATE", "masters", "customer", customer.id,
                   new_vals={"code": customer.code, "name": customer.name})

    def perform_update(self, serializer):
        old_data = CustomerListSerializer(self.get_object()).data
        customer = serializer.save()
        _log_audit(self.request.user, "UPDATE", "masters", "customer", customer.id,
                   old_vals=old_data)

    @action(detail=False, methods=["post"], parser_classes=[MultiPartParser])
    def import_excel(self, request):
        """Import customers from Excel."""
        file = request.FILES.get("file")
        if not file:
            return Response({"error": "No file uploaded."}, status=400)

        try:
            wb = openpyxl.load_workbook(file, read_only=True)
            ws = wb.active
        except Exception as e:
            return Response({"error": f"Invalid Excel file: {str(e)}"}, status=400)

        headers = [cell.value for cell in next(ws.iter_rows(min_row=1, max_row=1))]
        results = {"created": 0, "updated": 0, "errors": []}

        for row_num, row in enumerate(ws.iter_rows(min_row=2, values_only=True), start=2):
            row_data = dict(zip(headers, row))
            ser = CustomerImportSerializer(data=row_data)
            if not ser.is_valid():
                results["errors"].append({"row": row_num, "errors": ser.errors})
                continue

            data = ser.validated_data
            group = None
            if data.get("customer_group_code"):
                group = CustomerGroup.objects.filter(code=data.pop("customer_group_code")).first()
            else:
                data.pop("customer_group_code", None)

            customer, created = Customer.objects.update_or_create(
                code=data.pop("code"),
                defaults={**data, "customer_group": group, "created_by": request.user},
            )
            if created:
                results["created"] += 1
            else:
                results["updated"] += 1

        return Response(results)

    @action(detail=False, methods=["get"])
    def export_excel(self, request):
        """Export customers to Excel."""
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Customers"

        headers = [
            "Code", "Name", "Type", "City", "State", "GSTIN",
            "Credit Days", "Credit Limit", "Phone", "Email", "Group",
            "Territory", "Portal Enabled",
        ]
        ws.append(headers)

        customers = self.filter_queryset(self.get_queryset())
        for c in customers:
            ws.append([
                c.code, c.name, c.customer_type, c.city, c.state,
                c.gstin, c.credit_days, float(c.credit_limit),
                c.phone, c.email,
                c.customer_group.code if c.customer_group else "",
                c.sales_territory, c.portal_enabled,
            ])

        for col in ws.columns:
            max_len = max(len(str(cell.value or "")) for cell in col)
            ws.column_dimensions[col[0].column_letter].width = min(max_len + 2, 40)

        buffer = io.BytesIO()
        wb.save(buffer)
        buffer.seek(0)
        response = HttpResponse(
            buffer.getvalue(),
            content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )
        response["Content-Disposition"] = 'attachment; filename="customers_export.xlsx"'
        return response

    @action(detail=True, methods=["get", "post"])
    def ship_addresses(self, request, pk=None):
        """Manage shipping addresses for a customer."""
        customer = self.get_object()
        if request.method == "GET":
            addresses = customer.ship_addresses.filter(is_active=True)
            return Response(CustomerShipAddressSerializer(addresses, many=True).data)
        else:
            ser = CustomerShipAddressSerializer(data=request.data)
            ser.is_valid(raise_exception=True)
            ser.save(customer=customer)
            return Response(ser.data, status=201)


# ═══════════════════════════════════════════════════════════════════
# PRICE LIST
# ═══════════════════════════════════════════════════════════════════

class PriceListViewSet(viewsets.ModelViewSet):
    queryset = PriceList.objects.all()
    serializer_class = PriceListSerializer
    permission_classes = [IsAuthenticated]
    filterset_fields = ["plant", "is_active"]
