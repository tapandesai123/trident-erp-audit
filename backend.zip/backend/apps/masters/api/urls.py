"""
Masters Module URL Configuration.
Registers all viewsets with the DRF router.
"""
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from apps.masters.api.viewsets import (
    VendorGroupViewSet, VendorViewSet,
    ItemGroupViewSet, UOMViewSet, ItemViewSet, ItemVendorLinkViewSet,
    CustomerGroupViewSet, CustomerViewSet,
    PriceListViewSet,
)

app_name = "masters"

router = DefaultRouter()
router.register(r"vendor-groups", VendorGroupViewSet, basename="vendor-group")
router.register(r"vendors", VendorViewSet, basename="vendor")
router.register(r"item-groups", ItemGroupViewSet, basename="item-group")
router.register(r"uoms", UOMViewSet, basename="uom")
router.register(r"items", ItemViewSet, basename="item")
router.register(r"customer-groups", CustomerGroupViewSet, basename="customer-group")
router.register(r"customers", CustomerViewSet, basename="customer")
router.register(r"price-lists", PriceListViewSet, basename="price-list")

# Nested: Item vendor links — /api/v1/masters/items/{item_pk}/vendor-links/
item_vendor_router = DefaultRouter()
item_vendor_router.register(r"vendor-links", ItemVendorLinkViewSet, basename="item-vendor-link")

urlpatterns = [
    path("", include(router.urls)),
    path("items/<int:item_pk>/", include(item_vendor_router.urls)),
]
