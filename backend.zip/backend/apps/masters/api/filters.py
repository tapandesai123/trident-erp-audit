"""
Django Filter classes for Masters module.
Provides advanced filtering for list views.
"""
import django_filters
from apps.masters.models import Vendor, Item, Customer


class VendorFilter(django_filters.FilterSet):
    name = django_filters.CharFilter(lookup_expr="icontains")
    code = django_filters.CharFilter(lookup_expr="istartswith")
    city = django_filters.CharFilter(lookup_expr="icontains")
    state = django_filters.CharFilter(lookup_expr="icontains")
    gstin = django_filters.CharFilter(lookup_expr="istartswith")
    vendor_type = django_filters.ChoiceFilter(choices=Vendor.VendorType.choices)
    gst_type = django_filters.ChoiceFilter(choices=Vendor.GSTType.choices)
    vendor_group = django_filters.NumberFilter()
    is_approved = django_filters.BooleanFilter()
    is_active = django_filters.BooleanFilter()
    tds_applicable = django_filters.BooleanFilter()
    msme_registered = django_filters.BooleanFilter()
    created_after = django_filters.DateFilter(field_name="created_at", lookup_expr="gte")
    created_before = django_filters.DateFilter(field_name="created_at", lookup_expr="lte")

    class Meta:
        model = Vendor
        fields = [
            "code", "name", "vendor_type", "gst_type", "vendor_group",
            "city", "state", "gstin", "is_approved", "is_active",
            "tds_applicable", "msme_registered",
        ]


class ItemFilter(django_filters.FilterSet):
    name = django_filters.CharFilter(lookup_expr="icontains")
    code = django_filters.CharFilter(lookup_expr="istartswith")
    item_type = django_filters.ChoiceFilter(choices=Item.ItemType.choices)
    item_group = django_filters.NumberFilter()
    approval_status = django_filters.ChoiceFilter(choices=Item.ApprovalStatus.choices)
    is_approved = django_filters.BooleanFilter()
    is_active = django_filters.BooleanFilter()
    hsn_code = django_filters.CharFilter(lookup_expr="istartswith")
    paper_type = django_filters.CharFilter()
    bf_rating = django_filters.NumberFilter()
    bf_rating_min = django_filters.NumberFilter(field_name="bf_rating", lookup_expr="gte")
    bf_rating_max = django_filters.NumberFilter(field_name="bf_rating", lookup_expr="lte")
    gsm = django_filters.NumberFilter()
    gsm_min = django_filters.NumberFilter(field_name="gsm", lookup_expr="gte")
    gsm_max = django_filters.NumberFilter(field_name="gsm", lookup_expr="lte")
    gst_rate = django_filters.NumberFilter()

    class Meta:
        model = Item
        fields = [
            "code", "name", "item_type", "item_group", "approval_status",
            "is_approved", "is_active", "hsn_code", "paper_type",
            "bf_rating", "gsm", "gst_rate",
        ]


class CustomerFilter(django_filters.FilterSet):
    name = django_filters.CharFilter(lookup_expr="icontains")
    code = django_filters.CharFilter(lookup_expr="istartswith")
    city = django_filters.CharFilter(lookup_expr="icontains")
    state = django_filters.CharFilter(lookup_expr="icontains")
    gstin = django_filters.CharFilter(lookup_expr="istartswith")
    customer_type = django_filters.ChoiceFilter(choices=Customer.CustomerType.choices)
    customer_group = django_filters.NumberFilter()
    sales_territory = django_filters.CharFilter(lookup_expr="icontains")
    sales_zone = django_filters.CharFilter(lookup_expr="icontains")
    sales_region = django_filters.CharFilter(lookup_expr="icontains")
    portal_enabled = django_filters.BooleanFilter()
    is_active = django_filters.BooleanFilter()
    assigned_rsm = django_filters.NumberFilter()
    assigned_tsm = django_filters.NumberFilter()
    credit_limit_min = django_filters.NumberFilter(field_name="credit_limit", lookup_expr="gte")
    credit_limit_max = django_filters.NumberFilter(field_name="credit_limit", lookup_expr="lte")

    class Meta:
        model = Customer
        fields = [
            "code", "name", "customer_type", "customer_group",
            "city", "state", "gstin", "sales_territory",
            "portal_enabled", "is_active",
        ]
