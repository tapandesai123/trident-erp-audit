"""
Masters Module Serializers.
Handles Vendor, Item, Customer CRUD with nested contacts/addresses,
GSTIN/PAN validation, item approval workflow, and Excel import format.
"""
from rest_framework import serializers
from django.utils import timezone

from apps.masters.models import (
    VendorGroup, Vendor, VendorContact,
    ItemGroup, UOM, Item, ItemAlternate, ItemVendorLink,
    CustomerGroup, Customer, CustomerShipAddress, CustomerContact,
    PriceList, PriceListItem,
)


# ═══════════════════════════════════════════════════════════════════
# VENDOR SERIALIZERS
# ═══════════════════════════════════════════════════════════════════

class VendorGroupSerializer(serializers.ModelSerializer):
    children_count = serializers.SerializerMethodField()

    class Meta:
        model = VendorGroup
        fields = ["id", "code", "name", "parent", "is_active", "children_count"]

    def get_children_count(self, obj):
        return obj.children.count()


class VendorContactSerializer(serializers.ModelSerializer):
    class Meta:
        model = VendorContact
        fields = ["id", "name", "designation", "phone", "mobile", "email", "is_primary"]


class VendorListSerializer(serializers.ModelSerializer):
    """Lightweight serializer for list views."""
    vendor_group_name = serializers.CharField(source="vendor_group.name", read_only=True, default="")
    vendor_type_display = serializers.CharField(source="get_vendor_type_display", read_only=True)
    gst_type_display = serializers.CharField(source="get_gst_type_display", read_only=True)

    class Meta:
        model = Vendor
        fields = [
            "id", "uuid", "code", "name", "vendor_type", "vendor_type_display",
            "city", "state", "gstin", "gst_type", "gst_type_display",
            "vendor_group", "vendor_group_name",
            "is_approved", "is_active", "delivery_rating",
        ]


class VendorDetailSerializer(serializers.ModelSerializer):
    """Full serializer for detail/create/update views.

    Sensitive financial fields (bank_account, pan, bank_ifsc, tds_rate, tds_section,
    tds_applicable) are hidden from users who do not hold a Finance or Admin role.
    BUG-010 fix: prevents exposure of banking/PAN data to non-finance users.
    """
    contacts = VendorContactSerializer(many=True, required=False)
    vendor_group_name = serializers.CharField(source="vendor_group.name", read_only=True, default="")
    vendor_type_display = serializers.CharField(source="get_vendor_type_display", read_only=True)
    gst_type_display = serializers.CharField(source="get_gst_type_display", read_only=True)
    state_code = serializers.CharField(read_only=True)
    created_by_name = serializers.CharField(source="created_by.get_full_name", read_only=True, default="")
    approved_by_name = serializers.CharField(source="approved_by.get_full_name", read_only=True, default="")

    # Sensitive fields shown only to Finance/Admin roles (BUG-010)
    FINANCE_ONLY_FIELDS = {"bank_account", "bank_ifsc", "pan", "tds_applicable", "tds_section", "tds_rate"}

    class Meta:
        model = Vendor
        fields = "__all__"
        read_only_fields = [
            "uuid", "delivery_rating", "is_approved", "approved_by",
            "approved_at", "created_by", "updated_by", "created_at", "updated_at",
        ]

    def _user_has_finance_access(self):
        """Return True if the current request user is Finance/Admin."""
        request = self.context.get("request")
        if not request or not hasattr(request, "user"):
            return False
        user = request.user
        if user.is_superuser or user.is_staff:
            return True
        # Check via the Role system: any role whose name contains 'Finance' or 'Admin'
        return user.roles.filter(
            name__icontains="finance", is_active=True
        ).exists() or user.roles.filter(
            name__icontains="admin", is_active=True
        ).exists()

    def to_representation(self, instance):
        data = super().to_representation(instance)
        if not self._user_has_finance_access():
            for field in self.FINANCE_ONLY_FIELDS:
                data.pop(field, None)
        return data

    def validate_gstin(self, value):
        if value and self.instance:
            qs = Vendor.objects.filter(gstin=value).exclude(pk=self.instance.pk)
            if qs.exists():
                raise serializers.ValidationError(f"GSTIN {value} already exists for vendor {qs.first().code}.")
        elif value:
            if Vendor.objects.filter(gstin=value).exists():
                raise serializers.ValidationError(f"GSTIN {value} already registered.")
        return value

    def validate(self, attrs):
        gst_type = attrs.get("gst_type", getattr(self.instance, "gst_type", "REGULAR"))
        gstin = attrs.get("gstin", getattr(self.instance, "gstin", ""))

        if gst_type in ("REGULAR", "COMPOSITION") and not gstin:
            raise serializers.ValidationError(
                {"gstin": "GSTIN is required for Regular/Composition vendors."}
            )

        if attrs.get("tds_applicable") and not attrs.get("tds_section"):
            tds_section = getattr(self.instance, "tds_section", "") if self.instance else ""
            if not tds_section:
                raise serializers.ValidationError(
                    {"tds_section": "TDS section is required when TDS is applicable."}
                )
        return attrs

    def create(self, validated_data):
        contacts_data = validated_data.pop("contacts", [])
        request = self.context.get("request")
        if request and request.user:
            validated_data["created_by"] = request.user
        vendor = Vendor.objects.create(**validated_data)
        for contact_data in contacts_data:
            VendorContact.objects.create(vendor=vendor, **contact_data)
        return vendor

    def update(self, instance, validated_data):
        contacts_data = validated_data.pop("contacts", None)
        request = self.context.get("request")
        if request and request.user:
            validated_data["updated_by"] = request.user

        for attr, value in validated_data.items():
            setattr(instance, attr, value)
        instance.save()

        if contacts_data is not None:
            instance.contacts.all().delete()
            for contact_data in contacts_data:
                VendorContact.objects.create(vendor=instance, **contact_data)

        return instance


class VendorApprovalSerializer(serializers.Serializer):
    """Approve or reject a vendor."""
    action = serializers.ChoiceField(choices=["approve", "reject"])
    remarks = serializers.CharField(required=False, allow_blank=True)


class VendorImportSerializer(serializers.Serializer):
    """Serializer for Excel import validation."""
    code = serializers.CharField(max_length=20)
    name = serializers.CharField(max_length=200)
    vendor_type = serializers.ChoiceField(choices=Vendor.VendorType.choices, default="SUPPLIER")
    address_line1 = serializers.CharField(max_length=300, required=False, allow_blank=True)
    city = serializers.CharField(max_length=100, required=False, allow_blank=True)
    state = serializers.CharField(max_length=100, required=False, allow_blank=True)
    pincode = serializers.CharField(max_length=10, required=False, allow_blank=True)
    phone = serializers.CharField(max_length=20, required=False, allow_blank=True)
    email = serializers.EmailField(required=False, allow_blank=True)
    gstin = serializers.CharField(max_length=15, required=False, allow_blank=True)
    pan = serializers.CharField(max_length=10, required=False, allow_blank=True)
    gst_type = serializers.ChoiceField(choices=Vendor.GSTType.choices, default="REGULAR")
    tds_applicable = serializers.BooleanField(default=False)
    tds_section = serializers.CharField(max_length=10, required=False, allow_blank=True)
    tds_rate = serializers.DecimalField(max_digits=5, decimal_places=2, default=0)
    credit_days = serializers.IntegerField(default=30)
    vendor_group_code = serializers.CharField(max_length=20, required=False, allow_blank=True)


# ═══════════════════════════════════════════════════════════════════
# ITEM SERIALIZERS
# ═══════════════════════════════════════════════════════════════════

class ItemGroupSerializer(serializers.ModelSerializer):
    children_count = serializers.SerializerMethodField()
    items_count = serializers.SerializerMethodField()

    class Meta:
        model = ItemGroup
        fields = ["id", "code", "name", "parent", "item_type", "is_active", "children_count", "items_count"]

    def get_children_count(self, obj):
        return obj.children.count()

    def get_items_count(self, obj):
        return obj.items.count()


class UOMSerializer(serializers.ModelSerializer):
    class Meta:
        model = UOM
        fields = ["id", "code", "name", "decimal_places"]


class ItemVendorLinkSerializer(serializers.ModelSerializer):
    vendor_name = serializers.CharField(source="vendor.name", read_only=True)
    vendor_code = serializers.CharField(source="vendor.code", read_only=True)

    class Meta:
        model = ItemVendorLink
        fields = [
            "id", "vendor", "vendor_code", "vendor_name", "is_preferred",
            "last_rate", "last_po_date", "last_po_number",
            "min_order_qty", "lead_time_days", "remarks",
        ]


class ItemListSerializer(serializers.ModelSerializer):
    """Lightweight for list views."""
    item_group_name = serializers.CharField(source="item_group.name", read_only=True)
    uom_code = serializers.CharField(source="uom.code", read_only=True)
    item_type_display = serializers.CharField(source="get_item_type_display", read_only=True)
    approval_status_display = serializers.CharField(source="get_approval_status_display", read_only=True)

    class Meta:
        model = Item
        fields = [
            "id", "uuid", "code", "name", "item_type", "item_type_display",
            "item_group", "item_group_name", "uom", "uom_code",
            "hsn_code", "gst_rate", "min_stock", "max_stock",
            "bf_rating", "gsm", "deckle_mm", "paper_type",
            "approval_status", "approval_status_display",
            "is_approved", "is_active",
        ]


class ItemDetailSerializer(serializers.ModelSerializer):
    """Full serializer with nested vendor links."""
    vendor_links = ItemVendorLinkSerializer(many=True, read_only=True)
    item_group_name = serializers.CharField(source="item_group.name", read_only=True)
    uom_code = serializers.CharField(source="uom.code", read_only=True)
    secondary_uom_code = serializers.CharField(source="secondary_uom.code", read_only=True, default="")
    item_type_display = serializers.CharField(source="get_item_type_display", read_only=True)
    approval_status_display = serializers.CharField(source="get_approval_status_display", read_only=True)
    created_by_name = serializers.CharField(source="created_by.get_full_name", read_only=True, default="")
    approved_by_name = serializers.CharField(source="approved_by.get_full_name", read_only=True, default="")
    is_paper = serializers.BooleanField(read_only=True)

    class Meta:
        model = Item
        fields = "__all__"
        read_only_fields = [
            "uuid", "is_approved", "approved_by", "approved_at",
            "approval_status", "rejection_reason", "created_by", "updated_by",
            "created_at", "updated_at",
        ]

    def validate(self, attrs):
        item_type = attrs.get("item_type", getattr(self.instance, "item_type", ""))
        paper_type = attrs.get("paper_type", getattr(self.instance, "paper_type", ""))

        # Paper RM items must have BF, GSM
        if item_type == "RAW_MATERIAL" and paper_type:
            if not attrs.get("bf_rating") and not getattr(self.instance, "bf_rating", None):
                raise serializers.ValidationError({"bf_rating": "BF rating is required for paper items."})
            if not attrs.get("gsm") and not getattr(self.instance, "gsm", None):
                raise serializers.ValidationError({"gsm": "GSM is required for paper items."})

        # BUG-012: ply_count must be 3, 5, or 7 (corrugated board specification)
        ply_count = attrs.get("ply_count")
        if ply_count is not None and ply_count not in (3, 5, 7):
            raise serializers.ValidationError(
                {"ply_count": "Ply count must be 3, 5, or 7."}
            )

        return attrs

    def create(self, validated_data):
        request = self.context.get("request")
        if request and request.user:
            validated_data["created_by"] = request.user
            # Item enters as DRAFT, needs separate approval
            validated_data["approval_status"] = "PENDING"
        return super().create(validated_data)

    def update(self, instance, validated_data):
        request = self.context.get("request")
        if request and request.user:
            validated_data["updated_by"] = request.user
        return super().update(instance, validated_data)


class ItemApprovalSerializer(serializers.Serializer):
    """Approve or reject an item code."""
    action = serializers.ChoiceField(choices=["approve", "reject"])
    rejection_reason = serializers.CharField(required=False, allow_blank=True)


class ItemImportSerializer(serializers.Serializer):
    """For Excel import of items."""
    code = serializers.CharField(max_length=30)
    name = serializers.CharField(max_length=300)
    item_type = serializers.ChoiceField(choices=Item.ItemType.choices)
    item_group_code = serializers.CharField(max_length=20)
    uom_code = serializers.CharField(max_length=10)
    hsn_code = serializers.CharField(max_length=10, required=False, allow_blank=True)
    gst_rate = serializers.DecimalField(max_digits=5, decimal_places=2, default=18.00)
    min_stock = serializers.DecimalField(max_digits=15, decimal_places=3, default=0)
    max_stock = serializers.DecimalField(max_digits=15, decimal_places=3, default=0)
    bf_rating = serializers.IntegerField(required=False, allow_null=True)
    gsm = serializers.IntegerField(required=False, allow_null=True)
    deckle_mm = serializers.DecimalField(max_digits=10, decimal_places=2, required=False, allow_null=True)
    paper_type = serializers.CharField(max_length=50, required=False, allow_blank=True)


# ═══════════════════════════════════════════════════════════════════
# CUSTOMER SERIALIZERS
# ═══════════════════════════════════════════════════════════════════

class CustomerGroupSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomerGroup
        fields = ["id", "code", "name", "parent", "is_active"]


class CustomerShipAddressSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomerShipAddress
        fields = [
            "id", "label", "address_line1", "address_line2",
            "city", "state", "pincode", "gstin",
            "contact_person", "phone", "is_default", "is_active",
        ]


class CustomerContactSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomerContact
        fields = ["id", "name", "designation", "phone", "mobile", "email", "department", "is_primary"]


class CustomerListSerializer(serializers.ModelSerializer):
    customer_group_name = serializers.CharField(source="customer_group.name", read_only=True, default="")
    customer_type_display = serializers.CharField(source="get_customer_type_display", read_only=True)

    class Meta:
        model = Customer
        fields = [
            "id", "uuid", "code", "name", "customer_type", "customer_type_display",
            "city", "state", "gstin", "customer_group", "customer_group_name",
            "credit_days", "credit_limit", "sales_territory", "portal_enabled",
            "is_active",
        ]


class CustomerDetailSerializer(serializers.ModelSerializer):
    ship_addresses = CustomerShipAddressSerializer(many=True, required=False)
    contacts = CustomerContactSerializer(many=True, required=False)
    customer_group_name = serializers.CharField(source="customer_group.name", read_only=True, default="")
    customer_type_display = serializers.CharField(source="get_customer_type_display", read_only=True)
    state_code = serializers.CharField(read_only=True)
    assigned_rsm_name = serializers.CharField(source="assigned_rsm.get_full_name", read_only=True, default="")
    assigned_tsm_name = serializers.CharField(source="assigned_tsm.get_full_name", read_only=True, default="")
    assigned_zsm_name = serializers.CharField(source="assigned_zsm.get_full_name", read_only=True, default="")

    class Meta:
        model = Customer
        fields = "__all__"
        read_only_fields = [
            "uuid", "portal_user", "created_by", "updated_by", "created_at", "updated_at",
        ]

    def validate_gstin(self, value):
        if value and self.instance:
            qs = Customer.objects.filter(gstin=value).exclude(pk=self.instance.pk)
            if qs.exists():
                raise serializers.ValidationError(f"GSTIN {value} already exists for customer {qs.first().code}.")
        elif value:
            if Customer.objects.filter(gstin=value).exists():
                raise serializers.ValidationError(f"GSTIN {value} already registered.")
        return value

    def create(self, validated_data):
        addresses_data = validated_data.pop("ship_addresses", [])
        contacts_data = validated_data.pop("contacts", [])
        request = self.context.get("request")
        if request and request.user:
            validated_data["created_by"] = request.user

        customer = Customer.objects.create(**validated_data)

        for addr_data in addresses_data:
            CustomerShipAddress.objects.create(customer=customer, **addr_data)
        for contact_data in contacts_data:
            CustomerContact.objects.create(customer=customer, **contact_data)

        return customer

    def update(self, instance, validated_data):
        addresses_data = validated_data.pop("ship_addresses", None)
        contacts_data = validated_data.pop("contacts", None)
        request = self.context.get("request")
        if request and request.user:
            validated_data["updated_by"] = request.user

        for attr, value in validated_data.items():
            setattr(instance, attr, value)
        instance.save()

        if addresses_data is not None:
            instance.ship_addresses.all().delete()
            for addr_data in addresses_data:
                CustomerShipAddress.objects.create(customer=instance, **addr_data)

        if contacts_data is not None:
            instance.contacts.all().delete()
            for contact_data in contacts_data:
                CustomerContact.objects.create(customer=instance, **contact_data)

        return instance


class CustomerImportSerializer(serializers.Serializer):
    code = serializers.CharField(max_length=20)
    name = serializers.CharField(max_length=200)
    customer_type = serializers.ChoiceField(choices=Customer.CustomerType.choices, default="DIRECT")
    address_line1 = serializers.CharField(max_length=300, required=False, allow_blank=True)
    city = serializers.CharField(max_length=100, required=False, allow_blank=True)
    state = serializers.CharField(max_length=100, required=False, allow_blank=True)
    pincode = serializers.CharField(max_length=10, required=False, allow_blank=True)
    phone = serializers.CharField(max_length=20, required=False, allow_blank=True)
    email = serializers.EmailField(required=False, allow_blank=True)
    gstin = serializers.CharField(max_length=15, required=False, allow_blank=True)
    pan = serializers.CharField(max_length=10, required=False, allow_blank=True)
    gst_type = serializers.ChoiceField(choices=Vendor.GSTType.choices, default="REGULAR")
    credit_days = serializers.IntegerField(default=30)
    credit_limit = serializers.DecimalField(max_digits=15, decimal_places=2, default=0)
    customer_group_code = serializers.CharField(max_length=20, required=False, allow_blank=True)


# ═══════════════════════════════════════════════════════════════════
# PRICE LIST SERIALIZERS
# ═══════════════════════════════════════════════════════════════════

class PriceListItemSerializer(serializers.ModelSerializer):
    item_code = serializers.CharField(source="item.code", read_only=True)
    item_name = serializers.CharField(source="item.name", read_only=True)

    class Meta:
        model = PriceListItem
        fields = [
            "id", "item", "item_code", "item_name",
            "customer_group", "customer", "rate", "min_qty", "discount_pct",
        ]


class PriceListSerializer(serializers.ModelSerializer):
    items = PriceListItemSerializer(many=True, required=False)

    class Meta:
        model = PriceList
        fields = ["id", "name", "plant", "effective_from", "effective_to", "is_active", "items"]
