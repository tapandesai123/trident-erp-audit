from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('masters', '0001_initial'),
    ]

    operations = [
        migrations.AddField(
            model_name='item',
            name='box_length_mm',
            field=models.DecimalField(blank=True, decimal_places=2, help_text='Internal length (mm)', max_digits=10, null=True),
        ),
        migrations.AddField(
            model_name='item',
            name='box_width_mm',
            field=models.DecimalField(blank=True, decimal_places=2, help_text='Internal width (mm)', max_digits=10, null=True),
        ),
        migrations.AddField(
            model_name='item',
            name='box_height_mm',
            field=models.DecimalField(blank=True, decimal_places=2, help_text='Internal height (mm)', max_digits=10, null=True),
        ),
        migrations.AddField(
            model_name='item',
            name='box_type',
            field=models.CharField(blank=True, choices=[('RSC', 'Regular Slotted Container (RSC)'), ('HSC', 'Half Slotted Container (HSC)'), ('TOP_BOTTOM', 'Top & Bottom'), ('DIE_CUT', 'Die Cut'), ('OTHER', 'Other')], default='', max_length=20),
        ),
        migrations.AddField(
            model_name='item',
            name='ply_count',
            field=models.PositiveSmallIntegerField(blank=True, help_text='Number of plies (3-ply, 5-ply, etc.)', null=True),
        ),
        migrations.AddField(
            model_name='item',
            name='box_weight_kg',
            field=models.DecimalField(blank=True, decimal_places=3, help_text='Weight of one box (kg)', max_digits=8, null=True),
        ),
    ]
