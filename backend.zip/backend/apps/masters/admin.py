"""Django Admin configuration for Masters module."""
from django.contrib import admin
from apps.masters.models import (
    VendorGroup, Vendor, VendorContact,
    ItemGroup, UOM, Item, ItemAlternate, ItemVendorLink,
    CustomerGroup, Customer, CustomerShipAddress, CustomerContact,
    PriceList, PriceListItem,
)


# ─── Vendor ────────────────────────────────────────────────────────

class VendorContactInline(admin.TabularInline):
    model = VendorContact
    extra = 0


@admin.register(VendorGroup)
class VendorGroupAdmin(admin.ModelAdmin):
    list_display = ["code", "name", "parent", "is_active"]
    list_filter = ["is_active"]
    search_fields = ["code", "name"]


@admin.register(Vendor)
class VendorAdmin(admin.ModelAdmin):
    list_display = [
        "code", "name", "vendor_type", "city", "state",
        "gstin", "gst_type", "is_approved", "is_active",
    ]
    list_filter = ["vendor_type", "gst_type", "is_approved", "is_active", "vendor_group"]
    search_fields = ["code", "name", "gstin", "city"]
    readonly_fields = ["uuid", "delivery_rating", "created_at", "updated_at"]
    inlines = [VendorContactInline]
    fieldsets = (
        ("Identity", {"fields": ("code", "name", "legal_name", "vendor_group", "vendor_type")}),
        ("Address", {"fields": ("address_line1", "address_line2", "city", "state", "pincode", "country")}),
        ("Contact", {"fields": ("phone", "mobile", "email", "website", "contact_person")}),
        ("Tax & Statutory", {"fields": (
            "gstin", "pan", "gst_type", "tds_applicable", "tds_section", "tds_rate",
            "tcs_applicable", "tcs_rate", "msme_registered", "msme_number", "msme_type",
        )}),
        ("Bank Details", {"fields": ("bank_name", "bank_account", "bank_ifsc", "bank_branch")}),
        ("Commercial", {"fields": ("credit_days", "credit_limit", "payment_terms", "delivery_rating")}),
        ("Approval", {"fields": ("is_approved", "approved_by", "approved_at")}),
        ("Status", {"fields": ("is_active", "notes")}),
        ("Meta", {"fields": ("uuid", "created_by", "updated_by", "created_at", "updated_at")}),
    )


# ─── Item ──────────────────────────────────────────────────────────

class ItemVendorLinkInline(admin.TabularInline):
    model = ItemVendorLink
    extra = 0
    raw_id_fields = ["vendor"]


@admin.register(ItemGroup)
class ItemGroupAdmin(admin.ModelAdmin):
    list_display = ["code", "name", "item_type", "parent", "is_active"]
    list_filter = ["item_type", "is_active"]
    search_fields = ["code", "name"]


@admin.register(UOM)
class UOMAdmin(admin.ModelAdmin):
    list_display = ["code", "name", "decimal_places"]


@admin.register(Item)
class ItemAdmin(admin.ModelAdmin):
    list_display = [
        "code", "name", "item_type", "item_group", "uom",
        "hsn_code", "gst_rate", "approval_status", "is_active",
    ]
    list_filter = ["item_type", "approval_status", "is_active", "item_group", "paper_type"]
    search_fields = ["code", "name", "hsn_code"]
    readonly_fields = ["uuid", "created_at", "updated_at"]
    inlines = [ItemVendorLinkInline]
    fieldsets = (
        ("Identity", {"fields": ("code", "name", "description", "item_group", "item_type")}),
        ("UOM", {"fields": ("uom", "secondary_uom", "conversion_factor")}),
        ("Tax", {"fields": ("hsn_code", "gst_rate")}),
        ("Stock Parameters", {"fields": ("pack_size", "min_stock", "max_stock", "reorder_level", "lead_time_days", "shelf_life_days")}),
        ("Paper Specs", {"fields": ("paper_type", "bf_rating", "gsm", "deckle_mm"), "classes": ("collapse",)}),
        ("Approval", {"fields": ("approval_status", "is_approved", "approved_by", "approved_at", "rejection_reason")}),
        ("Status", {"fields": ("is_active",)}),
        ("Meta", {"fields": ("uuid", "created_by", "updated_by", "created_at", "updated_at")}),
    )


# ─── Customer ─────────────────────────────────────────────────────

class CustomerShipAddressInline(admin.TabularInline):
    model = CustomerShipAddress
    extra = 0


class CustomerContactInline(admin.TabularInline):
    model = CustomerContact
    extra = 0


@admin.register(CustomerGroup)
class CustomerGroupAdmin(admin.ModelAdmin):
    list_display = ["code", "name", "parent", "is_active"]


@admin.register(Customer)
class CustomerAdmin(admin.ModelAdmin):
    list_display = [
        "code", "name", "customer_type", "city", "state",
        "gstin", "credit_days", "portal_enabled", "is_active",
    ]
    list_filter = ["customer_type", "is_active", "portal_enabled", "customer_group"]
    search_fields = ["code", "name", "gstin", "city"]
    readonly_fields = ["uuid", "created_at", "updated_at"]
    inlines = [CustomerShipAddressInline, CustomerContactInline]
    fieldsets = (
        ("Identity", {"fields": ("code", "name", "legal_name", "customer_group", "customer_type")}),
        ("Address", {"fields": ("address_line1", "address_line2", "city", "state", "pincode", "country")}),
        ("Contact", {"fields": ("phone", "mobile", "email", "website", "contact_person")}),
        ("Tax", {"fields": ("gstin", "pan", "gst_type")}),
        ("Commercial", {"fields": ("credit_days", "credit_limit", "payment_terms")}),
        ("Sales Hierarchy", {"fields": ("sales_region", "sales_zone", "sales_territory", "assigned_rsm", "assigned_tsm", "assigned_zsm")}),
        ("Portal", {"fields": ("portal_enabled", "portal_user")}),
        ("Status", {"fields": ("is_active", "notes")}),
        ("Meta", {"fields": ("uuid", "created_by", "updated_by", "created_at", "updated_at")}),
    )


@admin.register(PriceList)
class PriceListAdmin(admin.ModelAdmin):
    list_display = ["name", "plant", "effective_from", "effective_to", "is_active"]
