"""
Tests for the Masters module.
Covers: Vendor CRUD, Item CRUD & approval workflow, Customer CRUD,
Excel import/export, GSTIN validation, paper name auto-generation.
"""
import io
import pytest
from decimal import Decimal
from django.test import TestCase
from django.urls import reverse
from rest_framework.test import APIClient
from rest_framework import status

from apps.core.models import Company, Plant, Department, User, Role
from apps.masters.models import (
    VendorGroup, Vendor, ItemGroup, UOM, Item,
    CustomerGroup, Customer, CustomerShipAddress,
)


class MasterDataMixin:
    """Shared setup for masters tests."""

    @classmethod
    def setUpTestData(cls):
        cls.company = Company.objects.create(name="Test Co", gstin="24AAKFT4708J2ZY")
        cls.plant = Plant.objects.create(
            company=cls.company, code="TEST", name="Test Plant",
            city="Vapi", state="Gujarat",
        )
        cls.dept = Department.objects.create(plant=cls.plant, code="PURCHASE", name="Purchase")

        cls.user1 = User.objects.create_user(
            username="creator", email="creator@test.com", password="Test@1234",
            plant=cls.plant, department=cls.dept,
        )
        cls.user2 = User.objects.create_user(
            username="approver", email="approver@test.com", password="Test@1234",
            plant=cls.plant, department=cls.dept,
        )
        cls.admin_user = User.objects.create_superuser(
            username="admin", email="admin@test.com", password="Admin@1234",
        )

        cls.vendor_group = VendorGroup.objects.create(code="CR-PAPER", name="Creditors Paper")
        cls.uom_kg = UOM.objects.create(code="KG", name="Kilograms", decimal_places=3)
        cls.uom_nos = UOM.objects.create(code="NOS", name="Numbers", decimal_places=0)
        cls.item_group = ItemGroup.objects.create(code="07", name="Kraft Paper", item_type="RAW_MATERIAL")
        cls.fg_group = ItemGroup.objects.create(code="50", name="3-Ply Boxes", item_type="FINISHED_GOOD")
        cls.customer_group = CustomerGroup.objects.create(code="DIRECT", name="Direct Customers")


class VendorModelTest(MasterDataMixin, TestCase):
    def test_create_vendor(self):
        vendor = Vendor.objects.create(
            code="V001", name="Paper Mill Ltd",
            vendor_group=self.vendor_group,
            vendor_type=Vendor.VendorType.SUPPLIER,
            gstin="24AABCP1234M1Z5",
            gst_type=Vendor.GSTType.REGULAR,
            city="Vapi", state="Gujarat",
            created_by=self.user1,
        )
        self.assertEqual(vendor.state_code, "24")
        self.assertEqual(str(vendor), "V001 - Paper Mill Ltd")
        self.assertFalse(vendor.is_approved)

    def test_gstin_state_code(self):
        vendor = Vendor(gstin="27AABCP1234M1Z5")
        self.assertEqual(vendor.state_code, "27")

    def test_empty_gstin_state_code(self):
        vendor = Vendor(gstin="")
        self.assertEqual(vendor.state_code, "")


class ItemModelTest(MasterDataMixin, TestCase):
    def test_paper_auto_name(self):
        """Paper RM items should auto-generate names from specs."""
        item = Item.objects.create(
            code="RM-07-001",
            name="placeholder",
            item_group=self.item_group,
            item_type=Item.ItemType.RAW_MATERIAL,
            uom=self.uom_kg,
            paper_type="KRAFT",
            bf_rating=18,
            gsm=150,
            deckle_mm=Decimal("1200.00"),
            created_by=self.user1,
        )
        self.assertEqual(item.name, "Kraft BF18 150GSM 1200.00mm")

    def test_non_paper_keeps_name(self):
        item = Item.objects.create(
            code="CON-001",
            name="Printing Ink Black",
            item_group=self.item_group,
            item_type=Item.ItemType.CONSUMABLE,
            uom=self.uom_kg,
            created_by=self.user1,
        )
        self.assertEqual(item.name, "Printing Ink Black")

    def test_unique_paper_spec_constraint(self):
        """Two paper items with same specs should fail."""
        Item.objects.create(
            code="RM-07-001", name="test", item_group=self.item_group,
            item_type=Item.ItemType.RAW_MATERIAL, uom=self.uom_kg,
            paper_type="KRAFT", bf_rating=18, gsm=150, deckle_mm=Decimal("1200"),
            created_by=self.user1,
        )
        from django.db import IntegrityError
        with self.assertRaises(IntegrityError):
            Item.objects.create(
                code="RM-07-002", name="test2", item_group=self.item_group,
                item_type=Item.ItemType.RAW_MATERIAL, uom=self.uom_kg,
                paper_type="KRAFT", bf_rating=18, gsm=150, deckle_mm=Decimal("1200"),
                created_by=self.user1,
            )

    def test_default_approval_status(self):
        item = Item.objects.create(
            code="RM-07-010", name="test", item_group=self.item_group,
            item_type=Item.ItemType.RAW_MATERIAL, uom=self.uom_kg,
            created_by=self.user1,
        )
        self.assertEqual(item.approval_status, "DRAFT")
        self.assertFalse(item.is_approved)


class VendorAPITest(MasterDataMixin, TestCase):
    def setUp(self):
        self.client = APIClient()
        self.client.force_authenticate(user=self.admin_user)

    def test_list_vendors(self):
        Vendor.objects.create(code="V001", name="Vendor A", created_by=self.user1)
        resp = self.client.get("/api/v1/masters/vendors/")
        self.assertEqual(resp.status_code, 200)
        self.assertGreaterEqual(resp.data["count"], 1)

    def test_create_vendor(self):
        data = {
            "code": "V100",
            "name": "New Paper Mill",
            "vendor_type": "SUPPLIER",
            "gst_type": "UNREGISTERED",
            "city": "Vapi",
            "state": "Gujarat",
        }
        resp = self.client.post("/api/v1/masters/vendors/", data, format="json")
        self.assertEqual(resp.status_code, 201)
        self.assertEqual(resp.data["code"], "V100")

    def test_create_vendor_requires_gstin_for_regular(self):
        data = {
            "code": "V101",
            "name": "Regular Vendor",
            "vendor_type": "SUPPLIER",
            "gst_type": "REGULAR",
            "city": "Mumbai",
        }
        resp = self.client.post("/api/v1/masters/vendors/", data, format="json")
        self.assertEqual(resp.status_code, 400)

    def test_approve_vendor(self):
        vendor = Vendor.objects.create(code="V200", name="To Approve", created_by=self.user1)
        resp = self.client.post(
            f"/api/v1/masters/vendors/{vendor.pk}/approve/",
            {"action": "approve"}, format="json",
        )
        self.assertEqual(resp.status_code, 200)
        vendor.refresh_from_db()
        self.assertTrue(vendor.is_approved)

    def test_search_vendors(self):
        Vendor.objects.create(code="V300", name="ABC Paper Mills", created_by=self.user1)
        Vendor.objects.create(code="V301", name="XYZ Ink Co", created_by=self.user1)
        resp = self.client.get("/api/v1/masters/vendors/?search=paper")
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(resp.data["count"], 1)

    def test_filter_by_type(self):
        Vendor.objects.create(code="V400", name="Transport Co", vendor_type="TRANSPORTER", created_by=self.user1)
        Vendor.objects.create(code="V401", name="Supplier Co", vendor_type="SUPPLIER", created_by=self.user1)
        resp = self.client.get("/api/v1/masters/vendors/?vendor_type=TRANSPORTER")
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(resp.data["count"], 1)


class ItemAPITest(MasterDataMixin, TestCase):
    def setUp(self):
        self.client = APIClient()

    def test_create_item_enters_as_pending(self):
        self.client.force_authenticate(user=self.user1)
        data = {
            "code": "RM-001",
            "name": "Test Paper",
            "item_type": "RAW_MATERIAL",
            "item_group": self.item_group.pk,
            "uom": self.uom_kg.pk,
            "gst_rate": "18.00",
        }
        resp = self.client.post("/api/v1/masters/items/", data, format="json")
        self.assertEqual(resp.status_code, 201)
        self.assertEqual(resp.data["approval_status"], "PENDING")

    def test_approval_by_different_user(self):
        """Item created by user1 should be approved by user2 (not user1)."""
        self.client.force_authenticate(user=self.user1)
        item = Item.objects.create(
            code="RM-002", name="Test", item_group=self.item_group,
            item_type="RAW_MATERIAL", uom=self.uom_kg,
            approval_status="PENDING", created_by=self.user1,
        )

        # user1 tries to approve own item → should fail
        resp = self.client.post(
            f"/api/v1/masters/items/{item.pk}/approve/",
            {"action": "approve"}, format="json",
        )
        self.assertEqual(resp.status_code, 403)

        # user2 approves → should succeed
        self.client.force_authenticate(user=self.user2)
        resp = self.client.post(
            f"/api/v1/masters/items/{item.pk}/approve/",
            {"action": "approve"}, format="json",
        )
        self.assertEqual(resp.status_code, 200)
        item.refresh_from_db()
        self.assertTrue(item.is_approved)
        self.assertEqual(item.approval_status, "APPROVED")
        self.assertEqual(item.approved_by, self.user2)

    def test_reject_item_with_reason(self):
        self.client.force_authenticate(user=self.user2)
        item = Item.objects.create(
            code="RM-003", name="Bad Item", item_group=self.item_group,
            item_type="RAW_MATERIAL", uom=self.uom_kg,
            approval_status="PENDING", created_by=self.user1,
        )
        resp = self.client.post(
            f"/api/v1/masters/items/{item.pk}/approve/",
            {"action": "reject", "rejection_reason": "Wrong HSN code"},
            format="json",
        )
        self.assertEqual(resp.status_code, 200)
        item.refresh_from_db()
        self.assertEqual(item.approval_status, "REJECTED")
        self.assertEqual(item.rejection_reason, "Wrong HSN code")

    def test_pending_approval_list(self):
        self.client.force_authenticate(user=self.admin_user)
        Item.objects.create(
            code="RM-010", name="Pending1", item_group=self.item_group,
            item_type="RAW_MATERIAL", uom=self.uom_kg, approval_status="PENDING",
        )
        Item.objects.create(
            code="RM-011", name="Approved1", item_group=self.item_group,
            item_type="RAW_MATERIAL", uom=self.uom_kg, approval_status="APPROVED",
        )
        resp = self.client.get("/api/v1/masters/items/pending_approval/")
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(resp.data["count"], 1)


class CustomerAPITest(MasterDataMixin, TestCase):
    def setUp(self):
        self.client = APIClient()
        self.client.force_authenticate(user=self.admin_user)

    def test_create_customer_with_addresses(self):
        data = {
            "code": "C001",
            "name": "ABC Industries",
            "customer_type": "DIRECT",
            "customer_group": self.customer_group.pk,
            "city": "Ahmedabad",
            "state": "Gujarat",
            "ship_addresses": [
                {
                    "label": "Factory",
                    "address_line1": "123 Industrial Area",
                    "city": "Ahmedabad",
                    "state": "Gujarat",
                    "pincode": "380015",
                    "is_default": True,
                },
                {
                    "label": "Warehouse",
                    "address_line1": "456 GIDC",
                    "city": "Vadodara",
                    "state": "Gujarat",
                    "pincode": "390010",
                },
            ],
        }
        resp = self.client.post("/api/v1/masters/customers/", data, format="json")
        self.assertEqual(resp.status_code, 201)
        customer = Customer.objects.get(code="C001")
        self.assertEqual(customer.ship_addresses.count(), 2)
        self.assertEqual(customer.ship_addresses.filter(is_default=True).count(), 1)

    def test_duplicate_gstin_rejected(self):
        Customer.objects.create(
            code="C100", name="Existing", gstin="24AABCP1234M1Z5",
            created_by=self.admin_user,
        )
        data = {
            "code": "C101",
            "name": "Duplicate GSTIN",
            "gstin": "24AABCP1234M1Z5",
        }
        resp = self.client.post("/api/v1/masters/customers/", data, format="json")
        self.assertEqual(resp.status_code, 400)
