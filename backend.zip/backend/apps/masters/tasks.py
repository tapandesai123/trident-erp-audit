"""Masters Module Celery Tasks."""
from celery import shared_task
from django.utils import timezone
from datetime import timedelta
from django.db.models import Q


@shared_task(name="masters.check_pending_item_approvals")
def check_pending_item_approvals():
    """
    Daily: Remind approvers of items in PENDING status for more than 3 days.
    """
    from apps.masters.models import Item
    from apps.core.models import Notification, User
    
    cutoff_date = timezone.now() - timedelta(days=3)
    
    # Find items in PENDING status older than 3 days
    pending_items = Item.objects.filter(
        approval_status='PENDING',
        created_at__lt=cutoff_date
    ).select_related('created_by')
    
    if not pending_items.exists():
        return "No pending items requiring approval reminders."
    
    # Get approvers (users with item approval permission)
    try:
        from apps.core.models import Permission
        approve_perm = Permission.objects.filter(
            module="masters",
            action="approve",
            resource="item"
        ).first()
        
        if approve_perm:
            approvers = User.objects.filter(
                userrole__role__permissions__permission=approve_perm,
                userrole__role__is_active=True,
                is_active=True
            ).distinct()
        else:
            # Fallback to managers
            approvers = User.objects.filter(
                Q(is_staff=True) | Q(is_superadmin=True),
                is_active=True
            )
    except:
        approvers = User.objects.filter(is_superadmin=True, is_active=True)
    
    if not approvers.exists():
        return "No approvers found for item approval."
    
    count = 0
    for item in pending_items:
        days_pending = (timezone.now().date() - item.created_at.date()).days
        
        for approver in approvers:
            Notification.objects.create(
                user=approver,
                title=f"Item Pending Approval: {item.item_code}",
                message=f"Item '{item.item_code} - {item.item_name}' has been pending approval for {days_pending} days. "
                        f"Created by: {item.created_by.get_full_name() if item.created_by else 'Unknown'}",
                notification_type="IN_APP",
                module="masters",
                resource="Item",
                resource_id=item.id,
            )
            count += 1
    
    return f"Sent {count} item approval reminders for {pending_items.count()} items."


@shared_task(name="masters.check_vendor_gstin_expiry")
def check_vendor_gstin_expiry():
    """
    Monthly: Flag vendors whose GSTIN might need renewal.
    Note: This is a log-only check as GSTIN doesn't have explicit expiry,
    but we check for vendors that haven't been updated in 12+ months.
    """
    from apps.masters.models import Vendor
    from apps.core.models import AuditLog
    
    cutoff_date = timezone.now() - timedelta(days=365)
    
    # Find vendors with GSTIN that haven't been updated in 12+ months
    stale_vendors = Vendor.objects.filter(
        gstin__isnull=False,
        updated_at__lt=cutoff_date,
        is_active=True
    ).exclude(gstin='')
    
    if not stale_vendors.exists():
        return "No vendors with stale GSTIN information."
    
    # Log the vendors for review
    log_entries = []
    for vendor in stale_vendors:
        days_since_update = (timezone.now().date() - vendor.updated_at.date()).days
        
        # Create audit log entry
        AuditLog.objects.create(
            user=None,  # System-generated
            action="EXPORT",  # Using EXPORT as a "system check" action
            module="masters",
            resource="Vendor",
            resource_id=vendor.id,
            notes=f"Vendor GSTIN not updated in {days_since_update} days. "
                  f"GSTIN: {vendor.gstin}. Please verify validity.",
        )
        log_entries.append(vendor.vendor_code)
    
    # Optionally create a summary notification for admin users
    from apps.core.models import Notification, User
    
    admins = User.objects.filter(
        Q(is_superadmin=True) | Q(is_staff=True),
        is_active=True
    )
    
    summary_message = f"""
Vendor GSTIN Review Required:

{stale_vendors.count()} vendor(s) have GSTIN information not updated in 12+ months:

{', '.join(log_entries[:10])}{'...' if len(log_entries) > 10 else ''}

Please verify GSTIN validity for these vendors.
This is an automated monthly check.
    """.strip()
    
    notification_count = 0
    for admin in admins:
        Notification.objects.create(
            user=admin,
            title="Monthly Vendor GSTIN Review",
            message=summary_message,
            notification_type="IN_APP",
            module="masters",
            resource="Vendor",
            resource_id=0,
        )
        notification_count += 1
    
    return f"Logged {len(log_entries)} vendors for GSTIN review. " \
           f"Sent notifications to {notification_count} admins."
