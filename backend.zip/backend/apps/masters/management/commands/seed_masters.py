"""
Seed initial master data for Trident ERP.
Run: python manage.py seed_masters
"""
from django.core.management.base import BaseCommand
from apps.core.models import Company, Plant, Department, Role, Permission
from apps.masters.models import VendorGroup, ItemGroup, UOM, CustomerGroup


class Command(BaseCommand):
    help = "Seed initial master data: UOMs, groups, roles, permissions, and demo company/plant."

    def handle(self, *args, **options):
        self.stdout.write("Seeding master data...")

        # ─── Company & Plant ───────────────────────────────────
        company, _ = Company.objects.get_or_create(
            name="Trident Paper Box Industries",
            defaults={
                "legal_name": "Trident Paper Box Industries Pvt. Ltd.",
                "gstin": "24AAKFT4708J2ZY",
                "city": "Pardi",
                "state": "Gujarat",
                "pincode": "396125",
                "country": "India",
                "financial_year_start": 4,
            },
        )
        self.stdout.write(f"  Company: {company.name}")

        plant, _ = Plant.objects.get_or_create(
            code="PARDI",
            defaults={
                "company": company,
                "name": "Pardi Plant",
                "city": "Pardi",
                "state": "Gujarat",
                "pincode": "396125",
                "gstin": "24AAKFT4708J2ZY",
            },
        )
        self.stdout.write(f"  Plant: {plant.code}")

        # ─── Departments ──────────────────────────────────────
        depts = [
            ("PURCHASE", "Purchase"),
            ("STORES", "Stores"),
            ("PRODUCTION", "Production"),
            ("QUALITY", "Quality Control"),
            ("ACCOUNTS", "Accounts & Finance"),
            ("SALES", "Sales & Marketing"),
            ("DISPATCH", "Dispatch"),
            ("MAINTENANCE", "Maintenance"),
            ("IT", "Information Technology"),
            ("ADMIN", "Administration"),
            ("MANAGEMENT", "Top Management"),
        ]
        for code, name in depts:
            Department.objects.get_or_create(plant=plant, code=code, defaults={"name": name})
        self.stdout.write(f"  Departments: {len(depts)}")

        # ─── UOMs ─────────────────────────────────────────────
        uoms = [
            ("KG", "Kilograms", 3),
            ("MT", "Metric Tons", 3),
            ("NOS", "Numbers", 0),
            ("PCS", "Pieces", 0),
            ("SET", "Set", 0),
            ("MTR", "Meters", 2),
            ("SQM", "Square Meters", 3),
            ("LTR", "Litres", 3),
            ("ROLL", "Roll", 0),
            ("PKT", "Packet", 0),
            ("BOX", "Box", 0),
            ("BTL", "Bottle", 0),
            ("LOT", "Lot", 0),
            ("REAM", "Ream", 0),
            ("PAIR", "Pair", 0),
        ]
        for code, name, decimals in uoms:
            UOM.objects.get_or_create(code=code, defaults={"name": name, "decimal_places": decimals})
        self.stdout.write(f"  UOMs: {len(uoms)}")

        # ─── Vendor Groups ────────────────────────────────────
        vendor_groups = [
            ("CR-PAPER", "Creditors - Paper"),
            ("CR-INK", "Creditors - Inks & Chemicals"),
            ("CR-ADHESIVE", "Creditors - Adhesives"),
            ("CR-PACKAGING", "Creditors - Packaging Materials"),
            ("CR-CONSUMABLE", "Creditors - Consumables"),
            ("CR-SPARES", "Creditors - Spares & Engineering"),
            ("CR-SERVICES", "Creditors - Services"),
            ("TRANSPORTER", "Transporters"),
            ("JOB-WORKER", "Job Workers"),
            ("CAPITAL", "Capital Goods Suppliers"),
        ]
        for code, name in vendor_groups:
            VendorGroup.objects.get_or_create(code=code, defaults={"name": name})
        self.stdout.write(f"  Vendor Groups: {len(vendor_groups)}")

        # ─── Item Groups (07 series = Kraft Paper, etc.) ──────
        item_groups = [
            # Raw Materials
            ("01", "Raw Materials - General", "RAW_MATERIAL"),
            ("07", "Kraft Paper", "RAW_MATERIAL"),
            ("07-BF16", "Kraft Paper BF 16", "RAW_MATERIAL"),
            ("07-BF18", "Kraft Paper BF 18", "RAW_MATERIAL"),
            ("07-BF20", "Kraft Paper BF 20", "RAW_MATERIAL"),
            ("07-BF22", "Kraft Paper BF 22", "RAW_MATERIAL"),
            ("07-BF25", "Kraft Paper BF 25", "RAW_MATERIAL"),
            ("08", "Flute Paper", "RAW_MATERIAL"),
            ("09", "Liner Paper", "RAW_MATERIAL"),
            ("10", "Inks", "RAW_MATERIAL"),
            ("11", "Adhesives / Gum", "RAW_MATERIAL"),
            ("12", "Strapping / Packaging", "RAW_MATERIAL"),
            # Consumables
            ("20", "Consumables - General", "CONSUMABLE"),
            ("21", "Printing Consumables", "CONSUMABLE"),
            # Spares
            ("30", "Engineering Spares", "SPARE"),
            ("31", "Electrical Spares", "SPARE"),
            # Finished Goods
            ("50", "Corrugated Boxes - 3 Ply", "FINISHED_GOOD"),
            ("51", "Corrugated Boxes - 5 Ply", "FINISHED_GOOD"),
            ("52", "Corrugated Boxes - 7 Ply", "FINISHED_GOOD"),
            ("55", "Corrugated Sheets", "FINISHED_GOOD"),
        ]
        for code, name, itype in item_groups:
            parent = None
            if "-" in code:
                parent_code = code.split("-")[0]
                parent = ItemGroup.objects.filter(code=parent_code).first()
            ItemGroup.objects.get_or_create(
                code=code, defaults={"name": name, "item_type": itype, "parent": parent}
            )
        self.stdout.write(f"  Item Groups: {len(item_groups)}")

        # ─── Customer Groups ──────────────────────────────────
        customer_groups = [
            ("DIRECT", "Direct Customers"),
            ("DEALER", "Dealers"),
            ("ECOM", "E-Commerce"),
            ("INSTITUTIONAL", "Institutional Buyers"),
            ("EXPORT", "Export Customers"),
        ]
        for code, name in customer_groups:
            CustomerGroup.objects.get_or_create(code=code, defaults={"name": name})
        self.stdout.write(f"  Customer Groups: {len(customer_groups)}")

        # ─── Roles ────────────────────────────────────────────
        roles = [
            ("SUPERADMIN", "Super Administrator", True),
            ("DIRECTOR", "Director / Managing Director", True),
            ("PLANT_HEAD", "Plant Head", True),
            ("HOD_PURCHASE", "HOD - Purchase", True),
            ("HOD_STORES", "HOD - Stores", True),
            ("HOD_PRODUCTION", "HOD - Production", True),
            ("HOD_QUALITY", "HOD - Quality", True),
            ("HOD_ACCOUNTS", "HOD - Accounts", True),
            ("HOD_SALES", "HOD - Sales", True),
            ("HOD_DISPATCH", "HOD - Dispatch", True),
            ("PURCHASE_EXEC", "Purchase Executive", True),
            ("STORES_EXEC", "Stores Executive", True),
            ("STORES_OPERATOR", "Stores / Forklift Operator", True),
            ("PRODUCTION_EXEC", "Production Executive", True),
            ("MACHINE_OPERATOR", "Machine Operator", True),
            ("QC_INSPECTOR", "QC Inspector", True),
            ("ACCOUNTS_EXEC", "Accounts Executive", True),
            ("SALES_RSM", "Regional Sales Manager", True),
            ("SALES_TSM", "Territory Sales Manager", True),
            ("SALES_EXEC", "Sales Executive", True),
            ("DISPATCH_EXEC", "Dispatch Executive", True),
            ("DATA_ENTRY", "Data Entry Operator", True),
            ("VIEWER", "View-Only Access", True),
            ("CUSTOMER_PORTAL", "Customer Portal User", True),
            ("DEALER_PORTAL", "Dealer Portal User", True),
        ]
        for name, desc, is_sys in roles:
            Role.objects.get_or_create(name=name, defaults={"description": desc, "is_system": is_sys})
        self.stdout.write(f"  Roles: {len(roles)}")

        # ─── Permissions ──────────────────────────────────────
        modules_resources = {
            "masters": ["vendor", "item", "customer", "price_list"],
            "purchase": ["purchase_requisition", "purchase_order", "gate_entry", "mrr"],
            "stores": ["inventory", "bin_location", "physical_verification"],
            "sales": ["enquiry", "quotation", "sales_order", "despatch", "invoice", "complaint"],
            "accounts": ["voucher", "outstanding", "gst_return"],
            "production": ["bom", "work_order", "job_card"],
            "quality": ["qc_inspection", "capa"],
            "tasks": ["task"],
            "reports": ["dashboard", "mis_report"],
        }
        actions = ["create", "read", "update", "delete", "approve", "export", "import"]
        perm_count = 0
        for module, resources in modules_resources.items():
            for resource in resources:
                for act in actions:
                    Permission.objects.get_or_create(
                        module=module, action=act, resource=resource,
                        defaults={"description": f"{act.title()} {resource.replace('_', ' ')} in {module}"},
                    )
                    perm_count += 1
        self.stdout.write(f"  Permissions: {perm_count}")

        self.stdout.write(self.style.SUCCESS("✅ Master data seeded successfully!"))

        # ─── Task 11: Seed Vendor Sauda demo data ──────────────────
        try:
            from apps.purchase.models import VendorSauda
            from apps.masters.models import Vendor, Item, UOM
            from apps.core.models import Plant
            from datetime import date

            plant = Plant.objects.first()
            vendor = Vendor.objects.first()
            item = Item.objects.first()
            uom, _ = UOM.objects.get_or_create(code="KG", defaults={"name": "Kilogram"})

            if plant and vendor and item:
                VendorSauda.objects.get_or_create(
                    sauda_number="SAUDA-2026-001",
                    defaults={
                        "plant": plant,
                        "vendor": vendor,
                        "item": item,
                        "agreed_qty": 100000,
                        "agreed_rate": "42.50",
                        "uom": uom,
                        "valid_from": date(2026, 4, 1),
                        "valid_to": date(2026, 9, 30),
                        "ordered_qty": 23500,
                        "status": "ACTIVE",
                    },
                )
                self.stdout.write("  Vendor Sauda: SAUDA-2026-001 seeded")
        except Exception as e:
            self.stdout.write(f"  Warning: Could not seed VendorSauda: {e}")

        # ─── Task 11: Seed MLF Billing records ─────────────────────
        try:
            from apps.core.models import MLFBillingRecord
            from decimal import Decimal
            from datetime import date

            MLFBillingRecord.objects.get_or_create(
                quarter="Q1 FY2026-27",
                defaults={
                    "period_start": date(2026, 4, 1),
                    "period_end": date(2026, 6, 30),
                    "base_rate": Decimal("14670.00"),
                    "months_in_period": 3,
                    "subtotal": Decimal("0.00"),
                    "gst_amount": Decimal("0.00"),
                    "total_amount": Decimal("0.00"),
                    "is_free_period": True,
                    "status": "DRAFT",
                    "notes": "Year 1 free period — no charge",
                },
            )
            self.stdout.write("  MLF Billing: Q1 FY2026-27 seeded (free period)")
        except Exception as e:
            self.stdout.write(f"  Warning: Could not seed MLFBillingRecord: {e}")

        # ─── Task 13: Seed MSME Report Permission ──────────────────
        try:
            from apps.core.models import Permission
            Permission.objects.get_or_create(
                module="accounts",
                action="view",
                resource="msme_report",
                defaults={"description": "View MSME Compliance Report"},
            )
            self.stdout.write("  Permission: accounts.view.msme_report seeded")
        except Exception as e:
            self.stdout.write(f"  Warning: Could not seed MSME permission: {e}")
