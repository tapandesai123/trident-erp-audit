"""Tasks Module Admin."""
from django.contrib import admin
from apps.tasks.models import Task, TaskComment, TaskTemplate, TaskAttachment


# ─── Inlines ──────────────────────────────────────────────────────

class TaskCommentInline(admin.TabularInline):
    """Inline for task comments."""
    model = TaskComment
    extra = 0
    readonly_fields = ['commented_by', 'created_at']
    fields = ['comment', 'commented_by', 'created_at']


class TaskAttachmentInline(admin.TabularInline):
    """Inline for task attachments."""
    model = TaskAttachment
    extra = 0
    readonly_fields = ['uploaded_by', 'created_at']
    fields = ['file', 'uploaded_by', 'created_at']


# ─── Task Admin ───────────────────────────────────────────────────

@admin.register(Task)
class TaskAdmin(admin.ModelAdmin):
    """Admin interface for Task model."""
    
    list_display = [
        'title', 'assigned_to', 'assigned_by', 'status', 'priority',
        'due_date', 'module', 'plant', 'created_at'
    ]
    list_filter = [
        'status', 'priority', 'module', 'plant', 'created_at'
    ]
    search_fields = [
        'title', 'description', 'assigned_to__username',
        'assigned_to__first_name', 'assigned_to__last_name',
        'assigned_by__username'
    ]
    readonly_fields = [
        'uuid', 'completed_at', 'reminder_sent', 'created_at', 'updated_at'
    ]
    date_hierarchy = 'due_date'
    inlines = [TaskCommentInline, TaskAttachmentInline]
    
    fieldsets = (
        ('Task Details', {
            'fields': ('uuid', 'title', 'description')
        }),
        ('Assignment', {
            'fields': ('assigned_to', 'assigned_by', 'plant')
        }),
        ('Status & Priority', {
            'fields': ('status', 'priority', 'due_date', 'completed_at')
        }),
        ('Module Reference', {
            'fields': ('module', 'reference_type', 'reference_id'),
            'classes': ('collapse',)
        }),
        ('System', {
            'fields': ('reminder_sent', 'created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )
    
    def get_queryset(self, request):
        """Optimize queryset with select_related."""
        return super().get_queryset(request).select_related(
            'assigned_to', 'assigned_by', 'plant'
        )


# ─── Task Template Admin ──────────────────────────────────────────

@admin.register(TaskTemplate)
class TaskTemplateAdmin(admin.ModelAdmin):
    """Admin interface for TaskTemplate model."""
    
    list_display = [
        'title', 'module', 'default_priority', 'default_due_days',
        'assigned_role', 'is_active', 'created_at'
    ]
    list_filter = ['module', 'default_priority', 'is_active', 'plant']
    search_fields = ['title', 'description']
    readonly_fields = ['created_at', 'updated_at']
    
    fieldsets = (
        ('Template Details', {
            'fields': ('title', 'description', 'module')
        }),
        ('Defaults', {
            'fields': (
                'default_priority', 'default_due_days',
                'assigned_role', 'plant'
            )
        }),
        ('Status', {
            'fields': ('is_active', 'created_at', 'updated_at')
        }),
    )
