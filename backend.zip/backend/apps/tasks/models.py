"""
Tasks Module Models — Structured task assignment with due dates, priorities, 
comments, and cross-module linking.
"""
from django.conf import settings
from django.db import models
from django.utils import timezone

from apps.core.models import UUIDModel, TimeStampedModel, Plant, Role


# ─── Task Model ────────────────────────────────────────────────────

class Task(UUIDModel, TimeStampedModel):
    """
    Task assignment across all modules with structured workflow.
    Links to any module via module+reference_type+reference_id.
    """

    # Module choices - all 18 apps in the system
    MODULE_CHOICES = [
        ('accounts', 'Accounts'),
        ('assets', 'Assets'),
        ('core', 'Core'),
        ('crm', 'CRM'),
        ('dispatch', 'Dispatch'),
        ('hr', 'HR'),
        ('maintenance', 'Maintenance'),
        ('masters', 'Masters'),
        ('payroll', 'Payroll'),
        ('production', 'Production'),
        ('projects', 'Projects'),
        ('purchase', 'Purchase'),
        ('quality', 'Quality'),
        ('reports', 'Reports'),
        ('sales', 'Sales'),
        ('stores', 'Stores'),
        ('tasks', 'Tasks'),
        ('webtel', 'Webtel'),
    ]

    PRIORITY_CHOICES = [
        ('LOW', 'Low'),
        ('NORMAL', 'Normal'),
        ('HIGH', 'High'),
        ('URGENT', 'Urgent'),
    ]

    STATUS_CHOICES = [
        ('OPEN', 'Open'),
        ('IN_PROGRESS', 'In Progress'),
        ('COMPLETED', 'Completed'),
        ('OVERDUE', 'Overdue'),
        ('CANCELLED', 'Cancelled'),
    ]

    title = models.CharField(max_length=300)
    description = models.TextField(blank=True)
    
    # Cross-module linking
    module = models.CharField(max_length=50, choices=MODULE_CHOICES, blank=True)
    reference_type = models.CharField(max_length=50, blank=True, help_text="e.g. PurchaseOrder, SalesOrder")
    reference_id = models.IntegerField(null=True, blank=True)
    
    # Assignment
    assigned_to = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name='assigned_tasks'
    )
    assigned_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='created_tasks'
    )
    
    # Task metadata
    due_date = models.DateField(null=True, blank=True)
    priority = models.CharField(max_length=20, choices=PRIORITY_CHOICES, default='NORMAL')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='OPEN')
    completed_at = models.DateTimeField(null=True, blank=True)
    reminder_sent = models.BooleanField(default=False)
    
    # Organization
    plant = models.ForeignKey(Plant, on_delete=models.SET_NULL, null=True, blank=True)

    class Meta:
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['assigned_to', 'status']),
            models.Index(fields=['due_date', 'status']),
            models.Index(fields=['module', 'reference_id']),
        ]

    def __str__(self):
        return f"{self.title} (assigned to {self.assigned_to.get_full_name() or self.assigned_to.username})"

    def is_overdue(self):
        """Check if task is overdue."""
        if self.status in ['COMPLETED', 'CANCELLED']:
            return False
        if self.due_date and self.due_date < timezone.now().date():
            return True
        return False


# ─── Task Comment ──────────────────────────────────────────────────

class TaskComment(TimeStampedModel):
    """Comments on tasks with timestamp and author tracking."""
    
    task = models.ForeignKey(Task, on_delete=models.CASCADE, related_name='comments')
    comment = models.TextField()
    commented_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True
    )

    class Meta:
        ordering = ['created_at']

    def __str__(self):
        return f"Comment on {self.task.title} by {self.commented_by}"


# ─── Task Attachment ───────────────────────────────────────────────

class TaskAttachment(TimeStampedModel):
    """File attachments for tasks."""
    
    task = models.ForeignKey(Task, on_delete=models.CASCADE, related_name='attachments')
    file = models.FileField(upload_to='task_attachments/%Y/%m/')
    uploaded_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True
    )

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"Attachment for {self.task.title}"


# ─── Task Template ─────────────────────────────────────────────────

class TaskTemplate(TimeStampedModel):
    """
    Templates for recurring or common tasks.
    Used to auto-create tasks with predefined settings.
    """
    
    title = models.CharField(max_length=300)
    description = models.TextField(blank=True)
    module = models.CharField(max_length=50, choices=Task.MODULE_CHOICES, blank=True)
    default_priority = models.CharField(
        max_length=20,
        choices=Task.PRIORITY_CHOICES,
        default='NORMAL'
    )
    default_due_days = models.IntegerField(
        default=7,
        help_text="Number of days from today to set as due date"
    )
    assigned_role = models.ForeignKey(
        Role,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        help_text="Default role to assign tasks to"
    )
    plant = models.ForeignKey(
        Plant,
        on_delete=models.SET_NULL,
        null=True,
        blank=True
    )
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ['title']

    def __str__(self):
        return self.title
