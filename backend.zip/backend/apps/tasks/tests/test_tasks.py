"""Tasks Module Tests."""
from datetime import date, timedelta
from django.test import TestCase
from django.utils import timezone
from django.contrib.auth import get_user_model
from rest_framework.test import APITestCase
from rest_framework import status

from apps.core.models import Plant, Company, Notification, Role
from apps.tasks.models import Task, TaskComment, TaskTemplate
from apps.tasks import services

User = get_user_model()


# ═══════════════════════════════════════════════════════════════════
# Service Layer Tests
# ═══════════════════════════════════════════════════════════════════

class TaskServiceTests(TestCase):
    """Test task services."""
    
    def setUp(self):
        """Set up test data."""
        self.company = Company.objects.create(name="Test Company")
        self.plant = Plant.objects.create(
            company=self.company,
            code="TST",
            name="Test Plant"
        )
        self.user1 = User.objects.create_user(
            username='user1',
            email='user1@test.com',
            password='testpass123'
        )
        self.user2 = User.objects.create_user(
            username='user2',
            email='user2@test.com',
            password='testpass123'
        )
    
    def test_create_task(self):
        """Test task creation with notification."""
        task = services.create_task(
            title="Test Task",
            assigned_to=self.user1,
            assigned_by=self.user2,
            due_date=date.today() + timedelta(days=7),
            priority='HIGH',
            module='purchase',
            plant=self.plant
        )
        
        self.assertIsNotNone(task)
        self.assertEqual(task.title, "Test Task")
        self.assertEqual(task.assigned_to, self.user1)
        self.assertEqual(task.assigned_by, self.user2)
        self.assertEqual(task.priority, 'HIGH')
        
        # Check notification created
        notifications = Notification.objects.filter(user=self.user1)
        self.assertEqual(notifications.count(), 1)
        self.assertIn("Test Task", notifications.first().title)
    
    def test_valid_status_transitions(self):
        """Test valid status transitions."""
        task = services.create_task(
            title="Test Task",
            assigned_to=self.user1,
            assigned_by=self.user2,
        )
        
        # OPEN → IN_PROGRESS
        updated = services.update_task_status(task, 'IN_PROGRESS', self.user1)
        self.assertEqual(updated.status, 'IN_PROGRESS')
        
        # IN_PROGRESS → COMPLETED
        updated = services.update_task_status(task, 'COMPLETED', self.user1)
        self.assertEqual(updated.status, 'COMPLETED')
        self.assertIsNotNone(updated.completed_at)
    
    def test_invalid_status_transitions(self):
        """Test invalid status transitions raise errors."""
        task = services.create_task(
            title="Test Task",
            assigned_to=self.user1,
            assigned_by=self.user2,
        )
        
        # OPEN → COMPLETED (should fail - must go through IN_PROGRESS)
        with self.assertRaises(ValueError):
            services.update_task_status(task, 'COMPLETED', self.user1)
        
        # Complete task properly
        services.update_task_status(task, 'IN_PROGRESS', self.user1)
        services.update_task_status(task, 'COMPLETED', self.user1)
        
        # COMPLETED → anything (terminal state)
        with self.assertRaises(ValueError):
            services.update_task_status(task, 'OPEN', self.user1)
    
    def test_completion_notification(self):
        """Test completion notifies assigned_by user."""
        task = services.create_task(
            title="Test Task",
            assigned_to=self.user1,
            assigned_by=self.user2,
        )
        
        # Clear existing notifications
        Notification.objects.all().delete()
        
        # Complete task
        services.update_task_status(task, 'IN_PROGRESS', self.user1)
        services.update_task_status(task, 'COMPLETED', self.user1)
        
        # Check user2 got notification
        notifications = Notification.objects.filter(user=self.user2)
        self.assertEqual(notifications.count(), 1)
        self.assertIn("Completed", notifications.first().title)
    
    def test_mark_overdue_tasks(self):
        """Test marking overdue tasks."""
        # Create overdue task
        overdue_task = services.create_task(
            title="Overdue Task",
            assigned_to=self.user1,
            assigned_by=self.user2,
            due_date=date.today() - timedelta(days=1)
        )
        
        # Create future task
        future_task = services.create_task(
            title="Future Task",
            assigned_to=self.user1,
            assigned_by=self.user2,
            due_date=date.today() + timedelta(days=1)
        )
        
        count = services.mark_overdue_tasks()
        
        overdue_task.refresh_from_db()
        future_task.refresh_from_db()
        
        self.assertEqual(count, 1)
        self.assertEqual(overdue_task.status, 'OVERDUE')
        self.assertEqual(future_task.status, 'OPEN')
    
    def test_send_task_reminders(self):
        """Test sending reminders for tasks due tomorrow."""
        tomorrow = date.today() + timedelta(days=1)
        
        # Create task due tomorrow
        task = services.create_task(
            title="Task Due Tomorrow",
            assigned_to=self.user1,
            assigned_by=self.user2,
            due_date=tomorrow
        )
        
        # Clear existing notifications
        Notification.objects.all().delete()
        
        count = services.send_task_reminders()
        
        task.refresh_from_db()
        
        self.assertEqual(count, 1)
        self.assertTrue(task.reminder_sent)
        
        # Check notification
        notifications = Notification.objects.filter(user=self.user1)
        self.assertEqual(notifications.count(), 1)
        self.assertIn("Tomorrow", notifications.first().title)
    
    def test_add_comment(self):
        """Test adding comment with notification."""
        task = services.create_task(
            title="Test Task",
            assigned_to=self.user1,
            assigned_by=self.user2,
        )
        
        # Clear existing notifications
        Notification.objects.all().delete()
        
        comment = services.add_comment(
            task=task,
            user=self.user2,
            comment_text="This is a comment"
        )
        
        self.assertIsNotNone(comment)
        self.assertEqual(comment.comment, "This is a comment")
        self.assertEqual(comment.commented_by, self.user2)
        
        # Check notification sent to assigned user
        notifications = Notification.objects.filter(user=self.user1)
        self.assertEqual(notifications.count(), 1)
        self.assertIn("Comment", notifications.first().title)
    
    def test_get_my_tasks(self):
        """Test getting tasks assigned to user."""
        # Create tasks for user1
        services.create_task(
            title="Task 1",
            assigned_to=self.user1,
            assigned_by=self.user2,
            status='OPEN'
        )
        services.create_task(
            title="Task 2",
            assigned_to=self.user1,
            assigned_by=self.user2,
            status='IN_PROGRESS'
        )
        
        # Create task for user2
        services.create_task(
            title="Task 3",
            assigned_to=self.user2,
            assigned_by=self.user1,
        )
        
        result = services.get_my_tasks(self.user1)
        
        self.assertEqual(result['total'], 2)
        self.assertEqual(result['status_counts']['OPEN'], 1)
        self.assertEqual(result['status_counts']['IN_PROGRESS'], 1)
    
    def test_create_from_template(self):
        """Test creating task from template."""
        role = Role.objects.create(name="Test Role")
        
        template = TaskTemplate.objects.create(
            title="Template Task",
            description="Template description",
            default_priority='HIGH',
            default_due_days=5,
            module='purchase',
            assigned_role=role,
            plant=self.plant
        )
        
        task = services.create_tasks_from_template(
            template=template,
            assigned_to=self.user1,
            user=self.user2
        )
        
        self.assertEqual(task.title, "Template Task")
        self.assertEqual(task.description, "Template description")
        self.assertEqual(task.priority, 'HIGH')
        self.assertEqual(task.module, 'purchase')
        self.assertEqual(
            task.due_date,
            date.today() + timedelta(days=5)
        )
    
    def test_task_summary_report(self):
        """Test task summary report generation."""
        # Create various tasks
        services.create_task(
            title="Open Task",
            assigned_to=self.user1,
            assigned_by=self.user2,
            status='OPEN',
            module='purchase'
        )
        services.create_task(
            title="Completed Task",
            assigned_to=self.user1,
            assigned_by=self.user2,
            status='COMPLETED',
            module='sales'
        )
        
        summary = services.get_task_summary_report()
        
        self.assertEqual(summary['total_tasks'], 2)
        self.assertEqual(summary['status_counts']['OPEN'], 1)
        self.assertEqual(summary['status_counts']['COMPLETED'], 1)
        self.assertEqual(len(summary['module_breakdown']), 2)


# ═══════════════════════════════════════════════════════════════════
# API Tests
# ═══════════════════════════════════════════════════════════════════

class TaskAPITests(APITestCase):
    """Test Task API endpoints."""
    
    def setUp(self):
        """Set up test data."""
        self.company = Company.objects.create(name="Test Company")
        self.plant = Plant.objects.create(
            company=self.company,
            code="TST",
            name="Test Plant"
        )
        self.user1 = User.objects.create_user(
            username='user1',
            email='user1@test.com',
            password='testpass123'
        )
        self.user2 = User.objects.create_user(
            username='user2',
            email='user2@test.com',
            password='testpass123'
        )
        self.client.force_authenticate(user=self.user1)
    
    def test_list_tasks(self):
        """Test listing tasks."""
        # Create tasks
        services.create_task(
            title="Task 1",
            assigned_to=self.user1,
            assigned_by=self.user2
        )
        services.create_task(
            title="Task 2",
            assigned_to=self.user1,
            assigned_by=self.user2
        )
        
        response = self.client.get('/api/tasks/tasks/')
        
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data['results']), 2)
    
    def test_create_task(self):
        """Test creating task via API."""
        data = {
            'title': 'New Task',
            'description': 'Test description',
            'assigned_to': self.user2.id,
            'due_date': str(date.today() + timedelta(days=7)),
            'priority': 'HIGH',
            'module': 'purchase',
            'plant': self.plant.id
        }
        
        response = self.client.post('/api/tasks/tasks/', data)
        
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(Task.objects.count(), 1)
        task = Task.objects.first()
        self.assertEqual(task.title, 'New Task')
        self.assertEqual(task.assigned_by, self.user1)
    
    def test_my_tasks_endpoint(self):
        """Test my_tasks custom action."""
        services.create_task(
            title="My Task",
            assigned_to=self.user1,
            assigned_by=self.user2
        )
        services.create_task(
            title="Other Task",
            assigned_to=self.user2,
            assigned_by=self.user1
        )
        
        response = self.client.get('/api/tasks/tasks/my_tasks/')
        
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data['results']), 1)
        self.assertIn('status_counts', response.data)
    
    def test_update_status_endpoint(self):
        """Test update_status custom action."""
        task = services.create_task(
            title="Test Task",
            assigned_to=self.user1,
            assigned_by=self.user2
        )
        
        response = self.client.post(
            f'/api/tasks/tasks/{task.id}/update_status/',
            {'status': 'IN_PROGRESS'}
        )
        
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        task.refresh_from_db()
        self.assertEqual(task.status, 'IN_PROGRESS')
    
    def test_add_comment_endpoint(self):
        """Test add_comment custom action."""
        task = services.create_task(
            title="Test Task",
            assigned_to=self.user1,
            assigned_by=self.user2
        )
        
        response = self.client.post(
            f'/api/tasks/tasks/{task.id}/add_comment/',
            {'comment': 'Test comment'}
        )
        
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(TaskComment.objects.count(), 1)
    
    def test_summary_endpoint(self):
        """Test summary custom action."""
        services.create_task(
            title="Task 1",
            assigned_to=self.user1,
            assigned_by=self.user2,
            module='purchase'
        )
        
        response = self.client.get('/api/tasks/tasks/summary/')
        
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('status_counts', response.data)
        self.assertIn('total_tasks', response.data)
        self.assertIn('module_breakdown', response.data)
