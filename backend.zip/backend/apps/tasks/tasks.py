"""Tasks Module Celery Tasks."""
from celery import shared_task
from django.utils import timezone
from apps.tasks import services


@shared_task(name="tasks.mark_overdue_tasks")
def mark_overdue_tasks():
    """
    Daily: Mark all OPEN/IN_PROGRESS tasks past due_date as OVERDUE.
    Scheduled to run at 7:00 AM daily.
    """
    count = services.mark_overdue_tasks()
    return f"Marked {count} tasks as OVERDUE."


@shared_task(name="tasks.send_task_reminders")
def send_task_reminders():
    """
    Daily: Send reminders for tasks due within 1 day.
    Scheduled to run at 8:00 AM daily.
    """
    count = services.send_task_reminders()
    return f"Sent {count} task reminders."


@shared_task(name="tasks.send_weekly_task_digest")
def send_weekly_task_digest():
    """
    Weekly: Send email digest to each user with their open/overdue tasks.
    Scheduled to run Monday 9:00 AM.
    """
    from apps.core.models import User, Notification
    from apps.tasks.models import Task
    from django.db.models import Q

    users_with_tasks = User.objects.filter(
        assigned_tasks__status__in=['OPEN', 'IN_PROGRESS', 'OVERDUE']
    ).distinct()

    count = 0
    for user in users_with_tasks:
        # Get open and overdue tasks
        open_tasks = Task.objects.filter(
            assigned_to=user,
            status__in=['OPEN', 'IN_PROGRESS']
        ).count()

        overdue_tasks = Task.objects.filter(
            assigned_to=user,
            status='OVERDUE'
        ).count()

        if open_tasks > 0 or overdue_tasks > 0:
            message = f"You have {open_tasks} open task(s)"
            if overdue_tasks > 0:
                message += f" and {overdue_tasks} overdue task(s)"
            message += ". Please review your tasks."

            Notification.objects.create(
                user=user,
                title="Weekly Task Digest",
                message=message,
                notification_type="IN_APP",
                module="tasks",
                resource="Task",
                resource_id=0,
            )
            count += 1

    return f"Sent weekly digest to {count} users."
