"""Tasks API URLs."""
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from apps.tasks.api.viewsets import TaskViewSet, TaskTemplateViewSet

app_name = "tasks"

router = DefaultRouter()
router.register(r'tasks', TaskViewSet, basename='task')
router.register(r'templates', TaskTemplateViewSet, basename='task-template')

urlpatterns = [
    path('', include(router.urls)),
]
