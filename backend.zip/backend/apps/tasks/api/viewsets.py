"""Tasks API ViewSets."""
from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.filters import SearchFilter, OrderingFilter

from apps.tasks.models import Task, TaskTemplate, TaskComment
from apps.tasks.api.serializers import (
    TaskListSerializer, TaskDetailSerializer, TaskCreateSerializer,
    TaskStatusUpdateSerializer, TaskTemplateSerializer, TaskCommentSerializer
)
from apps.tasks.api.filters import TaskFilter
from apps.tasks import services


# ─── Task ViewSet ─────────────────────────────────────────────────

class TaskViewSet(viewsets.ModelViewSet):
    """
    ViewSet for Task CRUD operations.
    
    Provides:
    - Standard CRUD
    - Filtering by status, priority, module, assigned_to, assigned_by, plant
    - Search on title
    - Ordering by due_date, priority, created_at
    - Custom actions: my_tasks, team_tasks, update_status, add_comment, overdue, summary
    """
    
    queryset = Task.objects.select_related(
        'assigned_to', 'assigned_by', 'plant'
    ).prefetch_related('comments', 'attachments')
    permission_classes = [IsAuthenticated]
    filter_backends = [DjangoFilterBackend, SearchFilter, OrderingFilter]
    filterset_class = TaskFilter
    search_fields = ['title', 'description']
    ordering_fields = ['due_date', 'priority', 'created_at', 'status']
    ordering = ['-created_at']
    
    def get_serializer_class(self):
        """Return appropriate serializer based on action."""
        if self.action == 'list':
            return TaskListSerializer
        elif self.action == 'create':
            return TaskCreateSerializer
        elif self.action == 'update_status':
            return TaskStatusUpdateSerializer
        return TaskDetailSerializer
    
    def perform_create(self, serializer):
        """Create task using service layer."""
        task = services.create_task(
            title=serializer.validated_data['title'],
            description=serializer.validated_data.get('description', ''),
            assigned_to=serializer.validated_data['assigned_to'],
            assigned_by=self.request.user,
            due_date=serializer.validated_data.get('due_date'),
            priority=serializer.validated_data.get('priority', 'NORMAL'),
            module=serializer.validated_data.get('module', ''),
            reference_type=serializer.validated_data.get('reference_type', ''),
            reference_id=serializer.validated_data.get('reference_id'),
            plant=serializer.validated_data.get('plant'),
        )
        serializer.instance = task
    
    @action(detail=False, methods=['get'])
    def my_tasks(self, request):
        """
        Get tasks assigned to the current user.
        Query params: status (optional)
        """
        status_filter = request.query_params.get('status')
        result = services.get_my_tasks(request.user, status_filter)
        
        page = self.paginate_queryset(result['tasks'])
        if page is not None:
            serializer = TaskListSerializer(page, many=True)
            response = self.get_paginated_response(serializer.data)
            response.data['status_counts'] = result['status_counts']
            response.data['total'] = result['total']
            return response
        
        serializer = TaskListSerializer(result['tasks'], many=True)
        return Response({
            'results': serializer.data,
            'status_counts': result['status_counts'],
            'total': result['total'],
        })
    
    @action(detail=False, methods=['get'])
    def team_tasks(self, request):
        """Get tasks assigned by the current user (tasks they created)."""
        plant_id = request.query_params.get('plant')
        plant = None
        if plant_id:
            from apps.core.models import Plant
            try:
                plant = Plant.objects.get(pk=plant_id)
            except Plant.DoesNotExist:
                pass
        
        result = services.get_team_tasks(request.user, plant)
        
        page = self.paginate_queryset(result['tasks'])
        if page is not None:
            serializer = TaskListSerializer(page, many=True)
            response = self.get_paginated_response(serializer.data)
            response.data['overdue_count'] = result['overdue_count']
            response.data['total'] = result['total']
            return response
        
        serializer = TaskListSerializer(result['tasks'], many=True)
        return Response({
            'results': serializer.data,
            'overdue_count': result['overdue_count'],
            'total': result['total'],
        })
    
    @action(detail=True, methods=['post'])
    def update_status(self, request, pk=None):
        """
        Update task status with transition validation.
        Body: {"status": "IN_PROGRESS"}
        """
        task = self.get_object()
        serializer = TaskStatusUpdateSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        
        try:
            updated_task = services.update_task_status(
                task=task,
                new_status=serializer.validated_data['status'],
                user=request.user
            )
            return Response(
                TaskDetailSerializer(updated_task).data,
                status=status.HTTP_200_OK
            )
        except ValueError as e:
            return Response(
                {'error': str(e)},
                status=status.HTTP_400_BAD_REQUEST
            )
    
    @action(detail=True, methods=['post'])
    def add_comment(self, request, pk=None):
        """
        Add a comment to a task.
        Body: {"comment": "This is a comment"}
        """
        task = self.get_object()
        comment_text = request.data.get('comment')
        
        if not comment_text:
            return Response(
                {'error': 'Comment text is required'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        comment = services.add_comment(
            task=task,
            user=request.user,
            comment_text=comment_text
        )
        
        return Response(
            TaskCommentSerializer(comment).data,
            status=status.HTTP_201_CREATED
        )
    
    @action(detail=False, methods=['get'])
    def overdue(self, request):
        """Get all overdue tasks."""
        overdue_tasks = Task.objects.filter(
            status='OVERDUE'
        ).select_related('assigned_to', 'assigned_by', 'plant')
        
        page = self.paginate_queryset(overdue_tasks)
        if page is not None:
            serializer = TaskListSerializer(page, many=True)
            return self.get_paginated_response(serializer.data)
        
        serializer = TaskListSerializer(overdue_tasks, many=True)
        return Response(serializer.data)
    
    @action(detail=False, methods=['get'])
    def summary(self, request):
        """Get task dashboard summary."""
        plant_id = request.query_params.get('plant')
        plant = None
        if plant_id:
            from apps.core.models import Plant
            try:
                plant = Plant.objects.get(pk=plant_id)
            except Plant.DoesNotExist:
                pass
        
        summary = services.get_task_summary_report(plant)
        return Response(summary)


# ─── Task Template ViewSet ────────────────────────────────────────

class TaskTemplateViewSet(viewsets.ModelViewSet):
    """
    ViewSet for Task Template CRUD operations.
    
    Provides:
    - Standard CRUD
    - Custom action: create_from_template
    """
    
    queryset = TaskTemplate.objects.select_related('assigned_role', 'plant')
    serializer_class = TaskTemplateSerializer
    permission_classes = [IsAuthenticated]
    filter_backends = [DjangoFilterBackend, SearchFilter, OrderingFilter]
    search_fields = ['title', 'description']
    ordering_fields = ['title', 'created_at']
    ordering = ['title']
    
    def get_queryset(self):
        """Filter to show only active templates by default."""
        queryset = super().get_queryset()
        if self.request.query_params.get('show_inactive') != 'true':
            queryset = queryset.filter(is_active=True)
        return queryset
    
    @action(detail=True, methods=['post'])
    def create_from_template(self, request, pk=None):
        """
        Create a task from this template.
        Body: {"assigned_to": <user_id>}
        """
        template = self.get_object()
        assigned_to_id = request.data.get('assigned_to')
        
        if not assigned_to_id:
            return Response(
                {'error': 'assigned_to is required'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        from apps.core.models import User
        try:
            assigned_to = User.objects.get(pk=assigned_to_id)
        except User.DoesNotExist:
            return Response(
                {'error': 'Invalid assigned_to user'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        task = services.create_tasks_from_template(
            template=template,
            assigned_to=assigned_to,
            user=request.user
        )
        
        return Response(
            TaskDetailSerializer(task).data,
            status=status.HTTP_201_CREATED
        )
