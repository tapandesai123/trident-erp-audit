"""Tasks API Filters."""
import django_filters
from django.utils import timezone
from apps.tasks.models import Task


class TaskFilter(django_filters.FilterSet):
    """Filter set for Task model."""
    
    status = django_filters.MultipleChoiceFilter(
        choices=Task.STATUS_CHOICES,
        field_name='status'
    )
    priority = django_filters.MultipleChoiceFilter(
        choices=Task.PRIORITY_CHOICES,
        field_name='priority'
    )
    module = django_filters.MultipleChoiceFilter(
        choices=Task.MODULE_CHOICES,
        field_name='module'
    )
    assigned_to = django_filters.NumberFilter(field_name='assigned_to')
    assigned_by = django_filters.NumberFilter(field_name='assigned_by')
    plant = django_filters.NumberFilter(field_name='plant')
    due_date_from = django_filters.DateFilter(
        field_name='due_date',
        lookup_expr='gte'
    )
    due_date_to = django_filters.DateFilter(
        field_name='due_date',
        lookup_expr='lte'
    )
    is_overdue = django_filters.BooleanFilter(method='filter_overdue')
    
    class Meta:
        model = Task
        fields = [
            'status', 'priority', 'module', 'assigned_to', 'assigned_by',
            'plant', 'due_date_from', 'due_date_to', 'is_overdue'
        ]
    
    def filter_overdue(self, queryset, name, value):
        """
        Filter for overdue tasks.
        value=True: Show only overdue tasks
        value=False: Show only non-overdue tasks
        """
        today = timezone.now().date()
        if value:
            return queryset.filter(
                due_date__lt=today,
                status__in=['OPEN', 'IN_PROGRESS', 'OVERDUE']
            )
        else:
            return queryset.exclude(
                due_date__lt=today,
                status__in=['OPEN', 'IN_PROGRESS', 'OVERDUE']
            )
