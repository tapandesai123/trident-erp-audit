"""Tasks API Serializers."""
from rest_framework import serializers
from apps.tasks.models import Task, TaskComment, TaskTemplate, TaskAttachment


# ─── Task Comment Serializer ──────────────────────────────────────

class TaskCommentSerializer(serializers.ModelSerializer):
    """Serializer for task comments."""
    
    commented_by_name = serializers.SerializerMethodField()
    
    class Meta:
        model = TaskComment
        fields = [
            'id', 'task', 'comment', 'commented_by', 
            'commented_by_name', 'created_at'
        ]
        read_only_fields = ['id', 'commented_by_name', 'created_at']
    
    def get_commented_by_name(self, obj):
        """Get full name of commenter."""
        if obj.commented_by:
            return obj.commented_by.get_full_name() or obj.commented_by.username
        return None


# ─── Task Attachment Serializer ───────────────────────────────────

class TaskAttachmentSerializer(serializers.ModelSerializer):
    """Serializer for task attachments."""
    
    uploaded_by_name = serializers.SerializerMethodField()
    
    class Meta:
        model = TaskAttachment
        fields = [
            'id', 'task', 'file', 'uploaded_by',
            'uploaded_by_name', 'created_at'
        ]
        read_only_fields = ['id', 'uploaded_by_name', 'created_at']
    
    def get_uploaded_by_name(self, obj):
        """Get full name of uploader."""
        if obj.uploaded_by:
            return obj.uploaded_by.get_full_name() or obj.uploaded_by.username
        return None


# ─── Task List Serializer ─────────────────────────────────────────

class TaskListSerializer(serializers.ModelSerializer):
    """Serializer for task list view."""
    
    assigned_to_name = serializers.SerializerMethodField()
    assigned_by_name = serializers.SerializerMethodField()
    priority_display = serializers.CharField(source='get_priority_display', read_only=True)
    status_display = serializers.CharField(source='get_status_display', read_only=True)
    is_overdue = serializers.SerializerMethodField()
    
    class Meta:
        model = Task
        fields = [
            'id', 'uuid', 'title', 'module', 'reference_type', 'reference_id',
            'assigned_to', 'assigned_to_name', 'assigned_by', 'assigned_by_name',
            'due_date', 'priority', 'priority_display', 'status', 'status_display',
            'is_overdue', 'created_at', 'updated_at'
        ]
        read_only_fields = ['id', 'uuid', 'created_at', 'updated_at']
    
    def get_assigned_to_name(self, obj):
        """Get full name of assigned user."""
        return obj.assigned_to.get_full_name() or obj.assigned_to.username
    
    def get_assigned_by_name(self, obj):
        """Get full name of assigner."""
        if obj.assigned_by:
            return obj.assigned_by.get_full_name() or obj.assigned_by.username
        return None
    
    def get_is_overdue(self, obj):
        """Check if task is overdue."""
        return obj.is_overdue()


# ─── Task Detail Serializer ───────────────────────────────────────

class TaskDetailSerializer(serializers.ModelSerializer):
    """Serializer for task detail view with nested comments."""
    
    assigned_to_name = serializers.SerializerMethodField()
    assigned_by_name = serializers.SerializerMethodField()
    plant_name = serializers.SerializerMethodField()
    priority_display = serializers.CharField(source='get_priority_display', read_only=True)
    status_display = serializers.CharField(source='get_status_display', read_only=True)
    module_display = serializers.CharField(source='get_module_display', read_only=True)
    comments = TaskCommentSerializer(many=True, read_only=True)
    attachments = TaskAttachmentSerializer(many=True, read_only=True)
    is_overdue = serializers.SerializerMethodField()
    
    class Meta:
        model = Task
        fields = [
            'id', 'uuid', 'title', 'description',
            'module', 'module_display', 'reference_type', 'reference_id',
            'assigned_to', 'assigned_to_name', 'assigned_by', 'assigned_by_name',
            'due_date', 'priority', 'priority_display', 'status', 'status_display',
            'completed_at', 'reminder_sent', 'plant', 'plant_name',
            'is_overdue', 'comments', 'attachments',
            'created_at', 'updated_at'
        ]
        read_only_fields = [
            'id', 'uuid', 'completed_at', 'reminder_sent',
            'created_at', 'updated_at'
        ]
    
    def get_assigned_to_name(self, obj):
        """Get full name of assigned user."""
        return obj.assigned_to.get_full_name() or obj.assigned_to.username
    
    def get_assigned_by_name(self, obj):
        """Get full name of assigner."""
        if obj.assigned_by:
            return obj.assigned_by.get_full_name() or obj.assigned_by.username
        return None
    
    def get_plant_name(self, obj):
        """Get plant name."""
        if obj.plant:
            return str(obj.plant)
        return None
    
    def get_is_overdue(self, obj):
        """Check if task is overdue."""
        return obj.is_overdue()


# ─── Task Create Serializer ───────────────────────────────────────

class TaskCreateSerializer(serializers.ModelSerializer):
    """Serializer for creating tasks."""
    
    class Meta:
        model = Task
        fields = [
            'title', 'description', 'assigned_to', 'due_date',
            'priority', 'module', 'reference_type', 'reference_id', 'plant'
        ]
    
    def validate_priority(self, value):
        """Validate priority choice."""
        valid_priorities = [choice[0] for choice in Task.PRIORITY_CHOICES]
        if value not in valid_priorities:
            raise serializers.ValidationError(
                f"Invalid priority. Must be one of: {', '.join(valid_priorities)}"
            )
        return value
    
    def validate_module(self, value):
        """Validate module choice."""
        if value:
            valid_modules = [choice[0] for choice in Task.MODULE_CHOICES]
            if value not in valid_modules:
                raise serializers.ValidationError(
                    f"Invalid module. Must be one of: {', '.join(valid_modules)}"
                )
        return value


# ─── Task Status Update Serializer ────────────────────────────────

class TaskStatusUpdateSerializer(serializers.Serializer):
    """Serializer for updating task status."""
    
    status = serializers.ChoiceField(choices=Task.STATUS_CHOICES)
    
    def validate_status(self, value):
        """Validate status is a valid choice."""
        valid_statuses = [choice[0] for choice in Task.STATUS_CHOICES]
        if value not in valid_statuses:
            raise serializers.ValidationError(
                f"Invalid status. Must be one of: {', '.join(valid_statuses)}"
            )
        return value


# ─── Task Template Serializer ─────────────────────────────────────

class TaskTemplateSerializer(serializers.ModelSerializer):
    """Serializer for task templates."""
    
    assigned_role_name = serializers.SerializerMethodField()
    plant_name = serializers.SerializerMethodField()
    priority_display = serializers.CharField(source='get_default_priority_display', read_only=True)
    module_display = serializers.CharField(source='get_module_display', read_only=True)
    
    class Meta:
        model = TaskTemplate
        fields = [
            'id', 'title', 'description', 'module', 'module_display',
            'default_priority', 'priority_display', 'default_due_days',
            'assigned_role', 'assigned_role_name', 'plant', 'plant_name',
            'is_active', 'created_at', 'updated_at'
        ]
        read_only_fields = ['id', 'created_at', 'updated_at']
    
    def get_assigned_role_name(self, obj):
        """Get role name."""
        if obj.assigned_role:
            return obj.assigned_role.name
        return None
    
    def get_plant_name(self, obj):
        """Get plant name."""
        if obj.plant:
            return str(obj.plant)
        return None
