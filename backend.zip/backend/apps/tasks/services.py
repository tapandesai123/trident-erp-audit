"""
Tasks Module Services

Services:
  create_task()                 — Create task with notifications and audit log
  update_task_status()          — Update status with validation and notifications
  mark_overdue_tasks()          — Bulk update overdue tasks (Celery job)
  send_task_reminders()         — Send reminders for upcoming tasks (Celery job)
  add_comment()                 — Add comment and notify
  get_my_tasks()                — Tasks assigned to user
  get_team_tasks()              — Tasks assigned by user
  create_tasks_from_template()  — Instantiate task from template
  get_task_summary_report()     — Dashboard summary
"""
from __future__ import annotations

from datetime import date, timedelta
from typing import Optional, Dict, Any, List

from django.db import transaction
from django.db.models import Count, Q, Avg, F
from django.utils import timezone

from apps.core.models import AuditLog, Notification
from .models import Task, TaskComment, TaskTemplate


# ─── Helpers ──────────────────────────────────────────────────────

def _log(user, action: str, resource: str, resource_id, details: dict = None):
    """Create audit log entry."""
    AuditLog.objects.create(
        user=user,
        action=action,
        module="tasks",
        resource=resource,
        resource_id=str(resource_id),
        new_values=details or {},
    )


def _notify(user, title: str, message: str, resource: str, resource_id):
    """Create in-app notification."""
    if user:
        Notification.objects.create(
            user=user,
            title=title,
            message=message,
            notification_type="IN_APP",
            module="tasks",
            resource=resource,
            resource_id=resource_id,
        )


# ═══════════════════════════════════════════════════════════════════
# Task Management
# ═══════════════════════════════════════════════════════════════════

@transaction.atomic
def create_task(
    title: str,
    assigned_to,
    assigned_by,
    due_date: Optional[date] = None,
    priority: str = 'NORMAL',
    module: str = '',
    reference_type: str = '',
    reference_id: Optional[int] = None,
    plant=None,
    description: str = ''
) -> Task:
    """
    Create a new task with notifications and audit log.
    
    Args:
        title: Task title
        assigned_to: User object
        assigned_by: User object
        due_date: Optional due date
        priority: LOW/NORMAL/HIGH/URGENT
        module: Module name (e.g., 'purchase', 'sales')
        reference_type: Type of referenced object
        reference_id: ID of referenced object
        plant: Plant object
        description: Task description
        
    Returns:
        Created Task instance
    """
    task = Task.objects.create(
        title=title,
        description=description,
        assigned_to=assigned_to,
        assigned_by=assigned_by,
        due_date=due_date,
        priority=priority,
        module=module,
        reference_type=reference_type,
        reference_id=reference_id,
        plant=plant,
    )
    
    # Audit log
    _log(
        user=assigned_by,
        action="CREATE",
        resource="Task",
        resource_id=task.id,
        details={
            "title": title,
            "assigned_to": assigned_to.username,
            "priority": priority,
            "due_date": str(due_date) if due_date else None,
        }
    )
    
    # Notify assigned user
    due_info = f" (due {due_date})" if due_date else ""
    _notify(
        user=assigned_to,
        title=f"New Task Assigned: {title}",
        message=f"You have been assigned a new task by {assigned_by.get_full_name() or assigned_by.username}{due_info}.",
        resource="Task",
        resource_id=task.id,
    )
    
    return task


# ─── Status Management ────────────────────────────────────────────

VALID_TRANSITIONS = {
    'OPEN': ['IN_PROGRESS', 'CANCELLED'],
    'IN_PROGRESS': ['COMPLETED', 'OPEN', 'CANCELLED'],
    'COMPLETED': [],  # Terminal state
    'OVERDUE': ['IN_PROGRESS', 'COMPLETED', 'CANCELLED'],
    'CANCELLED': [],  # Terminal state
}


@transaction.atomic
def update_task_status(task: Task, new_status: str, user) -> Task:
    """
    Update task status with transition validation.
    
    Valid transitions:
    - OPEN → IN_PROGRESS, CANCELLED
    - IN_PROGRESS → COMPLETED, OPEN, CANCELLED
    - OVERDUE → IN_PROGRESS, COMPLETED, CANCELLED
    - COMPLETED → (terminal)
    - CANCELLED → (terminal)
    
    Args:
        task: Task instance
        new_status: New status value
        user: User making the change
        
    Returns:
        Updated Task instance
        
    Raises:
        ValueError: If transition is invalid
    """
    old_status = task.status
    
    # Validate transition
    if new_status not in VALID_TRANSITIONS.get(old_status, []):
        raise ValueError(
            f"Invalid status transition from {old_status} to {new_status}. "
            f"Valid transitions: {', '.join(VALID_TRANSITIONS.get(old_status, []))}"
        )
    
    task.status = new_status
    
    # Set completion timestamp
    if new_status == 'COMPLETED':
        task.completed_at = timezone.now()
    
    task.save(update_fields=['status', 'completed_at', 'updated_at'])
    
    # Audit log
    _log(
        user=user,
        action="UPDATE",
        resource="Task",
        resource_id=task.id,
        details={
            "old_status": old_status,
            "new_status": new_status,
        }
    )
    
    # Notify assigned_by user on completion
    if new_status == 'COMPLETED' and task.assigned_by and task.assigned_by != user:
        _notify(
            user=task.assigned_by,
            title=f"Task Completed: {task.title}",
            message=f"{task.assigned_to.get_full_name() or task.assigned_to.username} completed the task '{task.title}'.",
            resource="Task",
            resource_id=task.id,
        )
    
    return task


# ─── Bulk Operations ──────────────────────────────────────────────

def mark_overdue_tasks() -> int:
    """
    Mark all OPEN/IN_PROGRESS tasks past due_date as OVERDUE.
    Called by Celery daily task.
    
    Returns:
        Number of tasks marked as overdue
    """
    today = timezone.now().date()
    
    overdue_count = Task.objects.filter(
        Q(status='OPEN') | Q(status='IN_PROGRESS'),
        due_date__lt=today
    ).update(status='OVERDUE')
    
    return overdue_count


def send_task_reminders() -> int:
    """
    Send reminders for tasks due within 1 day that haven't been reminded.
    Called by Celery daily task.
    
    Returns:
        Number of reminders sent
    """
    tomorrow = timezone.now().date() + timedelta(days=1)
    
    tasks = Task.objects.filter(
        Q(status='OPEN') | Q(status='IN_PROGRESS'),
        due_date=tomorrow,
        reminder_sent=False
    ).select_related('assigned_to', 'assigned_by')
    
    count = 0
    for task in tasks:
        _notify(
            user=task.assigned_to,
            title=f"Task Due Tomorrow: {task.title}",
            message=f"Task '{task.title}' is due tomorrow ({tomorrow}).",
            resource="Task",
            resource_id=task.id,
        )
        task.reminder_sent = True
        task.save(update_fields=['reminder_sent'])
        count += 1
    
    return count


# ─── Comments ─────────────────────────────────────────────────────

@transaction.atomic
def add_comment(task: Task, user, comment_text: str) -> TaskComment:
    """
    Add a comment to a task and notify assigned user.
    
    Args:
        task: Task instance
        user: User adding comment
        comment_text: Comment text
        
    Returns:
        Created TaskComment instance
    """
    comment = TaskComment.objects.create(
        task=task,
        comment=comment_text,
        commented_by=user
    )
    
    # Notify assigned user if different from commenter
    if task.assigned_to != user:
        _notify(
            user=task.assigned_to,
            title=f"New Comment on Task: {task.title}",
            message=f"{user.get_full_name() or user.username} commented: {comment_text[:100]}",
            resource="Task",
            resource_id=task.id,
        )
    
    return comment


# ─── Query Functions ──────────────────────────────────────────────

def get_my_tasks(user, status_filter: Optional[str] = None) -> Dict[str, Any]:
    """
    Get tasks assigned to a user with status breakdown.
    
    Args:
        user: User object
        status_filter: Optional status to filter by
        
    Returns:
        Dictionary with tasks and counts
    """
    queryset = Task.objects.filter(assigned_to=user)
    
    if status_filter:
        queryset = queryset.filter(status=status_filter)
    
    # Count by status
    status_counts = Task.objects.filter(assigned_to=user).values('status').annotate(
        count=Count('id')
    )
    
    return {
        'tasks': queryset.select_related('assigned_by', 'plant').prefetch_related('comments'),
        'status_counts': {item['status']: item['count'] for item in status_counts},
        'total': queryset.count(),
    }


def get_team_tasks(user, plant=None) -> Dict[str, Any]:
    """
    Get tasks assigned by a user (tasks they created).
    
    Args:
        user: User object
        plant: Optional plant filter
        
    Returns:
        Dictionary with tasks and overdue count
    """
    queryset = Task.objects.filter(assigned_by=user)
    
    if plant:
        queryset = queryset.filter(plant=plant)
    
    overdue_count = queryset.filter(status='OVERDUE').count()
    
    return {
        'tasks': queryset.select_related('assigned_to', 'plant'),
        'overdue_count': overdue_count,
        'total': queryset.count(),
    }


# ─── Templates ────────────────────────────────────────────────────

@transaction.atomic
def create_tasks_from_template(
    template: TaskTemplate,
    assigned_to,
    user
) -> Task:
    """
    Create a task from a template.
    
    Args:
        template: TaskTemplate instance
        assigned_to: User to assign the task to
        user: User creating the task
        
    Returns:
        Created Task instance
    """
    due_date = timezone.now().date() + timedelta(days=template.default_due_days)
    
    task = create_task(
        title=template.title,
        description=template.description,
        assigned_to=assigned_to,
        assigned_by=user,
        due_date=due_date,
        priority=template.default_priority,
        module=template.module,
        plant=template.plant,
    )
    
    return task


# ─── Reporting ────────────────────────────────────────────────────

def get_task_summary_report(plant=None) -> Dict[str, Any]:
    """
    Get task summary dashboard data.
    
    Args:
        plant: Optional plant filter
        
    Returns:
        Dictionary with counts and statistics
    """
    queryset = Task.objects.all()
    
    if plant:
        queryset = queryset.filter(plant=plant)
    
    # Count by status
    status_counts = queryset.values('status').annotate(count=Count('id'))
    
    # Overdue count
    overdue_count = queryset.filter(status='OVERDUE').count()
    
    # Average completion time for completed tasks
    completed_tasks = queryset.filter(status='COMPLETED', completed_at__isnull=False)
    avg_completion_time = None
    if completed_tasks.exists():
        # Calculate average days from created to completed
        avg_completion_time = completed_tasks.annotate(
            completion_days=F('completed_at') - F('created_at')
        ).aggregate(
            avg=Avg('completion_days')
        )['avg']
        if avg_completion_time:
            avg_completion_time = avg_completion_time.days
    
    # Tasks by module
    module_counts = queryset.exclude(module='').values('module').annotate(
        count=Count('id')
    ).order_by('-count')
    
    return {
        'status_counts': {item['status']: item['count'] for item in status_counts},
        'overdue_count': overdue_count,
        'avg_completion_days': avg_completion_time,
        'module_breakdown': list(module_counts),
        'total_tasks': queryset.count(),
    }
