"""
CRM Module Models — Section 15

Models:
  Lead            — Inbound/outbound sales lead from any channel
  LeadActivity    — Timeline of activities on a lead (calls, emails, visits)
  Opportunity     — Qualified lead converted to sales opportunity
  OpportunityStage — Configurable pipeline stages (master)
  Quote           — Formal commercial quotation linked to Opportunity
  QuoteLineItem   — Product/service line on a Quote
  CRMContact      — Contact person at a customer/prospect
  CustomerVisit   — Field-visit log by salesperson
  CampaignEmail   — Bulk/targeted email campaign header + recipients
"""
import uuid
from decimal import Decimal
from django.conf import settings
from django.db import models
from django.utils import timezone
from apps.core.models import TimeStampedModel, UUIDModel, Plant


# ═══════════════════════════════════════════════════════════════════
# OPPORTUNITY STAGE — Master (configurable pipeline)
# ═══════════════════════════════════════════════════════════════════

class OpportunityStage(UUIDModel, TimeStampedModel):
    """Configurable pipeline stage master (e.g. Prospecting → Qualified → Proposal → Won)."""

    plant = models.ForeignKey(
        Plant, on_delete=models.CASCADE, related_name="opportunity_stages"
    )
    name = models.CharField(max_length=100)
    order = models.PositiveIntegerField(default=0, help_text="Display / pipeline order (0 = first)")
    probability = models.DecimalField(
        max_digits=5, decimal_places=2, default=Decimal("0.00"),
        help_text="Default win probability % for this stage"
    )
    is_won = models.BooleanField(default=False, help_text="Marks the terminal 'Won' stage")
    is_lost = models.BooleanField(default=False, help_text="Marks the terminal 'Lost' stage")
    is_active = models.BooleanField(default=True)
    description = models.TextField(blank=True)

    class Meta:
        ordering = ["plant", "order"]
        unique_together = [("plant", "name")]

    def __str__(self):
        return f"{self.plant.code} | {self.name}"


# ═══════════════════════════════════════════════════════════════════
# CRM CONTACT
# ═══════════════════════════════════════════════════════════════════

class CRMContact(UUIDModel, TimeStampedModel):
    """Contact person at a customer or prospect company."""

    SALUTATION_CHOICES = [
        ("MR", "Mr."), ("MRS", "Mrs."), ("MS", "Ms."), ("DR", "Dr."), ("PROF", "Prof."),
    ]

    plant = models.ForeignKey(Plant, on_delete=models.CASCADE, related_name="crm_contacts")
    # Link to masters.Customer if they exist; null for prospects
    customer = models.ForeignKey(
        "masters.Customer", on_delete=models.SET_NULL,
        null=True, blank=True, related_name="crm_contacts"
    )
    salesperson = models.ForeignKey(
        "hr.Employee", on_delete=models.SET_NULL,
        null=True, blank=True, related_name="managed_contacts",
        help_text="Owning salesperson (hr.Employee)"
    )
    salutation = models.CharField(max_length=10, choices=SALUTATION_CHOICES, blank=True)
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100, blank=True)
    designation = models.CharField(max_length=150, blank=True)
    company_name = models.CharField(max_length=200, blank=True, help_text="For prospects not yet in masters")
    email = models.EmailField(blank=True)
    phone = models.CharField(max_length=20, blank=True)
    mobile = models.CharField(max_length=20, blank=True)
    linkedin_url = models.URLField(blank=True)
    birthday = models.DateField(null=True, blank=True)
    is_primary = models.BooleanField(default=False, help_text="Primary contact at the account")
    is_active = models.BooleanField(default=True)
    notes = models.TextField(blank=True)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="crm_contacts_created"
    )

    class Meta:
        ordering = ["last_name", "first_name"]

    def __str__(self):
        return f"{self.salutation} {self.first_name} {self.last_name}".strip()

    @property
    def full_name(self):
        return f"{self.first_name} {self.last_name}".strip()


# ═══════════════════════════════════════════════════════════════════
# LEAD
# ═══════════════════════════════════════════════════════════════════

class Lead(UUIDModel, TimeStampedModel):
    """Sales lead — top of funnel before qualification."""

    class LeadSource(models.TextChoices):
        WALK_IN     = "WALK_IN",    "Walk-In"
        PHONE       = "PHONE",      "Phone Call"
        EMAIL       = "EMAIL",      "Email"
        EXHIBITION  = "EXHIBITION", "Exhibition / Trade Show"
        REFERRAL    = "REFERRAL",   "Referral"
        WEBSITE     = "WEBSITE",    "Website"
        WHATSAPP    = "WHATSAPP",   "WhatsApp"
        CAMPAIGN    = "CAMPAIGN",   "Marketing Campaign"
        COLD_CALL   = "COLD_CALL",  "Cold Call"
        SOCIAL      = "SOCIAL",     "Social Media"
        OTHER       = "OTHER",      "Other"

    class LeadStatus(models.TextChoices):
        NEW         = "NEW",         "New"
        CONTACTED   = "CONTACTED",   "Contacted"
        WORKING     = "WORKING",     "Working"
        QUALIFIED   = "QUALIFIED",   "Qualified"
        CONVERTED   = "CONVERTED",   "Converted to Opportunity"
        UNQUALIFIED = "UNQUALIFIED", "Unqualified"
        RECYCLED    = "RECYCLED",    "Recycled"
        DEAD        = "DEAD",        "Dead"

    class LeadRating(models.TextChoices):
        HOT  = "HOT",  "Hot"
        WARM = "WARM", "Warm"
        COLD = "COLD", "Cold"

    plant = models.ForeignKey(Plant, on_delete=models.CASCADE, related_name="leads")
    lead_number = models.CharField(max_length=50, unique=True)
    lead_date = models.DateField()
    source = models.CharField(max_length=30, choices=LeadSource.choices, default=LeadSource.OTHER)
    status = models.CharField(max_length=20, choices=LeadStatus.choices, default=LeadStatus.NEW)
    rating = models.CharField(max_length=10, choices=LeadRating.choices, default=LeadRating.COLD)

    # Contact info (may be a prospect)
    contact = models.ForeignKey(
        CRMContact, on_delete=models.SET_NULL, null=True, blank=True, related_name="leads"
    )
    customer = models.ForeignKey(
        "masters.Customer", on_delete=models.SET_NULL,
        null=True, blank=True, related_name="leads"
    )
    # Prospect fields (when not yet a customer)
    prospect_name = models.CharField(max_length=200, blank=True)
    prospect_company = models.CharField(max_length=200, blank=True)
    prospect_email = models.EmailField(blank=True)
    prospect_phone = models.CharField(max_length=20, blank=True)

    # Interest
    title = models.CharField(max_length=300, help_text="Lead title / subject")
    description = models.TextField(blank=True)
    product_interest = models.TextField(blank=True, help_text="Products / categories of interest")
    estimated_value = models.DecimalField(max_digits=18, decimal_places=2, null=True, blank=True)

    # Assignment
    assigned_to = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="assigned_leads"
    )
    next_followup_date = models.DateField(null=True, blank=True)

    # Conversion
    converted_at = models.DateTimeField(null=True, blank=True)
    opportunity = models.OneToOneField(
        "Opportunity", on_delete=models.SET_NULL,
        null=True, blank=True, related_name="from_lead"
    )

    # Campaign link
    campaign = models.ForeignKey(
        "CampaignEmail", on_delete=models.SET_NULL,
        null=True, blank=True, related_name="leads_generated"
    )

    notes = models.TextField(blank=True)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="leads_created"
    )

    class Meta:
        ordering = ["-lead_date", "-created_at"]

    def __str__(self):
        return f"{self.lead_number} — {self.title[:60]}"


# ═══════════════════════════════════════════════════════════════════
# LEAD ACTIVITY
# ═══════════════════════════════════════════════════════════════════

class LeadActivity(UUIDModel, TimeStampedModel):
    """Activity log on a Lead — calls, emails, meetings, notes."""

    class ActivityType(models.TextChoices):
        CALL     = "CALL",     "Phone Call"
        EMAIL    = "EMAIL",    "Email"
        MEETING  = "MEETING",  "Meeting"
        DEMO     = "DEMO",     "Product Demo"
        NOTE     = "NOTE",     "Note"
        WHATSAPP = "WHATSAPP", "WhatsApp"
        VISIT    = "VISIT",    "Site Visit"
        FOLLOWUP = "FOLLOWUP", "Follow-Up"

    class ActivityOutcome(models.TextChoices):
        POSITIVE = "POSITIVE", "Positive"
        NEUTRAL  = "NEUTRAL",  "Neutral"
        NEGATIVE = "NEGATIVE", "Negative"
        NO_RESP  = "NO_RESP",  "No Response"

    lead = models.ForeignKey(Lead, on_delete=models.CASCADE, related_name="activities")
    activity_type = models.CharField(max_length=20, choices=ActivityType.choices)
    activity_date = models.DateTimeField(default=timezone.now)
    summary = models.CharField(max_length=500)
    details = models.TextField(blank=True)
    outcome = models.CharField(
        max_length=20, choices=ActivityOutcome.choices, blank=True
    )
    next_action = models.CharField(max_length=300, blank=True)
    next_action_date = models.DateField(null=True, blank=True)
    performed_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="lead_activities"
    )

    class Meta:
        ordering = ["-activity_date"]

    def __str__(self):
        return f"{self.lead.lead_number} | {self.activity_type} | {self.activity_date:%Y-%m-%d}"


# ═══════════════════════════════════════════════════════════════════
# OPPORTUNITY
# ═══════════════════════════════════════════════════════════════════

class Opportunity(UUIDModel, TimeStampedModel):
    """Qualified sales opportunity in the pipeline."""

    class OpportunityStatus(models.TextChoices):
        OPEN    = "OPEN",    "Open"
        WON     = "WON",     "Won"
        LOST    = "LOST",    "Lost"
        ON_HOLD = "ON_HOLD", "On Hold"

    plant = models.ForeignKey(Plant, on_delete=models.CASCADE, related_name="opportunities")
    opportunity_number = models.CharField(max_length=50, unique=True)
    name = models.CharField(max_length=300)
    stage = models.ForeignKey(
        OpportunityStage, on_delete=models.PROTECT, related_name="opportunities"
    )
    status = models.CharField(
        max_length=20, choices=OpportunityStatus.choices, default=OpportunityStatus.OPEN
    )

    # Customer
    customer = models.ForeignKey(
        "masters.Customer", on_delete=models.SET_NULL,
        null=True, blank=True, related_name="opportunities"
    )
    contact = models.ForeignKey(
        CRMContact, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="opportunities"
    )

    # Financial
    expected_value = models.DecimalField(max_digits=18, decimal_places=2, default=0)
    probability = models.DecimalField(
        max_digits=5, decimal_places=2, default=Decimal("0.00"),
        help_text="Win probability %"
    )
    weighted_value = models.DecimalField(
        max_digits=18, decimal_places=2, default=0,
        help_text="expected_value × probability/100 — maintained by service"
    )

    # Timeline
    expected_close_date = models.DateField(null=True, blank=True)
    actual_close_date = models.DateField(null=True, blank=True)

    # Assignment
    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="owned_opportunities"
    )

    # Loss reason (populated on LOST)
    lost_reason = models.CharField(max_length=300, blank=True)
    lost_to_competitor = models.CharField(max_length=200, blank=True)

    description = models.TextField(blank=True)
    notes = models.TextField(blank=True)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="opportunities_created"
    )

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.opportunity_number} — {self.name[:60]}"


# ═══════════════════════════════════════════════════════════════════
# QUOTE
# ═══════════════════════════════════════════════════════════════════

class Quote(UUIDModel, TimeStampedModel):
    """Commercial quotation linked to an Opportunity."""

    class QuoteStatus(models.TextChoices):
        DRAFT     = "DRAFT",     "Draft"
        SENT      = "SENT",      "Sent to Customer"
        ACCEPTED  = "ACCEPTED",  "Accepted"
        REJECTED  = "REJECTED",  "Rejected"
        EXPIRED   = "EXPIRED",   "Expired"
        CONVERTED = "CONVERTED", "Converted to Sales Order"

    plant = models.ForeignKey(Plant, on_delete=models.CASCADE, related_name="crm_quotes")
    quote_number = models.CharField(max_length=50, unique=True)
    quote_date = models.DateField()
    valid_until = models.DateField(null=True, blank=True)
    status = models.CharField(
        max_length=20, choices=QuoteStatus.choices, default=QuoteStatus.DRAFT
    )

    opportunity = models.ForeignKey(
        Opportunity, on_delete=models.CASCADE, related_name="quotes"
    )
    customer = models.ForeignKey(
        "masters.Customer", on_delete=models.SET_NULL,
        null=True, blank=True, related_name="crm_quotes"
    )
    contact = models.ForeignKey(
        CRMContact, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="quotes"
    )

    # Financials (maintained by services)
    subtotal = models.DecimalField(max_digits=18, decimal_places=2, default=0)
    discount_amount = models.DecimalField(max_digits=18, decimal_places=2, default=0)
    tax_amount = models.DecimalField(max_digits=18, decimal_places=2, default=0)
    total_amount = models.DecimalField(max_digits=18, decimal_places=2, default=0)

    # Terms
    payment_terms = models.CharField(max_length=200, blank=True)
    delivery_terms = models.CharField(max_length=200, blank=True)
    notes = models.TextField(blank=True)
    internal_notes = models.TextField(blank=True)

    # Conversion
    converted_at = models.DateTimeField(null=True, blank=True)
    sales_order = models.OneToOneField(
        "sales.SalesOrder", on_delete=models.SET_NULL,
        null=True, blank=True, related_name="from_crm_quote"
    )

    prepared_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="quotes_prepared"
    )
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="quotes_created"
    )

    class Meta:
        ordering = ["-quote_date", "-created_at"]

    def __str__(self):
        return f"{self.quote_number} ({self.status})"


# ═══════════════════════════════════════════════════════════════════
# QUOTE LINE ITEM
# ═══════════════════════════════════════════════════════════════════

class QuoteLineItem(UUIDModel, TimeStampedModel):
    """Line item on a CRM Quote."""

    quote = models.ForeignKey(Quote, on_delete=models.CASCADE, related_name="lines")
    line_number = models.PositiveIntegerField(default=1)

    # Product link (optional — can be free-text for non-stocked items)
    item = models.ForeignKey(
        "masters.Item", on_delete=models.SET_NULL,
        null=True, blank=True, related_name="quote_lines"
    )
    item_description = models.CharField(
        max_length=300, help_text="Auto-populated from item or entered manually"
    )
    uom = models.CharField(max_length=30, blank=True)

    quantity = models.DecimalField(max_digits=15, decimal_places=3)
    unit_price = models.DecimalField(max_digits=15, decimal_places=4)
    discount_pct = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    discount_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    taxable_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    gst_rate = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    gst_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    line_total = models.DecimalField(max_digits=15, decimal_places=2, default=0)

    notes = models.CharField(max_length=500, blank=True)

    class Meta:
        ordering = ["quote", "line_number"]

    def __str__(self):
        return f"{self.quote.quote_number} L{self.line_number} — {self.item_description[:50]}"


# ═══════════════════════════════════════════════════════════════════
# CUSTOMER VISIT
# ═══════════════════════════════════════════════════════════════════

class CustomerVisit(UUIDModel, TimeStampedModel):
    """Field-visit log by a salesperson at customer / prospect premises."""

    class VisitType(models.TextChoices):
        SALES      = "SALES",      "Sales Visit"
        FOLLOWUP   = "FOLLOWUP",   "Follow-Up"
        DEMO       = "DEMO",       "Product Demo"
        COMPLAINT  = "COMPLAINT",  "Complaint Resolution"
        COURTESY   = "COURTESY",   "Courtesy Call"
        COLLECTION = "COLLECTION", "Payment Collection"
        AUDIT      = "AUDIT",      "Customer Audit"

    class VisitOutcome(models.TextChoices):
        ORDER_EXPECTED  = "ORDER_EXPECTED",  "Order Expected"
        ORDER_RECEIVED  = "ORDER_RECEIVED",  "Order Received on Visit"
        POSITIVE        = "POSITIVE",        "Positive — Further Follow-Up"
        NEUTRAL         = "NEUTRAL",         "Neutral"
        NEGATIVE        = "NEGATIVE",        "Negative"

    plant = models.ForeignKey(Plant, on_delete=models.CASCADE, related_name="customer_visits")
    visit_number = models.CharField(max_length=50, unique=True)
    visit_date = models.DateField()
    visit_time = models.TimeField(null=True, blank=True)

    salesperson = models.ForeignKey(
        "hr.Employee", on_delete=models.PROTECT, related_name="customer_visits"
    )
    customer = models.ForeignKey(
        "masters.Customer", on_delete=models.SET_NULL,
        null=True, blank=True, related_name="visits"
    )
    contact = models.ForeignKey(
        CRMContact, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="visits"
    )
    prospect_name = models.CharField(max_length=200, blank=True)

    visit_type = models.CharField(max_length=20, choices=VisitType.choices, default=VisitType.SALES)
    outcome = models.CharField(
        max_length=25, choices=VisitOutcome.choices, blank=True
    )

    # Geo-tagging (optional)
    latitude = models.DecimalField(max_digits=10, decimal_places=7, null=True, blank=True)
    longitude = models.DecimalField(max_digits=10, decimal_places=7, null=True, blank=True)
    location_address = models.TextField(blank=True)

    purpose = models.CharField(max_length=500)
    discussion_notes = models.TextField(blank=True)
    next_action = models.CharField(max_length=300, blank=True)
    next_visit_date = models.DateField(null=True, blank=True)

    # Links
    opportunity = models.ForeignKey(
        Opportunity, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="visits"
    )
    lead = models.ForeignKey(
        Lead, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="visits"
    )

    approved = models.BooleanField(default=False)
    approved_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="approved_visits"
    )
    approved_at = models.DateTimeField(null=True, blank=True)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="visits_created"
    )

    class Meta:
        ordering = ["-visit_date", "-created_at"]

    def __str__(self):
        return f"{self.visit_number} | {self.salesperson} | {self.visit_date}"


# ═══════════════════════════════════════════════════════════════════
# CAMPAIGN EMAIL
# ═══════════════════════════════════════════════════════════════════

class CampaignEmail(UUIDModel, TimeStampedModel):
    """Email marketing campaign — header + recipient list."""

    class CampaignStatus(models.TextChoices):
        DRAFT     = "DRAFT",     "Draft"
        SCHEDULED = "SCHEDULED", "Scheduled"
        SENDING   = "SENDING",   "Sending"
        SENT      = "SENT",      "Sent"
        PAUSED    = "PAUSED",    "Paused"
        CANCELLED = "CANCELLED", "Cancelled"

    class CampaignType(models.TextChoices):
        PROMOTIONAL = "PROMOTIONAL", "Promotional"
        NEWSLETTER  = "NEWSLETTER",  "Newsletter"
        FOLLOWUP    = "FOLLOWUP",    "Follow-Up"
        SEASONAL    = "SEASONAL",    "Seasonal Greeting"
        REENGAGEMENT= "REENGAGEMENT","Re-Engagement"

    plant = models.ForeignKey(Plant, on_delete=models.CASCADE, related_name="email_campaigns")
    campaign_number = models.CharField(max_length=50, unique=True)
    name = models.CharField(max_length=200)
    campaign_type = models.CharField(
        max_length=20, choices=CampaignType.choices, default=CampaignType.PROMOTIONAL
    )
    status = models.CharField(
        max_length=20, choices=CampaignStatus.choices, default=CampaignStatus.DRAFT
    )

    subject = models.CharField(max_length=300)
    body_html = models.TextField(help_text="HTML email body")
    body_text = models.TextField(blank=True, help_text="Plain-text fallback")

    scheduled_at = models.DateTimeField(null=True, blank=True)
    sent_at = models.DateTimeField(null=True, blank=True)

    # Stats (updated by Celery tasks)
    total_recipients = models.PositiveIntegerField(default=0)
    sent_count = models.PositiveIntegerField(default=0)
    delivered_count = models.PositiveIntegerField(default=0)
    opened_count = models.PositiveIntegerField(default=0)
    clicked_count = models.PositiveIntegerField(default=0)
    bounced_count = models.PositiveIntegerField(default=0)
    unsubscribed_count = models.PositiveIntegerField(default=0)

    from_name = models.CharField(max_length=100, blank=True)
    from_email = models.EmailField(blank=True)
    reply_to = models.EmailField(blank=True)

    notes = models.TextField(blank=True)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="campaigns_created"
    )

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.campaign_number} — {self.name}"


class CampaignRecipient(UUIDModel, TimeStampedModel):
    """Individual recipient record on a CampaignEmail."""

    class DeliveryStatus(models.TextChoices):
        PENDING   = "PENDING",   "Pending"
        SENT      = "SENT",      "Sent"
        DELIVERED = "DELIVERED", "Delivered"
        OPENED    = "OPENED",    "Opened"
        CLICKED   = "CLICKED",   "Clicked"
        BOUNCED   = "BOUNCED",   "Bounced"
        FAILED    = "FAILED",    "Failed"
        OPTED_OUT = "OPTED_OUT", "Opted Out"

    campaign = models.ForeignKey(
        CampaignEmail, on_delete=models.CASCADE, related_name="recipients"
    )
    contact = models.ForeignKey(
        CRMContact, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="campaign_receipts"
    )
    email = models.EmailField()
    name = models.CharField(max_length=200, blank=True)
    delivery_status = models.CharField(
        max_length=20, choices=DeliveryStatus.choices, default=DeliveryStatus.PENDING
    )
    sent_at = models.DateTimeField(null=True, blank=True)
    opened_at = models.DateTimeField(null=True, blank=True)
    clicked_at = models.DateTimeField(null=True, blank=True)
    failure_reason = models.CharField(max_length=300, blank=True)

    class Meta:
        unique_together = [("campaign", "email")]
        ordering = ["campaign", "name"]

    def __str__(self):
        return f"{self.campaign.campaign_number} → {self.email}"
