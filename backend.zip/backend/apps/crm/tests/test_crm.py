"""
CRM Module Tests — Section 15

Covers:
  - OpportunityStage creation
  - CRMContact CRUD
  - Lead creation (create_lead)
  - Lead activity logging
  - Lead convert to opportunity (convert_lead_to_opportunity)
  - advance_opportunity_stage (open → won, open → lost)
  - Quote generation (generate_quote) + line totals
  - Quote convert to sales order (convert_quote_to_sales_order)
  - CustomerVisit logging (log_customer_visit)
  - Pipeline report (get_sales_pipeline_report)
  - Campaign creation (schedule_campaign) + recipient de-dup
  - API endpoints: leads list, create, convert action
  - API: opportunity pipeline-report
  - API: quote create + convert-to-so
  - API: visit create + approve
  - API: campaign send-now + stats
  - Expired quote task
  - Follow-up reminder task
"""
from datetime import date, timedelta
from decimal import Decimal
from unittest.mock import patch, MagicMock
from django.test import TestCase
from django.contrib.auth import get_user_model
from rest_framework.test import APIClient
from rest_framework import status

User = get_user_model()


def _setup_base():
    """Create minimal shared fixtures."""
    from apps.core.models import Plant
    user = User.objects.create_user(
        username="crm_user", password="pass123",
        first_name="CRM", last_name="User",
    )
    plant = Plant.objects.create(code="PLT", name="Test Plant")
    return user, plant


class OpportunityStageTest(TestCase):
    def setUp(self):
        self.user, self.plant = _setup_base()

    def test_create_stage(self):
        from apps.crm.models import OpportunityStage
        stage = OpportunityStage.objects.create(
            plant=self.plant, name="Prospecting", order=1, probability=Decimal("10.00")
        )
        self.assertEqual(stage.name, "Prospecting")
        self.assertFalse(stage.is_won)
        self.assertFalse(stage.is_lost)

    def test_won_lost_flags(self):
        from apps.crm.models import OpportunityStage
        won = OpportunityStage.objects.create(
            plant=self.plant, name="Won", order=9, probability=Decimal("100.00"), is_won=True
        )
        lost = OpportunityStage.objects.create(
            plant=self.plant, name="Lost", order=10, probability=Decimal("0.00"), is_lost=True
        )
        self.assertTrue(won.is_won)
        self.assertTrue(lost.is_lost)


class CRMContactTest(TestCase):
    def setUp(self):
        self.user, self.plant = _setup_base()

    def test_create_contact(self):
        from apps.crm.models import CRMContact
        contact = CRMContact.objects.create(
            plant=self.plant,
            first_name="Ravi", last_name="Sharma",
            email="ravi@acme.com", mobile="9876543210",
            designation="Purchase Manager",
            created_by=self.user,
        )
        self.assertEqual(contact.full_name, "Ravi Sharma")

    def test_contact_full_name_no_last(self):
        from apps.crm.models import CRMContact
        contact = CRMContact.objects.create(
            plant=self.plant, first_name="Raj", created_by=self.user
        )
        self.assertEqual(contact.full_name, "Raj")


class CreateLeadServiceTest(TestCase):
    def setUp(self):
        self.user, self.plant = _setup_base()

    def test_create_lead_basic(self):
        from apps.crm.services import create_lead
        lead = create_lead(
            plant=self.plant,
            title="Box requirement for festive season",
            source="EMAIL",
            prospect_name="Acme Corp",
            created_by=self.user,
        )
        self.assertIsNotNone(lead.lead_number)
        self.assertTrue(lead.lead_number.startswith("LDN/"))
        self.assertEqual(lead.status, "NEW")

    def test_lead_number_sequential(self):
        from apps.crm.services import create_lead
        l1 = create_lead(plant=self.plant, title="L1", source="EMAIL", created_by=self.user)
        l2 = create_lead(plant=self.plant, title="L2", source="EMAIL", created_by=self.user)
        self.assertNotEqual(l1.lead_number, l2.lead_number)

    def test_create_lead_with_estimated_value(self):
        from apps.crm.services import create_lead
        lead = create_lead(
            plant=self.plant,
            title="Bulk packaging deal",
            source="REFERRAL",
            estimated_value=Decimal("500000"),
            created_by=self.user,
        )
        self.assertEqual(lead.estimated_value, Decimal("500000"))


class ConvertLeadTest(TestCase):
    def setUp(self):
        self.user, self.plant = _setup_base()
        from apps.crm.models import OpportunityStage
        from apps.crm.services import create_lead
        self.stage = OpportunityStage.objects.create(
            plant=self.plant, name="Qualified", order=2, probability=Decimal("30.00")
        )
        self.lead = create_lead(
            plant=self.plant, title="Test Lead", source="PHONE", created_by=self.user
        )

    def test_convert_lead(self):
        from apps.crm.services import convert_lead_to_opportunity
        from apps.crm.models import Lead
        opp = convert_lead_to_opportunity(
            lead=self.lead, stage=self.stage, owner=self.user, converted_by=self.user
        )
        self.lead.refresh_from_db()
        self.assertEqual(self.lead.status, Lead.LeadStatus.CONVERTED)
        self.assertEqual(self.lead.opportunity, opp)
        self.assertTrue(opp.opportunity_number.startswith("OPP/"))

    def test_cannot_convert_twice(self):
        from apps.crm.services import convert_lead_to_opportunity
        convert_lead_to_opportunity(
            lead=self.lead, stage=self.stage, owner=self.user, converted_by=self.user
        )
        with self.assertRaises(ValueError):
            convert_lead_to_opportunity(
                lead=self.lead, stage=self.stage, owner=self.user, converted_by=self.user
            )

    def test_weighted_value_computed(self):
        from apps.crm.services import convert_lead_to_opportunity
        opp = convert_lead_to_opportunity(
            lead=self.lead,
            stage=self.stage,
            expected_value=Decimal("100000"),
            owner=self.user,
            converted_by=self.user,
        )
        self.assertEqual(opp.weighted_value, Decimal("30000.00"))


class AdvanceStageTest(TestCase):
    def setUp(self):
        self.user, self.plant = _setup_base()
        from apps.crm.models import OpportunityStage, Opportunity
        self.stage1 = OpportunityStage.objects.create(
            plant=self.plant, name="Proposal", order=3, probability=Decimal("50.00")
        )
        self.won_stage = OpportunityStage.objects.create(
            plant=self.plant, name="Won", order=9, probability=Decimal("100.00"), is_won=True
        )
        self.lost_stage = OpportunityStage.objects.create(
            plant=self.plant, name="Lost", order=10, probability=Decimal("0.00"), is_lost=True
        )
        self.opp = Opportunity.objects.create(
            plant=self.plant,
            opportunity_number="OPP/2025-26/00001",
            name="Test Opportunity",
            stage=self.stage1,
            status="OPEN",
            expected_value=Decimal("200000"),
            probability=Decimal("50.00"),
            weighted_value=Decimal("100000"),
            owner=self.user,
            created_by=self.user,
        )

    def test_advance_to_won(self):
        from apps.crm.services import advance_opportunity_stage
        from apps.crm.models import Opportunity
        opp = advance_opportunity_stage(
            opportunity=self.opp, new_stage=self.won_stage, updated_by=self.user
        )
        self.assertEqual(opp.status, Opportunity.OpportunityStatus.WON)
        self.assertIsNotNone(opp.actual_close_date)

    def test_advance_to_lost(self):
        from apps.crm.services import advance_opportunity_stage
        from apps.crm.models import Opportunity
        opp = advance_opportunity_stage(
            opportunity=self.opp,
            new_stage=self.lost_stage,
            lost_reason="Price too high",
            lost_to_competitor="Competitor X",
            updated_by=self.user,
        )
        self.assertEqual(opp.status, Opportunity.OpportunityStatus.LOST)
        self.assertEqual(opp.lost_reason, "Price too high")


class GenerateQuoteTest(TestCase):
    def setUp(self):
        self.user, self.plant = _setup_base()
        from apps.crm.models import OpportunityStage, Opportunity
        stage = OpportunityStage.objects.create(
            plant=self.plant, name="Proposal", order=3, probability=Decimal("50.00")
        )
        self.opp = Opportunity.objects.create(
            plant=self.plant,
            opportunity_number="OPP/2025-26/00001",
            name="Test Opp",
            stage=stage,
            status="OPEN",
            expected_value=Decimal("0"),
            probability=Decimal("50.00"),
            weighted_value=Decimal("0"),
            owner=self.user,
            created_by=self.user,
        )

    def test_generate_quote_totals(self):
        from apps.crm.services import generate_quote
        quote = generate_quote(
            opportunity=self.opp,
            lines=[
                {
                    "item_description": "Corrugated Box 5-ply",
                    "uom": "NOS", "quantity": "1000",
                    "unit_price": "12.50", "discount_pct": "5",
                    "gst_rate": "18",
                },
            ],
            created_by=self.user,
        )
        # subtotal = 1000 × 12.50 × (1 - 5%) = 11875
        self.assertEqual(quote.subtotal, Decimal("11875.00"))
        # gst = 11875 × 18% = 2137.50
        self.assertEqual(quote.tax_amount, Decimal("2137.50"))
        self.assertEqual(quote.total_amount, Decimal("14012.50"))

    def test_quote_number_starts_with_qcr(self):
        from apps.crm.services import generate_quote
        quote = generate_quote(
            opportunity=self.opp,
            lines=[{"item_description": "Box", "uom": "NOS", "quantity": "10", "unit_price": "100"}],
            created_by=self.user,
        )
        self.assertTrue(quote.quote_number.startswith("QCR/"))

    def test_opportunity_expected_value_updated(self):
        from apps.crm.services import generate_quote
        quote = generate_quote(
            opportunity=self.opp,
            lines=[{"item_description": "Box", "uom": "NOS", "quantity": "100", "unit_price": "50", "gst_rate": "12"}],
            created_by=self.user,
        )
        self.opp.refresh_from_db()
        self.assertEqual(self.opp.expected_value, quote.total_amount)


class CustomerVisitTest(TestCase):
    def setUp(self):
        self.user, self.plant = _setup_base()
        from apps.hr.models import Employee, Department
        from apps.masters.models import Customer
        dept = Department.objects.create(plant=self.plant, code="SLS", name="Sales")
        self.employee = Employee.objects.create(
            plant=self.plant,
            employee_code="E001",
            first_name="Ravi",
            last_name="Sales",
            department=dept,
            date_of_joining=date.today(),
            status="ACTIVE",
        )
        self.customer = Customer.objects.create(
            plant=self.plant,
            customer_code="C001",
            name="Acme Corp",
            created_by=self.user,
        )

    def test_log_visit(self):
        from apps.crm.services import log_customer_visit
        visit = log_customer_visit(
            plant=self.plant,
            salesperson=self.employee,
            visit_date=date.today(),
            purpose="Introduce new product range",
            customer=self.customer,
            discussion_notes="Interested in 5-ply boxes",
            outcome="ORDER_EXPECTED",
            created_by=self.user,
        )
        self.assertTrue(visit.visit_number.startswith("VST/"))
        self.assertEqual(visit.outcome, "ORDER_EXPECTED")

    def test_visit_number_unique(self):
        from apps.crm.services import log_customer_visit
        v1 = log_customer_visit(
            plant=self.plant, salesperson=self.employee,
            visit_date=date.today(), purpose="V1", created_by=self.user,
        )
        v2 = log_customer_visit(
            plant=self.plant, salesperson=self.employee,
            visit_date=date.today(), purpose="V2", created_by=self.user,
        )
        self.assertNotEqual(v1.visit_number, v2.visit_number)


class PipelineReportTest(TestCase):
    def setUp(self):
        self.user, self.plant = _setup_base()
        from apps.crm.models import OpportunityStage, Opportunity
        self.s1 = OpportunityStage.objects.create(
            plant=self.plant, name="Intro", order=1, probability=Decimal("20.00")
        )
        self.s2 = OpportunityStage.objects.create(
            plant=self.plant, name="Demo", order=2, probability=Decimal("60.00")
        )
        Opportunity.objects.create(
            plant=self.plant, opportunity_number="OPP/25-26/001",
            name="Opp1", stage=self.s1, status="OPEN",
            expected_value=Decimal("100000"), probability=Decimal("20.00"),
            weighted_value=Decimal("20000"), owner=self.user, created_by=self.user,
        )
        Opportunity.objects.create(
            plant=self.plant, opportunity_number="OPP/25-26/002",
            name="Opp2", stage=self.s2, status="OPEN",
            expected_value=Decimal("200000"), probability=Decimal("60.00"),
            weighted_value=Decimal("120000"), owner=self.user, created_by=self.user,
        )

    def test_pipeline_report_totals(self):
        from apps.crm.services import get_sales_pipeline_report
        report = get_sales_pipeline_report(plant=self.plant)
        self.assertEqual(report["opportunity_count"], 2)
        self.assertEqual(report["total_expected_value"], "300000.00")
        self.assertEqual(report["total_weighted_value"], "140000.00")
        self.assertEqual(len(report["by_stage"]), 2)

    def test_pipeline_report_by_owner(self):
        from apps.crm.services import get_sales_pipeline_report
        report = get_sales_pipeline_report(plant=self.plant)
        self.assertEqual(len(report["by_owner"]), 1)


class CampaignTest(TestCase):
    def setUp(self):
        self.user, self.plant = _setup_base()

    @patch("apps.crm.services.send_campaign_emails_task")
    def test_create_campaign(self, mock_task):
        mock_task.delay = MagicMock()
        from apps.crm.services import schedule_campaign
        campaign = schedule_campaign(
            plant=self.plant,
            name="New Year Campaign",
            campaign_type="SEASONAL",
            subject="Happy New Year from Trident!",
            body_html="<h1>Happy New Year!</h1>",
            recipients=[
                {"email": "a@b.com", "name": "Customer A"},
                {"email": "c@d.com", "name": "Customer B"},
            ],
            created_by=self.user,
        )
        self.assertTrue(campaign.campaign_number.startswith("CMP/"))
        self.assertEqual(campaign.total_recipients, 2)

    @patch("apps.crm.services.send_campaign_emails_task")
    def test_campaign_dedup_recipients(self, mock_task):
        mock_task.delay = MagicMock()
        from apps.crm.services import schedule_campaign
        campaign = schedule_campaign(
            plant=self.plant,
            name="Dedup Test",
            campaign_type="PROMOTIONAL",
            subject="Test",
            body_html="<p>Hi</p>",
            recipients=[
                {"email": "dup@b.com", "name": "A"},
                {"email": "DUP@B.COM", "name": "B"},  # duplicate (case-insensitive)
            ],
            created_by=self.user,
        )
        self.assertEqual(campaign.total_recipients, 1)


class CRMAPITest(TestCase):
    def setUp(self):
        self.user, self.plant = _setup_base()
        self.client = APIClient()
        self.client.force_authenticate(user=self.user)
        from apps.crm.models import OpportunityStage
        self.stage = OpportunityStage.objects.create(
            plant=self.plant, name="Qualified", order=2, probability=Decimal("30.00")
        )

    def test_list_leads_empty(self):
        resp = self.client.get("/api/v1/crm/leads/")
        self.assertEqual(resp.status_code, status.HTTP_200_OK)

    def test_create_lead_via_api(self):
        resp = self.client.post("/api/v1/crm/leads/", {
            "plant": str(self.plant.id),
            "title": "API Lead Test",
            "source": "WEBSITE",
            "prospect_name": "Test Prospect",
        }, format="json")
        self.assertEqual(resp.status_code, status.HTTP_201_CREATED)
        self.assertIn("lead_number", resp.data)

    def test_lead_convert_action(self):
        from apps.crm.services import create_lead
        lead = create_lead(
            plant=self.plant, title="Convert Me", source="EMAIL", created_by=self.user
        )
        resp = self.client.post(f"/api/v1/crm/leads/{lead.id}/convert/", {
            "stage": str(self.stage.id),
            "expected_value": "100000",
        }, format="json")
        self.assertEqual(resp.status_code, status.HTTP_200_OK)
        self.assertIn("opportunity_number", resp.data)

    def test_pipeline_report_api(self):
        resp = self.client.get(f"/api/v1/crm/opportunities/pipeline-report/?plant={self.plant.id}")
        self.assertEqual(resp.status_code, status.HTTP_200_OK)
        self.assertIn("total_expected_value", resp.data)

    def test_visit_approve_action(self):
        from apps.crm.models import CustomerVisit
        from apps.hr.models import Employee, Department
        dept = Department.objects.create(plant=self.plant, code="SLS2", name="Sales2")
        emp = Employee.objects.create(
            plant=self.plant, employee_code="E002", first_name="Test",
            department=dept, date_of_joining=date.today(), status="ACTIVE",
        )
        from apps.crm.services import log_customer_visit
        visit = log_customer_visit(
            plant=self.plant, salesperson=emp,
            visit_date=date.today(), purpose="Test",
            created_by=self.user,
        )
        resp = self.client.post(f"/api/v1/crm/visits/{visit.id}/approve/", {}, format="json")
        self.assertEqual(resp.status_code, status.HTTP_200_OK)
        self.assertTrue(resp.data["approved"])

    def test_stage_list(self):
        resp = self.client.get(f"/api/v1/crm/stages/?plant={self.plant.id}")
        self.assertEqual(resp.status_code, status.HTTP_200_OK)
        self.assertGreaterEqual(len(resp.data), 1)


class ExpiredQuoteTaskTest(TestCase):
    def setUp(self):
        self.user, self.plant = _setup_base()

    def test_mark_expired_quotes(self):
        from apps.crm.models import OpportunityStage, Opportunity, Quote
        stage = OpportunityStage.objects.create(
            plant=self.plant, name="Proposal", order=3, probability=Decimal("50.00")
        )
        opp = Opportunity.objects.create(
            plant=self.plant, opportunity_number="OPP/25-26/EXP",
            name="Expiry Test", stage=stage, status="OPEN",
            expected_value=Decimal("0"), probability=Decimal("50.00"),
            weighted_value=Decimal("0"), owner=self.user, created_by=self.user,
        )
        old_quote = Quote.objects.create(
            plant=self.plant,
            quote_number="QCR/2025-26/OLD",
            quote_date=date.today() - timedelta(days=60),
            valid_until=date.today() - timedelta(days=1),
            status=Quote.QuoteStatus.SENT,
            opportunity=opp,
        )
        from apps.crm.tasks import mark_expired_quotes
        result = mark_expired_quotes()
        old_quote.refresh_from_db()
        self.assertEqual(old_quote.status, Quote.QuoteStatus.EXPIRED)
        self.assertIn("Marked 1", result)
