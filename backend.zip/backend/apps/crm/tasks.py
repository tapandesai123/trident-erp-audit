"""CRM Module Celery Tasks."""
from celery import shared_task
from django.utils import timezone


@shared_task(bind=True, max_retries=3, default_retry_delay=300)
def send_campaign_emails_task(self, campaign_id: str):
    """
    Send emails to all PENDING recipients of a CampaignEmail.
    Uses Django's send_mail; in production replace with SMTP/MSG91/SendGrid.
    """
    try:
        from apps.crm.models import CampaignEmail, CampaignRecipient
        campaign = CampaignEmail.objects.get(pk=campaign_id)

        if campaign.status not in (
            CampaignEmail.CampaignStatus.DRAFT,
            CampaignEmail.CampaignStatus.SCHEDULED,
        ):
            return f"Campaign {campaign.campaign_number} already in status {campaign.status}. Skipping."

        campaign.status = CampaignEmail.CampaignStatus.SENDING
        campaign.save(update_fields=["status"])

        pending = campaign.recipients.filter(
            delivery_status=CampaignRecipient.DeliveryStatus.PENDING
        )
        sent_count = 0
        failed_count = 0

        for recipient in pending:
            try:
                from django.core.mail import send_mail
                from_email = campaign.from_email or "noreply@trident.local"
                send_mail(
                    subject=campaign.subject,
                    message=campaign.body_text or "Please view this email in an HTML-capable client.",
                    from_email=f"{campaign.from_name} <{from_email}>" if campaign.from_name else from_email,
                    recipient_list=[recipient.email],
                    html_message=campaign.body_html,
                    fail_silently=False,
                )
                recipient.delivery_status = CampaignRecipient.DeliveryStatus.SENT
                recipient.sent_at = timezone.now()
                recipient.save(update_fields=["delivery_status", "sent_at"])
                sent_count += 1
            except Exception as exc:
                recipient.delivery_status = CampaignRecipient.DeliveryStatus.FAILED
                recipient.failure_reason = str(exc)[:300]
                recipient.save(update_fields=["delivery_status", "failure_reason"])
                failed_count += 1

        campaign.status = CampaignEmail.CampaignStatus.SENT
        campaign.sent_at = timezone.now()
        campaign.sent_count = sent_count
        campaign.save(update_fields=["status", "sent_at", "sent_count"])

        return f"Campaign {campaign.campaign_number}: {sent_count} sent, {failed_count} failed."

    except Exception as exc:
        raise self.retry(exc=exc)


@shared_task(bind=True, max_retries=3, default_retry_delay=300)
def mark_expired_quotes(self):
    """
    Daily: Mark SENT quotes whose valid_until < today as EXPIRED.
    """
    try:
        from apps.crm.models import Quote
        today = timezone.now().date()
        expired = Quote.objects.filter(
            status=Quote.QuoteStatus.SENT,
            valid_until__lt=today,
        ).update(status=Quote.QuoteStatus.EXPIRED)
        return f"Marked {expired} quotes as EXPIRED."
    except Exception as exc:
        raise self.retry(exc=exc)


@shared_task(bind=True, max_retries=3, default_retry_delay=300)
def followup_reminder_task(self):
    """
    Daily: Send in-app notifications for leads with next_followup_date = today.
    """
    try:
        from apps.crm.models import Lead
        from apps.core.models import Notification
        today = timezone.now().date()

        due_leads = Lead.objects.filter(
            next_followup_date=today,
            status__in=["NEW", "CONTACTED", "WORKING", "QUALIFIED"],
            assigned_to__isnull=False,
        ).select_related("assigned_to")

        count = 0
        for lead in due_leads:
            Notification.objects.create(
                user=lead.assigned_to,
                title=f"Follow-Up Due: {lead.lead_number}",
                message=f"Lead '{lead.title}' is due for follow-up today.",
                notification_type="IN_APP",
                module="crm",
                resource="Lead",
                resource_id=lead.id,
            )
            count += 1
        return f"Sent {count} follow-up reminders."
    except Exception as exc:
        raise self.retry(exc=exc)


@shared_task(bind=True, max_retries=3, default_retry_delay=300)
def opportunity_stale_alert(self):
    """
    Weekly: Alert owners of OPEN opportunities with no activity for 14+ days.
    """
    try:
        from apps.crm.models import Opportunity
        from apps.core.models import Notification
        from datetime import timedelta

        cutoff = timezone.now() - timedelta(days=14)
        stale = Opportunity.objects.filter(
            status="OPEN",
            updated_at__lt=cutoff,
            owner__isnull=False,
        ).select_related("owner")

        count = 0
        for opp in stale:
            Notification.objects.create(
                user=opp.owner,
                title=f"Stale Opportunity: {opp.opportunity_number}",
                message=f"Opportunity '{opp.name}' has had no updates for 14+ days.",
                notification_type="IN_APP",
                module="crm",
                resource="Opportunity",
                resource_id=opp.id,
            )
            count += 1
        return f"Sent {count} stale opportunity alerts."
    except Exception as exc:
        raise self.retry(exc=exc)


@shared_task(bind=True, max_retries=3, default_retry_delay=300)
def sync_campaign_stats(self):
    """
    Hourly: Recount delivered/opened/clicked/bounced from recipient rows into campaign header.
    """
    try:
        from apps.crm.models import CampaignEmail, CampaignRecipient
        from django.db.models import Count, Q

        campaigns = CampaignEmail.objects.filter(
            status__in=[CampaignEmail.CampaignStatus.SENDING, CampaignEmail.CampaignStatus.SENT]
        )
        for campaign in campaigns:
            recipients = campaign.recipients.all()
            campaign.delivered_count = recipients.filter(
                delivery_status__in=["DELIVERED", "OPENED", "CLICKED"]
            ).count()
            campaign.opened_count = recipients.filter(
                delivery_status__in=["OPENED", "CLICKED"]
            ).count()
            campaign.clicked_count = recipients.filter(delivery_status="CLICKED").count()
            campaign.bounced_count = recipients.filter(delivery_status="BOUNCED").count()
            campaign.unsubscribed_count = recipients.filter(delivery_status="OPTED_OUT").count()
            campaign.save(update_fields=[
                "delivered_count", "opened_count", "clicked_count",
                "bounced_count", "unsubscribed_count",
            ])
        return f"Stats synced for {campaigns.count()} campaigns."
    except Exception as exc:
        raise self.retry(exc=exc)
