"""
CRM Module Services — Section 15

Services:
  create_lead()                    — Create lead with auto-number; AuditLog + Notification
  convert_lead_to_opportunity()    — Qualify lead → create Opportunity; link back to lead
  advance_opportunity_stage()      — Move opportunity to next/specific stage
  generate_quote()                 — Create Quote + QuoteLineItems for an Opportunity
  convert_quote_to_sales_order()   — Accept quote → create sales.SalesOrder
  log_customer_visit()             — Record a CustomerVisit; notify manager
  get_sales_pipeline_report()      — Weighted pipeline report by stage/salesperson
"""
from __future__ import annotations

from datetime import date
from decimal import Decimal, ROUND_HALF_UP
from typing import Optional, List, Dict, Any

from django.db import transaction
from django.utils import timezone

from apps.core.models import AuditLog, DocSequence, Notification


# ─── Helpers ──────────────────────────────────────────────────────

def _two(val) -> Decimal:
    return Decimal(str(val)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def _four(val) -> Decimal:
    return Decimal(str(val)).quantize(Decimal("0.0001"), rounding=ROUND_HALF_UP)


def _log(user, action: str, resource: str, resource_id, details: dict = None):
    AuditLog.objects.create(
        user=user,
        action=action,
        module="crm",
        resource=resource,
        resource_id=str(resource_id),
        new_values=details or {},
    )


def _notify(user, title: str, message: str, resource: str, resource_id):
    if user:
        Notification.objects.create(
            user=user,
            title=title,
            message=message,
            notification_type="IN_APP",
            module="crm",
            resource=resource,
            resource_id=resource_id,
        )


def get_next_doc_number(plant, doc_type: str, prefix: str) -> str:
    """Thread-safe sequential document numbering. Format: PREFIX/YYYY-YY/00001"""
    today = date.today()
    fy_start = today.year if today.month >= 4 else today.year - 1
    fy_label = f"{fy_start}-{str(fy_start + 1)[2:]}"

    with transaction.atomic():
        seq, _ = DocSequence.objects.select_for_update().get_or_create(
            plant=plant,
            doc_type=doc_type,
            defaults={"last_number": 0, "financial_year": fy_label},
        )
        if seq.financial_year != fy_label:
            seq.financial_year = fy_label
            seq.last_number = 0

        seq.last_number += 1
        seq.save(update_fields=["last_number", "financial_year"])
        return f"{prefix}/{fy_label}/{seq.last_number:05d}"


# ═══════════════════════════════════════════════════════════════════
# CREATE LEAD
# ═══════════════════════════════════════════════════════════════════

@transaction.atomic
def create_lead(
    *,
    plant,
    title: str,
    source: str,
    lead_date: date | None = None,
    customer=None,
    contact=None,
    prospect_name: str = "",
    prospect_company: str = "",
    prospect_email: str = "",
    prospect_phone: str = "",
    product_interest: str = "",
    estimated_value: Decimal | None = None,
    assigned_to=None,
    next_followup_date: date | None = None,
    description: str = "",
    notes: str = "",
    rating: str = "COLD",
    campaign=None,
    created_by=None,
):
    """
    Create a new Lead with auto-numbered lead_number.
    Notifies the assigned_to user if set.
    """
    from apps.crm.models import Lead

    lead_number = get_next_doc_number(plant, "LEAD", "LDN")

    lead = Lead.objects.create(
        plant=plant,
        lead_number=lead_number,
        lead_date=lead_date or date.today(),
        title=title,
        source=source,
        rating=rating,
        status=Lead.LeadStatus.NEW,
        customer=customer,
        contact=contact,
        prospect_name=prospect_name,
        prospect_company=prospect_company,
        prospect_email=prospect_email,
        prospect_phone=prospect_phone,
        product_interest=product_interest,
        estimated_value=estimated_value,
        assigned_to=assigned_to,
        next_followup_date=next_followup_date,
        description=description,
        notes=notes,
        campaign=campaign,
        created_by=created_by,
    )

    _log(created_by, "CREATE", "Lead", lead.id, {
        "lead_number": lead.lead_number,
        "title": title,
        "source": source,
    })

    if assigned_to:
        _notify(
            assigned_to,
            f"New Lead Assigned: {lead.lead_number}",
            f"You have been assigned lead '{title}'. Source: {source}.",
            "Lead", lead.id,
        )

    return lead


# ═══════════════════════════════════════════════════════════════════
# CONVERT LEAD TO OPPORTUNITY
# ═══════════════════════════════════════════════════════════════════

@transaction.atomic
def convert_lead_to_opportunity(
    *,
    lead,
    stage,
    name: str | None = None,
    expected_value: Decimal | None = None,
    expected_close_date: date | None = None,
    owner=None,
    converted_by=None,
):
    """
    Qualify a Lead → create an Opportunity, link them bidirectionally.
    If lead has a prospect (not yet a Customer), no customer is linked
    — the user should create a masters.Customer separately or pass one.
    """
    from apps.crm.models import Lead, Opportunity

    if lead.status == Lead.LeadStatus.CONVERTED:
        raise ValueError(f"Lead {lead.lead_number} is already converted.")

    opp_number = get_next_doc_number(lead.plant, "OPP", "OPP")

    opportunity = Opportunity.objects.create(
        plant=lead.plant,
        opportunity_number=opp_number,
        name=name or lead.title,
        stage=stage,
        status=Opportunity.OpportunityStatus.OPEN,
        customer=lead.customer,
        contact=lead.contact,
        expected_value=expected_value or lead.estimated_value or Decimal("0"),
        probability=stage.probability,
        weighted_value=_two(
            (expected_value or lead.estimated_value or Decimal("0"))
            * stage.probability / 100
        ),
        expected_close_date=expected_close_date,
        owner=owner or lead.assigned_to,
        created_by=converted_by,
    )

    # Update lead
    lead.status = Lead.LeadStatus.CONVERTED
    lead.converted_at = timezone.now()
    lead.opportunity = opportunity
    lead.save(update_fields=["status", "converted_at", "opportunity"])

    _log(converted_by, "CONVERT", "Lead", lead.id, {
        "opportunity_number": opp_number,
        "lead_number": lead.lead_number,
    })

    if opportunity.owner:
        _notify(
            opportunity.owner,
            f"Opportunity Created: {opp_number}",
            f"Lead '{lead.lead_number}' converted to opportunity '{opportunity.name}'.",
            "Opportunity", opportunity.id,
        )

    return opportunity


# ═══════════════════════════════════════════════════════════════════
# ADVANCE OPPORTUNITY STAGE
# ═══════════════════════════════════════════════════════════════════

@transaction.atomic
def advance_opportunity_stage(
    *,
    opportunity,
    new_stage,
    probability: Decimal | None = None,
    lost_reason: str = "",
    lost_to_competitor: str = "",
    actual_close_date: date | None = None,
    updated_by=None,
):
    """
    Move an Opportunity to a new stage.
    Marks status WON or LOST if the stage is terminal.
    Recalculates weighted_value.
    """
    from apps.crm.models import Opportunity

    old_stage_name = opportunity.stage.name
    opportunity.stage = new_stage
    new_prob = probability if probability is not None else new_stage.probability
    opportunity.probability = new_prob
    opportunity.weighted_value = _two(opportunity.expected_value * new_prob / 100)

    if new_stage.is_won:
        opportunity.status = Opportunity.OpportunityStatus.WON
        opportunity.actual_close_date = actual_close_date or date.today()
    elif new_stage.is_lost:
        opportunity.status = Opportunity.OpportunityStatus.LOST
        opportunity.lost_reason = lost_reason
        opportunity.lost_to_competitor = lost_to_competitor
        opportunity.actual_close_date = actual_close_date or date.today()

    opportunity.save(update_fields=[
        "stage", "probability", "weighted_value", "status",
        "actual_close_date", "lost_reason", "lost_to_competitor",
    ])

    _log(updated_by, "STAGE_CHANGE", "Opportunity", opportunity.id, {
        "opportunity_number": opportunity.opportunity_number,
        "from_stage": old_stage_name,
        "to_stage": new_stage.name,
        "status": opportunity.status,
    })

    if opportunity.owner and opportunity.status in (
        Opportunity.OpportunityStatus.WON, Opportunity.OpportunityStatus.LOST
    ):
        _notify(
            opportunity.owner,
            f"Opportunity {opportunity.status}: {opportunity.opportunity_number}",
            f"'{opportunity.name}' moved to stage '{new_stage.name}'.",
            "Opportunity", opportunity.id,
        )

    return opportunity


# ═══════════════════════════════════════════════════════════════════
# GENERATE QUOTE
# ═══════════════════════════════════════════════════════════════════

@transaction.atomic
def generate_quote(
    *,
    opportunity,
    quote_date: date | None = None,
    valid_until: date | None = None,
    lines: List[Dict[str, Any]],  # list of line dicts
    payment_terms: str = "",
    delivery_terms: str = "",
    notes: str = "",
    internal_notes: str = "",
    prepared_by=None,
    created_by=None,
):
    """
    Create a Quote + QuoteLineItems for an Opportunity.

    lines: [
      {
        item_id (optional), item_description, uom, quantity, unit_price,
        discount_pct (default 0), gst_rate (default 0), notes
      },
      ...
    ]
    """
    from apps.crm.models import Quote, QuoteLineItem
    try:
        from apps.masters.models import Item
        item_model = Item
    except ImportError:
        item_model = None

    quote_number = get_next_doc_number(opportunity.plant, "CRM_QUOTE", "QCR")

    quote = Quote.objects.create(
        plant=opportunity.plant,
        quote_number=quote_number,
        quote_date=quote_date or date.today(),
        valid_until=valid_until,
        status=Quote.QuoteStatus.DRAFT,
        opportunity=opportunity,
        customer=opportunity.customer,
        contact=opportunity.contact,
        payment_terms=payment_terms,
        delivery_terms=delivery_terms,
        notes=notes,
        internal_notes=internal_notes,
        prepared_by=prepared_by,
        created_by=created_by,
    )

    subtotal = Decimal("0")
    total_discount = Decimal("0")
    total_tax = Decimal("0")

    for idx, line_data in enumerate(lines, start=1):
        item = None
        if item_model and line_data.get("item_id"):
            try:
                item = item_model.objects.get(pk=line_data["item_id"])
            except item_model.DoesNotExist:
                pass

        qty = _four(line_data.get("quantity", 0))
        unit_price = _four(line_data.get("unit_price", 0))
        disc_pct = _two(line_data.get("discount_pct", 0))
        gst_rate = _two(line_data.get("gst_rate", 0))

        gross = _two(qty * unit_price)
        disc_amt = _two(gross * disc_pct / 100)
        taxable = _two(gross - disc_amt)
        gst_amt = _two(taxable * gst_rate / 100)
        line_total = _two(taxable + gst_amt)

        QuoteLineItem.objects.create(
            quote=quote,
            line_number=idx,
            item=item,
            item_description=line_data.get(
                "item_description",
                item.name if item else ""
            ),
            uom=line_data.get("uom", item.uom.code if item and hasattr(item, "uom") else ""),
            quantity=qty,
            unit_price=unit_price,
            discount_pct=disc_pct,
            discount_amount=disc_amt,
            taxable_amount=taxable,
            gst_rate=gst_rate,
            gst_amount=gst_amt,
            line_total=line_total,
            notes=line_data.get("notes", ""),
        )

        subtotal += taxable
        total_discount += disc_amt
        total_tax += gst_amt

    quote.subtotal = _two(subtotal)
    quote.discount_amount = _two(total_discount)
    quote.tax_amount = _two(total_tax)
    quote.total_amount = _two(subtotal + total_tax)
    quote.save(update_fields=["subtotal", "discount_amount", "tax_amount", "total_amount"])

    # Update opportunity expected_value to match quote
    opportunity.expected_value = quote.total_amount
    opportunity.weighted_value = _two(quote.total_amount * opportunity.probability / 100)
    opportunity.save(update_fields=["expected_value", "weighted_value"])

    _log(created_by, "CREATE", "Quote", quote.id, {
        "quote_number": quote_number,
        "opportunity_number": opportunity.opportunity_number,
        "total_amount": str(quote.total_amount),
    })

    return quote


# ═══════════════════════════════════════════════════════════════════
# CONVERT QUOTE TO SALES ORDER
# ═══════════════════════════════════════════════════════════════════

@transaction.atomic
def convert_quote_to_sales_order(
    *,
    quote,
    so_date: date | None = None,
    converted_by=None,
):
    """
    Accept a Quote and create a sales.SalesOrder from it.
    Marks quote as CONVERTED; advances opportunity stage to Won if a Won stage exists.
    """
    from apps.crm.models import Quote, Opportunity

    if quote.status == Quote.QuoteStatus.CONVERTED:
        raise ValueError(f"Quote {quote.quote_number} is already converted.")

    if quote.status not in (Quote.QuoteStatus.DRAFT, Quote.QuoteStatus.SENT):
        raise ValueError(
            f"Cannot convert quote in status '{quote.status}'. Expected DRAFT or SENT."
        )

    # Attempt to create a sales.SalesOrder
    sales_order = None
    try:
        from apps.sales.models import SalesOrder
        from apps.sales.services import create_sales_order

        # Build SO lines from quote lines
        so_lines = []
        for ql in quote.lines.all().order_by("line_number"):
            so_lines.append({
                "item_id": str(ql.item_id) if ql.item_id else None,
                "item_description": ql.item_description,
                "quantity": ql.quantity,
                "unit_price": ql.unit_price,
                "discount_pct": ql.discount_pct,
                "gst_rate": ql.gst_rate,
                "uom": ql.uom,
                "notes": ql.notes,
            })

        sales_order = create_sales_order(
            plant=quote.plant,
            customer=quote.customer,
            order_date=so_date or date.today(),
            lines=so_lines,
            payment_terms=quote.payment_terms,
            delivery_terms=quote.delivery_terms,
            notes=quote.notes,
            created_by=converted_by,
        )
    except Exception:
        # Graceful degradation: sales.SalesOrder creation failed (missing data etc.)
        # We still mark the quote converted — caller can link manually
        pass

    quote.status = Quote.QuoteStatus.CONVERTED
    quote.converted_at = timezone.now()
    if sales_order:
        quote.sales_order = sales_order
    quote.save(update_fields=["status", "converted_at", "sales_order"])

    # Try to advance opportunity to Won stage
    try:
        from apps.crm.models import OpportunityStage
        won_stage = OpportunityStage.objects.filter(
            plant=quote.plant, is_won=True
        ).first()
        if won_stage and quote.opportunity.status == Opportunity.OpportunityStatus.OPEN:
            advance_opportunity_stage(
                opportunity=quote.opportunity,
                new_stage=won_stage,
                actual_close_date=date.today(),
                updated_by=converted_by,
            )
    except Exception:
        pass

    _log(converted_by, "CONVERT", "Quote", quote.id, {
        "quote_number": quote.quote_number,
        "sales_order_number": getattr(sales_order, "order_number", None),
    })

    return quote, sales_order


# ═══════════════════════════════════════════════════════════════════
# LOG CUSTOMER VISIT
# ═══════════════════════════════════════════════════════════════════

@transaction.atomic
def log_customer_visit(
    *,
    plant,
    salesperson,
    visit_date: date,
    visit_type: str = "SALES",
    purpose: str,
    customer=None,
    contact=None,
    prospect_name: str = "",
    discussion_notes: str = "",
    outcome: str = "",
    next_action: str = "",
    next_visit_date: date | None = None,
    opportunity=None,
    lead=None,
    latitude: Decimal | None = None,
    longitude: Decimal | None = None,
    location_address: str = "",
    created_by=None,
):
    """
    Record a CustomerVisit by a salesperson.
    Notifies the salesperson's manager (if Employee has a reporting_to).
    """
    from apps.crm.models import CustomerVisit

    visit_number = get_next_doc_number(plant, "VISIT", "VST")

    visit = CustomerVisit.objects.create(
        plant=plant,
        visit_number=visit_number,
        visit_date=visit_date,
        salesperson=salesperson,
        customer=customer,
        contact=contact,
        prospect_name=prospect_name,
        visit_type=visit_type,
        purpose=purpose,
        discussion_notes=discussion_notes,
        outcome=outcome,
        next_action=next_action,
        next_visit_date=next_visit_date,
        opportunity=opportunity,
        lead=lead,
        latitude=latitude,
        longitude=longitude,
        location_address=location_address,
        created_by=created_by,
    )

    _log(created_by, "CREATE", "CustomerVisit", visit.id, {
        "visit_number": visit_number,
        "salesperson": str(salesperson),
        "visit_date": str(visit_date),
        "customer": str(customer) if customer else prospect_name,
    })

    # Notify manager if Employee has reporting_to
    try:
        manager = salesperson.reporting_to  # hr.Employee field
        if manager and hasattr(manager, "user") and manager.user:
            _notify(
                manager.user,
                f"Visit Logged: {visit_number}",
                f"{salesperson} visited "
                f"{'customer ' + str(customer) if customer else prospect_name} "
                f"on {visit_date}. Outcome: {outcome or 'not set'}.",
                "CustomerVisit", visit.id,
            )
    except Exception:
        pass

    return visit


# ═══════════════════════════════════════════════════════════════════
# GET SALES PIPELINE REPORT
# ═══════════════════════════════════════════════════════════════════

def get_sales_pipeline_report(plant, filters: dict | None = None) -> dict:
    """
    Return a weighted pipeline report.

    filters: {
      owner_id, stage_id, status, date_from, date_to
    }

    Returns:
    {
      total_expected_value, total_weighted_value, opportunity_count,
      by_stage: [{stage, count, expected_value, weighted_value, probability}],
      by_owner: [{owner, count, expected_value, weighted_value}],
      won_count, lost_count, won_value, lost_value,
      opportunities: [list]
    }
    """
    from apps.crm.models import Opportunity
    from django.db.models import Count, Sum
    from django.contrib.auth import get_user_model

    qs = Opportunity.objects.filter(plant=plant).select_related("stage", "owner", "customer")

    if filters:
        if filters.get("owner_id"):
            qs = qs.filter(owner_id=filters["owner_id"])
        if filters.get("stage_id"):
            qs = qs.filter(stage_id=filters["stage_id"])
        if filters.get("status"):
            qs = qs.filter(status=filters["status"])
        if filters.get("date_from"):
            qs = qs.filter(expected_close_date__gte=filters["date_from"])
        if filters.get("date_to"):
            qs = qs.filter(expected_close_date__lte=filters["date_to"])

    totals = qs.aggregate(
        total_expected=Sum("expected_value"),
        total_weighted=Sum("weighted_value"),
        total_count=Count("id"),
    )

    by_stage = list(
        qs.values("stage__name", "stage__probability", "stage__order")
        .annotate(
            count=Count("id"),
            expected_value=Sum("expected_value"),
            weighted_value=Sum("weighted_value"),
        )
        .order_by("stage__order")
    )

    by_owner = list(
        qs.values("owner__first_name", "owner__last_name", "owner__id")
        .annotate(
            count=Count("id"),
            expected_value=Sum("expected_value"),
            weighted_value=Sum("weighted_value"),
        )
        .order_by("-expected_value")
    )

    won_agg = qs.filter(status="WON").aggregate(
        won_count=Count("id"), won_value=Sum("expected_value")
    )
    lost_agg = qs.filter(status="LOST").aggregate(
        lost_count=Count("id"), lost_value=Sum("expected_value")
    )

    return {
        "total_expected_value": str(_two(totals["total_expected"] or 0)),
        "total_weighted_value": str(_two(totals["total_weighted"] or 0)),
        "opportunity_count": totals["total_count"] or 0,
        "by_stage": [
            {
                "stage": s["stage__name"],
                "probability": str(s["stage__probability"]),
                "count": s["count"],
                "expected_value": str(_two(s["expected_value"] or 0)),
                "weighted_value": str(_two(s["weighted_value"] or 0)),
            }
            for s in by_stage
        ],
        "by_owner": [
            {
                "owner": f"{o['owner__first_name']} {o['owner__last_name']}".strip() if o.get("owner__first_name") else "Unassigned",
                "count": o["count"],
                "expected_value": str(_two(o["expected_value"] or 0)),
                "weighted_value": str(_two(o["weighted_value"] or 0)),
            }
            for o in by_owner
        ],
        "won_count": won_agg["won_count"] or 0,
        "lost_count": lost_agg["lost_count"] or 0,
        "won_value": str(_two(won_agg["won_value"] or 0)),
        "lost_value": str(_two(lost_agg["lost_value"] or 0)),
    }


# ═══════════════════════════════════════════════════════════════════
# SCHEDULE / SEND CAMPAIGN EMAIL
# ═══════════════════════════════════════════════════════════════════

@transaction.atomic
def schedule_campaign(
    *,
    plant,
    name: str,
    campaign_type: str,
    subject: str,
    body_html: str,
    body_text: str = "",
    scheduled_at=None,
    from_name: str = "",
    from_email: str = "",
    reply_to: str = "",
    recipients: List[Dict[str, Any]],  # [{email, name, contact_id}]
    notes: str = "",
    created_by=None,
):
    """
    Create a CampaignEmail with recipients; schedule async send via Celery.
    recipients: [{"email": "...", "name": "...", "contact_id": optional_uuid}]
    """
    from apps.crm.models import CampaignEmail, CampaignRecipient, CRMContact

    campaign_number = get_next_doc_number(plant, "CAMPAIGN", "CMP")

    campaign = CampaignEmail.objects.create(
        plant=plant,
        campaign_number=campaign_number,
        name=name,
        campaign_type=campaign_type,
        status=CampaignEmail.CampaignStatus.DRAFT,
        subject=subject,
        body_html=body_html,
        body_text=body_text,
        scheduled_at=scheduled_at,
        from_name=from_name,
        from_email=from_email,
        reply_to=reply_to,
        notes=notes,
        created_by=created_by,
    )

    recipient_count = 0
    seen_emails = set()
    for r in recipients:
        email = r.get("email", "").strip().lower()
        if not email or email in seen_emails:
            continue
        seen_emails.add(email)

        contact = None
        if r.get("contact_id"):
            try:
                contact = CRMContact.objects.get(pk=r["contact_id"])
            except CRMContact.DoesNotExist:
                pass

        CampaignRecipient.objects.create(
            campaign=campaign,
            contact=contact,
            email=email,
            name=r.get("name", ""),
            delivery_status=CampaignRecipient.DeliveryStatus.PENDING,
        )
        recipient_count += 1

    campaign.total_recipients = recipient_count
    if scheduled_at:
        campaign.status = CampaignEmail.CampaignStatus.SCHEDULED
    campaign.save(update_fields=["total_recipients", "status"])

    _log(created_by, "CREATE", "CampaignEmail", campaign.id, {
        "campaign_number": campaign_number,
        "name": name,
        "recipients": recipient_count,
    })

    # Trigger async send via Celery
    if scheduled_at is None:
        try:
            from apps.crm.tasks import send_campaign_emails_task
            send_campaign_emails_task.delay(str(campaign.id))
        except Exception:
            pass

    return campaign
