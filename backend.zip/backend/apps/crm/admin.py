"""CRM Module Django Admin."""
from django.contrib import admin
from apps.crm.models import (
    OpportunityStage, CRMContact, Lead, LeadActivity,
    Opportunity, Quote, QuoteLineItem, CustomerVisit,
    CampaignEmail, CampaignRecipient,
)


@admin.register(OpportunityStage)
class OpportunityStageAdmin(admin.ModelAdmin):
    list_display = ["name", "plant", "order", "probability", "is_won", "is_lost", "is_active"]
    list_filter = ["plant", "is_won", "is_lost", "is_active"]
    ordering = ["plant", "order"]


@admin.register(CRMContact)
class CRMContactAdmin(admin.ModelAdmin):
    list_display = ["full_name", "company_name", "email", "phone", "customer", "is_primary", "is_active"]
    list_filter = ["plant", "is_primary", "is_active"]
    search_fields = ["first_name", "last_name", "email", "company_name", "phone"]
    raw_id_fields = ["customer", "salesperson"]


class LeadActivityInline(admin.TabularInline):
    model = LeadActivity
    extra = 0
    fields = ["activity_type", "activity_date", "summary", "outcome", "next_action_date", "performed_by"]
    readonly_fields = ["activity_date"]


@admin.register(Lead)
class LeadAdmin(admin.ModelAdmin):
    list_display = [
        "lead_number", "title", "source", "status", "rating",
        "prospect_name", "customer", "assigned_to", "next_followup_date",
    ]
    list_filter = ["plant", "source", "status", "rating"]
    search_fields = ["lead_number", "title", "prospect_name", "prospect_company", "prospect_email"]
    raw_id_fields = ["customer", "contact", "assigned_to", "opportunity", "campaign"]
    readonly_fields = ["lead_number", "converted_at"]
    inlines = [LeadActivityInline]


@admin.register(LeadActivity)
class LeadActivityAdmin(admin.ModelAdmin):
    list_display = ["lead", "activity_type", "activity_date", "outcome", "performed_by"]
    list_filter = ["activity_type", "outcome"]
    search_fields = ["lead__lead_number", "summary"]
    raw_id_fields = ["lead", "performed_by"]


class QuoteInline(admin.TabularInline):
    model = Quote
    extra = 0
    fields = ["quote_number", "quote_date", "status", "total_amount"]
    readonly_fields = ["quote_number", "total_amount"]


@admin.register(Opportunity)
class OpportunityAdmin(admin.ModelAdmin):
    list_display = [
        "opportunity_number", "name", "stage", "status",
        "expected_value", "probability", "weighted_value",
        "customer", "owner", "expected_close_date",
    ]
    list_filter = ["plant", "stage", "status"]
    search_fields = ["opportunity_number", "name", "customer__name"]
    raw_id_fields = ["customer", "contact", "owner"]
    readonly_fields = ["opportunity_number", "weighted_value"]
    inlines = [QuoteInline]


class QuoteLineItemInline(admin.TabularInline):
    model = QuoteLineItem
    extra = 1
    fields = [
        "line_number", "item", "item_description", "uom",
        "quantity", "unit_price", "discount_pct", "gst_rate", "line_total",
    ]
    readonly_fields = ["line_total"]


@admin.register(Quote)
class QuoteAdmin(admin.ModelAdmin):
    list_display = [
        "quote_number", "quote_date", "status",
        "opportunity", "customer", "total_amount",
        "valid_until", "prepared_by",
    ]
    list_filter = ["plant", "status"]
    search_fields = ["quote_number", "customer__name", "opportunity__opportunity_number"]
    raw_id_fields = ["opportunity", "customer", "contact", "prepared_by", "sales_order"]
    readonly_fields = ["quote_number", "subtotal", "discount_amount", "tax_amount", "total_amount", "converted_at"]
    inlines = [QuoteLineItemInline]


@admin.register(CustomerVisit)
class CustomerVisitAdmin(admin.ModelAdmin):
    list_display = [
        "visit_number", "visit_date", "salesperson", "customer",
        "visit_type", "outcome", "approved",
    ]
    list_filter = ["plant", "visit_type", "outcome", "approved"]
    search_fields = ["visit_number", "salesperson__employee_code", "customer__name", "prospect_name"]
    raw_id_fields = ["salesperson", "customer", "contact", "opportunity", "lead", "approved_by"]
    readonly_fields = ["visit_number", "approved_at"]


class CampaignRecipientInline(admin.TabularInline):
    model = CampaignRecipient
    extra = 0
    fields = ["email", "name", "delivery_status", "sent_at", "opened_at"]
    readonly_fields = ["sent_at", "opened_at"]
    show_change_link = False
    max_num = 100


@admin.register(CampaignEmail)
class CampaignEmailAdmin(admin.ModelAdmin):
    list_display = [
        "campaign_number", "name", "campaign_type", "status",
        "total_recipients", "sent_count", "opened_count",
        "scheduled_at", "sent_at",
    ]
    list_filter = ["plant", "campaign_type", "status"]
    search_fields = ["campaign_number", "name", "subject"]
    readonly_fields = [
        "campaign_number", "sent_at",
        "total_recipients", "sent_count", "delivered_count",
        "opened_count", "clicked_count", "bounced_count", "unsubscribed_count",
    ]
    inlines = [CampaignRecipientInline]
