"""CRM API Serializers — 3 variants per major model."""
from rest_framework import serializers
from apps.crm.models import (
    OpportunityStage, CRMContact, Lead, LeadActivity,
    Opportunity, Quote, QuoteLineItem, CustomerVisit,
    CampaignEmail, CampaignRecipient,
)


# ─── OpportunityStage ─────────────────────────────────────────────

class OpportunityStageListSerializer(serializers.ModelSerializer):
    plant_code = serializers.CharField(source="plant.code", read_only=True)

    class Meta:
        model = OpportunityStage
        fields = ["id", "uuid", "name", "order", "probability", "is_won", "is_lost", "is_active", "plant", "plant_code"]


class OpportunityStageDetailSerializer(serializers.ModelSerializer):
    plant_code = serializers.CharField(source="plant.code", read_only=True)

    class Meta:
        model = OpportunityStage
        fields = "__all__"


class OpportunityStageCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = OpportunityStage
        fields = ["plant", "name", "order", "probability", "is_won", "is_lost", "is_active", "description"]


# ─── CRMContact ───────────────────────────────────────────────────

class CRMContactListSerializer(serializers.ModelSerializer):
    full_name = serializers.CharField(read_only=True)
    customer_name = serializers.CharField(source="customer.name", read_only=True)

    class Meta:
        model = CRMContact
        fields = [
            "id", "uuid", "full_name", "salutation", "first_name", "last_name",
            "designation", "company_name", "email", "mobile", "phone",
            "customer", "customer_name", "is_primary", "is_active",
        ]


class CRMContactDetailSerializer(serializers.ModelSerializer):
    full_name = serializers.CharField(read_only=True)
    customer_name = serializers.CharField(source="customer.name", read_only=True)

    class Meta:
        model = CRMContact
        fields = "__all__"


class CRMContactCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = CRMContact
        fields = [
            "plant", "customer", "salesperson", "salutation",
            "first_name", "last_name", "designation", "company_name",
            "email", "phone", "mobile", "linkedin_url", "birthday",
            "is_primary", "notes",
        ]


# ─── Lead ─────────────────────────────────────────────────────────

class LeadListSerializer(serializers.ModelSerializer):
    assigned_to_name = serializers.SerializerMethodField()

    class Meta:
        model = Lead
        fields = [
            "id", "uuid", "lead_number", "lead_date", "title",
            "source", "status", "rating",
            "prospect_name", "prospect_company",
            "customer", "assigned_to", "assigned_to_name",
            "estimated_value", "next_followup_date",
        ]

    def get_assigned_to_name(self, obj):
        return obj.assigned_to.get_full_name() if obj.assigned_to else None


class LeadDetailSerializer(serializers.ModelSerializer):
    assigned_to_name = serializers.SerializerMethodField()
    contact_name = serializers.SerializerMethodField()
    customer_name = serializers.CharField(source="customer.name", read_only=True)
    opportunity_number = serializers.CharField(source="opportunity.opportunity_number", read_only=True)

    class Meta:
        model = Lead
        fields = "__all__"

    def get_assigned_to_name(self, obj):
        return obj.assigned_to.get_full_name() if obj.assigned_to else None

    def get_contact_name(self, obj):
        return obj.contact.full_name if obj.contact else None


class LeadCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Lead
        fields = [
            "plant", "lead_date", "title", "source", "rating",
            "customer", "contact",
            "prospect_name", "prospect_company", "prospect_email", "prospect_phone",
            "product_interest", "estimated_value", "description",
            "assigned_to", "next_followup_date", "notes", "campaign",
        ]


# ─── LeadActivity ─────────────────────────────────────────────────

class LeadActivitySerializer(serializers.ModelSerializer):
    performed_by_name = serializers.SerializerMethodField()

    class Meta:
        model = LeadActivity
        fields = "__all__"

    def get_performed_by_name(self, obj):
        return obj.performed_by.get_full_name() if obj.performed_by else None


class LeadActivityCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = LeadActivity
        fields = [
            "lead", "activity_type", "activity_date", "summary",
            "details", "outcome", "next_action", "next_action_date", "performed_by",
        ]


# ─── Opportunity ──────────────────────────────────────────────────

class OpportunityListSerializer(serializers.ModelSerializer):
    stage_name = serializers.CharField(source="stage.name", read_only=True)
    owner_name = serializers.SerializerMethodField()
    customer_name = serializers.CharField(source="customer.name", read_only=True)

    class Meta:
        model = Opportunity
        fields = [
            "id", "uuid", "opportunity_number", "name",
            "stage", "stage_name", "status",
            "expected_value", "probability", "weighted_value",
            "customer", "customer_name", "owner", "owner_name",
            "expected_close_date",
        ]

    def get_owner_name(self, obj):
        return obj.owner.get_full_name() if obj.owner else None


class OpportunityDetailSerializer(serializers.ModelSerializer):
    stage_name = serializers.CharField(source="stage.name", read_only=True)
    owner_name = serializers.SerializerMethodField()
    customer_name = serializers.CharField(source="customer.name", read_only=True)

    class Meta:
        model = Opportunity
        fields = "__all__"

    def get_owner_name(self, obj):
        return obj.owner.get_full_name() if obj.owner else None


class OpportunityCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Opportunity
        fields = [
            "plant", "name", "stage", "customer", "contact",
            "expected_value", "probability",
            "expected_close_date", "owner", "description", "notes",
        ]

    def validate(self, data):
        # Validate stage transitions — prevent backward jumps (BUG-031)
        instance = self.instance  # None on create, set on update
        new_stage = data.get('stage')
        if instance and new_stage and new_stage != instance.stage:
            current_stage = instance.stage
            # Allow any transition to/from terminal Won/Lost stages
            if not current_stage.is_won and not current_stage.is_lost:
                if not new_stage.is_won and not new_stage.is_lost:
                    if new_stage.order < current_stage.order:
                        raise serializers.ValidationError({
                            'stage': (
                                f'Cannot move opportunity backward from '
                                f'"{current_stage.name}" (order {current_stage.order}) '
                                f'to "{new_stage.name}" (order {new_stage.order}). '
                                f'Stage transitions must move forward in the pipeline.'
                            )
                        })
        return data


# ─── QuoteLineItem ────────────────────────────────────────────────

class QuoteLineItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = QuoteLineItem
        fields = "__all__"
        read_only_fields = ["line_total", "taxable_amount", "discount_amount", "gst_amount"]


class QuoteLineItemCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = QuoteLineItem
        fields = [
            "item", "item_description", "uom",
            "quantity", "unit_price", "discount_pct", "gst_rate", "notes",
        ]


# ─── Quote ────────────────────────────────────────────────────────

class QuoteListSerializer(serializers.ModelSerializer):
    opportunity_number = serializers.CharField(source="opportunity.opportunity_number", read_only=True)
    customer_name = serializers.CharField(source="customer.name", read_only=True)

    class Meta:
        model = Quote
        fields = [
            "id", "uuid", "quote_number", "quote_date", "status",
            "opportunity", "opportunity_number",
            "customer", "customer_name",
            "total_amount", "valid_until",
        ]


class QuoteDetailSerializer(serializers.ModelSerializer):
    opportunity_number = serializers.CharField(source="opportunity.opportunity_number", read_only=True)
    customer_name = serializers.CharField(source="customer.name", read_only=True)
    lines = QuoteLineItemSerializer(many=True, read_only=True)
    sales_order_number = serializers.CharField(source="sales_order.order_number", read_only=True)

    class Meta:
        model = Quote
        fields = "__all__"


class QuoteCreateSerializer(serializers.ModelSerializer):
    lines = QuoteLineItemCreateSerializer(many=True, write_only=True)

    class Meta:
        model = Quote
        fields = [
            "opportunity", "quote_date", "valid_until",
            "payment_terms", "delivery_terms", "notes", "internal_notes",
            "lines",
        ]


# ─── CustomerVisit ────────────────────────────────────────────────

class CustomerVisitListSerializer(serializers.ModelSerializer):
    salesperson_name = serializers.SerializerMethodField()
    customer_name = serializers.CharField(source="customer.name", read_only=True)

    class Meta:
        model = CustomerVisit
        fields = [
            "id", "uuid", "visit_number", "visit_date",
            "salesperson", "salesperson_name",
            "customer", "customer_name", "prospect_name",
            "visit_type", "outcome", "approved",
        ]

    def get_salesperson_name(self, obj):
        return str(obj.salesperson) if obj.salesperson else None


class CustomerVisitDetailSerializer(serializers.ModelSerializer):
    salesperson_name = serializers.SerializerMethodField()
    customer_name = serializers.CharField(source="customer.name", read_only=True)

    class Meta:
        model = CustomerVisit
        fields = "__all__"

    def get_salesperson_name(self, obj):
        return str(obj.salesperson) if obj.salesperson else None


class CustomerVisitCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomerVisit
        fields = [
            "plant", "visit_date", "visit_time",
            "salesperson", "customer", "contact", "prospect_name",
            "visit_type", "purpose", "discussion_notes",
            "outcome", "next_action", "next_visit_date",
            "opportunity", "lead",
            "latitude", "longitude", "location_address",
        ]


# ─── CampaignEmail ────────────────────────────────────────────────

class CampaignRecipientSerializer(serializers.ModelSerializer):
    class Meta:
        model = CampaignRecipient
        fields = ["id", "email", "name", "delivery_status", "sent_at", "opened_at", "clicked_at"]


class CampaignEmailListSerializer(serializers.ModelSerializer):
    class Meta:
        model = CampaignEmail
        fields = [
            "id", "uuid", "campaign_number", "name", "campaign_type", "status",
            "subject", "total_recipients", "sent_count", "opened_count",
            "scheduled_at", "sent_at",
        ]


class CampaignEmailDetailSerializer(serializers.ModelSerializer):
    recipients = CampaignRecipientSerializer(many=True, read_only=True)

    class Meta:
        model = CampaignEmail
        fields = "__all__"


class CampaignEmailCreateSerializer(serializers.ModelSerializer):
    recipients = serializers.ListField(
        child=serializers.DictField(), write_only=True,
        help_text="[{email, name, contact_id?}]"
    )

    class Meta:
        model = CampaignEmail
        fields = [
            "plant", "name", "campaign_type", "subject",
            "body_html", "body_text",
            "scheduled_at", "from_name", "from_email", "reply_to",
            "notes", "recipients",
        ]
