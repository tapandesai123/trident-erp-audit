"""CRM Module API Viewsets."""
from decimal import Decimal
from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated

from apps.crm.models import (
    OpportunityStage, CRMContact, Lead, LeadActivity,
    Opportunity, Quote, QuoteLineItem, CustomerVisit,
    CampaignEmail, CampaignRecipient,
)
from apps.crm.api.serializers import (
    OpportunityStageListSerializer, OpportunityStageDetailSerializer, OpportunityStageCreateSerializer,
    CRMContactListSerializer, CRMContactDetailSerializer, CRMContactCreateSerializer,
    LeadListSerializer, LeadDetailSerializer, LeadCreateSerializer,
    LeadActivitySerializer, LeadActivityCreateSerializer,
    OpportunityListSerializer, OpportunityDetailSerializer, OpportunityCreateSerializer,
    QuoteListSerializer, QuoteDetailSerializer, QuoteCreateSerializer,
    CustomerVisitListSerializer, CustomerVisitDetailSerializer, CustomerVisitCreateSerializer,
    CampaignEmailListSerializer, CampaignEmailDetailSerializer, CampaignEmailCreateSerializer,
)
from apps.crm import services


# ─── OpportunityStage ─────────────────────────────────────────────

class OpportunityStageViewSet(viewsets.ModelViewSet):
    queryset = OpportunityStage.objects.select_related("plant")
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return OpportunityStageListSerializer
        if self.action in ("create", "update", "partial_update"):
            return OpportunityStageCreateSerializer
        return OpportunityStageDetailSerializer

    def get_queryset(self):
        qs = super().get_queryset()
        plant = self.request.query_params.get("plant")
        if plant:
            qs = qs.filter(plant=plant)
        return qs.filter(is_active=True)


# ─── CRMContact ───────────────────────────────────────────────────

class CRMContactViewSet(viewsets.ModelViewSet):
    queryset = CRMContact.objects.select_related("plant", "customer", "salesperson")
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return CRMContactListSerializer
        if self.action in ("create", "update", "partial_update"):
            return CRMContactCreateSerializer
        return CRMContactDetailSerializer

    def get_queryset(self):
        qs = super().get_queryset()
        plant = self.request.query_params.get("plant")
        customer = self.request.query_params.get("customer")
        search = self.request.query_params.get("search")
        if plant:
            qs = qs.filter(plant=plant)
        if customer:
            qs = qs.filter(customer=customer)
        if search:
            qs = qs.filter(
                first_name__icontains=search
            ) | qs.filter(last_name__icontains=search) | qs.filter(email__icontains=search)
        return qs

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)


# ─── Lead ─────────────────────────────────────────────────────────

class LeadViewSet(viewsets.ModelViewSet):
    queryset = Lead.objects.select_related(
        "plant", "customer", "contact", "assigned_to", "opportunity", "campaign"
    )
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return LeadListSerializer
        if self.action in ("create", "update", "partial_update"):
            return LeadCreateSerializer
        return LeadDetailSerializer

    def get_queryset(self):
        qs = super().get_queryset()
        plant = self.request.query_params.get("plant")
        lead_status = self.request.query_params.get("status")
        source = self.request.query_params.get("source")
        assigned_to = self.request.query_params.get("assigned_to")
        search = self.request.query_params.get("search")
        if plant:
            qs = qs.filter(plant=plant)
        if lead_status:
            qs = qs.filter(status=lead_status)
        if source:
            qs = qs.filter(source=source)
        if assigned_to:
            qs = qs.filter(assigned_to=assigned_to)
        if search:
            qs = qs.filter(title__icontains=search) | qs.filter(prospect_name__icontains=search)
        return qs

    def create(self, request, *args, **kwargs):
        from apps.core.models import Plant
        try:
            plant = Plant.objects.get(pk=request.data["plant"])
            customer = None
            if request.data.get("customer"):
                from apps.masters.models import Customer
                customer = Customer.objects.get(pk=request.data["customer"])
            contact = None
            if request.data.get("contact"):
                contact = CRMContact.objects.get(pk=request.data["contact"])

            lead = services.create_lead(
                plant=plant,
                title=request.data["title"],
                source=request.data["source"],
                lead_date=request.data.get("lead_date"),
                customer=customer,
                contact=contact,
                prospect_name=request.data.get("prospect_name", ""),
                prospect_company=request.data.get("prospect_company", ""),
                prospect_email=request.data.get("prospect_email", ""),
                prospect_phone=request.data.get("prospect_phone", ""),
                product_interest=request.data.get("product_interest", ""),
                estimated_value=Decimal(str(request.data["estimated_value"])) if request.data.get("estimated_value") else None,
                assigned_to=request.user if not request.data.get("assigned_to") else None,
                next_followup_date=request.data.get("next_followup_date"),
                description=request.data.get("description", ""),
                notes=request.data.get("notes", ""),
                rating=request.data.get("rating", "COLD"),
                created_by=request.user,
            )
            return Response(LeadDetailSerializer(lead).data, status=status.HTTP_201_CREATED)
        except Exception as e:
            return Response({"detail": str(e)}, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=True, methods=["post"], url_path="convert")
    def convert(self, request, pk=None):
        """Convert a Lead to an Opportunity."""
        lead = self.get_object()
        try:
            stage = OpportunityStage.objects.get(pk=request.data["stage"])
            opportunity = services.convert_lead_to_opportunity(
                lead=lead,
                stage=stage,
                name=request.data.get("name"),
                expected_value=Decimal(str(request.data["expected_value"])) if request.data.get("expected_value") else None,
                expected_close_date=request.data.get("expected_close_date"),
                owner=request.user,
                converted_by=request.user,
            )
            return Response(OpportunityDetailSerializer(opportunity).data)
        except Exception as e:
            return Response({"detail": str(e)}, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=True, methods=["post"], url_path="log-activity")
    def log_activity(self, request, pk=None):
        """Log an activity on a Lead."""
        lead = self.get_object()
        from apps.crm.models import LeadActivity
        try:
            activity = LeadActivity.objects.create(
                lead=lead,
                activity_type=request.data["activity_type"],
                summary=request.data["summary"],
                details=request.data.get("details", ""),
                outcome=request.data.get("outcome", ""),
                next_action=request.data.get("next_action", ""),
                next_action_date=request.data.get("next_action_date"),
                performed_by=request.user,
            )
            # Update lead status if progressing
            if request.data.get("new_status"):
                lead.status = request.data["new_status"]
                lead.save(update_fields=["status"])
            if request.data.get("next_followup_date"):
                lead.next_followup_date = request.data["next_followup_date"]
                lead.save(update_fields=["next_followup_date"])

            return Response(LeadActivitySerializer(activity).data, status=status.HTTP_201_CREATED)
        except Exception as e:
            return Response({"detail": str(e)}, status=status.HTTP_400_BAD_REQUEST)


# ─── LeadActivity ─────────────────────────────────────────────────

class LeadActivityViewSet(viewsets.ModelViewSet):
    queryset = LeadActivity.objects.select_related("lead", "performed_by")
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action in ("create", "update", "partial_update"):
            return LeadActivityCreateSerializer
        return LeadActivitySerializer

    def get_queryset(self):
        qs = super().get_queryset()
        lead = self.request.query_params.get("lead")
        if lead:
            qs = qs.filter(lead=lead)
        return qs


# ─── Opportunity ──────────────────────────────────────────────────

class OpportunityViewSet(viewsets.ModelViewSet):
    queryset = Opportunity.objects.select_related(
        "plant", "stage", "customer", "contact", "owner"
    )
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return OpportunityListSerializer
        if self.action in ("create", "update", "partial_update"):
            return OpportunityCreateSerializer
        return OpportunityDetailSerializer

    def get_queryset(self):
        qs = super().get_queryset()
        plant = self.request.query_params.get("plant")
        opp_status = self.request.query_params.get("status")
        stage = self.request.query_params.get("stage")
        owner = self.request.query_params.get("owner")
        search = self.request.query_params.get("search")
        if plant:
            qs = qs.filter(plant=plant)
        if opp_status:
            qs = qs.filter(status=opp_status)
        if stage:
            qs = qs.filter(stage=stage)
        if owner:
            qs = qs.filter(owner=owner)
        if search:
            qs = qs.filter(name__icontains=search)
        return qs

    def create(self, request, *args, **kwargs):
        from apps.core.models import Plant
        try:
            plant = Plant.objects.get(pk=request.data["plant"])
            stage = OpportunityStage.objects.get(pk=request.data["stage"])
            customer = None
            if request.data.get("customer"):
                from apps.masters.models import Customer
                customer = Customer.objects.get(pk=request.data["customer"])

            opp_number = services.get_next_doc_number(plant, "OPP", "OPP")
            prob = Decimal(str(request.data.get("probability", stage.probability)))
            exp_val = Decimal(str(request.data.get("expected_value", 0)))
            opp = Opportunity.objects.create(
                plant=plant,
                opportunity_number=opp_number,
                name=request.data["name"],
                stage=stage,
                status=Opportunity.OpportunityStatus.OPEN,
                customer=customer,
                expected_value=exp_val,
                probability=prob,
                weighted_value=(exp_val * prob / 100).quantize(Decimal("0.01")),
                expected_close_date=request.data.get("expected_close_date"),
                owner=request.user,
                description=request.data.get("description", ""),
                notes=request.data.get("notes", ""),
                created_by=request.user,
            )
            return Response(OpportunityDetailSerializer(opp).data, status=status.HTTP_201_CREATED)
        except Exception as e:
            return Response({"detail": str(e)}, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=True, methods=["post"], url_path="advance-stage")
    def advance_stage(self, request, pk=None):
        """Move opportunity to a new stage."""
        opportunity = self.get_object()
        try:
            stage = OpportunityStage.objects.get(pk=request.data["stage"])
            opportunity = services.advance_opportunity_stage(
                opportunity=opportunity,
                new_stage=stage,
                probability=Decimal(str(request.data["probability"])) if request.data.get("probability") else None,
                lost_reason=request.data.get("lost_reason", ""),
                lost_to_competitor=request.data.get("lost_to_competitor", ""),
                actual_close_date=request.data.get("actual_close_date"),
                updated_by=request.user,
            )
            return Response(OpportunityDetailSerializer(opportunity).data)
        except Exception as e:
            return Response({"detail": str(e)}, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=False, methods=["get"], url_path="pipeline-report")
    def pipeline_report(self, request):
        """Weighted pipeline summary report."""
        from apps.core.models import Plant
        plant_id = request.query_params.get("plant")
        if not plant_id:
            return Response({"detail": "plant query param required."}, status=status.HTTP_400_BAD_REQUEST)
        try:
            plant = Plant.objects.get(pk=plant_id)
        except Plant.DoesNotExist:
            return Response({"detail": "Plant not found."}, status=status.HTTP_404_NOT_FOUND)

        filters = {
            k: request.query_params.get(k)
            for k in ("owner_id", "stage_id", "status", "date_from", "date_to")
            if request.query_params.get(k)
        }
        report = services.get_sales_pipeline_report(plant=plant, filters=filters)
        return Response(report)


# ─── Quote ────────────────────────────────────────────────────────

class QuoteViewSet(viewsets.ModelViewSet):
    queryset = Quote.objects.select_related(
        "plant", "opportunity", "customer", "contact", "prepared_by", "sales_order"
    ).prefetch_related("lines")
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return QuoteListSerializer
        if self.action in ("create", "update", "partial_update"):
            return QuoteCreateSerializer
        return QuoteDetailSerializer

    def get_queryset(self):
        qs = super().get_queryset()
        plant = self.request.query_params.get("plant")
        quote_status = self.request.query_params.get("status")
        opportunity = self.request.query_params.get("opportunity")
        if plant:
            qs = qs.filter(plant=plant)
        if quote_status:
            qs = qs.filter(status=quote_status)
        if opportunity:
            qs = qs.filter(opportunity=opportunity)
        return qs

    def create(self, request, *args, **kwargs):
        try:
            opportunity = Opportunity.objects.get(pk=request.data["opportunity"])
            lines = request.data.get("lines", [])
            quote = services.generate_quote(
                opportunity=opportunity,
                quote_date=request.data.get("quote_date"),
                valid_until=request.data.get("valid_until"),
                lines=lines,
                payment_terms=request.data.get("payment_terms", ""),
                delivery_terms=request.data.get("delivery_terms", ""),
                notes=request.data.get("notes", ""),
                internal_notes=request.data.get("internal_notes", ""),
                prepared_by=request.user,
                created_by=request.user,
            )
            return Response(QuoteDetailSerializer(quote).data, status=status.HTTP_201_CREATED)
        except Exception as e:
            return Response({"detail": str(e)}, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=True, methods=["post"], url_path="send")
    def send_quote(self, request, pk=None):
        """Mark quote as SENT (to customer)."""
        quote = self.get_object()
        if quote.status != Quote.QuoteStatus.DRAFT:
            return Response(
                {"detail": f"Cannot send quote in status '{quote.status}'."},
                status=status.HTTP_400_BAD_REQUEST,
            )
        quote.status = Quote.QuoteStatus.SENT
        quote.save(update_fields=["status"])
        return Response(QuoteDetailSerializer(quote).data)

    @action(detail=True, methods=["post"], url_path="convert-to-so")
    def convert_to_so(self, request, pk=None):
        """Convert quote to a SalesOrder."""
        quote = self.get_object()
        try:
            quote, sales_order = services.convert_quote_to_sales_order(
                quote=quote,
                so_date=request.data.get("so_date"),
                converted_by=request.user,
            )
            return Response({
                "quote": QuoteDetailSerializer(quote).data,
                "sales_order_number": getattr(sales_order, "order_number", None),
            })
        except Exception as e:
            return Response({"detail": str(e)}, status=status.HTTP_400_BAD_REQUEST)


# ─── CustomerVisit ────────────────────────────────────────────────

class CustomerVisitViewSet(viewsets.ModelViewSet):
    queryset = CustomerVisit.objects.select_related(
        "plant", "salesperson", "customer", "contact", "opportunity", "lead"
    )
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return CustomerVisitListSerializer
        if self.action in ("create", "update", "partial_update"):
            return CustomerVisitCreateSerializer
        return CustomerVisitDetailSerializer

    def get_queryset(self):
        qs = super().get_queryset()
        plant = self.request.query_params.get("plant")
        salesperson = self.request.query_params.get("salesperson")
        customer = self.request.query_params.get("customer")
        visit_type = self.request.query_params.get("visit_type")
        if plant:
            qs = qs.filter(plant=plant)
        if salesperson:
            qs = qs.filter(salesperson=salesperson)
        if customer:
            qs = qs.filter(customer=customer)
        if visit_type:
            qs = qs.filter(visit_type=visit_type)
        return qs

    def create(self, request, *args, **kwargs):
        from apps.core.models import Plant
        from apps.hr.models import Employee
        try:
            plant = Plant.objects.get(pk=request.data["plant"])
            salesperson = Employee.objects.get(pk=request.data["salesperson"])

            customer = None
            if request.data.get("customer"):
                from apps.masters.models import Customer
                customer = Customer.objects.get(pk=request.data["customer"])

            contact = None
            if request.data.get("contact"):
                contact = CRMContact.objects.get(pk=request.data["contact"])

            opportunity = None
            if request.data.get("opportunity"):
                opportunity = Opportunity.objects.get(pk=request.data["opportunity"])

            lead = None
            if request.data.get("lead"):
                lead = Lead.objects.get(pk=request.data["lead"])

            visit = services.log_customer_visit(
                plant=plant,
                salesperson=salesperson,
                visit_date=request.data["visit_date"],
                visit_type=request.data.get("visit_type", "SALES"),
                purpose=request.data["purpose"],
                customer=customer,
                contact=contact,
                prospect_name=request.data.get("prospect_name", ""),
                discussion_notes=request.data.get("discussion_notes", ""),
                outcome=request.data.get("outcome", ""),
                next_action=request.data.get("next_action", ""),
                next_visit_date=request.data.get("next_visit_date"),
                opportunity=opportunity,
                lead=lead,
                latitude=Decimal(str(request.data["latitude"])) if request.data.get("latitude") else None,
                longitude=Decimal(str(request.data["longitude"])) if request.data.get("longitude") else None,
                location_address=request.data.get("location_address", ""),
                created_by=request.user,
            )
            return Response(CustomerVisitDetailSerializer(visit).data, status=status.HTTP_201_CREATED)
        except Exception as e:
            return Response({"detail": str(e)}, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=True, methods=["post"], url_path="approve")
    def approve(self, request, pk=None):
        """Approve a customer visit log."""
        from django.utils import timezone
        visit = self.get_object()
        visit.approved = True
        visit.approved_by = request.user
        visit.approved_at = timezone.now()
        visit.save(update_fields=["approved", "approved_by", "approved_at"])
        return Response(CustomerVisitDetailSerializer(visit).data)


# ─── CampaignEmail ────────────────────────────────────────────────

class CampaignEmailViewSet(viewsets.ModelViewSet):
    queryset = CampaignEmail.objects.select_related("plant", "created_by").prefetch_related("recipients")
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return CampaignEmailListSerializer
        if self.action in ("create", "update", "partial_update"):
            return CampaignEmailCreateSerializer
        return CampaignEmailDetailSerializer

    def get_queryset(self):
        qs = super().get_queryset()
        plant = self.request.query_params.get("plant")
        camp_status = self.request.query_params.get("status")
        if plant:
            qs = qs.filter(plant=plant)
        if camp_status:
            qs = qs.filter(status=camp_status)
        return qs

    def create(self, request, *args, **kwargs):
        from apps.core.models import Plant
        try:
            plant = Plant.objects.get(pk=request.data["plant"])
            recipients = request.data.get("recipients", [])
            campaign = services.schedule_campaign(
                plant=plant,
                name=request.data["name"],
                campaign_type=request.data.get("campaign_type", "PROMOTIONAL"),
                subject=request.data["subject"],
                body_html=request.data["body_html"],
                body_text=request.data.get("body_text", ""),
                scheduled_at=request.data.get("scheduled_at"),
                from_name=request.data.get("from_name", ""),
                from_email=request.data.get("from_email", ""),
                reply_to=request.data.get("reply_to", ""),
                recipients=recipients,
                notes=request.data.get("notes", ""),
                created_by=request.user,
            )
            return Response(CampaignEmailDetailSerializer(campaign).data, status=status.HTTP_201_CREATED)
        except Exception as e:
            return Response({"detail": str(e)}, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=True, methods=["post"], url_path="send-now")
    def send_now(self, request, pk=None):
        """Trigger immediate async send via Celery."""
        campaign = self.get_object()
        if campaign.status not in (
            CampaignEmail.CampaignStatus.DRAFT, CampaignEmail.CampaignStatus.SCHEDULED
        ):
            return Response(
                {"detail": f"Cannot send campaign in status '{campaign.status}'."},
                status=status.HTTP_400_BAD_REQUEST,
            )
        try:
            from apps.crm.tasks import send_campaign_emails_task
            send_campaign_emails_task.delay(str(campaign.id))
            campaign.status = CampaignEmail.CampaignStatus.SCHEDULED
            campaign.save(update_fields=["status"])
            return Response({"detail": f"Campaign {campaign.campaign_number} queued for sending."})
        except Exception as e:
            return Response({"detail": str(e)}, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=True, methods=["get"], url_path="stats")
    def stats(self, request, pk=None):
        """Return delivery statistics for this campaign."""
        campaign = self.get_object()
        return Response({
            "campaign_number": campaign.campaign_number,
            "status": campaign.status,
            "total_recipients": campaign.total_recipients,
            "sent_count": campaign.sent_count,
            "delivered_count": campaign.delivered_count,
            "opened_count": campaign.opened_count,
            "clicked_count": campaign.clicked_count,
            "bounced_count": campaign.bounced_count,
            "unsubscribed_count": campaign.unsubscribed_count,
            "open_rate": round(
                campaign.opened_count / campaign.sent_count * 100, 2
            ) if campaign.sent_count else 0,
            "click_rate": round(
                campaign.clicked_count / campaign.sent_count * 100, 2
            ) if campaign.sent_count else 0,
        })
