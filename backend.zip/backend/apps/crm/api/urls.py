"""CRM API URL Configuration."""
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from apps.crm.api.viewsets import (
    OpportunityStageViewSet, CRMContactViewSet,
    LeadViewSet, LeadActivityViewSet,
    OpportunityViewSet, QuoteViewSet,
    CustomerVisitViewSet, CampaignEmailViewSet,
)

router = DefaultRouter()
router.register(r"stages", OpportunityStageViewSet, basename="crm-stage")
router.register(r"contacts", CRMContactViewSet, basename="crm-contact")
router.register(r"leads", LeadViewSet, basename="crm-lead")
router.register(r"lead-activities", LeadActivityViewSet, basename="crm-lead-activity")
router.register(r"opportunities", OpportunityViewSet, basename="crm-opportunity")
router.register(r"quotes", QuoteViewSet, basename="crm-quote")
router.register(r"visits", CustomerVisitViewSet, basename="crm-visit")
router.register(r"campaigns", CampaignEmailViewSet, basename="crm-campaign")

urlpatterns = [
    path("", include(router.urls)),
]
