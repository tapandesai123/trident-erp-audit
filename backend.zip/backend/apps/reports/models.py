"""
Reports & Analytics Module Models — Section 10
Models: ReportDefinition, ReportFilter, ScheduledReport, ReportExecution
"""
from django.db import models
from django.conf import settings
from apps.core.models import UUIDModel, TimeStampedModel, Plant


class ReportDefinition(UUIDModel, TimeStampedModel):
    """
    Catalogue of all available reports.
    Built-in reports reference a service function by slug.
    """
    CATEGORY_CHOICES = [
        ("INVENTORY", "Inventory"),
        ("PURCHASE", "Purchase"),
        ("SALES", "Sales"),
        ("PRODUCTION", "Production"),
        ("QUALITY", "Quality"),
        ("ACCOUNTS", "Accounts"),
        ("GST", "GST / Compliance"),
        ("CUSTOM", "Custom"),
    ]
    OUTPUT_FORMAT = [
        ("JSON", "JSON (API)"),
        ("XLSX", "Excel (.xlsx)"),
        ("PDF", "PDF"),
        ("CSV", "CSV"),
    ]

    slug = models.SlugField(max_length=100, unique=True,
                            help_text="Unique key matching a service function name")
    name = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    category = models.CharField(max_length=30, choices=CATEGORY_CHOICES)
    supported_formats = models.JSONField(default=list,
                                         help_text='e.g. ["JSON", "XLSX", "PDF"]')
    default_format = models.CharField(max_length=10, choices=OUTPUT_FORMAT, default="JSON")
    parameter_schema = models.JSONField(
        default=dict,
        help_text="JSON Schema describing accepted filter parameters"
    )
    is_active = models.BooleanField(default=True)
    is_system = models.BooleanField(default=True,
                                    help_text="System reports cannot be deleted")
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
                                   null=True, blank=True, related_name="report_definitions_created")

    class Meta:
        ordering = ["category", "name"]

    def __str__(self):
        return f"[{self.category}] {self.name}"


class ReportFilter(UUIDModel, TimeStampedModel):
    """Saved filter preset for a report."""
    report = models.ForeignKey(ReportDefinition, on_delete=models.CASCADE, related_name="filters")
    name = models.CharField(max_length=200)
    filters = models.JSONField(default=dict,
                               help_text="Key-value pairs matching report parameter_schema")
    is_default = models.BooleanField(default=False)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
                                   null=True, related_name="report_filters")

    class Meta:
        unique_together = [["report", "name", "created_by"]]
        ordering = ["-is_default", "name"]

    def __str__(self):
        return f"{self.report.name} / {self.name}"


class ScheduledReport(UUIDModel, TimeStampedModel):
    """
    Defines a recurring report delivery schedule.
    Celery Beat entry is created/updated when this record is saved.
    """
    FREQUENCY = [
        ("DAILY", "Daily"),
        ("WEEKLY", "Weekly"),
        ("MONTHLY", "Monthly"),
        ("QUARTERLY", "Quarterly"),
    ]

    plant = models.ForeignKey(Plant, on_delete=models.PROTECT, related_name="scheduled_reports")
    report = models.ForeignKey(ReportDefinition, on_delete=models.PROTECT,
                               related_name="schedules")
    name = models.CharField(max_length=200)
    frequency = models.CharField(max_length=20, choices=FREQUENCY)
    day_of_week = models.PositiveSmallIntegerField(
        null=True, blank=True, help_text="0=Mon … 6=Sun (for WEEKLY)"
    )
    day_of_month = models.PositiveSmallIntegerField(
        null=True, blank=True, help_text="1-28 (for MONTHLY/QUARTERLY)"
    )
    run_at_hour = models.PositiveSmallIntegerField(default=7)
    run_at_minute = models.PositiveSmallIntegerField(default=0)
    output_format = models.CharField(max_length=10, default="XLSX")
    filters = models.JSONField(default=dict)
    recipients = models.JSONField(default=list,
                                  help_text="List of email addresses to deliver to")
    is_active = models.BooleanField(default=True)
    celery_task_id = models.CharField(max_length=200, blank=True,
                                      help_text="Celery Beat periodic task name")
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
                                   null=True, related_name="scheduled_reports")

    class Meta:
        ordering = ["frequency", "name"]

    def __str__(self):
        return f"{self.name} ({self.frequency}) → {self.report.name}"


class ReportExecution(UUIDModel, TimeStampedModel):
    """
    Log of every report run — scheduled or on-demand.
    Stores the output file path and row count for audit.
    """
    STATUS_CHOICES = [
        ("RUNNING", "Running"),
        ("SUCCESS", "Success"),
        ("FAILED", "Failed"),
    ]

    report = models.ForeignKey(ReportDefinition, on_delete=models.PROTECT,
                               related_name="executions")
    scheduled_report = models.ForeignKey(ScheduledReport, on_delete=models.SET_NULL,
                                         null=True, blank=True, related_name="executions")
    plant = models.ForeignKey(Plant, on_delete=models.PROTECT, related_name="report_executions")
    triggered_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
                                     null=True, related_name="report_executions")
    filters_used = models.JSONField(default=dict)
    output_format = models.CharField(max_length=10, default="JSON")
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="RUNNING")
    row_count = models.IntegerField(default=0)
    file_path = models.CharField(max_length=500, blank=True,
                                 help_text="Server path / S3 key for generated file")
    error_message = models.TextField(blank=True)
    started_at = models.DateTimeField(auto_now_add=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    duration_ms = models.IntegerField(default=0, help_text="Execution duration in ms")

    class Meta:
        ordering = ["-started_at"]
        indexes = [
            models.Index(fields=["report", "status"]),
            models.Index(fields=["plant", "started_at"]),
        ]

    def __str__(self):
        return f"{self.report.slug} @ {self.started_at:%Y-%m-%d %H:%M} [{self.status}]"
