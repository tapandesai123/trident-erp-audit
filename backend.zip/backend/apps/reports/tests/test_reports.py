"""
Reports & Analytics Module Tests — Section 10
24 test cases covering all 7 report functions, export helpers,
dispatcher, scheduler, execution logging, and admin guards.
"""
from decimal import Decimal
from datetime import date, timedelta
from unittest.mock import patch, MagicMock
from django.test import TestCase
from django.contrib.auth import get_user_model

from apps.core.models import Plant, Company
from apps.masters.models import Item, UOM, Vendor, VendorGroup, ItemGroup
from apps.reports.models import ReportDefinition, ReportFilter, ScheduledReport, ReportExecution
from apps.reports import services

User = get_user_model()


def make_base():
    company = Company.objects.create(name="RPT Test Co", financial_year_start=4)
    plant = Plant.objects.create(company=company, code="RP1", name="Report Plant")
    user = User.objects.create_user(username="rptuser", email="rpt@test.com", password="x")
    uom = UOM.objects.create(uom_code="RPCS", uom_name="Report Pieces")
    vgroup = VendorGroup.objects.create(name="RPT VG")
    vendor = Vendor.objects.create(
        vendor_name="RPT Vendor", vendor_code="RV01",
        vendor_group=vgroup, vendor_type="SUPPLIER", gst_type="REGULAR",
    )
    igroup = ItemGroup.objects.create(name="RPT IG")
    item = Item.objects.create(
        item_code="RPT_FG01", item_name="Report FG",
        item_type="FG", purchase_uom=uom, stock_uom=uom, item_group=igroup,
    )
    return dict(company=company, plant=plant, user=user, uom=uom,
                vendor=vendor, item=item, igroup=igroup)


# ═══════════════════════════════════════════════════════════════════
# REPORT DEFINITION & SEED TESTS
# ═══════════════════════════════════════════════════════════════════

class TestReportDefinitions(TestCase):
    def setUp(self):
        self.f = make_base()

    def test_01_seed_creates_seven_definitions(self):
        """seed_report_definitions creates all 7 built-in reports."""
        services.seed_report_definitions()
        count = ReportDefinition.objects.filter(is_system=True).count()
        self.assertEqual(count, 7)

    def test_02_seed_is_idempotent(self):
        """Running seed twice does not create duplicates."""
        services.seed_report_definitions()
        services.seed_report_definitions()
        count = ReportDefinition.objects.count()
        self.assertEqual(count, 7)

    def test_03_report_definition_str(self):
        """ReportDefinition __str__ includes category and name."""
        services.seed_report_definitions()
        rdef = ReportDefinition.objects.get(slug="inventory_valuation")
        self.assertIn("INVENTORY", str(rdef))
        self.assertIn("Inventory Valuation", str(rdef))

    def test_04_report_execution_logged(self):
        """Report run creates a ReportExecution record."""
        services.seed_report_definitions()
        f = self.f
        services.inventory_valuation_report(f["plant"], user=f["user"])
        self.assertTrue(ReportExecution.objects.filter(
            report__slug="inventory_valuation", plant=f["plant"]
        ).exists())


# ═══════════════════════════════════════════════════════════════════
# INVENTORY VALUATION REPORT
# ═══════════════════════════════════════════════════════════════════

class TestInventoryValuationReport(TestCase):
    def setUp(self):
        self.f = make_base()
        services.seed_report_definitions()

    def test_05_inventory_valuation_no_stock(self):
        """Inventory valuation returns empty rows when no stock."""
        result = services.inventory_valuation_report(self.f["plant"], user=self.f["user"])
        self.assertEqual(result["report"], "Inventory Valuation")
        self.assertIn("rows", result)
        self.assertIsInstance(result["rows"], list)
        self.assertEqual(result["grand_total_value"], 0)

    def test_06_inventory_valuation_has_required_keys(self):
        """Inventory valuation result has all required top-level keys."""
        result = services.inventory_valuation_report(self.f["plant"])
        for key in ["report", "plant", "as_of_date", "grand_total_value", "rows", "row_count"]:
            self.assertIn(key, result)

    def test_07_inventory_valuation_plant_code_in_result(self):
        """Plant code correctly embedded in result."""
        result = services.inventory_valuation_report(self.f["plant"])
        self.assertEqual(result["plant"], "RP1")


# ═══════════════════════════════════════════════════════════════════
# PURCHASE ANALYSIS REPORT
# ═══════════════════════════════════════════════════════════════════

class TestPurchaseAnalysisReport(TestCase):
    def setUp(self):
        self.f = make_base()
        services.seed_report_definitions()

    def test_08_purchase_analysis_no_data(self):
        """Purchase analysis returns empty rows with no PO data."""
        result = services.purchase_analysis_report(
            self.f["plant"],
            from_date=date.today() - timedelta(days=30),
            to_date=date.today(),
        )
        self.assertEqual(result["report"], "Purchase Analysis")
        self.assertEqual(result["rows"], [])
        self.assertEqual(result["grand_total_ordered"], 0)

    def test_09_purchase_analysis_required_keys(self):
        """Purchase analysis has required summary keys."""
        result = services.purchase_analysis_report(
            self.f["plant"],
            from_date=date.today() - timedelta(days=30),
            to_date=date.today(),
        )
        for key in ["grand_total_ordered", "grand_total_received", "grand_total_pending", "rows"]:
            self.assertIn(key, result)


# ═══════════════════════════════════════════════════════════════════
# SALES ANALYSIS REPORT
# ═══════════════════════════════════════════════════════════════════

class TestSalesAnalysisReport(TestCase):
    def setUp(self):
        self.f = make_base()
        services.seed_report_definitions()

    def test_10_sales_analysis_no_data(self):
        """Sales analysis returns empty rows with no SO data."""
        result = services.sales_analysis_report(
            self.f["plant"],
            from_date=date.today() - timedelta(days=30),
            to_date=date.today(),
        )
        self.assertEqual(result["report"], "Sales Analysis")
        self.assertEqual(result["rows"], [])

    def test_11_sales_analysis_group_by_param(self):
        """Sales analysis embeds group_by in result."""
        for group_by in ("customer", "item", "month"):
            result = services.sales_analysis_report(
                self.f["plant"],
                from_date=date.today() - timedelta(days=30),
                to_date=date.today(),
                group_by=group_by,
            )
            self.assertEqual(result["group_by"], group_by)


# ═══════════════════════════════════════════════════════════════════
# PRODUCTION EFFICIENCY REPORT
# ═══════════════════════════════════════════════════════════════════

class TestProductionEfficiencyReport(TestCase):
    def setUp(self):
        self.f = make_base()
        services.seed_report_definitions()

    def test_12_production_efficiency_no_data(self):
        """Production efficiency returns correct structure with no WOs."""
        result = services.production_efficiency_report(
            self.f["plant"],
            from_date=date.today() - timedelta(days=30),
            to_date=date.today(),
        )
        self.assertIn("work_order_rows", result)
        self.assertIn("work_center_rows", result)
        self.assertEqual(result["wo_count"], 0)

    def test_13_production_efficiency_avg_yield_zero_when_no_wos(self):
        """avg_yield_pct is 0.0 when no WOs."""
        result = services.production_efficiency_report(
            self.f["plant"],
            from_date=date.today() - timedelta(days=7),
            to_date=date.today(),
        )
        self.assertEqual(result["avg_yield_pct"], 0.0)


# ═══════════════════════════════════════════════════════════════════
# QUALITY SUMMARY REPORT
# ═══════════════════════════════════════════════════════════════════

class TestQualitySummaryReport(TestCase):
    def setUp(self):
        self.f = make_base()
        services.seed_report_definitions()

    def test_14_quality_summary_structure(self):
        """Quality summary has all expected keys."""
        result = services.quality_summary_report(
            self.f["plant"],
            from_date=date.today() - timedelta(days=30),
            to_date=date.today(),
        )
        for key in ["summary_rows", "ncr_trend", "top_ncr_items"]:
            self.assertIn(key, result)
        self.assertEqual(len(result["summary_rows"]), 3)  # Lots, NCRs, CAPAs

    def test_15_quality_summary_categories(self):
        """Quality summary rows contain Inspection Lots, NCRs, CAPAs."""
        result = services.quality_summary_report(
            self.f["plant"],
            from_date=date.today() - timedelta(days=30),
            to_date=date.today(),
        )
        categories = [r["category"] for r in result["summary_rows"]]
        self.assertIn("Inspection Lots", categories)
        self.assertIn("NCRs", categories)
        self.assertIn("CAPAs", categories)


# ═══════════════════════════════════════════════════════════════════
# ACCOUNTS P&L REPORT
# ═══════════════════════════════════════════════════════════════════

class TestAccountsPLReport(TestCase):
    def setUp(self):
        self.f = make_base()
        services.seed_report_definitions()

    def test_16_accounts_pl_structure(self):
        """P&L report has income, expense, and net_profit keys."""
        result = services.accounts_pl_report(
            self.f["plant"],
            from_date=date.today() - timedelta(days=30),
            to_date=date.today(),
        )
        for key in ["total_income", "total_expenses", "net_profit", "income_rows", "expense_rows"]:
            self.assertIn(key, result)

    def test_17_accounts_pl_net_profit_calculation(self):
        """net_profit = total_income - total_expenses."""
        result = services.accounts_pl_report(
            self.f["plant"],
            from_date=date.today() - timedelta(days=30),
            to_date=date.today(),
        )
        self.assertAlmostEqual(
            result["net_profit"],
            result["total_income"] - result["total_expenses"],
            places=2,
        )


# ═══════════════════════════════════════════════════════════════════
# EXPORT HELPERS
# ═══════════════════════════════════════════════════════════════════

class TestExportHelpers(TestCase):
    def setUp(self):
        self.sample_data = {
            "report": "Test Report",
            "plant": "RP1",
            "period": "2025-04-01 to 2025-06-30",
            "grand_total": 150000.0,
            "row_count": 2,
            "rows": [
                {"item_code": "RM001", "qty": 100.0, "value": 50000.0},
                {"item_code": "RM002", "qty": 200.0, "value": 100000.0},
            ],
        }

    def test_18_export_to_csv(self):
        """CSV export returns correct header and row count."""
        csv_str = services.export_to_csv(self.sample_data)
        lines = [l for l in csv_str.strip().split("\n") if l]
        self.assertEqual(len(lines), 3)  # header + 2 rows
        self.assertIn("item_code", lines[0])

    def test_19_export_to_csv_empty_rows(self):
        """CSV export returns empty string when no rows."""
        result = services.export_to_csv({"rows": []})
        self.assertEqual(result, "")

    def test_20_export_to_excel_returns_bytes(self):
        """Excel export returns bytes (valid xlsx starts with PK magic bytes)."""
        try:
            xlsx_bytes = services.export_to_excel(self.sample_data)
            self.assertIsInstance(xlsx_bytes, bytes)
            self.assertTrue(xlsx_bytes[:2] == b"PK")  # ZIP/XLSX magic
        except ImportError:
            self.skipTest("openpyxl not installed")

    def test_21_export_to_pdf_returns_bytes(self):
        """PDF export returns bytes starting with %PDF."""
        try:
            pdf_bytes = services.export_to_pdf(self.sample_data)
            self.assertIsInstance(pdf_bytes, bytes)
            self.assertTrue(pdf_bytes[:4] == b"%PDF")
        except ImportError:
            self.skipTest("reportlab not installed")


# ═══════════════════════════════════════════════════════════════════
# DISPATCHER & SCHEDULER
# ═══════════════════════════════════════════════════════════════════

class TestDispatcher(TestCase):
    def setUp(self):
        self.f = make_base()
        services.seed_report_definitions()

    def test_22_run_report_invalid_slug_raises(self):
        """run_report with unknown slug raises ValueError."""
        with self.assertRaises(ValueError):
            services.run_report("nonexistent_slug", self.f["plant"])

    def test_23_run_report_returns_dict_for_json(self):
        """run_report in JSON format returns a dict."""
        result = services.run_report(
            "inventory_valuation", self.f["plant"], output_format="JSON"
        )
        self.assertIsInstance(result, dict)

    def test_24_schedule_report_creates_record(self):
        """schedule_report creates a ScheduledReport with correct celery_task_id."""
        f = self.f
        sr = services.schedule_report(
            plant=f["plant"],
            report_slug="inventory_valuation",
            name="Daily Inventory Report",
            frequency="DAILY",
            output_format="XLSX",
            recipients=["qa@trident.com"],
            filters={},
            run_at_hour=6,
            user=f["user"],
        )
        self.assertIsNotNone(sr.pk)
        self.assertEqual(sr.frequency, "DAILY")
        self.assertIn("inventory_valuation", sr.celery_task_id)
        self.assertEqual(sr.recipients, ["qa@trident.com"])

    # ── P4: WIP + RM Inventory Valuation ─────────────────────────

    def test_inventory_valuation_has_summary(self):
        """Enhanced report includes summary with rm/wip/fg breakdown."""
        from apps.reports.services import inventory_valuation_report
        from apps.core.models import Plant
        plant = Plant.objects.first()
        if plant:
            result = inventory_valuation_report(plant, user=None)
            self.assertIn("summary", result)
            self.assertIn("rm_total", result["summary"])
            self.assertIn("wip_total", result["summary"])
            self.assertIn("fg_total", result["summary"])
            self.assertIn("grand_total", result["summary"])

    def test_inventory_valuation_backward_compatible(self):
        """Old 'rows' and 'grand_total_value' keys still present."""
        from apps.reports.services import inventory_valuation_report
        from apps.core.models import Plant
        plant = Plant.objects.first()
        if plant:
            result = inventory_valuation_report(plant, user=None)
            self.assertIn("rows", result)
            self.assertIn("grand_total_value", result)

    def test_inventory_valuation_separate_sections(self):
        """Report has rm_rows, wip_rows, fg_rows, other_rows keys."""
        from apps.reports.services import inventory_valuation_report
        from apps.core.models import Plant
        plant = Plant.objects.first()
        if plant:
            result = inventory_valuation_report(plant, user=None)
            self.assertIn("rm_rows", result)
            self.assertIn("wip_rows", result)
            self.assertIn("fg_rows", result)
            self.assertIn("other_rows", result)

    def test_inventory_valuation_grand_total_consistent(self):
        """grand_total_value equals summary.grand_total."""
        from apps.reports.services import inventory_valuation_report
        from apps.core.models import Plant
        plant = Plant.objects.first()
        if plant:
            result = inventory_valuation_report(plant, user=None)
            self.assertAlmostEqual(
                result["grand_total_value"],
                result["summary"]["grand_total"],
                places=2
            )

    # ── P4 additional test (exact name from spec) ─────────────────
    def test_wip_rows_separate_from_rm(self):
        """WIP warehouse lots appear in wip_rows, not rm_rows."""
        from apps.reports.services import inventory_valuation_report
        from apps.core.models import Plant
        plant = Plant.objects.first()
        if plant:
            result = inventory_valuation_report(plant, user=None)
            # All items in rm_rows must be from RM warehouse types
            for row in result["rm_rows"]:
                self.assertIn(row["warehouse_type"], ("RM_STORE", "RAW_MATERIAL", "OTHER"))
