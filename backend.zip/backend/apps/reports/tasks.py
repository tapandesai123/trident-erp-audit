"""Reports & Analytics Celery tasks."""
from celery import shared_task
from datetime import date
import logging

logger = logging.getLogger(__name__)


@shared_task(bind=True, max_retries=2)
def deliver_scheduled_report(self, scheduled_report_id: int):
    """
    Execute a ScheduledReport and email the output file to all recipients.
    """
    try:
        from apps.reports.models import ScheduledReport
        from apps.reports.services import run_report
        from django.core.mail import EmailMessage
        from django.conf import settings

        sr = ScheduledReport.objects.select_related("plant", "report").get(pk=scheduled_report_id)
        if not sr.is_active:
            return {"skipped": True, "reason": "Scheduled report is inactive"}

        filters = {**sr.filters}
        # Auto-inject date range for period-based reports
        today = date.today()
        if "from_date" not in filters:
            filters["from_date"] = date(today.year, today.month, 1)
        if "to_date" not in filters:
            filters["to_date"] = today

        output = run_report(
            report_slug=sr.report.slug,
            plant=sr.plant,
            output_format=sr.output_format,
            **filters,
        )

        if not sr.recipients:
            return {"delivered": 0, "reason": "No recipients configured"}

        # Build attachment
        slug = sr.report.slug
        fmt = sr.output_format.lower()
        filename = f"{slug}_{today}.{fmt}"

        content_types = {
            "xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            "pdf": "application/pdf",
            "csv": "text/csv",
        }
        content_type = content_types.get(fmt, "application/octet-stream")

        if isinstance(output, str):
            output = output.encode("utf-8")

        for recipient in sr.recipients:
            try:
                msg = EmailMessage(
                    subject=f"[Trident ERP] {sr.report.name} — {today}",
                    body=f"Please find attached the {sr.report.name} report for {today}.",
                    from_email=getattr(settings, "DEFAULT_FROM_EMAIL", "erp@trident.com"),
                    to=[recipient],
                )
                msg.attach(filename, output, content_type)
                msg.send()
            except Exception as e:
                logger.warning(f"Failed to send report to {recipient}: {e}")

        return {"delivered": len(sr.recipients), "filename": filename}

    except Exception as exc:
        raise self.retry(exc=exc, countdown=300)


@shared_task
def run_all_scheduled_reports_for_frequency(frequency: str):
    """
    Called by Celery Beat for each frequency group (DAILY, WEEKLY, MONTHLY).
    Dispatches deliver_scheduled_report for each active schedule.
    """
    from apps.reports.models import ScheduledReport
    from datetime import date

    today = date.today()
    qs = ScheduledReport.objects.filter(frequency=frequency, is_active=True)

    if frequency == "WEEKLY":
        qs = qs.filter(day_of_week=today.weekday())
    elif frequency in ("MONTHLY", "QUARTERLY"):
        qs = qs.filter(day_of_month=today.day)

    dispatched = 0
    for sr in qs:
        deliver_scheduled_report.delay(sr.pk)
        dispatched += 1

    return {"frequency": frequency, "dispatched": dispatched}


@shared_task
def purge_old_report_executions(days_to_keep: int = 90):
    """
    Periodic housekeeping: remove ReportExecution records older than N days.
    """
    from apps.reports.models import ReportExecution
    from datetime import timedelta
    from django.utils import timezone

    cutoff = timezone.now() - timedelta(days=days_to_keep)
    deleted, _ = ReportExecution.objects.filter(
        started_at__lt=cutoff, status="SUCCESS"
    ).delete()
    return {"deleted_executions": deleted}


@shared_task
def async_run_report(report_slug: str, plant_id: int, output_format: str,
                     user_id: int = None, **kwargs):
    """
    On-demand async report execution (for large reports).
    Updates ReportExecution file_path on completion.
    """
    try:
        from apps.core.models import Plant
        from apps.reports.services import run_report, export_to_excel, export_to_pdf
        from django.contrib.auth import get_user_model
        import os, tempfile

        plant = Plant.objects.get(pk=plant_id)
        User = get_user_model()
        user = User.objects.filter(pk=user_id).first() if user_id else None

        result = run_report(report_slug, plant, output_format=output_format,
                            user=user, **kwargs)

        # Write to temp file (in production this would go to S3/SFTP)
        suffix = {"XLSX": ".xlsx", "PDF": ".pdf", "CSV": ".csv"}.get(output_format, ".json")
        with tempfile.NamedTemporaryFile(delete=False, suffix=suffix,
                                        prefix=f"{report_slug}_") as f:
            if isinstance(result, str):
                f.write(result.encode())
            elif isinstance(result, bytes):
                f.write(result)
            file_path = f.name

        return {"status": "SUCCESS", "file_path": file_path, "slug": report_slug}
    except Exception as e:
        return {"status": "FAILED", "error": str(e)}
