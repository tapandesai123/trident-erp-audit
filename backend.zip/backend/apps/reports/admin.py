"""Reports & Analytics admin registrations."""
from django.contrib import admin
from apps.reports.models import ReportDefinition, ReportFilter, ScheduledReport, ReportExecution


@admin.register(ReportDefinition)
class ReportDefinitionAdmin(admin.ModelAdmin):
    list_display = ["slug", "name", "category", "default_format", "is_active", "is_system"]
    list_filter = ["category", "is_active", "is_system"]
    search_fields = ["slug", "name"]
    readonly_fields = ["uuid", "created_at", "updated_at"]

    def has_delete_permission(self, request, obj=None):
        if obj and obj.is_system:
            return False
        return super().has_delete_permission(request, obj)


@admin.register(ReportFilter)
class ReportFilterAdmin(admin.ModelAdmin):
    list_display = ["name", "report", "created_by", "is_default"]
    list_filter = ["report", "is_default"]
    search_fields = ["name", "report__name"]
    readonly_fields = ["uuid", "created_at", "updated_at"]


@admin.register(ScheduledReport)
class ScheduledReportAdmin(admin.ModelAdmin):
    list_display = ["name", "report", "plant", "frequency", "output_format",
                    "run_at_hour", "is_active", "celery_task_id"]
    list_filter = ["frequency", "output_format", "is_active", "plant"]
    search_fields = ["name", "report__name"]
    readonly_fields = ["uuid", "celery_task_id", "created_at", "updated_at"]


@admin.register(ReportExecution)
class ReportExecutionAdmin(admin.ModelAdmin):
    list_display = ["report", "plant", "status", "output_format",
                    "row_count", "duration_ms", "started_at", "triggered_by"]
    list_filter = ["status", "output_format", "plant", "report"]
    search_fields = ["report__name", "report__slug"]
    readonly_fields = ["uuid", "started_at", "completed_at", "duration_ms",
                       "file_path", "status", "row_count", "error_message"]
    date_hierarchy = "started_at"

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False
