"""Reports & Analytics API Viewsets."""
from datetime import date
from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django.http import HttpResponse

from apps.reports.models import ReportDefinition, ReportFilter, ScheduledReport, ReportExecution
from apps.reports.api.serializers import (
    ReportDefinitionListSerializer, ReportDefinitionDetailSerializer, ReportDefinitionCreateSerializer,
    ReportFilterListSerializer, ReportFilterDetailSerializer, ReportFilterCreateSerializer,
    ScheduledReportListSerializer, ScheduledReportDetailSerializer, ScheduledReportCreateSerializer,
    ReportExecutionListSerializer, ReportExecutionDetailSerializer, ReportExecutionCreateSerializer,
)
from apps.reports import services


def _get_plant(request):
    from apps.core.models import Plant
    plant_id = request.query_params.get("plant") or request.data.get("plant")
    if not plant_id:
        raise ValueError("'plant' parameter required.")
    return Plant.objects.get(pk=plant_id)


def _parse_date(val, default=None):
    if not val:
        return default or date.today()
    if isinstance(val, date):
        return val
    return date.fromisoformat(str(val))


class ReportDefinitionViewSet(viewsets.ModelViewSet):
    queryset = ReportDefinition.objects.all()
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return ReportDefinitionListSerializer
        if self.action in ("create", "update", "partial_update"):
            return ReportDefinitionCreateSerializer
        return ReportDefinitionDetailSerializer

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user, is_system=False)

    def destroy(self, request, *args, **kwargs):
        obj = self.get_object()
        if obj.is_system:
            return Response({"error": "System reports cannot be deleted."},
                            status=status.HTTP_403_FORBIDDEN)
        return super().destroy(request, *args, **kwargs)

    @action(detail=False, methods=["post"])
    def seed(self, request):
        """POST /api/v1/reports/definitions/seed/ — seed built-in report definitions."""
        services.seed_report_definitions()
        return Response({"message": "Report definitions seeded."})


class ReportFilterViewSet(viewsets.ModelViewSet):
    queryset = ReportFilter.objects.select_related("report", "created_by")
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return ReportFilterListSerializer
        if self.action in ("create", "update", "partial_update"):
            return ReportFilterCreateSerializer
        return ReportFilterDetailSerializer

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)


class ScheduledReportViewSet(viewsets.ModelViewSet):
    queryset = ScheduledReport.objects.select_related("plant", "report", "created_by")
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return ScheduledReportListSerializer
        if self.action in ("create", "update", "partial_update"):
            return ScheduledReportCreateSerializer
        return ScheduledReportDetailSerializer

    def create(self, request, *args, **kwargs):
        from apps.core.models import Plant
        d = request.data
        try:
            plant = Plant.objects.get(pk=d["plant"])
            sr = services.schedule_report(
                plant=plant,
                report_slug=d["report_slug"],
                name=d["name"],
                frequency=d["frequency"],
                output_format=d.get("output_format", "XLSX"),
                recipients=d.get("recipients", []),
                filters=d.get("filters", {}),
                run_at_hour=int(d.get("run_at_hour", 7)),
                run_at_minute=int(d.get("run_at_minute", 0)),
                day_of_week=d.get("day_of_week"),
                day_of_month=d.get("day_of_month"),
                user=request.user,
            )
            return Response(ScheduledReportDetailSerializer(sr).data,
                            status=status.HTTP_201_CREATED)
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=True, methods=["post"])
    def trigger_now(self, request, pk=None):
        """Manually trigger a scheduled report immediately (async)."""
        sr = self.get_object()
        from apps.reports.tasks import deliver_scheduled_report
        deliver_scheduled_report.delay(sr.pk)
        return Response({"message": f"Report '{sr.name}' queued for execution."})


class ReportExecutionViewSet(viewsets.ReadOnlyModelViewSet):
    """Read-only log of report executions. Run reports via /run/ action on definitions."""
    queryset = ReportExecution.objects.select_related("report", "plant", "triggered_by")
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == "list":
            return ReportExecutionListSerializer
        return ReportExecutionDetailSerializer


class ReportRunnerViewSet(viewsets.ViewSet):
    """
    Stateless report runner — all 7 reports accessible via /api/v1/reports/run/{slug}/
    Supports on-demand JSON, XLSX, PDF, CSV output.
    """
    permission_classes = [IsAuthenticated]

    @action(detail=False, methods=["get", "post"], url_path=r"(?P<slug>[^/.]+)")
    def run(self, request, slug=None):
        """
        GET/POST /api/v1/reports/run/{slug}/
        Query/body params: plant, format (JSON|XLSX|PDF|CSV), + report-specific params.
        """
        try:
            plant = _get_plant(request)
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)

        params = {**request.query_params.dict(), **request.data}
        fmt = params.pop("format", "JSON").upper()
        params.pop("plant", None)

        # Parse date params
        for k in ("from_date", "to_date", "as_of_date"):
            if k in params:
                try:
                    params[k] = _parse_date(params[k])
                except ValueError:
                    return Response({"error": f"Invalid date for {k}"},
                                    status=status.HTTP_400_BAD_REQUEST)
        for k in ("month", "year", "warehouse_id", "vendor_id", "customer_id"):
            if k in params:
                try:
                    params[k] = int(params[k])
                except (TypeError, ValueError):
                    pass

        try:
            result = services.run_report(slug, plant, output_format=fmt,
                                         user=request.user, **params)
        except ValueError as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            return Response({"error": f"Report execution failed: {str(e)}"},
                            status=status.HTTP_500_INTERNAL_SERVER_ERROR)

        if fmt == "XLSX":
            resp = HttpResponse(result,
                                content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
            resp["Content-Disposition"] = f'attachment; filename="{slug}_{date.today()}.xlsx"'
            return resp
        elif fmt == "PDF":
            resp = HttpResponse(result, content_type="application/pdf")
            resp["Content-Disposition"] = f'attachment; filename="{slug}_{date.today()}.pdf"'
            return resp
        elif fmt == "CSV":
            resp = HttpResponse(result, content_type="text/csv")
            resp["Content-Disposition"] = f'attachment; filename="{slug}_{date.today()}.csv"'
            return resp

        return Response(result)
