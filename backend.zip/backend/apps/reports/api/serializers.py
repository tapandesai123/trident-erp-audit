"""Reports API Serializers — 3 variants per model."""
from rest_framework import serializers
from apps.reports.models import ReportDefinition, ReportFilter, ScheduledReport, ReportExecution


# ─── ReportDefinition ─────────────────────────────────────────────

class ReportDefinitionListSerializer(serializers.ModelSerializer):
    class Meta:
        model = ReportDefinition
        fields = ["id", "uuid", "slug", "name", "category",
                  "supported_formats", "default_format", "is_active"]


class ReportDefinitionDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = ReportDefinition
        fields = "__all__"


class ReportDefinitionCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = ReportDefinition
        fields = ["slug", "name", "description", "category",
                  "supported_formats", "default_format", "parameter_schema"]


# ─── ReportFilter ─────────────────────────────────────────────────

class ReportFilterListSerializer(serializers.ModelSerializer):
    report_name = serializers.CharField(source="report.name", read_only=True)

    class Meta:
        model = ReportFilter
        fields = ["id", "uuid", "report", "report_name", "name", "is_default"]


class ReportFilterDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = ReportFilter
        fields = "__all__"


class ReportFilterCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = ReportFilter
        fields = ["report", "name", "filters", "is_default"]


# ─── ScheduledReport ──────────────────────────────────────────────

class ScheduledReportListSerializer(serializers.ModelSerializer):
    report_name = serializers.CharField(source="report.name", read_only=True)
    plant_code = serializers.CharField(source="plant.code", read_only=True)

    class Meta:
        model = ScheduledReport
        fields = ["id", "uuid", "name", "report_name", "plant_code",
                  "frequency", "output_format", "is_active", "recipients"]


class ScheduledReportDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = ScheduledReport
        fields = "__all__"


class ScheduledReportCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = ScheduledReport
        fields = ["plant", "report", "name", "frequency", "day_of_week",
                  "day_of_month", "run_at_hour", "run_at_minute",
                  "output_format", "filters", "recipients"]


# ─── ReportExecution ──────────────────────────────────────────────

class ReportExecutionListSerializer(serializers.ModelSerializer):
    report_name = serializers.CharField(source="report.name", read_only=True)
    triggered_by_name = serializers.CharField(source="triggered_by.username", read_only=True)

    class Meta:
        model = ReportExecution
        fields = ["id", "uuid", "report_name", "plant", "status",
                  "output_format", "row_count", "started_at",
                  "completed_at", "duration_ms", "triggered_by_name"]


class ReportExecutionDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = ReportExecution
        fields = "__all__"


class ReportExecutionCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = ReportExecution
        fields = ["report", "plant", "filters_used", "output_format"]
