"""Reports API URLs."""
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from apps.reports.api.viewsets import (
    ReportDefinitionViewSet, ReportFilterViewSet,
    ScheduledReportViewSet, ReportExecutionViewSet,
    ReportRunnerViewSet,
)

router = DefaultRouter()
router.register("definitions", ReportDefinitionViewSet, basename="report-definition")
router.register("filters", ReportFilterViewSet, basename="report-filter")
router.register("schedules", ScheduledReportViewSet, basename="scheduled-report")
router.register("executions", ReportExecutionViewSet, basename="report-execution")
router.register("run", ReportRunnerViewSet, basename="report-run")

urlpatterns = [
    path("", include(router.urls)),
]
