"""
Reports & Analytics Module Services — Section 10

Report services return structured dicts (rows + metadata).
Export helpers convert to XLSX / PDF / CSV.
All report runs log to ReportExecution (AuditLog action=EXPORT).

Services:
  - inventory_valuation_report()
  - purchase_analysis_report()
  - sales_analysis_report()
  - production_efficiency_report()
  - quality_summary_report()
  - accounts_pl_report()
  - gstr_reconciliation_report()
  - export_to_excel()
  - export_to_pdf()
  - export_to_csv()
  - schedule_report()
  - run_report()              ← dispatcher
"""
import io
import time
from decimal import Decimal
from datetime import date, datetime
from django.db.models import Sum, Count, Avg, F, Q, Value, ExpressionWrapper, DecimalField
from django.db.models.functions import TruncMonth, TruncDate, Coalesce
from django.utils import timezone
from apps.core.models import AuditLog


# ═══════════════════════════════════════════════════════════════════
# HELPERS
# ═══════════════════════════════════════════════════════════════════

def _log_export(user, report_slug, plant):
    AuditLog.objects.create(
        user=user, action="EXPORT", module="reports",
        resource="Report", resource_id=None,
        new_values={"slug": report_slug, "plant": str(plant)},
    )


def _d(val):
    """Safe decimal conversion."""
    try:
        return float(Decimal(str(val or 0)))
    except Exception:
        return 0.0


def _start_execution(report_slug, plant, user, filters, fmt):
    from apps.reports.models import ReportDefinition, ReportExecution
    try:
        rdef = ReportDefinition.objects.get(slug=report_slug)
        return ReportExecution.objects.create(
            report=rdef, plant=plant, triggered_by=user,
            filters_used=filters, output_format=fmt, status="RUNNING",
        )
    except Exception:
        return None


def _finish_execution(execution, row_count, file_path="", error=""):
    if not execution:
        return
    execution.status = "FAILED" if error else "SUCCESS"
    execution.row_count = row_count
    execution.file_path = file_path
    execution.error_message = error
    execution.completed_at = timezone.now()
    if execution.started_at:
        delta = (execution.completed_at - execution.started_at).total_seconds()
        execution.duration_ms = int(delta * 1000)
    execution.save(update_fields=[
        "status", "row_count", "file_path", "error_message",
        "completed_at", "duration_ms",
    ])


# ═══════════════════════════════════════════════════════════════════
# REPORT 1 — INVENTORY VALUATION
# ═══════════════════════════════════════════════════════════════════

def inventory_valuation_report(plant, as_of_date=None, warehouse_id=None, user=None) -> dict:
    """
    Enhanced stock valuation report: breaks down by warehouse type.
    Shows RM, WIP, FG, and Other separately with subtotals.
    Backward-compatible: keeps 'rows' key with all rows combined.
    """
    execution = _start_execution("inventory_valuation", plant, user,
                                  {"as_of_date": str(as_of_date), "warehouse_id": warehouse_id}, "JSON")
    try:
        from apps.stores.models import InventoryLot

        qs = InventoryLot.objects.filter(
            plant=plant,
            status__in=("AVAILABLE", "RESERVED"),
            current_qty__gt=0,
        ).select_related("item", "warehouse", "uom")

        if warehouse_id:
            qs = qs.filter(warehouse_id=warehouse_id)

        totals_map = {}

        for lot in qs.order_by("warehouse__warehouse_type", "item__code", "warehouse__code", "created_at"):
            key = (lot.item_id, lot.warehouse_id)
            unit_cost = _d(getattr(lot, "unit_cost", 0) or getattr(lot, "cost_per_unit", 0))
            qty = _d(lot.current_qty)
            value = qty * unit_cost
            wtype = lot.warehouse.warehouse_type if lot.warehouse else "OTHER"

            if key not in totals_map:
                totals_map[key] = {
                    "item_code": getattr(lot.item, "item_code", None) or lot.item.code,
                    "item_name": getattr(lot.item, "item_name", None) or lot.item.name,
                    "warehouse_code": lot.warehouse.code if lot.warehouse else "",
                    "warehouse_name": lot.warehouse.name if lot.warehouse else "",
                    "warehouse_type": wtype,
                    "uom": lot.uom.code if lot.uom else "",
                    "total_qty": 0.0,
                    "total_value": 0.0,
                    "lot_count": 0,
                }
            totals_map[key]["total_qty"] += qty
            totals_map[key]["total_value"] += value
            totals_map[key]["lot_count"] += 1

        rm_rows, wip_rows, fg_rows, other_rows = [], [], [], []
        rm_total = wip_total = fg_total = other_total = 0.0

        for row in sorted(totals_map.values(), key=lambda r: (r["warehouse_type"], r["item_code"])):
            row["total_value"] = round(row["total_value"], 2)
            row["total_qty"] = round(row["total_qty"], 3)
            wtype = row["warehouse_type"]
            if wtype in ("RM_STORE", "RAW_MATERIAL"):
                rm_rows.append(row)
                rm_total += row["total_value"]
            elif wtype == "WIP":
                wip_rows.append(row)
                wip_total += row["total_value"]
            elif wtype in ("FG_STORE", "FINISHED_GOODS"):
                fg_rows.append(row)
                fg_total += row["total_value"]
            else:
                other_rows.append(row)
                other_total += row["total_value"]

        all_rows = rm_rows + wip_rows + fg_rows + other_rows
        grand_total = round(rm_total + wip_total + fg_total + other_total, 2)

        result = {
            "report": "Inventory Valuation",
            "plant": plant.code,
            "as_of_date": str(as_of_date or date.today()),
            "summary": {
                "rm_total": round(rm_total, 2),
                "wip_total": round(wip_total, 2),
                "fg_total": round(fg_total, 2),
                "other_total": round(other_total, 2),
                "grand_total": grand_total,
            },
            "rm_rows": rm_rows,
            "wip_rows": wip_rows,
            "fg_rows": fg_rows,
            "other_rows": other_rows,
            # Backward-compatible combined list
            "rows": all_rows,
            "grand_total_value": grand_total,
            "row_count": len(all_rows),
        }
        _finish_execution(execution, len(all_rows))
        _log_export(user, "inventory_valuation", plant)
        return result
    except Exception as e:
        _finish_execution(execution, 0, error=str(e))
        raise


# ═══════════════════════════════════════════════════════════════════
# REPORT 2 — PURCHASE ANALYSIS
# ═══════════════════════════════════════════════════════════════════

def purchase_analysis_report(plant, from_date, to_date, vendor_id=None, user=None) -> dict:
    """
    PO analysis: vendor-wise spend, PO qty vs GRN qty, pending deliveries.
    """
    execution = _start_execution("purchase_analysis", plant, user,
                                  {"from": str(from_date), "to": str(to_date)}, "JSON")
    try:
        from apps.purchase.models import PurchaseOrder, POLine

        qs = POLine.objects.filter(
            po__plant=plant,
            po__po_date__range=(from_date, to_date),
            po__status__in=("APPROVED", "PARTIALLY_RECEIVED", "FULLY_RECEIVED"),
        ).select_related("po__vendor", "item")

        if vendor_id:
            qs = qs.filter(po__vendor_id=vendor_id)

        # Vendor-wise aggregation
        vendor_map = {}
        rows = []

        for line in qs.order_by("po__vendor__vendor_name", "po__po_date"):
            vendor_name = line.po.vendor.vendor_name
            if vendor_name not in vendor_map:
                vendor_map[vendor_name] = {
                    "vendor_name": vendor_name,
                    "vendor_code": line.po.vendor.vendor_code,
                    "po_count": set(),
                    "ordered_qty_value": 0.0,
                    "received_qty_value": 0.0,
                    "pending_value": 0.0,
                }
            v = vendor_map[vendor_name]
            v["po_count"].add(line.po.po_number)
            ordered_val = _d(line.amount)
            received_val = _d(line.received_qty) * _d(line.rate)
            v["ordered_qty_value"] += ordered_val
            v["received_qty_value"] += received_val
            v["pending_value"] += (ordered_val - received_val)

        for v in vendor_map.values():
            v["po_count"] = len(v["po_count"])
            v["ordered_qty_value"] = round(v["ordered_qty_value"], 2)
            v["received_qty_value"] = round(v["received_qty_value"], 2)
            v["pending_value"] = round(v["pending_value"], 2)
            v["fulfillment_pct"] = round(
                v["received_qty_value"] / v["ordered_qty_value"] * 100
                if v["ordered_qty_value"] else 0, 1
            )
            rows.append(v)

        rows.sort(key=lambda r: -r["ordered_qty_value"])

        result = {
            "report": "Purchase Analysis",
            "plant": plant.code,
            "period": f"{from_date} to {to_date}",
            "grand_total_ordered": round(sum(r["ordered_qty_value"] for r in rows), 2),
            "grand_total_received": round(sum(r["received_qty_value"] for r in rows), 2),
            "grand_total_pending": round(sum(r["pending_value"] for r in rows), 2),
            "row_count": len(rows),
            "rows": rows,
        }
        _finish_execution(execution, len(rows))
        _log_export(user, "purchase_analysis", plant)
        return result
    except Exception as e:
        _finish_execution(execution, 0, error=str(e))
        raise


# ═══════════════════════════════════════════════════════════════════
# REPORT 3 — SALES ANALYSIS
# ═══════════════════════════════════════════════════════════════════

def sales_analysis_report(plant, from_date, to_date, customer_id=None,
                           group_by="customer", user=None) -> dict:
    """
    Sales analysis: SO vs Invoice, customer-wise or item-wise revenue.
    group_by: "customer" | "item" | "month"
    """
    execution = _start_execution("sales_analysis", plant, user,
                                  {"from": str(from_date), "to": str(to_date),
                                   "group_by": group_by}, "JSON")
    try:
        from apps.sales.models import SalesOrder, SOLine

        qs = SOLine.objects.filter(
            sales_order__plant=plant,
            sales_order__so_date__range=(from_date, to_date),
            sales_order__status__in=("APPROVED", "IN_PROGRESS", "COMPLETED", "INVOICED"),
        ).select_related("sales_order__customer", "item")

        if customer_id:
            qs = qs.filter(sales_order__customer_id=customer_id)

        agg_map = {}
        for line in qs:
            so = line.sales_order
            if group_by == "customer":
                key = so.customer.customer_name if so.customer else "Unknown"
                label = key
                code = so.customer.customer_code if so.customer else ""
            elif group_by == "item":
                key = line.item.item_code
                label = line.item.item_name
                code = key
            elif group_by == "month":
                key = str(so.so_date)[:7]  # YYYY-MM
                label = key
                code = key
            else:
                key = "ALL"
                label = "All"
                code = ""

            if key not in agg_map:
                agg_map[key] = {
                    "key": key,
                    "label": label,
                    "code": code,
                    "ordered_qty": 0.0,
                    "invoiced_qty": 0.0,
                    "ordered_value": 0.0,
                    "invoiced_value": 0.0,
                    "so_count": set(),
                }
            a = agg_map[key]
            ordered_qty = _d(getattr(line, "ordered_qty", 0) or getattr(line, "quantity", 0))
            a["ordered_qty"] += ordered_qty
            a["ordered_value"] += _d(getattr(line, "amount", 0) or
                                     ordered_qty * _d(getattr(line, "rate", 0)))
            a["so_count"].add(so.so_number)

        rows = []
        for a in agg_map.values():
            a["so_count"] = len(a["so_count"])
            a["ordered_qty"] = round(a["ordered_qty"], 3)
            a["ordered_value"] = round(a["ordered_value"], 2)
            rows.append(a)

        rows.sort(key=lambda r: -r["ordered_value"])

        result = {
            "report": "Sales Analysis",
            "plant": plant.code,
            "period": f"{from_date} to {to_date}",
            "group_by": group_by,
            "grand_total_value": round(sum(r["ordered_value"] for r in rows), 2),
            "row_count": len(rows),
            "rows": rows,
        }
        _finish_execution(execution, len(rows))
        _log_export(user, "sales_analysis", plant)
        return result
    except Exception as e:
        _finish_execution(execution, 0, error=str(e))
        raise


# ═══════════════════════════════════════════════════════════════════
# REPORT 4 — PRODUCTION EFFICIENCY
# ═══════════════════════════════════════════════════════════════════

def production_efficiency_report(plant, from_date, to_date, user=None) -> dict:
    """
    WO planned vs actual qty/cost, OEE proxy per work center.
    """
    execution = _start_execution("production_efficiency", plant, user,
                                  {"from": str(from_date), "to": str(to_date)}, "JSON")
    try:
        from apps.production.models import WorkOrder, JobCard

        wos = WorkOrder.objects.filter(
            plant=plant,
            planned_start__range=(from_date, to_date),
            status__in=("COMPLETED", "CLOSED"),
        ).select_related("finished_good")

        rows = []
        for wo in wos:
            planned_qty = _d(wo.planned_qty)
            produced_qty = _d(wo.produced_qty)
            rejected_qty = _d(wo.rejected_qty)
            std_cost = _d(wo.std_material_cost) + _d(wo.std_labour_cost) + _d(wo.std_overhead_cost)
            act_cost = _d(wo.actual_material_cost) + _d(wo.actual_labour_cost) + _d(wo.actual_overhead_cost)
            rows.append({
                "wo_number": wo.wo_number,
                "item_code": wo.finished_good.item_code,
                "item_name": wo.finished_good.item_name,
                "planned_qty": planned_qty,
                "produced_qty": produced_qty,
                "rejected_qty": rejected_qty,
                "yield_pct": round((produced_qty - rejected_qty) / planned_qty * 100
                                   if planned_qty else 0, 1),
                "std_cost": round(std_cost, 2),
                "actual_cost": round(act_cost, 2),
                "variance": round(act_cost - std_cost, 2),
                "variance_pct": round((act_cost - std_cost) / std_cost * 100
                                      if std_cost else 0, 1),
            })

        # Work center loading summary
        jc_agg = (
            JobCard.objects.filter(
                work_order__plant=plant,
                status="COMPLETED",
                completed_at__date__range=(from_date, to_date),
            )
            .values("work_center__code", "work_center__name")
            .annotate(
                total_planned_hrs=Sum("planned_hours"),
                total_actual_hrs=Sum("actual_hours"),
                job_count=Count("id"),
            )
        )

        wc_rows = [
            {
                "work_center_code": r["work_center__code"],
                "work_center_name": r["work_center__name"],
                "total_planned_hrs": _d(r["total_planned_hrs"]),
                "total_actual_hrs": _d(r["total_actual_hrs"]),
                "efficiency_pct": round(
                    _d(r["total_planned_hrs"]) / _d(r["total_actual_hrs"]) * 100
                    if _d(r["total_actual_hrs"]) else 0, 1
                ),
                "job_count": r["job_count"],
            }
            for r in jc_agg
        ]

        result = {
            "report": "Production Efficiency",
            "plant": plant.code,
            "period": f"{from_date} to {to_date}",
            "wo_count": len(rows),
            "total_variance": round(sum(r["variance"] for r in rows), 2),
            "avg_yield_pct": round(
                sum(r["yield_pct"] for r in rows) / len(rows) if rows else 0, 1
            ),
            "work_order_rows": rows,
            "work_center_rows": wc_rows,
            "row_count": len(rows) + len(wc_rows),
        }
        _finish_execution(execution, result["row_count"])
        _log_export(user, "production_efficiency", plant)
        return result
    except Exception as e:
        _finish_execution(execution, 0, error=str(e))
        raise


# ═══════════════════════════════════════════════════════════════════
# REPORT 5 — QUALITY SUMMARY
# ═══════════════════════════════════════════════════════════════════

def quality_summary_report(plant, from_date, to_date, user=None) -> dict:
    """
    Rejection %, NCR trend by month, CAPA closure rate.
    """
    execution = _start_execution("quality_summary", plant, user,
                                  {"from": str(from_date), "to": str(to_date)}, "JSON")
    try:
        from apps.quality.models import InspectionLot, NCR, CAPA

        lots = InspectionLot.objects.filter(
            plant=plant,
            inspection_date__range=(from_date, to_date),
        )
        total_lots = lots.count()
        rejected = lots.filter(status="REJECTED").count()
        accepted = lots.filter(status="ACCEPTED").count()

        ncrs = NCR.objects.filter(plant=plant, ncr_date__range=(from_date, to_date))
        ncr_by_severity = dict(
            ncrs.values("severity").annotate(c=Count("id")).values_list("severity", "c")
        )
        ncr_trend = list(
            ncrs.annotate(month=TruncMonth("ncr_date"))
            .values("month")
            .annotate(count=Count("id"))
            .order_by("month")
            .values_list("month", "count")
        )
        ncr_trend_rows = [{"month": str(m)[:7], "ncr_count": c} for m, c in ncr_trend]

        capas = CAPA.objects.filter(plant=plant, created_at__date__range=(from_date, to_date))
        total_capas = capas.count()
        closed_capas = capas.filter(status="CLOSED").count()
        overdue_capas = capas.filter(
            status__in=("OPEN", "IN_PROGRESS"), target_date__lt=date.today()
        ).count()
        avg_eff = capas.filter(effectiveness_rating__isnull=False).aggregate(
            avg=Avg("effectiveness_rating")
        )["avg"]

        # Top NCR items
        top_items = list(
            ncrs.values("item__item_code", "item__item_name")
            .annotate(ncr_count=Count("id"), total_qty=Sum("quantity_affected"))
            .order_by("-ncr_count")[:10]
        )

        rows = [
            {"category": "Inspection Lots", "total": total_lots,
             "accepted": accepted, "rejected": rejected,
             "rejection_pct": round(rejected / total_lots * 100 if total_lots else 0, 1)},
            {"category": "NCRs", "total": ncrs.count(),
             "open": ncrs.filter(status="OPEN").count(),
             "closed": ncrs.filter(status="CLOSED").count(),
             "by_severity": ncr_by_severity},
            {"category": "CAPAs", "total": total_capas,
             "closed": closed_capas,
             "closure_rate_pct": round(closed_capas / total_capas * 100 if total_capas else 0, 1),
             "overdue": overdue_capas,
             "avg_effectiveness": round(float(avg_eff), 1) if avg_eff else None},
        ]

        result = {
            "report": "Quality Summary",
            "plant": plant.code,
            "period": f"{from_date} to {to_date}",
            "summary_rows": rows,
            "ncr_trend": ncr_trend_rows,
            "top_ncr_items": list(top_items),
            "row_count": len(rows),
        }
        _finish_execution(execution, len(rows))
        _log_export(user, "quality_summary", plant)
        return result
    except Exception as e:
        _finish_execution(execution, 0, error=str(e))
        raise


# ═══════════════════════════════════════════════════════════════════
# REPORT 6 — ACCOUNTS P&L
# ═══════════════════════════════════════════════════════════════════

def accounts_pl_report(plant, from_date, to_date, user=None) -> dict:
    """
    Profit & Loss statement derived from posted voucher lines.
    Groups by AccountGroup type (INCOME vs EXPENSE).
    """
    execution = _start_execution("accounts_pl", plant, user,
                                  {"from": str(from_date), "to": str(to_date)}, "JSON")
    try:
        from apps.accounts.models import VoucherLine, LedgerAccount

        posted_lines = VoucherLine.objects.filter(
            voucher__plant=plant,
            voucher__voucher_date__range=(from_date, to_date),
            voucher__status="POSTED",
        ).select_related("ledger_account__account_group")

        income_rows = {}
        expense_rows = {}

        for line in posted_lines:
            if not hasattr(line, "ledger_account") or not line.ledger_account:
                continue
            acct = line.ledger_account
            grp_type = acct.account_group.group_type if hasattr(acct, "account_group") else ""
            net = _d(line.credit_amount) - _d(line.debit_amount)

            key = acct.account_name if hasattr(acct, "account_name") else str(acct)
            if grp_type in ("INCOME", "REVENUE"):
                income_rows[key] = income_rows.get(key, 0) + net
            elif grp_type in ("EXPENSE", "COST"):
                expense_rows[key] = expense_rows.get(key, 0) - net  # expenses are debits

        income_rows_list = [{"account": k, "amount": round(v, 2)}
                            for k, v in sorted(income_rows.items(), key=lambda x: -x[1])]
        expense_rows_list = [{"account": k, "amount": round(v, 2)}
                             for k, v in sorted(expense_rows.items(), key=lambda x: -x[1])]

        total_income = round(sum(r["amount"] for r in income_rows_list), 2)
        total_expenses = round(sum(r["amount"] for r in expense_rows_list), 2)
        net_profit = round(total_income - total_expenses, 2)

        result = {
            "report": "Profit & Loss",
            "plant": plant.code,
            "period": f"{from_date} to {to_date}",
            "total_income": total_income,
            "total_expenses": total_expenses,
            "net_profit": net_profit,
            "income_rows": income_rows_list,
            "expense_rows": expense_rows_list,
            "row_count": len(income_rows_list) + len(expense_rows_list),
        }
        _finish_execution(execution, result["row_count"])
        _log_export(user, "accounts_pl", plant)
        return result
    except Exception as e:
        _finish_execution(execution, 0, error=str(e))
        raise


# ═══════════════════════════════════════════════════════════════════
# REPORT 7 — GSTR RECONCILIATION
# ═══════════════════════════════════════════════════════════════════

def gstr_reconciliation_report(plant, month: int, year: int, user=None) -> dict:
    """
    GSTR-2B vs Purchase Register reconciliation diff.
    Flags: matched, unmatched in 2B only, unmatched in PR only, amount mismatch.
    """
    execution = _start_execution("gstr_reconciliation", plant, user,
                                  {"month": month, "year": year}, "JSON")
    try:
        from apps.webtel.models import GSTR2BRecord
        from apps.purchase.models import MRR, MRRLine

        # GSTR-2B records
        gstr2b = list(
            GSTR2BRecord.objects.filter(
                plant=plant, return_period__startswith=f"{year}{month:02d}"
            ).values("supplier_gstin", "invoice_number", "invoice_date",
                     "taxable_value", "igst", "cgst", "sgst", "total_tax")
        )
        gstr2b_map = {(r["supplier_gstin"], r["invoice_number"]): r for r in gstr2b}

        # Purchase register (MRR lines)
        mrrs = list(
            MRR.objects.filter(
                plant=plant,
                mrr_date__year=year, mrr_date__month=month,
                status__in=("APPROVED", "QC_PASSED"),
            ).select_related("vendor")
        )
        pr_map = {}
        for mrr in mrrs:
            gstin = mrr.vendor.gstin if hasattr(mrr.vendor, "gstin") else ""
            inv_no = getattr(mrr, "vendor_invoice_number", mrr.mrr_number)
            key = (gstin, inv_no)
            pr_map[key] = {
                "supplier_gstin": gstin,
                "invoice_number": inv_no,
                "mrr_number": mrr.mrr_number,
                "vendor_name": mrr.vendor.vendor_name,
                "taxable_value": _d(getattr(mrr, "taxable_value", 0)),
                "total_tax": _d(getattr(mrr, "total_tax", 0)),
            }

        rows = []
        all_keys = set(gstr2b_map.keys()) | set(pr_map.keys())

        for key in all_keys:
            in_2b = key in gstr2b_map
            in_pr = key in pr_map
            status = "MATCHED" if (in_2b and in_pr) else \
                     "IN_2B_ONLY" if in_2b else "IN_PR_ONLY"

            row = {
                "supplier_gstin": key[0],
                "invoice_number": key[1],
                "status": status,
                "gstr2b_value": _d(gstr2b_map[key]["taxable_value"]) if in_2b else 0,
                "pr_value": pr_map[key]["taxable_value"] if in_pr else 0,
                "vendor_name": pr_map[key]["vendor_name"] if in_pr else "",
            }
            if status == "MATCHED":
                diff = abs(row["gstr2b_value"] - row["pr_value"])
                if diff > 1:
                    row["status"] = "AMOUNT_MISMATCH"
                    row["diff"] = round(diff, 2)
            rows.append(row)

        matched = sum(1 for r in rows if r["status"] == "MATCHED")
        result = {
            "report": "GSTR-2B Reconciliation",
            "plant": plant.code,
            "period": f"{year}-{month:02d}",
            "total_2b_records": len(gstr2b),
            "total_pr_records": len(pr_map),
            "matched": matched,
            "mismatches": len(rows) - matched,
            "row_count": len(rows),
            "rows": rows,
        }
        _finish_execution(execution, len(rows))
        _log_export(user, "gstr_reconciliation", plant)
        return result
    except Exception as e:
        _finish_execution(execution, 0, error=str(e))
        raise


# ═══════════════════════════════════════════════════════════════════
# EXPORT HELPERS
# ═══════════════════════════════════════════════════════════════════

def export_to_excel(report_data: dict, sheet_name: str = "Report") -> bytes:
    """
    Convert any report dict → Excel (.xlsx) bytes.
    Handles both flat rows lists and nested structures.
    Uses openpyxl.
    """
    try:
        import openpyxl
        from openpyxl.styles import Font, PatternFill, Alignment
        from openpyxl.utils import get_column_letter
    except ImportError:
        raise ImportError("openpyxl required: pip install openpyxl")

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = sheet_name[:31]

    # ─── Title block ──────────────────────────────────────────────
    title_font = Font(bold=True, size=14)
    header_font = Font(bold=True, color="FFFFFF")
    header_fill = PatternFill("solid", fgColor="1F4E79")

    ws["A1"] = report_data.get("report", "Report")
    ws["A1"].font = title_font
    ws["A2"] = f"Plant: {report_data.get('plant', '')}   Period: {report_data.get('period', '')}"
    ws["A3"] = f"Generated: {datetime.now():%Y-%m-%d %H:%M:%S}"
    ws.append([])  # blank row

    # ─── Main rows ────────────────────────────────────────────────
    # Try common row key names
    rows_key = next(
        (k for k in ["rows", "work_order_rows", "income_rows", "summary_rows"]
         if k in report_data and isinstance(report_data[k], list) and report_data[k]),
        None,
    )

    if rows_key:
        rows = report_data[rows_key]
        if rows:
            headers = list(rows[0].keys())
            # Write header
            for col, h in enumerate(headers, start=1):
                cell = ws.cell(row=ws.max_row + 1, column=col,
                               value=str(h).replace("_", " ").title())
                cell.font = header_font
                cell.fill = header_fill
                cell.alignment = Alignment(horizontal="center")

            # Write data rows
            for row in rows:
                ws.append([
                    v if not isinstance(v, (dict, list, set)) else str(v)
                    for v in row.values()
                ])

    # ─── Summary block ────────────────────────────────────────────
    ws.append([])
    summary_keys = [k for k in report_data
                    if k not in ("rows", "work_order_rows", "income_rows",
                                 "expense_rows", "summary_rows", "ncr_trend",
                                 "top_ncr_items", "work_center_rows")
                    and not isinstance(report_data[k], (list, dict))]
    for k in summary_keys:
        ws.append([str(k).replace("_", " ").title(), report_data[k]])

    # ─── Auto column width ────────────────────────────────────────
    for col in ws.columns:
        max_len = max((len(str(cell.value or "")) for cell in col), default=8)
        ws.column_dimensions[get_column_letter(col[0].column)].width = min(max_len + 4, 50)

    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def export_to_pdf(report_data: dict) -> bytes:
    """
    Convert report dict → PDF bytes using reportlab.
    """
    try:
        from reportlab.lib.pagesizes import A4, landscape
        from reportlab.lib.styles import getSampleStyleSheet
        from reportlab.lib import colors
        from reportlab.platypus import (
            SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
        )
        from reportlab.lib.units import cm
    except ImportError:
        raise ImportError("reportlab required: pip install reportlab")

    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=landscape(A4),
                            leftMargin=1*cm, rightMargin=1*cm,
                            topMargin=1.5*cm, bottomMargin=1.5*cm)
    styles = getSampleStyleSheet()
    elements = []

    # Title
    elements.append(Paragraph(report_data.get("report", "Report"), styles["h1"]))
    elements.append(Paragraph(
        f"Plant: {report_data.get('plant', '')} | Period: {report_data.get('period', '')} | "
        f"Generated: {datetime.now():%Y-%m-%d %H:%M}",
        styles["Normal"]
    ))
    elements.append(Spacer(1, 0.4*cm))

    # Table
    rows_key = next(
        (k for k in ["rows", "work_order_rows", "income_rows", "summary_rows"]
         if k in report_data and isinstance(report_data[k], list) and report_data[k]),
        None,
    )

    if rows_key:
        rows = report_data[rows_key]
        if rows:
            headers = [str(h).replace("_", " ").title() for h in rows[0].keys()]
            table_data = [headers]
            for row in rows:
                table_data.append([
                    str(v)[:60] if isinstance(v, (dict, list)) else str(v or "")
                    for v in row.values()
                ])

            col_count = len(headers)
            col_width = (landscape(A4)[0] - 2*cm) / col_count
            tbl = Table(table_data, colWidths=[col_width] * col_count, repeatRows=1)
            tbl.setStyle(TableStyle([
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1F4E79")),
                ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                ("FONTSIZE", (0, 0), (-1, -1), 7),
                ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#EEF2F7")]),
                ("GRID", (0, 0), (-1, -1), 0.3, colors.HexColor("#CCCCCC")),
                ("ALIGN", (0, 0), (-1, -1), "LEFT"),
                ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                ("TOPPADDING", (0, 0), (-1, -1), 3),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
            ]))
            elements.append(tbl)

    doc.build(elements)
    return buf.getvalue()


def export_to_csv(report_data: dict) -> str:
    """Convert report rows to CSV string."""
    import csv
    rows_key = next(
        (k for k in ["rows", "work_order_rows", "income_rows", "summary_rows"]
         if k in report_data and isinstance(report_data[k], list) and report_data[k]),
        None,
    )
    if not rows_key:
        return ""

    rows = report_data[rows_key]
    if not rows:
        return ""

    buf = io.StringIO()
    writer = csv.DictWriter(buf, fieldnames=list(rows[0].keys()))
    writer.writeheader()
    for row in rows:
        writer.writerow({k: (str(v) if isinstance(v, (dict, list, set)) else v)
                        for k, v in row.items()})
    return buf.getvalue()


# ═══════════════════════════════════════════════════════════════════
# SCHEDULER
# ═══════════════════════════════════════════════════════════════════

def schedule_report(plant, report_slug: str, name: str, frequency: str,
                    output_format: str, recipients: list, filters: dict,
                    run_at_hour: int = 7, run_at_minute: int = 0,
                    day_of_week: int = None, day_of_month: int = None,
                    user=None):
    """
    Create or update a ScheduledReport record.
    Sets celery_task_id to a deterministic name for Celery Beat management.
    """
    from apps.reports.models import ReportDefinition, ScheduledReport
    from django.db import transaction

    rdef = ReportDefinition.objects.get(slug=report_slug)
    task_id = f"scheduled_report_{plant.code}_{report_slug}_{name}".lower().replace(" ", "_")

    with transaction.atomic():
        sr, created = ScheduledReport.objects.update_or_create(
            plant=plant, report=rdef, name=name,
            defaults={
                "frequency": frequency,
                "output_format": output_format,
                "recipients": recipients,
                "filters": filters,
                "run_at_hour": run_at_hour,
                "run_at_minute": run_at_minute,
                "day_of_week": day_of_week,
                "day_of_month": day_of_month,
                "celery_task_id": task_id,
                "is_active": True,
                "created_by": user,
            },
        )
    return sr


# ═══════════════════════════════════════════════════════════════════
# DISPATCHER
# ═══════════════════════════════════════════════════════════════════

REPORT_REGISTRY = {
    "inventory_valuation": inventory_valuation_report,
    "purchase_analysis": purchase_analysis_report,
    "sales_analysis": sales_analysis_report,
    "production_efficiency": production_efficiency_report,
    "quality_summary": quality_summary_report,
    "accounts_pl": accounts_pl_report,
    "gstr_reconciliation": gstr_reconciliation_report,
}


def run_report(report_slug: str, plant, output_format: str = "JSON",
               user=None, **kwargs) -> dict | bytes | str:
    """
    Dispatcher: run any registered report, optionally convert to XLSX/PDF/CSV.
    Returns dict (JSON), bytes (XLSX/PDF), or str (CSV).
    """
    if report_slug not in REPORT_REGISTRY:
        raise ValueError(f"Unknown report slug: '{report_slug}'. "
                         f"Available: {list(REPORT_REGISTRY.keys())}")

    fn = REPORT_REGISTRY[report_slug]
    data = fn(plant=plant, user=user, **kwargs)

    if output_format == "XLSX":
        return export_to_excel(data, sheet_name=data.get("report", report_slug)[:31])
    elif output_format == "PDF":
        return export_to_pdf(data)
    elif output_format == "CSV":
        return export_to_csv(data)
    return data


def seed_report_definitions():
    """
    Idempotent seed: create system ReportDefinition records.
    Call from a management command or data migration.
    """
    from apps.reports.models import ReportDefinition
    DEFINITIONS = [
        {"slug": "inventory_valuation", "name": "Inventory Valuation",
         "category": "INVENTORY", "supported_formats": ["JSON", "XLSX", "PDF", "CSV"],
         "parameter_schema": {"as_of_date": "date", "warehouse_id": "int?"}},
        {"slug": "purchase_analysis", "name": "Purchase Analysis",
         "category": "PURCHASE", "supported_formats": ["JSON", "XLSX", "PDF", "CSV"],
         "parameter_schema": {"from_date": "date", "to_date": "date", "vendor_id": "int?"}},
        {"slug": "sales_analysis", "name": "Sales Analysis",
         "category": "SALES", "supported_formats": ["JSON", "XLSX", "PDF", "CSV"],
         "parameter_schema": {"from_date": "date", "to_date": "date",
                              "customer_id": "int?", "group_by": "str"}},
        {"slug": "production_efficiency", "name": "Production Efficiency",
         "category": "PRODUCTION", "supported_formats": ["JSON", "XLSX", "PDF"],
         "parameter_schema": {"from_date": "date", "to_date": "date"}},
        {"slug": "quality_summary", "name": "Quality Summary",
         "category": "QUALITY", "supported_formats": ["JSON", "XLSX", "PDF"],
         "parameter_schema": {"from_date": "date", "to_date": "date"}},
        {"slug": "accounts_pl", "name": "Profit & Loss",
         "category": "ACCOUNTS", "supported_formats": ["JSON", "XLSX", "PDF"],
         "parameter_schema": {"from_date": "date", "to_date": "date"}},
        {"slug": "gstr_reconciliation", "name": "GSTR-2B Reconciliation",
         "category": "GST", "supported_formats": ["JSON", "XLSX"],
         "parameter_schema": {"month": "int", "year": "int"}},
    ]
    for d in DEFINITIONS:
        ReportDefinition.objects.update_or_create(
            slug=d["slug"],
            defaults={
                "name": d["name"],
                "category": d["category"],
                "supported_formats": d["supported_formats"],
                "default_format": "JSON",
                "parameter_schema": d["parameter_schema"],
                "is_active": True,
                "is_system": True,
            },
        )
