"""
Stores Module ViewSets — Section 4
"""
from rest_framework import viewsets, status, filters
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django_filters.rest_framework import DjangoFilterBackend
from django.utils import timezone

from apps.stores.models import (
    Warehouse, BinLocation, InventoryLot, InventoryTransaction,
    StockIssue, StockReturn, PhysicalVerification, PVLine,
    StockTransfer, MinMaxAlert,
)
from apps.stores.api.serializers import (
    WarehouseSerializer, BinLocationSerializer,
    InventoryLotListSerializer, InventoryLotDetailSerializer, AssignBinSerializer,
    InventoryTransactionSerializer,
    StockIssueSerializer, StockIssueCreateSerializer,
    StockReturnSerializer, StockReturnCreateSerializer,
    PhysicalVerificationSerializer, PVScanSerializer,
    StockTransferSerializer,
    MinMaxAlertSerializer,
)
from apps.stores import services


# ─── Warehouse ──────────────────────────────────────────────────────

class WarehouseViewSet(viewsets.ModelViewSet):
    serializer_class = WarehouseSerializer
    permission_classes = [IsAuthenticated]
    filter_backends = [filters.SearchFilter, DjangoFilterBackend]
    search_fields = ["code", "name"]
    filterset_fields = ["warehouse_type", "is_active"]  # "plant" removed to prevent bypass

    def get_queryset(self):
        qs = Warehouse.objects.select_related("plant").all()
        plant = getattr(self.request, "plant", None)
        if plant:
            qs = qs.filter(plant=plant)
        return qs

    @action(detail=True, methods=["get"])
    def bins(self, request, pk=None):
        """List all bin locations in this warehouse."""
        warehouse = self.get_object()
        bins = warehouse.bins.filter(is_active=True)
        return Response(BinLocationSerializer(bins, many=True).data)

    @action(detail=True, methods=["get"])
    def stock_summary(self, request, pk=None):
        """Current stock summary for this warehouse."""
        warehouse = self.get_object()
        plant = request.user.plant  # Set by middleware
        data = services.get_stock_summary(plant=plant, warehouse=warehouse)
        return Response(list(data))

    @action(detail=True, methods=["get"])
    def location_report(self, request, pk=None):
        """All lots and their bin locations."""
        warehouse = self.get_object()
        lots = services.get_location_report(warehouse)
        return Response(InventoryLotListSerializer(lots, many=True).data)


# ─── BinLocation ────────────────────────────────────────────────────

class BinLocationViewSet(viewsets.ModelViewSet):
    serializer_class = BinLocationSerializer
    permission_classes = [IsAuthenticated]
    filter_backends = [filters.SearchFilter, DjangoFilterBackend]
    search_fields = ["code", "description"]
    filterset_fields = ["warehouse", "is_active"]

    def get_queryset(self):
        qs = BinLocation.objects.select_related("warehouse").all()
        plant = getattr(self.request, "plant", None)
        if plant:
            qs = qs.filter(warehouse__plant=plant)
        return qs

    @action(detail=True, methods=["get"])
    def generate_qr(self, request, pk=None):
        """Generate / regenerate QR code image for this bin."""
        bin_loc = self.get_object()
        qr_b64 = services.generate_bin_qr(bin_loc)
        return Response({"qr_image_base64": qr_b64, "qr_data": bin_loc.qr_code_data})

    @action(detail=True, methods=["get"])
    def current_lots(self, request, pk=None):
        """All available lots currently in this bin."""
        bin_loc = self.get_object()
        lots = InventoryLot.objects.filter(
            bin_location=bin_loc,
            status=InventoryLot.LotStatus.AVAILABLE,
            is_active=True,
        ).select_related("item", "supplier")
        return Response(InventoryLotListSerializer(lots, many=True).data)


# ─── InventoryLot ────────────────────────────────────────────────────

class InventoryLotViewSet(viewsets.ReadOnlyModelViewSet):
    """
    Lots are created automatically by the Purchase module (MRR).
    Read-only here; mutations via issue/return/transfer.
    """
    permission_classes = [IsAuthenticated]
    filter_backends = [filters.SearchFilter, filters.OrderingFilter, DjangoFilterBackend]
    search_fields = ["lot_number", "roll_number", "item__code", "item__name", "batch_number"]
    filterset_fields = ["item", "warehouse", "bin_location", "status", "qc_status",
                        "supplier", "is_bit_roll", "plant", "customer_ref", "so_ref"]
    ordering_fields = ["fifo_date", "receipt_date", "current_qty", "age_days"]
    ordering = ["fifo_date"]

    def get_queryset(self):
        plant = getattr(self.request, "plant", None)
        qs = InventoryLot.objects.select_related(
            "item", "warehouse", "bin_location", "supplier", "uom"
        ).filter(is_active=True)
        if plant:
            qs = qs.filter(plant=plant)
        return qs

    def get_serializer_class(self):
        if self.action == "retrieve":
            return InventoryLotDetailSerializer
        return InventoryLotListSerializer

    @action(detail=True, methods=["post"])
    def assign_bin(self, request, pk=None):
        """
        Forklift operator scans bin QR and assigns lot to bin.
        POST { bin_location_id: X, remarks: "" }
        """
        lot = self.get_object()
        ser = AssignBinSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        try:
            from apps.stores.models import BinLocation
            bin_loc = BinLocation.objects.get(pk=ser.validated_data["bin_location_id"])
            services.assign_bin_to_lot(lot, bin_loc, request.user,
                                        ser.validated_data.get("remarks", ""))
            return Response(InventoryLotDetailSerializer(lot).data)
        except BinLocation.DoesNotExist:
            return Response({"error": "Bin location not found."}, status=404)

    @action(detail=True, methods=["get"])
    def qr_label(self, request, pk=None):
        """Get QR label image (base64 PNG) for printing."""
        lot = self.get_object()
        qr_b64 = services.generate_lot_qr(lot)
        return Response({
            "qr_image_base64": qr_b64,
            "qr_data": lot.qr_code_data,
            "lot_number": lot.lot_number,
            "item_code": lot.item.code,
            "item_name": lot.item.name,
            "supplier": lot.supplier.name if lot.supplier else "",
            "receipt_date": lot.receipt_date,
            "qty": lot.current_qty,
            "deckle": lot.deckle_mm,
            "gsm": lot.gsm,
            "bf": lot.bf,
        })

    @action(detail=True, methods=["get"])
    def transactions(self, request, pk=None):
        """Full transaction history for this lot."""
        lot = self.get_object()
        txns = lot.transactions.all().order_by("-created_at")
        return Response(InventoryTransactionSerializer(txns, many=True).data)

    @action(detail=False, methods=["get"])
    def bit_rolls(self, request):
        """All active bit-roll lots."""
        plant = request.user.plant
        lots = services.get_bit_roll_report(plant)
        return Response(InventoryLotListSerializer(lots, many=True).data)

    @action(detail=False, methods=["get"])
    def ageing(self, request):
        """Lots older than N days (default 90)."""
        plant = request.user.plant
        days  = int(request.query_params.get("days", 90))
        warehouse_id = request.query_params.get("warehouse")
        warehouse = None
        if warehouse_id:
            from apps.stores.models import Warehouse
            warehouse = Warehouse.objects.filter(pk=warehouse_id).first()
        lots = services.get_lot_ageing_report(plant, warehouse, days)
        return Response(InventoryLotListSerializer(lots, many=True).data)

    @action(detail=False, methods=["get"])
    def stock_summary(self, request):
        """Stock summary per item across all warehouses."""
        plant = request.user.plant
        data  = services.get_stock_summary(plant)
        return Response(list(data))

    @action(detail=False, methods=["get"])
    def scan(self, request):
        """
        QR scan lookup — pass ?qr_data=<raw> to resolve a lot from QR.
        Used by Android app.
        """
        import json
        qr_raw = request.query_params.get("qr_data", "")
        try:
            qr_data = json.loads(qr_raw)
            lot_uuid = qr_data.get("uuid")
            lot = InventoryLot.objects.get(uuid=lot_uuid)
            return Response(InventoryLotDetailSerializer(lot).data)
        except Exception:
            return Response({"error": "Lot not found for this QR code."}, status=404)

    @action(detail=False, methods=["get"])
    def below_minimum(self, request):
        """Items below minimum stock levels."""
        alerts = MinMaxAlert.objects.filter(
            plant=request.user.plant,
            alert_type__in=[MinMaxAlert.AlertType.BELOW_MIN, MinMaxAlert.AlertType.ZERO_STOCK],
            is_resolved=False,
        ).select_related("item", "warehouse")
        return Response(MinMaxAlertSerializer(alerts, many=True).data)

    @action(detail=True, methods=["get"], url_path="fifo-check")
    def fifo_check(self, request, pk=None):
        """
        Check if issuing this lot violates FIFO.
        GET /api/stores/inventory/{id}/fifo-check/?item={item_id}&plant={plant_id}
        Returns: {violated: bool, older_lot_number: str|null, older_lot_date: str|null}
        """
        lot = self.get_object()
        item_id = request.query_params.get("item")
        plant_id = request.query_params.get("plant")

        if not item_id:
            return Response({"error": "item query param required"}, status=400)

        try:
            from apps.masters.models import Item
            item = Item.objects.get(pk=item_id)
        except Exception:
            return Response({"error": "Item not found"}, status=404)

        if plant_id:
            try:
                from apps.core.models import Plant
                plant = Plant.objects.get(pk=plant_id)
            except Exception:
                return Response({"error": "Plant not found"}, status=404)
        else:
            plant = request.user.plant

        result = services.check_fifo_violation(item, plant, lot)
        return Response({
            "violated": result["violated"],
            "older_lot_number": result["older_lot_number"],
            "older_lot_date": str(result["older_lot_date"]) if result["older_lot_date"] else None,
        })

    # ─── Task 16: Print Tag PDF ─────────────────────────────────────

    @action(detail=True, methods=["get"], url_path="print-tag")
    def print_tag(self, request, pk=None):
        """
        Generate a printable PDF tag for this lot.
        ?size=A4           → half-A4 layout (2 per page), large QR
        ?size=LABEL_60x70  → 60×70mm label layout (4 per A4, or single)
        GET /api/v1/stores/inventory/{pk}/print-tag/?size=A4
        """
        from django.http import HttpResponse
        lot = self.get_object()
        size = request.query_params.get("size", "A4").upper()
        if size not in ("A4", "LABEL_60X70"):
            size = "A4"
        try:
            pdf_bytes = services.generate_lot_print_pdf([lot], size)
        except Exception as exc:
            return Response({"error": f"PDF generation failed: {exc}"}, status=500)
        return HttpResponse(
            pdf_bytes,
            content_type="application/pdf",
            headers={
                "Content-Disposition": (
                    f'attachment; filename="Tag_{lot.lot_number}_{size}.pdf"'
                )
            },
        )

    # ─── Task 16: Update Weight ─────────────────────────────────────

    @action(detail=True, methods=["post"], url_path="update-weight")
    def update_weight(self, request, pk=None):
        """
        Update lot weight/quantity and re-generate QR.
        POST { new_weight: float, reason: str }
        Returns { qr_base64: str, new_weight: float }
        """
        lot = self.get_object()
        new_weight = request.data.get("new_weight")
        reason = request.data.get("reason", "Weight update")

        if new_weight is None:
            return Response({"error": "new_weight is required."}, status=400)

        try:
            from decimal import Decimal
            new_weight_dec = Decimal(str(new_weight))
            if new_weight_dec < 0:
                return Response({"error": "Weight cannot be negative."}, status=400)
        except Exception:
            return Response({"error": "Invalid weight value."}, status=400)

        from apps.stores.models import InventoryTransaction
        qty_before = lot.current_qty
        lot.current_qty = new_weight_dec
        lot.gross_weight_kg = new_weight_dec
        lot.save(update_fields=["current_qty", "gross_weight_kg"])

        InventoryTransaction.objects.create(
            lot=lot,
            transaction_type=InventoryTransaction.TransactionType.ADJUSTMENT,
            quantity=new_weight_dec - qty_before,
            qty_before=qty_before,
            qty_after=new_weight_dec,
            remarks=reason,
            done_by=request.user,
        )

        qr_b64 = services.generate_lot_qr(lot)
        return Response({
            "qr_base64": qr_b64,
            "new_weight": float(new_weight_dec),
            "lot_number": lot.lot_number,
        })

    # ─── Task 16: Batch Print ───────────────────────────────────────

    @action(detail=False, methods=["post"], url_path="batch-print")
    def batch_print(self, request):
        """
        Generate a single merged PDF for multiple lots.
        POST { lot_ids: [uuid, ...], size: 'A4'|'LABEL_60x70' }
        GET /api/v1/stores/inventory/batch-print/
        """
        from django.http import HttpResponse
        lot_ids = request.data.get("lot_ids", [])
        size = request.data.get("size", "A4").upper()

        if not lot_ids:
            return Response({"error": "lot_ids is required."}, status=400)
        if size not in ("A4", "LABEL_60X70"):
            size = "A4"

        lots = list(
            InventoryLot.objects.select_related(
                "item", "warehouse", "bin_location", "supplier", "uom"
            ).filter(uuid__in=lot_ids, is_active=True)
        )
        if not lots:
            return Response({"error": "No matching lots found."}, status=404)

        try:
            pdf_bytes = services.generate_lot_print_pdf(lots, size)
        except Exception as exc:
            return Response({"error": f"PDF generation failed: {exc}"}, status=500)

        return HttpResponse(
            pdf_bytes,
            content_type="application/pdf",
            headers={
                "Content-Disposition": (
                    f'attachment; filename="BatchTags_{len(lots)}lots_{size}.pdf"'
                )
            },
        )


# ─── Stock Issue ─────────────────────────────────────────────────────

class StockIssueViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    filter_backends = [filters.SearchFilter, DjangoFilterBackend, filters.OrderingFilter]
    search_fields = ["issue_number", "job_card_number"]
    filterset_fields = ["status", "issue_type", "plant", "from_warehouse", "issued_to_dept"]
    ordering = ["-issue_date"]

    def get_queryset(self):
        return StockIssue.objects.select_related(
            "from_warehouse", "issued_by", "issued_to_dept"
        ).prefetch_related("lines__lot", "lines__item").all()

    def get_serializer_class(self):
        if self.action == "create":
            return StockIssueCreateSerializer
        return StockIssueSerializer

    def create(self, request, *args, **kwargs):
        ser = StockIssueCreateSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        plant = request.user.plant

        # FIFO enforcement check — performed before creating the issue
        fifo_override = request.headers.get('X-FIFO-Override', '').lower() == 'true'
        override_reason = request.data.get('override_reason', '')

        if plant.fifo_enforcement != 'OFF':
            lines_data = ser.validated_data.get('lines', [])
            warnings = []
            for line_data in lines_data:
                if line_data.get('lot_id'):
                    try:
                        from apps.masters.models import Item
                        item = Item.objects.get(pk=line_data['item_id'])
                        lot = InventoryLot.objects.get(pk=line_data['lot_id'])
                        fifo_result = services.check_fifo_violation(item, plant, lot)
                        if fifo_result['violated']:
                            older_num = fifo_result['older_lot_number']
                            older_date = fifo_result['older_lot_date']
                            msg = (
                                f"FIFO violation: older lot {older_num} "
                                f"(date {older_date}) must be issued first."
                            )
                            if plant.fifo_enforcement == 'HARD':
                                from rest_framework.exceptions import ValidationError
                                raise ValidationError({'lot': msg})
                            else:  # WARN
                                if not fifo_override:
                                    return Response(
                                        {
                                            'fifo_warning': True,
                                            'message': msg,
                                            'older_lot_number': older_num,
                                            'older_lot_date': str(older_date),
                                            'requires_override': True,
                                        },
                                        status=status.HTTP_200_OK,
                                    )
                                else:
                                    warnings.append({
                                        'lot_id': str(line_data['lot_id']),
                                        'message': msg,
                                    })
                    except (InventoryLot.DoesNotExist,):
                        pass

        try:
            validated = ser.validated_data
            lines_data = validated.pop('lines')
            issue = services.create_stock_issue(
                data=validated,
                lines_data=lines_data,
                user=request.user,
                plant=plant,
            )

            # Log FIFO override to AuditLog if applicable
            if fifo_override and override_reason:
                from apps.core.models import AuditLog
                AuditLog.objects.create(
                    user=request.user,
                    action='FIFO_OVERRIDE',
                    module='stores',
                    resource='StockIssue',
                    resource_id=None,
                    notes=f"FIFO Override — Issue: {issue.issue_number} | Reason: {override_reason}",
                    new_values={
                        'action': 'FIFO_OVERRIDE',
                        'reason': override_reason,
                        'issue_number': issue.issue_number,
                        'issue_id': str(issue.pk),
                    },
                )

            response_data = StockIssueSerializer(issue).data
            if 'warnings' in dir() and warnings:
                response_data['fifo_warnings'] = warnings
            return Response(response_data, status=status.HTTP_201_CREATED)
        except ValueError as e:
            return Response({'error': str(e)}, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=False, methods=["get"])
    def pending_returns(self, request):
        """Issues that have been made but have unreturned quantities."""
        issues = StockIssue.objects.filter(
            plant=request.user.plant,
            status__in=[StockIssue.IssueStatus.ISSUED,
                        StockIssue.IssueStatus.PARTIALLY_RETURNED],
        )
        return Response(StockIssueSerializer(issues, many=True).data)


# ─── Stock Return ─────────────────────────────────────────────────────

class StockReturnViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    filter_backends = [filters.SearchFilter, DjangoFilterBackend]
    search_fields = ["return_number"]
    filterset_fields = ["status", "plant", "to_warehouse"]
    ordering = ["-return_date"]

    def get_queryset(self):
        return StockReturn.objects.select_related(
            "to_warehouse", "returned_by", "received_by"
        ).prefetch_related("lines__original_lot", "lines__bit_roll_lot", "lines__item").all()

    def get_serializer_class(self):
        if self.action == "create":
            return StockReturnCreateSerializer
        return StockReturnSerializer

    def create(self, request, *args, **kwargs):
        ser = StockReturnCreateSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        plant = request.user.plant

        try:
            ret = services.create_stock_return(
                data=ser.validated_data,
                lines_data=ser.validated_data.pop("lines"),
                user=request.user,
                plant=plant,
            )
            return Response(StockReturnSerializer(ret).data, status=status.HTTP_201_CREATED)
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)


# ─── Physical Verification ────────────────────────────────────────────

class PhysicalVerificationViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    filter_backends = [DjangoFilterBackend, filters.OrderingFilter]
    filterset_fields = ["status", "pv_type", "plant", "warehouse"]
    ordering = ["-planned_date"]

    def get_queryset(self):
        return PhysicalVerification.objects.select_related(
            "warehouse", "approved_by"
        ).prefetch_related("lines", "conducted_by").all()

    def get_serializer_class(self):
        return PhysicalVerificationSerializer

    @action(detail=True, methods=["post"])
    def start(self, request, pk=None):
        """Start PV — snapshots current book quantities."""
        pv = self.get_object()
        try:
            services.start_physical_verification(pv, request.user)
            return Response(PhysicalVerificationSerializer(pv).data)
        except ValueError as e:
            return Response({"error": str(e)}, status=400)

    @action(detail=True, methods=["post"])
    def scan(self, request, pk=None):
        """Record a QR scan during PV. POST { qr_data_raw, physical_qty }"""
        pv  = self.get_object()
        ser = PVScanSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        try:
            from decimal import Decimal
            pv_line = services.record_pv_scan(
                pv=pv,
                qr_data_raw=ser.validated_data["qr_data_raw"],
                physical_qty=ser.validated_data["physical_qty"],
                user=request.user,
            )
            if pv_line:
                return Response({"status": "scanned", "variance_type": pv_line.variance_type,
                                 "variance_qty": pv_line.variance_qty})
            return Response({"status": "extra_lot_recorded"})
        except ValueError as e:
            return Response({"error": str(e)}, status=400)

    @action(detail=True, methods=["post"])
    def complete(self, request, pk=None):
        """Complete PV — calculates summary counts."""
        pv = self.get_object()
        try:
            services.complete_physical_verification(pv, request.user)
            return Response(PhysicalVerificationSerializer(pv).data)
        except ValueError as e:
            return Response({"error": str(e)}, status=400)

    @action(detail=True, methods=["post"])
    def post_adjustments(self, request, pk=None):
        """Post inventory adjustments after PV approval."""
        pv = self.get_object()
        try:
            services.post_pv_adjustments(pv, request.user)
            return Response({"status": "adjustments_posted",
                             "message": "Inventory updated per physical verification."})
        except ValueError as e:
            return Response({"error": str(e)}, status=400)

    @action(detail=True, methods=["get"])
    def variance_report(self, request, pk=None):
        """Only show lines with variances (short/excess/missing/extra)."""
        pv = self.get_object()
        lines = pv.lines.exclude(variance_type=PVLine.VarianceType.MATCHED)
        from apps.stores.api.serializers import PVLineSerializer
        return Response(PVLineSerializer(lines, many=True).data)

    @action(detail=True, methods=["get"])
    def pending_scans(self, request, pk=None):
        """Lines not yet scanned (still MISSING status)."""
        pv = self.get_object()
        lines = pv.lines.filter(variance_type=PVLine.VarianceType.MISSING)
        from apps.stores.api.serializers import PVLineSerializer
        return Response(PVLineSerializer(lines, many=True).data)


# ─── Stock Transfer ───────────────────────────────────────────────────

class StockTransferViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    filter_backends = [filters.SearchFilter, DjangoFilterBackend]
    search_fields = ["transfer_number"]
    filterset_fields = ["status", "plant", "from_warehouse", "to_warehouse"]
    ordering = ["-transfer_date"]

    def get_queryset(self):
        return StockTransfer.objects.select_related(
            "from_warehouse", "to_warehouse", "transferred_by"
        ).prefetch_related("lines__lot", "lines__item").all()

    def get_serializer_class(self):
        return StockTransferSerializer

    def create(self, request, *args, **kwargs):
        plant = request.user.plant
        lines_data = request.data.pop("lines", [])
        try:
            transfer = services.create_stock_transfer(
                data=request.data,
                lines_data=lines_data,
                user=request.user,
                plant=plant,
            )
            return Response(StockTransferSerializer(transfer).data, status=201)
        except Exception as e:
            return Response({"error": str(e)}, status=400)


# ─── MinMax Alerts ───────────────────────────────────────────────────

class MinMaxAlertViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = MinMaxAlertSerializer
    permission_classes = [IsAuthenticated]
    filter_backends = [DjangoFilterBackend]
    filterset_fields = ["alert_type", "is_resolved", "plant", "warehouse", "item"]

    def get_queryset(self):
        return MinMaxAlert.objects.select_related("item", "warehouse", "plant").all()

    @action(detail=True, methods=["post"])
    def resolve(self, request, pk=None):
        """Manually mark an alert as resolved."""
        alert = self.get_object()
        alert.is_resolved  = True
        alert.resolved_at  = timezone.now()
        alert.save(update_fields=["is_resolved", "resolved_at"])
        return Response({"status": "resolved"})

    @action(detail=False, methods=["post"])
    def run_check(self, request):
        """Manually trigger min/max check (usually run by Celery beat)."""
        plant = request.user.plant
        count = services.check_and_create_minmax_alerts(plant)
        return Response({"alerts_created": count})


# ─── Inventory Transactions (read-only ledger) ───────────────────────

class InventoryTransactionViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = InventoryTransactionSerializer
    permission_classes = [IsAuthenticated]
    filter_backends = [DjangoFilterBackend, filters.OrderingFilter]
    filterset_fields = ["transaction_type", "lot", "reference_type"]
    ordering = ["-created_at"]

    def get_queryset(self):
        return InventoryTransaction.objects.select_related(
            "lot__item", "done_by", "from_location", "to_location"
        ).all()
