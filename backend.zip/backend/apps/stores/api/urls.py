"""
Stores Module URLs — Section 4
"""
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from apps.stores.api.viewsets import (
    WarehouseViewSet,
    BinLocationViewSet,
    InventoryLotViewSet,
    InventoryTransactionViewSet,
    StockIssueViewSet,
    StockReturnViewSet,
    PhysicalVerificationViewSet,
    StockTransferViewSet,
    MinMaxAlertViewSet,
)

router = DefaultRouter()
router.register("warehouses",       WarehouseViewSet,             basename="warehouse")
router.register("bin-locations",    BinLocationViewSet,           basename="bin-location")
router.register("lots",             InventoryLotViewSet,           basename="inventory-lot")
router.register("transactions",     InventoryTransactionViewSet,   basename="inventory-txn")
router.register("issues",           StockIssueViewSet,             basename="stock-issue")
router.register("returns",          StockReturnViewSet,            basename="stock-return")
router.register("physical-verifications", PhysicalVerificationViewSet, basename="pv")
router.register("transfers",        StockTransferViewSet,          basename="stock-transfer")
router.register("alerts",           MinMaxAlertViewSet,            basename="minmax-alert")

app_name = "stores"
urlpatterns = [
    path("", include(router.urls)),
]
