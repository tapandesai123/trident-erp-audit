"""
Stores Module Serializers — Section 4
"""
from decimal import Decimal
from rest_framework import serializers
from apps.stores.models import (
    Warehouse, BinLocation, InventoryLot, InventoryTransaction,
    StockIssue, StockIssueLine,
    StockReturn, StockReturnLine,
    PhysicalVerification, PVLine,
    StockTransfer, StockTransferLine,
    MinMaxAlert,
)


# ─── Warehouse ──────────────────────────────────────────────────────

class WarehouseSerializer(serializers.ModelSerializer):
    plant_name = serializers.CharField(source="plant.name", read_only=True)
    bins_count = serializers.SerializerMethodField()

    class Meta:
        model = Warehouse
        fields = [
            "id", "plant", "plant_name", "code", "name",
            "warehouse_type", "address", "is_active", "bins_count",
        ]

    def get_bins_count(self, obj):
        return obj.bins.filter(is_active=True).count()


# ─── BinLocation ────────────────────────────────────────────────────

class BinLocationSerializer(serializers.ModelSerializer):
    warehouse_code = serializers.CharField(source="warehouse.code", read_only=True)
    current_lots   = serializers.SerializerMethodField()

    class Meta:
        model = BinLocation
        fields = [
            "id", "warehouse", "warehouse_code", "code", "description",
            "qr_code_data", "capacity_units", "is_active", "current_lots",
        ]

    def get_current_lots(self, obj):
        return obj.lots.filter(
            status=InventoryLot.LotStatus.AVAILABLE
        ).count()


# ─── Inventory Lot ──────────────────────────────────────────────────

class InventoryLotListSerializer(serializers.ModelSerializer):
    """Lightweight for list views."""
    item_code      = serializers.CharField(source="item.code", read_only=True)
    item_name      = serializers.CharField(source="item.name", read_only=True)
    warehouse_code = serializers.CharField(source="warehouse.code", read_only=True)
    bin_code       = serializers.CharField(source="bin_location.code", read_only=True, default="")
    supplier_name  = serializers.CharField(source="supplier.name", read_only=True, default="")
    available_qty  = serializers.DecimalField(max_digits=15, decimal_places=3, read_only=True)
    age_days       = serializers.IntegerField(read_only=True)

    class Meta:
        model = InventoryLot
        fields = [
            "id", "uuid", "lot_number", "roll_number",
            "item_code", "item_name",
            "warehouse_code", "bin_code",
            "original_qty", "current_qty", "available_qty", "reserved_qty",
            "gross_weight_kg", "deckle_mm", "gsm", "bf",
            "supplier_name", "receipt_date", "fifo_date",
            "qc_status", "status", "is_bit_roll", "age_days",
        ]


class InventoryLotDetailSerializer(serializers.ModelSerializer):
    """Full detail."""
    item_code     = serializers.CharField(source="item.code", read_only=True)
    item_name     = serializers.CharField(source="item.name", read_only=True)
    supplier_name = serializers.CharField(source="supplier.name", read_only=True, default="")
    warehouse_code = serializers.CharField(source="warehouse.code", read_only=True)
    bin_code      = serializers.CharField(source="bin_location.code", read_only=True, default="")
    available_qty = serializers.DecimalField(max_digits=15, decimal_places=3, read_only=True)
    age_days      = serializers.IntegerField(read_only=True)
    customer_ref_name = serializers.SerializerMethodField()
    so_ref_number     = serializers.SerializerMethodField()

    def get_customer_ref_name(self, obj):
        return obj.customer_ref.name if obj.customer_ref else None

    def get_so_ref_number(self, obj):
        return obj.so_ref.so_number if obj.so_ref else None

    class Meta:
        model = InventoryLot
        fields = "__all__"


class AssignBinSerializer(serializers.Serializer):
    """For forklift operator scanning bin QR."""
    bin_location_id = serializers.IntegerField()
    remarks         = serializers.CharField(required=False, allow_blank=True)


# ─── Inventory Transaction ──────────────────────────────────────────

class InventoryTransactionSerializer(serializers.ModelSerializer):
    lot_number = serializers.CharField(source="lot.lot_number", read_only=True)
    item_code  = serializers.CharField(source="lot.item.code", read_only=True)
    done_by_name = serializers.CharField(source="done_by.get_full_name", read_only=True)

    class Meta:
        model = InventoryTransaction
        fields = [
            "id", "lot", "lot_number", "item_code",
            "transaction_type", "quantity", "qty_before", "qty_after",
            "reference_type", "reference_number",
            "from_location", "to_location",
            "remarks", "done_by_name", "created_at",
        ]


# ─── Stock Issue ────────────────────────────────────────────────────

class StockIssueLineSerializer(serializers.ModelSerializer):
    item_code  = serializers.CharField(source="item.code", read_only=True)
    item_name  = serializers.CharField(source="item.name", read_only=True)
    lot_number = serializers.CharField(source="lot.lot_number", read_only=True)
    net_consumed_qty = serializers.DecimalField(max_digits=15, decimal_places=3, read_only=True)

    class Meta:
        model = StockIssueLine
        fields = [
            "id", "lot", "lot_number", "item", "item_code", "item_name",
            "requested_qty", "issued_qty", "returned_qty", "net_consumed_qty",
            "uom", "remarks",
        ]


class StockIssueCreateLineSerializer(serializers.Serializer):
    item_id       = serializers.IntegerField()
    requested_qty = serializers.DecimalField(max_digits=15, decimal_places=3)
    lot_id        = serializers.IntegerField(required=False)


class StockIssueSerializer(serializers.ModelSerializer):
    lines          = StockIssueLineSerializer(many=True, read_only=True)
    issued_by_name = serializers.CharField(source="issued_by.get_full_name", read_only=True, default="")
    warehouse_code = serializers.CharField(source="from_warehouse.code", read_only=True)

    class Meta:
        model = StockIssue
        fields = [
            "id", "uuid", "plant", "issue_number", "issue_date",
            "issue_type", "status",
            "job_card_number", "work_order_id",
            "from_warehouse", "warehouse_code",
            "issued_to_dept",
            "issued_by", "issued_by_name",
            "remarks", "lines", "created_at",
        ]


class StockIssueCreateSerializer(serializers.Serializer):
    issue_date       = serializers.DateField(required=False)
    issue_type       = serializers.ChoiceField(choices=StockIssue.IssueType.choices,
                                                default=StockIssue.IssueType.PRODUCTION)
    from_warehouse_id = serializers.IntegerField()
    job_card_number  = serializers.CharField(required=False, allow_blank=True)
    job_card_qr_data = serializers.CharField(required=False, allow_blank=True)
    work_order_id    = serializers.IntegerField(required=False, allow_null=True)
    issued_to_dept_id = serializers.IntegerField(required=False, allow_null=True)
    remarks          = serializers.CharField(required=False, allow_blank=True)
    lines            = StockIssueCreateLineSerializer(many=True)

    def validate_lines(self, lines):
        if not lines:
            raise serializers.ValidationError("At least one line item is required.")
        return lines


# ─── Stock Return ────────────────────────────────────────────────────

class StockReturnLineSerializer(serializers.ModelSerializer):
    item_code      = serializers.CharField(source="item.code", read_only=True)
    original_lot_number = serializers.CharField(source="original_lot.lot_number", read_only=True)
    bit_roll_lot_number = serializers.CharField(source="bit_roll_lot.lot_number",
                                                 read_only=True, default="")

    class Meta:
        model = StockReturnLine
        fields = [
            "id", "original_lot", "original_lot_number",
            "item", "item_code", "return_qty", "uom",
            "creates_bit_roll", "bit_roll_lot", "bit_roll_lot_number",
            "bit_roll_weight_kg", "bin_location", "condition", "remarks",
        ]


class StockReturnCreateLineSerializer(serializers.Serializer):
    original_lot_id    = serializers.IntegerField()
    return_qty         = serializers.DecimalField(max_digits=15, decimal_places=3)
    condition          = serializers.ChoiceField(choices=["GOOD","DAMAGED","SCRAP"], default="GOOD")
    bin_location_id    = serializers.IntegerField(required=False, allow_null=True)
    bit_roll_weight_kg = serializers.DecimalField(max_digits=10, decimal_places=3,
                                                   required=False, allow_null=True)


class StockReturnSerializer(serializers.ModelSerializer):
    lines = StockReturnLineSerializer(many=True, read_only=True)
    returned_by_name = serializers.CharField(source="returned_by.get_full_name",
                                              read_only=True, default="")
    warehouse_code = serializers.CharField(source="to_warehouse.code", read_only=True)

    class Meta:
        model = StockReturn
        fields = [
            "id", "uuid", "plant", "return_number", "return_date", "status",
            "original_issue", "to_warehouse", "warehouse_code",
            "returned_by", "returned_by_name", "received_by",
            "remarks", "lines", "created_at",
        ]


class StockReturnCreateSerializer(serializers.Serializer):
    return_date       = serializers.DateField(required=False)
    original_issue_id = serializers.IntegerField(required=False, allow_null=True)
    to_warehouse_id   = serializers.IntegerField()
    remarks           = serializers.CharField(required=False, allow_blank=True)
    lines             = StockReturnCreateLineSerializer(many=True)

    def validate_lines(self, lines):
        if not lines:
            raise serializers.ValidationError("At least one line required.")
        return lines


# ─── Physical Verification ──────────────────────────────────────────

class PVLineSerializer(serializers.ModelSerializer):
    item_code  = serializers.CharField(source="item.code", read_only=True, default="")
    bin_code   = serializers.CharField(source="bin_location.code", read_only=True, default="")
    lot_number = serializers.CharField(source="lot.lot_number", read_only=True, default="")

    class Meta:
        model = PVLine
        fields = [
            "id", "lot", "lot_number", "item", "item_code",
            "bin_location", "bin_code",
            "book_qty", "physical_qty", "variance_qty", "variance_type",
            "scanned_at", "adjustment_posted", "remarks",
        ]


class PVScanSerializer(serializers.Serializer):
    qr_data_raw  = serializers.CharField()
    physical_qty = serializers.DecimalField(max_digits=15, decimal_places=3)


class PhysicalVerificationSerializer(serializers.ModelSerializer):
    lines         = PVLineSerializer(many=True, read_only=True)
    warehouse_name = serializers.CharField(source="warehouse.name", read_only=True)
    variance_count = serializers.IntegerField(read_only=True)

    class Meta:
        model = PhysicalVerification
        fields = [
            "id", "uuid", "plant", "pv_number", "pv_type", "status",
            "warehouse", "warehouse_name",
            "planned_date", "start_time", "end_time",
            "total_lots_expected", "total_lots_scanned",
            "lots_matched", "lots_short", "lots_excess", "lots_missing",
            "variance_count",
            "approved_by", "remarks", "lines",
        ]


# ─── Stock Transfer ─────────────────────────────────────────────────

class StockTransferLineSerializer(serializers.ModelSerializer):
    item_code = serializers.CharField(source="item.code", read_only=True)
    lot_number = serializers.CharField(source="lot.lot_number", read_only=True)

    class Meta:
        model = StockTransferLine
        fields = ["id", "lot", "lot_number", "item", "item_code", "qty", "from_bin", "to_bin"]


class StockTransferSerializer(serializers.ModelSerializer):
    lines = StockTransferLineSerializer(many=True, read_only=True)

    class Meta:
        model = StockTransfer
        fields = [
            "id", "uuid", "plant", "transfer_number", "transfer_date", "status",
            "from_warehouse", "to_warehouse",
            "transferred_by", "remarks", "lines", "created_at",
        ]


# ─── Min/Max Alerts ─────────────────────────────────────────────────

class MinMaxAlertSerializer(serializers.ModelSerializer):
    item_code  = serializers.CharField(source="item.code", read_only=True)
    item_name  = serializers.CharField(source="item.name", read_only=True)
    warehouse_code = serializers.CharField(source="warehouse.code", read_only=True)

    class Meta:
        model = MinMaxAlert
        fields = [
            "id", "item", "item_code", "item_name",
            "plant", "warehouse", "warehouse_code",
            "alert_type", "alert_date",
            "min_level", "max_level", "current_stock", "shortage_qty",
            "is_resolved", "resolved_at", "email_sent",
        ]
