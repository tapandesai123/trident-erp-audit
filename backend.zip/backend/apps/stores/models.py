"""
Stores & Inventory Module — Full Implementation (Section 4)
Covers:
  - Warehouse & BinLocation (with QR generation)
  - InventoryLot (roll/lot tracking, FIFO, bit-roll)
  - InventoryTransaction (all stock movements)
  - StockIssue + StockIssueLine (scan job QR, issue RM to production)
  - StockReturn + StockReturnLine (partial/bit-roll returns from production)
  - BitRollSplit (when a partial roll comes back, create new lot)
  - PhysicalVerification + PVLine (bay-by-bay scanning, weekly/daily)
  - StockTransfer (bin-to-bin / warehouse-to-warehouse)
  - MinMaxAlert (items below min / above max levels)
"""
import uuid
from decimal import Decimal
from django.conf import settings
from django.db import models
from django.utils import timezone

from apps.core.models import TimeStampedModel, UUIDModel, Plant


# ─── Warehouse & Bin ────────────────────────────────────────────────

class Warehouse(TimeStampedModel):
    """Warehouse / Store locations within a plant."""
    class WarehouseType(models.TextChoices):
        RM_STORE          = "RM_STORE",          "Raw Material Store"
        FG_STORE          = "FG_STORE",           "Finished Goods Store"
        CONSUMABLE_STORE  = "CONSUMABLE_STORE",   "Consumable Store"
        ENGINEERING_STORE = "ENGINEERING_STORE",  "Engineering Store"
        QUARANTINE        = "QUARANTINE",          "Quarantine Area"
        JOB_WORK          = "JOB_WORK",           "Job Work Store"
        WIP               = "WIP",                "Work-in-Progress"

    plant          = models.ForeignKey(Plant, on_delete=models.CASCADE, related_name="warehouses")
    code           = models.CharField(max_length=20)
    name           = models.CharField(max_length=100)
    warehouse_type = models.CharField(max_length=30, choices=WarehouseType.choices)
    address        = models.TextField(blank=True)
    is_active      = models.BooleanField(default=True)

    class Meta:
        unique_together = ["plant", "code"]
        ordering = ["code"]

    def __str__(self):
        return f"{self.code} — {self.name}"


class BinLocation(models.Model):
    """
    Floor-marked bin locations (A1, A2, B1 …) with QR codes.
    Forklift operators scan bin QR + roll QR to assign location.
    """
    warehouse   = models.ForeignKey(Warehouse, on_delete=models.CASCADE, related_name="bins")
    code        = models.CharField(max_length=20, help_text="e.g. A1, B3")
    description = models.CharField(max_length=200, blank=True)
    qr_code_data = models.TextField(blank=True, help_text="JSON data encoded in QR")
    capacity_units = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True,
                                         help_text="Max rolls/lots this bin can hold")
    is_active   = models.BooleanField(default=True)

    class Meta:
        unique_together = ["warehouse", "code"]
        ordering        = ["code"]

    def __str__(self):
        return f"{self.warehouse.code}/{self.code}"

    def current_lots_count(self):
        return self.lots.filter(status="AVAILABLE").count()


# ─── Inventory Lot ──────────────────────────────────────────────────

class InventoryLot(UUIDModel, TimeStampedModel):
    """
    Roll/lot-level inventory tracking with QR barcodes.
    Each MRR line creates one InventoryLot.
    FIFO enforced via fifo_date ordering.
    """
    class QCStatus(models.TextChoices):
        PENDING  = "PENDING",  "QC Pending"
        PASSED   = "PASSED",   "QC Passed"
        REJECTED = "REJECTED", "QC Rejected"
        ON_HOLD  = "ON_HOLD",  "On Hold"

    class LotStatus(models.TextChoices):
        AVAILABLE  = "AVAILABLE",  "Available"
        RESERVED   = "RESERVED",   "Reserved"
        ISSUED     = "ISSUED",     "Fully Issued"
        QUARANTINE = "QUARANTINE", "Quarantine"
        RETURNED   = "RETURNED",   "Returned (bit-roll)"
        CONSUMED   = "CONSUMED",   "Fully Consumed"
        REJECTED   = "REJECTED",   "QC Rejected"
        TRANSFERRED = "TRANSFERRED","Transferred"

    # Item & Location
    item         = models.ForeignKey("masters.Item", on_delete=models.PROTECT, related_name="inventory_lots")
    plant        = models.ForeignKey(Plant, on_delete=models.CASCADE, related_name="inventory_lots")
    warehouse    = models.ForeignKey(Warehouse, on_delete=models.PROTECT, related_name="lots")
    bin_location = models.ForeignKey(BinLocation, on_delete=models.SET_NULL,
                                     null=True, blank=True, related_name="lots")

    # Identification
    lot_number   = models.CharField(max_length=50, blank=True, db_index=True)
    roll_number  = models.CharField(max_length=50, blank=True, db_index=True,
                                    help_text="Supplier's roll number if available")
    batch_number = models.CharField(max_length=50, blank=True)

    # Quantities
    original_qty = models.DecimalField(max_digits=15, decimal_places=3)
    current_qty  = models.DecimalField(max_digits=15, decimal_places=3)
    reserved_qty = models.DecimalField(max_digits=15, decimal_places=3, default=0)
    uom          = models.ForeignKey("masters.UOM", on_delete=models.PROTECT, null=True, blank=True)

    # Physical specs (paper-specific)
    gross_weight_kg = models.DecimalField(max_digits=10, decimal_places=3, null=True, blank=True)
    net_weight_kg   = models.DecimalField(max_digits=10, decimal_places=3, null=True, blank=True)
    deckle_mm       = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    gsm             = models.DecimalField(max_digits=8, decimal_places=2, null=True, blank=True)
    bf              = models.CharField(max_length=10, blank=True, help_text="Burst Factor e.g. BF18")

    # Supplier & dates
    supplier        = models.ForeignKey("masters.Vendor", on_delete=models.SET_NULL,
                                         null=True, blank=True, related_name="supplied_lots")
    receipt_date    = models.DateField()
    expiry_date     = models.DateField(null=True, blank=True)
    manufacture_date = models.DateField(null=True, blank=True)

    # QC
    qc_status   = models.CharField(max_length=20, choices=QCStatus.choices, default=QCStatus.PENDING)
    qc_date     = models.DateTimeField(null=True, blank=True)
    qc_remarks  = models.TextField(blank=True)
    qc_by       = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
                                     null=True, blank=True, related_name="qc_lots")

    # Barcode / QR
    qr_code_data    = models.TextField(blank=True, help_text="JSON data for QR generation")
    qr_label_printed = models.BooleanField(default=False)
    small_sticker_printed = models.BooleanField(default=False, help_text="60x70mm sticker for core pipe")

    # FIFO & Status
    fifo_date   = models.DateField(db_index=True, help_text="Used for FIFO ordering; usually = receipt_date")
    status      = models.CharField(max_length=20, choices=LotStatus.choices, default=LotStatus.AVAILABLE)
    is_active   = models.BooleanField(default=True)

    # Cross-references
    mrr_line_id    = models.IntegerField(null=True, blank=True)
    gate_entry_id  = models.IntegerField(null=True, blank=True)
    parent_lot     = models.ForeignKey("self", on_delete=models.SET_NULL,
                                        null=True, blank=True, related_name="child_lots",
                                        help_text="Original lot if this is a bit-roll")
    is_bit_roll    = models.BooleanField(default=False)

    created_by  = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
                                     null=True, related_name="created_lots")

    # Customer & Sales Order references (F1)
    customer_ref = models.ForeignKey(
        "masters.Customer", on_delete=models.SET_NULL,
        null=True, blank=True, related_name="inventory_lots",
        help_text="Customer this lot is reserved/produced for"
    )
    so_ref = models.ForeignKey(
        "sales.SalesOrder", on_delete=models.SET_NULL,
        null=True, blank=True, related_name="inventory_lots",
        help_text="Sales Order this lot is linked to"
    )

    class Meta:
        ordering = ["fifo_date", "receipt_date"]
        indexes  = [
            models.Index(fields=["item", "status"]),
            models.Index(fields=["warehouse", "bin_location"]),
            models.Index(fields=["fifo_date"]),
            models.Index(fields=["lot_number"]),
            models.Index(fields=["supplier", "receipt_date"]),
            models.Index(fields=["expiry_date"]),   # BUG-013: required for FEFO ordering
            models.Index(fields=["so_ref"]),         # Performance: SO-based lot queries
        ]

    def __str__(self):
        identifier = self.roll_number or self.lot_number or str(self.pk)[:8]
        return f"{self.item.code}/{identifier} ({self.current_qty})"

    @property
    def available_qty(self):
        return max(self.current_qty - self.reserved_qty, Decimal("0"))

    @property
    def age_days(self):
        return (timezone.now().date() - self.receipt_date).days

    def build_qr_data(self):
        """Build the dict that gets encoded into QR code."""
        return {
            "lot": self.lot_number,
            "roll": self.roll_number,
            "item": self.item.code,
            "item_name": self.item.name,
            "supplier": self.supplier.name if self.supplier else "",
            "receipt_date": str(self.receipt_date),
            "qty": str(self.current_qty),
            "deckle": str(self.deckle_mm or ""),
            "gsm": str(self.gsm or ""),
            "bf": self.bf,
            "warehouse": self.warehouse.code,
            "bin": self.bin_location.code if self.bin_location else "",
            "uuid": str(self.uuid),
        }


# ─── Inventory Transaction ──────────────────────────────────────────

class InventoryTransaction(models.Model):
    """
    Ledger of all stock movements. Every change to InventoryLot
    creates one record here.
    """
    class TransactionType(models.TextChoices):
        RECEIPT     = "RECEIPT",     "Receipt (MRR)"
        ISSUE       = "ISSUE",       "Issue to Production"
        RETURN      = "RETURN",      "Return from Production"
        TRANSFER    = "TRANSFER",    "Bin Transfer"
        ADJUSTMENT  = "ADJUSTMENT",  "Physical Verification Adjustment"
        BIT_ROLL    = "BIT_ROLL",    "Bit Roll Created"
        QC_REJECT   = "QC_REJECT",   "QC Rejection"
        QC_ACCEPT   = "QC_ACCEPT",   "QC Acceptance"
        WRITE_OFF   = "WRITE_OFF",   "Write Off"

    lot             = models.ForeignKey(InventoryLot, on_delete=models.CASCADE, related_name="transactions")
    transaction_type = models.CharField(max_length=30, choices=TransactionType.choices)
    quantity        = models.DecimalField(max_digits=15, decimal_places=3)
    qty_before      = models.DecimalField(max_digits=15, decimal_places=3, default=0)
    qty_after       = models.DecimalField(max_digits=15, decimal_places=3, default=0)

    # Reference document
    reference_type  = models.CharField(max_length=50, blank=True,
                                        help_text="e.g. StockIssue, StockReturn, PhysicalVerification")
    reference_id    = models.IntegerField(null=True, blank=True)
    reference_number = models.CharField(max_length=50, blank=True)

    # Locations
    from_location   = models.ForeignKey(BinLocation, on_delete=models.SET_NULL,
                                         null=True, blank=True, related_name="outbound_txns")
    to_location     = models.ForeignKey(BinLocation, on_delete=models.SET_NULL,
                                         null=True, blank=True, related_name="inbound_txns")
    remarks         = models.TextField(blank=True)
    done_by         = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
                                         null=True, related_name="inventory_transactions")
    created_at      = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]
        indexes  = [
            models.Index(fields=["lot", "transaction_type"]),
            models.Index(fields=["reference_type", "reference_id"]),
        ]

    def __str__(self):
        return f"{self.transaction_type}: {self.quantity} [{self.lot}]"


# ─── Stock Issue ────────────────────────────────────────────────────

class StockIssue(UUIDModel, TimeStampedModel):
    """
    Material issue to production / job work.
    Triggered by scanning Job Card QR on Android app.
    FIFO enforced — oldest lot issued first.
    """
    class IssueStatus(models.TextChoices):
        DRAFT     = "DRAFT",     "Draft"
        ISSUED    = "ISSUED",    "Issued"
        PARTIALLY_RETURNED = "PARTIALLY_RETURNED", "Partially Returned"
        CLOSED    = "CLOSED",    "Closed"
        CANCELLED = "CANCELLED", "Cancelled"

    class IssueType(models.TextChoices):
        PRODUCTION   = "PRODUCTION",   "To Production"
        JOB_WORK     = "JOB_WORK",     "To Job Worker"
        SAMPLE       = "SAMPLE",       "Sample Issue"
        MAINTENANCE  = "MAINTENANCE",  "Maintenance/Engineering"
        OTHER        = "OTHER",        "Other"

    plant          = models.ForeignKey(Plant, on_delete=models.CASCADE, related_name="stock_issues")
    issue_number   = models.CharField(max_length=50, unique=True)
    issue_date     = models.DateField()
    issue_type     = models.CharField(max_length=20, choices=IssueType.choices, default=IssueType.PRODUCTION)
    status         = models.CharField(max_length=25, choices=IssueStatus.choices, default=IssueStatus.DRAFT)

    # Reference to job card / work order (FK added when production module is built)
    job_card_number  = models.CharField(max_length=50, blank=True)
    job_card_qr_data = models.TextField(blank=True, help_text="Raw QR scan data from job card")
    work_order_id    = models.IntegerField(null=True, blank=True)

    from_warehouse   = models.ForeignKey(Warehouse, on_delete=models.PROTECT, related_name="issues")
    issued_to_dept   = models.ForeignKey("core.Department", on_delete=models.SET_NULL,
                                          null=True, blank=True)
    issued_by        = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
                                          null=True, related_name="stock_issues_made")
    approved_by      = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
                                          null=True, blank=True, related_name="stock_issues_approved")
    remarks          = models.TextField(blank=True)

    class Meta:
        ordering = ["-issue_date", "-created_at"]

    def __str__(self):
        return self.issue_number


class StockIssueLine(models.Model):
    """One line per lot issued."""
    issue       = models.ForeignKey(StockIssue, on_delete=models.CASCADE, related_name="lines")
    lot         = models.ForeignKey(InventoryLot, on_delete=models.PROTECT, related_name="issue_lines")
    item        = models.ForeignKey("masters.Item", on_delete=models.PROTECT)
    requested_qty = models.DecimalField(max_digits=15, decimal_places=3)
    issued_qty  = models.DecimalField(max_digits=15, decimal_places=3)
    uom         = models.ForeignKey("masters.UOM", on_delete=models.PROTECT, null=True, blank=True)
    remarks     = models.CharField(max_length=200, blank=True)

    # Returned quantity tracking
    returned_qty = models.DecimalField(max_digits=15, decimal_places=3, default=0)

    @property
    def net_consumed_qty(self):
        return self.issued_qty - self.returned_qty

    def __str__(self):
        return f"{self.issue.issue_number} / {self.item.code} — {self.issued_qty}"


# ─── Stock Return ────────────────────────────────────────────────────

class StockReturn(UUIDModel, TimeStampedModel):
    """
    Return of unused / partial material from production back to store.
    If a paper roll comes back partially used, it becomes a 'bit roll'
    and a new InventoryLot is created for the remaining quantity.
    """
    class ReturnStatus(models.TextChoices):
        DRAFT     = "DRAFT",     "Draft"
        RECEIVED  = "RECEIVED",  "Received in Store"
        CANCELLED = "CANCELLED", "Cancelled"

    plant          = models.ForeignKey(Plant, on_delete=models.CASCADE, related_name="stock_returns")
    return_number  = models.CharField(max_length=50, unique=True)
    return_date    = models.DateField()
    status         = models.CharField(max_length=20, choices=ReturnStatus.choices, default=ReturnStatus.DRAFT)

    original_issue = models.ForeignKey(StockIssue, on_delete=models.SET_NULL,
                                        null=True, blank=True, related_name="returns")
    to_warehouse   = models.ForeignKey(Warehouse, on_delete=models.PROTECT, related_name="returns")
    returned_by    = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
                                        null=True, related_name="stock_returns_made")
    received_by    = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
                                        null=True, blank=True, related_name="stock_returns_received")
    remarks        = models.TextField(blank=True)

    class Meta:
        ordering = ["-return_date", "-created_at"]

    def __str__(self):
        return self.return_number


class StockReturnLine(models.Model):
    """One line per lot being returned."""
    stock_return    = models.ForeignKey(StockReturn, on_delete=models.CASCADE, related_name="lines")
    original_lot    = models.ForeignKey(InventoryLot, on_delete=models.PROTECT,
                                         related_name="return_lines",
                                         help_text="The original lot that was issued")
    item            = models.ForeignKey("masters.Item", on_delete=models.PROTECT)
    return_qty      = models.DecimalField(max_digits=15, decimal_places=3)
    uom             = models.ForeignKey("masters.UOM", on_delete=models.PROTECT, null=True, blank=True)

    # If partial return → a new bit-roll lot is created
    creates_bit_roll = models.BooleanField(default=False)
    bit_roll_lot    = models.ForeignKey(InventoryLot, on_delete=models.SET_NULL,
                                         null=True, blank=True, related_name="created_from_return",
                                         help_text="New bit-roll lot created from this return")
    bit_roll_weight_kg = models.DecimalField(max_digits=10, decimal_places=3,
                                              null=True, blank=True,
                                              help_text="Weigh the bit roll on return")
    bin_location    = models.ForeignKey(BinLocation, on_delete=models.SET_NULL,
                                         null=True, blank=True,
                                         help_text="Where to put this returned lot")
    condition       = models.CharField(max_length=20,
                                        choices=[("GOOD","Good"),("DAMAGED","Damaged"),("SCRAP","Scrap")],
                                        default="GOOD")
    remarks         = models.CharField(max_length=200, blank=True)

    def __str__(self):
        return f"{self.stock_return.return_number} / {self.item.code} — {self.return_qty}"


# ─── Physical Verification ─────────────────────────────────────────

class PhysicalVerification(UUIDModel, TimeStampedModel):
    """
    Bay-by-bay physical counting of inventory.
    Runs without stopping production.
    Generates pending/missing reports.
    """
    class PVStatus(models.TextChoices):
        PLANNED    = "PLANNED",    "Planned"
        IN_PROGRESS = "IN_PROGRESS","In Progress"
        COMPLETED  = "COMPLETED",  "Completed"
        APPROVED   = "APPROVED",   "Approved & Posted"
        CANCELLED  = "CANCELLED",  "Cancelled"

    class PVType(models.TextChoices):
        DAILY    = "DAILY",    "Daily Spot Check"
        WEEKLY   = "WEEKLY",   "Weekly Bay Scan"
        MONTHLY  = "MONTHLY",  "Monthly Full Count"
        ANNUAL   = "ANNUAL",   "Annual Physical Inventory"

    plant          = models.ForeignKey(Plant, on_delete=models.CASCADE, related_name="physical_verifications")
    pv_number      = models.CharField(max_length=50, unique=True)
    pv_type        = models.CharField(max_length=20, choices=PVType.choices)
    status         = models.CharField(max_length=20, choices=PVStatus.choices, default=PVStatus.PLANNED)

    warehouse      = models.ForeignKey(Warehouse, on_delete=models.PROTECT, related_name="pvs")
    # Optionally restrict to specific bins
    bins_to_check  = models.ManyToManyField(BinLocation, blank=True,
                                             help_text="Leave empty = all bins in warehouse")

    planned_date   = models.DateField()
    start_time     = models.DateTimeField(null=True, blank=True)
    end_time       = models.DateTimeField(null=True, blank=True)

    conducted_by   = models.ManyToManyField(settings.AUTH_USER_MODEL,
                                             related_name="pvs_conducted", blank=True)
    approved_by    = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
                                        null=True, blank=True, related_name="pvs_approved")
    remarks        = models.TextField(blank=True)

    # Summary counts (auto-populated on completion)
    total_lots_expected  = models.IntegerField(default=0)
    total_lots_scanned   = models.IntegerField(default=0)
    lots_matched         = models.IntegerField(default=0)
    lots_short           = models.IntegerField(default=0)
    lots_excess          = models.IntegerField(default=0)
    lots_missing         = models.IntegerField(default=0)

    class Meta:
        ordering = ["-planned_date"]

    def __str__(self):
        return f"{self.pv_number} ({self.get_pv_type_display()})"

    @property
    def variance_count(self):
        return self.lots_short + self.lots_excess + self.lots_missing


class PVLine(models.Model):
    """
    One line per lot scanned / expected during physical verification.
    Discrepancies flagged automatically.
    """
    class VarianceType(models.TextChoices):
        MATCHED  = "MATCHED",  "Matched"
        SHORT    = "SHORT",    "Short (less than book)"
        EXCESS   = "EXCESS",   "Excess (more than book)"
        MISSING  = "MISSING",  "Missing (not found)"
        EXTRA    = "EXTRA",    "Extra (not in system)"

    pv           = models.ForeignKey(PhysicalVerification, on_delete=models.CASCADE, related_name="lines")
    lot          = models.ForeignKey(InventoryLot, on_delete=models.SET_NULL,
                                      null=True, blank=True, related_name="pv_lines",
                                      help_text="Null if EXTRA lot not in system")
    item         = models.ForeignKey("masters.Item", on_delete=models.PROTECT, null=True, blank=True)
    bin_location = models.ForeignKey(BinLocation, on_delete=models.SET_NULL,
                                      null=True, blank=True)

    # Quantities
    book_qty     = models.DecimalField(max_digits=15, decimal_places=3, default=0,
                                        help_text="System quantity before PV")
    physical_qty = models.DecimalField(max_digits=15, decimal_places=3, default=0,
                                        help_text="Actual counted quantity")
    variance_qty = models.DecimalField(max_digits=15, decimal_places=3, default=0,
                                        help_text="physical_qty - book_qty")
    variance_type = models.CharField(max_length=20, choices=VarianceType.choices, default=VarianceType.MATCHED)

    # QR scan data
    scanned_qr   = models.TextField(blank=True)
    scanned_at   = models.DateTimeField(null=True, blank=True)
    scanned_by   = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
                                      null=True, blank=True)

    # Resolution
    adjustment_posted = models.BooleanField(default=False)
    adjustment_txn    = models.ForeignKey(InventoryTransaction, on_delete=models.SET_NULL,
                                           null=True, blank=True, related_name="pv_lines")
    remarks           = models.CharField(max_length=300, blank=True)

    def __str__(self):
        return f"PV {self.pv.pv_number} / {self.item} — variance: {self.variance_qty}"


# ─── Stock Transfer ──────────────────────────────────────────────────

class StockTransfer(UUIDModel, TimeStampedModel):
    """
    Move lots from one bin to another (or warehouse to warehouse).
    Forklift operator scans roll QR → enters new bin QR → done.
    """
    class TransferStatus(models.TextChoices):
        DRAFT     = "DRAFT",     "Draft"
        COMPLETED = "COMPLETED", "Completed"
        CANCELLED = "CANCELLED", "Cancelled"

    plant           = models.ForeignKey(Plant, on_delete=models.CASCADE, related_name="stock_transfers")
    transfer_number = models.CharField(max_length=50, unique=True)
    transfer_date   = models.DateField()
    status          = models.CharField(max_length=20, choices=TransferStatus.choices, default=TransferStatus.DRAFT)

    from_warehouse  = models.ForeignKey(Warehouse, on_delete=models.PROTECT, related_name="outbound_transfers")
    to_warehouse    = models.ForeignKey(Warehouse, on_delete=models.PROTECT, related_name="inbound_transfers")
    transferred_by  = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
                                         null=True, related_name="stock_transfers_done")
    remarks         = models.TextField(blank=True)

    class Meta:
        ordering = ["-transfer_date"]

    def __str__(self):
        return self.transfer_number


class StockTransferLine(models.Model):
    """One line per lot being transferred."""
    transfer      = models.ForeignKey(StockTransfer, on_delete=models.CASCADE, related_name="lines")
    lot           = models.ForeignKey(InventoryLot, on_delete=models.PROTECT, related_name="transfer_lines")
    item          = models.ForeignKey("masters.Item", on_delete=models.PROTECT)
    qty           = models.DecimalField(max_digits=15, decimal_places=3)
    from_bin      = models.ForeignKey(BinLocation, on_delete=models.SET_NULL,
                                       null=True, blank=True, related_name="transfer_from_lines")
    to_bin        = models.ForeignKey(BinLocation, on_delete=models.SET_NULL,
                                       null=True, blank=True, related_name="transfer_to_lines")

    def __str__(self):
        return f"{self.transfer.transfer_number} / {self.item.code}"


# ─── Min/Max Alert ─────────────────────────────────────────────────

class MinMaxAlert(models.Model):
    """
    Tracks items that fall below min level or exceed max level.
    Generated by a Celery periodic task.
    Auto-emails purchasing team.
    """
    class AlertType(models.TextChoices):
        BELOW_MIN = "BELOW_MIN", "Below Minimum Level"
        ABOVE_MAX = "ABOVE_MAX", "Above Maximum Level"
        ZERO_STOCK = "ZERO_STOCK", "Zero Stock"

    item        = models.ForeignKey("masters.Item", on_delete=models.CASCADE, related_name="minmax_alerts")
    plant       = models.ForeignKey(Plant, on_delete=models.CASCADE)
    warehouse   = models.ForeignKey(Warehouse, on_delete=models.CASCADE)
    alert_type  = models.CharField(max_length=20, choices=AlertType.choices)
    alert_date  = models.DateField(auto_now_add=True)

    min_level   = models.DecimalField(max_digits=15, decimal_places=3)
    max_level   = models.DecimalField(max_digits=15, decimal_places=3)
    current_stock = models.DecimalField(max_digits=15, decimal_places=3)
    shortage_qty  = models.DecimalField(max_digits=15, decimal_places=3, default=0)

    is_resolved  = models.BooleanField(default=False)
    resolved_at  = models.DateTimeField(null=True, blank=True)
    email_sent   = models.BooleanField(default=False)
    email_sent_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-alert_date"]
        indexes  = [models.Index(fields=["item", "alert_type", "is_resolved"])]

    def __str__(self):
        return f"{self.alert_type} — {self.item.code} ({self.current_stock})"