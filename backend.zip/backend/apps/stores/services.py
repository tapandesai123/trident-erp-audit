"""
Stores Module Services — Section 4
Business logic for:
  - FIFO lot selection
  - QR code generation for bins & lots
  - Stock issue with FIFO enforcement
  - Bit-roll creation on partial return
  - Physical verification: scan, variance, post adjustments
  - Stock transfer (bin-to-bin)
  - Min/Max level checking & alert generation
"""
import json
import qrcode
import io
import base64
from decimal import Decimal
from datetime import date
from django.db import transaction
from django.db.models import Sum, F, Q
from django.utils import timezone

from apps.core.models import AuditLog, DocSequence, Notification
from apps.stores.models import (
    Warehouse, BinLocation, InventoryLot, InventoryTransaction,
    StockIssue, StockIssueLine,
    StockReturn, StockReturnLine,
    PhysicalVerification, PVLine,
    StockTransfer, StockTransferLine,
    MinMaxAlert,
)


# ═══════════════════════════════════════════════════════════════════
# HELPERS
# ═══════════════════════════════════════════════════════════════════

def _log(user, action, resource, resource_id, details=None):
    AuditLog.objects.create(
        user=user, action=action, module="stores",
        resource=resource, resource_id=int(resource_id),
        new_values=details or {},
    )


def _notify(user, title, message):
    Notification.objects.create(
        user=user, title=title, message=message,
        notification_type="IN_APP", module="stores",
    )


def _get_next_number(plant, doc_type, prefix):
    from apps.purchase.services import get_next_doc_number
    return get_next_doc_number(plant, doc_type, prefix)


def generate_qr_image_base64(data: dict) -> str:
    """Encode dict as JSON into QR, return base64 PNG."""
    qr = qrcode.QRCode(version=1, box_size=6, border=2)
    qr.add_data(json.dumps(data, default=str))
    qr.make(fit=True)
    img = qr.make_image(fill_color="black", back_color="white")
    buffer = io.BytesIO()
    img.save(buffer, format="PNG")
    return base64.b64encode(buffer.getvalue()).decode()


def generate_bin_qr(bin_location: BinLocation) -> str:
    """Generate and save QR code data for a bin location."""
    data = {
        "type": "BIN",
        "warehouse": bin_location.warehouse.code,
        "bin": bin_location.code,
        "id": bin_location.pk,
    }
    bin_location.qr_code_data = json.dumps(data)
    bin_location.save(update_fields=["qr_code_data"])
    return generate_qr_image_base64(data)


def generate_lot_qr(lot: InventoryLot) -> str:
    """Generate and save QR code for a lot. Returns base64 PNG."""
    data = lot.build_qr_data()
    lot.qr_code_data = json.dumps(data)
    lot.save(update_fields=["qr_code_data"])
    return generate_qr_image_base64(data)


# ═══════════════════════════════════════════════════════════════════
# FIFO
# ═══════════════════════════════════════════════════════════════════

def get_fifo_lots(item, plant, warehouse=None, qty_needed=None):
    """
    Return available lots for an item ordered per the plant's stock_issue_mode.
    FIFO: oldest first (default).
    LIFO: newest first.
    MANUAL: default ordering, operator selects.
    If qty_needed is provided, returns only as many lots as needed to cover it.
    """
    qs = InventoryLot.objects.filter(
        item=item,
        plant=plant,
        status=InventoryLot.LotStatus.AVAILABLE,
        qc_status=InventoryLot.QCStatus.PASSED,
        is_active=True,
    ).filter(
        current_qty__gt=F("reserved_qty")
    )

    # Apply ordering based on plant's stock_issue_mode (F5)
    issue_mode = getattr(plant, "stock_issue_mode", "FIFO")
    if issue_mode == "FEFO":
        qs = qs.order_by(F("expiry_date").asc(nulls_last=True), "fifo_date")
    elif issue_mode == "MANUAL":
        qs = qs.order_by("fifo_date")
    else:  # FIFO (default)
        qs = qs.order_by("fifo_date", "receipt_date")

    if warehouse:
        qs = qs.filter(warehouse=warehouse)

    if qty_needed is None:
        return list(qs)

    # Collect lots until we have enough qty
    selected = []
    accumulated = Decimal("0")
    for lot in qs:
        if accumulated >= qty_needed:
            break
        selected.append(lot)
        accumulated += lot.available_qty

    if accumulated < qty_needed:
        raise ValueError(
            f"Insufficient FIFO stock for {item.code}. "
            f"Available: {accumulated}, Required: {qty_needed}"
        )

    return selected


def check_fifo_violation(item, plant, lot_to_issue: InventoryLot):
    """
    Returns a dict:
      {violated: bool, older_lot_number: str|None, older_lot_date: date|None}
    Used to warn/block before issue.
    """
    older_lot = InventoryLot.objects.filter(
        item=item,
        plant=plant,
        status=InventoryLot.LotStatus.AVAILABLE,
        qc_status=InventoryLot.QCStatus.PASSED,
        is_active=True,
        fifo_date__lt=lot_to_issue.fifo_date,
    ).filter(current_qty__gt=F("reserved_qty")).order_by("fifo_date").first()

    if older_lot:
        return {
            "violated": True,
            "older_lot_number": older_lot.lot_number,
            "older_lot_date": older_lot.fifo_date,
        }
    return {"violated": False, "older_lot_number": None, "older_lot_date": None}


# ═══════════════════════════════════════════════════════════════════
# BIN LOCATION ASSIGNMENT
# ═══════════════════════════════════════════════════════════════════

def assign_bin_to_lot(lot: InventoryLot, bin_location: BinLocation, user, remarks=""):
    """
    Assign or change the bin location of a lot.
    Used by forklift operator scanning bin QR after placing the roll.
    """
    old_bin = lot.bin_location

    with transaction.atomic():
        lot.bin_location = bin_location
        lot.save(update_fields=["bin_location", "updated_at"])

        # Update QR code data to reflect new bin
        generate_lot_qr(lot)

        # Record as a transfer transaction if bin changed
        if old_bin != bin_location:
            InventoryTransaction.objects.create(
                lot=lot,
                transaction_type=InventoryTransaction.TransactionType.TRANSFER,
                quantity=lot.current_qty,
                qty_before=lot.current_qty,
                qty_after=lot.current_qty,
                from_location=old_bin,
                to_location=bin_location,
                remarks=remarks or f"Bin assigned via scan",
                done_by=user,
            )

        _log(user, "BIN_ASSIGN", "InventoryLot", lot.pk,
             {"old_bin": str(old_bin), "new_bin": str(bin_location)})

    return lot


# ═══════════════════════════════════════════════════════════════════
# STOCK ISSUE
# ═══════════════════════════════════════════════════════════════════

@transaction.atomic
def create_stock_issue(data: dict, lines_data: list, user, plant) -> StockIssue:
    """
    Create a stock issue with FIFO enforcement.
    data: dict with issue header fields
    lines_data: list of {item_id, requested_qty, lot_id (optional)}
    """
    issue_number = _get_next_number(plant, "SI", "SI")

    issue = StockIssue.objects.create(
        plant=plant,
        issue_number=issue_number,
        issue_date=data.get("issue_date", date.today()),
        issue_type=data.get("issue_type", StockIssue.IssueType.PRODUCTION),
        from_warehouse_id=data["from_warehouse_id"],
        job_card_number=data.get("job_card_number", ""),
        job_card_qr_data=data.get("job_card_qr_data", ""),
        work_order_id=data.get("work_order_id"),
        issued_to_dept_id=data.get("issued_to_dept_id"),
        issued_by=user,
        remarks=data.get("remarks", ""),
        status=StockIssue.IssueStatus.DRAFT,
    )

    total_requested = Decimal("0")
    total_issued = Decimal("0")

    for line_data in lines_data:
        from apps.masters.models import Item
        item = Item.objects.get(pk=line_data["item_id"])
        requested_qty = Decimal(str(line_data["requested_qty"]))
        total_requested += requested_qty

        # If specific lot provided, use it; else auto-select FIFO
        if line_data.get("lot_id"):
            lot = InventoryLot.objects.select_for_update().get(pk=line_data["lot_id"])

            # Warn if FIFO violation — actual enforcement is done in the viewset
            fifo_result = check_fifo_violation(item, plant, lot)
            if fifo_result["violated"]:
                # In a real system this would be a warning flag; we still allow it
                pass

            issued_qty = min(requested_qty, lot.available_qty)
            _issue_from_lot(issue, lot, item, requested_qty, issued_qty, user)
            total_issued += issued_qty
        else:
            # FIFO auto-selection
            fifo_lots = get_fifo_lots(item, plant,
                                       warehouse=issue.from_warehouse,
                                       qty_needed=requested_qty)
            remaining = requested_qty
            for lot in fifo_lots:
                if remaining <= 0:
                    break
                qty_to_issue = min(remaining, lot.available_qty)
                _issue_from_lot(issue, lot, item, qty_to_issue, qty_to_issue, user)
                remaining -= qty_to_issue
            line_issued = requested_qty - remaining
            total_issued += line_issued

    # BUG-016: Set ISSUED only when all requested quantities are fulfilled;
    # leave as DRAFT if any line was partially or not fulfilled.
    if total_requested > 0 and total_issued >= total_requested:
        issue.status = StockIssue.IssueStatus.ISSUED
    else:
        issue.status = StockIssue.IssueStatus.DRAFT
    issue.save(update_fields=["status"])

    _log(user, "STOCK_ISSUE", "StockIssue", issue.pk,
         {"issue_number": issue.issue_number, "lines": len(lines_data)})

    return issue


def _issue_from_lot(issue, lot, item, requested_qty, issued_qty, user):
    """Internal: deduct qty from lot and create issue line + transaction.

    BUG-015: Re-fetch the lot inside a select_for_update() lock to guard against
    stale available_qty reads when multiple concurrent requests target the same lot.
    """
    # Re-fetch with a row-level lock to get the latest available_qty
    lot = InventoryLot.objects.select_for_update().get(pk=lot.pk)
    fresh_available = lot.current_qty - lot.reserved_qty
    if fresh_available <= 0:
        raise ValueError(
            f"Lot {lot.lot_number or lot.pk} has no available stock (available: {fresh_available})."
        )
    # Clamp issued_qty to what is actually available now
    issued_qty = min(issued_qty, fresh_available)

    old_qty = lot.current_qty
    lot.current_qty = F("current_qty") - issued_qty
    if issued_qty >= fresh_available:
        lot.status = InventoryLot.LotStatus.ISSUED
    lot.save(update_fields=["current_qty", "status", "updated_at"])
    lot.refresh_from_db()

    StockIssueLine.objects.create(
        issue=issue,
        lot=lot,
        item=item,
        requested_qty=requested_qty,
        issued_qty=issued_qty,
        uom=item.uom,
    )

    InventoryTransaction.objects.create(
        lot=lot,
        transaction_type=InventoryTransaction.TransactionType.ISSUE,
        quantity=issued_qty,
        qty_before=old_qty,
        qty_after=lot.current_qty,
        reference_type="StockIssue",
        reference_id=issue.pk,
        reference_number=issue.issue_number,
        from_location=lot.bin_location,
        done_by=user,
    )


# ═══════════════════════════════════════════════════════════════════
# STOCK RETURN & BIT-ROLL CREATION
# ═══════════════════════════════════════════════════════════════════

@transaction.atomic
def create_stock_return(data: dict, lines_data: list, user, plant) -> StockReturn:
    """
    Return partial/full material from production to store.
    If partial return: creates a new 'bit-roll' InventoryLot with remaining qty.
    """
    return_number = _get_next_number(plant, "SR", "SR")

    stock_return = StockReturn.objects.create(
        plant=plant,
        return_number=return_number,
        return_date=data.get("return_date", date.today()),
        original_issue_id=data.get("original_issue_id"),
        to_warehouse_id=data["to_warehouse_id"],
        returned_by=user,
        remarks=data.get("remarks", ""),
        status=StockReturn.ReturnStatus.DRAFT,
    )

    for line_data in lines_data:
        original_lot = InventoryLot.objects.select_for_update().get(pk=line_data["original_lot_id"])
        return_qty   = Decimal(str(line_data["return_qty"]))
        condition    = line_data.get("condition", "GOOD")

        return_line = StockReturnLine.objects.create(
            stock_return=stock_return,
            original_lot=original_lot,
            item=original_lot.item,
            return_qty=return_qty,
            uom=original_lot.uom,
            bin_location_id=line_data.get("bin_location_id"),
            condition=condition,
            bit_roll_weight_kg=line_data.get("bit_roll_weight_kg"),
        )

        if condition == "GOOD":
            # Create a bit-roll lot for the returned qty
            bit_roll = _create_bit_roll(
                original_lot=original_lot,
                return_qty=return_qty,
                weight_kg=line_data.get("bit_roll_weight_kg"),
                bin_location_id=line_data.get("bin_location_id"),
                to_warehouse_id=data["to_warehouse_id"],
                user=user,
                return_number=return_number,
            )
            return_line.creates_bit_roll = True
            return_line.bit_roll_lot = bit_roll
            return_line.save(update_fields=["creates_bit_roll", "bit_roll_lot"])

            # Update original lot's returned qty tracking
            issue_line = StockIssueLine.objects.filter(
                lot=original_lot
            ).order_by("-id").first()
            if issue_line:
                issue_line.returned_qty = F("returned_qty") + return_qty
                issue_line.save(update_fields=["returned_qty"])

    # Mark return received
    stock_return.status = StockReturn.ReturnStatus.RECEIVED
    stock_return.received_by = user
    stock_return.save(update_fields=["status", "received_by"])

    _log(user, "STOCK_RETURN", "StockReturn", stock_return.pk,
         {"return_number": return_number})

    return stock_return


def _create_bit_roll(original_lot, return_qty, weight_kg, bin_location_id,
                      to_warehouse_id, user, return_number):
    """
    Create a new InventoryLot (bit-roll) from a partial return.
    Auto-generates new lot number, prints new sticker.
    """
    import uuid as _uuid

    new_lot_number = f"BR-{original_lot.lot_number}-{str(_uuid.uuid4())[:6].upper()}"

    bit_roll = InventoryLot.objects.create(
        item=original_lot.item,
        plant=original_lot.plant,
        warehouse_id=to_warehouse_id,
        bin_location_id=bin_location_id,
        lot_number=new_lot_number,
        roll_number="",
        batch_number=original_lot.batch_number,
        original_qty=return_qty,
        current_qty=return_qty,
        uom=original_lot.uom,
        gross_weight_kg=weight_kg,
        net_weight_kg=weight_kg,
        deckle_mm=original_lot.deckle_mm,
        gsm=original_lot.gsm,
        bf=original_lot.bf,
        supplier=original_lot.supplier,
        receipt_date=date.today(),
        fifo_date=original_lot.fifo_date,  # Keep original FIFO date
        qc_status=InventoryLot.QCStatus.PASSED,  # Already QC'd on inward
        status=InventoryLot.LotStatus.RETURNED,
        is_bit_roll=True,
        parent_lot=original_lot,
        created_by=user,
    )

    # Generate new QR code for bit-roll
    generate_lot_qr(bit_roll)

    # Transaction record
    InventoryTransaction.objects.create(
        lot=bit_roll,
        transaction_type=InventoryTransaction.TransactionType.BIT_ROLL,
        quantity=return_qty,
        qty_before=0,
        qty_after=return_qty,
        reference_type="StockReturn",
        reference_number=return_number,
        done_by=user,
        remarks=f"Bit roll from lot {original_lot.lot_number}",
    )

    return bit_roll


# ═══════════════════════════════════════════════════════════════════
# PHYSICAL VERIFICATION
# ═══════════════════════════════════════════════════════════════════

@transaction.atomic
def start_physical_verification(pv: PhysicalVerification, user):
    """
    Start a PV session: snapshot book quantities for all lots in warehouse.
    """
    if pv.status != PhysicalVerification.PVStatus.PLANNED:
        raise ValueError("PV must be in PLANNED status to start.")

    # Get all active lots in the warehouse
    lots_qs = InventoryLot.objects.filter(
        warehouse=pv.warehouse,
        is_active=True,
    ).filter(
        ~Q(status__in=[InventoryLot.LotStatus.ISSUED, InventoryLot.LotStatus.CONSUMED])
    )

    if pv.bins_to_check.exists():
        lots_qs = lots_qs.filter(bin_location__in=pv.bins_to_check.all())

    # Create expected lines from book stock
    pv_lines = []
    for lot in lots_qs:
        pv_lines.append(PVLine(
            pv=pv,
            lot=lot,
            item=lot.item,
            bin_location=lot.bin_location,
            book_qty=lot.current_qty,
            physical_qty=Decimal("0"),
            variance_type=PVLine.VarianceType.MISSING,  # Default: missing until scanned
        ))
    PVLine.objects.bulk_create(pv_lines)

    pv.status = PhysicalVerification.PVStatus.IN_PROGRESS
    pv.start_time = timezone.now()
    pv.total_lots_expected = len(pv_lines)
    pv.save(update_fields=["status", "start_time", "total_lots_expected"])

    _log(user, "PV_START", "PhysicalVerification", pv.pk,
         {"lots_expected": len(pv_lines)})
    return pv


@transaction.atomic
def record_pv_scan(pv: PhysicalVerification, qr_data_raw: str, physical_qty: Decimal, user):
    """
    Record a scan during physical verification.
    qr_data_raw: raw string from QR scanner (JSON)
    """
    if pv.status != PhysicalVerification.PVStatus.IN_PROGRESS:
        raise ValueError("PV is not in progress.")

    try:
        qr_data = json.loads(qr_data_raw)
        lot_uuid = qr_data.get("uuid")
    except (json.JSONDecodeError, KeyError):
        raise ValueError("Invalid QR code data.")

    lot = InventoryLot.objects.filter(uuid=lot_uuid).first()
    if not lot:
        # Lot not in system → create EXTRA line
        PVLine.objects.create(
            pv=pv,
            lot=None,
            item=None,
            book_qty=Decimal("0"),
            physical_qty=physical_qty,
            variance_qty=physical_qty,
            variance_type=PVLine.VarianceType.EXTRA,
            scanned_qr=qr_data_raw,
            scanned_at=timezone.now(),
            scanned_by=user,
        )
        return None

    # Find existing PV line for this lot
    pv_line = PVLine.objects.filter(pv=pv, lot=lot).first()
    if not pv_line:
        # Lot not in planned scope → also EXTRA
        pv_line = PVLine(
            pv=pv,
            lot=lot,
            item=lot.item,
            bin_location=lot.bin_location,
            book_qty=Decimal("0"),
            variance_type=PVLine.VarianceType.EXTRA,
        )

    pv_line.physical_qty = physical_qty
    pv_line.variance_qty = physical_qty - pv_line.book_qty
    pv_line.scanned_qr   = qr_data_raw
    pv_line.scanned_at   = timezone.now()
    pv_line.scanned_by   = user

    if pv_line.variance_qty == 0:
        pv_line.variance_type = PVLine.VarianceType.MATCHED
    elif pv_line.variance_qty < 0:
        pv_line.variance_type = PVLine.VarianceType.SHORT
    else:
        pv_line.variance_type = PVLine.VarianceType.EXCESS

    pv_line.save()
    return pv_line


@transaction.atomic
def complete_physical_verification(pv: PhysicalVerification, user):
    """
    Complete PV: calculate summary counts.
    Does NOT post adjustments yet — that requires separate approval.
    """
    lines = pv.lines.all()
    pv.total_lots_scanned = lines.filter(
        variance_type__in=[PVLine.VarianceType.MATCHED,
                           PVLine.VarianceType.SHORT,
                           PVLine.VarianceType.EXCESS,
                           PVLine.VarianceType.EXTRA]
    ).count()
    pv.lots_matched = lines.filter(variance_type=PVLine.VarianceType.MATCHED).count()
    pv.lots_short   = lines.filter(variance_type=PVLine.VarianceType.SHORT).count()
    pv.lots_excess  = lines.filter(variance_type=PVLine.VarianceType.EXCESS).count()
    pv.lots_missing = lines.filter(variance_type=PVLine.VarianceType.MISSING).count()
    pv.status       = PhysicalVerification.PVStatus.COMPLETED
    pv.end_time     = timezone.now()
    pv.save()

    _log(user, "PV_COMPLETE", "PhysicalVerification", pv.pk, {
        "matched": pv.lots_matched,
        "short": pv.lots_short,
        "missing": pv.lots_missing,
        "excess": pv.lots_excess,
    })
    return pv


@transaction.atomic
def post_pv_adjustments(pv: PhysicalVerification, user):
    """
    Post inventory adjustments for all variance lines.
    Requires PV to be in COMPLETED status and user to have approval rights.
    """
    if pv.status != PhysicalVerification.PVStatus.COMPLETED:
        raise ValueError("PV must be completed before posting adjustments.")

    variance_lines = pv.lines.filter(
        adjustment_posted=False,
    ).exclude(variance_type=PVLine.VarianceType.MATCHED)

    for line in variance_lines:
        if not line.lot:
            continue  # EXTRA lots without system record — skip (handle manually)

        lot = InventoryLot.objects.select_for_update().get(pk=line.lot_id)
        old_qty = lot.current_qty
        lot.current_qty = line.physical_qty
        lot.save(update_fields=["current_qty", "updated_at"])

        txn = InventoryTransaction.objects.create(
            lot=lot,
            transaction_type=InventoryTransaction.TransactionType.ADJUSTMENT,
            quantity=abs(line.variance_qty),
            qty_before=old_qty,
            qty_after=line.physical_qty,
            reference_type="PhysicalVerification",
            reference_id=pv.pk,
            reference_number=pv.pv_number,
            remarks=f"PV adjustment: {line.variance_type}",
            done_by=user,
        )

        line.adjustment_posted = True
        line.adjustment_txn    = txn
        line.save(update_fields=["adjustment_posted", "adjustment_txn"])

    pv.status = PhysicalVerification.PVStatus.APPROVED
    pv.approved_by = user
    pv.save(update_fields=["status", "approved_by"])

    _log(user, "PV_POSTED", "PhysicalVerification", pv.pk,
         {"adjustments": variance_lines.count()})
    return pv


# ═══════════════════════════════════════════════════════════════════
# STOCK TRANSFER (BIN TO BIN)
# ═══════════════════════════════════════════════════════════════════

@transaction.atomic
def create_stock_transfer(data: dict, lines_data: list, user, plant) -> StockTransfer:
    """
    Transfer lots from one bin/warehouse to another.
    Typically triggered by forklift operator scanning roll QR → new bin QR.
    """
    transfer_number = _get_next_number(plant, "ST", "ST")

    transfer = StockTransfer.objects.create(
        plant=plant,
        transfer_number=transfer_number,
        transfer_date=data.get("transfer_date", date.today()),
        from_warehouse_id=data["from_warehouse_id"],
        to_warehouse_id=data["to_warehouse_id"],
        transferred_by=user,
        remarks=data.get("remarks", ""),
        status=StockTransfer.TransferStatus.DRAFT,
    )

    for ld in lines_data:
        lot = InventoryLot.objects.select_for_update().get(pk=ld["lot_id"])
        from_bin = lot.bin_location
        to_bin   = BinLocation.objects.get(pk=ld["to_bin_id"]) if ld.get("to_bin_id") else None
        qty      = Decimal(str(ld.get("qty", lot.current_qty)))

        StockTransferLine.objects.create(
            transfer=transfer,
            lot=lot,
            item=lot.item,
            qty=qty,
            from_bin=from_bin,
            to_bin=to_bin,
        )

        # Update lot location
        lot.warehouse_id  = data["to_warehouse_id"]
        lot.bin_location  = to_bin
        lot.save(update_fields=["warehouse", "bin_location", "updated_at"])

        # Regenerate QR with new bin
        generate_lot_qr(lot)

        InventoryTransaction.objects.create(
            lot=lot,
            transaction_type=InventoryTransaction.TransactionType.TRANSFER,
            quantity=qty,
            qty_before=qty,
            qty_after=qty,
            from_location=from_bin,
            to_location=to_bin,
            reference_type="StockTransfer",
            reference_number=transfer_number,
            done_by=user,
        )

    transfer.status = StockTransfer.TransferStatus.COMPLETED
    transfer.save(update_fields=["status"])

    _log(user, "STOCK_TRANSFER", "StockTransfer", transfer.pk,
         {"transfer_number": transfer_number})
    return transfer


# ═══════════════════════════════════════════════════════════════════
# MIN/MAX ALERTS
# ═══════════════════════════════════════════════════════════════════

def check_and_create_minmax_alerts(plant):
    """
    Run via Celery beat daily.
    Checks all items against their min/max levels and creates alerts.

    Performance fix: replaced N+1 nested loops (items × warehouses × aggregate query)
    with a single annotated queryset grouped by item+warehouse.
    """
    from apps.masters.models import Item

    # Single query: aggregate current stock per item+warehouse combination
    stock_by_item_wh = (
        InventoryLot.objects
        .filter(
            plant=plant,
            status=InventoryLot.LotStatus.AVAILABLE,
            qc_status=InventoryLot.QCStatus.PASSED,
            is_active=True,
            item__is_active=True,
            item__approval_status="APPROVED",
            item__min_stock__gt=0,
        )
        .values("item", "warehouse")
        .annotate(total=Sum("current_qty"))
    )

    # Build lookup: {(item_id, warehouse_id): total_qty}
    stock_map = {(row["item"], row["warehouse"]): row["total"] for row in stock_by_item_wh}

    # Fetch qualifying items and active warehouses in two flat queries
    items = list(
        Item.objects.filter(is_active=True, approval_status="APPROVED", min_stock__gt=0)
        .only("pk", "min_stock", "max_stock")
    )
    warehouses = list(Warehouse.objects.filter(plant=plant, is_active=True).only("pk"))

    alerts_created = 0
    for item in items:
        for wh in warehouses:
            current_stock = stock_map.get((item.pk, wh.pk), Decimal("0"))

            alert_type = None
            shortage = Decimal("0")

            if current_stock == 0:
                alert_type = MinMaxAlert.AlertType.ZERO_STOCK
                shortage = item.min_stock or Decimal("0")
            elif item.min_stock and current_stock < item.min_stock:
                alert_type = MinMaxAlert.AlertType.BELOW_MIN
                shortage = item.min_stock - current_stock
            elif item.max_stock and current_stock > item.max_stock:
                alert_type = MinMaxAlert.AlertType.ABOVE_MAX

            if alert_type:
                # Only create if no unresolved alert exists for same item+wh+type
                existing = MinMaxAlert.objects.filter(
                    item=item, plant=plant, warehouse=wh,
                    alert_type=alert_type, is_resolved=False
                ).exists()
                if not existing:
                    MinMaxAlert.objects.create(
                        item=item, plant=plant, warehouse=wh,
                        alert_type=alert_type,
                        min_level=item.min_stock or 0,
                        max_level=item.max_stock or 0,
                        current_stock=current_stock,
                        shortage_qty=shortage,
                    )
                    alerts_created += 1
            else:
                # Resolve any existing open alert
                MinMaxAlert.objects.filter(
                    item=item, plant=plant, warehouse=wh,
                    is_resolved=False,
                ).update(is_resolved=True, resolved_at=timezone.now())

    return alerts_created


# ═══════════════════════════════════════════════════════════════════
# REPORTS
# ═══════════════════════════════════════════════════════════════════

def get_stock_summary(plant, warehouse=None, item=None):
    """
    Current stock summary grouped by item.
    Returns list of dicts: {item, total_qty, available_qty, lots_count, oldest_date}
    """
    qs = InventoryLot.objects.filter(
        plant=plant,
        is_active=True,
        status=InventoryLot.LotStatus.AVAILABLE,
    )
    if warehouse:
        qs = qs.filter(warehouse=warehouse)
    if item:
        qs = qs.filter(item=item)

    from django.db.models import Min, Count
    return qs.values("item__code", "item__name").annotate(
        total_qty=Sum("current_qty"),
        available_qty=Sum(F("current_qty") - F("reserved_qty")),
        lots_count=Count("id"),
        oldest_receipt=Min("receipt_date"),
    ).order_by("item__code")


def get_lot_ageing_report(plant, warehouse=None, days_threshold=90):
    """
    Lots older than threshold — ageing report.
    """
    cutoff = timezone.now().date()
    from datetime import timedelta
    old_date = cutoff - timedelta(days=days_threshold)

    qs = InventoryLot.objects.filter(
        plant=plant,
        is_active=True,
        status=InventoryLot.LotStatus.AVAILABLE,
        receipt_date__lte=old_date,
    )
    if warehouse:
        qs = qs.filter(warehouse=warehouse)

    return qs.select_related("item", "supplier", "bin_location", "warehouse").order_by("receipt_date")


def get_bit_roll_report(plant):
    """All active bit-rolls with age and location."""
    return InventoryLot.objects.filter(
        plant=plant,
        is_bit_roll=True,
        is_active=True,
        status__in=[InventoryLot.LotStatus.AVAILABLE, InventoryLot.LotStatus.RETURNED],
    ).select_related("item", "warehouse", "bin_location", "parent_lot").order_by("fifo_date")


def get_location_report(warehouse):
    """All lots and their bin locations within a warehouse."""
    return InventoryLot.objects.filter(
        warehouse=warehouse,
        is_active=True,
    ).exclude(
        status__in=[InventoryLot.LotStatus.ISSUED, InventoryLot.LotStatus.CONSUMED]
    ).select_related("item", "bin_location").order_by("bin_location__code", "item__code")


# ═══════════════════════════════════════════════════════════════════
# LOT TAG / STICKER PDF (Task 16)
# ═══════════════════════════════════════════════════════════════════

def _render_tag_block_a4(lot, qr_b64: str) -> str:
    """Render one half-A4 tag block for a lot (HTML fragment)."""
    supplier = lot.supplier.name if lot.supplier else "—"
    bin_code  = lot.bin_location.code if lot.bin_location else "—"
    warehouse = lot.warehouse.code if lot.warehouse else "—"
    uom_code  = lot.uom.code if lot.uom else ""

    specs = []
    if lot.gsm:
        specs.append(f"GSM: {lot.gsm}")
    if lot.deckle_mm:
        specs.append(f"Deckle: {lot.deckle_mm} mm")
    if lot.bf:
        specs.append(f"BF: {lot.bf}")
    specs_str = " &nbsp;|&nbsp; ".join(specs) if specs else ""

    weight_str = ""
    if lot.gross_weight_kg is not None:
        weight_str = f"Gross: <strong>{lot.gross_weight_kg} kg</strong>"
        if lot.net_weight_kg is not None:
            weight_str += f" &nbsp;|&nbsp; Net: <strong>{lot.net_weight_kg} kg</strong>"

    return f"""
<div class="tag-a4">
  <div class="tag-a4-left">
    <img src="data:image/png;base64,{qr_b64}" alt="QR" class="qr-img-a4" />
    <div class="lot-num">{lot.lot_number or lot.roll_number or "—"}</div>
    <div class="location-box">
      <span class="loc-label">WH</span> {warehouse}
      &nbsp;/&nbsp;
      <span class="loc-label">BIN</span> {bin_code}
    </div>
  </div>
  <div class="tag-a4-right">
    <div class="item-code">{lot.item.code}</div>
    <div class="item-desc">{lot.item.name}</div>
    {'<div class="specs-line">' + specs_str + '</div>' if specs_str else ''}
    <div class="tag-row"><span class="lbl">Supplier</span><span class="val">{supplier}</span></div>
    <div class="tag-row"><span class="lbl">Receipt Date</span><span class="val">{lot.receipt_date.strftime('%d-%b-%Y')}</span></div>
    <div class="tag-row"><span class="lbl">Qty</span><span class="val"><strong>{lot.current_qty} {uom_code}</strong></span></div>
    {'<div class="weight-row">' + weight_str + '</div>' if weight_str else ''}
    {'<div class="tag-row"><span class="lbl">Roll #</span><span class="val">' + lot.roll_number + '</span></div>' if lot.roll_number else ''}
    <div class="tag-row"><span class="lbl">QC Status</span><span class="val qc-{lot.qc_status.lower()}">{lot.qc_status}</span></div>
    <div class="tag-footer">Trident ERP — Printed {__import__('datetime').date.today().strftime('%d/%m/%Y')}</div>
  </div>
</div>"""


def _render_tag_block_label(lot, qr_b64: str) -> str:
    """Render one 60×70mm label block (HTML fragment)."""
    bin_code = lot.bin_location.code if lot.bin_location else "—"
    weight   = f"{lot.gross_weight_kg} kg" if lot.gross_weight_kg else f"{lot.current_qty}"
    specs    = []
    if lot.gsm:
        specs.append(f"{lot.gsm}GSM")
    if lot.deckle_mm:
        specs.append(f"{lot.deckle_mm}mm")
    if lot.bf:
        specs.append(lot.bf)
    spec_str = " | ".join(specs)

    return f"""
<div class="label-cell">
  <div class="label-top">
    <img src="data:image/png;base64,{qr_b64}" alt="QR" class="qr-img-lbl" />
    <div class="label-meta">
      <div class="lbl-item-code">{lot.item.code}</div>
      <div class="lbl-lot">{lot.lot_number or lot.roll_number}</div>
      {'<div class="lbl-spec">' + spec_str + '</div>' if spec_str else ''}
    </div>
  </div>
  <div class="lbl-weight">{weight}</div>
  <div class="lbl-bin">BIN: {bin_code} | {lot.receipt_date.strftime('%d/%m/%y')}</div>
</div>"""


def generate_lot_print_pdf(lots, size: str = "A4") -> bytes:
    """
    Generate a PDF for one or more InventoryLots.

    size='A4'          → Half-A4 layout with large QR, 2 tags per page
    size='LABEL_60X70' → 60×70mm compact labels, 4 per A4 page

    Returns WeasyPrint-rendered PDF bytes.
    """
    # Pre-compute QR for each lot
    qr_map = {}
    for lot in lots:
        qr_map[lot.pk] = generate_lot_qr(lot)

    if size == "LABEL_60X70":
        css = """
@page { size: A4 portrait; margin: 5mm; }
* { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: 'DejaVu Sans', Arial, sans-serif; font-size: 8pt; }
.label-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 4mm; }
.label-cell {
  width: 60mm; height: 70mm; border: 0.8pt solid #333;
  border-radius: 2mm; padding: 2mm; display: flex; flex-direction: column;
  overflow: hidden;
}
.label-top { display: flex; gap: 2mm; margin-bottom: 1.5mm; }
.qr-img-lbl { width: 20mm; height: 20mm; flex-shrink: 0; }
.label-meta { flex: 1; min-width: 0; }
.lbl-item-code { font-size: 9pt; font-weight: bold; color: #111; line-height: 1.2; }
.lbl-lot { font-size: 7.5pt; color: #333; margin-top: 1mm; font-family: monospace; }
.lbl-spec { font-size: 7pt; color: #555; margin-top: 0.8mm; }
.lbl-weight { font-size: 11pt; font-weight: bold; color: #1a237e; text-align: center;
              border-top: 0.5pt solid #ccc; border-bottom: 0.5pt solid #ccc;
              padding: 1mm 0; margin: 1mm 0; }
.lbl-bin { font-size: 6.5pt; color: #555; text-align: center; margin-top: auto; }"""

        tag_blocks = "".join(_render_tag_block_label(lot, qr_map[lot.pk]) for lot in lots)
        body_html = f'<div class="label-grid">{tag_blocks}</div>'

    else:  # A4
        css = """
@page { size: A4 portrait; margin: 8mm; }
* { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: 'DejaVu Sans', Arial, sans-serif; font-size: 9pt; color: #111; }
.tag-a4 {
  display: flex; gap: 6mm; width: 100%; min-height: 130mm;
  border: 1pt solid #333; border-radius: 3mm; padding: 6mm;
  margin-bottom: 6mm; page-break-inside: avoid;
  background: #fff;
}
.tag-a4:nth-child(odd) { border-top: 3pt solid #1a237e; }
.tag-a4-left { width: 80mm; flex-shrink: 0; display: flex; flex-direction: column; align-items: center; }
.qr-img-a4 { width: 80mm; height: 80mm; }
.lot-num {
  font-family: 'Courier New', monospace; font-size: 12pt; font-weight: bold;
  color: #1a237e; margin-top: 3mm; letter-spacing: 0.5px; text-align: center;
}
.location-box {
  margin-top: 2mm; background: #f0f4ff; border: 0.5pt solid #c5cae9;
  border-radius: 2mm; padding: 1.5mm 3mm; font-size: 8pt; color: #333;
}
.loc-label { font-weight: bold; color: #1a237e; }
.tag-a4-right { flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 2mm; }
.item-code { font-size: 22pt; font-weight: bold; color: #111; line-height: 1; }
.item-desc { font-size: 14pt; color: #333; line-height: 1.2; margin-bottom: 2mm; }
.specs-line { font-size: 8pt; color: #666; background: #f5f5f5; padding: 1.5mm 2mm; border-radius: 1.5mm; }
.tag-row { display: flex; gap: 4mm; font-size: 9pt; align-items: baseline; }
.lbl { color: #777; min-width: 85px; flex-shrink: 0; }
.val { color: #111; font-weight: 500; }
.weight-row { font-size: 10pt; color: #333; background: #e8f5e9; padding: 2mm; border-radius: 1.5mm; }
.qc-passed { color: #1b5e20; font-weight: bold; }
.qc-pending { color: #e65100; font-weight: bold; }
.qc-rejected { color: #b71c1c; font-weight: bold; }
.qc-on_hold { color: #827717; font-weight: bold; }
.tag-footer { margin-top: auto; font-size: 7pt; color: #aaa; }"""

        tag_blocks = "".join(_render_tag_block_a4(lot, qr_map[lot.pk]) for lot in lots)
        body_html = tag_blocks

    html = f"""<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<style>{css}</style>
</head>
<body>
{body_html}
</body>
</html>"""

    from weasyprint import HTML as WeasyHTML
    return WeasyHTML(string=html).write_pdf()


# ═══════════════════════════════════════════════════════════════════
# CONSUMPTION ANALYTICS — Task 20
# ═══════════════════════════════════════════════════════════════════

def get_avg_daily_consumption(item, plant, days: int = 30) -> Decimal:
    """
    Calculate average daily consumption of an item at a given plant
    over the last {days} days by summing StockIssueLine.issued_qty
    for ISSUED stock issues in that window.

    Returns: Decimal avg daily consumption (0 if no issues found).
    """
    from datetime import timedelta
    from django.db.models import Sum
    from apps.stores.models import StockIssueLine, StockIssue

    cutoff = date.today() - timedelta(days=days)

    total = (
        StockIssueLine.objects
        .filter(
            item=item,
            issue__plant=plant,
            issue__issue_date__gte=cutoff,
            issue__status=StockIssue.IssueStatus.ISSUED,
        )
        .aggregate(total=Sum("issued_qty"))["total"]
    )

    if not total:
        return Decimal("0")

    return (Decimal(str(total)) / Decimal(str(days))).quantize(
        Decimal("0.0001"), rounding="ROUND_HALF_UP"
    )
