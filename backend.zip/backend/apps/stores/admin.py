"""
Stores Module Admin — Section 4
"""
from django.contrib import admin
from apps.stores.models import (
    Warehouse, BinLocation, InventoryLot, InventoryTransaction,
    StockIssue, StockIssueLine,
    StockReturn, StockReturnLine,
    PhysicalVerification, PVLine,
    StockTransfer, StockTransferLine,
    MinMaxAlert,
)


@admin.register(Warehouse)
class WarehouseAdmin(admin.ModelAdmin):
    list_display  = ["code", "name", "warehouse_type", "plant", "is_active"]
    list_filter   = ["warehouse_type", "plant", "is_active"]
    search_fields = ["code", "name"]


@admin.register(BinLocation)
class BinLocationAdmin(admin.ModelAdmin):
    list_display  = ["code", "warehouse", "description", "is_active"]
    list_filter   = ["warehouse", "is_active"]
    search_fields = ["code", "description"]


class InventoryTransactionInline(admin.TabularInline):
    model  = InventoryTransaction
    extra  = 0
    readonly_fields = ["transaction_type", "quantity", "qty_before", "qty_after",
                       "reference_type", "reference_number", "done_by", "created_at"]
    can_delete = False


@admin.register(InventoryLot)
class InventoryLotAdmin(admin.ModelAdmin):
    list_display  = ["lot_number", "item", "warehouse", "bin_location",
                     "current_qty", "qc_status", "status", "receipt_date", "is_bit_roll"]
    list_filter   = ["status", "qc_status", "is_bit_roll", "warehouse", "plant"]
    search_fields = ["lot_number", "roll_number", "item__code"]
    readonly_fields = ["uuid", "qr_code_data", "created_at", "updated_at"]
    inlines       = [InventoryTransactionInline]
    date_hierarchy = "receipt_date"


class StockIssueLineInline(admin.TabularInline):
    model = StockIssueLine
    extra = 0
    readonly_fields = ["lot", "item", "issued_qty", "returned_qty"]


@admin.register(StockIssue)
class StockIssueAdmin(admin.ModelAdmin):
    list_display  = ["issue_number", "issue_date", "issue_type", "status",
                     "from_warehouse", "job_card_number", "issued_by"]
    list_filter   = ["status", "issue_type", "plant"]
    search_fields = ["issue_number", "job_card_number"]
    inlines       = [StockIssueLineInline]


class StockReturnLineInline(admin.TabularInline):
    model = StockReturnLine
    extra = 0
    readonly_fields = ["original_lot", "return_qty", "creates_bit_roll", "bit_roll_lot"]


@admin.register(StockReturn)
class StockReturnAdmin(admin.ModelAdmin):
    list_display  = ["return_number", "return_date", "status", "to_warehouse", "returned_by"]
    list_filter   = ["status", "plant"]
    search_fields = ["return_number"]
    inlines       = [StockReturnLineInline]


class PVLineInline(admin.TabularInline):
    model  = PVLine
    extra  = 0
    readonly_fields = ["lot", "item", "book_qty", "physical_qty", "variance_qty",
                       "variance_type", "scanned_at", "adjustment_posted"]


@admin.register(PhysicalVerification)
class PhysicalVerificationAdmin(admin.ModelAdmin):
    list_display  = ["pv_number", "pv_type", "status", "warehouse", "planned_date",
                     "total_lots_expected", "lots_missing"]
    list_filter   = ["status", "pv_type", "plant", "warehouse"]
    inlines       = [PVLineInline]


@admin.register(MinMaxAlert)
class MinMaxAlertAdmin(admin.ModelAdmin):
    list_display  = ["item", "alert_type", "current_stock", "shortage_qty",
                     "warehouse", "alert_date", "is_resolved"]
    list_filter   = ["alert_type", "is_resolved", "plant"]
    search_fields = ["item__code", "item__name"]
