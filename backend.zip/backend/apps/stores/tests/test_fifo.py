"""
Task 18: FIFO Hard Block Tests
Tests for FIFO enforcement modes: HARD, WARN, OFF
"""
from decimal import Decimal
from datetime import date, timedelta
from django.test import TestCase
from django.contrib.auth import get_user_model
from rest_framework.test import APIClient
from rest_framework import status

from apps.stores.models import (
    Warehouse, BinLocation, InventoryLot, StockIssue,
)
from apps.stores import services

User = get_user_model()


def make_user(username="fifo_test_user"):
    return User.objects.create_user(username=username, password="pass123",
                                     email=f"{username}@test.com")


class FIFOEnforcementTests(TestCase):
    """Test FIFO enforcement: HARD block, WARN, and OFF modes."""

    def setUp(self):
        from apps.core.models import Company, Plant
        from apps.masters.models import ItemGroup, UOM, Item

        self.company = Company.objects.create(name="Trident FIFO Test Co")
        self.plant = Plant.objects.create(
            company=self.company, code="FP1", name="FIFO Plant",
            gstin="24AAKFT4708J2ZY",
            fifo_enforcement='HARD',  # Default to HARD for most tests
        )
        self.user = make_user("fifo_enforcement_user")
        self.user.plant = self.plant
        self.user.save()

        grp = ItemGroup.objects.create(code="08", name="Test Paper")
        uom = UOM.objects.create(code="KG2", name="Kilogram")
        self.item = Item.objects.create(
            code="08-001", name="Test Item FIFO",
            item_group=grp, uom=uom,
            item_type="RM", approval_status="APPROVED",
        )

        self.wh = Warehouse.objects.create(
            plant=self.plant, code="FRM1", name="FIFO RM Store",
            warehouse_type=Warehouse.WarehouseType.RM_STORE,
        )

        # lot_old: received 30 days ago (should be issued first)
        self.lot_old = InventoryLot.objects.create(
            item=self.item, plant=self.plant, warehouse=self.wh,
            lot_number="FIFO-OLD-001",
            original_qty=Decimal("500"),
            current_qty=Decimal("500"),
            receipt_date=date.today() - timedelta(days=30),
            fifo_date=date.today() - timedelta(days=30),
            qc_status=InventoryLot.QCStatus.PASSED,
            status=InventoryLot.LotStatus.AVAILABLE,
        )

        # lot_new: received today (should NOT be issued while lot_old is available)
        self.lot_new = InventoryLot.objects.create(
            item=self.item, plant=self.plant, warehouse=self.wh,
            lot_number="FIFO-NEW-001",
            original_qty=Decimal("300"),
            current_qty=Decimal("300"),
            receipt_date=date.today(),
            fifo_date=date.today(),
            qc_status=InventoryLot.QCStatus.PASSED,
            status=InventoryLot.LotStatus.AVAILABLE,
        )

    def test_check_fifo_violation_returns_dict(self):
        """check_fifo_violation should return a dict with violated/older_lot info."""
        result = services.check_fifo_violation(self.item, self.plant, self.lot_new)
        self.assertIsInstance(result, dict)
        self.assertIn('violated', result)
        self.assertIn('older_lot_number', result)
        self.assertIn('older_lot_date', result)

    def test_fifo_violation_detected_for_newer_lot(self):
        """Should detect violation when issuing newer lot while older lot exists."""
        result = services.check_fifo_violation(self.item, self.plant, self.lot_new)
        self.assertTrue(result['violated'])
        self.assertEqual(result['older_lot_number'], 'FIFO-OLD-001')

    def test_no_fifo_violation_for_older_lot(self):
        """Should not detect violation when issuing the oldest lot."""
        result = services.check_fifo_violation(self.item, self.plant, self.lot_old)
        self.assertFalse(result['violated'])
        self.assertIsNone(result['older_lot_number'])

    def test_hard_block_returns_400(self):
        """HARD enforcement: issuing newer lot while older available → 400."""
        self.plant.fifo_enforcement = 'HARD'
        self.plant.save()

        client = APIClient()
        client.force_authenticate(user=self.user)

        payload = {
            "issue_date": str(date.today()),
            "issue_type": "PRODUCTION",
            "from_warehouse": str(self.wh.pk),
            "lines": [
                {
                    "item_id": str(self.item.pk),
                    "lot_id": str(self.lot_new.pk),
                    "requested_qty": "100",
                }
            ]
        }
        response = client.post('/api/v1/stores/issues/', payload, format='json')
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        response_data = response.json()
        # Should contain error about FIFO violation
        self.assertTrue(
            'lot' in response_data or 'error' in response_data or 'detail' in response_data,
            f"Expected FIFO error in response: {response_data}"
        )

    def test_warn_mode_returns_warning_without_override(self):
        """WARN enforcement: should return 200 with fifo_warning=True (no override header)."""
        self.plant.fifo_enforcement = 'WARN'
        self.plant.save()

        client = APIClient()
        client.force_authenticate(user=self.user)

        payload = {
            "issue_date": str(date.today()),
            "issue_type": "PRODUCTION",
            "from_warehouse": str(self.wh.pk),
            "lines": [
                {
                    "item_id": str(self.item.pk),
                    "lot_id": str(self.lot_new.pk),
                    "requested_qty": "100",
                }
            ]
        }
        response = client.post('/api/v1/stores/issues/', payload, format='json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        response_data = response.json()
        self.assertTrue(response_data.get('fifo_warning'))
        self.assertTrue(response_data.get('requires_override'))

    def test_warn_mode_proceeds_with_override(self):
        """WARN enforcement: issue proceeds when X-FIFO-Override header is set."""
        self.plant.fifo_enforcement = 'WARN'
        self.plant.save()

        client = APIClient()
        client.force_authenticate(user=self.user)

        payload = {
            "issue_date": str(date.today()),
            "issue_type": "PRODUCTION",
            "from_warehouse": str(self.wh.pk),
            "override_reason": "Urgent production requirement",
            "lines": [
                {
                    "item_id": str(self.item.pk),
                    "lot_id": str(self.lot_new.pk),
                    "requested_qty": "100",
                }
            ]
        }
        response = client.post(
            '/api/v1/stores/issues/', payload, format='json',
            HTTP_X_FIFO_OVERRIDE='true'
        )
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)

    def test_warn_mode_override_logged_to_auditlog(self):
        """WARN override should be logged to AuditLog with action=FIFO_OVERRIDE."""
        from apps.core.models import AuditLog
        self.plant.fifo_enforcement = 'WARN'
        self.plant.save()

        client = APIClient()
        client.force_authenticate(user=self.user)

        payload = {
            "issue_date": str(date.today()),
            "issue_type": "PRODUCTION",
            "from_warehouse": str(self.wh.pk),
            "override_reason": "Manager approved override",
            "lines": [
                {
                    "item_id": str(self.item.pk),
                    "lot_id": str(self.lot_new.pk),
                    "requested_qty": "50",
                }
            ]
        }
        response = client.post(
            '/api/v1/stores/issues/', payload, format='json',
            HTTP_X_FIFO_OVERRIDE='true'
        )
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)

        # Check AuditLog
        override_log = AuditLog.objects.filter(action='FIFO_OVERRIDE').first()
        self.assertIsNotNone(override_log)
        self.assertEqual(override_log.new_values.get('reason'), 'Manager approved override')

    def test_off_mode_no_check_performed(self):
        """OFF enforcement: issue proceeds without any FIFO check."""
        self.plant.fifo_enforcement = 'OFF'
        self.plant.save()

        client = APIClient()
        client.force_authenticate(user=self.user)

        payload = {
            "issue_date": str(date.today()),
            "issue_type": "PRODUCTION",
            "from_warehouse": str(self.wh.pk),
            "lines": [
                {
                    "item_id": str(self.item.pk),
                    "lot_id": str(self.lot_new.pk),
                    "requested_qty": "100",
                }
            ]
        }
        response = client.post('/api/v1/stores/issues/', payload, format='json')
        # Should NOT be blocked (201 created)
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        response_data = response.json()
        # Should not have FIFO warning
        self.assertFalse(response_data.get('fifo_warning', False))

    def test_fifo_check_endpoint(self):
        """GET /api/stores/inventory/{id}/fifo-check/ should return violation info."""
        client = APIClient()
        client.force_authenticate(user=self.user)

        url = f'/api/v1/stores/lots/{self.lot_new.pk}/fifo-check/?item={self.item.pk}'
        response = client.get(url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        data = response.json()
        self.assertTrue(data['violated'])
        self.assertEqual(data['older_lot_number'], 'FIFO-OLD-001')
        self.assertIsNotNone(data['older_lot_date'])

    def test_fifo_check_endpoint_no_violation(self):
        """fifo-check on the oldest lot should return violated=False."""
        client = APIClient()
        client.force_authenticate(user=self.user)

        url = f'/api/v1/stores/lots/{self.lot_old.pk}/fifo-check/?item={self.item.pk}'
        response = client.get(url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        data = response.json()
        self.assertFalse(data['violated'])
        self.assertIsNone(data['older_lot_number'])
