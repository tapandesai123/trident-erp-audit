"""
Stores Module Tests — Section 4
Tests for: FIFO, bin assignment, stock issue, bit-roll, physical verification, transfer
"""
from decimal import Decimal
from datetime import date, timedelta
from django.test import TestCase
from django.contrib.auth import get_user_model
from rest_framework.test import APITestCase
from rest_framework import status

from apps.stores.models import (
    Warehouse, BinLocation, InventoryLot, InventoryTransaction,
    StockIssue, StockReturn, PhysicalVerification, PVLine,
)
from apps.stores import services

User = get_user_model()


def make_user(username="testuser"):
    return User.objects.create_user(username=username, password="pass123",
                                     email=f"{username}@test.com")


class FIFOTests(TestCase):
    """Test FIFO lot selection logic."""

    def setUp(self):
        from apps.core.models import Company, Plant
        from apps.masters.models import ItemGroup, UOM, Item

        self.company = Company.objects.create(name="Trident Test")
        self.plant   = Plant.objects.create(company=self.company, code="P1", name="Plant 1",
                                             gstin="24AAKFT4708J2ZY")
        self.user    = make_user("fifo_user")
        self.user.plant = self.plant

        grp  = ItemGroup.objects.create(code="07", name="Kraft Paper")
        uom  = UOM.objects.create(code="KG", name="Kilogram")
        self.item = Item.objects.create(
            code="07-001", name="BF18 150GSM 1200mm",
            item_group=grp, uom=uom,
            item_type="RM", approval_status="APPROVED",
        )

        self.wh = Warehouse.objects.create(
            plant=self.plant, code="RM1", name="RM Store",
            warehouse_type=Warehouse.WarehouseType.RM_STORE
        )

        # Create 3 lots with different receipt dates (FIFO order: lot1 oldest)
        self.lot1 = InventoryLot.objects.create(
            item=self.item, plant=self.plant, warehouse=self.wh,
            lot_number="LOT001", original_qty=Decimal("500"),
            current_qty=Decimal("500"), receipt_date=date.today() - timedelta(days=30),
            fifo_date=date.today() - timedelta(days=30),
            qc_status=InventoryLot.QCStatus.PASSED,
            status=InventoryLot.LotStatus.AVAILABLE,
        )
        self.lot2 = InventoryLot.objects.create(
            item=self.item, plant=self.plant, warehouse=self.wh,
            lot_number="LOT002", original_qty=Decimal("300"),
            current_qty=Decimal("300"), receipt_date=date.today() - timedelta(days=15),
            fifo_date=date.today() - timedelta(days=15),
            qc_status=InventoryLot.QCStatus.PASSED,
            status=InventoryLot.LotStatus.AVAILABLE,
        )
        self.lot3 = InventoryLot.objects.create(
            item=self.item, plant=self.plant, warehouse=self.wh,
            lot_number="LOT003", original_qty=Decimal("200"),
            current_qty=Decimal("200"), receipt_date=date.today(),
            fifo_date=date.today(),
            qc_status=InventoryLot.QCStatus.PASSED,
            status=InventoryLot.LotStatus.AVAILABLE,
        )

    def test_fifo_order_oldest_first(self):
        """FIFO should return lot1 first (oldest)."""
        lots = services.get_fifo_lots(self.item, self.plant)
        self.assertEqual(lots[0].lot_number, "LOT001")
        self.assertEqual(lots[1].lot_number, "LOT002")
        self.assertEqual(lots[2].lot_number, "LOT003")

    def test_fifo_qty_selection_single_lot(self):
        """Requesting 400 KG should return only lot1 (500 available)."""
        lots = services.get_fifo_lots(self.item, self.plant, qty_needed=Decimal("400"))
        self.assertEqual(len(lots), 1)
        self.assertEqual(lots[0].lot_number, "LOT001")

    def test_fifo_qty_selection_multiple_lots(self):
        """Requesting 600 KG should span lot1 + lot2."""
        lots = services.get_fifo_lots(self.item, self.plant, qty_needed=Decimal("600"))
        self.assertEqual(len(lots), 2)

    def test_fifo_insufficient_raises(self):
        """Requesting more than total stock raises ValueError."""
        with self.assertRaises(ValueError):
            services.get_fifo_lots(self.item, self.plant, qty_needed=Decimal("9999"))

    def test_fifo_violation_detection(self):
        """Issuing lot3 when lot1/lot2 available = violation."""
        violation = services.check_fifo_violation(self.item, self.plant, self.lot3)
        self.assertTrue(violation)

    def test_no_fifo_violation_oldest(self):
        """Issuing lot1 (oldest) = no violation."""
        violation = services.check_fifo_violation(self.item, self.plant, self.lot1)
        self.assertFalse(violation)


class BinAssignmentTests(TestCase):
    """Test bin location assignment to lots."""

    def setUp(self):
        from apps.core.models import Company, Plant
        from apps.masters.models import ItemGroup, UOM, Item

        self.company = Company.objects.create(name="T2")
        self.plant   = Plant.objects.create(company=self.company, code="P2", name="Plant 2",
                                             gstin="24AAKFT4708J2ZZ")
        self.user    = make_user("bin_user")

        grp  = ItemGroup.objects.create(code="08", name="Test Group")
        uom  = UOM.objects.create(code="KG2", name="KG")
        self.item = Item.objects.create(
            code="08-001", name="Test Item",
            item_group=grp, uom=uom, item_type="RM", approval_status="APPROVED",
        )
        self.wh  = Warehouse.objects.create(
            plant=self.plant, code="RM2", name="RM Store 2",
            warehouse_type=Warehouse.WarehouseType.RM_STORE
        )
        self.bin_a1 = BinLocation.objects.create(warehouse=self.wh, code="A1")
        self.bin_b2 = BinLocation.objects.create(warehouse=self.wh, code="B2")

        self.lot = InventoryLot.objects.create(
            item=self.item, plant=self.plant, warehouse=self.wh,
            lot_number="BINTEST001",
            original_qty=Decimal("100"), current_qty=Decimal("100"),
            receipt_date=date.today(), fifo_date=date.today(),
            qc_status=InventoryLot.QCStatus.PASSED,
            status=InventoryLot.LotStatus.AVAILABLE,
        )

    def test_assign_bin_updates_lot(self):
        services.assign_bin_to_lot(self.lot, self.bin_a1, self.user, "placed in A1")
        self.lot.refresh_from_db()
        self.assertEqual(self.lot.bin_location, self.bin_a1)

    def test_assign_bin_creates_transaction(self):
        services.assign_bin_to_lot(self.lot, self.bin_a1, self.user)
        txn = InventoryTransaction.objects.filter(lot=self.lot).first()
        self.assertIsNotNone(txn)
        self.assertEqual(txn.transaction_type, InventoryTransaction.TransactionType.TRANSFER)
        self.assertEqual(txn.to_location, self.bin_a1)

    def test_reassign_bin(self):
        services.assign_bin_to_lot(self.lot, self.bin_a1, self.user)
        services.assign_bin_to_lot(self.lot, self.bin_b2, self.user, "moved to B2")
        self.lot.refresh_from_db()
        self.assertEqual(self.lot.bin_location, self.bin_b2)
        txns = InventoryTransaction.objects.filter(lot=self.lot)
        self.assertEqual(txns.count(), 2)


class StockIssueTests(TestCase):
    """Test stock issue creation with FIFO."""

    def setUp(self):
        from apps.core.models import Company, Plant, Department
        from apps.masters.models import ItemGroup, UOM, Item

        self.company = Company.objects.create(name="T3")
        self.plant   = Plant.objects.create(company=self.company, code="P3", name="Plant 3",
                                             gstin="24AAKFT4708J2ZX")
        self.user    = make_user("issue_user")
        self.user.plant = self.plant

        grp  = ItemGroup.objects.create(code="09", name="Test Group 3")
        uom  = UOM.objects.create(code="KG3", name="KG")
        self.item = Item.objects.create(
            code="09-001", name="Issue Test Item",
            item_group=grp, uom=uom, item_type="RM", approval_status="APPROVED",
        )
        self.wh = Warehouse.objects.create(
            plant=self.plant, code="RM3", name="RM Store 3",
            warehouse_type=Warehouse.WarehouseType.RM_STORE
        )
        self.lot = InventoryLot.objects.create(
            item=self.item, plant=self.plant, warehouse=self.wh,
            lot_number="ISSUE001",
            original_qty=Decimal("1000"), current_qty=Decimal("1000"),
            receipt_date=date.today() - timedelta(days=5),
            fifo_date=date.today() - timedelta(days=5),
            qc_status=InventoryLot.QCStatus.PASSED,
            status=InventoryLot.LotStatus.AVAILABLE,
        )

    def test_create_stock_issue_reduces_lot_qty(self):
        issue = services.create_stock_issue(
            data={
                "from_warehouse_id": self.wh.pk,
                "job_card_number": "JC001",
                "issue_type": StockIssue.IssueType.PRODUCTION,
            },
            lines_data=[{"item_id": self.item.pk, "requested_qty": "300"}],
            user=self.user,
            plant=self.plant,
        )
        self.lot.refresh_from_db()
        self.assertEqual(self.lot.current_qty, Decimal("700"))
        self.assertEqual(issue.status, StockIssue.IssueStatus.ISSUED)

    def test_create_stock_issue_creates_transaction(self):
        services.create_stock_issue(
            data={"from_warehouse_id": self.wh.pk},
            lines_data=[{"item_id": self.item.pk, "requested_qty": "100"}],
            user=self.user, plant=self.plant,
        )
        txn = InventoryTransaction.objects.filter(
            lot=self.lot,
            transaction_type=InventoryTransaction.TransactionType.ISSUE
        ).first()
        self.assertIsNotNone(txn)
        self.assertEqual(txn.quantity, Decimal("100"))

    def test_issue_insufficient_stock_raises(self):
        with self.assertRaises(ValueError):
            services.create_stock_issue(
                data={"from_warehouse_id": self.wh.pk},
                lines_data=[{"item_id": self.item.pk, "requested_qty": "9999"}],
                user=self.user, plant=self.plant,
            )


class BitRollTests(TestCase):
    """Test bit-roll creation on partial return."""

    def setUp(self):
        from apps.core.models import Company, Plant
        from apps.masters.models import ItemGroup, UOM, Item

        self.company = Company.objects.create(name="T4")
        self.plant   = Plant.objects.create(company=self.company, code="P4", name="Plant 4",
                                             gstin="24AAKFT4708J2ZW")
        self.user    = make_user("bitroll_user")

        grp  = ItemGroup.objects.create(code="10", name="Test Group 4")
        uom  = UOM.objects.create(code="KG4", name="KG")
        self.item = Item.objects.create(
            code="10-001", name="BitRoll Test Item",
            item_group=grp, uom=uom, item_type="RM", approval_status="APPROVED",
        )
        self.wh  = Warehouse.objects.create(
            plant=self.plant, code="RM4", name="RM Store 4",
            warehouse_type=Warehouse.WarehouseType.RM_STORE
        )
        self.original_lot = InventoryLot.objects.create(
            item=self.item, plant=self.plant, warehouse=self.wh,
            lot_number="ORIG001",
            original_qty=Decimal("500"), current_qty=Decimal("200"),
            receipt_date=date.today() - timedelta(days=10),
            fifo_date=date.today() - timedelta(days=10),
            qc_status=InventoryLot.QCStatus.PASSED,
            status=InventoryLot.LotStatus.ISSUED,
        )

    def test_partial_return_creates_bit_roll(self):
        ret = services.create_stock_return(
            data={"to_warehouse_id": self.wh.pk},
            lines_data=[{
                "original_lot_id": self.original_lot.pk,
                "return_qty": "150",
                "condition": "GOOD",
                "bit_roll_weight_kg": "148.5",
            }],
            user=self.user, plant=self.plant,
        )
        self.assertEqual(ret.status, StockReturn.ReturnStatus.RECEIVED)
        bit_rolls = InventoryLot.objects.filter(is_bit_roll=True, parent_lot=self.original_lot)
        self.assertEqual(bit_rolls.count(), 1)
        br = bit_rolls.first()
        self.assertEqual(br.current_qty, Decimal("150"))
        self.assertEqual(br.net_weight_kg, Decimal("148.5"))
        self.assertTrue(br.lot_number.startswith("BR-ORIG001"))

    def test_bit_roll_inherits_fifo_date(self):
        """Bit roll keeps original lot's FIFO date for proper ageing."""
        services.create_stock_return(
            data={"to_warehouse_id": self.wh.pk},
            lines_data=[{
                "original_lot_id": self.original_lot.pk,
                "return_qty": "50", "condition": "GOOD",
            }],
            user=self.user, plant=self.plant,
        )
        br = InventoryLot.objects.filter(is_bit_roll=True).first()
        self.assertEqual(br.fifo_date, self.original_lot.fifo_date)


class PhysicalVerificationTests(TestCase):
    """Test PV flow: plan → start → scan → complete → post."""

    def setUp(self):
        from apps.core.models import Company, Plant
        from apps.masters.models import ItemGroup, UOM, Item

        self.company = Company.objects.create(name="T5")
        self.plant   = Plant.objects.create(company=self.company, code="P5", name="Plant 5",
                                             gstin="24AAKFT4708J2ZV")
        self.user    = make_user("pv_user")

        grp  = ItemGroup.objects.create(code="11", name="PV Group")
        uom  = UOM.objects.create(code="KG5", name="KG")
        self.item = Item.objects.create(
            code="11-001", name="PV Test Item",
            item_group=grp, uom=uom, item_type="RM", approval_status="APPROVED",
        )
        self.wh  = Warehouse.objects.create(
            plant=self.plant, code="RM5", name="RM Store 5",
            warehouse_type=Warehouse.WarehouseType.RM_STORE
        )
        import uuid as _uuid
        self.lot = InventoryLot.objects.create(
            item=self.item, plant=self.plant, warehouse=self.wh,
            lot_number="PV001",
            original_qty=Decimal("400"), current_qty=Decimal("400"),
            receipt_date=date.today(), fifo_date=date.today(),
            qc_status=InventoryLot.QCStatus.PASSED,
            status=InventoryLot.LotStatus.AVAILABLE,
        )

        self.pv = PhysicalVerification.objects.create(
            plant=self.plant,
            pv_number="PV/2026/001",
            pv_type=PhysicalVerification.PVType.WEEKLY,
            warehouse=self.wh,
            planned_date=date.today(),
        )

    def test_start_pv_creates_expected_lines(self):
        services.start_physical_verification(self.pv, self.user)
        self.pv.refresh_from_db()
        self.assertEqual(self.pv.status, PhysicalVerification.PVStatus.IN_PROGRESS)
        self.assertEqual(self.pv.total_lots_expected, 1)
        lines = PVLine.objects.filter(pv=self.pv)
        self.assertEqual(lines.count(), 1)
        self.assertEqual(lines.first().book_qty, Decimal("400"))

    def test_scan_matched(self):
        import json
        services.start_physical_verification(self.pv, self.user)
        qr_data = {"uuid": str(self.lot.uuid), "lot": "PV001"}
        line = services.record_pv_scan(
            self.pv, json.dumps(qr_data), Decimal("400"), self.user
        )
        self.assertEqual(line.variance_type, PVLine.VarianceType.MATCHED)
        self.assertEqual(line.variance_qty, Decimal("0"))

    def test_scan_short(self):
        import json
        services.start_physical_verification(self.pv, self.user)
        qr_data = {"uuid": str(self.lot.uuid)}
        line = services.record_pv_scan(
            self.pv, json.dumps(qr_data), Decimal("350"), self.user
        )
        self.assertEqual(line.variance_type, PVLine.VarianceType.SHORT)
        self.assertEqual(line.variance_qty, Decimal("-50"))

    def test_complete_pv_summary(self):
        import json
        services.start_physical_verification(self.pv, self.user)
        # Simulate short scan
        qr_data = {"uuid": str(self.lot.uuid)}
        services.record_pv_scan(self.pv, json.dumps(qr_data), Decimal("380"), self.user)
        services.complete_physical_verification(self.pv, self.user)
        self.pv.refresh_from_db()
        self.assertEqual(self.pv.status, PhysicalVerification.PVStatus.COMPLETED)
        self.assertEqual(self.pv.lots_short, 1)
        self.assertEqual(self.pv.lots_matched, 0)

    def test_post_adjustments_updates_lot_qty(self):
        import json
        services.start_physical_verification(self.pv, self.user)
        qr_data = {"uuid": str(self.lot.uuid)}
        services.record_pv_scan(self.pv, json.dumps(qr_data), Decimal("380"), self.user)
        services.complete_physical_verification(self.pv, self.user)
        services.post_pv_adjustments(self.pv, self.user)
        self.lot.refresh_from_db()
        self.assertEqual(self.lot.current_qty, Decimal("380"))


class StoresAPITests(APITestCase):
    """Smoke tests for Stores REST API endpoints."""

    def setUp(self):
        from apps.core.models import Company, Plant
        self.company = Company.objects.create(name="API Test Co")
        self.plant   = Plant.objects.create(company=self.company, code="PA", name="API Plant",
                                             gstin="24AAKFT4708J2ZU")
        self.user = make_user("api_stores")
        self.user.plant = self.plant
        self.user.save()
        self.client.force_authenticate(user=self.user)

        self.wh = Warehouse.objects.create(
            plant=self.plant, code="API1", name="API Warehouse",
            warehouse_type=Warehouse.WarehouseType.RM_STORE,
        )

    def test_list_warehouses(self):
        response = self.client.get("/api/stores/warehouses/")
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_create_warehouse(self):
        response = self.client.post("/api/stores/warehouses/", {
            "plant": self.plant.pk,
            "code": "NEW1",
            "name": "New Warehouse",
            "warehouse_type": "CONSUMABLE_STORE",
        })
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)

    def test_list_bins(self):
        BinLocation.objects.create(warehouse=self.wh, code="X1")
        response = self.client.get("/api/stores/bin-locations/")
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_list_lots(self):
        response = self.client.get("/api/stores/lots/")
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_list_issues(self):
        response = self.client.get("/api/stores/issues/")
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_list_pvs(self):
        response = self.client.get("/api/stores/physical-verifications/")
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_list_alerts(self):
        response = self.client.get("/api/stores/alerts/")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
