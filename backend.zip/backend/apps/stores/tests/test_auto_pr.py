"""
Tests — Task 20: Auto PR from Consumable Consumption History
Covers: get_avg_daily_consumption, auto_raise_consumption_prs task,
        duplicate PR prevention, sufficient-stock skip, notification.
"""
from decimal import Decimal
from datetime import date, timedelta

from django.test import TestCase
from django.contrib.auth import get_user_model

from apps.core.models import Company, Plant, Notification
from apps.masters.models import ItemGroup, UOM, Item
from apps.stores.models import (
    Warehouse, InventoryLot,
    StockIssue, StockIssueLine,
)
from apps.stores.services import get_avg_daily_consumption
from apps.stores.tasks import auto_raise_consumption_prs
from apps.purchase.models import PurchaseRequisition, PRLine

User = get_user_model()


# ─── Fixtures ────────────────────────────────────────────────────────────────

def _make_context():
    """Minimal fixture for auto-PR tests."""
    company = Company.objects.create(name="AutoPR Co", financial_year_start=4)
    plant = Plant.objects.create(company=company, code="AP1", name="AutoPR Plant")

    system_user = User.objects.create_user(
        username="system", email="system@test.com", password="x",
    )
    hod = User.objects.create_user(
        username="pur_hod", email="hod@test.com", password="x", is_staff=True,
    )

    uom = UOM.objects.create(code="LITR", name="Litre")
    igroup = ItemGroup.objects.create(code="CONS", name="Consumables")

    item = Item.objects.create(
        code="INK-001", name="Black Ink",
        item_group=igroup, item_type="CONSUMABLE",
        uom=uom,
        auto_pr_enabled=True,
        auto_pr_lead_days=7,
        max_stock=Decimal("100"),
        is_active=True,
    )

    wh = Warehouse.objects.create(
        plant=plant, code="CSWH", name="Consumable Store",
        warehouse_type=Warehouse.WarehouseType.RM_STORE,
    )

    return dict(
        company=company, plant=plant,
        system_user=system_user, hod=hod,
        uom=uom, item=item, wh=wh,
    )


def _add_stock(ctx, qty: Decimal):
    """Create an InventoryLot with given current_qty."""
    lot = InventoryLot.objects.create(
        item=ctx["item"],
        plant=ctx["plant"],
        warehouse=ctx["wh"],
        original_qty=qty,
        current_qty=qty,
        receipt_date=date.today(),
        fifo_date=date.today(),
        status=InventoryLot.LotStatus.AVAILABLE,
        qc_status=InventoryLot.QCStatus.PASSED,
        created_by=ctx["system_user"],
    )
    return lot


def _add_issue_history(ctx, daily_qty: Decimal, num_days: int):
    """
    Create StockIssue + StockIssueLine records simulating {num_days} days of
    {daily_qty} consumption each day.
    """
    for i in range(num_days):
        issue_date = date.today() - timedelta(days=i + 1)
        # Create a minimal lot to attach the issue line to
        lot = InventoryLot.objects.create(
            item=ctx["item"],
            plant=ctx["plant"],
            warehouse=ctx["wh"],
            original_qty=daily_qty,
            current_qty=Decimal("0"),
            receipt_date=issue_date,
            fifo_date=issue_date,
            status=InventoryLot.LotStatus.CONSUMED,
            qc_status=InventoryLot.QCStatus.PASSED,
            created_by=ctx["system_user"],
        )
        issue = StockIssue.objects.create(
            plant=ctx["plant"],
            issue_number=f"SI-AP-{i:04d}-{issue_date.strftime('%Y%m%d')}",
            issue_date=issue_date,
            issue_type=StockIssue.IssueType.PRODUCTION,
            status=StockIssue.IssueStatus.ISSUED,
            from_warehouse=ctx["wh"],
            issued_by=ctx["system_user"],
        )
        StockIssueLine.objects.create(
            issue=issue,
            lot=lot,
            item=ctx["item"],
            requested_qty=daily_qty,
            issued_qty=daily_qty,
            uom=ctx["uom"],
        )


# ─── Unit Tests: get_avg_daily_consumption ────────────────────────────────────

class AvgDailyConsumptionTest(TestCase):

    def setUp(self):
        self.ctx = _make_context()

    def test_returns_zero_with_no_issues(self):
        avg = get_avg_daily_consumption(self.ctx["item"], self.ctx["plant"], days=30)
        self.assertEqual(avg, Decimal("0"))

    def test_correct_average_with_10_days_1_unit_each(self):
        _add_issue_history(self.ctx, daily_qty=Decimal("1"), num_days=10)
        avg = get_avg_daily_consumption(self.ctx["item"], self.ctx["plant"], days=30)
        # 10 units over 30 days = 0.333…
        expected = Decimal("10") / Decimal("30")
        self.assertAlmostEqual(float(avg), float(expected), places=3)

    def test_correct_average_with_30_days_1_unit_each(self):
        _add_issue_history(self.ctx, daily_qty=Decimal("1"), num_days=30)
        avg = get_avg_daily_consumption(self.ctx["item"], self.ctx["plant"], days=30)
        self.assertAlmostEqual(float(avg), 1.0, places=3)

    def test_ignores_draft_issues(self):
        """DRAFT issues should not count towards consumption."""
        lot = InventoryLot.objects.create(
            item=self.ctx["item"], plant=self.ctx["plant"],
            warehouse=self.ctx["wh"],
            original_qty=Decimal("5"), current_qty=Decimal("5"),
            receipt_date=date.today() - timedelta(days=5),
            fifo_date=date.today() - timedelta(days=5),
            status=InventoryLot.LotStatus.AVAILABLE,
            qc_status=InventoryLot.QCStatus.PASSED,
            created_by=self.ctx["system_user"],
        )
        draft_issue = StockIssue.objects.create(
            plant=self.ctx["plant"],
            issue_number="SI-DRAFT-001",
            issue_date=date.today() - timedelta(days=2),
            issue_type=StockIssue.IssueType.PRODUCTION,
            status=StockIssue.IssueStatus.DRAFT,  # ← DRAFT, not ISSUED
            from_warehouse=self.ctx["wh"],
            issued_by=self.ctx["system_user"],
        )
        StockIssueLine.objects.create(
            issue=draft_issue, lot=lot,
            item=self.ctx["item"], requested_qty=Decimal("5"),
            issued_qty=Decimal("5"), uom=self.ctx["uom"],
        )
        avg = get_avg_daily_consumption(self.ctx["item"], self.ctx["plant"], days=30)
        self.assertEqual(avg, Decimal("0"))


# ─── Task Tests: auto_raise_consumption_prs ───────────────────────────────────

class AutoRaisePRTest(TestCase):

    def setUp(self):
        self.ctx = _make_context()

    def _run_task(self):
        return auto_raise_consumption_prs()

    def test_pr_created_when_stock_below_threshold(self):
        """
        10 days of 1-unit/day issues → avg ≈ 0.333/day.
        Current stock = 5 units → stock_days ≈ 15 days > lead_days=7.
        BUT if we set lead_days=20, it should trigger.
        """
        _add_issue_history(self.ctx, daily_qty=Decimal("1"), num_days=30)
        # avg = 1/day; stock=5; stock_days=5 < lead_days=7 → should trigger
        _add_stock(self.ctx, qty=Decimal("5"))

        result = self._run_task()

        self.assertGreaterEqual(result["prs_created"], 1)
        self.assertTrue(PurchaseRequisition.objects.filter(plant=self.ctx["plant"]).exists())
        pr = PurchaseRequisition.objects.get(plant=self.ctx["plant"])
        self.assertEqual(pr.status, PurchaseRequisition.Status.DRAFT)
        self.assertEqual(pr.lines.count(), 1)
        pr_line = pr.lines.first()
        self.assertEqual(pr_line.item, self.ctx["item"])
        self.assertGreater(pr_line.quantity, 0)

    def test_no_duplicate_pr_when_open_pr_exists(self):
        """Running the task twice should not create a second PR."""
        _add_issue_history(self.ctx, daily_qty=Decimal("1"), num_days=30)
        _add_stock(self.ctx, qty=Decimal("5"))

        result1 = self._run_task()
        self.assertGreaterEqual(result1["prs_created"], 1)

        result2 = self._run_task()
        self.assertEqual(result2["prs_created"], 0)

        # Only one PR should exist
        self.assertEqual(PurchaseRequisition.objects.filter(plant=self.ctx["plant"]).count(), 1)

    def test_no_pr_when_stock_days_exceed_lead_days(self):
        """
        avg = 1/day, stock = 100 units → stock_days=100 > lead_days=7 → no PR.
        """
        _add_issue_history(self.ctx, daily_qty=Decimal("1"), num_days=30)
        _add_stock(self.ctx, qty=Decimal("100"))

        result = self._run_task()
        self.assertEqual(result["prs_created"], 0)
        self.assertFalse(PurchaseRequisition.objects.filter(plant=self.ctx["plant"]).exists())

    def test_no_pr_when_zero_consumption(self):
        """Items with no issue history should be skipped."""
        _add_stock(self.ctx, qty=Decimal("5"))
        result = self._run_task()
        self.assertEqual(result["prs_created"], 0)

    def test_notification_sent_to_hod_on_pr_creation(self):
        """Purchase HOD (is_staff=True) should receive a notification when auto PR is raised."""
        _add_issue_history(self.ctx, daily_qty=Decimal("1"), num_days=30)
        _add_stock(self.ctx, qty=Decimal("5"))

        self._run_task()

        hod_notifications = Notification.objects.filter(user=self.ctx["hod"])
        self.assertGreater(hod_notifications.count(), 0)
        notif = hod_notifications.first()
        self.assertIn("INK-001", notif.title)
        self.assertIn("stock left", notif.title)

    def test_auto_pr_disabled_item_is_skipped(self):
        """Item with auto_pr_enabled=False should never get a PR."""
        self.ctx["item"].auto_pr_enabled = False
        self.ctx["item"].save()

        _add_issue_history(self.ctx, daily_qty=Decimal("1"), num_days=30)
        _add_stock(self.ctx, qty=Decimal("5"))

        result = self._run_task()
        self.assertEqual(result["prs_created"], 0)

    def test_pr_remarks_contain_stock_days_info(self):
        """Auto-generated PR remarks should describe the stock situation."""
        _add_issue_history(self.ctx, daily_qty=Decimal("1"), num_days=30)
        _add_stock(self.ctx, qty=Decimal("5"))

        self._run_task()

        pr = PurchaseRequisition.objects.get(plant=self.ctx["plant"])
        self.assertIn("Auto-generated", pr.remarks)
        self.assertIn("days stock remaining", pr.remarks)
        self.assertIn("avg", pr.remarks)

    def test_items_checked_count_reflects_enabled_items(self):
        """items_checked in result should count plant-item combos with consumption."""
        _add_issue_history(self.ctx, daily_qty=Decimal("1"), num_days=10)
        _add_stock(self.ctx, qty=Decimal("3"))

        result = self._run_task()
        self.assertGreaterEqual(result["items_checked"], 1)
