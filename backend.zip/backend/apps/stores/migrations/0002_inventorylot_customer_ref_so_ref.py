from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):

    dependencies = [
        ('stores', '0001_initial'),
        ('masters', '0001_initial'),
        ('sales', '0001_initial'),
    ]

    operations = [
        migrations.AddField(
            model_name='inventorylot',
            name='customer_ref',
            field=models.ForeignKey(
                blank=True, null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                related_name='inventory_lots',
                to='masters.customer',
                help_text='Customer this lot is reserved/produced for'
            ),
        ),
        migrations.AddField(
            model_name='inventorylot',
            name='so_ref',
            field=models.ForeignKey(
                blank=True, null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                related_name='inventory_lots',
                to='sales.salesorder',
                help_text='Sales Order this lot is linked to'
            ),
        ),
    ]
