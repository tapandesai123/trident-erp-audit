from django.db import migrations, models


class Migration(migrations.Migration):
    """
    Add database indexes for:
    - InventoryLot.expiry_date  (BUG-013: required for FEFO ordering performance)
    - InventoryLot.so_ref       (Performance: SO-based lot queries require full table scan without this)
    """

    dependencies = [
        ('stores', '0002_inventorylot_customer_ref_so_ref'),
    ]

    operations = [
        migrations.AddIndex(
            model_name='inventorylot',
            index=models.Index(fields=['expiry_date'], name='stores_inventorylot_expiry_date_idx'),
        ),
        migrations.AddIndex(
            model_name='inventorylot',
            index=models.Index(fields=['so_ref'], name='stores_inventorylot_so_ref_idx'),
        ),
    ]
