"""
Stores Celery Tasks — Section 4
Periodic tasks:
  - Daily min/max alert check
  - Auto-email for below-minimum items
"""
from celery import shared_task
from django.utils import timezone


@shared_task(name="stores.check_minmax_alerts")
def check_minmax_alerts():
    """
    Run daily (Celery Beat schedule).
    Checks all items against min/max levels and creates alerts.
    Sends email to purchase team for BELOW_MIN / ZERO_STOCK.
    """
    from apps.core.models import Plant
    from apps.stores.services import check_and_create_minmax_alerts

    plants = Plant.objects.filter(is_active=True)
    total_alerts = 0
    for plant in plants:
        count = check_and_create_minmax_alerts(plant)
        total_alerts += count

    return f"Min/max check complete. Alerts created: {total_alerts}"


@shared_task(name="stores.send_minmax_emails")
def send_minmax_emails():
    """
    Send email alerts for unresolved below-min items.
    Run after check_minmax_alerts.
    """
    from apps.stores.models import MinMaxAlert
    from django.core.mail import send_mail
    from django.conf import settings

    unsent = MinMaxAlert.objects.filter(
        is_resolved=False,
        email_sent=False,
        alert_type__in=["BELOW_MIN", "ZERO_STOCK"],
    ).select_related("item", "warehouse", "plant")

    if not unsent.exists():
        return "No alerts to email."

    # Group by plant
    from collections import defaultdict
    plant_alerts = defaultdict(list)
    for alert in unsent:
        plant_alerts[alert.plant].append(alert)

    sent_count = 0
    for plant, alerts in plant_alerts.items():
        lines = []
        for a in alerts:
            lines.append(
                f"• {a.item.code} — {a.item.name} | "
                f"Current: {a.current_stock} | Min: {a.min_level} | "
                f"Short by: {a.shortage_qty} | WH: {a.warehouse.code}"
            )
        body = (
            f"Below Minimum Stock Alert — {plant.name}\n"
            f"Generated: {timezone.now().strftime('%d-%b-%Y %H:%M')}\n\n"
            + "\n".join(lines)
        )
        try:
            send_mail(
                subject=f"[Trident ERP] Below Min Stock Alert — {len(alerts)} item(s)",
                message=body,
                from_email=settings.DEFAULT_FROM_EMAIL,
                recipient_list=getattr(settings, "PURCHASE_ALERT_EMAILS", []),
                fail_silently=True,
            )
            # Mark as sent
            alert_ids = [a.pk for a in alerts]
            MinMaxAlert.objects.filter(pk__in=alert_ids).update(
                email_sent=True, email_sent_at=timezone.now()
            )
            sent_count += len(alerts)
        except Exception:
            pass

    return f"Emails sent for {sent_count} alerts."


@shared_task(name="stores.auto_generate_pv")
def auto_generate_weekly_pv():
    """
    Auto-create a weekly PV plan every Monday for each active warehouse.
    Storekeeper just needs to start and scan.
    """
    from datetime import date
    from apps.core.models import Plant
    from apps.stores.models import Warehouse, PhysicalVerification

    today = date.today()
    if today.weekday() != 0:  # Only on Monday
        return "Not Monday — skipped."

    created = 0
    plants = Plant.objects.filter(is_active=True)
    for plant in plants:
        warehouses = Warehouse.objects.filter(plant=plant, is_active=True)
        for wh in warehouses:
            pv_number = f"PV/{wh.code}/{today.strftime('%Y%m%d')}"
            if not PhysicalVerification.objects.filter(pv_number=pv_number).exists():
                PhysicalVerification.objects.create(
                    plant=plant,
                    pv_number=pv_number,
                    pv_type=PhysicalVerification.PVType.WEEKLY,
                    warehouse=wh,
                    planned_date=today,
                    status=PhysicalVerification.PVStatus.PLANNED,
                )
                created += 1

    return f"Weekly PVs created: {created}"


@shared_task(name="apps.stores.tasks.auto_raise_consumption_prs")
def auto_raise_consumption_prs():
    """
    Daily at 7:00 AM — analyse consumable consumption history and
    auto-raise Purchase Requisitions for items whose projected stock
    will fall below their auto_pr_lead_days threshold.

    Returns dict: {prs_created: N, items_checked: M}
    """
    from decimal import Decimal
    from datetime import date, timedelta
    from django.contrib.auth import get_user_model
    from django.db.models import Sum

    from apps.core.models import Plant, Notification
    from apps.masters.models import Item
    from apps.stores.models import InventoryLot
    from apps.stores.services import get_avg_daily_consumption
    from apps.purchase.models import PurchaseRequisition, PRLine
    from apps.purchase.services import get_next_doc_number

    User = get_user_model()

    # Resolve "system" user: prefer username='system', fall back to first superuser
    system_user = (
        User.objects.filter(username="system").first()
        or User.objects.filter(is_superuser=True).order_by("pk").first()
    )
    if system_user is None:
        return {"error": "No system user found — cannot create PRs", "prs_created": 0, "items_checked": 0}

    # Purchase HOD = staff users (for notification)
    hod_users = list(User.objects.filter(is_staff=True))

    items_checked = 0
    prs_created = 0

    enabled_items = Item.objects.filter(auto_pr_enabled=True, is_active=True).select_related("uom")

    for item in enabled_items:
        # Determine plants that have inventory lots for this item
        plants_with_stock = Plant.objects.filter(
            is_active=True,
            inventory_lots__item=item,
        ).distinct()

        # Also include plants that have issued this item even if stock is zero now
        plants_with_issues = Plant.objects.filter(
            is_active=True,
            stock_issues__lines__item=item,
        ).distinct()

        candidate_plants = (plants_with_stock | plants_with_issues).distinct()

        for plant in candidate_plants:
            items_checked += 1

            # --- Average daily consumption ---
            avg = get_avg_daily_consumption(item, plant, days=30)
            if avg == 0:
                continue

            # --- Current stock ---
            current_stock = (
                InventoryLot.objects
                .filter(item=item, plant=plant, status="AVAILABLE")
                .aggregate(total=Sum("current_qty"))["total"]
            ) or Decimal("0")

            stock_days = current_stock / avg

            if stock_days >= item.auto_pr_lead_days:
                continue  # Enough stock — skip

            # --- Check for existing open PR ---
            open_pr_exists = (
                PRLine.objects
                .filter(
                    item=item,
                    pr__plant=plant,
                    pr__status__in=[
                        PurchaseRequisition.Status.DRAFT,
                        PurchaseRequisition.Status.SUBMITTED,
                        PurchaseRequisition.Status.HOD_APPROVED,
                        PurchaseRequisition.Status.PLANT_HEAD_APPROVED,
                    ],
                )
                .exists()
            )
            if open_pr_exists:
                continue

            # --- Qty to order ---
            qty_to_order = (
                (Decimal(str(item.auto_pr_lead_days)) - stock_days) * avg
                + Decimal(str(item.max_stock))
            ).quantize(Decimal("0.001"))

            if qty_to_order <= 0:
                qty_to_order = avg * Decimal(str(item.auto_pr_lead_days))

            # --- Create PR ---
            pr_number = get_next_doc_number(plant, "PR", "PR")
            pr = PurchaseRequisition.objects.create(
                pr_number=pr_number,
                plant=plant,
                pr_date=date.today(),
                required_date=date.today() + timedelta(days=item.auto_pr_lead_days),
                priority=PurchaseRequisition.Priority.HIGH,
                status=PurchaseRequisition.Status.DRAFT,
                remarks=(
                    f"Auto-generated: {stock_days:.1f} days stock remaining "
                    f"(avg {avg:.2f}/day)"
                ),
                requested_by=system_user,
            )

            PRLine.objects.create(
                pr=pr,
                line_number=1,
                item=item,
                quantity=qty_to_order,
                uom=item.uom,
            )

            prs_created += 1

            # --- Notify purchase HODs ---
            msg = (
                f"Auto PR {pr_number} raised for {item.code} — {item.name}: "
                f"{stock_days:.1f} days stock remaining "
                f"(avg {avg:.2f}/day). Qty ordered: {qty_to_order} {item.uom.code}."
            )
            for hod in hod_users:
                Notification.objects.create(
                    user=hod,
                    title=f"Auto PR raised for {item.code} — {stock_days:.1f} days stock left",
                    message=msg,
                    notification_type="IN_APP",
                    module="purchase",
                    resource="PurchaseRequisition",
                )

    return {"prs_created": prs_created, "items_checked": items_checked}
