"""Customer Portal URL Configuration."""
from django.urls import path
from apps.portal.api.views import (
    PortalLoginView,
    PortalRequestOTPView,
    PortalVerifyOTPView,
    PortalOrderListCreateView,
    PortalOrderDetailView,
    PortalInvoiceListView,
    PortalInvoicePDFView,
    PortalOutstandingView,
    PortalComplaintListCreateView,
)

app_name = "portal"

urlpatterns = [
    # Auth
    path("auth/login/", PortalLoginView.as_view(), name="portal-login"),
    path("auth/request-otp/", PortalRequestOTPView.as_view(), name="portal-request-otp"),
    path("auth/verify-otp/", PortalVerifyOTPView.as_view(), name="portal-verify-otp"),

    # Orders
    path("orders/", PortalOrderListCreateView.as_view(), name="portal-orders"),
    path("orders/<str:so_number>/", PortalOrderDetailView.as_view(), name="portal-order-detail"),

    # Invoices
    path("invoices/", PortalInvoiceListView.as_view(), name="portal-invoices"),
    path("invoices/<uuid:uuid>/pdf/", PortalInvoicePDFView.as_view(), name="portal-invoice-pdf"),

    # Outstanding
    path("outstanding/", PortalOutstandingView.as_view(), name="portal-outstanding"),

    # Complaints
    path("complaints/", PortalComplaintListCreateView.as_view(), name="portal-complaints"),
]
