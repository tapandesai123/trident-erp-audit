"""Portal API Serializers."""
from rest_framework import serializers
from apps.portal.models import CustomerPortalUser


class PortalLoginSerializer(serializers.Serializer):
    email = serializers.EmailField()
    password = serializers.CharField(write_only=True)


class PortalOTPRequestSerializer(serializers.Serializer):
    email = serializers.EmailField()


class PortalOTPVerifySerializer(serializers.Serializer):
    email = serializers.EmailField()
    otp = serializers.CharField(max_length=6, min_length=6)


class PortalComplaintCreateSerializer(serializers.Serializer):
    category = serializers.ChoiceField(choices=[
        "QUALITY", "DELIVERY", "QUANTITY", "BILLING", "PACKAGING", "OTHER"
    ])
    complaint_details = serializers.CharField()
    customer_contact = serializers.CharField(required=False, allow_blank=True)


class PortalOrderCreateSerializer(serializers.Serializer):
    customer_po_number = serializers.CharField(required=False, allow_blank=True)
    required_delivery_date = serializers.DateField(required=False)
    remarks = serializers.CharField(required=False, allow_blank=True)
    lines = serializers.ListField(
        child=serializers.DictField(),
        min_length=1,
    )
