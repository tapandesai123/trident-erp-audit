"""
Portal JWT Authentication.

Uses a separate JWT secret claim 'portal_user_id' to identify
CustomerPortalUser — completely separate from ERP staff JWT.
"""
import jwt
from datetime import datetime, timedelta, timezone
from django.conf import settings
from rest_framework.authentication import BaseAuthentication
from rest_framework.exceptions import AuthenticationFailed

from apps.portal.models import CustomerPortalUser


PORTAL_JWT_ALGORITHM = "HS256"
PORTAL_JWT_LIFETIME_MINUTES = 30  # 30 minutes — reduced for security (was 24 hours)


def _secret():
    from django.core.exceptions import ImproperlyConfigured
    secret = getattr(settings, 'PORTAL_JWT_SECRET_KEY', None)
    if not secret:
        raise ImproperlyConfigured(
            'PORTAL_JWT_SECRET_KEY must be set in settings. '
            'It must be different from SECRET_KEY.'
        )
    return secret


def generate_portal_token(portal_user: CustomerPortalUser) -> str:
    """Generate a signed JWT for a CustomerPortalUser."""
    payload = {
        "portal_user_id": portal_user.pk,
        "customer_id": portal_user.customer_id,
        "email": portal_user.email,
        "exp": datetime.now(tz=timezone.utc) + timedelta(minutes=PORTAL_JWT_LIFETIME_MINUTES),
        "iat": datetime.now(tz=timezone.utc),
        "token_type": "portal_access",
    }
    return jwt.encode(payload, _secret(), algorithm=PORTAL_JWT_ALGORITHM)


def decode_portal_token(token: str) -> dict:
    try:
        return jwt.decode(token, _secret(), algorithms=[PORTAL_JWT_ALGORITHM])
    except jwt.ExpiredSignatureError:
        raise AuthenticationFailed("Portal token has expired.")
    except jwt.InvalidTokenError:
        raise AuthenticationFailed("Invalid portal token.")


class PortalJWTAuthentication(BaseAuthentication):
    """
    DRF authentication class for the customer portal.
    Reads the 'portal_user_id' claim from the Bearer token.
    Returns (CustomerPortalUser, payload) — NOT an ERP staff User.
    """

    def authenticate(self, request):
        auth_header = request.META.get("HTTP_AUTHORIZATION", "")
        if not auth_header.startswith("Bearer "):
            return None

        token = auth_header.split(" ", 1)[1].strip()
        if not token:
            return None

        try:
            payload = decode_portal_token(token)
        except AuthenticationFailed:
            raise

        if payload.get("token_type") != "portal_access":
            return None

        portal_user_id = payload.get("portal_user_id")
        try:
            portal_user = CustomerPortalUser.objects.select_related("customer").get(
                pk=portal_user_id, is_active=True
            )
        except CustomerPortalUser.DoesNotExist:
            raise AuthenticationFailed("Portal user not found or inactive.")

        return (portal_user, payload)

    def authenticate_header(self, request):
        return "Bearer realm='portal'"
