"""
Customer Portal API Views.

All views use PortalJWTAuthentication — completely separate from ERP staff auth.
Rate limiting applied to login endpoint via django-ratelimit.
"""
from datetime import date, timedelta
from decimal import Decimal

from django.core.mail import send_mail
from django.conf import settings as django_settings
from django.utils import timezone
from django.db import transaction
from django.db.models import Sum, Q

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import AllowAny
from rest_framework import status

from apps.portal.models import CustomerPortalUser
from apps.portal.api.auth import PortalJWTAuthentication, generate_portal_token
from apps.portal.api.serializers import (
    PortalLoginSerializer, PortalOTPRequestSerializer,
    PortalOTPVerifySerializer, PortalComplaintCreateSerializer,
    PortalOrderCreateSerializer,
)


# ── Permission ────────────────────────────────────────────────────

class IsPortalAuthenticated:
    """Mixin — ensure request.user is a CustomerPortalUser."""
    authentication_classes = [PortalJWTAuthentication]
    permission_classes = []

    def get_portal_user(self, request):
        user = request.user
        if not isinstance(user, CustomerPortalUser):
            from rest_framework.exceptions import AuthenticationFailed
            raise AuthenticationFailed("Portal authentication required.")
        return user


# ── Rate Limit Helper ─────────────────────────────────────────────

def _rate_limit_login(request):
    """
    Simple in-memory rate limiter: 5 attempts per 15 min per IP.
    Uses Django cache. Falls back gracefully if cache unavailable.
    """
    from django.core.cache import cache

    ip = request.META.get("REMOTE_ADDR", "unknown")
    cache_key = f"portal_login_attempts_{ip}"
    attempts = cache.get(cache_key, 0)
    if attempts >= 5:
        return False
    cache.set(cache_key, attempts + 1, timeout=900)  # 15 min
    return True


def _reset_rate_limit(request):
    from django.core.cache import cache
    ip = request.META.get("REMOTE_ADDR", "unknown")
    cache.delete(f"portal_login_attempts_{ip}")


# ═══════════════════════════════════════════════════════════════════
# AUTH VIEWS
# ═══════════════════════════════════════════════════════════════════

class PortalLoginView(APIView):
    """POST /api/portal/auth/login/"""
    authentication_classes = []
    permission_classes = [AllowAny]

    def post(self, request):
        if not _rate_limit_login(request):
            return Response(
                {"detail": "Too many login attempts. Please try again after 15 minutes."},
                status=status.HTTP_429_TOO_MANY_REQUESTS,
            )

        serializer = PortalLoginSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        email = serializer.validated_data["email"].lower()
        password = serializer.validated_data["password"]

        try:
            portal_user = CustomerPortalUser.objects.select_related("customer").get(
                email__iexact=email, is_active=True
            )
        except CustomerPortalUser.DoesNotExist:
            return Response(
                {"detail": "Invalid email or password."},
                status=status.HTTP_401_UNAUTHORIZED,
            )

        if not portal_user.check_password(password):
            return Response(
                {"detail": "Invalid email or password."},
                status=status.HTTP_401_UNAUTHORIZED,
            )

        portal_user.record_login()
        portal_user.save(update_fields=["last_login"])
        _reset_rate_limit(request)

        token = generate_portal_token(portal_user)
        return Response({
            "access": token,
            "customer_name": portal_user.customer.name,
            "customer_id": str(portal_user.customer.uuid),
        })


class PortalRequestOTPView(APIView):
    """POST /api/portal/auth/request-otp/"""
    authentication_classes = []
    permission_classes = [AllowAny]

    def post(self, request):
        serializer = PortalOTPRequestSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        email = serializer.validated_data["email"].lower()

        try:
            portal_user = CustomerPortalUser.objects.get(email__iexact=email, is_active=True)
        except CustomerPortalUser.DoesNotExist:
            # Security: don't reveal if email exists
            return Response({"detail": "If this email is registered, an OTP has been sent."})

        code = portal_user.generate_otp()
        portal_user.save(update_fields=["otp", "otp_expiry"])

        try:
            send_mail(
                subject="Your Trident ERP Portal OTP",
                message=f"Your one-time password is: {code}\n\nThis OTP is valid for 10 minutes.",
                from_email=django_settings.DEFAULT_FROM_EMAIL,
                recipient_list=[email],
                fail_silently=True,
            )
        except Exception:
            pass

        # Also send OTP via SMS if portal user has a mobile number
        if portal_user.mobile:
            try:
                from apps.core.sms import SMSService
                SMSService.send_otp(portal_user.mobile, code)
            except Exception:
                pass  # SMS is best-effort; email already sent

        return Response({"detail": "If this email is registered, an OTP has been sent."})


class PortalVerifyOTPView(APIView):
    """POST /api/portal/auth/verify-otp/"""
    authentication_classes = []
    permission_classes = [AllowAny]

    def post(self, request):
        # Rate limit OTP verify — prevent brute force (BUG-023)
        if not _rate_limit_login(request):
            return Response({'detail': 'Too many attempts. Please wait 15 minutes.'}, status=429)

        serializer = PortalOTPVerifySerializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        email = serializer.validated_data["email"].lower()
        otp_code = serializer.validated_data["otp"]

        try:
            portal_user = CustomerPortalUser.objects.select_related("customer").get(
                email__iexact=email, is_active=True
            )
        except CustomerPortalUser.DoesNotExist:
            return Response({"detail": "Invalid OTP."}, status=status.HTTP_401_UNAUTHORIZED)

        if not portal_user.verify_otp(otp_code):
            return Response({"detail": "Invalid or expired OTP."}, status=status.HTTP_401_UNAUTHORIZED)

        portal_user.clear_otp()
        portal_user.record_login()
        portal_user.save(update_fields=["otp", "otp_expiry", "last_login"])

        token = generate_portal_token(portal_user)
        return Response({
            "access": token,
            "customer_name": portal_user.customer.name,
            "customer_id": str(portal_user.customer.uuid),
        })


# ═══════════════════════════════════════════════════════════════════
# ORDER VIEWS
# ═══════════════════════════════════════════════════════════════════

class PortalOrderListCreateView(IsPortalAuthenticated, APIView):
    """GET|POST /api/portal/orders/"""
    authentication_classes = [PortalJWTAuthentication]
    permission_classes = []

    def get(self, request):
        portal_user = self.get_portal_user(request)
        customer = portal_user.customer

        from apps.sales.models import SalesOrder, Despatch
        from django.db.models import Count, Sum

        orders = SalesOrder.objects.filter(
            customer=customer,
        ).exclude(
            status="CANCELLED",
        ).select_related("customer").prefetch_related("lines", "despatches").annotate(
            line_count=Count('lines', distinct=True),
            total_qty_sum=Sum('lines__ordered_qty'),
        ).order_by("-so_date", "-created_at")

        result = []
        for so in orders:
            despatches = []
            for d in so.despatches.all().order_by("dc_date"):
                despatches.append({
                    "dc_number": d.dc_number,
                    "date": d.dc_date.isoformat(),
                    "status": d.status,
                    "vehicle_number": d.vehicle_number,
                    "driver_phone": d.driver_phone,
                    "gate_out_time": d.gate_out_time.isoformat() if d.gate_out_time else None,
                    "reached": d.status == Despatch.DespatchStatus.DELIVERED,
                    "reached_at": None,  # Not tracked in current model
                })

            result.append({
                "so_number": so.so_number,
                "so_date": so.so_date.isoformat(),
                "status": so.status,
                "items_count": so.line_count,
                "total_qty": float(so.total_qty_sum or 0),
                "total_amount": float(so.total_amount),
                "delivery_date": so.required_delivery_date.isoformat() if so.required_delivery_date else None,
                "customer_po_number": so.customer_po_number,
                "despatches": despatches,
            })

        return Response(result)

    @transaction.atomic
    def post(self, request):
        portal_user = self.get_portal_user(request)
        customer = portal_user.customer

        serializer = PortalOrderCreateSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        data = serializer.validated_data
        lines_data = data["lines"]

        from apps.sales.models import SalesOrder, SOLine
        from apps.core.models import Plant, DocSequence

        # Use customer's plant or the first plant
        plant = Plant.objects.filter(is_active=True).first()
        if not plant:
            return Response({"detail": "No active plant configured."}, status=status.HTTP_400_BAD_REQUEST)

        # Generate SO number atomically — avoid TOCTOU race with count() (BUG-022)
        today = date.today()
        with transaction.atomic():
            seq, _ = DocSequence.objects.select_for_update().get_or_create(
                plant=plant,
                doc_type='SO_PORTAL',
                defaults={'last_number': 0, 'financial_year': today.strftime('%Y')},
            )
            seq.last_number += 1
            seq.save(update_fields=['last_number'])
            so_number = f"SO-P-{today.strftime('%y%m%d')}-{seq.last_number:04d}"

        so = SalesOrder.objects.create(
            plant=plant,
            so_number=so_number,
            so_date=today,
            so_type=SalesOrder.SOType.REGULAR,
            status=SalesOrder.SOStatus.DRAFT,
            customer=customer,
            customer_po_number=data.get("customer_po_number", ""),
            required_delivery_date=data.get("required_delivery_date"),
            remarks=data.get("remarks", ""),
            internal_notes="Created via Customer Portal",
            portal_source="PORTAL",
        )

        # Create lines
        for i, line in enumerate(lines_data, start=1):
            item_id = line.get("item_id")
            description = line.get("description", "")
            ordered_qty = Decimal(str(line.get("qty", 0)))
            unit_rate = Decimal(str(line.get("unit_rate", 0)))
            required_date = line.get("required_date")

            from apps.masters.models import Item, UOM
            item = None
            if item_id:
                try:
                    item = Item.objects.get(pk=item_id)
                    if not description:
                        description = item.name
                except Item.DoesNotExist:
                    pass

            uom = None
            if item:
                uom = item.uom

            line_total = ordered_qty * unit_rate

            # Apply GST from item master — portal orders must not have 0 GST (BUG-027)
            gst_rate = Decimal('0')
            if item and hasattr(item, 'gst_rate') and item.gst_rate:
                gst_rate = Decimal(str(item.gst_rate))
            # Determine IGST vs CGST+SGST based on customer state vs plant state
            cgst_rate = sgst_rate = igst_rate = Decimal('0')
            gst_amount = Decimal('0')
            if gst_rate > 0:
                customer_state = getattr(customer, 'state', '')
                plant_state = getattr(plant, 'state', '')
                if customer_state and plant_state and customer_state.upper() != plant_state.upper():
                    igst_rate = gst_rate
                    igst_amt = (line_total * igst_rate / Decimal('100')).quantize(Decimal('0.01'))
                    gst_amount = igst_amt
                else:
                    cgst_rate = sgst_rate = gst_rate / Decimal('2')
                    cgst_amt = (line_total * cgst_rate / Decimal('100')).quantize(Decimal('0.01'))
                    gst_amount = cgst_amt * 2
            tax_rate = gst_rate

            SOLine.objects.create(
                so=so,
                line_no=i,
                item=item,
                description=description,
                ordered_qty=ordered_qty,
                uom=uom,
                unit_rate=unit_rate,
                taxable_amt=line_total,
                line_total=line_total + gst_amount,
                tax_rate=tax_rate,
                cgst_rate=cgst_rate,
                sgst_rate=sgst_rate,
                igst_rate=igst_rate,
                gst_amount=gst_amount,
                required_date=required_date,
            )

        # Update SO totals
        total = sum(l.line_total for l in so.lines.all())
        so.subtotal = total
        so.taxable_amount = total
        so.total_amount = total
        so.save(update_fields=["subtotal", "taxable_amount", "total_amount"])

        return Response({
            "so_number": so.so_number,
            "status": so.status,
            "total_amount": float(so.total_amount),
            "source": "PORTAL",
        }, status=status.HTTP_201_CREATED)


class PortalOrderDetailView(IsPortalAuthenticated, APIView):
    """GET /api/portal/orders/<so_number>/"""
    authentication_classes = [PortalJWTAuthentication]
    permission_classes = []

    def get(self, request, so_number):
        portal_user = self.get_portal_user(request)
        customer = portal_user.customer

        from apps.sales.models import SalesOrder, Despatch

        try:
            so = SalesOrder.objects.select_related("customer", "plant").prefetch_related(
                "lines", "lines__item", "despatches"
            ).get(so_number=so_number, customer=customer)
        except SalesOrder.DoesNotExist:
            return Response({"detail": "Order not found."}, status=status.HTTP_404_NOT_FOUND)

        lines = []
        for l in so.lines.all():
            lines.append({
                "line_no": l.line_no,
                "item_code": l.item.item_code if l.item else None,
                "description": l.description,
                "ordered_qty": float(l.ordered_qty),
                "despatched_qty": float(l.despatched_qty),
                "pending_qty": float(l.pending_qty),
                "unit_rate": float(l.unit_rate),
                "line_total": float(l.line_total),
                "required_date": l.required_date.isoformat() if l.required_date else None,
            })

        despatches = []
        for d in so.despatches.all().order_by("dc_date"):
            despatches.append({
                "dc_number": d.dc_number,
                "date": d.dc_date.isoformat(),
                "status": d.status,
                "vehicle_number": d.vehicle_number,
                "driver_name": d.driver_name,
                "driver_phone": d.driver_phone,
                "transporter_name": d.transporter_name,
                "lr_number": d.lr_number,
                "no_of_packages": d.no_of_packages,
                "gate_out_time": d.gate_out_time.isoformat() if d.gate_out_time else None,
                "reached": d.status == Despatch.DespatchStatus.DELIVERED,
            })

        return Response({
            "so_number": so.so_number,
            "so_date": so.so_date.isoformat(),
            "status": so.status,
            "customer_po_number": so.customer_po_number,
            "required_delivery_date": so.required_delivery_date.isoformat() if so.required_delivery_date else None,
            "total_amount": float(so.total_amount),
            "remarks": so.remarks,
            "lines": lines,
            "despatches": despatches,
        })


# ═══════════════════════════════════════════════════════════════════
# INVOICE VIEWS
# ═══════════════════════════════════════════════════════════════════

class PortalInvoiceListView(IsPortalAuthenticated, APIView):
    """GET /api/portal/invoices/"""
    authentication_classes = [PortalJWTAuthentication]
    permission_classes = []

    def get(self, request):
        portal_user = self.get_portal_user(request)
        customer = portal_user.customer

        from apps.sales.models import Invoice

        invoices = Invoice.objects.filter(
            customer=customer,
        ).exclude(
            status="CANCELLED",
        ).order_by("-invoice_date")

        result = []
        for inv in invoices:
            result.append({
                "id": str(inv.uuid),
                "invoice_number": inv.invoice_number,
                "date": inv.invoice_date.isoformat(),
                "total_amount": float(inv.total_amount),
                "outstanding_amount": float(inv.outstanding_amount),
                "irn": inv.irn,
                "ack_number": inv.ack_number,
                "status": inv.status,
                "is_paid": inv.outstanding_amount == 0,
                "pdf_url": f"/api/portal/invoices/{inv.uuid}/pdf/",
            })

        return Response(result)


class PortalInvoicePDFView(IsPortalAuthenticated, APIView):
    """GET /api/portal/invoices/<uuid>/pdf/"""
    authentication_classes = [PortalJWTAuthentication]
    permission_classes = []

    def get(self, request, uuid):
        portal_user = self.get_portal_user(request)
        customer = portal_user.customer

        from apps.sales.models import Invoice
        from django.http import HttpResponse

        try:
            invoice = Invoice.objects.get(uuid=uuid, customer=customer)
        except Invoice.DoesNotExist:
            return Response({"detail": "Invoice not found."}, status=status.HTTP_404_NOT_FOUND)

        # Try WeasyPrint PDF generation (same as existing sales service)
        try:
            from apps.sales.services import generate_invoice_pdf
            pdf_bytes = generate_invoice_pdf(invoice)
            response = HttpResponse(pdf_bytes, content_type="application/pdf")
            response["Content-Disposition"] = (
                f'attachment; filename="{invoice.invoice_number}.pdf"'
            )
            return response
        except Exception:
            # Fallback: return invoice metadata as JSON
            return Response({
                "invoice_number": invoice.invoice_number,
                "detail": "PDF generation unavailable. Please contact support.",
            })


# ═══════════════════════════════════════════════════════════════════
# OUTSTANDING VIEW
# ═══════════════════════════════════════════════════════════════════

class PortalOutstandingView(IsPortalAuthenticated, APIView):
    """GET /api/portal/outstanding/"""
    authentication_classes = [PortalJWTAuthentication]
    permission_classes = []

    def get(self, request):
        portal_user = self.get_portal_user(request)
        customer = portal_user.customer

        from apps.sales.models import Invoice

        today = date.today()
        invoices = Invoice.objects.filter(
            customer=customer,
            outstanding_amount__gt=0,
        ).exclude(status="CANCELLED")

        buckets = {"current": 0, "days_1_30": 0, "days_31_60": 0, "days_61_90": 0, "days_90_plus": 0}
        total = Decimal("0")
        detail = []

        for inv in invoices:
            amt = inv.outstanding_amount
            total += amt
            due = inv.due_date if inv.due_date else (inv.invoice_date + timedelta(days=customer.credit_days))
            overdue_days = (today - due).days if due else 0

            if overdue_days <= 0:
                bucket = "current"
            elif overdue_days <= 30:
                bucket = "days_1_30"
            elif overdue_days <= 60:
                bucket = "days_31_60"
            elif overdue_days <= 90:
                bucket = "days_61_90"
            else:
                bucket = "days_90_plus"

            buckets[bucket] = buckets[bucket] + float(amt)
            detail.append({
                "invoice_number": inv.invoice_number,
                "date": inv.invoice_date.isoformat(),
                "due_date": due.isoformat() if due else None,
                "total_amount": float(inv.total_amount),
                "outstanding_amount": float(amt),
                "overdue_days": overdue_days,
                "bucket": bucket,
            })

        return Response({
            "total_outstanding": float(total),
            "ageing": buckets,
            "invoices": detail,
        })


# ═══════════════════════════════════════════════════════════════════
# COMPLAINT VIEWS
# ═══════════════════════════════════════════════════════════════════

class PortalComplaintListCreateView(IsPortalAuthenticated, APIView):
    """GET|POST /api/portal/complaints/"""
    authentication_classes = [PortalJWTAuthentication]
    permission_classes = []

    def get(self, request):
        portal_user = self.get_portal_user(request)
        customer = portal_user.customer

        from apps.sales.models import CustomerComplaint

        complaints = CustomerComplaint.objects.filter(
            customer=customer,
        ).order_by("-complaint_date")

        result = []
        for c in complaints:
            result.append({
                "complaint_number": c.complaint_number,
                "date": c.complaint_date.isoformat(),
                "category": c.category,
                "status": c.status,
                "details": c.complaint_details,
                "customer_contact": c.customer_contact,
            })

        return Response(result)

    @transaction.atomic
    def post(self, request):
        portal_user = self.get_portal_user(request)
        customer = portal_user.customer

        serializer = PortalComplaintCreateSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        data = serializer.validated_data

        from apps.sales.models import CustomerComplaint
        from apps.core.models import Plant

        plant = Plant.objects.filter(is_active=True).first()
        if not plant:
            return Response({"detail": "No active plant."}, status=status.HTTP_400_BAD_REQUEST)

        today = date.today()
        count = CustomerComplaint.objects.count()
        complaint_number = f"COMP-PORTAL-{today.strftime('%Y%m%d')}-{count + 1:04d}"

        complaint = CustomerComplaint.objects.create(
            plant=plant,
            complaint_number=complaint_number,
            complaint_date=today,
            customer=customer,
            category=data["category"],
            status=CustomerComplaint.ComplaintStatus.OPEN,
            complaint_details=data["complaint_details"],
            customer_contact=data.get("customer_contact", ""),
        )

        return Response({
            "complaint_number": complaint.complaint_number,
            "status": complaint.status,
            "category": complaint.category,
        }, status=status.HTTP_201_CREATED)
