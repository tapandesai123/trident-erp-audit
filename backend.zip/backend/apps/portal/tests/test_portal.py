"""
Customer Portal Tests — Task 14.
Tests for CustomerPortalUser auth, order isolation, order creation, and rate limiting.
"""
from datetime import date
from decimal import Decimal
from unittest.mock import patch, MagicMock

from django.test import TestCase
from django.contrib.auth.hashers import make_password
from rest_framework.test import APIClient


class BasePortalTest(TestCase):
    """Shared test setup for portal tests."""

    def setUp(self):
        from apps.core.models import Company, Plant
        from apps.masters.models import CustomerGroup, Customer
        from apps.portal.models import CustomerPortalUser

        self.company = Company.objects.create(
            name="Trident Paper Box", gstin="24AAKFT4708J2ZY"
        )
        self.plant = Plant.objects.create(
            company=self.company,
            code="PARDI",
            name="Pardi Plant",
            gstin="24AAKFT4708J2ZY",
            state_code="24",
            is_active=True,
        )

        cg = CustomerGroup.objects.create(name="Portal Customers")

        self.customer = Customer.objects.create(
            code="CUST001",
            name="ABC Packaging Pvt Ltd",
            customer_group=cg,
            credit_days=30,
            credit_limit=Decimal("500000"),
        )

        self.other_customer = Customer.objects.create(
            code="CUST002",
            name="XYZ Industries Ltd",
            customer_group=cg,
            credit_days=30,
            credit_limit=Decimal("200000"),
        )

        # Portal user for customer 1
        self.portal_user = CustomerPortalUser.objects.create(
            customer=self.customer,
            email="portal@abcpackaging.com",
            password_hash=make_password("SecurePass123"),
            is_active=True,
        )

        # Portal user for customer 2
        self.other_portal_user = CustomerPortalUser.objects.create(
            customer=self.other_customer,
            email="portal@xyzindustries.com",
            password_hash=make_password("OtherPass123"),
            is_active=True,
        )

        self.client = APIClient()

    def _get_portal_token(self, portal_user=None):
        """Get a JWT for a portal user."""
        from apps.portal.api.auth import generate_portal_token
        user = portal_user or self.portal_user
        return generate_portal_token(user)

    def _auth_client(self, portal_user=None):
        """Return an APIClient authenticated as portal user."""
        token = self._get_portal_token(portal_user)
        client = APIClient()
        client.credentials(HTTP_AUTHORIZATION=f"Bearer {token}")
        return client

    def _make_sales_order(self, customer=None, status="CONFIRMED"):
        """Helper to create a SalesOrder."""
        from apps.sales.models import SalesOrder
        cust = customer or self.customer
        count = SalesOrder.objects.count()
        return SalesOrder.objects.create(
            plant=self.plant,
            so_number=f"SO-TEST-{count + 1:04d}",
            so_date=date.today(),
            status=status,
            customer=cust,
            total_amount=Decimal("50000"),
        )


# ═══════════════════════════════════════════════════════════════════
# AUTH TESTS
# ═══════════════════════════════════════════════════════════════════

class TestPortalLogin(BasePortalTest):

    def test_login_returns_jwt(self):
        """Valid credentials should return an access token."""
        response = self.client.post("/api/portal/auth/login/", {
            "email": "portal@abcpackaging.com",
            "password": "SecurePass123",
        }, format="json")
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertIn("access", data)
        self.assertIn("customer_name", data)
        self.assertIn("customer_id", data)
        self.assertEqual(data["customer_name"], "ABC Packaging Pvt Ltd")

    def test_login_wrong_password_returns_401(self):
        """Wrong password should return 401."""
        response = self.client.post("/api/portal/auth/login/", {
            "email": "portal@abcpackaging.com",
            "password": "WrongPassword",
        }, format="json")
        self.assertEqual(response.status_code, 401)

    def test_login_unknown_email_returns_401(self):
        """Unknown email should return 401."""
        response = self.client.post("/api/portal/auth/login/", {
            "email": "nobody@nowhere.com",
            "password": "any",
        }, format="json")
        self.assertEqual(response.status_code, 401)

    def test_login_inactive_user_returns_401(self):
        """Inactive portal user should not be able to log in."""
        self.portal_user.is_active = False
        self.portal_user.save()
        response = self.client.post("/api/portal/auth/login/", {
            "email": "portal@abcpackaging.com",
            "password": "SecurePass123",
        }, format="json")
        self.assertEqual(response.status_code, 401)

    def test_login_token_is_valid_jwt(self):
        """Returned token should be decodeable with portal auth."""
        response = self.client.post("/api/portal/auth/login/", {
            "email": "portal@abcpackaging.com",
            "password": "SecurePass123",
        }, format="json")
        token = response.json()["access"]

        from apps.portal.api.auth import decode_portal_token
        payload = decode_portal_token(token)
        self.assertEqual(payload["token_type"], "portal_access")
        self.assertEqual(payload["portal_user_id"], self.portal_user.pk)


class TestPortalOTP(BasePortalTest):

    def test_request_otp_known_email(self):
        """OTP request for known email should return 200."""
        response = self.client.post("/api/portal/auth/request-otp/", {
            "email": "portal@abcpackaging.com",
        }, format="json")
        self.assertEqual(response.status_code, 200)

    def test_request_otp_unknown_email(self):
        """OTP request for unknown email should still return 200 (security)."""
        response = self.client.post("/api/portal/auth/request-otp/", {
            "email": "ghost@nowhere.com",
        }, format="json")
        self.assertEqual(response.status_code, 200)

    def test_verify_otp_success(self):
        """Correct OTP within expiry should return JWT."""
        from apps.portal.models import CustomerPortalUser
        from django.utils import timezone

        self.portal_user.otp = "123456"
        self.portal_user.otp_expiry = timezone.now() + timezone.timedelta(minutes=5)
        self.portal_user.save()

        response = self.client.post("/api/portal/auth/verify-otp/", {
            "email": "portal@abcpackaging.com",
            "otp": "123456",
        }, format="json")
        self.assertEqual(response.status_code, 200)
        self.assertIn("access", response.json())

    def test_verify_otp_wrong_code(self):
        """Wrong OTP should return 401."""
        from django.utils import timezone
        self.portal_user.otp = "123456"
        self.portal_user.otp_expiry = timezone.now() + timezone.timedelta(minutes=5)
        self.portal_user.save()

        response = self.client.post("/api/portal/auth/verify-otp/", {
            "email": "portal@abcpackaging.com",
            "otp": "999999",
        }, format="json")
        self.assertEqual(response.status_code, 401)

    def test_verify_otp_expired(self):
        """Expired OTP should return 401."""
        from django.utils import timezone
        self.portal_user.otp = "123456"
        self.portal_user.otp_expiry = timezone.now() - timezone.timedelta(minutes=5)
        self.portal_user.save()

        response = self.client.post("/api/portal/auth/verify-otp/", {
            "email": "portal@abcpackaging.com",
            "otp": "123456",
        }, format="json")
        self.assertEqual(response.status_code, 401)


# ═══════════════════════════════════════════════════════════════════
# ORDERS TESTS
# ═══════════════════════════════════════════════════════════════════

class TestPortalOrders(BasePortalTest):

    def test_unauthenticated_returns_401(self):
        """Unauthenticated request to /api/portal/orders/ should return 401."""
        response = self.client.get("/api/portal/orders/")
        self.assertEqual(response.status_code, 401)

    def test_customer_sees_own_orders_only(self):
        """Customer should only see their own orders."""
        own_order = self._make_sales_order(customer=self.customer)
        other_order = self._make_sales_order(customer=self.other_customer)

        client = self._auth_client()
        response = client.get("/api/portal/orders/")
        self.assertEqual(response.status_code, 200)
        data = response.json()

        so_numbers = [o["so_number"] for o in data]
        self.assertIn(own_order.so_number, so_numbers)
        self.assertNotIn(other_order.so_number, so_numbers)

    def test_cancelled_orders_excluded(self):
        """Cancelled orders should not appear in the list."""
        active_order = self._make_sales_order(status="CONFIRMED")
        cancelled_order = self._make_sales_order(status="CANCELLED")

        client = self._auth_client()
        response = client.get("/api/portal/orders/")
        data = response.json()

        so_numbers = [o["so_number"] for o in data]
        self.assertIn(active_order.so_number, so_numbers)
        self.assertNotIn(cancelled_order.so_number, so_numbers)

    def test_create_order_via_portal(self):
        """Creating an order via portal should create SalesOrder with internal_notes=PORTAL."""
        from apps.sales.models import SalesOrder

        client = self._auth_client()
        response = client.post("/api/portal/orders/", {
            "customer_po_number": "PO-PORTAL-001",
            "lines": [
                {
                    "description": "Corrugated Box 12x8x6",
                    "qty": 500,
                    "unit_rate": 15.50,
                }
            ],
        }, format="json")
        self.assertEqual(response.status_code, 201)

        data = response.json()
        self.assertIn("so_number", data)

        # Verify in DB
        so = SalesOrder.objects.get(so_number=data["so_number"])
        self.assertEqual(so.customer, self.customer)
        self.assertIn("Portal", so.internal_notes)
        self.assertEqual(so.portal_source, "PORTAL")

    def test_create_order_missing_lines_returns_400(self):
        """Order without lines should return 400."""
        client = self._auth_client()
        response = client.post("/api/portal/orders/", {
            "lines": [],
        }, format="json")
        self.assertEqual(response.status_code, 400)

    def test_order_detail_not_found_for_other_customer(self):
        """Customer should not be able to see another customer's order detail."""
        other_order = self._make_sales_order(customer=self.other_customer)

        client = self._auth_client()  # authenticated as customer 1
        response = client.get(f"/api/portal/orders/{other_order.so_number}/")
        self.assertEqual(response.status_code, 404)

    def test_order_detail_returns_correct_structure(self):
        """Order detail should include lines and despatches."""
        order = self._make_sales_order()

        client = self._auth_client()
        response = client.get(f"/api/portal/orders/{order.so_number}/")
        self.assertEqual(response.status_code, 200)

        data = response.json()
        self.assertIn("so_number", data)
        self.assertIn("lines", data)
        self.assertIn("despatches", data)


# ═══════════════════════════════════════════════════════════════════
# INVOICES TESTS
# ═══════════════════════════════════════════════════════════════════

class TestPortalInvoices(BasePortalTest):

    def _make_invoice(self, customer=None, status="CONFIRMED"):
        from apps.sales.models import Invoice
        cust = customer or self.customer
        count = Invoice.objects.count()
        return Invoice.objects.create(
            plant=self.plant,
            invoice_number=f"INV-PORTAL-{count + 1:04d}",
            invoice_date=date.today(),
            status=status,
            customer=cust,
            total_amount=Decimal("25000"),
            outstanding_amount=Decimal("25000"),
        )

    def test_customer_sees_own_invoices_only(self):
        """Invoice list should only show this customer's invoices."""
        own_inv = self._make_invoice(customer=self.customer)
        other_inv = self._make_invoice(customer=self.other_customer)

        client = self._auth_client()
        response = client.get("/api/portal/invoices/")
        self.assertEqual(response.status_code, 200)

        invoice_numbers = [i["invoice_number"] for i in response.json()]
        self.assertIn(own_inv.invoice_number, invoice_numbers)
        self.assertNotIn(other_inv.invoice_number, invoice_numbers)

    def test_invoice_list_has_correct_fields(self):
        """Invoice list items should have required fields."""
        self._make_invoice()
        client = self._auth_client()
        response = client.get("/api/portal/invoices/")
        inv = response.json()[0]

        for key in ["invoice_number", "date", "total_amount", "outstanding_amount", "status", "is_paid", "pdf_url"]:
            self.assertIn(key, inv, f"Missing field: {key}")


# ═══════════════════════════════════════════════════════════════════
# OUTSTANDING TESTS
# ═══════════════════════════════════════════════════════════════════

class TestPortalOutstanding(BasePortalTest):

    def test_outstanding_returns_ageing(self):
        """Outstanding view should return ageing buckets."""
        client = self._auth_client()
        response = client.get("/api/portal/outstanding/")
        self.assertEqual(response.status_code, 200)

        data = response.json()
        self.assertIn("total_outstanding", data)
        self.assertIn("ageing", data)
        ageing = data["ageing"]
        for bucket in ["current", "days_1_30", "days_31_60", "days_61_90", "days_90_plus"]:
            self.assertIn(bucket, ageing)


# ═══════════════════════════════════════════════════════════════════
# COMPLAINTS TESTS
# ═══════════════════════════════════════════════════════════════════

class TestPortalComplaints(BasePortalTest):

    def test_create_complaint_via_portal(self):
        """Creating a complaint via portal should succeed."""
        from apps.sales.models import CustomerComplaint

        client = self._auth_client()
        response = client.post("/api/portal/complaints/", {
            "category": "QUALITY",
            "complaint_details": "Boxes are misaligned on layer 3",
            "customer_contact": "Ramesh Kumar",
        }, format="json")
        self.assertEqual(response.status_code, 201)
        data = response.json()
        self.assertIn("complaint_number", data)
        self.assertEqual(data["status"], "OPEN")

        # Verify in DB
        complaint = CustomerComplaint.objects.get(complaint_number=data["complaint_number"])
        self.assertEqual(complaint.customer, self.customer)
        self.assertEqual(complaint.category, "QUALITY")

    def test_customer_sees_own_complaints_only(self):
        """Complaint list should only show this customer's complaints."""
        from apps.sales.models import CustomerComplaint

        client1 = self._auth_client(self.portal_user)
        client1.post("/api/portal/complaints/", {
            "category": "DELIVERY",
            "complaint_details": "Late delivery",
        }, format="json")

        client2 = self._auth_client(self.other_portal_user)
        client2.post("/api/portal/complaints/", {
            "category": "QUALITY",
            "complaint_details": "Quality issue",
        }, format="json")

        response = client1.get("/api/portal/complaints/")
        self.assertEqual(response.status_code, 200)
        data = response.json()
        # All returned complaints should be for customer 1
        comp_numbers = [c["complaint_number"] for c in data]
        complaints = CustomerComplaint.objects.filter(complaint_number__in=comp_numbers)
        for c in complaints:
            self.assertEqual(c.customer, self.customer)

    def test_complaint_invalid_category_returns_400(self):
        """Invalid complaint category should return 400."""
        client = self._auth_client()
        response = client.post("/api/portal/complaints/", {
            "category": "INVALID_CATEGORY",
            "complaint_details": "Something wrong",
        }, format="json")
        self.assertEqual(response.status_code, 400)


# ═══════════════════════════════════════════════════════════════════
# RATE LIMITING TESTS
# ═══════════════════════════════════════════════════════════════════

class TestPortalRateLimit(BasePortalTest):

    def test_rate_limit_after_5_failed_attempts(self):
        """After 5 failed login attempts, subsequent attempts should return 429."""
        from django.core.cache import cache
        cache.clear()

        for i in range(5):
            self.client.post("/api/portal/auth/login/", {
                "email": "portal@abcpackaging.com",
                "password": "WrongPassword",
            }, format="json")

        # 6th attempt should be rate-limited
        response = self.client.post("/api/portal/auth/login/", {
            "email": "portal@abcpackaging.com",
            "password": "WrongPassword",
        }, format="json")
        self.assertEqual(response.status_code, 429)

    def test_successful_login_resets_rate_limit(self):
        """A successful login should reset the rate limit counter."""
        from django.core.cache import cache
        cache.clear()

        # Make 4 failed attempts
        for i in range(4):
            self.client.post("/api/portal/auth/login/", {
                "email": "portal@abcpackaging.com",
                "password": "WrongPassword",
            }, format="json")

        # Now succeed
        response = self.client.post("/api/portal/auth/login/", {
            "email": "portal@abcpackaging.com",
            "password": "SecurePass123",
        }, format="json")
        self.assertEqual(response.status_code, 200)

        # Another login attempt should work (counter reset)
        response = self.client.post("/api/portal/auth/login/", {
            "email": "portal@abcpackaging.com",
            "password": "SecurePass123",
        }, format="json")
        self.assertEqual(response.status_code, 200)
