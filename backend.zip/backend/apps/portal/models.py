"""
Customer Portal Models.

CustomerPortalUser — standalone auth user for the customer-facing portal.
Completely separate from the ERP staff User model.
"""
from django.db import models
from django.contrib.auth.hashers import make_password, check_password
from django.utils import timezone
from apps.core.models import UUIDModel, TimeStampedModel


class CustomerPortalUser(UUIDModel, TimeStampedModel):
    """
    Authentication model for customer portal users.
    One portal user per customer email. Separate from ERP staff users.
    """
    customer = models.ForeignKey(
        "masters.Customer",
        on_delete=models.CASCADE,
        related_name="portal_users",
    )
    email = models.EmailField(unique=True, db_index=True)
    password_hash = models.CharField(max_length=256)
    mobile = models.CharField(max_length=20, blank=True,
                              help_text="Mobile number for SMS OTP (10 digits, no country code)")
    is_active = models.BooleanField(default=True)

    # OTP for passwordless login
    otp = models.CharField(max_length=6, blank=True)
    otp_expiry = models.DateTimeField(null=True, blank=True)

    last_login = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["email"]

    def __str__(self):
        return f"{self.email} ({self.customer.name})"

    def set_password(self, raw_password: str):
        self.password_hash = make_password(raw_password)

    def check_password(self, raw_password: str) -> bool:
        return check_password(raw_password, self.password_hash)

    def generate_otp(self) -> str:
        import secrets
        from datetime import timedelta
        # Cooldown: don't overwrite an OTP sent in the last 1 minute (BUG-037)
        if self.otp_expiry and timezone.now() < self.otp_expiry - timedelta(minutes=9):
            raise ValueError('OTP already sent within last 1 minute. Please wait before requesting again.')
        # Use cryptographically secure PRNG (BUG-023)
        code = f"{secrets.randbelow(1_000_000):06d}"
        self.otp = code
        self.otp_expiry = timezone.now() + timezone.timedelta(minutes=10)
        return code

    def verify_otp(self, code: str) -> bool:
        if not self.otp or not self.otp_expiry:
            return False
        if timezone.now() > self.otp_expiry:
            return False
        return self.otp == code

    def clear_otp(self):
        self.otp = ""
        self.otp_expiry = None

    def record_login(self):
        self.last_login = timezone.now()
