"""
Integration Test: Full Production Flow
BOM → Work Order → Job Card → WIP stage → in-process QC → FG stock → SO dispatch
"""
from decimal import Decimal
from datetime import date, timedelta
from django.test import TestCase
from django.utils import timezone

from apps.core.models import Company, Plant, Department, User, DocSequence
from apps.masters.models import ItemGroup, UOM, Item, CustomerGroup, Customer
from apps.stores.models import Warehouse, InventoryTransaction
from apps.production.models import (
    ProductionBOMHeader, ProductionBOMLine,
    WorkCenter, WorkOrder, JobCard,
)
from apps.production.services import (
    create_work_order,
    release_work_order,
    complete_job_card,
    close_work_order,
)
from apps.quality.models import (
    SamplingScheme, InspectionPlan, InspectionLot,
)
from apps.sales.models import SalesOrder, SOLine, Despatch, DespatchLine
from apps.sales.services import (
    create_sales_order,
    confirm_sales_order,
    create_despatch,
    record_gate_out,
)


class ProductionFullIntegrationTest(TestCase):
    """End-to-end: BOM → WO → Job Card → In-process QC → FG Stock → SO Despatch."""

    @classmethod
    def setUpTestData(cls):
        # ── Company / Plant ──────────────────────────────────────
        cls.company = Company.objects.create(
            name="Trident Production Test Co",
            gstin="24AAKFT4710J2ZY",
        )
        cls.plant = Plant.objects.create(
            company=cls.company, code="PPVPI", name="Production Test Plant",
            city="Vapi", state="Gujarat",
        )

        # ── Departments ───────────────────────────────────────────
        cls.dept_prod = Department.objects.create(
            plant=cls.plant, code="PPRD", name="Production (IT)"
        )
        cls.dept_qc = Department.objects.create(
            plant=cls.plant, code="PPQC", name="Quality (IT)"
        )
        cls.dept_sales = Department.objects.create(
            plant=cls.plant, code="PPSLS", name="Sales (IT Prod)"
        )

        # ── Users ─────────────────────────────────────────────────
        cls.prod_manager = User.objects.create_user(
            username="pp_prod_mgr", password="Test@1234",
            plant=cls.plant, department=cls.dept_prod,
        )
        cls.qc_user = User.objects.create_user(
            username="pp_qc_user", password="Test@1234",
            plant=cls.plant, department=cls.dept_qc,
        )
        cls.salesman = User.objects.create_user(
            username="pp_salesman", password="Test@1234",
            plant=cls.plant, department=cls.dept_sales,
        )

        # ── UOM ───────────────────────────────────────────────────
        cls.uom_pcs = UOM.objects.create(
            code="PP-PCS", name="Pieces (PP)", decimal_places=0
        )
        cls.uom_kg = UOM.objects.create(
            code="PP-KG", name="Kilograms (PP)", decimal_places=3
        )

        # ── Items ─────────────────────────────────────────────────
        cls.fg_group = ItemGroup.objects.create(
            code="PP-FG", name="PP Finished Goods", item_type="FINISHED_GOOD"
        )
        cls.rm_group = ItemGroup.objects.create(
            code="PP-RM", name="PP Raw Materials", item_type="RAW_MATERIAL"
        )

        cls.fg_item = Item.objects.create(
            code="PP-BOX500", name="5-Ply Corrugated Box (PP)",
            item_group=cls.fg_group, uom=cls.uom_pcs,
            item_type="FINISHED_GOOD",
        )
        cls.rm_paper = Item.objects.create(
            code="PP-PAPER001", name="Kraft Paper 150GSM (PP)",
            item_group=cls.rm_group, uom=cls.uom_kg,
            item_type="RAW_MATERIAL",
        )
        cls.rm_flute = Item.objects.create(
            code="PP-FLUTE001", name="Fluting Medium (PP)",
            item_group=cls.rm_group, uom=cls.uom_kg,
            item_type="RAW_MATERIAL",
        )

        # ── Warehouse ─────────────────────────────────────────────
        cls.fg_warehouse = Warehouse.objects.create(
            plant=cls.plant, code="PP-FG-WH", name="PP FG Warehouse",
        )

        # ── BOM ───────────────────────────────────────────────────
        cls.bom = ProductionBOMHeader.objects.create(
            plant=cls.plant,
            finished_good=cls.fg_item,
            bom_number="PP-BOM-001",
            revision="A",
            base_qty=Decimal("100"),
            base_uom=cls.uom_pcs,
            status="ACTIVE",
            effective_from=date.today() - timedelta(days=30),
            created_by=cls.prod_manager,
        )
        ProductionBOMLine.objects.create(
            bom=cls.bom,
            line_no=10,
            item=cls.rm_paper,
            qty=Decimal("150.000"),  # 1.5 kg per 100 boxes
            uom=cls.uom_kg,
            scrap_pct=Decimal("5"),
        )
        ProductionBOMLine.objects.create(
            bom=cls.bom,
            line_no=20,
            item=cls.rm_flute,
            qty=Decimal("80.000"),  # 0.8 kg per 100 boxes
            uom=cls.uom_kg,
            scrap_pct=Decimal("5"),
        )

        # ── Work Center ───────────────────────────────────────────
        cls.corrugator = WorkCenter.objects.create(
            plant=cls.plant,
            code="PP-WC-CORR",
            name="Corrugator Line 1 (PP)",
            cost_per_hour=Decimal("500.00"),
            capacity_per_shift=Decimal("1000"),
            shifts_per_day=2,
        )
        cls.die_cutting = WorkCenter.objects.create(
            plant=cls.plant,
            code="PP-WC-DIE",
            name="Die Cutting (PP)",
            cost_per_hour=Decimal("350.00"),
            capacity_per_shift=Decimal("800"),
            shifts_per_day=2,
        )

        # ── Quality Plan ──────────────────────────────────────────
        cls.sampling_scheme = SamplingScheme.objects.create(
            plant=cls.plant,
            scheme_name="PP Normal II",
            acceptance_level=Decimal("2.5"),
        )
        cls.in_process_plan = InspectionPlan.objects.create(
            plant=cls.plant,
            item=cls.fg_item,
            trigger="IN_PROCESS",
            plan_name="PP In-Process QC Plan",
            sampling_scheme=cls.sampling_scheme,
            is_mandatory=True,
            is_active=True,
            effective_from=date.today() - timedelta(days=30),
            created_by=cls.qc_user,
        )

        # ── Customer for SO ───────────────────────────────────────
        cls.cust_group = CustomerGroup.objects.create(
            code="PP-CG", name="PP Customer Group"
        )
        cls.customer = Customer.objects.create(
            code="PP-CUST001", name="PP Test Customer",
            customer_group=cls.cust_group,
            city="Surat", state="Gujarat",
        )

        # ── Doc Sequences ─────────────────────────────────────────
        for doc_type, prefix in [
            ("WO", "WO"), ("JC", "JC"), ("SO", "SO"),
            ("DC", "DC"), ("INV", "INV"),
        ]:
            DocSequence.objects.get_or_create(
                plant=cls.plant, doc_type=doc_type,
                defaults={"prefix": prefix, "next_number": 1, "padding": 4},
            )

    def test_full_production_flow(self):
        """BOM → WO → Job Cards → In-process QC → FG stock → SO Despatch."""

        # ── STEP 1: Create Work Order from BOM ────────────────────
        wo = create_work_order(
            plant=self.plant,
            finished_good=self.fg_item,
            planned_qty=Decimal("500"),
            planned_start=date.today(),
            planned_end=date.today() + timedelta(days=3),
            bom=self.bom,
            user=self.prod_manager,
        )
        self.assertIsNotNone(wo)
        self.assertEqual(wo.status, "DRAFT")
        self.assertEqual(wo.planned_qty, Decimal("500"))
        self.assertEqual(wo.bom, self.bom)

        # ── STEP 2: Release WO ────────────────────────────────────
        wo = release_work_order(wo, self.prod_manager)
        wo.refresh_from_db()
        self.assertEqual(wo.status, "RELEASED")

        # ── STEP 3: Create Job Cards manually (corrugation + die cut) ──
        jc1 = JobCard.objects.create(
            work_order=wo,
            jc_number=f"PP-JC-{wo.wo_number}-001",
            operation_name="Corrugation",
            sequence_no=10,
            work_center=self.corrugator,
            assigned_to=self.prod_manager,
            planned_hours=Decimal("5.0"),
            planned_qty=Decimal("500"),
            status="OPEN",
        )
        jc2 = JobCard.objects.create(
            work_order=wo,
            jc_number=f"PP-JC-{wo.wo_number}-002",
            operation_name="Die Cutting",
            sequence_no=20,
            work_center=self.die_cutting,
            assigned_to=self.prod_manager,
            planned_hours=Decimal("4.0"),
            planned_qty=Decimal("500"),
            status="OPEN",
        )
        self.assertEqual(wo.job_cards.count(), 2)

        # ── STEP 4: WIP Stage — In-process QC ─────────────────────
        # QC inspection lot for corrugation
        insp_lot = InspectionLot.objects.create(
            plant=self.plant,
            lot_number=f"PP-QC-{jc1.jc_number}",
            inspection_plan=self.in_process_plan,
            item=self.fg_item,
            job_card=jc1,
            work_order=wo,
            origin_doc="JOBCARD",
            origin_doc_number=jc1.jc_number,
            lot_qty=Decimal("500"),
            uom=self.uom_pcs,
            inspection_date=date.today(),
            status="IN_PROGRESS",
            stage="Corrugation",
            inspector=self.qc_user,
        )
        self.assertIsNotNone(insp_lot)
        self.assertEqual(insp_lot.work_order, wo)

        # QC passes — accept
        insp_lot.status = "ACCEPTED"
        insp_lot.qty_produced = 500
        insp_lot.qty_rejected = 3
        insp_lot.completed_date = date.today()
        insp_lot.remarks = "Minor defects within tolerance"
        insp_lot.save()
        insp_lot.refresh_from_db()
        self.assertEqual(insp_lot.status, "ACCEPTED")

        # ── STEP 5: Complete Job Cards ─────────────────────────────
        jc1 = complete_job_card(
            jc=jc1,
            completed_qty=Decimal("497"),
            rejected_qty=Decimal("3"),
            actual_hours=Decimal("5.5"),
            remarks="Corrugation complete",
            user=self.prod_manager,
        )
        self.assertEqual(jc1.status, "COMPLETED")
        self.assertEqual(jc1.completed_qty, Decimal("497"))

        jc2 = complete_job_card(
            jc=jc2,
            completed_qty=Decimal("497"),
            rejected_qty=Decimal("0"),
            actual_hours=Decimal("4.0"),
            remarks="Die cutting complete",
            user=self.prod_manager,
        )
        self.assertEqual(jc2.status, "COMPLETED")

        # ── STEP 6: WO is auto-completed when all JCs done ────────
        wo.refresh_from_db()
        self.assertEqual(wo.status, "COMPLETED")
        self.assertEqual(wo.produced_qty, Decimal("497"))

        # ── STEP 7: Close WO → FG stock receipt ───────────────────
        wo = close_work_order(wo, self.prod_manager)
        wo.refresh_from_db()
        self.assertEqual(wo.status, "CLOSED")

        # FG inventory transaction created
        fg_transactions = InventoryTransaction.objects.filter(
            item=self.fg_item,
            transaction_type="RECEIPT",
            reference_doc="WO_COMPLETION",
        )
        self.assertGreater(fg_transactions.count(), 0, "FG stock receipt should exist")

        # ── STEP 8: Create SO and Despatch ────────────────────────
        so = create_sales_order(
            data={
                "so_number": f"PP-SO-{SalesOrder.objects.count()+1:04d}",
                "so_date": date.today(),
                "so_type": SalesOrder.SOType.REGULAR,
                "customer_id": str(self.customer.pk),
                "required_delivery_date": date.today() + timedelta(days=2),
            },
            lines_data=[
                {
                    "line_no": 1,
                    "item_id": str(self.fg_item.pk),
                    "description": "5-Ply Corrugated Box",
                    "ordered_qty": Decimal("400"),
                    "uom_id": str(self.uom_pcs.pk),
                    "unit_rate": Decimal("30.00"),
                    "gst_pct": Decimal("18"),
                    "cgst_pct": Decimal("9"),
                    "sgst_pct": Decimal("9"),
                    "igst_pct": Decimal("0"),
                }
            ],
            user=self.salesman,
            plant=self.plant,
        )
        confirm_sales_order(so, self.salesman)
        so.refresh_from_db()
        self.assertEqual(so.status, SalesOrder.SOStatus.CONFIRMED)

        so_line = so.lines.first()
        despatch = create_despatch(
            data={
                "so_id": str(so.pk),
                "despatch_date": date.today(),
                "vehicle_number": "GJ-06-CD-5678",
                "transporter": "Quick Transport",
            },
            lines_data=[
                {
                    "so_line_id": str(so_line.pk),
                    "item_id": str(self.fg_item.pk),
                    "description": "5-Ply Corrugated Box",
                    "uom_id": str(self.uom_pcs.pk),
                    "despatched_qty": Decimal("400"),
                    "unit_rate": Decimal("30.00"),
                }
            ],
            user=self.salesman,
            plant=self.plant,
        )
        self.assertIsNotNone(despatch)
        self.assertEqual(despatch.lines.count(), 1)

        # Gate out
        record_gate_out(despatch, self.salesman)
        despatch.refresh_from_db()
        self.assertIsNotNone(despatch.gate_out_at)

        # ── ASSERT: Final summary ──────────────────────────────────
        self.assertEqual(wo.status, "CLOSED")
        self.assertEqual(insp_lot.status, "ACCEPTED")
        self.assertEqual(jc1.status, "COMPLETED")
        self.assertEqual(jc2.status, "COMPLETED")
        self.assertEqual(despatch.lines.first().despatched_qty, Decimal("400"))

    def test_bom_explosion(self):
        """BOM explosion produces correct material quantities."""
        from apps.production.services import explode_bom, consolidate_explosion

        exploded = explode_bom(self.bom, Decimal("200"))
        consolidated = consolidate_explosion(exploded)

        # Should have 2 raw materials
        self.assertEqual(len(consolidated), 2)
        items = {row["item"].code: row["qty"] for row in consolidated}
        # 150 KG per 100 pcs → 300 KG for 200 pcs (+ 5% scrap)
        self.assertIn("PP-PAPER001", items)
        self.assertIn("PP-FLUTE001", items)

    def test_work_order_wip_stages(self):
        """Work Order progresses through DRAFT → RELEASED → IN_PROGRESS → COMPLETED."""
        wo2 = create_work_order(
            plant=self.plant,
            finished_good=self.fg_item,
            planned_qty=Decimal("100"),
            planned_start=date.today(),
            planned_end=date.today() + timedelta(days=1),
            bom=self.bom,
            user=self.prod_manager,
        )
        self.assertEqual(wo2.status, "DRAFT")

        release_work_order(wo2, self.prod_manager)
        wo2.refresh_from_db()
        self.assertEqual(wo2.status, "RELEASED")

        # Simulate in-progress
        jc_single = JobCard.objects.create(
            work_order=wo2,
            jc_number=f"PP-JC-SINGLE-{wo2.wo_number}",
            operation_name="All Operations",
            sequence_no=10,
            work_center=self.corrugator,
            planned_hours=Decimal("2.0"),
            planned_qty=Decimal("100"),
            status="IN_PROGRESS",
        )
        # Mark WO as in progress
        wo2.status = "IN_PROGRESS"
        wo2.actual_start = date.today()
        wo2.save()
        wo2.refresh_from_db()
        self.assertEqual(wo2.status, "IN_PROGRESS")

        # Complete
        complete_job_card(
            jc=jc_single,
            completed_qty=Decimal("100"),
            rejected_qty=Decimal("0"),
            actual_hours=Decimal("2.5"),
            user=self.prod_manager,
        )
        wo2.refresh_from_db()
        self.assertEqual(wo2.status, "COMPLETED")
