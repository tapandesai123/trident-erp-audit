"""
Integration Test: Full Purchase-to-Payment Flow
PR → approve PR → PO → Gate Entry → MRR → QC pass → Vendor Bill → TDS → Payment
"""
from decimal import Decimal
from datetime import date, timedelta
from django.test import TestCase
from django.utils import timezone

from apps.core.models import Company, Plant, Department, User, DocSequence
from apps.masters.models import (
    VendorGroup, Vendor, ItemGroup, UOM, Item,
)
from apps.stores.models import Warehouse, InventoryLot
from apps.accounts.models import (
    AccountGroup, LedgerAccount, VendorBill, BillPayment, TDSEntry,
)
from apps.purchase.models import (
    PurchaseRequisition, PRLine,
    PurchaseOrder, POLine,
    GateEntry, GateEntryLine,
    MRR, MRRLine,
)
from apps.purchase.services import (
    submit_pr, approve_pr,
    create_po_from_pr,
    approve_po,
    create_gate_entry,
    create_mrr_from_gate_entry,
)
from apps.accounts.services import (
    receive_vendor_bill,
    update_bill_checklist,
    pass_vendor_bill,
    pay_vendor,
)


class PurchaseToPaymentIntegrationTest(TestCase):
    """End-to-end: PR → PO → Gate Entry → MRR → QC pass → Bill → Payment."""

    @classmethod
    def setUpTestData(cls):
        # ── Company / Plant ──────────────────────────────────────
        cls.company = Company.objects.create(
            name="Trident Paper Box Industries",
            gstin="24AAKFT4708J2ZY",
        )
        cls.plant = Plant.objects.create(
            company=cls.company, code="VPI", name="Vapi Plant",
            city="Vapi", state="Gujarat",
        )

        # ── Departments ───────────────────────────────────────────
        cls.dept_purchase = Department.objects.create(
            plant=cls.plant, code="PUR", name="Purchase"
        )
        cls.dept_stores = Department.objects.create(
            plant=cls.plant, code="STR", name="Stores"
        )

        # ── Users ─────────────────────────────────────────────────
        cls.requester = User.objects.create_user(
            username="int_requester", password="Test@1234",
            plant=cls.plant, department=cls.dept_purchase,
        )
        cls.hod = User.objects.create_user(
            username="int_hod", password="Test@1234",
            plant=cls.plant, department=cls.dept_purchase,
        )
        cls.plant_head = User.objects.create_user(
            username="int_ph", password="Test@1234",
            plant=cls.plant,
        )
        cls.director = User.objects.create_user(
            username="int_dir", password="Test@1234",
            plant=cls.plant,
        )
        cls.stores_user = User.objects.create_user(
            username="int_stores", password="Test@1234",
            plant=cls.plant, department=cls.dept_stores,
        )
        cls.accounts_user = User.objects.create_user(
            username="int_accounts", password="Test@1234",
            plant=cls.plant,
        )

        # ── Vendor ────────────────────────────────────────────────
        cls.vendor_group = VendorGroup.objects.create(
            code="INT-CR", name="Integration Creditors"
        )
        cls.vendor = Vendor.objects.create(
            code="INT-V001", name="Integration Paper Mills",
            vendor_group=cls.vendor_group, vendor_type="SUPPLIER",
            gstin="24AABCP1234M1Z5", gst_type="REGULAR",
            city="Vapi", state="Gujarat", is_approved=True,
        )

        # ── Item ──────────────────────────────────────────────────
        cls.uom = UOM.objects.create(
            code="INT-KG", name="Kilograms (INT)", decimal_places=3
        )
        cls.item_group = ItemGroup.objects.create(
            code="INT-07", name="Integration Kraft Paper", item_type="RAW_MATERIAL"
        )
        cls.item = Item.objects.create(
            code="INT-KP001", name="Kraft Paper 150 GSM (INT)",
            item_group=cls.item_group, uom=cls.uom,
            item_type="RAW_MATERIAL",
        )

        # ── Warehouse ─────────────────────────────────────────────
        cls.warehouse = Warehouse.objects.create(
            plant=cls.plant, code="INT-WH01", name="Integration Main Store",
        )

        # ── Accounts: Ledger for bank payment ────────────────────
        cls.ag_assets = AccountGroup.objects.create(
            plant=cls.plant, code="INT-AS", name="Integration Assets",
            group_type=AccountGroup.GroupType.ASSETS,
        )
        cls.bank_ledger = LedgerAccount.objects.create(
            plant=cls.plant, code="INT-BANK01", name="Integration Bank Account",
            account_group=cls.ag_assets, ledger_type="BANK",
            opening_balance=Decimal("5000000"),
        )

        # ── Doc Sequences ─────────────────────────────────────────
        for seq_type, prefix in [
            ("PR", "PR"), ("PO", "PO"), ("GE", "GE"),
            ("MRR", "MRR"), ("VBILL", "VBILL"), ("VP", "VP"),
            ("BP", "BP"), ("JV", "JV"),
        ]:
            DocSequence.objects.get_or_create(
                plant=cls.plant, doc_type=f"INT-{seq_type}",
                defaults={"prefix": f"INT{prefix}", "next_number": 1, "padding": 4},
            )
            # Also create without prefix for services that look up without "INT-"
            DocSequence.objects.get_or_create(
                plant=cls.plant, doc_type=seq_type,
                defaults={"prefix": prefix, "next_number": 1, "padding": 4},
            )

    # ─────────────────────────────────────────────────────────────
    def _create_pr(self):
        """Create and return a draft PR with one line."""
        pr = PurchaseRequisition.objects.create(
            plant=self.plant,
            department=self.dept_purchase,
            pr_number=f"INT-PR-{PurchaseRequisition.objects.count()+1:04d}",
            pr_date=date.today(),
            required_date=date.today() + timedelta(days=14),
            priority=PurchaseRequisition.Priority.NORMAL,
            status=PurchaseRequisition.Status.DRAFT,
            requested_by=self.requester,
        )
        PRLine.objects.create(
            pr=pr,
            item=self.item,
            uom=self.uom,
            quantity=Decimal("1000.000"),
            estimated_rate=Decimal("50.00"),
        )
        return pr

    def test_full_purchase_to_payment_flow(self):
        """Assert each step's DB state in the purchase-to-payment journey."""

        # ── STEP 1: Create PR ─────────────────────────────────────
        pr = self._create_pr()
        self.assertEqual(pr.status, PurchaseRequisition.Status.DRAFT)
        self.assertEqual(pr.lines.count(), 1)

        # ── STEP 2: Submit PR ─────────────────────────────────────
        submit_pr(pr, self.requester)
        pr.refresh_from_db()
        self.assertEqual(pr.status, PurchaseRequisition.Status.SUBMITTED)

        # ── STEP 3: Approve PR (HOD → Plant Head → Director) ─────
        approve_pr(pr, self.hod, "HOD", "APPROVE", remarks="OK by HOD")
        pr.refresh_from_db()
        self.assertEqual(pr.status, PurchaseRequisition.Status.HOD_APPROVED)

        approve_pr(pr, self.plant_head, "PLANT_HEAD", "APPROVE", remarks="OK by PH")
        pr.refresh_from_db()
        self.assertEqual(pr.status, PurchaseRequisition.Status.PLANT_HEAD_APPROVED)

        approve_pr(pr, self.director, "DIRECTOR", "APPROVE", remarks="OK by Dir")
        pr.refresh_from_db()
        self.assertIn(
            pr.status,
            (
                PurchaseRequisition.Status.DIRECTOR_APPROVED,
                PurchaseRequisition.Status.PLANT_HEAD_APPROVED,
            ),
            "PR should be fully approved after director sign-off",
        )

        # ── STEP 4: Create PO from PR ─────────────────────────────
        po = create_po_from_pr(pr, self.vendor, self.requester, po_type="FIXED_QTY")
        self.assertIsNotNone(po)
        self.assertEqual(po.vendor, self.vendor)
        self.assertEqual(po.lines.count(), 1)

        # ── STEP 5: Approve PO ───────────────────────────────────
        approve_po(po, self.director, "APPROVE", remarks="PO approved")
        po.refresh_from_db()
        self.assertEqual(po.status, PurchaseOrder.Status.APPROVED)

        # ── STEP 6: Gate Entry ────────────────────────────────────
        ge_data = {
            "gate_entry_number": f"INT-GE-{GateEntry.objects.count()+1:04d}",
            "vendor_id": str(self.vendor.pk),
            "vehicle_number": "GJ-06-AB-1234",
            "entry_datetime": timezone.now(),
            "remarks": "Integration test delivery",
        }
        ge_lines = [
            {
                "po_line_id": str(po.lines.first().pk),
                "item_id": str(self.item.pk),
                "uom_id": str(self.uom.pk),
                "received_qty": Decimal("1000.000"),
                "gross_weight": Decimal("1050.000"),
                "tare_weight": Decimal("50.000"),
                "net_weight": Decimal("1000.000"),
                "packing": "Rolls",
            }
        ]
        gate_entry = create_gate_entry(ge_data, ge_lines, self.stores_user, self.plant)
        self.assertIsNotNone(gate_entry)
        self.assertEqual(gate_entry.lines.count(), 1)

        # ── STEP 7: MRR from Gate Entry ───────────────────────────
        mrr = create_mrr_from_gate_entry(gate_entry, self.warehouse, self.stores_user)
        self.assertIsNotNone(mrr)
        self.assertEqual(mrr.lines.count(), 1)

        # Inventory lot created
        lots = InventoryLot.objects.filter(mrr=mrr)
        self.assertGreater(lots.count(), 0, "MRR should create inventory lots")

        # ── STEP 8: QC pass — mark lots as PASSED ────────────────
        lots.update(qc_status="PASSED")
        for lot in lots:
            self.assertEqual(lot.qc_status, "PASSED")

        # ── STEP 9: Receive Vendor Bill ───────────────────────────
        bill = receive_vendor_bill(
            data={
                "vendor_id": str(self.vendor.pk),
                "mrr_id": str(mrr.pk),
                "vendor_bill_ref": "ABM/INV/2026/001",
                "vendor_bill_date": date.today(),
                "received_date": date.today(),
                "taxable_amount": Decimal("50000.00"),
                "cgst_amount": Decimal("4500.00"),
                "sgst_amount": Decimal("4500.00"),
                "igst_amount": Decimal("0"),
                "total_amount": Decimal("59000.00"),
                "due_date": date.today() + timedelta(days=30),
            },
            user=self.accounts_user,
            plant=self.plant,
        )
        self.assertIsNotNone(bill)
        self.assertEqual(bill.status, VendorBill.BillStatus.RECEIVED)
        self.assertEqual(bill.vendor, self.vendor)

        # ── STEP 10: Update checklist (TDS 194C @ 2%) ─────────────
        bill = update_bill_checklist(
            bill,
            checklist_data={
                "chk_pr_authorised": True,
                "chk_po_approved": True,
                "chk_gate_entry_done": True,
                "chk_mrr_qty_match": True,
                "chk_qc_passed": True,
                "chk_gst_copy_received": True,
                "chk_accounts_paper_ok": True,
                "chk_calculation_verified": True,
                "checklist_remarks": "All verified – integration test",
            },
            user=self.accounts_user,
        )
        self.assertTrue(bill.checklist_complete)
        self.assertEqual(bill.checklist_score, 8)

        # ── STEP 11: Pass Bill ─────────────────────────────────────
        # Set TDS on bill before passing
        bill.tds_section = "194C"
        bill.tds_rate = Decimal("2.00")
        bill.save()

        bill = pass_vendor_bill(bill, self.accounts_user, self.plant)
        bill.refresh_from_db()
        self.assertEqual(bill.status, VendorBill.BillStatus.PASSED)
        self.assertGreater(bill.outstanding, 0)

        # ── STEP 12: Pay Vendor ────────────────────────────────────
        payment = pay_vendor(
            data={
                "vendor_bill_id": str(bill.pk),
                "payment_date": date.today(),
                "payment_mode": "NEFT",
                "gross_amount": bill.outstanding,
                "bank_account_id": str(self.bank_ledger.pk),
                "utr_number": "NEFT20260225001",
                "remarks": "Integration test payment",
            },
            user=self.accounts_user,
            plant=self.plant,
        )
        self.assertIsNotNone(payment)

        # ── ASSERT: Final DB state ─────────────────────────────────
        bill.refresh_from_db()
        self.assertEqual(bill.status, VendorBill.BillStatus.PAID)
        self.assertEqual(bill.outstanding, Decimal("0"))

        # TDS entry created
        tds_entries = TDSEntry.objects.filter(vendor=self.vendor, plant=self.plant)
        self.assertGreater(tds_entries.count(), 0, "TDS entry should be created on payment")

        # Vouchers created
        payment.refresh_from_db()
        self.assertIsNotNone(payment.voucher)

        # Summary assertions
        self.assertEqual(pr.lines.count(), 1)
        self.assertEqual(po.lines.count(), 1)
        self.assertEqual(gate_entry.lines.count(), 1)
        self.assertEqual(mrr.lines.count(), 1)
